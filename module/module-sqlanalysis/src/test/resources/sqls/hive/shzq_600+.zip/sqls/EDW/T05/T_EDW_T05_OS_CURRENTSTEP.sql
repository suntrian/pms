--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:操作流程表                                                                           */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
 TRUNCATE TABLE EDW_PROD.T_EDW_T05_OS_CURRENTSTEP;
------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T05_OS_CURRENTSTEP
(
                                    ID                 --ID
                                   ,ENTRY_ID           --wtentry ID
                                   ,STEP_ID            --步骤ID
                                   ,ACTION_ID          --操作ID
                                   ,OWNER              --分配执行人
                                   ,START_DATE         --开始时间
                                   ,FINISH_DATE        --结束时间
                                   ,DUE_DATE           --有效时间
                                   ,STATUS             --状态
                                   ,CALLER             --执行人
                                   ,FLAG               --标志
                                   ,SUMMARY            --摘要
                                   ,CONSIGNER          --委托人
								   ,XTBS         
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.ID              as ID               --ID
                                   ,t.ENTRY_ID        as ENTRY_ID         --wtentry ID
                                   ,t.STEP_ID         as STEP_ID          --步骤ID
                                   ,t.ACTION_ID       as ACTION_ID        --操作ID
                                   ,t.OWNER           as OWNER            --分配执行人
                                   ,t.START_DATE      as START_DATE       --开始时间
                                   ,t.FINISH_DATE     as FINISH_DATE      --结束时间
                                   ,t.DUE_DATE        as DUE_DATE         --有效时间
                                   ,t.STATUS          as STATUS           --状态
                                   ,t.CALLER          as CALLER           --执行人
                                   ,t.FLAG            as FLAG             --标志
                                   ,t.SUMMARY         as SUMMARY          --摘要
                                   ,t.CONSIGNER       as CONSIGNER        --委托人
                                   ,'YGTCX'		      as XTBS  					   
 FROM 		YGTCX.CIF_OS_CURRENTSTEP 	 				t
 WHERE 		t.DT = '%d{yyyyMMdd}';
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_OS_CURRENTSTEP',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_OS_CURRENTSTEP;
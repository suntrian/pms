 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:交易权限申请表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
   TRUNCATE TABLE EDW_PROD.T_EDW_T02_TJYQXSQ;
-------插入数据开始------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TJYQXSQ(
                                    JYQXSQID                            --交易权限申请主键                           
                                   ,SQRQ                                --申请日期                               
                                   ,SQSJ                                --申请时间                               
                                   ,KHH                                 --客户号                                
                                   ,KHMC                                --客户名称                               
                                   ,YYB                                 --营业部                                
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,SQFX                                --申请方向                               
                                   ,JYQX                                --交易权限                               
                                   ,QSRQ                                --签署日期                               
                                   ,KSRQ                                --生效日期                               
                                   ,JSRQ                                --失效日期                               
                                   ,SQGY                                --申请柜员                               
                                   ,SHGY                                --审核柜员                               
                                   ,JYQXCLBZ                            --交易权限处理标志                           
                                   ,SBRQ                                --申报日期                               
                                   ,HBJG                                --回报结果                               
                                   ,JGSM                                --结果说明                               
                                   ,SQYY                                --申请原因                               
                                   ,YWXT                                --业务系统                               
                                   ,YWZH                                --业务帐号                               
                                   ,YWQQID                              --业务请求主键                             
                                   ,YWQQCLID                            --业务请求处理主键                           
                                   ,KHZC                                --客户资产  
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
select 
                                    t.ID                                  as JYQXSQID                            --ID                                  
                                   ,t.SQRQ                                as SQRQ                                --申请日期                                
                                   ,t.SQSJ                                as SQSJ                                --申请时间                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHMC                                as KHMC                                --客户名称                                
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                 as YYB                                 --营业部                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.SQFX                                as SQFX                                --申请方向                                
                                   ,t.JYQX                                as JYQX                                --交易权限                                
                                   ,t.QSRQ                                as QSRQ                                --签署日期                                
                                   ,t.KSRQ                                as KSRQ                                --生效日期                                
                                   ,t.JSRQ                                as JSRQ                                --失效日期                                
                                   ,t.SQGY                                as SQGY                                --申请柜员                                
                                   ,t.SHGY                                as SHGY                                --审核柜员                                
                                   ,CASE WHEN t.SQRQ < 20110630 AND t.CLBZ IN (2,3) 
								         THEN '1'
								         ELSE CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.CLBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) 
										 END                              as JYQXCLBZ                            --处理标志                                
                                   ,t.SBRQ                                as SBRQ                                --申报日期                                
                                   ,t.HBJG                                as HBJG                                --回报结果                                
                                   ,t.JGSM                                as JGSM                                --结果说明                                
                                   ,t.SQYY                                as SQYY                                --申请原因                                
                                   ,t.YWXT                                as YWXT                                --业务系统                                
                                   ,t.YWZH                                as YWZH                                --业务帐号                                
                                   ,t.YWQQID                              as YWQQID                              --业务请求ID                              
                                   ,t.YWQQCLID                            as YWQQCLID                            --业务请求处理ID                            
                                   ,t.KHZC                                as KHZC                                --客户资产     
                                   ,'YGT_GT'								   
 FROM           YGTCX.CIF_TJYQXSQ                      t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'ZJLBDM'
 AND            t1.YXT = 'YGT_GT'
 AND            t1.YDM = CAST(t.ZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'JYQXCLBZ'
 AND            t2.YXT = 'YGT_GT'
 AND            t2.YDM = CAST(t.CLBZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'JYS'
 AND            t3.YXT = 'YGT_GT'
 AND            t3.YDM = CAST(t.JYS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t4
 ON             t4.YXT = 'CIF'
 AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
-----插入数据结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TJYQXSQ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TJYQXSQ;

------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:内部机构分公司部门表                                                                */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
TRUNCATE TABLE DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT ;
INSERT OVERWRITE DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT
(                                  FILIL_DEPT_CDG            --分公司部门编码
                                  ,FILIL_DEPT_FULLNM         --分公司部门全称
                                  ,FILIL_DEPT_SHRTNM         --分公司部门简称                            	
                                  ,BELTO_PROV                --所属省        
								  ,BELTO_CITY                --所属市 								                                   								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT    DISTINCT     t.MBJGDM                 as FILIL_DEPT_CDG            --分公司部门编码                        
                        ,t.MBJGQC                as FILIL_DEPT_FULLNM         --分公司部门全称
                        ,t.MBJGJC                as FILIL_DEPT_SHRTNM         --分公司部门简称                                       						   
                        ,t.SF                    as BELTO_PROV                --所属省       
                        ,t.CS                    as BELTO_CITY                --所属市 		

 FROM           EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING                t       
 WHERE          t.JGLB NOT IN ('3')
;		
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_INR_ORG_FILIL_DEPT',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
       invalidate metadata DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT ;
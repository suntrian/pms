--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:基金净值历史表                                                                       */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
---注解FLAG(0正常代码,1退市代码,,3,需要考虑的代码)
 ---前端代码和后端代码转换转换基金交易代码--
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TOF_JJJZ_TEMP;
 CREATE TABLE EDW_PROD.T_EDW_T04_TOF_JJJZ_TEMP as
 SELECT ApplyingCodeFront as ZQDM1,SecurityCode as ZQDM,a.DT
 FROM   FUNDEXT.DBO_MF_FundArchives  a
 WHERE a.DT = '%d{yyyyMMdd}'
 AND    length(trim(NVL(a.ApplyingCodeFront,'')))>0
 AND   length(trim(NVL(a.SecurityCode,'')))>0 
 AND   a.ApplyingCodeFront <> a.SecurityCode
 AND   substr(a.securitycode,7,1) <> 'J'
 UNION 
 SELECT ApplyingCodeBack as ZQDM1,SecurityCode as ZQDM,a.DT
 FROM   FUNDEXT.DBO_MF_FundArchives  a
 WHERE a.DT = '%d{yyyyMMdd}'
 AND    length(trim(NVL(a.ApplyingCodeBack,'')))>0
 AND   length(trim(NVL(a.SecurityCode,'')))>0 
 AND   a.ApplyingCodeBack <> a.SecurityCode
 AND   substr(a.securitycode,7,1) <> 'J'
 ;

------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TOF_JJJZ
 (
                                     RQ                                                --日期
                                    ,TADM                                              --TA代码
                                    ,JJDM                                              --基金代码
                                    ,ZXJZ                                              --最新净值
                                    ,LJJZ                                              --累计净值
                                    ,MWFSY                                             --每万份收益
                                    ,NSYL                                              --年收益率
                                    ,FLAG                                              --标志
									,XTBS                                    									
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT                distinct  
                                     t.RQ          as RQ                               --日期
                                    ,t.TADM        as TADM                             --TA代码
                                    ,CASE WHEN a2.ZQDM1 IS NOT NULL
									      THEN a2.ZQDM
										  ELSE t.JJDM
										  END      as JJDM                             --基金代码
                                    ,t.ZXJZ        as ZXJZ                             --最新净值
                                    ,t.LJJZ        as LJJZ                             --累计净值
                                    ,t.MWFSY       as NWFSY                            --每万份收益
                                    ,t.NSYL        as NSYL                             --年收益率 
                                    ,CASE WHEN SUBSTR(t.JJDM,1,1) = 'A'
                                          THEN 0
                                          WHEN SUBSTR(t.JJDM,1,2) = '95'
                                          THEN 0
                                          WHEN a1.ZQDM IS NOT NULL AND	 %d{yyyyMMdd} BETWEEN a1.SSRQ AND a1.TSRQ
                                          THEN 0
										  WHEN t.JJDM IN ('00954','536068','2460021','328004','1A0017','370003')
										  THEN 0
                                          WHEN a1.ZQDM IS NULL
                                          THEN 3
                                          ELSE 1
                                          END      as FLAG										  
                                    ,'JZJY'        as XTBS     									
 FROM 		 JZJYCX.DATACENTER_TOF_JJJZ          t	
 LEFT JOIN   EDW_PROD.T_EDW_T04_TOF_JJJZ_TEMP    a2
 ON          t.jjDM = a2.zqdm1
 LEFT JOIN      (   SELECT     NVL(a.JYS,b.JYS) as JYS
                              ,NVL(a.ZQDM,b.ZQDM) as ZQDM
							  ,LEAST(NVL(a.SSRQ,99999999),NVL(b.SSRQ,99999999)) as SSRQ
							  ,GREATEST(NVL(a.TSRQ,00000000),NVL(b.TSRQ,00000000)) as TSRQ
                    FROM      (SELECT JYS,ZQDM,SSRQ,TSRQ 
					           FROM EDW_PROD.T_EDW_T04_TSZQDM
							   WHERE BUS_DATE = %d{yyyyMMdd}
							   AND   CPLB = 8
							   AND   ZQDM NOT LIKE '%J'
							   ) a
			        FULL JOIN  (SELECT JYS,SUBSTR(ZQDM,1,6) as ZQDM,MIN(SSRQ) as SSRQ,MAX(TSRQ) as TSRQ,BUS_DATE FROM EDW_PROD.T_EDW_T04_TSZQDM
			                     WHERE CPLB = 8
				                 AND   ZQDM LIKE '%J'
								 AND BUS_DATE = %d{yyyyMMdd}
								 GROUP BY JYS,ZQDM,BUS_DATE
				                ) b
				    ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
				    AND          a.JYS = b.JYS
				   
				   
                )           a1
 ON       t.jjDM = a1.ZQDM
 WHERE		 t.DT = '%d{yyyyMMdd}'
 AND         t.JJDM NOT IN ('180042','519028','519521','519522','519523','000636','000653')
 and         a2.ZQDM1 IS NULL
 ;
-------插入数据结束
-----180042转换成180002 519028转换成519029 519521，519522，519523转换成519511J 000636申购代码 证券代码 000634
------000653申购代码 基金代码 000652
-----删除临时表--
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TOF_JJJZ_TEMP;
 
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TOF_JJJZ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 -- /* ***************************************** SQL Begin ***************************************** */
 -- /* 脚本功能:个人客户信息表                                                               */
 -- /* 创建人:黄勇华                                                                              */
 -- /* 创建时间:2016-11-02                                                                        */ 
 --TRUNCATE TABLE EDW_PROD.T_EDW_T01_TGRKHXX ;
---------------- 插入数据开始 
INSERT OVERWRITE EDW_PROD.T_EDW_T01_TGRKHXX(
                                    KHH                                 --客户号                                
                                   ,CSRQ                                --出生日期                               
                                   ,XBDM                                --性别代码                               
                                   ,XLDM                                --学历代码                               
                                   ,ZYDM                                --职业代码                               
                                   ,MZDM                                --民族代码                               
                                   ,JG                                  --籍贯                                 
                                   ,HYZKDM                              --婚姻状况代码                             
                                   ,GZDW                                --工作单位                               
                                   ,JTDZ                                --家庭地址                               
                                   ,JTYB                                --家庭邮编                               
                                   ,JTDH                                --家庭电话                               
                                   ,GZDWDZ                              --单位地址                               
                                   ,GZDWYB                              --单位邮编                               
                                   ,GZDWDH                              --单位电话  
                                   ,XTBS  								   
) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,CAST(a1.CSRQ AS DECIMAL(8,0))         as CSRQ                                --出生日期                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.XB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as XBDM                                --性别                                  
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.XLDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as XLDM                                --学历                                  
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZYDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZYDM                                --职业                                  
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.MZDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as MZDM                                --民族                                  
                                   ,t.JG                                  as JG                                  --籍贯                                  
                                   ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.HYZK AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as HYZKDM                              --婚姻状况                                
                                   ,t.GZDW                                as GZDW                                --工作单位                                
                                   ,t.JTDZ                                as JTDZ                                --家庭地址                                
                                   ,t.JTYB                                as JTYB                                --家庭邮编                                
                                   ,t.JTDH                                as JTDH                                --家庭电话                                
                                   ,t.GZDWDZ                              as GZDWDZ                              --单位地址                                
                                   ,t.GZDWYB                              as GZDWYB                              --单位邮编                                
                                   ,t.GZDWDH                              as GZDWDH                              --单位电话    
                                   ,'YGT_GT'							  as XTBS	   
 FROM 			YGTCX.CIF_TGRKHXX t
 LEFT JOIN       (SELECT a1.KHH,a1.DT
                          ,CASE WHEN a1.CSRQ LIKE '196O1128%' 
						        THEN '19601128'
								WHEN a1.CSRQ LIKE '1940092+%'
								THEN '99999999'
						  WHEN a1.CSRQ IS NULL 
                          OR TRIM(a1.CSRQ) = '0' 
                          OR SUBSTR(TRIM(a1.CSRQ),1,4) NOT BETWEEN '1900' AND SUBSTR('%d{yyyyMMdd}',1,4)
						  OR SUBSTR(TRIM(a1.CSRQ),5,2) NOT BETWEEN '01' AND '12'
						  OR SUBSTR(TRIM(a1.CSRQ),7,2) NOT BETWEEN '01' AND '31'
						  OR LENGTH(REGEXP_REPLACE(TRIM(NVL(a1.csrq,'')),' ',''))<>8
						  THEN '99999999'
						  ELSE a1.CSRQ
						  END      as CSRQ
                 FROM (SELECT a.KHH
                             ,CASE WHEN (a.CSRQ>CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-16,0,0),1,4),'0101') AS DECIMAL(8,0)) OR a.CSRQ<19000101 OR a.CSRQ IS NULL) AND b.ZJLB=0 and LENGTH(REGEXP_REPLACE(nvl(zjbh,''),' ',''))=18 THEN SUBSTR(ZJBH,7,8)
                                   WHEN (a.CSRQ>CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-16,0,0),1,4),'0101') AS DECIMAL(8,0)) OR a.CSRQ<19000101 OR a.CSRQ IS NULL) AND b.ZJLB=0 and LENGTH(REGEXP_REPLACE(NVL(zjbh,''),' ',''))=15 THEN CONCAT('19',SUBSTR(ZJBH,7,6))
                                   ELSE  CAST(a.CSRQ AS STRING)
                                   END   as CSRQ
                             ,a.DT			 
                       FROM            YGTCX.CIF_TGRKHXX   a
                       LEFT JOIN       YGTCX.CIF_TKHXX      b
                       ON              a.KHH = b.KHH
                       AND             a.DT = b.DT
                       AND             b.DT = '%d{yyyyMMdd}'
                       WHERE           a.DT = '%d{yyyyMMdd}' 
                       ) a1
	          )        a1 
 ON             t.KHH = a1.KHH
 AND            t.DT = a1.DT
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING            t1 
 ON             t1.DMLX = 'XBDM'                                  
 AND            t1.YXT = 'YGT_GT'                                 
 AND            t1.YDM = CAST(t.XB AS VARCHAR(20))               
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING            t2
 ON             t2.DMLX = 'XLDM'                                  
 AND            t2.YXT = 'YGT_GT'                                
 AND            t2.YDM = CAST(t.XLDM AS VARCHAR(20))              
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING            t3 
 ON             t3.DMLX = 'ZYDM'                                  
 AND            t3.YXT = 'YGT_GT'                                 
 AND            t3.YDM = CAST(t.ZYDM AS VARCHAR(20))              
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING            t4
 ON             t4.DMLX = 'MZDM'                                  
 AND            t4.YXT = 'YGT_GT'                                 
 AND            t4.YDM = CAST(t.MZDM AS VARCHAR(20))              
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING            t5
 ON             t5.DMLX = 'HYZKDM'                                
 AND            t5.YXT = 'YGT_GT'                                
 AND            t5.YDM = CAST(t.HYZK AS VARCHAR(20))              
 WHERE          t.DT = '%d{yyyyMMdd}';
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TGRKHXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T01_TGRKHXX;


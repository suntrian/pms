--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:数据质量检测规则                                                                    */
--/* 创建人:黄勇华                                                                               */
--/* 创建时间:2017-12-05                                                                        */

ALTER TABLE DDW_PROD.T_DATA_QUA_CHK_DETAIL DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ; 
---插入DW公共代码一致性检测
 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT            '00'                                        as MCGY                         --大类      
                   ,'00'                                       as FINE                         --细类      
                   ,'DW'                                       as SYS                          --系统    
                   ,'T_EDW_T99_PUBLIC_CODE_MAPPING'            as TABLE_NAME                   --表明		
                   ,NULL                                       as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                          as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
	         FROM EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING
	        )   t
 LEFT JOIN (SELECT  1        as ID
                   ,YDM      as YDM
				   ,YXT      as YXT
				   ,DMLX     as DMLX
                   ,COUNT(1) as ERR_NUM
	        FROM EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING
			GROUP BY YDM,YXT,DMLX,ID
			HAVING COUNT(1) > 1
           ) a1
 ON        t.ID = a1.ID
 ;
 
 ---插入JZJY代码一致性检测
 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                        as MCGY                         --大类      
                   ,'00'                                       as FINE                         --细类      
                   ,'JZJY'                                     as SYS                          --系统    
                   ,'ABOSS_TXTDM'                              as TABLE_NAME                   --表明		
                   ,NULL                                       as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
	         FROM  JZJYCX.ABOSS_TXTDM
			 WHERE DT = '%d{yyyyMMdd}'
	        )   t
 LEFT JOIN (SELECT  1         as ID
                   ,FLDM      as FLDM
				   ,BM        as BM
                   ,COUNT(1) as ERR_NUM
	        FROM JZJYCX.ABOSS_TXTDM
			WHERE DT = '%d{yyyyMMdd}'
			GROUP BY FLDM,BM,ID
			HAVING COUNT(1) > 1
           ) a1
 ON        t.ID = a1.ID
 ;
 ---插入GGQQ代码一致性检测
 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'00'                                       as FINE                         --细类      
                   ,'GGQQ'                                     as SYS                          --系统    
                   ,'ABOSS_TXTDM'                              as TABLE_NAME                   --表明		
                   ,NULL                                       as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                          as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
	         FROM  GGQQCX.ABOSS_TXTDM
			 WHERE DT = '%d{yyyyMMdd}'
	        )   t
 LEFT JOIN (SELECT  1         as ID
                   ,FLDM      as FLDM
				   ,BM        as BM
                   ,COUNT(1) as ERR_NUM
	        FROM GGQQCX.ABOSS_TXTDM
			WHERE DT = '%d{yyyyMMdd}'
			GROUP BY FLDM,BM,ID
			HAVING COUNT(1) > 1
           ) a1
 ON        t.ID = a1.ID
 ;
 
 ---插入RZRQ代码一致性检测
 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                        as MCGY                         --大类      
                   ,'00'                                       as FINE                         --细类      
                   ,'RZRQ'                                     as SYS                          --系统    
                   ,'ABOSS_TXTDM'                              as TABLE_NAME                   --表明		
                   ,NULL                                       as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
	         FROM  RZRQCX.ABOSS_TXTDM
			 WHERE DT = '%d{yyyyMMdd}'
	        )   t
 LEFT JOIN (SELECT  1         as ID
                   ,FLDM      as FLDM
				   ,BM        as BM
                   ,COUNT(1) as ERR_NUM
	        FROM RZRQCX.ABOSS_TXTDM
			WHERE DT = '%d{yyyyMMdd}'
			GROUP BY FLDM,BM,ID
			HAVING COUNT(1) > 1
           ) a1
 ON        t.ID = a1.ID
 ;
 ---插入CIF代码一致性检测
 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'00'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TXTDM'                                as TABLE_NAME                   --表明		
                   ,NULL                                       as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
	         FROM  YGTCX.CIF_TXTDM
			 WHERE DT = '%d{yyyyMMdd}'
	        )   t
 LEFT JOIN (SELECT  1         as ID
                   ,FLDM      as FLDM
				   ,IBM       as CBM
                   ,COUNT(1) as ERR_NUM
	        FROM YGTCX.CIF_TXTDM
			WHERE DT = '%d{yyyyMMdd}'
			GROUP BY FLDM,CBM,ID
			HAVING COUNT(1) > 1
           ) a1
 ON        t.ID = a1.ID
 ;
 
 
 ----------------------------检查CIF.TKHXX
 
 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'KHJC'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(KHJC)) = 0
           ) a1
 ON        t.ID = a1.ID
 ;
 
 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'KHJC'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(KHJC)) > 0
		 AND    regexp_like(khjc,'[[:punct:]]') 
           ) a1
 ON        t.ID = a1.ID
 ;
 
 
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'KHMC'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(KHMC)) = 0
           ) a1
 ON        t.ID = a1.ID
 ;
 
 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'KHMC'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(KHMC)) > 0
		 AND    regexp_like(khjc,'[[:punct:]]') 
           ) a1
 ON        t.ID = a1.ID
 ;
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'ZJLB'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   ZJLB IS NULL
           ) a1
 ON        t.ID = a1.ID
 ;  

 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'ZJLB'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   ZJLB IS NOT NULL
		 AND   ((khlb = 1 and zjlb not in (8,90)) OR (khlb = 0 and zjlb not in (0,6,20,16,15,19,1)))
           ) a1
 ON        t.ID = a1.ID
 ;
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'ZJBH'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(ZJBH)) = 0
           ) a1
 ON        t.ID = a1.ID
 ;  
 
 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'ZJBH'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(ZJBH)) > 0
		 AND   ((KHLB = 0 and LENGTH(TRIM(ZJBH)) NOT IN (15,18) AND ZJLB = 0) 
		 OR    (KHLB =0 AND  LENGTH(TRIM(ZJBH)) = 18 
		                AND (NOT REGEXP_LIKE(SUBSTR(ZJBH,1,6),'[0-9]') 
                        OR NOT REGEXP_LIKE(SUBSTR(ZJBH,7,2),'(18|19|20|21|22|23)')
	                    OR NOT REGEXP_LIKE(SUBSTR(ZJBH,9,2),'[0-9]')
	                    OR NOT REGEXP_LIKE(SUBSTR(ZJBH,11,2),'(0[1-9]|10|11|12)')
	                    OR NOT REGEXP_LIKE(SUBSTR(ZJBH,13,2),'(([0-2][1-9])|10|20|31|30)')
	                    OR NOT REGEXP_LIKE(SUBSTR(ZJBH,15,4),'[0-9Xx]')
	                          ) 
			    )
		OR    (KHLB =0 AND  LENGTH(TRIM(ZJBH)) = 15 
		                AND (NOT REGEXP_LIKE(SUBSTR(ZJBH,1,8),'[0-9]') 
                        OR NOT REGEXP_LIKE(SUBSTR(ZJBH,9,2),'(0[1-9]|10|11|12)')
	                    OR NOT REGEXP_LIKE(SUBSTR(ZJBH,11,2),'(([0-2][1-9])|10|20|31|30)')
	                    OR NOT REGEXP_LIKE(SUBSTR(ZJBH,13,3),'[0-9Xx]')	                   
	                          ) 
			    ) )
           ) a1
 ON        t.ID = a1.ID
 ;
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'ZJJZRQ'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   ZJJZRQ IS NULL
           ) a1
 ON        t.ID = a1.ID
 ;  
 
    INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'ZJJZRQ'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   ZJJZRQ IS NOT NULL 
		 AND   (LENGTH(CAST(ZJJZRQ as STRING)) < > 8 
		 OR     NOT REGEXP_LIKE(SUBSTR(CAST(ZJJZRQ as STRING),5,2),'(0[1-9]|10|11|12)')		 
		 OR    NOT REGEXP_LIKE(SUBSTR(CAST(ZJJZRQ as STRING),7,2),'(([0-2][1-9])|10|20|31|30)') 
		       )
			   ) a1
 ON        t.ID = a1.ID
 ;  
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'ZJDZ'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(ZJDZ)) = 0
           ) a1
 ON        t.ID = a1.ID
 ; 
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'ZJDZ'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(ZJDZ)) > 0
		 AND   LENGTH(TRIM(ZJDZ)) < 5
           ) a1
 ON        t.ID = a1.ID ;
 
    INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'ZJZP'                                as TABLE_NAME                   --表明		
                   ,'CIF_TKHXX'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(ZJZP)) = 0
           ) a1
 ON        t.ID = a1.ID
 ; 
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'DZ'                                       as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(DZ)) = 0
           ) a1
 ON        t.ID = a1.ID
 ;  
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'DZ'                                       as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(DZ)) > 0
		 AND   LENGTH(TRIM(DZ)) < 5
           ) a1
 ON        t.ID = a1.ID ;
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'DH,SJ'                                    as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(DH)) = 0
		 AND   LENGTH(TRIM(SJ)) = 0
           ) a1
 ON        t.ID = a1.ID
 ; 
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX'                                as TABLE_NAME                   --表明		
                   ,'GJ'                                       as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHXX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   (GJ IS NULL
		 OR   GJ = 0)
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 
    INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TGRKHXX'                              as TABLE_NAME                   --表明		
                   ,'CSRQ'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TGRKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TGRKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  CSRQ IS NULL
           ) a1
 ON        t.ID = a1.ID
 ; 
 
  
    INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TGRKHXX'                              as TABLE_NAME                   --表明		
                   ,'CSRQ'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TGRKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TGRKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   CSRQ IS NOT NULL 
		 AND   (LENGTH(CAST(CSRQ as STRING)) < > 8 
		 OR    NOT REGEXP_LIKE(SUBSTR(CAST(CSRQ as STRING),1,2),'(18|19|20|21|22|23)') 
         OR    NOT REGEXP_LIKE(SUBSTR(CAST(CSRQ as STRING),3,2),'[0-9]')  		 
		 OR     NOT REGEXP_LIKE(SUBSTR(CAST(CSRQ as STRING),5,2),'(0[1-9]|10|11|12)')		 
		 OR    NOT REGEXP_LIKE(SUBSTR(CAST(CSRQ as STRING),7,2),'(([0-2][1-9])|10|20|31|30)') 
		 
		  )
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 
 
  
    INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TGRKHXX'                              as TABLE_NAME                   --表明		
                   ,'XB'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TGRKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TGRKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  XB IS NULL
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 
     INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TGRKHXX'                              as TABLE_NAME                   --表明		
                   ,'XLDM'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TGRKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TGRKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  XLDM IS NULL
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 
      INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TGRKHXX'                              as TABLE_NAME                   --表明		
                   ,'ZYDM'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TGRKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TGRKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  ZYDM IS NULL
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 
 
      INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'JGJYFW'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  LENGTH(TRIM(JGJYFW)) =0 
           ) a1
 ON        t.ID = a1.ID
 ;  
 
 
 
      INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'ZZJGDM'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  LENGTH(TRIM(ZZJGDM)) =0  
           ) a1
 ON        t.ID = a1.ID
 ;  
 
       INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'ZZJGDMJZRQ'                               as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  ZZJGDMJZRQ IS NULL
           ) a1
 ON        t.ID = a1.ID
 ; 
 
        INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'ZZJGDMJZRQ'                               as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
			AND   ZZJGDMJZRQ IS NOT NULL 
		 AND   (LENGTH(CAST(ZZJGDMJZRQ as STRING)) < > 8 		
         OR    NOT REGEXP_LIKE(SUBSTR(CAST(ZZJGDMJZRQ as STRING),1,4),'[0-9]')  		 
		 OR     NOT REGEXP_LIKE(SUBSTR(CAST(ZZJGDMJZRQ as STRING),5,2),'(0[1-9]|10|11|12)')		 
		 OR    NOT REGEXP_LIKE(SUBSTR(CAST(ZZJGDMJZRQ as STRING),7,2),'(([0-2][1-9])|10|20|31|30)')		   					   
		       )
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 
        INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'GSSWDJZ,DSSWDJZ'                          as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  LENGTH(TRIM(GSSWDJZ)) =0  AND  LENGTH(TRIM(DSSWDJZ)) = 0
           ) a1
 ON        t.ID = a1.ID
 ; 

        INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'GSSWDJZJZRQ'                              as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
					   
		  AND   GSSWDJZJZRQ IS NOT NULL 
		 AND   (LENGTH(CAST(GSSWDJZJZRQ as STRING)) < > 8 		
         OR    NOT REGEXP_LIKE(SUBSTR(CAST(GSSWDJZJZRQ as STRING),1,4),'[0-9]')  		 
		 OR     NOT REGEXP_LIKE(SUBSTR(CAST(GSSWDJZJZRQ as STRING),5,2),'(0[1-9]|10|11|12)')		 
		 OR    NOT REGEXP_LIKE(SUBSTR(CAST(GSSWDJZJZRQ as STRING),7,2),'(([0-2][1-9])|10|20|31|30)')		 		  		
           )
           )		   a1
 ON        t.ID = a1.ID
 ; 




        INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'DSSWDJZJZRQ'                              as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
			AND   DSSWDJZJZRQ IS NOT NULL 
		 AND   (LENGTH(CAST(DSSWDJZJZRQ as STRING)) < > 8 		
         OR    NOT REGEXP_LIKE(SUBSTR(CAST(DSSWDJZJZRQ as STRING),1,4),'[0-9]')  		 
		 OR     NOT REGEXP_LIKE(SUBSTR(CAST(DSSWDJZJZRQ as STRING),5,2),'(0[1-9]|10|11|12)')		 
		 OR    NOT REGEXP_LIKE(SUBSTR(CAST(DSSWDJZJZRQ as STRING),7,2),'(([0-2][1-9])|10|20|31|30)')	
           )
		   ) a1
 ON        t.ID = a1.ID
 ; 


       INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'GSSWDJZJZRQ,DSSWDJZJZRQ'                          as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  GSSWDJZJZRQ IS NULL AND DSSWDJZJZRQ IS NULL
           ) a1
 ON        t.ID = a1.ID
 ; 


       INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'FRDBXM'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND LENGTH(TRIM(FRDBXM)) = 0
           ) a1
 ON        t.ID = a1.ID
 ; 


       INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'FRDBXM'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
		 AND    LENGTH(TRIM(FRDBXM)) > 0
 		 AND    regexp_like(FRDBXM,'[[:punct:]]')
           ) a1
 ON        t.ID = a1.ID
 ; 

       INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'FRDBZJLB'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  FRDBZJLB IS NULL 
           ) a1
 ON        t.ID = a1.ID
 ; 

        INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'FRDBZJBH'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND   LENGTH(TRIM(FRDBZJBH)) = 0
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'FRDBZJBH'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 AND   LENGTH(TRIM(FRDBZJBH)) > 0
 AND (( LENGTH(TRIM(FRDBZJBH)) NOT IN (15,18) AND FRDBZJLB = 0) 
		 OR    ( LENGTH(TRIM(FRDBZJBH)) = 18 
		                AND (NOT REGEXP_LIKE(SUBSTR(FRDBZJBH,1,6),'[0-9]') 
                        OR NOT REGEXP_LIKE(SUBSTR(FRDBZJBH,7,2),'(18|19|20|21|22|23)')
	                    OR NOT REGEXP_LIKE(SUBSTR(FRDBZJBH,9,2),'[0-9]')
	                    OR NOT REGEXP_LIKE(SUBSTR(FRDBZJBH,11,2),'(0[1-9]|10|11|12)')
	                    OR NOT REGEXP_LIKE(SUBSTR(FRDBZJBH,13,2),'(([0-2][1-9])|10|20|31|30)')
	                    OR NOT REGEXP_LIKE(SUBSTR(FRDBZJBH,15,4),'[0-9Xx]')
	                          ) 
			    )
		OR    (  LENGTH(TRIM(FRDBZJBH)) = 15 
		                AND (NOT REGEXP_LIKE(SUBSTR(FRDBZJBH,1,8),'[0-9]') 
                        OR NOT REGEXP_LIKE(SUBSTR(FRDBZJBH,9,2),'(0[1-9]|10|11|12)')
	                    OR NOT REGEXP_LIKE(SUBSTR(FRDBZJBH,11,2),'(([0-2][1-9])|10|20|31|30)')
	                    OR NOT REGEXP_LIKE(SUBSTR(FRDBZJBH,13,3),'[0-9Xx]')	                   
	                          ) 
			    ) ) ) a1
 ON        t.ID = a1.ID
 ; 
 
 
 
         INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'FRDBZJJZRQ'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  FRDBZJJZRQ IS NULL 
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 
        INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'FRDBZJJZRQ'                              as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 
		  AND   FRDBZJJZRQ IS NOT NULL 
		 AND   (LENGTH(CAST(FRDBZJJZRQ as STRING)) < > 8 
		-- OR    NOT REGEXP_LIKE(SUBSTR(CAST(CSRQ as STRING),1,2),'(18|19|20|21|22|23)') 
         OR    NOT REGEXP_LIKE(SUBSTR(CAST(FRDBZJJZRQ as STRING),1,4),'[0-9]')  		 
		 OR     NOT REGEXP_LIKE(SUBSTR(CAST(FRDBZJJZRQ as STRING),5,2),'(0[1-9]|10|11|12)')		 
		 OR    NOT REGEXP_LIKE(SUBSTR(CAST(FRDBZJJZRQ as STRING),7,2),'(([0-2][1-9])|10|20|31|30)')
		 )

           ) a1
 ON        t.ID = a1.ID
 ; 
 
 
        INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'JBRZJJZRQ'                              as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
		 AND   JBRZJJZRQ IS NOT NULL 
		 AND   (LENGTH(CAST(JBRZJJZRQ as STRING)) < > 8 
		-- OR    NOT REGEXP_LIKE(SUBSTR(CAST(CSRQ as STRING),1,2),'(18|19|20|21|22|23)') 
         OR    NOT REGEXP_LIKE(SUBSTR(CAST(JBRZJJZRQ as STRING),1,4),'[0-9]')  		 
		 OR     NOT REGEXP_LIKE(SUBSTR(CAST(JBRZJJZRQ as STRING),5,2),'(0[1-9]|10|11|12)')		 
		 OR    NOT REGEXP_LIKE(SUBSTR(CAST(JBRZJJZRQ as STRING),7,2),'(([0-2][1-9])|10|20|31|30)')
		 ) 
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'JBRZJBH'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 AND  (( LENGTH(TRIM(JBRZJBH)) NOT IN (15,18) AND JBRZJLB = 0) 
		 OR    ( LENGTH(TRIM(JBRZJBH)) = 18 
		                AND (NOT REGEXP_LIKE(SUBSTR(JBRZJBH,1,6),'[0-9]') 
                        OR NOT REGEXP_LIKE(SUBSTR(JBRZJBH,7,2),'(18|19|20|21|22|23)')
	                    OR NOT REGEXP_LIKE(SUBSTR(JBRZJBH,9,2),'[0-9]')
	                    OR NOT REGEXP_LIKE(SUBSTR(JBRZJBH,11,2),'(0[1-9]|10|11|12)')
	                    OR NOT REGEXP_LIKE(SUBSTR(JBRZJBH,13,2),'(([0-2][1-9])|10|20|31|30)')
	                    OR NOT REGEXP_LIKE(SUBSTR(JBRZJBH,15,4),'[0-9Xx]')
	                          ) 
			    )
		OR    (  LENGTH(TRIM(JBRZJBH)) = 15 
		                AND (NOT REGEXP_LIKE(SUBSTR(JBRZJBH,1,8),'[0-9]') 
                        OR NOT REGEXP_LIKE(SUBSTR(JBRZJBH,9,2),'(0[1-9]|10|11|12)')
	                    OR NOT REGEXP_LIKE(SUBSTR(JBRZJBH,11,2),'(([0-2][1-9])|10|20|31|30)')
	                    OR NOT REGEXP_LIKE(SUBSTR(JBRZJBH,13,3),'[0-9Xx]')	                   
	                          ) 
			    ) )
           ) a1
 ON        t.ID = a1.ID
 ; 
 
    INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'03'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'JBRXM'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 AND   LENGTH(TRIM(JBRXM)) > 0
AND    regexp_like(JBRXM,'[[:punct:]]')
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 
          INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'JBRXM'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  LENGTH(TRIM(JBRXM)) = 0
           ) a1
 ON        t.ID = a1.ID
 ; 
 
           INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'JBRZJLB'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  JBRZJLB IS NULL 
           ) a1
 ON        t.ID = a1.ID
 ; 
 
            INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'JBRZJBH'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  LENGTH(TRIM(JBRZJBH)) = 0
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 

  
            INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'JBRZJJZRQ'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  JBRZJJZRQ IS NULL 
           ) a1
 ON        t.ID = a1.ID
 ; 
 
   
            INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TJGKHXX'                              as TABLE_NAME                   --表明		
                   ,'CPBZ'                                   as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM YGTCX.CIF_TJGKHXX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TJGKHXX A
 		   WHERE  A.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX B 
                        WHERE    B.DT = '%d{yyyyMMdd}'
				        AND     A.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  CPBZ IS NULL 
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHYWSX'                              as TABLE_NAME                   --表明		
                   ,'XQFXDJ'                                       as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHYWSX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHYWSX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND  XQFXDJ IS NULL
		-- AND   TRIM(GJ) = '0'
           ) a1
 ON        t.ID = a1.ID
 ; 
 

   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHYWSX'                              as TABLE_NAME                   --表明		
                   ,'TZPZ'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHYWSX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHYWSX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		-- AND  TZPZ IS NULL
		 AND  LENGTH(TRIM(TZPZ)) = 0
		-- AND   TRIM(GJ) = '0'
           ) a1
 ON        t.ID = a1.ID
 ; 

  
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHYWSX'                              as TABLE_NAME                   --表明		
                   ,'TZQX'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHYWSX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHYWSX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		   AND  TZQX IS NULL
		 --AND  LENGTH(TRIM(TZQX)) = 0
		-- AND   TRIM(GJ) = '0'
           ) a1
 ON        t.ID = a1.ID
 ;  
 
    INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHYWSX'                              as TABLE_NAME                   --表明		
                   ,'YQSY'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHYWSX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHYWSX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		  -- AND  YQSY IS NULL
		   AND  LENGTH(TRIM(YQSY)) = 0
		-- AND   TRIM(GJ) = '0'
           ) a1
 ON        t.ID = a1.ID
 ; 
 
    INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHYWSX'                              as TABLE_NAME                   --表明		
                   ,'SJSYR'                                    as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHYWSX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHYWSX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		  -- AND  YQSY IS NULL
		   AND  LENGTH(TRIM(SJSYR)) = 0
		-- AND   TRIM(GJ) = '0'
           ) a1
 ON        t.ID = a1.ID
 ; 
 
     INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'01'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHYWSX'                              as TABLE_NAME                   --表明		
                   ,'SJKZR'                                    as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
          FROM  YGTCX.CIF_TKHYWSX a
 		 WHERE DT = '%d{yyyyMMdd}'
		 AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                      WHERE    b.DT = '%d{yyyyMMdd}'
				      AND     a.KHH = b.KHH
					  AND     b.SXZ IN ('0','1','2','8','19')
				  )
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM   YGTCX.CIF_TKHYWSX a
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		  -- AND  YQSY IS NULL
		   AND  LENGTH(TRIM(SJKZR)) = 0
		-- AND   TRIM(GJ) = '0'
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 ---------------
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'00'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHSX'                                as TABLE_NAME                   --表明		
                   ,'CPDJ'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHSDX a
 		     WHERE DT = '%d{yyyyMMdd}'
			 AND   sdxlb = 'JJFXCSNL'
         )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM         YGTCX.CIF_TKHSDX a
		   LEFT JOIN    YGTCX.CIF_TKHXX  b
		   ON           a.KHH = b.KHH
		   AND          a.DT = b.DT
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND    a.sdxlb = 'JJFXCSNL'
		   AND    b.KHZT = 0
		   AND    (CPDJ IS NULL OR CPDJ < 11 OR CPDJ > 16)
 		  -- AND  YQSY IS NULL
		   
		-- AND   TRIM(GJ) = '0'
           ) a1
 ON        t.ID = a1.ID
 ; 
 
 



 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX,JZJYCX.DATACENTER_TKHXX'        as TABLE_NAME                   --表明		
                   ,'KHJC,KHXM'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHXX a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TKHXX a
		   LEFT JOIN JZJYCX.DATACENTER_TKHXX c
		   ON        a.KHH = c.KHH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    TRIM(DECODE(LENGTH(TRIM(a.KHJC)),0,'-1',a.KHJC)) < > TRIM(DECODE(LENGTH(TRIM(c.KHXM)),0,'-1',c.KHXM))
           ) a1
 ON        t.ID = a1.ID
 ;
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX,JZJYCX.DATACENTER_TKHXX'        as TABLE_NAME                   --表明		
                   ,'KHMC,KHQC'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHXX a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TKHXX a
		   LEFT JOIN JZJYCX.DATACENTER_TKHXX c
		   ON        a.KHH = c.KHH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    TRIM(DECODE(LENGTH(TRIM(a.KHMC)),0,'-1',a.KHMC)) < > TRIM(DECODE(LENGTH(TRIM(c.KHQC)),0,'-1',c.KHQC))
           ) a1
 ON        t.ID = a1.ID
 ;
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX,JZJYCX.DATACENTER_TKHXX'        as TABLE_NAME                   --表明		
                   ,'ZJLB,ZJLB'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHXX a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TKHXX a
		   LEFT JOIN JZJYCX.DATACENTER_TKHXX c
		   ON        a.KHH = c.KHH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    NVL(a.ZJLB,-1) < > NVL(c.ZJLB,-1)
           ) a1
 ON        t.ID = a1.ID
 ;
 
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX,JZJYCX.DATACENTER_TKHXX'        as TABLE_NAME                   --表明		
                   ,'ZJBH,ZJBH'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHXX a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TKHXX a
		   LEFT JOIN JZJYCX.DATACENTER_TKHXX c
		   ON        a.KHH = c.KHH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    TRIM(DECODE(LENGTH(TRIM(a.ZJBH)),0,'-1',a.ZJBH)) < > TRIM(DECODE(LENGTH(TRIM(c.ZJBH)),0,'-1',c.ZJBH))
           ) a1
 ON        t.ID = a1.ID
 ;
 
 
 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX,GGQQCX.DATACENTER_TKHXX'        as TABLE_NAME                   --表明		
                   ,'KHJC,KHXM'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHXX a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TKHXX a
		   LEFT JOIN GGQQCX.DATACENTER_TKHXX c
		   ON        a.KHH = c.KHH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    TRIM(DECODE(LENGTH(TRIM(a.KHJC)),0,'-1',a.KHJC)) < > TRIM(DECODE(LENGTH(TRIM(c.KHXM)),0,'-1',c.KHXM))
           ) a1
 ON        t.ID = a1.ID
 ;
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX,GGQQCX.DATACENTER_TKHXX'        as TABLE_NAME                   --表明		
                   ,'KHMC,KHQC'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHXX a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TKHXX a
		   LEFT JOIN GGQQCX.DATACENTER_TKHXX c
		   ON        a.KHH = c.KHH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    TRIM(DECODE(LENGTH(TRIM(a.KHMC)),0,'-1',a.KHMC)) < > TRIM(DECODE(LENGTH(TRIM(c.KHQC)),0,'-1',c.KHQC))
           ) a1
 ON        t.ID = a1.ID
 ;
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX,GGQQCX.DATACENTER_TKHXX'        as TABLE_NAME                   --表明		
                   ,'ZJLB,ZJLB'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHXX a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TKHXX a
		   LEFT JOIN GGQQCX.DATACENTER_TKHXX c
		   ON        a.KHH = c.KHH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    NVL(a.ZJLB,-1) < > NVL(c.ZJLB,-1)
           ) a1
 ON        t.ID = a1.ID
 ;
 
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX,GGQQCX.DATACENTER_TKHXX'        as TABLE_NAME                   --表明		
                   ,'ZJBH,ZJBH'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHXX a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TKHXX a
		   LEFT JOIN GGQQCX.DATACENTER_TKHXX c
		   ON        a.KHH = c.KHH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    TRIM(DECODE(LENGTH(TRIM(a.ZJBH)),0,'-1',a.ZJBH)) < > TRIM(DECODE(LENGTH(TRIM(c.ZJBH)),0,'-1',c.ZJBH))
           ) a1
 ON        t.ID = a1.ID
 ;
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX,RZRQCX.DATACENTER_TKHXX'        as TABLE_NAME                   --表明		
                   ,'KHJC,KHXM'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHXX a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TKHXX a
		   LEFT JOIN RZRQCX.DATACENTER_TKHXX c
		   ON        a.KHH = c.KHH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    TRIM(DECODE(LENGTH(TRIM(a.KHJC)),0,'-1',a.KHJC)) < > TRIM(DECODE(LENGTH(TRIM(c.KHXM)),0,'-1',c.KHXM))
           ) a1
 ON        t.ID = a1.ID
 ;
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX,RZRQCX.DATACENTER_TKHXX'        as TABLE_NAME                   --表明		
                   ,'KHMC,KHQC'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHXX a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TKHXX a
		   LEFT JOIN RZRQCX.DATACENTER_TKHXX c
		   ON        a.KHH = c.KHH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    TRIM(DECODE(LENGTH(TRIM(a.KHMC)),0,'-1',a.KHMC)) < > TRIM(DECODE(LENGTH(TRIM(c.KHQC)),0,'-1',c.KHQC))
           ) a1
 ON        t.ID = a1.ID
 ;
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX,RZRQCX.DATACENTER_TKHXX'        as TABLE_NAME                   --表明		
                   ,'ZJLB,ZJLB'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHXX a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TKHXX a
		   LEFT JOIN RZRQCX.DATACENTER_TKHXX c
		   ON        a.KHH = c.KHH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    NVL(a.ZJLB,-1) < > NVL(c.ZJLB,-1)
           ) a1
 ON        t.ID = a1.ID
 ;
 
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TKHXX,RZRQCX.DATACENTER_TKHXX'        as TABLE_NAME                   --表明		
                   ,'ZJBH,ZJBH'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TKHXX a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TKHXX a
		   LEFT JOIN RZRQCX.DATACENTER_TKHXX c
		   ON        a.KHH = c.KHH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    TRIM(DECODE(LENGTH(TRIM(a.ZJBH)),0,'-1',a.ZJBH)) < > TRIM(DECODE(LENGTH(TRIM(c.ZJBH)),0,'-1',c.ZJBH))
           ) a1
 ON        t.ID = a1.ID
 ;
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TGDZH,JZJYCX.DATACENTER_TGDH'        as TABLE_NAME                   --表明		
                   ,'GDMC,GDXM'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TGDZH a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TGDZH a
		   LEFT JOIN JZJYCX.DATACENTER_TGDH c
		   ON        a.KHH = c.KHH
		   AND       a.GDH = c.GDH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    TRIM(DECODE(LENGTH(TRIM(a.GDMC)),0,'-1',a.GDMC)) < > TRIM(DECODE(LENGTH(TRIM(c.GDXM)),0,'-1',c.GDXM))
           ) a1
 ON        t.ID = a1.ID
 ;
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '00'                                       as MCGY                         --大类      
                   ,'06'                                       as FINE                         --细类      
                   ,'CIF'                                      as SYS                          --系统    
                   ,'CIF_TGDZH,RZRQCX.DATACENTER_TGDH'        as TABLE_NAME                   --表明		
                   ,'GDMC,GDXM'                                     as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  YGTCX.CIF_TGDZH a
 		    WHERE DT = '%d{yyyyMMdd}'
		     AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                          WHERE    b.DT = '%d{yyyyMMdd}'
				          AND     a.KHH = b.KHH
					      AND     b.SXZ IN ('0','1','2','8','19')
				         )
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM      YGTCX.CIF_TGDZH a
		   LEFT JOIN RZRQCX.DATACENTER_TGDH c
		   ON        a.KHH = c.KHH
		   AND       a.GDH = c.GDH
		   AND       c.DT = '%d{yyyyMMdd}'
 		   WHERE  a.DT = '%d{yyyyMMdd}'
		   AND   EXISTS(SELECT 1 FROM    YGTCX.CIF_TKHSX b 
                        WHERE    b.DT = '%d{yyyyMMdd}'
				        AND     a.KHH = b.KHH
					    AND     b.SXZ IN ('0','1','2','8','19')
				       )
 		 AND    c.KHH IS NOT NULL
		 AND    TRIM(DECODE(LENGTH(TRIM(a.GDMC)),0,'-1',a.GDMC)) < > TRIM(DECODE(LENGTH(TRIM(c.GDXM)),0,'-1',c.GDXM))
           ) a1
 ON        t.ID = a1.ID
 ;
 
 
 
 ---------------
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '02'                                       as MCGY                         --大类      
                   ,'20'                                       as FINE                         --细类      
                   ,'数据仓库'                                 as SYS                          --系统    
                   ,'T_DDW_QOT_MOT'                            as TABLE_NAME                   --表明		
                   ,''                                         as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  DDW_PROD.T_DDW_PUB_QOT a
 		    WHERE BUS_DATE = %d{yyyyMMdd}		    
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM    DDW_PROD.T_DDW_QOT_MOT
		   WHERE BUS_DATE = %d{yyyyMMdd}
           ) a1
 ON        t.ID = a1.ID
 ;
 
    INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '02'                                       as MCGY                         --大类      
                   ,'20'                                       as FINE                         --细类      
                   ,'数据仓库'                                 as SYS                          --系统    
                   ,'T_DDW_CPTL_DTL_BIZ_SBJ_MOT'                            as TABLE_NAME                   --表明		
                   ,''                                         as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  EDW_PROD.T_EDW_T05_TZJMXLS a
 		    WHERE BUS_DATE = %d{yyyyMMdd}		    
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM    DDW_PROD.T_DDW_CPTL_DTL_BIZ_SBJ_MOT
		   WHERE BUS_DATE = %d{yyyyMMdd}
           ) a1
 ON        t.ID = a1.ID
 ;
 
 
 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '02'                                       as MCGY                         --大类      
                   ,'20'                                       as FINE                         --细类      
                   ,'数据仓库'                                 as SYS                          --系统    
                   ,'T_DDW_CUST_STATMTD_MOT'                   as TABLE_NAME                   --表明		
                   ,''                                         as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  DDW_PROD.T_DDW_CUST_STATMT_DAY a
 		    WHERE BUS_DATE = %d{yyyyMMdd}		    
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM    DDW_PROD.T_DDW_CUST_STATMTD_MOT
		   WHERE BUS_DATE = %d{yyyyMMdd}
           ) a1
 ON        t.ID = a1.ID
 ;
 
 INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '02'                                       as MCGY                         --大类      
                   ,'20'                                       as FINE                         --细类      
                   ,'数据仓库'                                 as SYS                          --系统    
                   ,'T_DDW_CD_SECTION_ADD_MOT'                            as TABLE_NAME                   --表明		
                   ,''                                         as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  EDW_PROD.T_EDW_T02_TZQGL a
 		    WHERE BUS_DATE = %d{yyyyMMdd}		    
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM    DDW_PROD.T_DDW_CD_SECTION_ADD_MOT
		   WHERE BUS_DATE = %d{yyyyMMdd}
           ) a1
 ON        t.ID = a1.ID
 ;
 
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '02'                                       as MCGY                         --大类      
                   ,'20'                                       as FINE                         --细类      
                   ,'数据仓库'                                 as SYS                          --系统    
                   ,'T_DDW_HLD_VAR_MOT'                        as TABLE_NAME                   --表明		
                   ,''                                         as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS  a
 		    WHERE BUS_DATE = %d{yyyyMMdd}		    
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM    DDW_PROD.T_DDW_HLD_VAR_MOT
		   WHERE BUS_DATE = %d{yyyyMMdd}
           ) a1
 ON        t.ID = a1.ID
 ;
 
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '02'                                       as MCGY                         --大类      
                   ,'20'                                       as FINE                         --细类      
                   ,'数据仓库'                                 as SYS                          --系统    
                   ,'T_DDW_SEC_CD_PFX_TRD_CGY_MOT'                        as TABLE_NAME                   --表明		
                   ,''                                         as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  EDW_PROD.T_EDW_T05_TJGMXLS  a
 		    WHERE BUS_DATE = %d{yyyyMMdd}		    
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM    DDW_PROD.T_DDW_SEC_CD_PFX_TRD_CGY_MOT
		   WHERE BUS_DATE = %d{yyyyMMdd}
           ) a1
 ON        t.ID = a1.ID
 ;
 
  
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '02'                                       as MCGY                         --大类      
                   ,'20'                                       as FINE                         --细类      
                   ,'数据仓库'                                 as SYS                          --系统    
                   ,'T_ODS_DATA_WARNG_MOT'                     as TABLE_NAME                   --表明		
                   ,''                                         as COL                          --字段
                   ,40                                         as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                          as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM    DDW_PROD.T_ODS_DATA_WARNG_MOT
		   WHERE BUS_DATE = %d{yyyyMMdd}
           ) a1

 ;
 
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '02'                                       as MCGY                         --大类      
                   ,'20'                                       as FINE                         --细类      
                   ,'数据仓库'                                 as SYS                          --系统    
                   ,'T_DDW_PER_PRET_STK_MOT'                   as TABLE_NAME                   --表明		
                   ,''                                         as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY  a
 		    WHERE BUS_DATE = %d{yyyyMMdd}		    
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM    DDW_PROD.T_DDW_PER_PRET_STK_MOT
		   WHERE BUS_DATE = %d{yyyyMMdd}
           ) a1
 ON        t.ID = a1.ID
 ;
 
  INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '02'                                       as MCGY                         --大类      
                   ,'20'                                       as FINE                         --细类      
                   ,'数据仓库'                                 as SYS                          --系统    
                   ,'T_DDW_HLD_CD_DLSTG_EXCPT_MOT'                   as TABLE_NAME                   --表明		
                   ,''                                         as COL                          --字段
                   ,t.CHK_NUM                                  as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM       (SELECT  1 as ID
                     ,COUNT(1) as CHK_NUM 
             FROM  EDW_PROD.T_EDW_T02_TZQGL  a
 		    WHERE BUS_DATE = %d{yyyyMMdd}		    
            )   t
 LEFT JOIN (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM    DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT
		   WHERE BUS_DATE = %d{yyyyMMdd}
           ) a1
 ON        t.ID = a1.ID
 ;
 
 
   INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '02'                                       as MCGY                         --大类      
                   ,'21'                                       as FINE                         --细类      
                   ,'数据仓库'                                 as SYS                          --系统    
                   ,'T_ORIG_TAR_NUM_MOT'                       as TABLE_NAME                   --表明		
                   ,'ODS-EDW'                                  as COL                          --字段
                   ,600                                        as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM      (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM    DDW_PROD.T_ORIG_TAR_NUM_MOT
		   WHERE BUS_DATE = %d{yyyyMMdd}
		   AND   ID < 601
		   AND   IF_EQUAL = 0
           ) a1
-- ON        t.ID = a1.ID
 ;
 
    INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '02'                                       as MCGY                         --大类      
                   ,'21'                                       as FINE                         --细类      
                   ,'数据仓库'                                 as SYS                          --系统    
                   ,'T_ORIG_TAR_NUM_MOT'                       as TABLE_NAME                   --表明		
                   ,'EDW-DDW'                                  as COL                          --字段
                   ,300                                        as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM      (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM    DDW_PROD.T_ORIG_TAR_NUM_MOT
		   WHERE BUS_DATE = %d{yyyyMMdd}
		   AND   ID < 901
		   AND   IF_EQUAL = 0
           ) a1
 --ON        t.ID = a1.ID
 ;
 
     INSERT INTO DDW_PROD.T_DATA_QUA_CHK_DETAIL
 (
                                   MCGY                         --大类         
                                  ,FINE                         --细类                  
                                  ,SYS                          --系统    
                                  ,TABLE_NAME                   --表明							  
                                  ,COL                          --字段
                                  ,CHK_NUM                      --检测条数
                                  ,ERR_NUM   			        --错误条数	                 							
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT             '02'                                       as MCGY                         --大类      
                   ,'21'                                       as FINE                         --细类      
                   ,'数据仓库'                                 as SYS                          --系统    
                   ,'T_ORIG_TAR_NUM_MOT'                       as TABLE_NAME                   --表明		
                   ,'DDW-APP'                                  as COL                          --字段
                   ,300                                        as CHK_NUM                      --检测条数
                   ,NVL(a1.ERR_NUM,0)                                 as ERR_NUM   			        --错误条数	
 FROM      (SELECT  1         as ID                   
                   ,COUNT(1) as ERR_NUM
           FROM    DDW_PROD.T_ORIG_TAR_NUM_MOT
		   WHERE BUS_DATE = %d{yyyyMMdd}
		   AND   ID > = 901
		   AND   IF_EQUAL = 0
           ) a1
-- ON        t.ID = a1.ID
 ;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:股东配售权益余额表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */

    TRUNCATE TABLE EDW_PROD.T_EDW_T02_TPSQY;                                                                       
  
--------插入数据开始-----------
----插入集中交易数据
INSERT INTO EDW_PROD.T_EDW_T02_TPSQY
(
                                    GDH                                 --股东号                                
                                   ,JYS                                 --交易所                                
                                   ,KHH                                 --客户号                                
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQLB                                --证券类别                               
                                   ,JSBZDM                              --结算币种                               
                                   ,ZQSL                                --证券数量                               
                                   ,MRWTSL                              --当日买入数量                             
                                   ,MCWTSL                              --当日卖出数量                             
                                   ,DZRQ                                --权益到帐日期                             
                                   ,RGRQ                                --认购日期                               
                                   ,QRFQSL                              --确认放弃                               
                                   ,FXJ                                 --发行价                                
                                   ,QRJG                                --确认结果                               
                                   ,JGSM                                --结果说明                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --客户营业部                               
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.ZQLB                                as ZQLB                                --证券类别                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as JSBZDM                              --结算币种                                
                                   ,t.ZQSL                                as ZQSL                                --证券数量                                
                                   ,t.MRWTSL                              as MRWTSL                              --当日买入数量                              
                                   ,t.MCWTSL                              as MCWTSL                              --当日卖出数量                              
                                   ,t.DZRQ                                as DZRQ                                --权益到帐日期                              
                                   ,t.RGRQ                                as RGRQ                                --认购日期                                
                                   ,t.QRFQSL                              as QRFQSL                              --确认放弃                                
                                   ,t.FXJ                                 as FXJ                                 --发行价                                 
                                   ,t.QRJG                                as QRJG                                --确认结果                                
                                   ,t.JGSM                                as JGSM                                --结果说明                                
                                   ,'JZJY'                               as XTBS                                --                                    
 FROM           JZJYCX.SECURITIES_TPSQY                t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t2
 ON             t2.YXT = 'JZJY'
 AND            t2.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';

-----插入融资融券数据
INSERT INTO  EDW_PROD.T_EDW_T02_TPSQY(
                                     GDH                                 --股东号                                
                                   ,JYS                                 --交易所                                
                                   ,KHH                                 --客户号                                
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQLB                                --证券类别                               
                                   ,JSBZDM                              --结算币种                               
                                   ,ZQSL                                --证券数量                               
                                   ,MRWTSL                              --当日买入数量                             
                                   ,MCWTSL                              --当日卖出数量                             
                                   ,DZRQ                                --权益到帐日期                             
                                   ,RGRQ                                --认购日期                               
                                   ,QRFQSL                              --确认放弃                               
                                   ,FXJ                                 --发行价                                
                                   ,QRJG                                --确认结果                               
                                   ,JGSM                                --结果说明                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --客户营业部                               
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.ZQLB                                as ZQLB                                --证券类别                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as JSBZDM                              --结算币种                                
                                   ,t.ZQSL                                as ZQSL                                --证券数量                                
                                   ,t.MRWTSL                              as MRWTSL                              --当日买入数量                              
                                   ,t.MCWTSL                              as MCWTSL                              --当日卖出数量                              
                                   ,t.DZRQ                                as DZRQ                                --权益到帐日期                              
                                   ,t.RGRQ                                as RGRQ                                --认购日期                                
                                   ,t.QRFQSL                              as QRFQSL                              --确认放弃                                
                                   ,t.FXJ                                 as FXJ                                 --发行价                                 
                                   ,t.QRJG                                as QRJG                                --确认结果                                
                                   ,t.JGSM                                as JGSM                                --结果说明                                
                                   ,'RZRQ'                                as XTBS                                --                                    
 FROM           RZRQCX.SECURITIES_TPSQY                t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t2
 ON             t2.YXT = 'RZRQ'
 AND            t2.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---------插入数据结束----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TPSQY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TPSQY;
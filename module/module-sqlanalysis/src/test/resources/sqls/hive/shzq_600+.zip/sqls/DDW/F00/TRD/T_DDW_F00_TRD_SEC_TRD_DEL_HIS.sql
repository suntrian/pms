 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:证券交易明细历史表                                                        */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */ 
 


--------------插入数据-------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
(           EVNT_SEQNBR1             --事件序号
            ,EVNT_SEQNBR             --事件序号	        
            ,ODR_NO                  --委托号	           
            ,CUST_NO                 --客户号	           
            ,CUST_NAME             	--客户姓名	       		  
            ,SHRHLD_NO               --股东号	           
            ,SHRHLD_NAME             --股东姓名	       
            ,EXG                     --交易所	           
            ,CCY_CD                  --币种代码	       
			,ODR_MOD                 --委托方式	       
            ,BRH_NO                  --营业部	           
            ,SEC_CD                  --证券代码
            ,SEC_CD1                 --证券代码1			
			,SEC_NAME                --证券名称	       
			,SEC_CGY                 --证券类别	       
            ,ODR_CGY                 --委托类别	       
			,MTCH_NO                 --成交编号	                         							  
            ,MTCH_DT                 --成交日期	       
            ,END_DT                  --结束日期           
            ,MTCH_ITMS               --成交笔数	       
			,MTCH_QTY                --成交数量	       
			,MTCH_PRC                --成交价格	       
			,MTCH_AMT                --成交金额	       
			,S1                      --实收佣金	       
            ,S2                      --印花税	           
            ,S3                      --过户费	           
            ,S4                      --附加费	           
            ,S5                      --证管费
            ,S6                      --交易规费			
            ,RCVB_AMT                --应收金额	       
            ,S11                     --一级费用-经手费    
            ,S12                     --一级费用-证管费	   
            ,S13                     --一级费用-过户费	   
            ,S15                     --一级费用-结算费	   
            ,S16                     --一级费用-风险基金  
            ,INT_AMT                 --利息金额	       
			,OPRT_CLNT               --操作终端
			,IF_TRD                  --是否算交易
			,IF_PRET                 --是否算赢亏
            ,SYS_SRC                 --账户来源    	   	
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT    row_number() over(order by t.KHH) as EVNT_SEQNBR1             --事件序号	
           ,t.SEQNO         as EVNT_SEQNBR             --事件序号	        
           ,t.WTH	        as ODR_NO                  --委托号	                                                        
           ,t.KHH	        as CUST_NO                 --客户号	           
           ,t.KHXM          as CUST_NAME             	--客户姓名	       		
           ,t.GDH	        as SHRHLD_NO               --股东号	           
           ,t.GDXM          as SHRHLD_NAME             --股东姓名	       
           ,t.JYS	        as EXG                     --交易所	           
           ,t.BZDM          as CCY_CD                  --币种代码	       
           ,t.WTFS          as ODR_MOD                 --委托方式	       
           ,t.YYB	        as BRH_NO                  --营业部	           
           ,t.ZQDM          as SEC_CD                  --证券代码
           ,t.ZQDM1          as SEC_CD1                 --证券代码1			
           ,t.ZQMC          as SEC_NAME                --证券名称	       
           , CASE WHEN t.JYS = 'SB'
		         AND  SUBSTR(t.ZQDM,1,3) = '200'
				 AND  NVL(a3.ZQLB,t.ZQLB) NOT LIKE 'B%'
				 THEN 'B0'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('135','145','146')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z36'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('500')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('512')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J04'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('519')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J07'
 				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('101')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z04'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z04'
				  WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z01'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('112')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z13'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('119')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('127','128')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z10'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('150')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J06'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('184')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 ELSE NVL(a3.ZQLB,t.ZQLB)
		         END        as SEC_CGY                 --证券类别	       
           ,t.WTLB          as ODR_CGY                 --委托类别	       
           ,t.CJBH          as MTCH_NO                 --成交编号	           
           ,t.CJRQ          as MTCH_DT                 --成交日期	       
           ,t.JSRQ          as END_DT                  --结束日期           
           ,a4.CJBS          as MTCH_ITMS               --成交笔数	       
           ,t.CJSL          as MTCH_QTY                --成交数量	       
           ,t.CJJG          as MTCH_PRC                --成交价格	       
           ,t.CJJE          as MTCH_AMT                --成交金额	       
           ,t.S1	        as S1                      --实收佣金	       
           ,t.S2	        as S2                      --印花税	           
           ,t.S3	        as S3                      --过户费	           
           ,t.S4	        as S4                      --附加费	           
           ,t.S5	        as S5                      --证管费	
           ,t.S6            as S6                      --交易规费	           
           ,t.YSJE          as RCVB_AMT                --应收金额	       
           ,t.S11	        as S11                     --一级费用-经手费    
           ,t.S12	        as S12                     --一级费用-证管费	   
           ,t.S13	        as S13                     --一级费用-过户费	   
           ,t.S15	        as S15                     --一级费用-结算费	   
           ,t.S16	        as S16                     --一级费用-风险基金  
           ,t.LXJE          as INT_AMT                 --利息金额	       
           ,t.CZZD1         as OPRT_CLNT               --操作终端
           ,NVL(a1.IF_TRD,a2.IF_TRD)          as IF_TRD                  --是否算交易
           ,NVL(a1.IF_PRFT,a2.IF_PRFT)          as IF_PRET                 --是否算赢亏
           ,DECODE(t.XTBS,'JZJY','普通账户','信用账户')          as SYS_SRC                 --账户来源    	   	
 FROM           EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW                   t
 LEFT JOIN      (SELECT SEQNO,CJBS 
                 FROM EDW_PROD.T_EDW_T05_TJGMXLS 
                 WHERE BUS_DATE = %d{yyyyMMdd}
				 GROUP BY SEQNO,CJBS
				)      a4
  ON            t.SEQNO = a4.SEQNO				
  LEFT JOIN     (SELECT   EXG,SEC_CD_PFX,TRD_CGY,IF_PRFT,IF_TRD 
                 FROM     DDW_PROD.T_DDW_CFG_SEC
				 GROUP BY EXG,SEC_CD_PFX,TRD_CGY,IF_PRFT,IF_TRD
				)                                                     a1
 ON             t.ZQDM = a1.SEC_CD_PFX
 AND            t.JYS = a1.EXG
 AND            t.WTLB = a1.TRD_CGY
 LEFT JOIN     (SELECT   EXG,SEC_CD_PFX,TRD_CGY,IF_PRFT,IF_TRD 
                 FROM     DDW_PROD.T_DDW_CFG_SEC
				 GROUP BY EXG,SEC_CD_PFX,TRD_CGY,IF_PRFT,IF_TRD
				)                                                     a2
 ON             SUBSTR(t.ZQDM,1,3) = a2.SEC_CD_PFX
 AND            t.JYS = a2.EXG
 AND            t.WTLB = a2.TRD_CGY
 LEFT JOIN     EDW_PROD.T_EDW_T04_TZQDM       a3
 ON            t.JYS = a3.JYS
 AND           t.ZQDM = a3.ZQDM
 AND           a3.BUS_DATE = %d{yyyyMMdd}
 WHERE         t.BUS_DATE = %d{yyyyMMdd}
 ;
 
----------------------插入数据结束------------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_TRD_SEC_TRD_DEL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS ;
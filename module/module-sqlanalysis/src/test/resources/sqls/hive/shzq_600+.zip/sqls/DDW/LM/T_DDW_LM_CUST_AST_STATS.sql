------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户资产统计表                                                                  	   */
------/* 创建人:常静静                                                                                 */
------/* 创建时间:2018-11-26                                                                           */

--删除今天的数据--
ALTER TABLE DDW_PROD.T_DDW_LM_CUST_AST_STATS DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd});

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT CUST_NO
      ,'0'   --总账户
	  ,'1'   --日
	  ,TOT_AST - TOT_GL AS TOT_AST
	  ,0
	  ,TOT_AST AS NET_AST
	  ,0
	  ,0
	  ,0
	  ,0
FROM 
(
  SELECT CUST_NO
        ,SUM(TOT_AST) AS TOT_AST
		,SUM(TOTGL) AS TOT_GL
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
) T
WHERE TOT_AST <> 0 OR TOT_GL <> 0
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT CUST_NO
      ,'1'   --普通账户
	  ,'1'   --日
	  ,TOT_AST - TOT_GL AS TOT_AST
	  ,0
	  ,TOT_AST AS NET_AST
	  ,0
	  ,0
	  ,0
	  ,0
FROM 
(
  SELECT CUST_NO
        ,SUM(ORDI_AST) AS TOT_AST
		,SUM(ORDI_GL) AS TOT_GL
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
) T
WHERE TOT_AST <> 0 OR TOT_GL <> 0
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT CUST_NO
      ,'2'   --信用账户
	  ,'1'   --日
	  ,TOT_AST - TOT_GL AS TOT_AST
	  ,0
	  ,TOT_AST AS NET_AST
	  ,0
	  ,0
	  ,0
	  ,0
FROM 
(
  SELECT CUST_NO
        ,SUM(CRD_AST) AS TOT_AST
		,SUM(CRD_GL) AS TOT_GL
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
) T
WHERE TOT_AST <> 0 OR TOT_GL <> 0
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT CUST_NO
      ,'0' AS ACT_CGY   --总账户
	  ,'2' AS DATA_PRD   --5日
	  ,0 AS TOT_AST
	  ,0 AS TOT_AST_MAX
	  ,0 AS NET_AST
	  ,0 AS NET_AST_MAX
	  ,AVG(NET_AST) AS NET_AST_AVG
	  ,AVG(EXG_NET_AST_AVG) AS EXG_NET_AST_AVG
	  ,0 AS AST_IN_NAV
FROM 
(
  SELECT CUST_NO
        ,SUM(TOT_AST) AS TOT_AST
		,SUM(TOTGL) AS TOT_GL
		,SUM(TOT_AST) - SUM(TOTGL) AS NET_AST
		,SUM(EXG_NET_TOT_AST) AS EXG_NET_AST_AVG
		,BUS_DATE
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE IN (SELECT TRD_DT FROM 
                                       (
                                         SELECT TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC) AS NUM 
                                         FROM 
                                             (
                                                SELECT DISTINCT TRD_DT
                                                FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                                WHERE  BUS_DATE = (SELECT MAX(BUS_DATE) FROM EDW_PROD.T_EDW_T99_TRD_DATE)
                                                AND TRD_DT <= %d{yyyyMMdd}
                                             ) T
                                       ) T1
                                   WHERE NUM <= 5)
GROUP BY CUST_NO,BUS_DATE
) T
WHERE TOT_AST <> 0 OR TOT_GL <> 0
GROUP BY CUST_NO
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT CUST_NO
      ,'1' AS ACT_CGY   --普通账户
	  ,'2' AS DATA_PRD   --5日
	  ,0 AS TOT_AST
	  ,0 AS TOT_AST_MAX
	  ,0 AS NET_AST
	  ,0 AS NET_AST_MAX
	  ,AVG(NET_AST) AS NET_AST_AVG
	  ,AVG(EXG_NET_AST_AVG) AS EXG_NET_AST_AVG
	  ,0 AS AST_IN_NAV
FROM 
(
  SELECT CUST_NO
        ,SUM(ORDI_AST) AS TOT_AST
		,SUM(ORDI_GL) AS TOT_GL
		,SUM(ORDI_NET_AST) AS NET_AST
		,SUM(EXG_NET_TOT_AST)-SUM(CRD_NET_AST)-SUM(WRNT_AST) AS EXG_NET_AST_AVG
		,BUS_DATE
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE IN (SELECT TRD_DT FROM 
                                       (
                                         SELECT TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC) AS NUM 
                                         FROM 
                                             (
                                                SELECT DISTINCT TRD_DT
                                                FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                                WHERE  BUS_DATE = (SELECT MAX(BUS_DATE) FROM EDW_PROD.T_EDW_T99_TRD_DATE)
                                                AND TRD_DT <= %d{yyyyMMdd}
                                             ) T
                                       ) T1
                                   WHERE NUM <= 5)
GROUP BY CUST_NO,BUS_DATE
) T
WHERE TOT_AST <> 0 OR TOT_GL <> 0
GROUP BY CUST_NO
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT CUST_NO
      ,'2' AS ACT_CGY   --信用账户
	  ,'2' AS DATA_PRD   --5日
	  ,0 AS TOT_AST
	  ,0 AS TOT_AST_MAX
	  ,0 AS NET_AST
	  ,0 AS NET_AST_MAX
	  ,AVG(NET_AST) AS NET_AST_AVG
	  ,AVG(EXG_NET_AST_AVG) AS EXG_NET_AST_AVG
	  ,0 AS AST_IN_NAV
FROM 
(
  SELECT CUST_NO
        ,SUM(CRD_AST) AS TOT_AST
		,SUM(CRD_GL) AS TOT_GL
		,SUM(CRD_NET_AST) AS NET_AST
		,SUM(CRD_NET_AST) AS EXG_NET_AST_AVG
		,BUS_DATE
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE IN (SELECT TRD_DT FROM 
                                       (
                                         SELECT TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC) AS NUM 
                                         FROM 
                                             (
                                                SELECT DISTINCT TRD_DT
                                                FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                                WHERE  BUS_DATE = (SELECT MAX(BUS_DATE) FROM EDW_PROD.T_EDW_T99_TRD_DATE)
                                                AND TRD_DT <= %d{yyyyMMdd}
                                             ) T
                                       ) T1
                                   WHERE NUM <= 5)
GROUP BY CUST_NO,BUS_DATE
) T
WHERE TOT_AST <> 0 OR TOT_GL <> 0
GROUP BY CUST_NO
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT CUST_NO
      ,'0' AS ACT_CGY   --总账户
	  ,'3' AS DATA_PRD   --10日
	  ,0 AS TOT_AST
	  ,0 AS TOT_AST_MAX
	  ,0 AS NET_AST
	  ,0 AS NET_AST_MAX
	  ,AVG(NET_AST) AS NET_AST_AVG
	  ,0 AS EXG_NET_AST_AVG
	  ,0 AS AST_IN_NAV
FROM 
(
  SELECT CUST_NO
        ,SUM(TOT_AST) AS TOT_AST
		,SUM(TOTGL) AS TOT_GL
		,SUM(TOT_AST) - SUM(TOTGL) AS NET_AST
		,BUS_DATE
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE IN (SELECT TRD_DT FROM 
                                       (
                                         SELECT TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC) AS NUM 
                                         FROM 
                                             (
                                                SELECT DISTINCT TRD_DT
                                                FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                                WHERE  BUS_DATE = (SELECT MAX(BUS_DATE) FROM EDW_PROD.T_EDW_T99_TRD_DATE)
                                                AND TRD_DT <= %d{yyyyMMdd}
                                             ) T
                                       ) T1
                                   WHERE NUM <= 10)
GROUP BY CUST_NO,BUS_DATE
) T
WHERE TOT_AST <> 0 OR TOT_GL <> 0
GROUP BY CUST_NO
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT CUST_NO
      ,'1' AS ACT_CGY   --普通账户
	  ,'3' AS DATA_PRD   --10日
	  ,0 AS TOT_AST
	  ,0 AS TOT_AST_MAX
	  ,0 AS NET_AST
	  ,0 AS NET_AST_MAX
	  ,AVG(NET_AST) AS NET_AST_AVG
	  ,0 AS EXG_NET_AST_AVG
	  ,0 AS AST_IN_NAV
FROM 
(
  SELECT CUST_NO
        ,SUM(ORDI_AST) AS TOT_AST
		,SUM(ORDI_GL) AS TOT_GL
		,SUM(ORDI_NET_AST) AS NET_AST
		,BUS_DATE
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE IN (SELECT TRD_DT FROM 
                                       (
                                         SELECT TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC) AS NUM 
                                         FROM 
                                             (
                                                SELECT DISTINCT TRD_DT
                                                FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                                WHERE  BUS_DATE = (SELECT MAX(BUS_DATE) FROM EDW_PROD.T_EDW_T99_TRD_DATE)
                                                AND TRD_DT <= %d{yyyyMMdd}
                                             ) T
                                       ) T1
                                   WHERE NUM <= 10)
GROUP BY CUST_NO,BUS_DATE
) T
WHERE TOT_AST <> 0 OR TOT_GL <> 0
GROUP BY CUST_NO
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT CUST_NO
      ,'2' AS ACT_CGY   --信用账户
	  ,'3' AS DATA_PRD   --10日
	  ,0 AS TOT_AST
	  ,0 AS TOT_AST_MAX
	  ,0 AS NET_AST
	  ,0 AS NET_AST_MAX
	  ,AVG(NET_AST) AS NET_AST_AVG
	  ,0 AS EXG_NET_AST_AVG
	  ,0 AS AST_IN_NAV
FROM 
(
  SELECT CUST_NO
        ,SUM(CRD_AST) AS TOT_AST
		,SUM(CRD_GL) AS TOT_GL
		,SUM(CRD_NET_AST) AS NET_AST
		,BUS_DATE
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE IN (SELECT TRD_DT FROM 
                                       (
                                         SELECT TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC) AS NUM 
                                         FROM 
                                             (
                                                SELECT DISTINCT TRD_DT
                                                FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                                WHERE  BUS_DATE = (SELECT MAX(BUS_DATE) FROM EDW_PROD.T_EDW_T99_TRD_DATE)
                                                AND TRD_DT <= %d{yyyyMMdd}
                                             ) T
                                       ) T1
                                   WHERE NUM <= 10)
GROUP BY CUST_NO,BUS_DATE
) T
WHERE TOT_AST <> 0 OR TOT_GL <> 0
GROUP BY CUST_NO
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO
      ,'0' AS ACT_CGY   --总账户
	  ,'4' AS DATA_PRD   --月
	  ,0 AS TOT_AST
	  ,0 AS TOT_AST_MAX
	  ,0 AS NET_AST
	  ,0 AS NET_AST_MAX
	  ,AVG(T.NET_AST) AS NET_AST_AVG
	  ,AVG(EXG_NET_AST_AVG) AS EXG_NET_AST_AVG
	  ,SUM(T1.NET_FLW_IN_AMT) AS AST_IN_NAV
FROM 
(
  SELECT CUST_NO
        ,SUM(TOT_AST) AS TOT_AST
		,SUM(TOTGL) AS TOT_GL
		,SUM(TOT_AST) - SUM(TOTGL) AS NET_AST
		,SUM(EXG_NET_TOT_AST) AS EXG_NET_AST_AVG
		,BUS_DATE
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE IN ( SELECT DISTINCT TRD_DT
                      FROM EDW_PROD.T_EDW_T99_TRD_DATE
                      WHERE  BUS_DATE = (SELECT MAX(BUS_DATE) FROM EDW_PROD.T_EDW_T99_TRD_DATE)
                      AND SUBSTR(CAST(TRD_DT AS STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
                    ) 
  GROUP BY CUST_NO,BUS_DATE
) T
LEFT JOIN
(
  SELECT CUST_NO
        ,SUM(NET_FLW_IN_AMT) AS NET_FLW_IN_AMT
		,BUS_DATE
  FROM DDW_PROD.T_DDW_CUST_STATMT_DAY
  WHERE SUBSTR(CAST(BUS_DATE AS STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
  GROUP BY CUST_NO,BUS_DATE
) T1
ON T.CUST_NO = T1.CUST_NO
AND T.BUS_DATE = T1.BUS_DATE
WHERE T.TOT_AST <> 0 OR T.TOT_GL <> 0
GROUP BY T.CUST_NO
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO
      ,'1' AS ACT_CGY   --普通账户
	  ,'4' AS DATA_PRD   --月
	  ,0 AS TOT_AST
	  ,0 AS TOT_AST_MAX
	  ,0 AS NET_AST
	  ,0 AS NET_AST_MAX
	  ,AVG(T.NET_AST) AS NET_AST_AVG
	  ,AVG(EXG_NET_AST_AVG) AS EXG_NET_AST_AVG
	  ,0 AS AST_IN_NAV
FROM 
(
  SELECT CUST_NO
        ,SUM(ORDI_AST) AS TOT_AST
		,SUM(ORDI_GL) AS TOT_GL
		,SUM(ORDI_NET_AST) AS NET_AST
		,SUM(EXG_NET_TOT_AST)-SUM(CRD_NET_AST)-SUM(WRNT_AST) AS EXG_NET_AST_AVG
		,BUS_DATE
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE IN (
                      SELECT DISTINCT TRD_DT
                      FROM EDW_PROD.T_EDW_T99_TRD_DATE
                      WHERE  BUS_DATE = (SELECT MAX(BUS_DATE) FROM EDW_PROD.T_EDW_T99_TRD_DATE)
                      AND SUBSTR(CAST(TRD_DT AS STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
                    )
  GROUP BY CUST_NO,BUS_DATE
) T
WHERE T.TOT_AST <> 0 OR T.TOT_GL <> 0
GROUP BY T.CUST_NO
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO
      ,'2' AS ACT_CGY   --信用账户
	  ,'4' AS DATA_PRD   --月
	  ,0 AS TOT_AST
	  ,0 AS TOT_AST_MAX
	  ,0 AS NET_AST
	  ,0 AS NET_AST_MAX
	  ,AVG(T.NET_AST) AS NET_AST_AVG
	  ,AVG(EXG_NET_AST_AVG) AS EXG_NET_AST_AVG
	  ,0 AS AST_IN_NAV
FROM 
(
  SELECT CUST_NO
        ,SUM(CRD_AST) AS TOT_AST
		,SUM(CRD_GL) AS TOT_GL
		,SUM(CRD_NET_AST) AS NET_AST
		,SUM(CRD_NET_AST) AS EXG_NET_AST_AVG
		,BUS_DATE
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE IN ( 
                      SELECT DISTINCT TRD_DT
                      FROM EDW_PROD.T_EDW_T99_TRD_DATE
                      WHERE  BUS_DATE = (SELECT MAX(BUS_DATE) FROM EDW_PROD.T_EDW_T99_TRD_DATE)
                      AND SUBSTR(CAST(TRD_DT AS STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
                    )
  GROUP BY CUST_NO,BUS_DATE
) T
WHERE T.TOT_AST <> 0 OR T.TOT_GL <> 0
GROUP BY T.CUST_NO
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO
      ,'0' AS ACT_CGY   --总账户
	  ,'6' AS DATA_PRD   --年
	  ,0 AS TOT_AST
	  ,MAX(TOT_AST) AS TOT_AST_MAX
	  ,0 AS NET_AST
	  ,MAX(NET_AST) AS NET_AST_MAX
	  ,AVG(T.NET_AST) AS NET_AST_AVG
	  ,AVG(EXG_NET_AST_AVG) AS EXG_NET_AST_AVG
	  ,SUM(NET_FLW_IN_AMT) AS AST_IN_NAV
FROM 
(
  SELECT CUST_NO
        ,SUM(TOT_AST) AS TOT_AST
		,SUM(TOTGL) AS TOT_GL
		,SUM(TOT_AST) - SUM(TOTGL) AS NET_AST
		,SUM(EXG_NET_TOT_AST) AS EXG_NET_AST_AVG
		,SUM(NET_TFR_IN_AMT) + SUM(NET_TFR_IN_MKTVAL) AS NET_FLW_IN_AMT
		,BUS_DATE
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE IN ( SELECT DISTINCT TRD_DT
                      FROM EDW_PROD.T_EDW_T99_TRD_DATE
                      WHERE  BUS_DATE = (SELECT MAX(BUS_DATE) FROM EDW_PROD.T_EDW_T99_TRD_DATE)
                      AND SUBSTR(CAST(TRD_DT AS STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
                    )
  GROUP BY CUST_NO,BUS_DATE
) T
--LEFT JOIN
--(
--  SELECT CUST_NO
--        ,SUM(NET_FLW_IN_AMT) AS NET_FLW_IN_AMT
--		,BUS_DATE
--  FROM DDW_PROD.T_DDW_CUST_STATMT_DAY
--  WHERE SUBSTR(CAST(BUS_DATE AS STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
--  GROUP BY CUST_NO,BUS_DATE
--) T1
--ON T.CUST_NO = T1.CUST_NO
--AND T.BUS_DATE = T1.BUS_DATE
WHERE T.TOT_AST <> 0 OR T.TOT_GL <> 0
GROUP BY T.CUST_NO
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO
      ,'1' AS ACT_CGY   --普通账户
	  ,'6' AS DATA_PRD   --年
	  ,0 AS TOT_AST
	  ,MAX(TOT_AST) AS TOT_AST_MAX
	  ,0 AS NET_AST
	  ,MAX(NET_AST) AS NET_AST_MAX
	  ,AVG(T.NET_AST) AS NET_AST_AVG
	  ,AVG(EXG_NET_AST_AVG) AS EXG_NET_AST_AVG
	  ,SUM(NET_FLW_IN_AMT) AS AST_IN_NAV
FROM 
(
  SELECT CUST_NO
        ,SUM(ORDI_AST) AS TOT_AST
		,SUM(ORDI_GL) AS TOT_GL
		,SUM(ORDI_NET_AST) AS NET_AST
		,SUM(EXG_NET_TOT_AST)-SUM(CRD_NET_AST)-SUM(WRNT_AST) AS EXG_NET_AST_AVG
		,SUM(ORDI_NET_TFR_IN_AMT) + SUM(ORDI_NET_TFR_IN_MKTVAL) AS NET_FLW_IN_AMT
		,BUS_DATE
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE IN (
                      SELECT DISTINCT TRD_DT
                      FROM EDW_PROD.T_EDW_T99_TRD_DATE
                      WHERE  BUS_DATE = (SELECT MAX(BUS_DATE) FROM EDW_PROD.T_EDW_T99_TRD_DATE)
                      AND SUBSTR(CAST(TRD_DT AS STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
                    )
  GROUP BY CUST_NO,BUS_DATE
) T
WHERE T.TOT_AST <> 0 OR T.TOT_GL <> 0
GROUP BY T.CUST_NO
;

INSERT INTO DDW_PROD.T_DDW_LM_CUST_AST_STATS
(
 CUST_NO           			--1. 客户号
,ACCT_CGY                  	--2. 账户类别
,DATA_PRD		            --3. 统计周期
,TOT_AST		            --4. 总资产
,TOT_AST_MAX                --5. 峰值总资产
,NET_AST		            --6. 净资产
,NET_AST_MAX		        --7. 峰值净资产
,NET_AST_AVG		        --8. 日均净资产
,EXG_NET_AST_AVG            --9. 日均场内净资产
,AST_IN_NAV        	        --10. 资产净流入
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO
      ,'2' AS ACT_CGY   --信用账户
	  ,'6' AS DATA_PRD   --年
	  ,0 AS TOT_AST
	  ,MAX(TOT_AST) AS TOT_AST_MAX
	  ,0 AS NET_AST
	  ,MAX(NET_AST) AS NET_AST_MAX
	  ,AVG(T.NET_AST) AS NET_AST_AVG
	  ,AVG(EXG_NET_AST_AVG) AS EXG_NET_AST_AVG
	  ,SUM(NET_FLW_IN_AMT) AS AST_IN_NAV
FROM 
(
  SELECT CUST_NO
        ,SUM(CRD_AST) AS TOT_AST
		,SUM(CRD_GL) AS TOT_GL
		,SUM(CRD_NET_AST) AS NET_AST
		,SUM(CRD_NET_AST) AS EXG_NET_AST_AVG
		,SUM(CRD_NET_TFR_IN_AMT) + SUM(CRD_NET_TFR_IN_MKTVAL) AS NET_FLW_IN_AMT
		,BUS_DATE
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE IN (
                      SELECT DISTINCT TRD_DT
                      FROM EDW_PROD.T_EDW_T99_TRD_DATE
                      WHERE  BUS_DATE = (SELECT MAX(BUS_DATE) FROM EDW_PROD.T_EDW_T99_TRD_DATE)
                      AND SUBSTR(CAST(TRD_DT AS STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
                    )
  GROUP BY CUST_NO,BUS_DATE
) T
WHERE T.TOT_AST <> 0 OR T.TOT_GL <> 0
GROUP BY T.CUST_NO
;


INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_LM_CUST_AST_STATS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
invalidate metadata DDW_PROD.T_DDW_LM_CUST_AST_STATS;

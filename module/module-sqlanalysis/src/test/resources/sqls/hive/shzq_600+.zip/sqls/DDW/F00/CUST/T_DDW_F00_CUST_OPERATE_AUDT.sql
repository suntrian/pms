 ----/* ***************************************** SQL Begin *****************************************  */
  ----/* 脚本功能:操作人审核表                                                                         */
  ----/* 创建人:黄勇华                                                                               */
  ----/* 创建时间:2018-06-12                                                                        */ 
  ----/YWDM 20322 20323 走20321 业务代码
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP;
CREATE TABLE DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP
as SELECT      a.KHH           as KHH
              ,a.CZLX          as CZLX
			  ,b.YWDM          as YWDM
			  ,c.NAME          as NAME
			  ,b.YWQQZT        as YWQQZT
			  ,a.YWQQID        as YWQQID
			  ,a.BUS_DATE      as BUS_DATE
			  ,a.BZSM          as BZSM
              ,CASE WHEN a.CZLX = 211
                    THEN ROW_NUMBER() OVER(PARTITION BY a.YWQQID,a.CZLX ORDER BY a.CZSJ )
					END        as SORT_1 			  
   FROM       EDW_PROD.T_EDW_T05_TYWQQ_CZLS a
   LEFT JOIN  EDW_PROD.T_EDW_T05_TYWQQ      b
   ON         a.ywqqid = b.YWQQID
   LEFT JOIN EDW_PROD.T_EDW_T02_TUSER       c
   ON        a.CZR = c.TUSER_ID
   AND       c.BUS_DATE = %d{yyyyMMdd}
   WHERE       (b.FQQD = 1 OR (b.YWDM = '20042' AND b.FQQD = 11))
   AND   EXISTS(SELECT 1 
                FROM (SELECT  b.YWDM
				      FROM      EDW_PROD.T_EDW_T99_TYWLC_TJ_SHJD a
				      LEFT JOIN  EDW_PROD.T_EDW_T99_TYWLC_TJ     b
				      ON         a.BUS_DATE = b.BUS_DATE		       
				      AND        a.tywlc_tj_id = b.ID
				      WHERE      a.SHJS IN (47,48,60,813)
					  AND        a.BUS_DATE = %d{yyyyMMdd}
				      )      d
				  WHERE DECODE(b.YWDM,'20322','20321','20323','20321',b.YWDM) = d.YWDM
                  )
  AND       c.USERID IN ('00000320','00000287','00000256','00000579','00000708','00000235','00000181','00001071','00002722','88890181','88890708','88890287','88890256','88892722','88890579','88890320')    
  AND       a.BUS_DATE > = 20180401 
  AND       a.CZLX IN (211,301,302,321,322);
  
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP1;
  CREATE TABLE DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP1
  as  SELECT   a.KHH           as KHH
              ,a.CZLX          as CZLX
			  ,a.YWDM          as YWDM
			  ,a.NAME          as NAME
			  ,a.YWQQZT        as YWQQZT
			  ,a.YWQQID        as YWQQID
			  ,a.BUS_DATE      as FSRQ
			  ,a.SORT_1        as SORT_1
			  ,a.BZSM          as BZSM
			  ,CASE WHEN b.YWQQID IS NOT NULL
			        THEN b.BUS_DATE
					WHEN e.YWQQID IS NOT NULL
			        THEN e.BUS_DATE
					ELSE a.BUS_DATE
					END        as BUS_DATE
			  ,CASE WHEN c.YWQQID IS NOT NULL
			        THEN 0
					WHEN a.CZLX IN (301,302)
					THEN 0
					WHEN d.YWQQID IS NOT NULL
			        THEN 0
					ELSE 1
					END            as IF_YWQQZT --是否看业务请求状态(0 不看 1 是看)
      FROM        DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP  a
      LEFT  JOIN (SELECT   YWQQID,MIN(BUS_DATE) as BUS_DATE
                  FROM     DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP
			      WHERE    CZLX IN (211)
 			      GROUP BY YWQQID  
                  )    b
      ON         a.YWQQID = b.YWQQID
      AND        a.CZLX IN (301,302,211)
	  LEFT  JOIN (SELECT   YWQQID,MIN(BUS_DATE) as BUS_DATE
                  FROM     DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP
			      WHERE    CZLX IN (321,322)
 			      GROUP BY YWQQID  
                  )    e
      ON         a.YWQQID = e.YWQQID
      AND        a.CZLX IN (321,322)
	  LEFT  JOIN (SELECT   YWQQID
                  FROM     DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP
			      WHERE    CZLX IN (301,302)
 			      GROUP BY YWQQID  
                  )    c
      ON         a.YWQQID = c.YWQQID
      AND        a.CZLX IN (211)
	  LEFT  JOIN (SELECT   YWQQID
                  FROM     DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP
			      WHERE    CZLX IN (301,302,211)
 			      GROUP BY YWQQID  
                  )    d
      ON         a.YWQQID = d.YWQQID
      AND        a.CZLX IN (321,322);
	  
----插入数据
INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT
(
               CUST_NO            --客户号
              ,OPRT_TP            --操作类型
              ,CUST_CGY           --客户类别
              ,BIZ_CD             --业务代码
			  ,BIZ_NAME           --业务名称
              ,AUDT_PSN_NAME      --审核人姓名
			  ,AUDT_TS            --审核时长                           
			  ,BIZ_APL_STAT       --业务请求状态
			  ,BIZ_APL_ID         --业务请求ID
			  ,IF_BIZ_APL_STAT    --是否看业务请求状态
			  ,OCC_DT             --发生日期
			  ,STEP_EXPLN         --步骤说明
)PARTITION(BUS_DATE)
SELECT         t.KHH           as CUST_NO            --客户号
              ,t.CZLX          as OPRT_TP            --操作类型
              ,a1.KHLB         as CUST_CGY           --客户类别
              ,t.YWDM          as BIZ_CD             --业务代码
			  ,a4.YWMC         as BIZ_NAME           --业务名称
              ,t.NAME          as AUDT_PSN_NAME      --审核人姓名
			  ,CASE WHEN t.CZLX IN (321,322)
			        THEN 0
					ELSE unix_timestamp(a3.finish_date)-unix_timestamp(a3.start_date)
					END        as AUDT_TS            --审核时长                           
			  ,t.YWQQZT        as BIZ_APL_STAT       --业务请求状态
			  ,t.YWQQID        as BIZ_APL_ID         --业务请求ID
			  ,t.IF_YWQQZT     as IF_BIZ_APL_STAT    --是否看业务请求状态
			  ,t.FSRQ          as OCC_DT             --发生日期
			  ,t.BZSM          as STEP_EXPLN         --步骤说明
			  ,t.BUS_DATE      as BUS_DATE
FROM      DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP1    t
LEFT JOIN EDW_PROD.T_EDW_T01_TKHXX       a1
ON        t.KHH = a1.KHH
AND       a1.BUS_DATE = %d{yyyyMMdd} 
LEFT JOIN (SELECT    a.YWQQID
                    ,a.BUS_DATE
                    ,a.instid
                    ,b.state	
                    ,CASE WHEN b.state IN (1,3)
                          THEN ROW_NUMBER() OVER(PARTITION BY a.YWQQID ORDER BY b.init_date )
					      END        as SORT_2 					
             FROM       EDW_PROD.T_EDW_T05_LCGTYW    a
			 LEFT JOIN  EDW_PROD.T_EDW_T05_OS_WFENTRY b
			 ON         a.instid = b.ID
			 AND        a.BUS_DATE = b.BUS_DATE
			 WHERE a.instid < > -1
			 UNION 
			 SELECT a.YWQQID
                    ,a.BUS_DATE
                    ,a.instid
                    ,b.state
                    ,CASE WHEN b.state IN (1,3)
                          THEN ROW_NUMBER() OVER(PARTITION BY a.YWQQID ORDER BY b.init_date )
					      END		as SORT_2			
             FROM       EDW_PROD.T_EDW_T05_LCGTYW_KHXXXG    a
			 LEFT JOIN  EDW_PROD.T_EDW_T05_OS_WFENTRY b
			 ON         a.instid = b.ID
			 AND        a.BUS_DATE = b.BUS_DATE
			 WHERE a.instid < > -1
			 )      a2
 ON     t.YWQQID = a2.YWQQID
 AND    ((t.CZLX IN (301,302) AND a2.STATE IN(1,4))
 OR     (t.CZLX IN (211) AND t.SORT_1 = a2.SORT_2 AND a2.STATE IN(1,3)  ))
 LEFT JOIN (SELECT  entry_id
                    ,MIN(start_date) as start_date
					,MAX(finish_date) as finish_date
					,bus_date 
             FROM EDW_PROD.T_EDW_T05_OS_HISTORYSTEP
			 GROUP BY entry_id,BUS_DATE 
			 )      a3
  ON        a2.instid = a3.entry_id 
 LEFT JOIN EDW_PROD.T_EDW_T99_TYWDM a4
 ON        t.YWDM = a4.YWDM
 AND       a4.BUS_DATE = %d{yyyyMMdd}  ;
  
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP1;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TEMP2;
  
  
------------------------插入数据结束---------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_OPERATE_AUDT',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT ;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户资料修改表                                                                   */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 

-------插入数据开始------------
INSERT OVERWRITE EDW_PROD.T_EDW_T05_TKHZLXG(
                                     KHXGZI_ID                           --修改客户资料编号                           
                                   ,KHH                                 --客户号                                
                                   ,XGRQ                                --修改日期                               
                                   ,MODIFYTIME                          --修改时间                               
                                   ,ZD                                  --字段                                 
                                   ,ZDMC                                --字段名称                               
                                   ,OLDVALUE                            --原值                                 
                                   ,NEWVALUE                            --新值                                 
                                   ,OLDNAME                             --原值说明                               
                                   ,NEWNAME                             --新值说明                               
                                   ,XGR                                 --修改人                                
                                   ,XGQD                                --修改渠道                               
                                   ,CZMX_LSH                            --操作明细流水号                            
                                   ,SFXS                                --是否显示  
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.ID                                  as KHXGZI_ID                           --ID                                  
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.XGRQ                                as XGRQ                                --修改日期                                
                                   ,t.XGSJ                                as MODIFYTIME                          --修改时间                                
                                   ,t.ZD                                  as ZD                                  --字段                                  
                                   ,t.ZDMC                                as ZDMC                                --字段名称                                
                                   ,t.OLDVALUE                            as OLDVALUE                            --原值                                  
                                   ,t.NEWVALUE                            as NEWVALUE                            --新值                                  
                                   ,t.OLDNAME                             as OLDNAME                             --原值说明                                
                                   ,t.NEWNAME                             as NEWNAME                             --新值说明                                
                                   ,t.XGR                                 as XGR                                 --修改人                                 
                                   ,t.XGQD                                as XGQD                                --修改渠道                                
                                   ,t.CZMXID                              as CZMX_LSH                            --操作明细ID                              
                                   ,t.SFXS                                as SFXS                                --是否显示    
                                   ,'YGT'                                 as XTBS								   
 FROM        YGTCX.CIF_TKHZLXG t 
 WHERE       cast(t.DT AS int) IN 
  (SELECT NAT_DT FROM EDW_PROD.T_EDW_T99_TRD_DATE WHERE BUS_DATE = %d{yyyyMMdd} AND TRD_DT =  %d{yyyyMMdd});
----------------插入数据结束------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TKHZLXG',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_TKHZLXG;
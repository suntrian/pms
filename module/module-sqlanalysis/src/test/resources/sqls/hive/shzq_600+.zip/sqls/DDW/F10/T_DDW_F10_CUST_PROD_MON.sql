------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户产品月表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2019-05-15                                                                        */ 
  
  

 

------插入数据
  INSERT OVERWRITE DDW_PROD.T_DDW_F10_CUST_PROD_MON
(   CUST_NO                                         --客户号
  , PROD_SALE_VOL_010100                            --公募基金销量_股票型   
  , PROD_SALE_VOL_010200                            --公募基金销量_债券型
  , PROD_SALE_VOL_010300                            --公募基金销量_货币型
  , PROD_SALE_VOL_010500                            --公募基金销量_混合型
  , PROD_SALE_VOL_010400_010600                     --公募基金销量_其他
  , PROD_SALE_BUYIN_AMT_010100                      --公募基金买入金额_股票型   
  , PROD_SALE_BUYIN_AMT_010200                      --公募基金买入金额_债券型
  , PROD_SALE_BUYIN_AMT_010300                      --公募基金买入金额_货币型
  , PROD_SALE_BUYIN_AMT_010500                      --公募基金买入金额_混合型
  , PROD_SALE_BUYIN_AMT_010400_010600               --公募基金买入金额_其他
  , PROD_SALE_VOL_020100                            --私募基金销量_固收类
  , PROD_SALE_VOL_020200                            --私募基金销量_权益类
  , PROD_SALE_VOL_020400                            --私募基金销量_其他
  , PROD_SALE_VOL_030100                            --信托产品销量_固收类
  , PROD_SALE_VOL_030200                            --信托产品销量_权益类
  , PROD_SALE_VOL_030300_030400                     --信托产品销量_其他
  , PROD_SALE_VOL_040100                            --内部资管产品销量_大集合产品
  , PROD_SALE_VOL_040200                            --内部资管产品销量_小集合产品
  , PROD_SALE_VOL_040300                            --内部资管产品销量_定向产品
  , PROD_SALE_VOL_050100                            --银行理财产品销量 
  , PROD_SALE_VOL_060100                            --收益凭证销量_本金保障
  , PROD_SALE_VOL_060200                            --收益凭证销量_非本金保障
  , PROD_SALE_VOL_070100                            --外部资管产品销量_固收类
  , PROD_SALE_VOL_070200                            --外部资管产品销量_权益类
  , PROD_SALE_VOL_070300_070400                     --外部资管产品销量_其他
  , PROD_SALE_VOL_080100                            --基金专户销量_股票型
  , PROD_SALE_VOL_080200                            --基金专户销量_债券型
  , PROD_SALE_VOL_080300                            --基金专户销量_货币型
  , PROD_SALE_VOL_080500                            --基金专户销量_混合型
  , PROD_SALE_VOL_080400_080600                     --基金专户销量_其他
  
  ,PROD_SALE_VOL_110000                             --报价回购销量
  
  , PROD_RTAN_VOL_AVG_010100                        --公募基金日均保有量_股票型
  , PROD_RTAN_VOL_AVG_010200                        --公募基金日均保有量_债券型
  , PROD_RTAN_VOL_AVG_010300                        --公募基金日均保有量_货币型
  , PROD_RTAN_VOL_AVG_010500                        --公募基金日均保有量_混合型
  , PROD_RTAN_VOL_AVG_010400_010600                 --公募基金日均保有量_其他
  , PROD_RTAN_VOL_AVG_020100                        --私募基金日均保有量_固收类
  , PROD_RTAN_VOL_AVG_020200                        --私募基金日均保有量_权益类
  , PROD_RTAN_VOL_AVG_020400                        --私募基金日均保有量_其他
  , PROD_RTAN_VOL_AVG_030100                        --信托产品日均保有量_固收类
  , PROD_RTAN_VOL_AVG_030200                        --信托产品日均保有量_权益类
  , PROD_RTAN_VOL_AVG_030300_030400                 --信托产品日均保有量_其他
  , PROD_RTAN_VOL_AVG_040100                        --内部资管产品日均保有量_大集合产品
  , PROD_RTAN_VOL_AVG_040200                        --内部资管产品日均保有量_小集合产品
  , PROD_RTAN_VOL_AVG_040300                        --内部资管产品日均保有量_定向产品
  , PROD_RTAN_VOL_AVG_050100                        --银行理财产品日均保有量
  , PROD_RTAN_VOL_AVG_060100                        --收益凭证日均保有量_本金保障
  , PROD_RTAN_VOL_AVG_060200                        --收益凭证日均保有量_非本金保障
  , PROD_RTAN_VOL_AVG_070100                        --外部资管产品日均保有量_固收类
  , PROD_RTAN_VOL_AVG_070200                        --外部资管产品日均保有量_权益类
  , PROD_RTAN_VOL_AVG_070300_070400                 --外部资管产品日均保有量_其他
  , PROD_RTAN_VOL_AVG_080100                        --基金专户日均保有量_股票型
  , PROD_RTAN_VOL_AVG_080200                        --基金专户日均保有量_债券型
  , PROD_RTAN_VOL_AVG_080300                        --基金专户日均保有量_货币型
  , PROD_RTAN_VOL_AVG_080500                        --基金专户日均保有量_混合型
  , PROD_RTAN_VOL_AVG_080400_080600                 --基金专户日均保有量_其他
  , PROD_RTAN_VOL_AVG_CASH                          --现金添利产品日均保有量
  
  ,PROD_RTAN_VOL_AVG_110000                             --报价回购日均保有量
  
  , PROD_RTAN_VOL_FNL_010100                        --公募基金期末保有量_股票型
  , PROD_RTAN_VOL_FNL_010200                        --公募基金期末保有量_债券型
  , PROD_RTAN_VOL_FNL_010300                        --公募基金期末保有量_货币型
  , PROD_RTAN_VOL_FNL_010500                        --公募基金期末保有量_混合型
  , PROD_RTAN_VOL_FNL_010400_010600                 --公募基金期末保有量_其他
  , PROD_RTAN_VOL_FNL_020100                        --私募基金期末保有量_固收类
  , PROD_RTAN_VOL_FNL_020200                        --私募基金期末保有量_权益类
  , PROD_RTAN_VOL_FNL_020400                        --私募基金期末保有量_其他
  , PROD_RTAN_VOL_FNL_030100                        --信托产品期末保有量_固收类
  , PROD_RTAN_VOL_FNL_030200                        --信托产品期末保有量_权益类
  , PROD_RTAN_VOL_FNL_030300_030400                 --信托产品期末保有量_其他
  , PROD_RTAN_VOL_FNL_040100                        --内部资管产品期末保有量_大集合产品
  , PROD_RTAN_VOL_FNL_040200                        --内部资管产品期末保有量_小集合产品
  , PROD_RTAN_VOL_FNL_040300                        --内部资管产品期末保有量_定向产品
  , PROD_RTAN_VOL_FNL_050100                        --银行理财产品期末保有量
  , PROD_RTAN_VOL_FNL_060100                        --收益凭证期末保有量_本金保障
  , PROD_RTAN_VOL_FNL_060200                        --收益凭证期末保有量_非本金保障
  , PROD_RTAN_VOL_FNL_070100                        --外部资管产品期末保有量_固收类
  , PROD_RTAN_VOL_FNL_070200                        --外部资管产品期末保有量_权益类
  , PROD_RTAN_VOL_FNL_070300_070400                 --外部资管产品期末保有量_其他
  , PROD_RTAN_VOL_FNL_080100                        --基金专户期末保有量_股票型
  , PROD_RTAN_VOL_FNL_080200                        --基金专户期末保有量_债券型
  , PROD_RTAN_VOL_FNL_080300                        --基金专户期末保有量_货币型
  , PROD_RTAN_VOL_FNL_080500                        --基金专户期末保有量_混合型
  , PROD_RTAN_VOL_FNL_080400_080600                 --基金专户期末保有量_其他
  , PROD_RTAN_VOL_FNL_CASH                          --现金添利产品期末保有量
  
  , PROD_RTAN_VOL_FNL_110000                         --报价回购期末保有量
  , ETL_DT  
 ) PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT          
    t.CUST_NO                                         --客户号
  , SUM(DECODE(t.PROD_CL_CD,'010100',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_010100                            --公募基金销量_股票型   
  , SUM(DECODE(t.PROD_CL_CD,'010200',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_010200                            --公募基金销量_债券型
  , SUM(DECODE(t.PROD_CL_CD,'010300',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_010300                            --公募基金销量_货币型
  , SUM(DECODE(t.PROD_CL_CD,'010500',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_010500                            --公募基金销量_混合型
  , SUM(DECODE(t.PROD_CL_CD,'010400',SCRP_AMT+PRCH_AMT+FIXINV_AMT,'010600',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_010400_010600                     --公募基金销量_其他
  , SUM(DECODE(t.PROD_CL_CD,'010100',BUYIN_AMT,0)) as PROD_SALE_BUYIN_AMT_010100                      --公募基金买入金额_股票型   
  , SUM(DECODE(t.PROD_CL_CD,'010200',BUYIN_AMT,0)) as PROD_SALE_BUYIN_AMT_010200                      --公募基金买入金额_债券型
  , SUM(DECODE(t.PROD_CL_CD,'010300',BUYIN_AMT,0)) as PROD_SALE_BUYIN_AMT_010300                      --公募基金买入金额_货币型
  , SUM(DECODE(t.PROD_CL_CD,'010500',BUYIN_AMT,0)) as PROD_SALE_BUYIN_AMT_010500                      --公募基金买入金额_混合型
  , SUM(DECODE(t.PROD_CL_CD,'010400',BUYIN_AMT,'010600',BUYIN_AMT,0)) as PROD_SALE_BUYIN_AMT_010400_010600               --公募基金买入金额_其他
  , SUM(DECODE(t.PROD_CL_CD,'020100',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_020100                            --私募基金销量_固收类
  , SUM(DECODE(t.PROD_CL_CD,'020200',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_020200                            --私募基金销量_权益类
  , SUM(DECODE(t.PROD_CL_CD,'020400',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_020400                            --私募基金销量_其他
  , SUM(DECODE(t.PROD_CL_CD,'030100',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_030100                            --信托产品销量_固收类
  , SUM(DECODE(t.PROD_CL_CD,'030200',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_030200                            --信托产品销量_权益类
  , SUM(DECODE(t.PROD_CL_CD,'030300',SCRP_AMT+PRCH_AMT+FIXINV_AMT,'030400',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_030300_030400                     --信托产品销量_其他
  , SUM(DECODE(t.PROD_CL_CD,'040100',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_040100                            --内部资管产品销量_大集合产品
  , SUM(DECODE(t.PROD_CL_CD,'040200',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_040200                            --内部资管产品销量_小集合产品
  , SUM(DECODE(t.PROD_CL_CD,'040300',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_040300                            --内部资管产品销量_定向产品
  , SUM(DECODE(t.PROD_CL_CD,'050100',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_050100                            --银行理财产品销量 
  , SUM(DECODE(t.PROD_CL_CD,'060100',SCRP_AMT+PRCH_AMT+FIXINV_AMT,'100000',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_060100                            --收益凭证销量_本金保障
  , SUM(DECODE(t.PROD_CL_CD,'060200',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_060200                            --收益凭证销量_非本金保障
  , SUM(DECODE(t.PROD_CL_CD,'070100',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_070100                            --外部资管产品销量_固收类
  , SUM(DECODE(t.PROD_CL_CD,'070200',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_070200                            --外部资管产品销量_权益类
  , SUM(DECODE(t.PROD_CL_CD,'070300',SCRP_AMT+PRCH_AMT+FIXINV_AMT,'070400',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_070300_070400                     --外部资管产品销量_其他
  , SUM(DECODE(t.PROD_CL_CD,'080100',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_080100                            --基金专户销量_股票型
  , SUM(DECODE(t.PROD_CL_CD,'080200',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_080200                            --基金专户销量_债券型
  , SUM(DECODE(t.PROD_CL_CD,'080300',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_080300                            --基金专户销量_货币型
  , SUM(DECODE(t.PROD_CL_CD,'080500',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_080500                            --基金专户销量_混合型
  , SUM(DECODE(t.PROD_CL_CD,'080400',SCRP_AMT+PRCH_AMT+FIXINV_AMT,'080600',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_080400_080600                     --基金专户销量_其他
  , SUM(DECODE(t.PROD_CL_CD,'110000',SCRP_AMT+PRCH_AMT+FIXINV_AMT,0)) as PROD_SALE_VOL_110000                             --报价回购销量
  
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'010100',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_010100                        --公募基金日均保有量_股票型
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'010200',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_010200                        --公募基金日均保有量_债券型
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'010300',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_010300                        --公募基金日均保有量_货币型
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'010500',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_010500                        --公募基金日均保有量_混合型
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'010400',HLD_AMT*1.0000/a1.NUM,'010600',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_010400_010600                 --公募基金日均保有量_其他
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'020100',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_020100                        --私募基金日均保有量_固收类
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'020200',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_020200                        --私募基金日均保有量_权益类
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'020400',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_020400                        --私募基金日均保有量_其他
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'030100',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_030100                        --信托产品日均保有量_固收类
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'030200',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_030200                        --信托产品日均保有量_权益类
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'030300',HLD_AMT*1.0000/a1.NUM,'030400',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_030300_030400                 --信托产品日均保有量_其他
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'040100',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_040100                        --内部资管产品日均保有量_大集合产品
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'040200',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_040200                        --内部资管产品日均保有量_小集合产品
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'040300',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_040300                        --内部资管产品日均保有量_定向产品
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'050100',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_050100                        --银行理财产品日均保有量
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'060100',HLD_AMT*1.0000/a1.NUM,'100000',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_060100                        --收益凭证日均保有量_本金保障
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'060200',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_060200                        --收益凭证日均保有量_非本金保障
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'070100',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_070100                        --外部资管产品日均保有量_固收类
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'070200',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_070200                        --外部资管产品日均保有量_权益类
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'070300',HLD_AMT*1.0000/a1.NUM,'070400',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_070300_070400                 --外部资管产品日均保有量_其他
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'080100',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_080100                        --基金专户日均保有量_股票型
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'080200',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_080200                        --基金专户日均保有量_债券型
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'080300',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_080300                        --基金专户日均保有量_货币型
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'080500',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_080500                        --基金专户日均保有量_混合型
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'080400',HLD_AMT*1.0000/a1.NUM,'080600',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_080400_080600                 --基金专户日均保有量_其他
  , SUM(ROUND(DECODE(t.PROD_CD,'A30003',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_CASH                          --现金添利产品日均保有量
  , SUM(ROUND(DECODE(t.PROD_CL_CD,'110000',HLD_AMT*1.0000/a1.NUM,0),2)) AS PROD_RTAN_VOL_AVG_110000                             --报价回购日均保有量
  
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '010100'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_010100                        --公募基金期末保有量_股票型
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '010200'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_010200                        --公募基金期末保有量_债券型
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '010300'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_010300                        --公募基金期末保有量_货币型
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '010500'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_010500                        --公募基金期末保有量_混合型
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD IN ('010600','010400')
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_010400_010600                 --公募基金期末保有量_其他
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '020100'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_020100                        --私募基金期末保有量_固收类
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '020200'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_020200                        --私募基金期末保有量_权益类
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '020400'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_020400                        --私募基金期末保有量_其他
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '030100'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_030100                        --信托产品期末保有量_固收类
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '030200'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_030200                        --信托产品期末保有量_权益类
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD IN ('030300','030400')
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_030300_030400                 --信托产品期末保有量_其他
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '040100'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_040100                        --内部资管产品期末保有量_大集合产品
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '040200'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_040200                        --内部资管产品期末保有量_小集合产品
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '040300'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_040300                        --内部资管产品期末保有量_定向产品
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '050100'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_050100                        --银行理财产品期末保有量
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '060100'
			 THEN HLD_AMT
			 WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '100000'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_060100                        --收益凭证期末保有量_本金保障
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '060200'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_060200                        --收益凭证期末保有量_非本金保障
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '070100'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_070100                        --外部资管产品期末保有量_固收类
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '070200'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_070200                        --外部资管产品期末保有量_权益类
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD IN ('070300','070400')
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_070300_070400                 --外部资管产品期末保有量_其他
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '080100'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_080100                        --基金专户期末保有量_股票型
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '080200'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_080200                        --基金专户期末保有量_债券型
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '080300'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_080300                        --基金专户期末保有量_货币型
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '080500'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_080500                        --基金专户期末保有量_混合型
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD IN ('080400','080600')
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_080400_080600                 --基金专户期末保有量_其他	  
   , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CD = 'A30003'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_CASH                          --现金添利产品期末保有量
  , SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd} 
             AND  t.PROD_CL_CD = '110000'
		     THEN HLD_AMT
		     ELSE 0
		     END
		) PROD_RTAN_VOL_FNL_110000                         --报价回购期末保有量
		
		
 , %d{yyyyMMdd} as ETL_DT
 FROM       (SELECT 1 AS ID,* FROM DDW_PROD.T_DDW_F10_CUST_PROD_DAY WHERE   SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) )               t 
 LEFT JOIN  (SELECT 1 as ID,COUNT(1) as NUM FROM  EDW_PROD.T_EDW_T99_TRD_DATE WHERE BUS_DATE = %d{yyyyMMdd} AND SUBSTR(CAST(NAT_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)) a1
 ON          t.ID = a1.ID 
 GROUP BY t.CUST_NO
 ;
 


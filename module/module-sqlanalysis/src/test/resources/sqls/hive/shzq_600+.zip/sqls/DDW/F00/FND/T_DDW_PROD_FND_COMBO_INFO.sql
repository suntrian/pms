------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:组合基金关联关系表                                                                    */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2018-11-26                                                                        */ 

INSERT OVERWRITE DDW_PROD.T_DDW_PROD_FND_COMBO_INFO
(
                  GROUP_ID          
				 ,GROUP_NM          
				 ,BUILD_DT          
				 ,RCOMD_RSN         
				 ,STATUS            
				 ,GROUP_NAV_DT      
				 ,GROUP_NAV         
				 ,GROUP_NAV_RS_DWN_D
				 ,YLD_RATE_ANULZ    
				 ,MAX_RETRACE       
				 ,FLUC_RATIO_ANULZ  
				 ,SHARP_RATIO       
				 ,RSK_ID            
				 ,RSK_NM            
				 ,FLUIDITY_ID       
				 ,FLUIDITY_NM       
) PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT       
                 T.GROUP_ID                                          AS GROUP_ID          
			    ,T.GROUP_NAME                                        AS GROUP_NM          
				,T.BUILD_DATE                                        AS BUILD_DT          
				,T.RECOMMEND_REASON                                  AS RCOMD_RSN         
				,T.STATUS                                            AS STATUS            
				,CAST(T1.GROUP_NV AS STRING)                         AS GROUP_NAV_DT      
				,CAST(T1.GROUP_NV_DAILY_GROWTH AS DECIMAL(38,6))     AS GROUP_NAV         
				,T1.BUS_DATE                                         AS GROUP_NAV_RS_DWN_D
				,CAST(T2.ANNUAL_PROFIT_RATE AS DECIMAL(38,6))        AS YLD_RATE_ANULZ    
				,CAST(T3.MAX_RETRACE AS DECIMAL(38,6))               AS MAX_RETRACE       
				,CAST(T4.FLUC_RATIO AS DECIMAL(38,6))                AS FLUC_RATIO_ANULZ  
				,CAST(T5.SHARP_RATIO AS DECIMAL(38,6))               AS SHARP_RATIO       
				,T6.RISK_PREFER                                      AS RSK_ID            
				,T7.NAME                                             AS RSK_NM            
				,T8.FLUIDITY_PREFER                                  AS FLUIDITY_ID       
				,T9.NAME                                             AS FLUIDITY_NM       
FROM        EDW_PROD.T_EDW_T04_GROUP_INFO         T
LEFT JOIN   (
             SELECT GROUP_ID,GROUP_NV,GROUP_NV_DAILY_GROWTH,BUS_DATE
             FROM EDW_PROD.T_EDW_T04_GROUP_NV
			 WHERE BUS_DATE = %d{yyyyMMdd}
             GROUP BY GROUP_ID,GROUP_NV,GROUP_NV_DAILY_GROWTH,BUS_DATE
            )T1
ON          T.GROUP_ID = T1.GROUP_ID
AND         T.BUS_DATE = T1.BUS_DATE
LEFT JOIN   (
             SELECT GROUP_ID,ANNUAL_PROFIT_RATE,BUS_DATE
             FROM EDW_PROD.T_EDW_T04_GROUP_ANNUAL_PROFIT_RATE
			 WHERE BUS_DATE = %d{yyyyMMdd}
             GROUP BY GROUP_ID,ANNUAL_PROFIT_RATE,BUS_DATE
            )T2
ON          T.GROUP_ID = T2.GROUP_ID
AND         T.BUS_DATE = T2.BUS_DATE
LEFT JOIN   (
             SELECT GROUP_ID,MAX_RETRACE,BUS_DATE
             FROM EDW_PROD.T_EDW_T04_GROUP_MAX_RETRACE
			 WHERE BUS_DATE = %d{yyyyMMdd}
             GROUP BY GROUP_ID,MAX_RETRACE,BUS_DATE
            )T3
ON          T.GROUP_ID = T3.GROUP_ID
AND         T.BUS_DATE = T3.BUS_DATE
LEFT JOIN   (
             SELECT GROUP_ID,FLUC_RATIO,BUS_DATE
             FROM EDW_PROD.T_EDW_T04_GROUP_FLUC_RATIO
			 WHERE BUS_DATE = %d{yyyyMMdd}
             GROUP BY GROUP_ID,FLUC_RATIO,BUS_DATE
            )T4
ON          T.GROUP_ID = T4.GROUP_ID
AND         T.BUS_DATE = T4.BUS_DATE
LEFT JOIN   (
             SELECT GROUP_ID,SHARP_RATIO,BUS_DATE
             FROM EDW_PROD.T_EDW_T04_GROUP_SHARP_RATIO
			 WHERE BUS_DATE = %d{yyyyMMdd}
             GROUP BY GROUP_ID,SHARP_RATIO,BUS_DATE
            )T5
ON          T.GROUP_ID = T5.GROUP_ID
AND         T.BUS_DATE = T5.BUS_DATE
LEFT JOIN   (
             SELECT GROUP_ID,group_concat(cast(RISK_PREFER as string),';') as RISK_PREFER,BUS_DATE 
			 FROM(
			 SELECT DISTINCT GROUP_ID,RISK_PREFER,BUS_DATE
             FROM EDW_PROD.T_EDW_T04_GROUP_TAG_REL
			 )A
             GROUP BY GROUP_ID,BUS_DATE
            )T6
ON          T.GROUP_ID = T6.GROUP_ID
AND         T.BUS_DATE = T6.BUS_DATE
LEFT JOIN   EDW_PROD.T_EDW_T04_RISK_PREFER T7
ON          T6.RISK_PREFER     = CAST(T7.ID AS STRING)
AND         T6.BUS_DATE        = T7.BUS_DATE
LEFT JOIN   (
             SELECT GROUP_ID,group_concat(cast(FLUIDITY_PREFER as string),';') as FLUIDITY_PREFER,BUS_DATE 
			 FROM(
			 SELECT DISTINCT GROUP_ID,FLUIDITY_PREFER,BUS_DATE
             FROM EDW_PROD.T_EDW_T04_GROUP_TAG_REL
			 )A
             GROUP BY GROUP_ID,BUS_DATE
            )T8
ON          T.GROUP_ID = T8.GROUP_ID
AND         T.BUS_DATE = T8.BUS_DATE
LEFT JOIN   (SELECT A.GROUP_ID,group_concat(B.NAME,';') AS NAME,A.BUS_DATE 
             FROM EDW_PROD.T_EDW_T04_GROUP_TAG_REL A
			 LEFT JOIN EDW_PROD.T_EDW_T04_FLUIDITY_PREFER B
			 ON A.FLUIDITY_PREFER = B.ID
			 AND A.BUS_DATE = B.BUS_DATE
			 GROUP BY A.GROUP_ID,A.BUS_DATE) T9
ON          T.GROUP_ID = T9.GROUP_ID
AND         T.BUS_DATE = T9.BUS_DATE
WHERE T.BUS_DATE = %d{yyyyMMdd}
;
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PROD_FND_COMBO_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PROD_FND_COMBO_INFO ;
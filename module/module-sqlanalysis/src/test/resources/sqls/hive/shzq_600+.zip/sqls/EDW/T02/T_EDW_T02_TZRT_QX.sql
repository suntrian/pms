 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:转融通期限表                                                                       */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
    TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZRT_QX; 
--------插入数据开始------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZRT_QX(
                                    ZRT_YWLX                              --转融通业务类型                       
                                   ,QX                                    --期限                            
                                   ,BZRRFL                                --标准融入费率                        
                                   ,BZRCFL                                --标准融出费率                        
                                   ,ZQBZ                                  --展期标志                          
                                   ,SHBZ                                  --审核标志                          
                                   ,JYRQ                                  --交易日期                          
                                   ,FDFL                                  --浮动利率                          
                                   ,TQGHLL                                --提前归还利率 
                                   ,DBSX    							  --单笔委托最大值
                                   ,DBXX                                  --单笔委托最小值
                                   ,FXLL                                  --罚息利率   
                                   ,KZSX                                  --控制属性   
                                   ,XTBS  


) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.YWLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as ZRT_YWLX                              --转融通业务类型                                
                                   ,t.QX                                    as QX                                    --期限                                     
                                   ,t.BZRRFL                                as BZRRFL                                --标准融入费率                                 
                                   ,t.BZRCFL                                as BZRCFL                                --标准融出费率                                 
                                   ,t.ZQBZ                                  as ZQBZ                                  --展期标志                                   
                                   ,t.SHBZ                                  as SHBZ                                  --审核标志                                   
                                   ,t.JYRQ                                  as JYRQ                                  --交易日期                                   
                                   ,t.FDFL                                  as FDFL                                  --浮动利率                                   
                                   ,t.TQGHLL                                as TQGHLL                                --提前归还利率       
                                   ,t.DBSX                                  as DBSX    							                --单笔委托最大值       
                                   ,t.DBXX                                  as DBXX                                  --单笔委托最小值      
                                   ,t.FXLL                                  as FXLL                                  --罚息利率         
                                   ,t.KZSX                                  as KZSX                                  --控制属性         
                                   ,'RZRQ'                                  as XTBS                                                 

 FROM           RZRQCX.ZRT_TZRT_QX                       t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING   t1 
 ON             t1.DMLX = 'ZRT_YWLX'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.YWLX AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
-------插入数据结束--------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZRT_QX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TZRT_QX;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:历史柜员日志表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
-----------------------------------删除今天的数据--------------------
 ALTER TABLE EDW_PROD.T_EDW_T05_TGYRZLS DROP IF EXISTS PARTITION   (BUS_DATE = %d{yyyyMMdd});
----------------------------------删除今天的数据结束-----------------------
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TGYRZLS_TEMP ;
 CREATE TABLE  EDW_PROD.T_EDW_T05_TGYRZLS_TEMP AS
 SELECT SEQNO        as SEQNO    
       ,LSH          as LSH      
	   ,RQ           as RQ       
	   ,FSSJ         as FSSJ     
	   ,LOGINID      as LOGINID  
	   ,DLSF         as DLSF     
	   ,YWKM         as YWKM     
	   ,ZY           as ZY       
	   ,FSYYB        as FSYYB    
	   ,CZZD         as CZZD     
 FROM JZJYCX.DATACENTER_TGYRZLS 
 WHERE DT = '%d{yyyyMMdd}'
 AND    RQ < = %d{yyyyMMdd}
 UNION ALL  
 SELECT NULL         as SEQNO    
       ,LSH          as LSH      
	   ,RQ           as RQ       
	   ,FSSJ         as FSSJ     
	   ,LOGINID      as LOGINID  
	   ,DLSF         as DLSF     
	   ,YWKM         as YWKM     
	   ,ZY           as ZY       
	   ,FSYYB        as FSYYB    
	   ,CZZD         as CZZD     
 FROM JZJYCX.ABOSS_TGYRZ  T
 INNER JOIN (SELECT MAX(TRD_DT) as TRD_DT,MIN(NAT_DT) AS NAT_DT,MAX(NAT_DT) AS NAT_DT1  
             FROM  EDW_PROD.T_EDW_T99_TRD_DATE
			 WHERE ((TRD_DT = %d{yyyyMMdd} AND NAT_DT = TRD_DT)  OR (NXTM_TRD_D =  %d{yyyyMMdd} AND NAT_DT < > TRD_DT))
			 AND   BUS_DATE = %d{yyyyMMdd} 
			 ) A1
   ON         t.RQ > = a1.NAT_DT  
  AND        t.RQ < = a1.NAT_DT1         
  WHERE  T.DT = '%d{yyyyMMdd}'
  AND    t.DT IN (SELECT MAX(DT) AS DT FROM JZJYCX.ABOSS_TGYRZ)  ;
  
   DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TGYRZLS_TEMP1 ;
 CREATE TABLE  EDW_PROD.T_EDW_T05_TGYRZLS_TEMP1 AS
 SELECT SEQNO        as SEQNO    
       ,LSH          as LSH      
	   ,RQ           as RQ       
	   ,FSSJ         as FSSJ     
	   ,LOGINID      as LOGINID  
	   ,DLSF         as DLSF     
	   ,YWKM         as YWKM     
	   ,ZY           as ZY       
	   ,FSYYB        as FSYYB    
	   ,CZZD         as CZZD     
 FROM GGQQCX.DATACENTER_TGYRZLS 
 WHERE  DT = '%d{yyyyMMdd}'
 AND    RQ < = %d{yyyyMMdd}
 UNION ALL  
 SELECT NULL         as SEQNO    
       ,LSH          as LSH      
	   ,RQ           as RQ       
	   ,FSSJ         as FSSJ     
	   ,LOGINID      as LOGINID  
	   ,DLSF         as DLSF     
	   ,YWKM         as YWKM     
	   ,ZY           as ZY       
	   ,FSYYB        as FSYYB    
	   ,CZZD         as CZZD     
 FROM GGQQCX.ABOSS_TGYRZ  T
 INNER JOIN (SELECT MAX(TRD_DT) as TRD_DT,MIN(NAT_DT) AS NAT_DT,MAX(NAT_DT) AS NAT_DT1  
             FROM  EDW_PROD.T_EDW_T99_TRD_DATE
			 WHERE ((TRD_DT = %d{yyyyMMdd} AND NAT_DT = TRD_DT)  OR (NXTM_TRD_D =  %d{yyyyMMdd} AND NAT_DT < > TRD_DT))
			 AND   BUS_DATE = %d{yyyyMMdd}
			 ) A1
   ON         t.RQ > = a1.NAT_DT  
  AND        t.RQ < = a1.NAT_DT1         
  WHERE  T.DT = '%d{yyyyMMdd}'
  AND    t.DT IN (SELECT MAX(DT) AS DT FROM GGQQCX.ABOSS_TGYRZ)    
 ;
 
  DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TGYRZLS_TEMP2 ;
 CREATE TABLE  EDW_PROD.T_EDW_T05_TGYRZLS_TEMP2 AS 
 SELECT SEQNO        as SEQNO    
       ,LSH          as LSH      
	   ,RQ           as RQ       
	   ,FSSJ         as FSSJ     
	   ,LOGINID      as LOGINID  
	   ,DLSF         as DLSF     
	   ,YWKM         as YWKM     
	   ,ZY           as ZY       
	   ,FSYYB        as FSYYB    
	   ,CZZD         as CZZD     
 FROM RZRQCX.DATACENTER_TGYRZLS 
 WHERE  DT = '%d{yyyyMMdd}'
 AND    RQ < = %d{yyyyMMdd}
 UNION ALL  
 SELECT NULL         as SEQNO    
       ,LSH          as LSH      
	   ,RQ           as RQ       
	   ,FSSJ         as FSSJ     
	   ,LOGINID      as LOGINID  
	   ,DLSF         as DLSF     
	   ,YWKM         as YWKM     
	   ,ZY           as ZY       
	   ,FSYYB        as FSYYB    
	   ,CZZD         as CZZD     
 FROM RZRQCX.ABOSS_TGYRZ  T
 INNER JOIN (SELECT MAX(TRD_DT) as TRD_DT,MIN(NAT_DT) AS NAT_DT,MAX(NAT_DT) AS NAT_DT1  
             FROM  EDW_PROD.T_EDW_T99_TRD_DATE
			 WHERE ((TRD_DT = %d{yyyyMMdd} AND NAT_DT = TRD_DT)  OR (NXTM_TRD_D =  %d{yyyyMMdd} AND NAT_DT < > TRD_DT))
			 AND   BUS_DATE = %d{yyyyMMdd}
			 ) a1
  ON         t.RQ > = a1.NAT_DT  
  AND        t.RQ < = a1.NAT_DT1  
  WHERE  T.DT = '%d{yyyyMMdd}'
  AND    t.DT IN (SELECT MAX(DT) AS DT FROM RZRQCX.ABOSS_TGYRZ)
 ;



---------------- 插入集中交易数据 -----------------------
INSERT  INTO  EDW_PROD.T_EDW_T05_TGYRZLS(
                                     SEQNO                               --事件序号                               
                                   ,LSH                                 --流水号                                
                                   ,RQ                                  --日期                                 
                                   ,FSSJ                                --发生时间                               
                                   ,LOGINID                             --登陆ID                               
                                   ,DLSF                                --登陆身份                               
                                   ,YWKM                                --业务科目                               
                                   ,ZY                                  --摘要                                 
                                   ,FSYYB                               --发生营业部                              
                                   ,CZZD                                --操作站点                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.SEQNO                               as SEQNO                               --序号                                  
                                   ,t.LSH                                 as LSH                                 --流水号                                 
                                   ,t.RQ                                  as RQ                                  --日期                                  
                                   ,t.FSSJ                                as FSSJ                                --发生时间                                
                                   ,t.LOGINID                             as LOGINID                             --登陆ID                                
                                   ,t.DLSF                                as DLSF                                --登陆身份                                
                                   ,t.YWKM                                as YWKM                                --业务科目                                
                                   ,t.ZY                                  as ZY                                  --摘要                                  
                                   ,t.FSYYB                              as FSYYB                               --发生营业部                               
                                   ,t.CZZD                                as CZZD                                --操作站点                                
                                   ,'JZJY'                                as XTBS                                --                                    
 FROM          EDW_PROD.T_EDW_T05_TGYRZLS_TEMP t
  ;
	
	-----------------------插入集中交易数据结束--------------------------
	
	----------------------插入个股期权数据开始-------------------------------
INSERT  INTO  EDW_PROD.T_EDW_T05_TGYRZLS(
                                     SEQNO                               --事件序号                               
                                   ,LSH                                 --流水号                                
                                   ,RQ                                  --日期                                 
                                   ,FSSJ                                --发生时间                               
                                   ,LOGINID                             --登陆ID                               
                                   ,DLSF                                --登陆身份                               
                                   ,YWKM                                --业务科目                               
                                   ,ZY                                  --摘要                                 
                                   ,FSYYB                               --发生营业部                              
                                   ,CZZD                                --操作站点                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.SEQNO                               as SEQNO                               --序号                                  
                                   ,t.LSH                                 as LSH                                 --流水号                                 
                                   ,t.RQ                                  as RQ                                  --日期                                  
                                   ,t.FSSJ                                as FSSJ                                --发生时间                                
                                   ,t.LOGINID                             as LOGINID                             --登陆ID                                
                                   ,t.DLSF                                as DLSF                                --登陆身份                                
                                   ,t.YWKM                                as YWKM                                --业务科目                                
                                   ,t.ZY                                  as ZY                                  --摘要                                  
                                   ,t.FSYYB                              as FSYYB                               --发生营业部                               
                                   ,t.CZZD                                as CZZD                                --操作站点                                
                                   ,'GGQQ'                               as XTBS                                --                                    
 FROM          EDW_PROD.T_EDW_T05_TGYRZLS_TEMP1 t ;
	-------------------------------插入个股期权数据结束-------------------------------
	-------------------------------插入融资融券数据开始-----------------------------
INSERT  INTO  EDW_PROD.T_EDW_T05_TGYRZLS(
                                     SEQNO                               --事件序号                               
                                   ,LSH                                 --流水号                                
                                   ,RQ                                  --日期                                 
                                   ,FSSJ                                --发生时间                               
                                   ,LOGINID                             --登陆ID                               
                                   ,DLSF                                --登陆身份                               
                                   ,YWKM                                --业务科目                               
                                   ,ZY                                  --摘要                                 
                                   ,FSYYB                               --发生营业部                              
                                   ,CZZD                                --操作站点                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.SEQNO                               as SEQNO                               --序号                                  
                                   ,t.LSH                                 as LSH                                 --流水号                                 
                                   ,t.RQ                                  as RQ                                  --日期                                  
                                   ,t.FSSJ                                as FSSJ                                --发生时间                                
                                   ,t.LOGINID                             as LOGINID                             --登陆ID                                
                                   ,t.DLSF                                as DLSF                                --登陆身份                                
                                   ,t.YWKM                                as YWKM                                --业务科目                                
                                   ,t.ZY                                  as ZY                                  --摘要                                  
                                   ,t.FSYYB                               as FSYYB                               --发生营业部                               
                                   ,t.CZZD                                as CZZD                                --操作站点                                
                                   ,'RZRQ'                                as XTBS                                --                                    
  FROM          EDW_PROD.T_EDW_T05_TGYRZLS_TEMP2 t  ;
---------------- 插入融资融券数据结束-----------------------
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TGYRZLS_TEMP ;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TGYRZLS_TEMP1 ;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TGYRZLS_TEMP2 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TGYRZLS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_TGYRZLS;
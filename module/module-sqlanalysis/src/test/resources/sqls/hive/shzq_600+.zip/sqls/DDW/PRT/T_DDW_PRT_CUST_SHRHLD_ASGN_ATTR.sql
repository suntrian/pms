 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:客户股东指定属性表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2019-02-13                                                                        */ 
  
  TRUNCATE TABLE DDW_PROD.T_DDW_PRT_CUST_SHRHLD_ASGN_ATTR ;
  ---创建临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_SHRHLD_ASGN_ATTR_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_PRT_CUST_SHRHLD_ASGN_ATTR_TEMP  AS 
SELECT t.CUST_NO,a2.ORDI_OPNAC_DT,GROUP_CONCAT(CAST(t.SHRHLD_ASGN_ATTR as STRING),',') as SHRHLD_ASGN_ATTR
FROM (SELECT DISTINCT CUST_NO,SHRHLD_ASGN_ATTR,BRH_NO 
      FROM DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO 
	  WHERE BUS_DATE = %d{yyyyMMdd}  
	  AND EXG = 'SH' 
	  AND SHRHLD_NO NOT LIKE 'F%'
	  AND SHRHLD_NO NOT LIKE 'E%'
	  ORDER BY CUST_NO,SHRHLD_ASGN_ATTR
	  ) t 
INNER JOIN  DDW_PROD.T_DDW_INR_ORG_BRH     a1
ON          t.BRH_NO = a1.BRH_NO
AND         a1.BUS_DATE = %d{yyyyMMdd}
INNER JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO    a2
ON         t.CUST_NO = a2.CUST_NO 
AND        a2.BUS_DATE =  %d{yyyyMMdd}
GROUP BY  t.CUST_NO,a2.ORDI_OPNAC_DT ;

INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CUST_SHRHLD_ASGN_ATTR
(
                                     CUST_NO                                 --客户号                                                                  
								    ,ORDI_OPNAC_DT                           --开户日期  
                                    ,SHRHLD_ASGN_ATTR                        --股东指定属性								
) 
 PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT                              CUST_NO                                 --客户号                                                                  
								    ,ORDI_OPNAC_DT                           --开户日期  
                                    ,SHRHLD_ASGN_ATTR                        --股东指定属性	
 FROM DDW_PROD.T_DDW_PRT_CUST_SHRHLD_ASGN_ATTR_TEMP 
 ;
 --删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_SHRHLD_ASGN_ATTR_TEMP ;
 
 ---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_DDW_PRT_CUST_SHRHLD_ASGN_ATTR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 
    invalidate metadata DDW_PROD.T_DDW_PRT_CUST_SHRHLD_ASGN_ATTR ;
 
--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:国债代保管派息表                                                                     */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T05_TGZDBGPL ;
------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T05_TGZDBGPL
(
                                    DBGBH                               --代保管编号                              
                                   ,GZPLLX                              --国债派利类型                             
                                   ,NBDM                                --内部代码                               
                                   ,NF                                  --年份                                 
                                   ,ZJZH                                --柜台资金账号                             
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,SFZH                                --身份证号                               
                                   ,DBGME                               --代保管面额                              
                                   ,DQBX                                --到期本息                               
                                   ,DBGRQ                               --代保管日期                              
                                   ,DFRQ                                --兑付日期                               
                                   ,DQRQ                                --到期日期                               
                                   ,DFJE                                --兑付金额                               
                                   ,DFLL                                --兑付利率                               
                                   ,DFLX                                --兑付利息                               
                                   ,S1                                  --佣金                                 
                                   ,YHS                                 --印花税                                
                                   ,DBGGY                               --代保管柜员                              
                                   ,DFGY                                --兑付柜员                               
                                   ,DBGYYB                              --代保管营业部                             
                                   ,DFYYB                               --兑付营业部                              
                                   ,DBGZT                               --国债代保管状态                            
                                   ,GSRQ                                --GSRQ                               
                                   ,ZY                                  --摘要                                 
                                   ,S3                                  --过户费                                
                                   ,S4                                  --附加费                                
                                   ,LXSL                                --利息税率                               
                                   ,LXS                                 --利息税                                
                                   ,ZQMC                                --证券名称                               
                                   ,GSSJ                                --GSSJ                               
                                   ,DBGSJ                               --代保管时间                              
                                   ,DFSJ                                --兑付时间                               
                                   ,PLSJ                                --派利时间                               
                                   ,PLRQ                                --派利日期                               
                                   ,CB1                                 --CB1                                
                                   ,LSH                                 --流水号   
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.DBGBH                               as DBGBH                               --代保管编号                               
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.PLLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as GZPLLX                              --派利类型                                
                                   ,t.NBDM                                as NBDM                                --内部代码                                
                                   ,t.NF                                  as NF                                  --年份                                  
                                   ,t.ZJZH                                as ZJZH                                --资金账号                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.SFZH                                as SFZH                                --身份证号                                
                                   ,t.DBGME                               as DBGME                               --代保管面额                               
                                   ,t.DQBX                                as DQBX                                --到期本息                                
                                   ,t.DBGRQ                               as DBGRQ                               --代保管日期                               
                                   ,t.DFRQ                                as DFRQ                                --兑付日期                                
                                   ,t.DQRQ                                as DQRQ                                --到期日期                                
                                   ,t.DFJE                                as DFJE                                --兑付金额                                
                                   ,t.DFLL                                as DFLL                                --兑付利率                                
                                   ,t.DFLX                                as DFLX                                --兑付利息                                
                                   ,t.S1                                  as S1                                  --佣金                                  
                                   ,t.S2                                  as YHS                                 --印花税                                 
                                   ,t.DBGGY                               as DBGGY                               --代保管柜员                               
                                   ,t.DFGY                                as DFGY                                --兑付柜员                                
                                   ,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.DBGYYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                              as DBGYYB                              --代保管营业部                              
                                   ,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.DFYYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                               as DFYYB                               --兑付营业部                               
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                    as DBGZT                               --状态                                  
                                   ,t.GSRQ                                as GSRQ                                --GSRQ                                
                                   ,t.ZY                                  as ZY                                  --摘要                                  
                                   ,t.S3                                  as S3                                  --过户费                                 
                                   ,t.S4                                  as S4                                  --附加费                                 
                                   ,t.LXSL                                as LXSL                                --利息税率                                
                                   ,t.LXS                                 as LXS                                 --利息税                                 
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.GSSJ                                as GSSJ                                --                                    
                                   ,t.DBGSJ                               as DBGSJ                               --代保管时间                               
                                   ,t.DFSJ                                as DFSJ                                --兑付时间                                
                                   ,t.PLSJ                                as PLSJ                                --派利时间                                
                                   ,t.PLRQ                                as PLRQ                                --派利日期                                
                                   ,t.CB1                                 as CB1                                 --                                    
                                   ,t.LSH                                 as LSH                                 --流水号  
								   ,'JZJY'                                as XTBS								   
 FROM  			JZJYCX.SECURITIES_TGZDBGPL 						t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t1
 ON             t1.DMLX = 'GZPLLX'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.PLLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t2
 ON             t2.DMLX = 'DBGZT'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.ZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING             t3
 ON             t3.YXT = 'JZJY'
 AND            t3.JGDM = CAST(t.DBGYYB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING             t4
 ON             t4.YXT = 'JZJY'
 AND            t4.JGDM = CAST(t.DFYYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';


---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TGZDBGPL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_TGZDBGPL;
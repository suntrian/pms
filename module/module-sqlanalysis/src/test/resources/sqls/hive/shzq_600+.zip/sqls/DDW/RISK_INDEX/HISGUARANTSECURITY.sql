------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:担保证券集中度                                                                      */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2017-12-29                                                                        */ 
DROP TABLE IF EXISTS RISK_INDEX.HISGUARANTSECURITY_TEMP0 ;
   CREATE TABLE RISK_INDEX.HISGUARANTSECURITY_TEMP0    as
   SELECT       b.SECUCODE                              as ZQDM
                ,DECODE(b.secumarket,83,'SH',90,'SZ')   as JYS
		        ,a.onlinepuboffcode                     as SGDM
				,a.PREFALTCODEH                         as PZDM	
                ,CAST(CONCAt(substr(OnLinePubOffDate,1,4),substr(OnLinePubOffDate,6,2),substr(OnLinePubOffDate,9,2) ) as INT)  as SWSGRQ 
                ,c.SSRQ                   as SSRQ
                ,c.TSRQ	             as TSRQ			
   FROM        FUNDEXT.DBO_BOND_CONBDISSUE    a
   LEFT JOIN   FUNDEXT.DBO_BOND_CODE          b
   ON          a.INNERCODE = b.INNERCODE
   AND         b.DT = '%d{yyyyMMdd}'
   LEFT JOIN   EDW_PROD.T_EDW_T04_TSZQDM  c
   ON          b.SECUCODE = c.ZQDM
   AND         DECODE(b.secumarket,83,'SH',90,'SZ') = c.JYS
   AND         c.BUS_DATE = %d{yyyyMMdd}  
   WHERE       a.DT = '%d{yyyyMMdd}'
   AND         (CONCAt(substr(onlinepuboffdate,1,4),substr(onlinepuboffdate,6,2),substr(onlinepuboffdate,9,2) ) > '20140101'
				OR CONCAt(substr(prefaltpaystartdateh,1,4),substr(prefaltpaystartdateh,6,2),substr(prefaltpaystartdateh,9,2) ) > '20140101'
				)
   AND        b.secumarket IN (83,90);

-------创建债券认购的转换代码   
   DROP TABLE IF EXISTS RISK_INDEX.HISGUARANTSECURITY_TEMP1;
   CREATE TABLE RISK_INDEX.HISGUARANTSECURITY_TEMP1					
   as  SELECT        b.SECUCode                            as ZQDM
                    ,DECODE(b.secumarket,83,'SH',90,'SZ')  as JYS
		            ,a.ApplyCodeOnline                        as RGDM		 
                    ,CAST(CONCAt(substr(a.issuestardate,1,4),substr(a.issuestardate,6,2),substr(a.issuestardate,9,2) ) as INT)   as QSRQ                   						  						  
                    ,CAST(CONCAt(substr(a.IssueEndDate,1,4),substr(a.IssueEndDate,6,2),substr(a.IssueEndDate,9,2) ) as INT)   as JZRQ 
					,c.SSRQ                  as SSRQ
                    ,c.TSRQ  	             as TSRQ	
	   FROM        FUNDEXT.DBO_Bond_Issue          a
       LEFT JOIN   fundext.dbo_BOND_CODE           b
       ON          a.INNERCODE = b.INNERCODE
       AND         b.DT = '%d{yyyyMMdd}'
	   LEFT JOIN   EDW_PROD.T_EDW_T04_TSZQDM  c
       ON          b.SECUCODE = c.ZQDM
       AND         DECODE(b.secumarket,83,'SH',90,'SZ') = c.JYS
       AND         c.BUS_DATE = %d{yyyyMMdd} 
	WHERE  CAST(CONCAt(substr(a.issuestardate,1,4),substr(a.issuestardate,6,2),substr(a.issuestardate,9,2) ) as INT) > = 20140101
    AND    b.secumarket IN (83,90)
    AND	   a.DT = '%d{yyyyMMdd}'
	;
	
   DROP TABLE IF EXISTS RISK_INDEX.HISGUARANTSECURITY_TEMP2;
   CREATE TABLE RISK_INDEX.HISGUARANTSECURITY_TEMP2
       AS SELECT CASE WHEN b.ExApplyingCode IS NOT NULL
			          THEN b.SecurityCode  
	                  WHEN a5.ZQDM IS NOT NULL
				      THEN a5.ZQDM
				      WHEN a6.ZQDM IS NOT NULL
				      THEN a6.ZQDM
				      ELSE EDW_PROD.CODE_TRANS_ZQDM(DECODE(trim(exchange_type),'1','SH','2','SZ'),trim(t.STOCK_CODE))
				      END AS STOCK_CODE
					 ,t.OC_DATE
					 ,DECODE(trim(t.exchange_type),'1','SH','2','SZ') as exchange_type
					 ,t.CURRENT_AMOUNT
					 FROM HSFK.HSMAN_HISCLIENTPLEDGESTOCK  t					 
					 LEFT JOIN    RISK_INDEX.HISGUARANTSECURITY_TEMP0        a5
                     ON           ((DECODE(SUBSTR(TRIM(t.STOCK_CODE),1,3),'743',CONCAT('733',SUBSTR(TRIM(t.STOCK_CODE),4,3)),'793',CONCAT('783',SUBSTR(TRIM(t.STOCK_CODE),4,3)),'755',CONCAT('754',SUBSTR(TRIM(t.STOCK_CODE),4,3)),TRIM(t.STOCK_CODE)) = a5.SGDM  AND %d{yyyyMMdd} BETWEEN a5.SWSGRQ AND a5.SSRQ)
                                   OR (TRIM(t.STOCK_CODE) = a5.PZDM  AND %d{yyyyMMdd} BETWEEN a5.SWSGRQ AND a5.TSRQ))
                     AND          DECODE(trim(t.exchange_type),'1','SH','2','SZ') = a5.JYS
                     LEFT JOIN    RISK_INDEX.HISGUARANTSECURITY_TEMP1        a6
                     ON           TRIM(t.STOCK_CODE) = TRIM(a6.RGDM)  
                     AND          DECODE(trim(t.exchange_type),'1','SH','2','SZ') = a6.JYS
                     AND          %d{yyyyMMdd} BETWEEN a6.QSRQ AND a6.JZRQ
					 LEFT JOIN   (SELECT      SecurityCode
                                             ,ExApplyingCode
											 ,DT 
		                          FROM       fundext.dbo_MF_FundArchives
			                      WHERE      LENGTH(TRIM(exapplyingcode))>0
			                      AND        securitycode < > exapplyingcode
		                          AND        SUBSTR(securitycode,7,1) <> 'J'
			                      AND        DT =  '%d{yyyyMMdd}'
			                       )                                         b
                    ON          TRIM(t.STOCK_CODE) = b.ExApplyingCode
                    AND        (SUBSTR(TRIM(t.STOCK_CODE),1,3) = '519' AND trim(t.exchange_type) = '1')
                     WHERE  t.oc_date          = %d{yyyyMMdd}
                     AND    t.business_type    = '0'
                     AND    t.DT               = '%d{yyyyMMdd}';
	
--------------插入数据-------------------
INSERT OVERWRITE RISK_INDEX.HISGUARANTSECURITY
(                            
  TRADEDATE                 --交易日期                               
 ,UNIT_CODE                 --所属机构（1、国泰君安证券；2、上海证券）
 ,STOCK_CODE                --证券代码                               
 ,STOCK_NAME                --证券名称                               
 ,MARKET_VALUE              --市值                                   
 ,MARKET_VALUE_CHG          --市值较上期增减                         
 ,RATE                      --占总市值比例                           
 ,DEBTS                     --负债 
 ,TOTAL_MARKET_VALUE        --总股本市值
) 
PARTITION(DT = '%d{yyyyMMdd}')
SELECT               CAST(t.OC_DATE AS CHAR(8))                                      AS TRADEDATE
                    ,CAST('2' AS VARCHAR(160))                                       AS UNIT_CODE
                    ,CAST(t.STOCK_CODE as VARCHAR(12))                                                   AS STOCK_CODE                                                   
                    ,CAST(a4.ZQMC AS VARCHAR(160))                                   AS STOCK_NAME
                    ,CAST(NVL(t.CURRENT_AMOUNT * a1.LAST_PRICE, 0)  AS DECIMAL(20,4) ) AS MARKET_VALUE 
                    ,CAST(NVL(t.CURRENT_AMOUNT * a1.LAST_PRICE, 0)  - NVL(a2.MARKET_VALUE,0)   AS DECIMAL(20,4))                                        AS MARKET_VALUE_CHG  
                    ,CAST((DECODE(NVL(a3.TOTALSHARES,0),0,0,NVL(t.CURRENT_AMOUNT * a1.LAST_PRICE,0))*1.000/(a3.TOTALSHARES*a1.LAST_PRICE))  AS DECIMAL(20,4))  AS rate
                    ,0                                                               AS DEBTS
                    ,CAST(a3.TOTALSHARES * a1.LAST_PRICE    AS DECIMAL(20,4))         AS TOTAL_MARKET_VALUE
FROM             (SELECT   OC_DATE
                           ,STOCK_CODE
						   ,exchange_type
                           ,SUM(CURRENT_AMOUNT) AS CURRENT_AMOUNT
				  FROM  RISK_INDEX.HISGUARANTSECURITY_TEMP2
				  GROUP BY OC_DATE,STOCK_CODE,exchange_type
				  ) t
LEFT JOIN            HSFK.HSMAN_HISPRICE a1 
ON                   t.OC_DATE         = a1.OC_DATE
AND                  t.EXCHANGE_TYPE   = DECODE(trim(a1.exchange_type),'1','SH','2','SZ')
AND                  t.STOCK_CODE      = TRIM(a1.STOCK_CODE)
AND                  a1.DT             = '%d{yyyyMMdd}'
LEFT JOIN           (SELECT a.STOCK_CODE,
                            a.MARKET_VALUE
                     FROM   RISK_INDEX.HISGUARANTSECURITY  a
                     WHERE EXISTS(SELECT 1 
                                  FROM     EDW_PROD.T_EDW_T99_TRD_DATE b
                                  WHERE    b.BUS_DATE     = %d{yyyyMMdd}
                                    AND    b.TRD_DT       = %d{yyyyMMdd}
                                    AND    CAST( a.TRADEDATE AS DECIMAL(38,0) ) = b.LST_TRD_D
                                 )
                     ) a2
ON                   t.STOCK_CODE = a2.STOCK_CODE
LEFT JOIN           (SELECT a.TOTALSHARES
                            ,b.COMPANYCODE
                            ,b.SECUCODE
							,DECODE(b.secumarket,83,'SH',90,'SZ') as JYS
                     FROM         FUNDEXT.DBO_LC_NEWESTSHARESTRU a
                     LEFT JOIN    FUNDEXT.DBO_SECUMAIN b
                     ON           a.COMPANYCODE = b.COMPANYCODE
                     AND          b.DT          = '%d{yyyyMMdd}'
                     WHERE        a.DT          = '%d{yyyyMMdd}'
					 AND          b.listedstate NOT IN(5)
                     GROUP BY     a.TOTALSHARES,
                                  b.COMPANYCODE,
                                  b.SECUCODE,
								  JYS
                    ) a3
ON                   TRIM(t.STOCK_CODE) = TRIM(a3.SECUCODE)
AND                  t.exchange_type = a3.JYS
LEFT JOIN            EDW_PROD.T_EDW_T04_TZQDM a4
ON                   TRIM(t.STOCK_CODE) = a4.ZQDM
AND                   t.exchange_type = a4.JYS
AND                  a4.BUS_DATE        = %d{yyyyMMdd};

 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:用户管理表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TUSER;  
--------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TUSER
(
                                    TUSER_ID                            --用户管理主键                             
                                   ,ORGID                               --隶属部门                               
                                   ,USERID                              --用户ID                               
                                   ,PASSWORD                            --密码                                 
                                   ,NAME                                --用户姓名                               
                                   ,SFZH                                --身份证号                               
                                   ,MOBILE                              --手机                                 
                                   ,DH                                  --电话                                 
                                   ,GRADE                               --节点级别                               
                                   ,GYFL                                --柜员分类                               
                                   ,LASTLOGIN                           --最近登陆时间                             
                                   ,LOGINS                              --登陆次数                               
                                   ,CHGPWDLIMIT                         --更密周期                               
                                   ,CHGPWDTIME                          --密码变更时间                             
                                   ,STATUS                              --允许登陆                               
                                   ,IPLIMIT                             --登陆IP限制                             
                                   ,CERTNO                              --证书号                                
                                   ,LOCKTIME                            --锁定时间                               
                                   ,DLYZFS                              --登陆验证方式                             
                                   ,GYSXDM                              --柜员属性代码                             
                                   ,ZT                                  --状态                                 
                                   ,CZQX_FJQX                           --附加权限    
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.ID                                  as TUSER_ID                            --ID                                  
                                   ,t.ORGID                               as ORGID                               --隶属部门                                
                                   ,t.USERID                              as USERID                              --用户ID                                
                                   ,t.PASSWORD                            as PASSWORD                            --密码                                  
                                   ,t.NAME                                as NAME                                --用户姓名                                
                                   ,t.SFZH                                as SFZH                                --身份证号                                
                                   ,t.SJ                                  as MOBILE                              --手机                                  
                                   ,t.DH                                  as DH                                  --电话                                  
                                   ,t.GRADE                               as GRADE                               --节点级别                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.GYFL AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as GYFL                                --柜员分类                                
                                   ,t.LASTLOGIN                           as LASTLOGIN                           --最近登陆时间                              
                                   ,t.LOGINS                              as LOGINS                              --登陆次数                                
                                   ,t.CHGPWDLIMIT                         as CHGPWDLIMIT                         --更密周期                                
                                   ,t.CHGPWDTIME                          as CHGPWDTIME                          --密码变更时间                              
                                   ,t.STATUS                              as STATUS                              --允许登陆                                
                                   ,t.IPLIMIT                             as IPLIMIT                             --登陆IP限制                              
                                   ,t.CERTNO                              as CERTNO                              --证书号                                 
                                   ,t.LOCKTIME                            as LOCKTIME                            --锁定时间                                
                                   ,t.DLYZFS                              as DLYZFS                              --登陆验证方式                              
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.GYSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as GYSXDM                              --柜员属性                                
                                   ,t.ZT                                  as ZT                                  --状态                                  
                                   ,t.CZQX_FJQX                           as CZQX_FJQX                           --附加权限  
                                   ,'YGT_GT'							  as XTBS   
FROM           YGTCX.CIF_TUSER                       t
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
ON             t1.DMLX = 'GYFL'
AND            t1.YXT = 'YGT_GT'
AND            t1.YDM = CAST(t.GYFL AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
ON             t2.DMLX = 'GYSXDM'
AND            t2.YXT = 'YGT'
AND            t2.YDM = CAST(t.GYSX AS VARCHAR(20))
WHERE          t.DT = '%d{yyyyMMdd}';
-----------插入数据结束-----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TUSER',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TUSER;
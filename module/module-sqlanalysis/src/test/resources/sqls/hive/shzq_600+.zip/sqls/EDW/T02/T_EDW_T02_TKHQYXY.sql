 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户签约协议信息表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TKHQYXY;  
------插入数据开始-----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TKHQYXY(
                                    KHH                                 --客户号                                
                                   ,XYID                                --协议ID                               
                                   ,XYLXDM                              --协议类型代码                             
                                   ,XYBH                                --协议编号                               
                                   ,QSRQ                                --签署日期                               
                                   ,QSSJ                                --签署时间                               
                                   ,CZGY                                --操作柜员                               
                                   ,FHGY                                --复核柜员                               
                                   ,YWQQID                              --业务请求主键   
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.XYID                                as XYID                                --协议ID                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.XYLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as XYLXDM                              --协议类型                                
                                   ,t.XYBH                                as XYBH                                --协议编号                                
                                   ,t.QSRQ                                as QSRQ                                --签署日期                                
                                   ,t.QSSJ                                as QSSJ                                --签署时间                                
                                   ,t.CZGY                                as CZGY                                --操作柜员                                
                                   ,t.FHGY                                as FHGY                                --复核柜员                                
                                   ,t.YWQQID                              as YWQQID                              --业务请求ID     
                                   ,'YGT_GT'								   
 FROM           YGTCX.CIF_TKHQYXY                              t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t1 
 ON             t1.DMLX = 'XYLXDM'
 AND            t1.YXT = 'YGT_GT'
 AND            t1.YDM = CAST(t.XYLX AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
--------插入数据结束-------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TKHQYXY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TKHQYXY;
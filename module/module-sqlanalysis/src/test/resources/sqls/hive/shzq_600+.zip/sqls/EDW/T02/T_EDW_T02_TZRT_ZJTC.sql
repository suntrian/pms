 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:转融通资金头寸表                                                                  */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
   TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZRT_ZJTC;  
-----插入数据开始-------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZRT_ZJTC
(
                 			JYRQ                                --交易日期   
                            ,SZTCJE                            --深圳头寸金额
							,SHTCJE                              --上海头寸金额 
							,XTBS
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.JYRQ                                as JYRQ                                --交易日期
									,t.SZTCJE                              as SZTCJE                              --深圳头寸金额 
                                    ,t.SHTCJE                              as SHTCJE                              --上海头寸金额	
                                    ,'RZRQ'                                as XTBS									
 FROM     		RZRQCX.ZRT_TZRT_ZJTC t
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束----------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZRT_ZJTC',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ; 

invalidate metadata EDW_PROD.T_EDW_T02_TZRT_ZJTC;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:金融产品订单明细                                                                 */
  --/* 创建人:段智泓                                                                             */
  --/* 创建时间:2018-09-06                                                                 */ 

-------插入数据开始--------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TFP_CPDDMX
(
                       ID             --ID
                      ,WTH            --委托号
                      ,KHH            --客户
                      ,KHLX           --客户类型
                      ,ZJLB           --证件类别
                      ,DBR            --法定代表人\授权代表人
                      ,ZJBH           --证件编号
                      ,LXDH           --联系电话
                      ,SJ             --手机
                      ,EMAIL          --电子邮箱
                      ,TXDZ           --通讯地址
                      ,YZBM           --邮政编码
                      ,FXCSNL         --风险承受能力
                      ,DDRQ           --订单日期
                      ,FXJG           --发行机构
                      ,TZZH           --产品账号
                      ,JYZH           --交易账号
                      ,CPFL           --产品分类
                      ,CPID           --产品名称
                      ,CPDM           --产品代码
                      ,YWLB           --业务类别
                      ,YYD            --预约号
                      ,GMSL           --委托数量
                      ,GMJE           --委托金额
                      ,HKJE           --划款金额
                      ,FHFS           --分红方式
                      ,SFFS           --收费方式
                      ,JESHCLFS       --巨额赎回方式
                      ,HTH            --合同号
                      ,KHJL           --客户经理
                      ,JSLX           --结算类型
                      ,JSJG           --结算机构
                      ,JSZH           --结算帐户
                      ,BZ             --备注
                      ,FXPJ           --风险评级
                      ,ZKL            --折扣率
                      ,SYR            --受益人
                      ,SYRZH          --受益人账户
                      ,SYRZHYH        --受益人开户行
                      ,YYB            --营业部
                      ,FSYYB          --发生营业部
                      ,XSWD           --销售网点
                      ,WTFS           --委托方式
                      ,DDZT           --订单状态
                      ,DJRQ           --登记日期
                      ,DJSJ           --登记时间
                      ,DJR            --登记人
                      ,CZZD           --操作IP
                      ,QRRQ           --确认日期
                      ,QRR            --确认人
                      ,SFSD           --是否适当
                      ,BSDSM          --不适当说明
                      ,FXJB_FXF       --发行方评测的风险等级
                      ,KHTZPZ         --客户投资品种
                      ,KHTZQX         --客户投资期限
                      ,DJBM           --
                      ,HFCLZT         --
                      ,ZFFS           --支付方式
                      ,ZFZH           --支付账号
                      ,ZJHZFS         --
                      ,SLID           --
                      ,SDXBZ          --适当性标志
                      ,CPTZQX         --产品投资期限
                      ,CPTZPZ         --产品投资品种
                      ,CPFXPJ         --产品风险评级
                      ,SMFXCSNL       --私募基金风险承受能力
                      ,WBQD           --
                      ,XTBS           --系统标识
)
PARTITION( bus_date = %d{yyyyMMdd})
SELECT                           
                       t.ID           as ID            --ID
                      ,t.WTH          as WTH           --委托号
                      ,t.KHH          as KHH           --客户
                      ,t.KHLX         as KHLX          --客户类型
                      ,t.ZJLB         as ZJLB          --证件类别
                      ,t.DBR          as DBR           --法定代表人\授权代表人
                      ,t.ZJBH         as ZJBH          --证件编号
                      ,t.LXDH         as LXDH          --联系电话
                      ,t.SJ           as SJ            --手机
                      ,t.EMAIL        as EMAIL         --电子邮箱
                      ,t.TXDZ         as TXDZ          --通讯地址
                      ,t.YZBM         as YZBM          --邮政编码
                      ,t.FXCSNL       as FXCSNL        --风险承受能力
                      ,t.DDRQ         as DDRQ          --订单日期
                      ,t.FXJG         as FXJG          --发行机构
                      ,t.TZZH         as TZZH          --产品账号
                      ,t.JYZH         as JYZH          --交易账号
                      ,t.CPFL         as CPFL          --产品分类
                      ,t.CPID         as CPID          --产品名称
                      ,t.CPDM         as CPDM          --产品代码
                      ,t.YWLB         as YWLB          --业务类别
                      ,t.YYD          as YYD           --预约号
                      ,t.GMSL         as GMSL          --委托数量
                      ,t.GMJE         as GMJE          --委托金额
                      ,t.HKJE         as HKJE          --划款金额
                      ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.FHFS AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))         as FHFS --分红方式 
                      ,t.SFFS         as SFFS          --收费方式
                      ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JESHCLFS AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))     as JESHCLFS      --巨额赎回方式
                      ,t.HTH          as HTH           --合同号
                      ,t.KHJL         as KHJL          --客户经理
                      ,t.JSLX         as JSLX          --结算类型
                      ,t.JSJG         as JSJG          --结算机构
                      ,t.JSZH         as JSZH          --结算帐户
                      ,t.BZ           as BZ            --备注
                      ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.FXPJ AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))         as FXPJ          --风险评级
                      ,t.ZKL          as ZKL           --折扣率
                      ,t.SYR          as SYR           --受益人
                      ,t.SYRZH        as SYRZH         --受益人账户
                      ,t.SYRZHYH      as SYRZHYH       --受益人开户行
                      ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))         as YYB  --营业部 
                      ,t.FSYYB        as FSYYB         --发生营业部
                      ,t.XSWD         as XSWD          --销售网点
                      ,t.WTFS         as WTFS          --委托方式
                      ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.DDZT AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))         as DDZT          --订单状态
                      ,t.DJRQ         as DJRQ          --登记日期
                      ,t.DJSJ         as DJSJ          --登记时间
                      ,t.DJR          as DJR           --登记人
                      ,t.CZZD         as CZZD          --操作IP
                      ,t.QRRQ         as QRRQ          --确认日期
                      ,t.QRR          as QRR           --确认人
                      ,t.SFSD         as SFSD          --是否适当
                      ,t.BSDSM        as BSDSM         --不适当说明
                      ,t.FXJB_FXF     as FXJB_FXF      --发行方评测的风险等级
                      ,t.KHTZPZ       as KHTZPZ        --客户投资品种
                      ,t.KHTZQX       as KHTZQX        --客户投资期限
                      ,t.DJBM         as DJBM          --
                      ,t.HFCLZT       as HFCLZT        --
                      ,t.ZFFS         as ZFFS          --支付方式
                      ,t.ZFZH         as ZFZH          --支付账号
                      ,t.ZJHZFS       as ZJHZFS        --
                      ,t.SLID         as SLID          --
                      ,t.SDXBZ        as SDXBZ         --适当性标志
                      ,t.CPTZQX       as CPTZQX        --产品投资期限
                      ,t.CPTZPZ       as CPTZPZ        --产品投资品种
                      ,t.CPFXPJ       as CPFXPJ        --产品风险评级
                      ,t.SMFXCSNL     as SMFXCSNL      --私募基金风险承受能力
                      ,t.WBQD         as WBQD          --
                      ,'OTC'          as XTBS          --系统标识
FROM           OTCCX.FPSS_TFP_CPDDMX t
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1
ON             t1.DMLX = 'OF_FHFS'
AND            t1.YXT = 'OTC'
AND            t1.YDM = CAST(t.FHFS AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2
ON             t2.DMLX = 'OTC_JESHCLFS'
AND            t2.YXT = 'OTC'
AND            t2.YDM = CAST(t.JESHCLFS AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3
ON             t3.DMLX = 'OTC_CPFXPJ'
AND            t3.YXT = 'OTC'
AND            t3.YDM = CAST(t.FXPJ AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t4
ON             t4.YXT = 'OTC'
AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t5
ON             t5.DMLX = 'OTC_DDZT'
AND            t5.YXT = 'OTC'
AND            t5.YDM = CAST(t.DDZT AS VARCHAR(20))
WHERE 	       t.DT = '%d{yyyyMMdd}'
;
----------插入数据结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TFP_CPDDMX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TFP_CPDDMX;
 --/* ***************************************** SQL Begin *****************************************  */
  --/* 脚本功能:客户360查询                                                                      */
  --/* 创建人:程骏                                                                               */
  --/* 创建时间:2017-10-18                                                                        */ 
  
  /* T_DDW_F01_CUST_INFO	替换为	T_DDW_F00_CUST_CUST_INFO */
  /* T_DDW_F01_CUST_BRK_RLN	替换为	T_DDW_F00_CUST_CUST_BRK_RLN */
  
----删除今天的数据--



---------------- 插入集中交易数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_QRY
  (
                                     CUST_NO				  		    --客户号
                                    ,CUST_NAME		      				--姓名
                                    ,CTF_NO				  				--证件号码
                                    ,CTCT_ADDR		      				--联系地址
                                    ,CTCT_TEL		      				--联系电话
                                    ,PHONE				  				--手机
                                    ,CUST_STAT			  				--客户状态
                                    ,CUST_CGY			  				--客户类别
                                    ,BRH_NAME			  				--所属营业部
                                    ,BRK_NAME              				--经纪人姓名
                                    ,TOL_AST               				--客户总资产                    
 ) PARTITION( bus_date = %d{yyyyMMdd})
 SELECT    t.CUST_NO               as CUST_NO				  		    --客户号  
	       ,t.CUST_NAME            as CUST_NAME		      				--姓名
	       ,t.CTF_NO               as CTF_NO				  			--证件号码
	       ,t.CTCT_ADDR            as CTCT_ADDR		      				--联系地址
	       ,t.CTCT_TEL             as CTCT_TEL		      				--联系电话
	       ,t.PHONE                as PHONE				  				--手机
	       ,a1.CUST_STAT_NAME      as CUST_STAT			  				--客户状态
	       ,a2.CUST_CGY_NAME       as CUST_CGY			  				--客户类别
	       ,t.BRH_NAME             as BRH_NAME			  				--所属营业部
	       ,a3.BRK_NAME            as BRK_NAME              			--经纪人姓名
	       ,NVL(a4.TOL_AST,0)      as TOL_AST               			--客户总资产               
 FROM          DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
 LEFT JOIN     DDW_PROD.V_CUST_STAT a1
 ON            T.ORDI_CUST_STAT =  a1.CUST_STAT
 LEFT JOIN     DDW_PROD.V_CUST_CGY a2
 ON            t.CUST_CGY = a2.CUST_CGY		
 LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN a3 
 ON            t.cust_no = a3.cust_no 
 AND           a3.VLD_BRK_CUST_FLG = 1 
 AND           t.bus_date = a3.bus_date		
 LEFT JOIN     DDW_PROD.T_DDW_CUST_STATMT_DAY a4
 ON            t.cust_no = a4.cust_no 
 AND           t.bus_date = a4.bus_date	
 WHERE         t.BUS_DATE = %d{yyyyMMdd}	;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_QRY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_QRY;
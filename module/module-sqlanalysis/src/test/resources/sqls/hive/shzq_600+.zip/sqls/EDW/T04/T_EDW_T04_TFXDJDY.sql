--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:风险等级对应表                                                                       */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
 TRUNCATE TABLE EDW_PROD.T_EDW_T04_TFXDJDY;
------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TFXDJDY
 (
 								 TYPE                                --类型                                 
 								,FXZL                                --风险种类                               
 								,FXJBFW                              --风险等级范围                             
 								,XGRQ                                --修改日期                               
 								,GYH                                 --修改柜员  
 								,XTBS								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
 								 t.TYPE                                as TYPE                                --类型                                  
 								,t.FXZL                                as FXZL                                --风险种类                                
 								,t.FXJBFW                              as FXJBFW                              --风险等级范围                              
 								,t.XGRQ                                as XGRQ                                --修改日期                                
 								,t.XGGY                                as GYH                                 --修改柜员 
 								,'JZJY'								   
 FROM 		JZJYCX.ABOSS_TFXDJDY t 
 WHERE 		t.DT = '%d{yyyyMMdd}';
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TFXDJDY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
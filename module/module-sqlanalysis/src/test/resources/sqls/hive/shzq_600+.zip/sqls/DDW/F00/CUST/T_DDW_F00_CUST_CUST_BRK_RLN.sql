 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:经纪人客户关系表                                                                       */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 


--------------插入数据-------------------
 INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN 
 (
                                     CUST_NO                             --客户号         
                                    ,BRH_NO                              --营业部编号       
                                    ,BRH_NAME                            --营业部名称       
                                    ,STATS_DT                            --统计日期        
                                    ,CNCL_DT                             --注销日期 
                                    ,EXPR_DT                             --截至日期	
                                    ,EFF_DT                              --生效日期									
                                    ,BRK                                 --经纪人         
                                    ,BRK_NO                              --经纪人编号       
                                    ,BRK_NAME                            --经纪人姓名       
                                    ,BRK_CGY                             --经纪人类别 
                                    ,BRK_BELTO_BRH                       --经纪人所属营业部									
                                    ,OPNAC_DT                            --开户日期        
                                    ,CNCLACT_DT                          --销户日期 
								    ,ENTRY_DT              --入职日期
									,RSG_DT                              --离职日期
                                    ,IF_OPN_STATMT                       --是否开通对账单
                                    ,RSK_HINT_CNFM_CNDT                  --风险提示及确认书签订情况
                                    ,VLD_BRK_CUST_FLG                    --有效经纪人客户标志(1,有效经纪人客户，-1已注销经纪人客户)
                                    ,BRK_RLN_TML_DT                      --经纪关系终止日期									
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                                   t.KHH                                           as CUST_NO                             --客户号                                                  
                                   ,a5.YYB                                         as BRH_NO                              --营业部编号                                                
                                   ,NVL(a6.BRH_SHRTNM,a7.FILIL_DEPT_SHRTNM)        as BRH_NAME                            --营业部名称                                                
                                   ,t.TJRQ                                         as STATS_DT                            --统计日期                                                                                      
                                   ,t.ZXRQ                                         as CNCL_DT                             --注销日期 
                                   ,t.JZRQ                                         as EXPR_DT                             --截至日期								   
                                   ,t.SXRQ                                         as EFF_DT                              --生效日期
								   ,CAST(t.JJR as STRING)                          as BRK                                 --经纪人                                                  
                                   ,a1.JJRBH                                       as BRK_NO                              --经纪人编号                                                
                                   ,a1.JJRXM                                       as BRK_NAME                            --经纪人姓名                                                
                                   ,a1.JJRLB                                       as BRK_CGY                             --经纪人类别
                                   ,a1.JJRYYB                                      as BRK_BELTO_BRH                       --经纪人所属营业部								   
                                   ,a1.KHRQ                                        as OPNAC_DT                            --开户日期                                                 
                                   ,a1.XHRQ                                        as CNCLACT_DT                          --销户日期
                                   ,a1.RZRQ                                        as ENTRY_DT              --入职日期
								   ,a1.LZRQ                                        as RSG_DT                              --离职日期								   
                                   ,CASE WHEN a3.KHH IS NULL
                                         THEN '未开通'
                                         ELSE '开通'
                                         END                                       as IF_OPN_STATMT                       --是否开通对账单 
                                   ,NVL(a4.BZ,'未签署')                               as RSK_HINT_CNFM_CNDT                  --风险提示及确认书签订情况										 
                                   ,CASE WHEN (t.ZXRQ IS NULL OR t.ZXRQ > %d{yyyyMMdd})  
                                         AND   (t.JZRQ IS NULL OR t.JZRQ > %d{yyyyMMdd})
                                         AND	a1.ZHZT <> '1' 
                                         AND   a1.JJRLB IN ('1','2','3','4','102','103','104')
                                         AND   (a5.JZJYKH_KHZTDM <> '3' OR a5.JZJYKH_XHRQ > %d{yyyyMMdd})
										 THEN  1
										 WHEN 	a1.JJRLB IN ('1','2','3','4','102','103','104')
                                         AND  LEAST(NVL(t.ZXRQ,99999999),NVL(a1.LZRQ1,99999999),NVL(a1.XHRQ1,99999999),NVL(a5.JZJYKH_XHRQ1,99999999),NVL(t.JZRQ,99999999)) BETWEEN CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-3,0,0),1,4),'0101') AS DECIMAL(38,0)) AND %d{yyyyMMdd}
										 THEN -1
										 END                                     as VLD_BRK_CUST_FLG                    --有效经纪人客户标志
								   ,LEAST(NVL(t.ZXRQ,99999999),NVL(a1.LZRQ1,99999999),NVL(a1.XHRQ1,99999999),NVL(a5.JZJYKH_XHRQ1,99999999),NVL(t.JZRQ,99999999)) as BRK_RLN_TML_DT    --经纪关系终止日期
										 
  FROM          EDW_PROD.T_EDW_T01_TJJGX                  t
  LEFT JOIN     ( SELECT CASE WHEN ZHZT = '1'
                              THEN LZRQ
							  END  AS LZRQ1
						 ,CASE WHEN ZHZT = '1'
                              THEN XHRQ
							  END  AS XHRQ1
                        ,ID
                        ,BUS_DATE
                        ,JJRBH  						
                        ,JJRXM  
                        ,JJRLB  
                        ,JJRYYB 
                        ,KHRQ   
                        ,XHRQ   
                        ,LZRQ   
                        ,ZHZT
						,RZRQ
                FROM EDW_PROD.T_EDW_T01_TJJR 
				WHERE BUS_DATE = %d{yyyyMMdd}    )                  a1
  ON            t.JJR = a1.ID   
  AND           t.bus_date = a1.bus_date  
  LEFT JOIN   (SELECT DISTINCT khh,DT from C5CX.SPIF_TFWCP_DZXX_KH where fwcp=612) a3 
  ON            t.KHH = CAST(a3.KHH as STRING)
  AND           t.BUS_DATE = CAST(a3.DT AS INT)
  LEFT JOIN ( SELECT b.JJR,b.KHH,'已签署' as BZ
              FROM (SELECT   JJR
                             ,CAST(KHH AS STRING) as KHH 
                     FROM    NEWCRM.CRMII_TJJRSJKHLKHKHBD
                     WHERE   CLJG IN ('自动认领成功','人工认领:成功','自动认领:成功')
                     AND     SM LIKE '%已网签风险确认书%'                   
                     UNION ALL
                      SELECT   JJR
                               ,CAST(KHH AS STRING) as KHH
                     FROM    C5CX.CIS_LCJJRKHRLBD--NEWCRM.CRMII_LCJJRKHRLBD -- C5CX.CIS_LCJJRKHRLBD
                     WHERE   ((CLJG IN ('自动认领成功','人工认领:成功','自动认领:成功') AND SM LIKE '%已网签风险确认书%')
                      OR      (SM LIKE '%存量认领%' AND FXTSQRS = '1'))
                     
                     UNION ALL
                     SELECT   YG as JJR
                              ,CAST(KHH AS STRING) as KHH
                     FROM    C5CX.CIS_LCYGKHRLBD--NEWCRM.CRMII_LCYGKHRLBD --C5CX.CIS_LCYGKHRLBD
                     WHERE   SM LIKE '%存量认领%' AND FXTSQRS ='1'
                    
                   )          b
                     GROUP BY  b.KHH,b.JJR
  )                                                a4
  ON              t.KHH = a4.KHH
  AND             t.JJR = a4.JJR 
  LEFT JOIN  (SELECT CASE WHEN JZJYKH_KHZTDM = '3' OR JZJYKH_XHRQ BETWEEN CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-3,0,0),1,4),'0101') AS DECIMAL(38,0))  AND %d{yyyyMMdd}
                          THEN JZJYKH_XHRQ
						  END AS JZJYKH_XHRQ1
                     ,KHH
					 ,JZJYKH_XHRQ
					 ,JZJYKH_KHZTDM
					 ,BUS_DATE
                     ,YYB					 
			   FROM  EDW_PROD.T_EDW_T01_TKHXX )    a5
  ON          t.KHH = a5.KHH
  AND         a5.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH         a6
  ON            a5.YYB = a6.BRH_NO   
  AND           a6.BUS_DATE = %d{yyyyMMdd} 
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a7
  ON            a5.YYB = a7.FILIL_DEPT_CDG
  AND           a7.BUS_DATE = %d{yyyyMMdd}   
  WHERE         t.bus_date = %d{yyyyMMdd}
  AND           t.TJRQ < = %d{yyyyMMdd} 
  AND           t.SXRQ < = %d{yyyyMMdd}
    ;

  -----------------------------------结束插入---------
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_CUST_BRK_RLN',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN ;


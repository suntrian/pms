 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:未做风险测评客户信息表                                                                     */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */
/* T_DDW_F01_CUST_INFO	修改为	T_DDW_F00_CUST_CUST_INFO */  
TRUNCATE TABLE DDW_PROD.T_DDW_PRT_UN_RSK_EVAL_CUST_INFO;
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_UN_RSK_EVAL_CUST_INFO
(        
								 BRH_NO                --营业部编号  
								,BRH_NAME              --营业部名称  
								,OPNAC_DT              --开户日期    
								,CUST_NO               --客户号      
								,CUST_NAME             --客户姓名    
								,CTF_CGY_CD            --证件类别代码
								,CTF_NO                --证件号码    
								,DEPMGT_BANK           --存管银行    
								,CTRL_ATTR             --控制属性    
								,IMAGE_TP              --影像资料    
								,M_LAUND_RSK_LVL       --洗钱风险等级
								,RSK_BEAR_ABLTY        --风险承受能力
								,CTF_EXPR_DT           --证件截至日期
								,CTCT_ADDR             --联系地址    
								,CTCT_TEL              --联系电话    
								,PHONE                 --手机        
								,EDU_CD                --学历代码    				
								,OCP_CD                --职业代码    
								,RSK_LVL               --风险级别           						 				
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
					 t.BRH_NO                                 AS BRH_NO                --营业部编号       
					,t.BRH_NAME                               AS BRH_NAME              --营业部名称       
					,t.ORDI_OPNAC_DT                               AS OPNAC_DT              --开户日期         
					,t.CUST_NO                                AS CUST_NO               --客户号           
					,t.CUST_NAME                              AS CUST_NAME             --客户姓名         
					,b1.CTF_CGY_CD_NAME                            AS CTF_CGY_CD            --证件类别代码     
					,t.CTF_NO                                 AS CTF_NO                --证件号码         
					,t.DEPMGT_BANK                            AS DEPMGT_BANK           --存管银行         
					,t.CTRL_ATTR                              AS CTRL_ATTR             --控制属性         
					,t.IMAGE_TP                               AS IMAGE_TP              --影像资料         
					,b6.M_LAUND_RSK_LVL_NAME                        AS M_LAUND_RSK_LVL       --洗钱风险等级     
					,b2.RSK_BEAR_ABLTY_NAME                         AS RSK_BEAR_ABLTY        --风险承受能力     
					,t.CTF_EXPR_DT                            AS CTF_EXPR_DT           --证件截至日期     
					,t.CTCT_ADDR                              AS CTCT_ADDR             --联系地址         
					,t.CTCT_TEL                               AS CTCT_TEL              --联系电话         
					,t.PHONE                                  AS PHONE                 --手机             
					,b3.EDU_CD_NAME        	              	  AS EDU_CD                --学历代码    			
					,b4.OCP_CD_NAME                           AS OCP_CD                --职业代码         
					,b5.CUST_RSK_LVL_NAME                          AS RSK_LVL               --风险级别         
  FROM  		 DDW_PROD.T_DDW_F00_CUST_CUST_INFO    t 
  LEFT JOIN 		DDW_PROD.V_CTF_CGY_CD					b1
  ON				t.CTF_CGY_CD = b1.CTF_CGY_CD
  LEFT JOIN 		DDW_PROD.V_RSK_BEAR_ABLTY				b2
  ON				t.RSK_BEAR_ABLTY = b2.RSK_BEAR_ABLTY
  LEFT JOIN 		DDW_PROD.V_EDU_CD						b3
  ON				t.EDU_CD = b3.EDU_CD
  LEFT JOIN 		DDW_PROD.V_OCP_CD						b4
  ON				t.OCP_CD = b4.OCP_CD
  LEFT JOIN 		DDW_PROD.V_CUST_RSK_LVL						b5
  ON				t.CUST_RSK_LVL = b5.CUST_RSK_LVL
  LEFT JOIN  DDW_PROD.V_M_LAUND_RSK_LVL            b6
  ON         t.M_LAUND_RSK_LVL = b6.M_LAUND_RSK_LVL
  WHERE 		 t.bus_date = %d{yyyyMMdd}
  AND       	 t.ORDI_CUST_STAT<>'3'
  AND            t.CUST_CGY = '0'
  AND       	 t.CUST_RSK_LVL IN ('0','1','2','8','19')
  AND            t.BRH_NO <> '1'
  AND       	 (t.RSK_BEAR_ABLTY = '0' OR t.RSK_BEAR_ABLTY IS NULL)
  ;
  ------结束----
  
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_UN_RSK_EVAL_CUST_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_UN_RSK_EVAL_CUST_INFO ; 
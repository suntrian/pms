------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户产品交易汇总月表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
  


------插入数据
  INSERT OVERWRITE DDW_PROD.T_DDW_F10_TRD_CUST_PROD_TRD_AGGR_MON
(                CUST_NO                       --客户号                 
                ,BRH_NO                        --营业部编号                         
                ,CUST_CGY				       --客户类别
                ,OTC_FND_SCRP_AMT              --场外基金认购金额
                ,OTC_FND_PRCH_AMT              --场外基金申购金额	
                ,OTC_FND_RDMPT_AMT             --场外基金赎回金额
                ,OTC_FND_MTCH_AMT              --场外基金成交金额
                ,CO_PROD_SCRP_AMT              --公司自管产品认购金额
                ,CO_PROD_PRCH_AMT              --公司自管产品申购金额	
                ,CO_PROD_RDMPT_AMT             --公司自管产品赎回金额
                ,CO_PROD_MTCH_AMT              --公司自管产品成交金额
                ,GJ_CO_PROD_SCRP_AMT           --国君公司产品认购金额
                ,GJ_CO_PROD_PRCH_AMT           --国君公司产品申购金额
                ,GJ_CO_PROD_RDMPT_AMT          --国君公司产品赎回金额
                ,GJ_CO_PROD_MTCH_AMT           --国君公司产品成交金额
                ,FNCL_PROD_SCRP_AMT            --金融产品认购金额
                ,FNCL_PROD_RDMPT_AMT           --金融产品赎回金额
                ,FNCL_PROD_MTCH_AMT            --金融产品成交金额
                ,OTC_FND_SCRP_SHR              --场外基金认购份额
                ,OTC_FND_PRCH_SHR              --场外基金申购份额	
                ,OTC_FND_RDMPT_SHR             --场外基金赎回份额
                ,OTC_FND_MTCH_SHR              --场外基金成交份额
                ,CO_PROD_SCRP_SHR              --公司自管产品认购份额
                ,CO_PROD_PRCH_SHR              --公司自管产品申购份额	
                ,CO_PROD_RDMPT_SHR             --公司自管产品赎回份额
                ,CO_PROD_MTCH_SHR              --公司自管产品成交份额
                ,GJ_CO_PROD_SCRP_SHR           --国君公司产品认购份额
                ,GJ_CO_PROD_PRCH_SHR           --国君公司产品申购份额
                ,GJ_CO_PROD_RDMPT_SHR          --国君公司产品赎回份额
                ,GJ_CO_PROD_MTCH_SHR           --国君公司产品成交份额
                ,FNCL_PROD_SCRP_SHR            --金融产品认购份额
                ,FNCL_PROD_RDMPT_SHR           --金融产品赎回份额
                ,FNCL_PROD_MTCH_SHR            --金融产品成交份额	
                ,OTC_FND_SCRP_CMSN_FEE         --场外基金认购手续费
                ,OTC_FND_PRCH_CMSN_FEE         --场外基金申购手续费	
                ,OTC_FND_RDMPT_CMSN_FEE        --场外基金赎回手续费
                ,OTC_FND_MTCH_CMSN_FEE         --场外基金成交手续费
                ,CO_PROD_SCRP_CMSN_FEE         --公司自管产品认购手续费
                ,CO_PROD_PRCH_CMSN_FEE         --公司自管产品申购手续费	
                ,CO_PROD_RDMPT_CMSN_FEE        --公司自管产品赎回手续费
                ,CO_PROD_MTCH_CMSN_FEE         --公司自管产品成交手续费
                ,GJ_CO_PROD_SCRP_CMSN_FEE      --国君公司产品认购手续费
                ,GJ_CO_PROD_PRCH_CMSN_FEE      --国君公司产品申购手续费
                ,GJ_CO_PROD_RDMPT_CMSN_FEE     --国君公司产品赎回手续费
                ,GJ_CO_PROD_MTCH_CMSN_FEE      --国君公司产品成交手续费
                ,FNCL_PROD_SCRP_CMSN_FEE       --金融产品认购手续费
                ,FNCL_PROD_RDMPT_CMSN_FEE      --金融产品赎回手续费
                ,FNCL_PROD_MTCH_CMSN_FEE       --金融产品成交手续费
                ,OTC_FND_RTN_CMSN_FEE          --场外基金返回手续费    
                ,CO_PROD_RTN_CMSN_FEE          --公司自管产品返回手续费
                ,GJ_CO_PROD_RTN_CMSN_FEE       --国君公司产品返回手续费
                ,FNCL_PROD_RTN_CMSN_FEE        --金融产品返回手续费
                ,OTC_FND_SCRP_ITMS            --场外基金认购笔数
                ,OTC_FND_PRCH_ITMS            --场外基金申购笔数	
                ,OTC_FND_RDMPT_ITMS           --场外基金赎回笔数
                ,OTC_FND_MTCH_ITMS            --场外基金成交笔数
                ,CO_PROD_SCRP_ITMS            --公司自管产品认购笔数
                ,CO_PROD_PRCH_ITMS            --公司自管产品申购笔数	
                ,CO_PROD_RDMPT_ITMS           --公司自管产品赎回笔数
                ,CO_PROD_MTCH_ITMS            --公司自管产品成交笔数
                ,GJ_CO_PROD_SCRP_ITMS         --国君公司产品认购笔数
                ,GJ_CO_PROD_PRCH_ITMS         --国君公司产品申购笔数
                ,GJ_CO_PROD_RDMPT_ITMS        --国君公司产品赎回笔数
                ,GJ_CO_PROD_MTCH_ITMS         --国君公司产品成交笔数
                ,FNCL_PROD_SCRP_ITMS          --金融产品认购笔数
                ,FNCL_PROD_RDMPT_ITMS         --金融产品赎回笔数
                ,FNCL_PROD_MTCH_ITMS          --金融产品成交笔数
				,OTC_FND_TFR_IN_MKTVAL        --场外基金转入市值
                ,OTC_FND_TFR_OUT_MKTVAL       --场外基金转出市值
                ,OTC_FND_NET_TFR_IN_MKTVAL    --场外基金净转入市值
			    ,CO_PROD_TFR_IN_MKTVAL        --公司自管产品转入市值
			    ,CO_PROD_TFR_OUT_MKTVAL       --公司自管产品转出市值
			    ,CO_PROD_NET_TFR_IN_MKTVAL    --公司自管产品净转入市值
			    ,GJ_CO_PROD_TFR_IN_MKTVAL     --国君公司产品转入市值
			    ,GJ_CO_PROD_TFR_OUT_MKTVAL    --国君公司产品转出市值
			    ,GJ_CO_PROD_NET_TFR_IN_MKTVAL --国君公司产品净转入市值
			    ,FNCL_PROD_TFR_IN_MKTVAL      --金融产品转入市值
			    ,FNCL_PROD_TFR_OUT_MKTVAL     --金融产品转出市值
                ,FNCL_PROD_NET_TFR_IN_MKTVAL  --金融产品净转入市值
			    ,PROD_TFR_IN_MKTVAL           --产品转入总市值
                ,PROD_TFR_OUT_MKTVAL          --产品转出总市值
                ,PROD_NET_TFR_IN_MKTVAL       --产品净转入总市值
                ,ETL_DT 				
 ) partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT          CUST_NO                          as CUST_NO                       --客户号                 
                ,BRH_NO                           as BRH_NO                        --营业部编号                         
                ,CUST_CGY				          as CUST_CGY				       --客户类别
                ,SUM(OTC_FND_SCRP_AMT)            as OTC_FND_SCRP_AMT              --场外基金认购金额
                ,SUM(OTC_FND_PRCH_AMT)            as OTC_FND_PRCH_AMT              --场外基金申购金额	
                ,SUM(OTC_FND_RDMPT_AMT)           as OTC_FND_RDMPT_AMT             --场外基金赎回金额
                ,SUM(OTC_FND_MTCH_AMT)            as OTC_FND_MTCH_AMT              --场外基金成交金额
                ,SUM(CO_PROD_SCRP_AMT)            as CO_PROD_SCRP_AMT              --公司自管产品认购金额
                ,SUM(CO_PROD_PRCH_AMT)            as CO_PROD_PRCH_AMT              --公司自管产品申购金额	
                ,SUM(CO_PROD_RDMPT_AMT)           as CO_PROD_RDMPT_AMT             --公司自管产品赎回金额
                ,SUM(CO_PROD_MTCH_AMT)            as CO_PROD_MTCH_AMT              --公司自管产品成交金额
                ,SUM(GJ_CO_PROD_SCRP_AMT)         as GJ_CO_PROD_SCRP_AMT           --国君公司产品认购金额
                ,SUM(GJ_CO_PROD_PRCH_AMT)         as GJ_CO_PROD_PRCH_AMT           --国君公司产品申购金额
                ,SUM(GJ_CO_PROD_RDMPT_AMT)        as GJ_CO_PROD_RDMPT_AMT          --国君公司产品赎回金额
                ,SUM(GJ_CO_PROD_MTCH_AMT)         as GJ_CO_PROD_MTCH_AMT           --国君公司产品成交金额
                ,SUM(FNCL_PROD_SCRP_AMT)          as FNCL_PROD_SCRP_AMT            --金融产品认购金额
                ,SUM(FNCL_PROD_RDMPT_AMT)         as FNCL_PROD_RDMPT_AMT           --金融产品赎回金额
                ,SUM(FNCL_PROD_MTCH_AMT)          as FNCL_PROD_MTCH_AMT            --金融产品成交金额
                ,SUM(OTC_FND_SCRP_SHR)            as OTC_FND_SCRP_SHR              --场外基金认购份额
                ,SUM(OTC_FND_PRCH_SHR)            as OTC_FND_PRCH_SHR              --场外基金申购份额	
                ,SUM(OTC_FND_RDMPT_SHR)           as OTC_FND_RDMPT_SHR             --场外基金赎回份额
                ,SUM(OTC_FND_MTCH_SHR)            as OTC_FND_MTCH_SHR              --场外基金成交份额
                ,SUM(CO_PROD_SCRP_SHR)            as CO_PROD_SCRP_SHR              --公司自管产品认购份额
                ,SUM(CO_PROD_PRCH_SHR)            as CO_PROD_PRCH_SHR              --公司自管产品申购份额	
                ,SUM(CO_PROD_RDMPT_SHR)           as CO_PROD_RDMPT_SHR             --公司自管产品赎回份额
                ,SUM(CO_PROD_MTCH_SHR)            as CO_PROD_MTCH_SHR              --公司自管产品成交份额
                ,SUM(GJ_CO_PROD_SCRP_SHR)         as GJ_CO_PROD_SCRP_SHR           --国君公司产品认购份额
                ,SUM(GJ_CO_PROD_PRCH_SHR)         as GJ_CO_PROD_PRCH_SHR           --国君公司产品申购份额
                ,SUM(GJ_CO_PROD_RDMPT_SHR)        as GJ_CO_PROD_RDMPT_SHR          --国君公司产品赎回份额
                ,SUM(GJ_CO_PROD_MTCH_SHR)         as GJ_CO_PROD_MTCH_SHR           --国君公司产品成交份额
                ,SUM(FNCL_PROD_SCRP_SHR)          as FNCL_PROD_SCRP_SHR            --金融产品认购份额
                ,SUM(FNCL_PROD_RDMPT_SHR)         as FNCL_PROD_RDMPT_SHR           --金融产品赎回份额
                ,SUM(FNCL_PROD_MTCH_SHR)          as FNCL_PROD_MTCH_SHR            --金融产品成交份额	
                ,SUM(OTC_FND_SCRP_CMSN_FEE)       as OTC_FND_SCRP_CMSN_FEE         --场外基金认购手续费
                ,SUM(OTC_FND_PRCH_CMSN_FEE)       as OTC_FND_PRCH_CMSN_FEE         --场外基金申购手续费	
                ,SUM(OTC_FND_RDMPT_CMSN_FEE)      as OTC_FND_RDMPT_CMSN_FEE        --场外基金赎回手续费
                ,SUM(OTC_FND_MTCH_CMSN_FEE)       as OTC_FND_MTCH_CMSN_FEE         --场外基金成交手续费
                ,SUM(CO_PROD_SCRP_CMSN_FEE)       as CO_PROD_SCRP_CMSN_FEE         --公司自管产品认购手续费
                ,SUM(CO_PROD_PRCH_CMSN_FEE)       as CO_PROD_PRCH_CMSN_FEE         --公司自管产品申购手续费	
                ,SUM(CO_PROD_RDMPT_CMSN_FEE)      as CO_PROD_RDMPT_CMSN_FEE        --公司自管产品赎回手续费
                ,SUM(CO_PROD_MTCH_CMSN_FEE)       as CO_PROD_MTCH_CMSN_FEE         --公司自管产品成交手续费
                ,SUM(GJ_CO_PROD_SCRP_CMSN_FEE)    as GJ_CO_PROD_SCRP_CMSN_FEE      --国君公司产品认购手续费
                ,SUM(GJ_CO_PROD_PRCH_CMSN_FEE)    as GJ_CO_PROD_PRCH_CMSN_FEE      --国君公司产品申购手续费
                ,SUM(GJ_CO_PROD_RDMPT_CMSN_FEE)   as GJ_CO_PROD_RDMPT_CMSN_FEE     --国君公司产品赎回手续费
                ,SUM(GJ_CO_PROD_MTCH_CMSN_FEE)    as GJ_CO_PROD_MTCH_CMSN_FEE      --国君公司产品成交手续费
                ,SUM(FNCL_PROD_SCRP_CMSN_FEE)     as FNCL_PROD_SCRP_CMSN_FEE       --金融产品认购手续费
                ,SUM(FNCL_PROD_RDMPT_CMSN_FEE)    as FNCL_PROD_RDMPT_CMSN_FEE      --金融产品赎回手续费
                ,SUM(FNCL_PROD_MTCH_CMSN_FEE)     as FNCL_PROD_MTCH_CMSN_FEE       --金融产品成交手续费
                ,SUM(OTC_FND_RTN_CMSN_FEE)        as OTC_FND_RTN_CMSN_FEE          --场外基金返回手续费    
                ,SUM(CO_PROD_RTN_CMSN_FEE)        as CO_PROD_RTN_CMSN_FEE          --公司自管产品返回手续费
                ,SUM(GJ_CO_PROD_RTN_CMSN_FEE)     as GJ_CO_PROD_RTN_CMSN_FEE       --国君公司产品返回手续费
                ,SUM(FNCL_PROD_RTN_CMSN_FEE)      as FNCL_PROD_RTN_CMSN_FEE        --金融产品返回手续费
                ,SUM(OTC_FND_SCRP_ITMS)           as OTC_FND_SCRP_ITMS            --场外基金认购笔数
                ,SUM(OTC_FND_PRCH_ITMS)           as OTC_FND_PRCH_ITMS            --场外基金申购笔数	
                ,SUM(OTC_FND_RDMPT_ITMS)          as OTC_FND_RDMPT_ITMS           --场外基金赎回笔数
                ,SUM(OTC_FND_MTCH_ITMS)           as OTC_FND_MTCH_ITMS            --场外基金成交笔数
                ,SUM(CO_PROD_SCRP_ITMS)           as CO_PROD_SCRP_ITMS            --公司自管产品认购笔数
                ,SUM(CO_PROD_PRCH_ITMS)           as CO_PROD_PRCH_ITMS            --公司自管产品申购笔数	
                ,SUM(CO_PROD_RDMPT_ITMS)          as CO_PROD_RDMPT_ITMS           --公司自管产品赎回笔数
                ,SUM(CO_PROD_MTCH_ITMS)           as CO_PROD_MTCH_ITMS            --公司自管产品成交笔数
                ,SUM(GJ_CO_PROD_SCRP_ITMS)        as GJ_CO_PROD_SCRP_ITMS         --国君公司产品认购笔数
                ,SUM(GJ_CO_PROD_PRCH_ITMS)        as GJ_CO_PROD_PRCH_ITMS         --国君公司产品申购笔数
                ,SUM(GJ_CO_PROD_RDMPT_ITMS)       as GJ_CO_PROD_RDMPT_ITMS        --国君公司产品赎回笔数
                ,SUM(GJ_CO_PROD_MTCH_ITMS)        as GJ_CO_PROD_MTCH_ITMS         --国君公司产品成交笔数
                ,SUM(FNCL_PROD_SCRP_ITMS)         as FNCL_PROD_SCRP_ITMS          --金融产品认购笔数
                ,SUM(FNCL_PROD_RDMPT_ITMS)        as FNCL_PROD_RDMPT_ITMS         --金融产品赎回笔数
                ,SUM(FNCL_PROD_MTCH_ITMS)         as FNCL_PROD_MTCH_ITMS          --金融产品成交笔数
                ,SUM(OTC_FND_TFR_IN_MKTVAL)       as OTC_FND_TFR_IN_MKTVAL        --场外基金转入市值
                ,SUM(OTC_FND_TFR_OUT_MKTVAL)      as OTC_FND_TFR_OUT_MKTVAL       --场外基金转出市值
                ,SUM(OTC_FND_NET_TFR_IN_MKTVAL)   as OTC_FND_NET_TFR_IN_MKTVAL    --场外基金净转入市值
			    ,SUM(CO_PROD_TFR_IN_MKTVAL)       as CO_PROD_TFR_IN_MKTVAL        --公司自管产品转入市值
			    ,SUM(CO_PROD_TFR_OUT_MKTVAL)      as CO_PROD_TFR_OUT_MKTVAL       --公司自管产品转出市值
			    ,SUM(CO_PROD_NET_TFR_IN_MKTVAL)   as CO_PROD_NET_TFR_IN_MKTVAL    --公司自管产品净转入市值
			    ,SUM(GJ_CO_PROD_TFR_IN_MKTVAL)    as GJ_CO_PROD_TFR_IN_MKTVAL     --国君公司产品转入市值
			    ,SUM(GJ_CO_PROD_TFR_OUT_MKTVAL)   as GJ_CO_PROD_TFR_OUT_MKTVAL    --国君公司产品转出市值
			    ,SUM(GJ_CO_PROD_NET_TFR_IN_MKTVAL)as GJ_CO_PROD_NET_TFR_IN_MKTVAL --国君公司产品净转入市值
			    ,SUM(FNCL_PROD_TFR_IN_MKTVAL)     as FNCL_PROD_TFR_IN_MKTVAL      --金融产品转入市值
			    ,SUM(FNCL_PROD_TFR_OUT_MKTVAL)    as FNCL_PROD_TFR_OUT_MKTVAL     --金融产品转出市值
                ,SUM(FNCL_PROD_NET_TFR_IN_MKTVAL) as FNCL_PROD_NET_TFR_IN_MKTVAL  --金融产品净转入市值
			    ,SUM(PROD_TFR_IN_MKTVAL)          as PROD_TFR_IN_MKTVAL           --产品转入总市值
                ,SUM(PROD_TFR_OUT_MKTVAL)         as PROD_TFR_OUT_MKTVAL          --产品转出总市值
                ,SUM(PROD_NET_TFR_IN_MKTVAL)      as PROD_NET_TFR_IN_MKTVAL       --产品净转入总市值				
                ,%d{yyyyMMdd}                         as ETL_DT
 FROM           DDW_PROD.T_DDW_F10_TRD_CUST_PROD_TRD_AGGR_DAY   t
 WHERE          t.BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
 GROUP BY       CUST_NO,CUST_CGY,BRH_NO,ETL_DT
 ;

-----------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_TRD_CUST_PROD_TRD_AGGR_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F10_TRD_CUST_PROD_TRD_AGGR_MON;
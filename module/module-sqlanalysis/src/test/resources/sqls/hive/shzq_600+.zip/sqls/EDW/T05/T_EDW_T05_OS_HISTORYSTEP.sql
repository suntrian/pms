--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:操作流程历史表                                                                           */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  

------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T05_OS_HISTORYSTEP
(
                                    ID              --ID
                                   ,ENTRY_ID        --wtentry ID
                                   ,STEP_ID         --步骤ID
                                   ,ACTION_ID       --操作ID
                                   ,OWNER           --分配执行人
                                   ,START_DATE      --开始时间
                                   ,FINISH_DATE     --结束时间
                                   ,DUE_DATE        --有效时间
                                   ,STATUS          --状态
                                   ,CALLER          --执行人
                                   ,FLAG            --标志
                                   ,SUMMARY         --摘要
                                   ,CONSIGNER       --委托人
								   ,XTBS         
) 
PARTITION( bus_date)
SELECT 
                                    t.ID              as ID              --ID
                                   ,t.ENTRY_ID        as ENTRY_ID        --wtentry ID
                                   ,t.STEP_ID         as STEP_ID         --步骤ID
                                   ,t.ACTION_ID       as ACTION_ID       --操作ID
                                   ,t.OWNER           as OWNER           --分配执行人
                                   ,t.START_DATE      as START_DATE      --开始时间
                                   ,t.FINISH_DATE     as FINISH_DATE     --结束时间
                                   ,t.DUE_DATE        as DUE_DATE        --有效时间
                                   ,t.STATUS          as STATUS          --状态
                                   ,t.CALLER          as CALLER          --执行人
                                   ,t.FLAG            as FLAG            --标志
                                   ,t.SUMMARY         as SUMMARY         --摘要
                                   ,t.CONSIGNER       as CONSIGNER       --委托人
                                   ,'YGT'		      as XTBS  					   
                                   ,CAST(CASE WHEN a1.NAT_DT = a1.TRD_DT
      				                          THEN a1.TRD_DT
					                          WHEN a1.NAT_DT < > a1.TRD_DT
					                          THEN a2.TRD_DT
					                          END as INT
									     )  as BUS_DATE
 FROM 		    YGTCX.CIF_OS_HISTORYSTEP 				t
 LEFT JOIN      EDW_PROD.T_EDW_T99_TRD_DATE  a1
 ON             CAST(CONCAT(SUBSTR(t.start_date,1,4),SUBSTR(t.start_date,6,2),SUBSTR(t.start_date,9,2)) as INT) = a1.NAT_DT
 AND            a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN      EDW_PROD.T_EDW_T99_TRD_DATE    a2
 ON             a2.NAT_DT = a2.TRD_DT
 AND            a2.BUS_DATE = %d{yyyyMMdd}
 AND            a1.TRD_DT = a2.LST_TRD_D
 WHERE   CAST(a1.TRD_DT as STRING) BETWEEN EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,-20)  AND '%d{yyyyMMdd}' 
 AND     t.DT = '%d{yyyyMMdd}'
 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_OS_HISTORYSTEP',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_OS_HISTORYSTEP;
 

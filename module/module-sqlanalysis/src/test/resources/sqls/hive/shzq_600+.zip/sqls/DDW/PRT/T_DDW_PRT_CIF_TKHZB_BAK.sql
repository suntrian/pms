INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CIF_TKHZB
(          ID	         --自增序号
          ,RQ	         --日期
          ,KHH	         --客户号
          ,ZBDM	         --指标代码
          ,ZBZ	         --指标值  
) 
 SELECT   ID	         --自增序号
          ,RQ	         --日期
          ,KHH	         --客户号
          ,ZBDM	         --指标代码
          ,ZBZ	         --指标值 
 FROM DDW_PROD.T_DDW_PRT_CIF_TKHZB1 ;
 invalidate metadata DDW_PROD.T_DDW_PRT_CIF_TKHZB ;
 
 DELETE FROM DDW_PROD.T_DDW_PRT_CIF_TKHZB_KUDU;
 INSERT INTO DDW_PROD.T_DDW_PRT_CIF_TKHZB_KUDU
(         U_ID
          ,ID	         --自增序号
          ,RQ	         --日期
          ,KHH	         --客户号
          ,ZBDM	         --指标代码
          ,ZBZ	         --指标值  
) 
 SELECT   REPLACE(UUID(),'-','')
           ,ID	         --自增序号
          ,RQ	         --日期
          ,KHH	         --客户号
          ,ZBDM	         --指标代码
          ,ZBZ	         --指标值 
 FROM DDW_PROD.T_DDW_PRT_CIF_TKHZB1 ;
 invalidate metadata DDW_PROD.T_DDW_PRT_CIF_TKHZB_KUDU ;
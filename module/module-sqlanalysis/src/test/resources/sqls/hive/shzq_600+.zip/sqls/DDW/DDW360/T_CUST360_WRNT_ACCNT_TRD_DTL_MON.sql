 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360期权账户交易明细月表                                                       */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-10-27                                                                       */ 
  


---------------- 插入数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_WRNT_ACCNT_TRD_DTL_MON
 (
	 STATS_MON                --统计年月
	,CUST_NO                  --客户号
	,WRNT_CTC_CD              --期权合约代码
	,WRNT_CTC_CD_NAME         --期权名称
	,WRNT_TP                  --期权类型
	,WRNT_BS_DRCT             --期权买卖方向
	,WRNT_OPN_CP_FLG          --开平标志
	,WRNT_CVD_LABL            --期权备兑标签
	,EXG                      --交易所
	,MTCH_QTY                 --成交数量
	,MTCH_AMT                 --成交金额
	,S1                       --佣金
 )PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT      CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)                as STATS_MON                --统计年月
            ,t.CUST_NO                 as CUST_NO                  --客户号
            ,t.WRNT_CTC_CD             as WRNT_CTC_CD              --期权合约代码
			,t.WRNT_CTC_SHRTNM         as WRNT_CTC_CD_NAME         --期权名称
            ,a1.WRNT_TP_NAME           as WRNT_TP                  --期权类型
            ,a3.WRNT_BS_DRCT_NAME      as WRNT_BS_DRCT             --期权买卖方向
            ,a4.WRNT_OPN_CP_FLG_NAME   as WRNT_OPN_CP_FLG          --开平标志
            ,a5.WRNT_CVD_LABL_NAME     as WRNT_CVD_LABL            --期权备兑标签  
			,a2.EXG_NAME               as EXG                      --交易所
            ,SUM(MTCH_QTY)             as MTCH_QTY                 --成交数量
            ,SUM(MTCH_AMT)             as MTCH_AMT                 --成交金额
            ,SUM(S1)                   as S1                       --佣金
 FROM         DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS        t
 LEFT JOIN    DDW_PROD.V_WRNT_TP                           a1
 ON           t.WRNT_TP = a1.WRNT_TP
 LEFT JOIN    DDW_PROD.V_EXG                               a2
 ON           t.EXG = a2.EXG
 LEFT JOIN    DDW_PROD.V_WRNT_BS_DRCT                       a3
 ON           t.WRNT_BS_DRCT = a3.WRNT_BS_DRCT
 LEFT JOIN    DDW_PROD.V_WRNT_OPN_CP_FLG                    a4
 ON           t.WRNT_OPN_CP_FLG = a4.WRNT_OPN_CP_FLG
 LEFT JOIN    DDW_PROD.V_WRNT_CVD_LABL                      a5
 ON           t.WRNT_CVD_LABL = a5.WRNT_CVD_LABL        
 WHERE        t.WRNT_TP < > '#'
 AND          SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
 GROUP BY   STATS_MON,CUST_NO,WRNT_CTC_CD,WRNT_CTC_CD_NAME,WRNT_TP,WRNT_BS_DRCT,WRNT_OPN_CP_FLG,WRNT_CVD_LABL,EXG 
 
 
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_WRNT_ACCNT_TRD_DTL_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_WRNT_ACCNT_TRD_DTL_MON;
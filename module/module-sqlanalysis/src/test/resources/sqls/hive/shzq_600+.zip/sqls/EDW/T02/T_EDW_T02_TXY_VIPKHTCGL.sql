 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:VIP客户头寸管理表                                                                  */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TXY_VIPKHTCGL;  
------插入数据开始------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TXY_VIPKHTCGL(
                                    YYB                                                        --营业部                         
                                   ,TYPE                                                       --类型                          
                                   ,KHH                                                        --客户号                         
                                   ,KHQZ                                                       --客户群组                        
                                   ,ZRT_TCLX                                                   --头寸类型                        
                                   ,XGRQ                                                       --修改日期                        
                                   ,XTBS                                                      --系统标识                                                                                                                                            							   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                               as YYB                                                        --营业部                              
                                   ,t.LX                                as TYPE                                                       --类型                               
                                   ,t.KHH                               as KHH                                                        --客户号                              
                                   ,t.KHQZ                              as KHQZ                                                       --客户群组                             
                                   ,t.TCLX                              as ZRT_TCLX                                                   --头寸类型                             
                                   ,t.BDRQ                              as XGRQ                                                       --修改日期                             
                                   ,'RZRQ'                              as XTBS                                                      --系统标识                                                      							   
 FROM      RZRQCX.MARGIN_TXY_VIPKHTCGL t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'RZRQ'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE     t.DT = '%d{yyyyMMdd}';
-------插入数据结束------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TXY_VIPKHTCGL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TXY_VIPKHTCGL;
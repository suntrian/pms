 /* ***************************************** SQL Begin ******************************************/
 /* 脚本功能:已注销经纪人客户表                                                                     */
 /* 创建人:黄勇华                                                                              */
 /* 创建时间:2016-12-10                                                                        */ 
 /* 修改时间:2017-03-07                                                                       */ 
 

 
  TRUNCATE TABLE DDW_PROD.T_DDW_PRT_ED_CNCL_BROK_CUST;
--删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ED_CNCL_BROK_CUST_TEMP;
 
--创建临时表
 CREATE TABLE DDW_PROD.T_DDW_PRT_ED_CNCL_BROK_CUST_TEMP
 as
 SELECT  SUM(ORDI_TRD_VOL_RMB+CRD_TRD_VOL+WRNT_TRD_VOL+WRNT_S1_INCM) AS MTCH_AMT
        ,SUM(ORDI_S1_INCM_RMB+CRD_S1_INCM+WRNT_S1_INCM+WRNT_S1_INCM) AS ACCNGROSS_CMSN
		,SUM(PROD_SCRP_AMT  +PROD_PRCH_AMT  +PROD_FIXINV_AMT+PROD_RDMPT_AMT) AS PROD_MTCH_AMT --代销金融产品确认金额
		,CUST_NO 
 FROM   DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
 WHERE (BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}) 
 GROUP BY CUST_NO
 ;
 


-------------插入数据开始--------------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_ED_CNCL_BROK_CUST
(
                                     BRH_NO                          --营业部编号      
                                    ,BRH_NAME                        --营业部名称      
                                    ,BRK_NO                          --经纪人编号      
                                    ,BRK_CGY                         --经纪人类别    
                                    ,BRK_NAME                        --经纪人姓名 
                                    ,BRK_BELTO_BRH                   --经纪人所属营业部									
                                    ,OPNAC_DT                        --开户日期       
                                    ,OPNAC_MOD                       --开户方式       
                                    ,CUST_NO                         --客户号        
                                    ,CUST_NAME                       --客户姓名       
                                    ,CTF_CGY_CD                      --证件类别代码     
                                    ,CTF_NO                          --证件号码       
                                    ,DEPMGT_BANK                     --存管银行       
                                    ,CTRL_ATTR                       --控制属性     
                                    ,IMAGE_TP                        --影像资料       
                                    ,M_LAUND_RSK_LVL                 --洗钱风险等级     
                                    ,RSK_BEAR_ABLTY                  --风险承受能力     
                                    ,CTF_EXPR_DT                     --证件截止日期    
                                    ,CTCT_ADDR                       --联系地址      
                                    ,CTCT_TEL                        --联系电话      
                                    ,PHONE                           --手机        
                                    ,EDU_CD                          --学历代码      
                                    ,OCP_CD                          --职业代码
                                    ,CMSN_SETUP_DT                   --佣金设置日期
                                    ,CMSN_SETUP_ABST                 --佣金设置摘要										
                                    ,MTCH_AMT                        --成交金额     
                                    ,GROSS_CMSN                      --毛佣金      				
                                    ,IF_OPN_PHONE_ODR                --是否开通手机委托 
								    ,IF_OPN_STATMT                   --是否开通对账单
			                        ,RSK_HINT_CNFM_CNDT              --风险提示及确认书
									,BRK_RLN_TML_DT                  --经纪关系终止日期
									,T3IP_DEPMGT_TURNOUT			 --三方转出
                                    ,PROD_MTCH_AMT                   --代销金融产品确认金额
								  --  ,WHITELIST_TMS                                     --白名单次数    
                                   -- ,BLACKLIST_TMS                                     --黑名单次数    



) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                                    t.BRH_NO                         as BRH_NO                                            --营业部编号                                              
                                   ,t.BRH_NAME                       as BRH_NAME                                          --营业部名称                                              
                                   ,t.BRK_NO                         as BRK_NO                                            --经纪人编号                                              
                                   ,a2.PSN_CGY_NAME                  as BRK_CGY                                           --经纪人类别                                                                               
                                   ,t.BRK_NAME                       as BRK_NAME                                          --经纪人姓名  
                                   ,t.BRK_BELTO_BRH                  as BRK_BELTO_BRH                                     --经纪人所属营业部								   
                                   ,a1.ORDI_OPNAC_DT                      as OPNAC_DT                                          --开户日期                                               
                                   ,a3.OPNAC_MOD_NAME                as OPNAC_MOD                                         --开户方式                                               
                                   ,a1.CUST_NO                       as CUST_NO                                           --客户号                                                
                                   ,a1.CUST_NAME                     as CUST_NAME                                         --客户姓名                                               
                                   ,a4.CTF_CGY_CD_NAME               as CTF_CGY_CD                                        --证件类别代码                                             
                                   ,a1.CTF_NO                        as CTF_NO                                            --证件号码                                               
                                   ,a1.DEPMGT_BANK                   as DEPMGT_BANK                                       --存管银行                                               
                                   ,a1.CTRL_ATTR                     as CTRL_ATTR                                         --控制属性                                         
                                   ,a1.IMAGE_TP                      as IMAGE_TP                                          --影像资料                                               
                                   ,b6.M_LAUND_RSK_LVL_NAME               as M_LAUND_RSK_LVL                                   --洗钱风险等级                                             
                                   ,a5.RSK_BEAR_ABLTY_NAME           as RSK_BEAR_ABLTY                                    --风险承受能力                                             
                                   ,a1.CTF_EXPR_DT                   as CTF_EXPR_DT                                       --证件截止日期                                                                                                                      
                                   ,a1.CTCT_ADDR                     as CTCT_ADDR                                         --联系地址                                               
                                   ,a1.CTCT_TEL                      as CTCT_TEL                                          --联系电话                                                                         
                                   ,a1.PHONE                         as PHONE                                             --手机                                                                                  
                                   ,a6.EDU_CD_NAME                   as EDU_CD                                            --学历代码                                               
                                   ,a7.OCP_CD_NAME                   as OCP_CD                                            --职业代码  
                                   ,a1.CMSN_SETUP_DT                 as CMSN_SETUP_DT                                     --佣金设置日期
                                   ,a1.CMSN_SETUP_ABST               as CMSN_SETUP_ABST                                   --佣金设置摘要							   
                                   ,NVL(a8.MTCH_AMT,0)               as MTCH_AMT                                          --成交金额           
                                   ,NVL(a8.ACCNGROSS_CMSN,0)         as ACCNGROSS_CMSN                                    --毛佣金      						   
                                   ,a1.IF_OPN_PHONE_ODR              as IF_OPN_PHONE_ODR                                  --是否开通手机委托
                                   ,t.IF_OPN_STATMT                  as IF_OPN_STATMT                                     --是否开通对账单	
                                   ,t.RSK_HINT_CNFM_CNDT             as RSK_HINT_CNFM_CNDT                                --风险提示及确认书
                                   ,t.BRK_RLN_TML_DT                 as BRK_RLN_TML_DT                                    --经纪关系终止日期
								   ,NVL(a9.T3IP_DEPMGT_TURNOUT,0)    as	T3IP_DEPMGT_TURNOUT									--近二年第三方存管转出累计数								   
                                   --,NVL(a2.WHITELIST_TMS,0)          as WHITELIST_TMS                                     --白名单次数          
                                   --,NVL(a3.BLACKLIST_TMS,0)          as BLACKLIST_TMS                                     --黑名单次数          
                                  ,NVL(a8.PROD_MTCH_AMT,0)         as PROD_MTCH_AMT                   --代销金融产品确认金额
   FROM          DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN                                            t
   LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO                                               a1
   ON            t.CUST_NO = a1.CUST_NO
   AND           t.BUS_DATE = a1.BUS_DATE 
    LEFT JOIN     DDW_PROD.V_PSN_CGY                           								a2
   ON            t.BRK_CGY = a2.PSN_CGY							
   LEFT JOIN     DDW_PROD.V_OPNAC_MOD                     									a3
   ON            a1.OPNAC_MOD = a3.OPNAC_MOD							
   LEFT JOIN     DDW_PROD.V_CTF_CGY_CD                   									a4
   ON            a1.CTF_CGY_CD = a4.CTF_CGY_CD									
   LEFT JOIN     DDW_PROD.V_RSK_BEAR_ABLTY               									a5
   ON            a1.RSK_BEAR_ABLTY = a5.RSK_BEAR_ABLTY									
   LEFT JOIN     DDW_PROD.V_EDU_CD                       									a6
   ON            a1.EDU_CD = a6.EDU_CD 									
   LEFT JOIN     DDW_PROD.V_OCP_CD                       									a7
   ON            a1.OCP_CD = a7.OCP_CD     
   LEFT JOIN 	 DDW_PROD.T_DDW_PRT_ED_CNCL_BROK_CUST_TEMP									a8
   ON			 t.CUST_NO = a8.CUST_NO
  
   LEFT JOIN (SELECT CUST_NO,SUM(CRD_WTHDR_AMT+ORDI_WTHDR_AMT_RMB+WRNT_WTHDR_AMT) AS T3IP_DEPMGT_TURNOUT 
              FROM    DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
			  WHERE   BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND  %d{yyyyMMdd} 			  
			  GROUP BY CUST_NO
   )	a9
   ON			 t.CUST_NO = a9.CUST_NO
 --  LEFT JOIN     (SELECT CLIENT_ID             AS CUST_NO
           --             ,CAST(DT AS INT)       AS BUS_DATE  
				--		,COUNT(1)              AS WHITELIST_TMS 
				--  FROM HSFK.HSMAN_CRM_CLIENTWHITELIST
				--  GROUP BY CLIENT_ID,CAST(DT AS INT)
				--  )                                                                          a2
   --ON             t.CUST_NO = TRIM(a2.CUST_NO)
  -- AND            t.BUS_DATE = a2.BUS_DATE
   --LEFT JOIN    (SELECT  a1.CUST_NO,COUNT(1) AS BLACKLIST_TMS
        --          FROM    (SELECT CLIENT_ID AS CUST_NO,HOLDER_NAME AS CZZD,MIN(OC_DATE) AS DT 
		--		            FROM HSFK.HSMAN_HISICSENTRUST a							
	--						GROUP BY a.CLIENT_ID,a.HOLDER_NAME
		--				   ) a1
		--				   WHERE NOT EXISTS (SELECT 1 FROM HSFK.HSMAN_CRM_CLIENTWHITELIST a2
		--					                         WHERE a1.CUST_NO = a2.CLIENT_ID 
		--											 AND   a2.DT = '%d{yyyyMMdd}'
		--									)
		--		  GROUP BY a1.CUST_NO
         --        )	                                                                          a3
   --ON            t.CUST_NO = TRIM(a3.CUST_NO)
LEFT JOIN  DDW_PROD.V_M_LAUND_RSK_LVL            b6
  ON         a1.M_LAUND_RSK_LVL = b6.M_LAUND_RSK_LVL   
   WHERE         t.BUS_DATE = %d{yyyyMMdd} 
   AND           t.VLD_BRK_CUST_FLG = -1 
 ;    
   
--删除临时表
 
------结束----   

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ED_CNCL_BROK_CUST_TEMP;


INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_ED_CNCL_BROK_CUST',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
     invalidate metadata DDW_PROD.T_DDW_PRT_ED_CNCL_BROK_CUST; 
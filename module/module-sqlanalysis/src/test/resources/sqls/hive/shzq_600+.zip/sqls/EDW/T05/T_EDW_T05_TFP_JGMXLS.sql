 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:金融产品交割流水表                                                                 */
  --/* 创建人:段智泓                                                                             */
  --/* 创建时间:2018-08-29                                                                 */ 

-------插入数据开始--------------

INSERT OVERWRITE EDW_PROD.T_EDW_T05_TFP_JGMXLS
(
                                 RQ	          --日期 
                                ,YYB	      --营业部  
                                ,QDWD	      --渠道网点 
                                ,LSH	      --流水号  
                                ,SFFS	      --收费方式
                                ,FHFS	      --分红方式 
                                ,KHH	      --客户号  
                                ,KHXM	      --客户名称 
                                ,TZZH	      --投资理财账户 
                                ,JSZH	      --结算帐号/资金账户 
                                ,JSJG	      --结算机构 
                                ,JSLX	      --结算类型 
                                ,JGDM	      --产品机构代码 
                                ,CPDM	      --产品代码 
                                ,CPFL	      --产品类别
                                ,CPLX	      --产品类型 
                                ,JYS	      --交易所 
                                ,YWDM	      --业务代码
                                ,WTRQ	      --委托日期 
                                ,WTH	      --委托号  
                                ,WTFE	      --委托份额 
                                ,WTJE	      --委托金额 
                                ,XYBH	      --协议编号 
                                ,WTFS	      --委托方式 
                                ,FSYYB	      --发生营业部 
                                ,SQBH	      --申请编号 
                                ,CJBH	      --成交编号 
                                ,QRFE	      --确认份额 
                                ,QRJE	      --确认金额 
                                ,CJJG	      --成交价格 
                                ,SXF	      --佣金/手续费  
                                ,BZDM	          --币种 
                                ,DLF	      --推介费/代理费  
                                ,YHS	      --印花税  
                                ,QTF	      --其它费用  
                                ,GHF	      --过户费  
                                ,LX	          --利息 
                                ,LXS	      --利息税  
                                ,ZKL	      --折扣率  
                                ,FYSM	      --费用说明 
                                ,BZXX	      --备注信息 
                                ,ZJYE	      --本次资金余额 
                                ,FEYE	      --本次份额余额 
                                ,FEDJYE	      --本次冻结余额 
                                ,YSJE	      --应收金额 
                                ,JSRQ	      --交收日期 
                                ,YJ_ZGF	      --一级证管费
                                ,YJ_JSF	      --一级经手费
                                ,YJ_CLEARFEE  --一级结算费
                                ,YJ_FXJJ	  --一级风险基金 
                                ,YJ_GHF	      --一级过户费
                                ,YJ_QTF	      --一级其他费用
                                ,HSF	      -- 
                                ,FJF	      -- 
                                ,CJSJ	      --成交时间
                                ,DJBM	      --
                                ,JYZH	      --
								,XTBS         --系统标识
)
PARTITION( bus_date = %d{yyyyMMdd})
SELECT                           
                                 t.RQ	          as RQ              --日期 
                                ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  as YYB          --营业部  
                                ,t.QDWD	          as QDWD            --渠道网点 
                                ,t.LSH	          as LSH             --流水号  
                                ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.SFFS AS VARCHAR(20))),'ERR')) AS DECIMAL(2,0))  as SFFS	      --收费方式
                                ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.FHFS AS VARCHAR(20))),'ERR')) AS DECIMAL(2,0))  as FHFS	      --分红方式 
                                ,t.KHH	          as KHH	         --客户号  
                                ,t.KHXM	          as KHXM	         --客户名称 
                                ,t.TZZH	          as TZZH	         --投资理财账户 
                                ,t.JSZH	          as JSZH	         --结算帐号/资金账户 
                                ,t.JSJG	          as JSJG	         --结算机构 
                                ,t.JSLX	          as JSLX	         --结算类型 
                                ,t.JGDM	          as JGDM	         --产品机构代码 
                                ,t.CPDM	          as CPDM	         --产品代码 
                                ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.CPFL AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))  as CPFL	      --产品类别
                                ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.CPLX AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))  as CPLX	      --产品类型 
                                ,t.JYS	          as JYS	         --交易所 
                                ,t.YWDM	          as YWDM	         --业务代码
                                ,t.WTRQ	          as WTRQ	         --委托日期 
                                ,t.WTH	          as WTH	         --委托号  
                                ,t.WTFE	          as WTFE	         --委托份额 
                                ,t.WTJE	          as WTJE	         --委托金额 
                                ,t.XYBH	          as XYBH	         --协议编号 
                                ,t.WTFS	          as WTFS	         --委托方式 
                                ,t.FSYYB	      as FSYYB	         --发生营业部 
                                ,t.SQBH	          as SQBH	         --申请编号 
                                ,t.CJBH	          as CJBH	         --成交编号 
                                ,t.QRFE	          as QRFE	         --确认份额 
                                ,t.QRJE	          as QRJE	         --确认金额 
                                ,t.CJJG	          as CJJG	         --成交价格 
                                ,t.SXF	          as SXF	         --佣金/手续费  
                                ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS STRING)    as BZ	             --币种 
                                ,t.DLF	          as DLF	         --推介费/代理费  
                                ,t.YHS	          as YHS	         --印花税  
                                ,t.QTF	          as QTF	         --其它费用  
                                ,t.GHF	          as GHF	         --过户费  
                                ,t.LX	          as LX	             --利息 
                                ,t.LXS	          as LXS	         --利息税  
                                ,t.ZKL	          as ZKL	         --折扣率  
                                ,t.FYSM	          as FYSM	         --费用说明 
                                ,t.BZXX	          as BZXX	         --备注信息 
                                ,t.ZJYE	          as ZJYE	         --本次资金余额 
                                ,t.FEYE	          as FEYE	         --本次份额余额 
                                ,t.FEDJYE	      as FEDJYE	         --本次冻结余额 
                                ,t.YSJE	          as YSJE	         --应收金额 
                                ,t.JSRQ	          as JSRQ	         --交收日期 
                                ,t.YJ_ZGF	      as YJ_ZGF	         --一级证管费
                                ,t.YJ_JSF	      as YJ_JSF	         --一级经手费
                                ,t.YJ_CLEARFEE    as YJ_CLEARFEE     --一级结算费
                                ,t.YJ_FXJJ	      as YJ_FXJJ	     --一级风险基金 
                                ,t.YJ_GHF	      as YJ_GHF	         --一级过户费
                                ,t.YJ_QTF	      as YJ_QTF	         --一级其他费用
                                ,t.HSF	          as HSF	         -- 
                                ,t.FJF	          as FJF	         -- 
                                ,t.CJSJ	          as CJSJ	         --成交时间
                                ,t.DJBM	          as DJBM	         --
                                ,t.JYZH	          as JYZH	         --
								,'OTC'            AS XTBS
FROM OTCCX.FPSS_HIS_TFP_JGMXLS t
LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t1
ON             t1.YXT = 'OTC'
AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2
ON             t2.DMLX = 'OTC_SFFS'
AND            t2.YXT = 'OTC'
AND            t2.YDM = CAST(t.SFFS AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3
ON             t3.DMLX = 'OF_FHFS'
AND            t3.YXT = 'OTC'
AND            t3.YDM = CAST(t.SFFS AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4
ON             t4.DMLX = 'OTC_CPFL'
AND            t4.YXT = 'OTC'
AND            t4.YDM = CAST(t.CPFL AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t5
ON             t5.DMLX = 'OTC_CPLX'
AND            t5.YXT = 'OTC'
AND            t5.YDM = CAST(t.CPLX AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t6
ON             t6.DMLX = 'BZDM'
AND            t6.YXT = 'OTC'
AND            t6.YDM = CAST(t.BZ AS VARCHAR(20))
WHERE          t.DT = '%d{yyyyMMdd}';

---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TFP_JGMXLS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_TFP_JGMXLS;
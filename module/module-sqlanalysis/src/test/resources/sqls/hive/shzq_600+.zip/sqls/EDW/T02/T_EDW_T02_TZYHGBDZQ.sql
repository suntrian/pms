 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:质押回购标的证券                                                                  */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZYHGBDZQ ;
----插入数据开始-------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZYHGBDZQ
(
                                    JYS                                 --交易所                                
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQFL                                --证券分类                               
                                   ,RQSX                                --融券上线                               
                                   ,RQ                                  --日期                                 
                                   ,GFXZ                                --股份性质                               
                                   ,TYPE                                --类型                                 
                                   ,ZJYT                                --资金用途                               
                                   ,TDLX                                --通道类型      
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.ZQFL                                as ZQFL                                --证券分类                                
                                   ,t.RQSX                                as RQSX                                --融券上线                                
                                   ,t.RQ                                  as RQ                                  --日期                                  
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.GFXZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as GFXZ                                --股份性质                                
                                   ,t.TYPE                                as TYPE                                --类型                                  
                                   ,t.ZJYT                                as ZJYT                                --资金用途                                
                                   ,t.TDLX                                as TDLX                                --通道类型       
                                   ,'JZJY'								   
 FROM           JZJYCX.SECURITIES_TZYHGBDZQ                  t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING       t1 
 ON             t1.DMLX = 'GFXZ'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.GFXZ AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束----------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZYHGBDZQ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

invalidate metadata EDW_PROD.T_EDW_T02_TZYHGBDZQ;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:证券余额表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 

----------------------------删除今天的数据开始----------
ALTER TABLE EDW_PROD.T_EDW_T02_TZQGL DROP IF EXISTS PARTITION   (BUS_DATE = %d{yyyyMMdd});
------------------------------------删除今天的数据结束-----  

---插入数据开始-----
----插入集中交易的数据
INSERT INTO  EDW_PROD.T_EDW_T02_TZQGL
(
                                     KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFL                                --公司分类代码                             
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,ZQDM                                --证券代码                               
                                   ,XWDM                                --席位代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQLB                                --证券类别                               
                                   ,BZDM                                --币种代码                               
                                   ,ZQSL                                --证券数量                               
                                   ,DJSL                                --冻结数量                               
                                   ,FLTSL                               --非流通数量                              
                                   ,WJSSL                               --未交收数量                              
                                   ,ZXSZ                                --最新市值                               
                                   ,MRWTSL                              --买入委托数量                             
                                   ,MRCJSL                              --买入成交数量                             
                                   ,SHCJSL                              --赎回成交数量                             
                                   ,MRDXSL                              --当日抵消数量                             
                                   ,MRCJJE                              --买入成交金额                             
                                   ,MCCJJE                              --卖出成交金额                             
                                   ,KCRQ                                --开仓日期                               
                                   ,BDRQ                                --变动日期                               
                                   ,MRJE                                --买入金额                               
                                   ,MRSL                                --买入数量                               
                                   ,PGJE                                --配股数量                               
                                   ,MCJE                                --卖出金额                               
                                   ,MCSL                                --卖出数量                               
                                   ,HLJE                                --红利金额                               
                                   ,SGSL                                --申购数量                               
                                   ,JYFY                                --交易费用                               
                                   ,CCCB                                --持仓成本                               
                                   ,LJYK                                --累计盈亏                               
                                   ,PGSL                                --送股数量                               
                                   ,MCWTSL                              --当日卖出委托数量                           
                                   ,MCDXSL                              --可抵消卖出数量                            
                                   ,MCCJSL                              --当日卖出成交数量                                                     
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFL                                --公司分类                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.XWDM                                as XWDM                                --席位代码                                
                                   ,a1.ZQMC                               as ZQMC                                --证券名称                                
                                   ,a1.ZQLB                               as ZQLB                                --证券类别                                
                                   ,CASE WHEN t.JYS IN ('HK','SK')
								         THEN 'HKD'
										 ELSE CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) 
										 END                              as BZDM                                --币种                                  
                                   ,t.ZQSL                                as ZQSL                                --证券数量                                
                                   ,t.DJSL                                as DJSL                                --冻结数量                                
                                   ,t.FLTSL                               as FLTSL                               --非流通数量                               
                                   ,t.WJSSL                               as WJSSL                               --未交收数量                               
                                   ,t.ZXSZ                                as ZXSZ                                --最新市值                                
                                   ,t.MRWTSL                              as MRWTSL                              --买入委托数量                              
                                   ,t.MRCJSL                              as MRCJSL                              --买入成交数量                              
                                   ,t.SHCJSL                              as SHCJSL                              --赎回成交数量                              
                                   ,t.MRDXSL                              as MRDXSL                              --当日抵消数量                              
                                   ,t.MRCJJE                              as MRCJJE                              --买入成交金额                              
                                   ,t.MCCJJE                              as MCCJJE                              --卖出成交金额                              
                                   ,t.KCRQ                                as KCRQ                                --开仓日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.MRJE                                as MRJE                                --买入金额                                
                                   ,t.MRSL                                as MRSL                                --买入数量                                
                                   ,t.PGJE                                as PGJE                                --配股数量                                
                                   ,t.MCJE                                as MCJE                                --卖出金额                                
                                   ,t.MCSL                                as MCSL                                --卖出数量                                
                                   ,t.HLJE                                as HLJE                                --红利金额                                
                                   ,t.SGSL                                as SGSL                                --申购数量                                
                                   ,t.JYFY                                as JYFY                                --交易费用                                
                                   ,t.CCCB                                as CCCB                                --持仓成本                                
                                   ,t.LJYK                                as LJYK                                --累计盈亏                                
                                   ,t.PGSL                                as PGSL                                --送股数量                                
                                   ,t.MCWTSL                              as MCWTSL                              --当日卖出委托数量                            
                                   ,t.MCDXSL                              as MCDXSL                              --可抵消卖出数量                             
                                   ,t.MCCJSL                              as MCCJSL                              --当日卖出成交数量                                                     
                                   ,%d{yyyyMMdd}                             as KSRQ                                --                                    
                                   ,%d{yyyyMMdd}                             as JSRQ                                --                                    
                                   ,'JZJY'                               as XTBS                                --                                    
 FROM           JZJYCX.DATACENTER_TZQGL                t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      JZJYCX.SECURITIES_TZQDM                 a1
 ON              t.JYS = a1.JYS
 AND             t.ZQDM = a1.ZQDM
 AND             t.DT = a1.DT
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t2
 ON             t2.YXT = 'JZJY'
 AND            t2.JGDM = CAST(t.YYB AS VARCHAR(20)) 
 WHERE           t.DT = '%d{yyyyMMdd}'
    AND           (  (t.ZQSL < 0 
                 AND SUBSTR(t.ZQDM,1,3) NOT IN ('700','701','710','711','184')
				 AND SUBSTR(t.ZQDM,1,2) NOT IN ('08','09')
				 AND (SUBSTR(t.ZQDM,1,3) NOT IN ('790','751','730') OR t.KCRQ NOT BETWEEN 20060101 AND 20071231)
                 AND t.ZQDM  NOT IN ('000709','002041','510054','519599','519505','519508','112072','160611','110317')
				 AND t.KCRQ < > 20080627
				 ) OR t.ZQSL > 0
				)   ;

----插入融资融券的数据 
INSERT  INTO  EDW_PROD.T_EDW_T02_TZQGL
(
                                     KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFL                                --公司分类代码                             
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,ZQDM                                --证券代码                               
                                   ,XWDM                                --席位代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQLB                                --证券类别                               
                                   ,BZDM                                --币种代码                               
                                   ,ZQSL                                --证券数量                               
                                   ,DJSL                                --冻结数量                               
                                   ,FLTSL                               --非流通数量                              
                                   ,WJSSL                               --未交收数量                              
                                   ,ZXSZ                                --最新市值                               
                                   ,MRWTSL                              --买入委托数量                             
                                   ,MRCJSL                              --买入成交数量                             
                                   ,SHCJSL                              --赎回成交数量                             
                                   ,MRDXSL                              --当日抵消数量                             
                                   ,MRCJJE                              --买入成交金额                             
                                   ,MCCJJE                              --卖出成交金额                             
                                   ,KCRQ                                --开仓日期                               
                                   ,BDRQ                                --变动日期                               
                                   ,MRJE                                --买入金额                               
                                   ,MRSL                                --买入数量                               
                                   ,PGJE                                --配股数量                               
                                   ,MCJE                                --卖出金额                               
                                   ,MCSL                                --卖出数量                               
                                   ,HLJE                                --红利金额                               
                                   ,SGSL                                --申购数量                               
                                   ,JYFY                                --交易费用                               
                                   ,CCCB                                --持仓成本                               
                                   ,LJYK                                --累计盈亏                               
                                   ,PGSL                                --送股数量                               
                                   ,MCWTSL                              --当日卖出委托数量                           
                                   ,MCDXSL                              --可抵消卖出数量                            
                                   ,MCCJSL                              --当日卖出成交数量                                                     
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFL                                --公司分类                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.XWDM                                as XWDM                                --席位代码                                
                                   ,a1.ZQMC                                as ZQMC                                --证券名称                                
                                   ,a1.ZQLB                                as ZQLB                                --证券类别                                
                                   ,CASE WHEN t.JYS IN ('HK','SK')
								         THEN 'HKD'
										 ELSE CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) 
										 END                              as BZDM                                --币种                                  
                                   ,t.ZQSL                                as ZQSL                                --证券数量                                
                                   ,t.DJSL                                as DJSL                                --冻结数量                                
                                   ,t.FLTSL                               as FLTSL                               --非流通数量                               
                                   ,t.WJSSL                               as WJSSL                               --未交收数量                               
                                   ,t.ZXSZ                                as ZXSZ                                --最新市值                                
                                   ,t.MRWTSL                              as MRWTSL                              --买入委托数量                              
                                   ,t.MRCJSL                              as MRCJSL                              --买入成交数量                              
                                   ,t.SHCJSL                              as SHCJSL                              --赎回成交数量                              
                                   ,t.MRDXSL                              as MRDXSL                              --当日抵消数量                              
                                   ,t.MRCJJE                              as MRCJJE                              --买入成交金额                              
                                   ,t.MCCJJE                              as MCCJJE                              --卖出成交金额                              
                                   ,t.KCRQ                                as KCRQ                                --开仓日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.MRJE                                as MRJE                                --买入金额                                
                                   ,t.MRSL                                as MRSL                                --买入数量                                
                                   ,t.PGJE                                as PGJE                                --配股数量                                
                                   ,t.MCJE                                as MCJE                                --卖出金额                                
                                   ,t.MCSL                                as MCSL                                --卖出数量                                
                                   ,t.HLJE                                as HLJE                                --红利金额                                
                                   ,t.SGSL                                as SGSL                                --申购数量                                
                                   ,t.JYFY                                as JYFY                                --交易费用                                
                                   ,t.CCCB                                as CCCB                                --持仓成本                                
                                   ,t.LJYK                                as LJYK                                --累计盈亏                                
                                   ,t.PGSL                                as PGSL                                --送股数量                                
                                   ,t.MCWTSL                              as MCWTSL                              --当日卖出委托数量                            
                                   ,t.MCDXSL                              as MCDXSL                              --可抵消卖出数量                             
                                   ,t.MCCJSL                              as MCCJSL                              --当日卖出成交数量                                                     
                                   ,%d{yyyyMMdd}                             as KSRQ                                --                                    
                                   ,%d{yyyyMMdd}                             as JSRQ                                --                                    
                                   ,'RZRQ'                               as XTBS                                --                                    
 FROM           RZRQCX.DATACENTER_TZQGL                t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
  LEFT JOIN      JZJYCX.SECURITIES_TZQDM                 a1
 ON              t.JYS = a1.JYS
 AND             t.ZQDM = a1.ZQDM
 AND             t.DT = a1.DT 
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t2
 ON             t2.YXT = 'RZRQ'
 AND            t2.JGDM = CAST(t.YYB AS VARCHAR(20)) 
 WHERE           t.DT = '%d{yyyyMMdd}'
  AND           (  (t.ZQSL < 0 
                 AND SUBSTR(t.ZQDM,1,3) NOT IN ('700','701','710','711','184')
				 AND SUBSTR(t.ZQDM,1,2) NOT IN ('08','09')
				 AND (SUBSTR(t.ZQDM,1,3) NOT IN ('790','751','730') OR t.KCRQ NOT BETWEEN 20060101 AND 20071231)
                 AND t.ZQDM  NOT IN ('000709','002041','510054','519599','519505','519508','112072','160611','110317')
				 AND t.KCRQ < > 20080627
				 ) OR t.ZQSL > 0
				)  ;
	-------插入数据结束-----------------
	INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZQGL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TZQGL;
 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360产品账户交易明细月表                                                       */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-10-27                                                                       */ 
  


---------------- 插入数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_PROD_ACCNT_TRD_DTL_MON
 (
	 STATS_MON             --统计年月 
	,CUST_NO               --客户号
	,PROD_CD               --产品代码
	,PROD_NAME             --产品名称
	,PROD_TP               --产品类型
	,PROD_BIZ_CD           --产品业务代码
	,PROD_BIZ_NAME         --产品业务名称
	,CMSN_FEE              --手续费
	,CCY                   --币种
	,CNFM_SHR              --确认份额
	,CNFM_AMT              --确认金额
    ,PROD_SRC              --产品来源
 )PARTITION( YEAR_MON  = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT      CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)                as STATS_MON             --统计年月 
            ,t.CUST_NO                 as CUST_NO               --客户号
            ,t.PROD_CD                 as PROD_CD               --产品代码
			,t.PROD_NAME               as PROD_NAME             --产品名称
            ,CASE WHEN t.PROD_CGY = 8 AND SUBSTR(t.PROD_CD,1,1) = 'A'
			      THEN '公司资管产品'
				  WHEN t.PROD_CGY = 8 AND SUBSTR(t.PROD_CD,1,2) = '95'
				  THEN '国泰君安资管产品'
				  WHEN t.PROD_CGY = 9 
				  THEN '银行产品'
				  ELSE '场外基金' 
				  END                  as PROD_TP               --产品类型
            ,t.PROD_BIZ_CD             as PROD_BIZ_CD           --产品业务代码
            ,a1.YWMC                   as PROD_BIZ_NAME         --产品业务名称
            ,t.CMSN_FEE                as CMSN_FEE              --手续费
			,a2.CCY_CD_NAME            as CCY                   --币种
            ,t.CNFM_SHR                as CNFM_SHR              --确认份额
            ,t.CNFM_AMT                as CNFM_AMT              --确认金额
			,DECODE(t.PROD_CGY,8,'场外基金',9,'金融产品') as PROD_SRC              --产品来源
 FROM         DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS        t
 LEFT JOIN    EDW_PROD.T_EDW_T99_TOF_YWDM                 a1
 ON           t.PROD_BIZ_CD = a1.YWDM
 AND          a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN    DDW_PROD.V_CCY_CD                     a2
 ON           t.CCY_CD = a2.CCY_CD      
 WHERE        t.PROD_BIZ_CD IN ('122','124','142','139','130')
AND          SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 ;             
 
---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_PROD_ACCNT_TRD_DTL_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_PROD_ACCNT_TRD_DTL_MON;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:证书信息表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
TRUNCATE TABLE EDW_PROD.T_EDW_T02_TCERT; 
-------插入数据开始--------------
insert overwrite EDW_PROD.T_EDW_T02_TCERT(
                                    TCERT_ID                            --证书信息主键                             
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,KHQC                                --客户全称                               
                                   ,SZZS_BFJG                           --数字证书颁发机构                           
                                   ,YYBID                               --营业部ID                              
                                   ,YYB                                 --营业部                                
                                   ,YYBMC                               --营业部名称                              
                                   ,GJDM                                --国籍代码                               
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,MOBILE                              --手机号                                
                                   ,EMAIL                               --电子邮件                               
                                   ,CKH                                 --参考号                                
                                   ,AUTHCODE                            --授权码                                
                                   ,SN                                  --SN                                 
                                   ,SZZS_ZSLX                           --数字证书证书类型                           
                                   ,SQFS                                --证书申请方式                             
                                   ,DN                                  --DN                                 
                                   ,ZT                                  --状态                                 
                                   ,XGSJ                                --修改时间                               
                                   ,QSSJ                                --起始时间                               
                                   ,JSSJ                                --结束时间  
                                   ,XTBS                         								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
select 
                                    t.ID                                  as TCERT_ID                            --ID                                  
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.KHQC                                as KHQC                                --客户全称                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BFJG AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SZZS_BFJG                           --颁发机构                                
                                   ,t.YYBID                               as YYBID                               --营业部ID                               
                                   ,CAST(COALESCE(t5.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --营业部                                 
                                   ,t.YYBMC                               as YYBMC                               --营业部名称                               
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.GJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as GJDM                                --国籍                                  
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,t.MOBILE                              as MOBILE                              --手机号                                 
                                   ,t.EMAIL                               as EMAIL                               --电子邮件                                
                                   ,t.CKH                                 as CKH                                 --参考号                                 
                                   ,t.AUTHCODE                            as AUTHCODE                            --授权码                                 
                                   ,t.SN                                  as SN                                  --SN                                  
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.LX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as SZZS_ZSLX                           --证书类型                                
                                   ,t.SQFS                                as SQFS                                --证书申请方式                              
                                   ,t.DN                                  as DN                                  --DN                                  
                                   ,t.STATUS                              as ZT                                  --状态                                  
                                   ,t.MODIFYTIME                          as XGSJ                                 --修改时间                                
                                   ,t.STARTTIME                           as QSSJ                                --起始时间                                
                                   ,t.ENDTIME                             as JSSJ                                --结束时间  
                                   ,'YGT'							   
 FROM           YGTCX.CIF_TCERT                        t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'SZZS_BFJG'
 AND            t1.YXT = 'YGT'
 AND            t1.YDM = CAST(t.BFJG AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'GJDM'
 AND            t2.YXT = 'YGT'
 AND            t2.YDM = CAST(t.GJ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'ZJLBDM'
 AND            t3.YXT = 'YGT_GT'
 AND            t3.YDM = CAST(t.ZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
 ON             t4.DMLX = 'SZZS_ZSLX'
 AND            t4.YXT = 'YGT'
 AND            t4.YDM = CAST(t.LX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t5
 ON             t5.YXT = 'CIF'
 AND            t5.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TCERT',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TCERT;
--/* ***************************************** SQL Begin *****************************************   */
  --/* 脚本功能:领导驾驶舱月指标表                                                                  */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2016-11-02                                                                        */ 

 ------插入来源于万德资讯的指标(净资产,净利润,营业收入,股基市场份额(包括它的同比,环比,券商排名等))
 ------删除初始化
  ALTER TABLE DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON DROP IF EXISTS PARTITION (YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT));
  ALTER TABLE DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON DROP IF EXISTS PARTITION (YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT));
 -----净资产指标的插入
 INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'NET_AST'     as CODE
           ,YEAR_MON     as DIM_MON
		   ,NULL         as DIM_ORG
		   ,NULL         as VALUE_STR
		   ,NET_AST      as VALUE
		   ,%d{yyyyMMdd}     as ETL_DATE
 FROM      DDW_PROD.F08_SECCO_FNC_MON
 WHERE     secco_name = '上海证券有限责任公司'
 AND       YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT);
 
 
 
-----净资产同比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'NET_AST_YOY_RTO'     as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),NET_AST,NULL))*1.000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),NET_AST,0)) -1		   
		   
              as VALUE
		   ,%d{yyyyMMdd}         as ETL_DATE
 FROM      DDW_PROD.F08_SECCO_FNC_MON
 WHERE     secco_name = '上海证券有限责任公司'
 AND       YEAR_MON IN  (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT));

--------净资产环比
INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'NET_AST_MOM_RTO'     as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),NET_AST,NULL))*1.000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),NET_AST,0)) -1		   
		   
              as VALUE
		   ,%d{yyyyMMdd}         as ETL_DATE
 FROM      DDW_PROD.F08_SECCO_FNC_MON
 WHERE     secco_name = '上海证券有限责任公司'
 AND       YEAR_MON IN  (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT));

------净资产券商排名
 INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'NET_AST_SECCO_RANK'         as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,t.VALUE		         as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM    ( SELECT  SECCO_NAME
                  ,ROW_NUMBER() OVER(ORDER BY NET_AST DESC)   as VALUE	      
           FROM    DDW_PROD.F08_SECCO_FNC_MON
           WHERE     YEAR_MON  = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
           AND       IF_CLC = 0
		   )       t
  WHERE       SECCO_NAME = '上海证券有限责任公司' 
 ;
 
 ------净利润
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'NET_PROF'     as CODE
           ,YEAR_MON      as DIM_MON
		   ,NULL          as DIM_ORG
		   ,NULL          as VALUE_STR
		   ,NET_PROF      as VALUE
		   ,%d{yyyyMMdd} as ETL_DATE
 FROM      DDW_PROD.F08_SECCO_FNC_MON
 WHERE     secco_name = '上海证券有限责任公司'
 AND       YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT);
-----净利润同比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'NET_PROF_YOY_RTO'     as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),NET_PROF,NULL))*1.000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),NET_PROF,0)) -1		   
		   
              as VALUE
		   ,%d{yyyyMMdd}         as ETL_DATE
 FROM      DDW_PROD.F08_SECCO_FNC_MON
 WHERE     secco_name = '上海证券有限责任公司'
 AND       YEAR_MON IN  (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT)) ;
-----净利润环比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'NET_PROF_MOM_RTO'     as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),NET_PROF,NULL))*1.000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),NET_PROF,0)) -1		   
		   
              as VALUE
		   ,%d{yyyyMMdd}         as ETL_DATE
 FROM      DDW_PROD.F08_SECCO_FNC_MON
 WHERE     secco_name = '上海证券有限责任公司'
 AND       YEAR_MON IN  (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
 ;
 ------净利润排名
   INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'NET_PROF_SECCO_RANK'         as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,t.VALUE		         as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM    ( SELECT  SECCO_NAME
                  ,ROW_NUMBER() OVER(ORDER BY NET_PROF DESC)   as VALUE	      
           FROM    DDW_PROD.F08_SECCO_FNC_MON
           WHERE     YEAR_MON  = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
           AND       IF_CLC = 0
		   )       t
  WHERE       SECCO_NAME = '上海证券有限责任公司' 
 ;
 
 --------营业收入
    INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'OPRTG_INCM'     as CODE
           ,YEAR_MON     as DIM_MON
		   ,NULL         as DIM_ORG
		   ,NULL         as VALUE_STR
		   ,OPRTG_INCM      as VALUE
		   ,%d{yyyyMMdd} as ETL_DATE
 FROM      DDW_PROD.F08_SECCO_FNC_MON
 WHERE     secco_name = '上海证券有限责任公司'
 AND       YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
 ;
------营业收入同比
    INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'OPRTG_INCM_YOY_RTO'     as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),OPRTG_INCM,NULL))*1.000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),OPRTG_INCM,0)) -1		   
		   
              as VALUE
		   ,%d{yyyyMMdd}         as ETL_DATE
 FROM      DDW_PROD.F08_SECCO_FNC_MON
 WHERE     secco_name = '上海证券有限责任公司'
 AND       YEAR_MON IN  (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT))
 ;
 
-----营业收入环比
    INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'OPRTG_INCM_MOM_RTO'     as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),OPRTG_INCM,NULL))*1.000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),OPRTG_INCM,0)) -1		   
		   
              as VALUE
		   ,%d{yyyyMMdd}         as ETL_DATE
 FROM      DDW_PROD.F08_SECCO_FNC_MON
 WHERE     secco_name = '上海证券有限责任公司'
 AND       YEAR_MON IN  (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
 ;
 
 -----营业收入排名
    INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'OPRTG_INCM_SECCO_RANK'         as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,t.VALUE		         as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM    ( SELECT  SECCO_NAME
                  ,ROW_NUMBER() OVER(ORDER BY OPRTG_INCM DESC)   as VALUE	      
           FROM    DDW_PROD.F08_SECCO_FNC_MON
           WHERE     YEAR_MON  = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
           AND       IF_CLC = 0
		   )       t
  WHERE       SECCO_NAME = '上海证券有限责任公司' 
 ;

 -----股基市场份额
    INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'STK_FUND_MKT_SHR'         as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,ROUND((SEC_TRD_VOL_TOT+FNC_TRD_VOL_TOT)*1.00000000000/(SEC_TRD_VOL_TOT*1.00000000000*100/SEC_MKT_SHR_TOT+FNC_TRD_VOL_TOT*1.00000000000*100/FNC_MKT_SHR_TOT),16)		         as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.F08_FNC_SEC_CO_TRD_VOL_COMPR_MON
 WHERE     YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
 AND       SEC_CO = '上海证券'    
 ;

  -----股基市场份额排名
    INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'STK_FUND_MKT_SHR_RANK'         as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,t.VALUE		         as VALUE 
		   ,%d{yyyyMMdd}             as ETL_DATE
		   
		   
   FROM    ( SELECT  SEC_CO
                    ,ROW_NUMBER() OVER(ORDER BY (SEC_TRD_VOL_TOT+FNC_TRD_VOL_TOT)*1.00000000000/(SEC_TRD_VOL_TOT*1.00000000000*100/SEC_MKT_SHR_TOT+FNC_TRD_VOL_TOT*1.00000000000*100/FNC_MKT_SHR_TOT)  DESC)   as VALUE	      
           FROM    DDW_PROD.F08_FNC_SEC_CO_TRD_VOL_COMPR_MON
           WHERE     YEAR_MON  = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
		   )       t
  WHERE       SEC_CO = '上海证券' 
 ;
----------------------------业务规模指标(融资融券业务,股票质押业务,小微贷业务,约定购回业务,代销基金,资管产品,金融产品,个股期权业务期末规模，累计交易量) 
 -------融资融券业务_期末余额(上月截至)
 INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'MRGNC_MRGNS_BIZ_FNL_BAL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(DECODE(t.JYLB,64,t.RQJE*(t.RQSL-t.HQSL)*1.000/t.RQSL,61,(t.FZBJ-t.HKJE+t.GHLX),0),3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      EDW_PROD.T_EDW_T05_TXY_FZXXLS    t
 WHERE     SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
 AND       EXISTS (SELECT 1 FROM (SELECT MAX(TRD_DT) as TRD_DT FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                  WHERE BUS_DATE = %d{yyyyMMdd}
				                  AND   SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
                                 )	t	
					WHERE         t.BUS_DATE = TRD_DT
                  )
 ;	
 ---------融资融券业务_期末余额(当月截至) 
 INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT    'MRGNC_MRGNS_BIZ_FNL_BAL'   as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)      as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(DECODE(t.JYLB,64,t.RQJE*(t.RQSL-t.HQSL)*1.000/t.RQSL,61,(t.FZBJ-t.HKJE+t.GHLX),0),3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      EDW_PROD.T_EDW_T05_TXY_FZXXLS    t
 WHERE     t.BUS_DATE = %d{yyyyMMdd}
 ;	 
 
 -----------融资融券业务_累计交易量(上月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'MRGNC_MRGNS_BIZ_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(MTCH_AMT,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F05_ORDI_CRD_ACCNT_DLV_TRD_DEL    t
 WHERE     ODR_CGY IN (61,64)
 AND       BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
 ;
 
  -----------融资融券业务_累计交易量(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ) 
 SELECT    'MRGNC_MRGNS_BIZ_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(MTCH_AMT,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F05_ORDI_CRD_ACCNT_DLV_TRD_DEL    t
 WHERE     ODR_CGY IN (61,64)
 AND       BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < = %d{yyyyMMdd}
 ;
 
 
  -----------股票质押业务_期末余额(上月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'STK_PLG_BIZ_FNL_BAL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(t.CJJE,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      EDW_PROD.T_EDW_T02_TZYHGLS    t
 WHERE     SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
 AND       EXISTS (SELECT 1 FROM (SELECT MAX(TRD_DT) as TRD_DT FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                  WHERE BUS_DATE = %d{yyyyMMdd}
				                  AND   SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
                                 )	a	
					WHERE         t.BUS_DATE = a.TRD_DT
                  )
 AND     (t.CPDM NOT LIKE 'WD%' OR LENGTH(TRIM(t.CPDM)) = 0)
 ;
 
  -----------股票质押业务_期末余额(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT    'STK_PLG_BIZ_FNL_BAL'   as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(t.CJJE,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      EDW_PROD.T_EDW_T02_TZYHGLS    t
 WHERE     BUS_DATE  = %d{yyyyMMdd}
  AND      (t.CPDM NOT LIKE 'WD%' OR LENGTH(TRIM(t.CPDM)) = 0)
 ;
 
 
  -----------股票质押业务_累计交易量(上月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'STK_PLG__BIZ_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(CJJE,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      EDW_PROD.T_EDW_T05_TJGMXLS    t
 WHERE     WTLB = 53
 AND       WTFS = 8
 AND       BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
 ;
 
  -----------股票质押业务_累计交易量(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)) 
 SELECT    'STK_PLG__BIZ_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(CJJE,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      EDW_PROD.T_EDW_T05_TJGMXLS    t
 WHERE     WTLB = 53
 AND       WTFS = 8
 AND       BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < = %d{yyyyMMdd}
 ;
 
 
 -----------小微贷业务_期末余额(上月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'SMALL_M_LOAN__BIZ_FNL_BAL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(t.CJJE,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      EDW_PROD.T_EDW_T02_TZYHGLS    t
 WHERE     SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
 AND       EXISTS (SELECT 1 FROM (SELECT MAX(TRD_DT) as TRD_DT FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                  WHERE BUS_DATE = %d{yyyyMMdd}
				                  AND   SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
                                 )	a	
					WHERE         t.BUS_DATE = a.TRD_DT
                  )
 AND     t.CPDM  LIKE 'WD%' 
 AND LENGTH(TRIM(t.CPDM)) > 0
 ;
 
  -----------小微贷业务_期末余额(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT    'SMALL_M_LOAN__BIZ_FNL_BAL'    as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(t.CJJE,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      EDW_PROD.T_EDW_T02_TZYHGLS    t
 WHERE     BUS_DATE  = %d{yyyyMMdd}
 AND      t.CPDM  LIKE 'WD%' 
 AND      LENGTH(TRIM(t.CPDM)) > 0
 ;
 
 
  -----------小微贷业务_累计交易量(上月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'SMALL_M_LOAN__BIZ_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(CJJE,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      EDW_PROD.T_EDW_T05_TJGMXLS    t
 WHERE     WTLB = 53
 AND       WTFS < > 8
 AND       BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
 ;
 
  -----------小微贷业务_累计交易量(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT    'SMALL_M_LOAN__BIZ_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(CJJE,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      EDW_PROD.T_EDW_T05_TJGMXLS    t
 WHERE     WTLB = 53
 AND       WTFS < > 8
 AND       BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < = %d{yyyyMMdd}
 ;
 
 




 -----------代销基金_期末余额(上月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'AG_FND__BIZ_FNL_BAL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(t.prod_newst_mktval,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F02_PROD_HLD_DTL   t
 WHERE     SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
 AND       EXISTS (SELECT 1 FROM (SELECT MAX(TRD_DT) as TRD_DT FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                  WHERE BUS_DATE = %d{yyyyMMdd}
				                  AND   SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
                                 )	a	
					WHERE         t.BUS_DATE = a.TRD_DT
                  )
 AND      SUBSTR(PROD_CD,1,2) <> '95'
 AND      SUBSTR(PROD_CD,1,2) <> 'A'
 AND      PROD_CGY = 8 
 AND      CUST_NO <> '100610335855'
 ;
 
  -----------代销基金_期末余额(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT    'AG_FND__BIZ_FNL_BAL'     as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(t.prod_newst_mktval,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F02_PROD_HLD_DTL   t
 WHERE     BUS_DATE  = %d{yyyyMMdd}
 AND     SUBSTR(PROD_CD,1,2) <> '95'
 AND      SUBSTR(PROD_CD,1,2) <> 'A'
 AND      PROD_CGY = 8 
 AND      CUST_NO <> '100610335855'
 ;
 
 
  -----------代销基金_累计交易量(上月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'AG_FND__BIZ_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(cnfm_amt,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F05_PROD_DLV_TRD_DEL    t
 WHERE    SUBSTR(PROD_CD,1,2) <> '95'
 AND      SUBSTR(PROD_CD,1,2) <> 'A'
 AND      PROD_CGY = 8 
 AND      CUST_NO <> '100610335855'
 AND       PROD_BIZ_CD IN ('122','124','130','139','142','150')
 AND       BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
 ;
 
  -----------代销基金_累计交易量(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT    'AG_FND__BIZ_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(cnfm_amt,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F05_PROD_DLV_TRD_DEL    t
 WHERE    SUBSTR(PROD_CD,1,2) <> '95'
 AND      SUBSTR(PROD_CD,1,2) <> 'A'
 AND      PROD_CGY = 8 
 AND      CUST_NO <> '100610335855'
 AND       PROD_BIZ_CD IN ('122','124','130','139','142','150')
 AND       BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < = %d{yyyyMMdd}
 ; 
 
 
 
 
 
 
  -----------资管产品_期末余额(上月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'ASTMGT_PROD_FNL_BAL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(t.prod_newst_mktval,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F02_PROD_HLD_DTL   t
 WHERE     SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
 AND       EXISTS (SELECT 1 FROM (SELECT MAX(TRD_DT) as TRD_DT FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                  WHERE BUS_DATE = %d{yyyyMMdd}
				                  AND   SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
                                 )	a	
					WHERE         t.BUS_DATE = a.TRD_DT
                  )
 AND      (SUBSTR(PROD_CD,1,2) = '95' OR SUBSTR(PROD_CD,1,2) = 'A')
 AND      PROD_CGY = 8 
 AND      CUST_NO <> '100610335855'
 ;
 
  -----------资管产品_期末余额(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT    'ASTMGT_PROD_FNL_BAL'     as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(t.prod_newst_mktval,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F02_PROD_HLD_DTL   t
 WHERE     BUS_DATE  = %d{yyyyMMdd}
 AND      (SUBSTR(PROD_CD,1,2) = '95' OR SUBSTR(PROD_CD,1,2) = 'A')
 AND      PROD_CGY = 8 
 AND      CUST_NO <> '100610335855'
 ;
 
 
  -----------资管产品_累计交易量(上月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'ASTMGT_PROD_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(cnfm_amt,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F05_PROD_DLV_TRD_DEL    t
 WHERE     (SUBSTR(PROD_CD,1,2) = '95' OR SUBSTR(PROD_CD,1,2) = 'A')
 AND      PROD_CGY = 8 
 AND      CUST_NO <> '100610335855'
 AND       PROD_BIZ_CD IN ('122','124','130','139','142','133')
 AND       BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
 ;
 
  -----------资管产品_累计交易量(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT    'ASTMGT_PROD_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(cnfm_amt,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F05_PROD_DLV_TRD_DEL    t
 WHERE   (SUBSTR(PROD_CD,1,2) = '95' OR SUBSTR(PROD_CD,1,2) = 'A')
 AND      PROD_CGY = 8 
 AND      CUST_NO <> '100610335855'
 AND       PROD_BIZ_CD IN ('122','124','130','139','142','133')
 AND       BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < = %d{yyyyMMdd}
 ; 
 
 
 






  -----------金融产品_期末余额(上月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'FNCL_PROD_FNL_BAL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(t.prod_newst_mktval,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F02_PROD_HLD_DTL   t
 WHERE     SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
 AND       EXISTS (SELECT 1 FROM (SELECT MAX(TRD_DT) as TRD_DT FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                  WHERE BUS_DATE = %d{yyyyMMdd}
				                  AND   SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
                                 )	a	
					WHERE         t.BUS_DATE = a.TRD_DT
                  )
 AND      PROD_CGY = 9
 AND      CUST_NO <> '100610335855'
 ;
 
  -----------金融产品_期末余额(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT    'FNCL_PROD_FNL_BAL'     as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(t.prod_newst_mktval,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F02_PROD_HLD_DTL   t
 WHERE     BUS_DATE  = %d{yyyyMMdd}
 AND      PROD_CGY = 9 
 AND      CUST_NO <> '100610335855'
 ;
 
 
  -----------金融产品_累计交易量(上月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'FNCL_PROD_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(cnfm_amt,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F05_PROD_DLV_TRD_DEL    t
 WHERE    PROD_CGY = 9
 AND      CUST_NO <> '100610335855'
 AND       PROD_BIZ_CD IN ('130','142')
 AND       BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
 ;
 
  -----------金融产品_累计交易量(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)  )
 SELECT    'FNCL_PROD_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(cnfm_amt,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F05_PROD_DLV_TRD_DEL    t
 WHERE     PROD_CGY = 9
 AND      CUST_NO <> '100610335855'
 AND       PROD_BIZ_CD IN ('130','142')
 AND       BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < = %d{yyyyMMdd}
 ;  
 
 
 
 
 
 
 
 
   -----------个股期权业务_期末余额(上月截至) 单位是(张数)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
  SELECT    'WRNT_BIZ_FNL_BAL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(t.opt_ctc_qty,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F02_WRNT_HLD_DTL    t
 WHERE     SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
 AND       EXISTS (SELECT 1 FROM (SELECT MAX(TRD_DT) as TRD_DT FROM EDW_PROD.T_EDW_T99_TRD_DATE
                                  WHERE BUS_DATE = %d{yyyyMMdd}
				                  AND   SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
                                 )	a	
					WHERE         t.BUS_DATE = a.TRD_DT
                  )
 ;
 
  -----------个股期权业务_期末余额(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT    'WRNT_BIZ_FNL_BAL'     as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(t.opt_ctc_qty,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F02_WRNT_HLD_DTL    t
 WHERE     BUS_DATE  = %d{yyyyMMdd}
 ;
 
 
  -----------个股期权业务_累计交易量(上月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT    'WRNT_BIZ_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(mtch_qty,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F05_WRNT_ACCNT_TRD_DEL    t
 WHERE         BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
 ;
 
  -----------个股期权业务_累计交易量(当月截至)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT    'WRNT_BIZ_TYEAR_GT_TRD_VOL'   as CODE	        --指标代码
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                       as DIM_ORG	        --指标机构维度
		   ,NULL                       as VALUE_STR	        --指标值_字符
		   ,SUM(ROUND(mtch_qty,3))
		   ,%d{yyyyMMdd}             as ETL_DATE
 FROM      DDW_PROD.T_DDW_F05_WRNT_ACCNT_TRD_DEL    t
 WHERE     BUS_DATE > = CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4),'0101') as INT)
 AND       BUS_DATE < = %d{yyyyMMdd}
 ;
 
 
   -----------财务月报指标(固定收益,财富中心,资产管理的指标)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON =  CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)  )
 SELECT      a1.ZBBM              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,SUM(NVL(t.LC_LND_AMT*a1.CS,0))	as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.acg_cntt_code = a1.KSNRBM  
   AND    LENGTH(TRIM(t.acg_cntt_code))> 0
   WHERE  a1.ZBBM IN ('FIX_YLD_HEADS_NET_INCM','FIX_YLD_HEADS_NET_INCM_UDWRT_NET_INCM','FIX_YLD_HEADS_NET_INCM_FAIRS_VAL_CHG_PL'
                     ,'FIX_YLD_HEADS_NET_INCM_IVSM_YLD','FIX_YLD_HEADS_NET_INCM_OTHER_INCM','WEA_MGMT_CENTR_HEADS_NET_INCM'
                     ,'WEA_MGMT_CENTR_HEADS_NET_INCM_FND_CO_NET_INCM','WEA_MGMT_CENTR_HEADS_NET_INCM_QFII_NET_INCM'
                     ,'AST_MGMT_HEADS_NET_INCM','AST_MGMT_HEADS_NET_INCM_ENTRUST_MGMT_NET_INCM','AST_MGMT_HEADS_NET_INCM_IVSM_YLD')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) 
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;
 
    -----------财务月报指标(公司本部)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT      a1.ZBBM              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,SUM(NVL(t.LC_LND_AMT*a1.CS,0))	as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    ((LENGTH(TRIM(t.acg_cntt_code))> 0 AND t.acg_cntt_code NOT IN ('30','14','16')) OR LENGTH(TRIM(t.acg_cntt_code))= 0)
   AND    t.ORG_CD = '0002'
   WHERE  a1.ZBBM IN ('CO_HEADS_NET_INCM','CO_HEADS_NET_INCM_INT_NET_INCM','CO_HEADS_NET_INCM_OTHER_INCM'
                      ,'CO_HEADS_NET_INCM__CMSN_FEE_PAYOUT','CO_HEADS_NET_INCM_CMSN_FEE_NET_INCM','CO_HEADS_NET_INCM_AGGR_PL'
                      ,'CO_HEADS_NET_INCM_IVSM_YLD')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) 
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;
   -----------财务月报指标(其他)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT      a1.ZBBM              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,SUM(NVL(t.LC_LND_AMT*a1.CS,0))	as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.ORG_CD < > '0002'
   WHERE  a1.ZBBM IN ('BROK_BIZ_NET_INCM','BROK_BIZ_NET_INCM__INT_NET_INCM','BROK_BIZ_NET_INCM_3IP_DEPMGT_PAYOUT','BROK_BIZ_NET_INCM_AGGR_PL'
                      ,'BROK_BIZ_NET_INCM_CMSN_NET_INCM','BROK_BIZ_NET_INCM_OTHER_INCM','SEC_IVSM_HEADS_NET_INCM'
                      ,'SEC_IVSM_HEADS_NET_INCM__INT_NET_INCM','SEC_IVSM_HEADS_NET_INCM_FAIRS_VAL_CHG_PL','SEC_IVSM_HEADS_NET_INCM_IVSM_YLD','SEC_IVSM_HEADS_NET_INCM_CMSN_NET_INCM'
                      ,'OTC_MKT_HEADS_NET_INCM','OTC_MKT_HEADS_NET_INCM_IVSM_YLD','OTC_MKT_HEADS_NET_INCM_FNC_CON_NET_INCM','OTC_MKT_HEADS_NET_INCM__INT_NET_INCM','OTC_MKT_HEADS_NET_INCM_OTHER_INCM','CRD_BIZ_HEADS_NET_INCM'
                      ,'CRD_BIZ_HEADS_NET_INCM__INT_NET_INCM','CRD_BIZ_HEADS_NET_INCM_FAIRS_VAL_CHG_PL','CRD_BIZ_HEADS_NET_INCM_IVSM_YLD','OTC_MKT_HEADS_OPRTG_PAYOUT','OTC_MKT_HEADS_OPRTG_PAYOUT_IMPMT_PREP','SEC_IVSM_HEADS_OPRTG_PAYOUT'
                      ,'SEC_IVSM_HEADS_OPRTG_PAYOUT_IMPMT_PREP','CRD_BIZ_HEADS_OPRTG_PAYOUT','CRD_BIZ_HEADS_OPRTG_PAYOUT_IMPMT_PREP','WHL_CO_GT_PAYOUT_MON','WHL_CO_GT_PAYOUT_MON','WHL_CO_GT_PAYOUT_MON')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) 
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;
 ------全公司月累计净收入
  
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT      'WHL_CO_GT_NET_INCM_MON'             as CODE
             ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		     ,NULL                 as DIM_ORG
		     ,NULL                 as VALUE_STR
		     ,SUM(NVL(t.VALUE,0))	as VALUE
		    ,%d{yyyyMMdd}             as ETL_DATE
 FROM (SELECT   SUM(NVL(t.LC_LND_AMT*a1.CS,0))	as VALUE
       FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
       LEFT JOIN   (SELECT         a.ZBBM
                                  ,a.JGBM
							      ,a.KSNRBM
							      ,b.KMBM
						       	  ,b.CS
                    FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
                    LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			        ON             a.ZBBM = b.ZBBM
                    )                                       a1
       ON    a1.JGBM = t.ORG_CD 
       AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
       AND    t.acg_cntt_code = a1.KSNRBM  
       AND    LENGTH(TRIM(t.acg_cntt_code))> 0
      WHERE  a1.ZBBM IN ('FIX_YLD_HEADS_NET_INCM','WEA_MGMT_CENTR_HEADS_NET_INCM','AST_MGMT_HEADS_NET_INCM')
      AND     a1.ZBBM IS NOT NULL
      AND     t.YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)  
      UNION ALL
      SELECT    SUM(NVL(t.LC_LND_AMT*a1.CS,0))	as VALUE
      FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
      LEFT JOIN   (SELECT         a.ZBBM
                                 ,a.JGBM
							     ,a.KSNRBM
							     ,b.KMBM
							     ,b.CS
                   FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
                   LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			       ON             a.ZBBM = b.ZBBM
                  )                                       a1
       ON    a1.JGBM = t.ORG_CD 
       AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
       AND    ((LENGTH(TRIM(t.acg_cntt_code))> 0 AND t.acg_cntt_code NOT IN ('30','14','16')) OR LENGTH(TRIM(t.acg_cntt_code))= 0)
       AND    t.ORG_CD = '0002'
       WHERE  a1.ZBBM IN ('CO_HEADS_NET_INCM')
       AND     a1.ZBBM IS NOT NULL
       AND     t.YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) 
       UNION ALL
	   SELECT      SUM(NVL(t.LC_LND_AMT*a1.CS,0))	as VALUE
       FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
       LEFT JOIN   (SELECT         a.ZBBM
                                   ,a.JGBM
							       ,a.KSNRBM
							       ,b.KMBM
							       ,b.CS
                    FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
                    LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			        ON             a.ZBBM = b.ZBBM
                   )                                       a1
       ON    a1.JGBM = t.ORG_CD 
       AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
       AND    t.ORG_CD < > '0002'
      WHERE   a1.ZBBM IN ('BROK_BIZ_NET_INCM','SEC_IVSM_HEADS_NET_INCM' ,'OTC_MKT_HEADS_NET_INCM','CRD_BIZ_HEADS_NET_INCM','CO_HEADS_NET_INCM')
       AND     a1.ZBBM IS NOT NULL
       AND     t.YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) 
      )    t
 ;
 

 




  ---------固定收益总部净收入_同比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'FIX_YLD_HEADS_NET_INCM_YOY_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.acg_cntt_code = a1.KSNRBM  
   AND    LENGTH(TRIM(t.acg_cntt_code))> 0
   WHERE  a1.ZBBM IN ('FIX_YLD_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;
 
 

  ---------固定收益总部净收入_环比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'FIX_YLD_HEADS_NET_INCM_MOM_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.acg_cntt_code = a1.KSNRBM  
   AND    LENGTH(TRIM(t.acg_cntt_code))> 0
   WHERE  a1.ZBBM IN ('FIX_YLD_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;
 
 
   ---------财富管理中心净收入_同比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'WEA_MGMT_CENTR_HEADS_NET_INCM_YOY_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.acg_cntt_code = a1.KSNRBM  
   AND    LENGTH(TRIM(t.acg_cntt_code))> 0
   WHERE  a1.ZBBM IN ('WEA_MGMT_CENTR_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;
 
 

  ---------财富管理中心净收入_环比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'WEA_MGMT_CENTR_HEADS_NET_INCM_MOM_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.acg_cntt_code = a1.KSNRBM  
   AND    LENGTH(TRIM(t.acg_cntt_code))> 0
   WHERE  a1.ZBBM IN ('WEA_MGMT_CENTR_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;
 
 
 
 
 
    ---------资产管理总部净收入_同比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'AST_MGMT_HEADS_NET_INCM_YOY_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.acg_cntt_code = a1.KSNRBM  
   AND    LENGTH(TRIM(t.acg_cntt_code))> 0
   WHERE  a1.ZBBM IN ('AST_MGMT_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;
 
 

  ---------资产管理总部净收入_环比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'AST_MGMT_HEADS_NET_INCM_MOM_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.acg_cntt_code = a1.KSNRBM  
   AND    LENGTH(TRIM(t.acg_cntt_code))> 0
   WHERE  a1.ZBBM IN ('AST_MGMT_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;
 
 
    -----------公司本部净收入_同比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'CO_HEADS_NET_INCM_YOY_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE	
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    ((LENGTH(TRIM(t.acg_cntt_code))> 0 AND t.acg_cntt_code NOT IN ('30','14','16')) OR LENGTH(TRIM(t.acg_cntt_code))= 0)
   AND    t.ORG_CD = '0002'
   WHERE  a1.ZBBM IN ('CO_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
 AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT))
 ;
 
 
  
    -----------公司本部净收入_环比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'CO_HEADS_NET_INCM_MOM_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 	as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    ((LENGTH(TRIM(t.acg_cntt_code))> 0 AND t.acg_cntt_code NOT IN ('30','14','16')) OR LENGTH(TRIM(t.acg_cntt_code))= 0)
   AND    t.ORG_CD = '0002'
   WHERE  a1.ZBBM IN ('CO_HEADS_NET_INCM')
   AND     a1.ZBBM IS NOT NULL
   AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
 ;
 
 
 
 
 
 
 
 
 
 
   -----------经纪业务净收入_同比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'BROK_BIZ_NET_INCM_YOY_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.ORG_CD < > '0002'
   WHERE  a1.ZBBM IN ('BROK_BIZ_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;

  -----------经纪业务净收入_环比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'BROK_BIZ_NET_INCM_MOM_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.ORG_CD < > '0002'
   WHERE  a1.ZBBM IN ('BROK_BIZ_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
 
 
 
 
    -----------证券投资净收入_同比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'SEC_IVSM_HEADS_NET_INCM_YOY_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.ORG_CD < > '0002'
   WHERE  a1.ZBBM IN ('SEC_IVSM_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;

  -----------证券投资净收入_环比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'SEC_IVSM_HEADS_NET_INCM_MOM_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.ORG_CD < > '0002'
   WHERE  a1.ZBBM IN ('SEC_IVSM_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
 
    -----------场外市场总部净收入_同比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'OTC_MKT_HEADS_NET_INCM_YOY_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.ORG_CD < > '0002'
   WHERE  a1.ZBBM IN ('OTC_MKT_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;

  -----------场外市场总部净收入_环比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'OTC_MKT_HEADS_NET_INCM_MOM_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.ORG_CD < > '0002'
   WHERE  a1.ZBBM IN ('OTC_MKT_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
 
 
 
     -----------信用业务总部净收入_同比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
 SELECT     'CRD_BIZ_HEADS_NET_INCM_YOY_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.ORG_CD < > '0002'
   WHERE  a1.ZBBM IN ('CRD_BIZ_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ;

  -----------信用业务总部净收入_环比
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)) 
 SELECT     'CRD_BIZ_HEADS_NET_INCM_MOM_RTO'              as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                 as DIM_ORG
		   ,NULL                 as VALUE_STR
		  ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL))*1.000000/
            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),t.LC_LND_AMT*a1.CS,NULL)) -1 as VALUE
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F08_FNC_ENTR_DETAIL_MON  t
  LEFT JOIN   (SELECT         a.ZBBM
                            ,a.JGBM
							,a.KSNRBM
							,b.KMBM
							,b.CS
             FROM           EDW_PROD.T_EDW_T99_CWDB_JGBM_PZB   a
             LEFT JOIN      EDW_PROD.T_EDW_T99_CWDB_KMBM_PZB   b
			 ON             a.ZBBM = b.ZBBM
             )                                       a1
   ON    a1.JGBM = t.ORG_CD 
   AND   (SUBSTR(t.FNC_SBJ_CD,1,4) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,6) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,8) = a1.KMBM OR SUBSTR(t.FNC_SBJ_CD,1,10) = a1.KMBM)
   AND    t.ORG_CD < > '0002'
   WHERE  a1.ZBBM IN ('CRD_BIZ_HEADS_NET_INCM')
  AND     a1.ZBBM IS NOT NULL
  AND     t.YEAR_MON IN (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
--  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
 
 
   -----------客户数
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT     'CUST_TOT'                                      as CODE
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.CUST_TOT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
    -----------交易客户数
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT     'TRD_CUST_TOT'                                      as CODE
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.TRD_CUST_TOT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
    -----------有效客户数
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT     'VLD_CUST_TOT'                                      as CODE
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.VLD_CUST_TOT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
     -----------总客户资产
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT     'CUST_AST_TOT'                                      as CODE
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.CUST_AST_TOT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
  
     -----------客户数(本年累计)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT     'CUST_TOT_TYEAR_GT'                                      as CODE
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.CUST_TOT_TYEAR_GT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
      -----------交易客户数(本年累计)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT     'TRD_CUST_TOT_TYEAR_GT'                                      as CODE
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.TRD_CUST_TOT_TYEAR_GT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
  
      -----------有效客户数(本年)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT     'VLD_CUST_TOT_TYEAR_GT'                                      as CODE
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.VLD_CUST_TOT_TYEAR_GT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
       -----------今年开户客户资产(本年)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT     'CUST_AST_TOT_TYEAR_GT'                                      as CODE
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.CUST_AST_TOT_TYEAR_GT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
        -----------当月开户数
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT     'CUST_OPNAC_TOT_TMTH'                                      as CODE
           ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.CUST_OPNAC_TOT_TMTH)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 -----------客户数
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT))
 SELECT     'CUST_TOT'                                      as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.CUST_TOT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE  EXISTS (SELECT 1 
                 FROM (SELECT MAX(TRD_DT) as TRD_DT
                       FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
				       WHERE  BUS_DATE = %d{yyyyMMdd}
				       AND    SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				      ) a
				WHERE t.BUS_DATE = a.TRD_DT	  
				)
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
    -----------交易客户数
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT))
 SELECT     'TRD_CUST_TOT'                                      as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.TRD_CUST_TOT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE  EXISTS (SELECT 1 
                 FROM (SELECT MAX(TRD_DT) as TRD_DT
                       FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
				       WHERE  BUS_DATE = %d{yyyyMMdd}
				       AND    SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				      ) a
				WHERE t.BUS_DATE = a.TRD_DT	  
				)
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
    -----------有效客户数
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT))
 SELECT     'VLD_CUST_TOT'                                      as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.VLD_CUST_TOT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE  EXISTS (SELECT 1 
                 FROM (SELECT MAX(TRD_DT) as TRD_DT
                       FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
				       WHERE  BUS_DATE = %d{yyyyMMdd}
				       AND    SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				      ) a
				WHERE t.BUS_DATE = a.TRD_DT	  
				)
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
     -----------总客户资产
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT))
 SELECT     'CUST_AST_TOT'                                      as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.CUST_AST_TOT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE  EXISTS (SELECT 1 
                 FROM (SELECT MAX(TRD_DT) as TRD_DT
                       FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
				       WHERE  BUS_DATE = %d{yyyyMMdd}
				       AND    SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				      ) a
				WHERE t.BUS_DATE = a.TRD_DT	  
				)
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
  
     -----------客户数(本年累计)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT))
 SELECT     'CUST_TOT_TYEAR_GT'                                      as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.CUST_TOT_TYEAR_GT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE  EXISTS (SELECT 1 
                 FROM (SELECT MAX(TRD_DT) as TRD_DT
                       FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
				       WHERE  BUS_DATE = %d{yyyyMMdd}
				       AND    SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				      ) a
				WHERE t.BUS_DATE = a.TRD_DT	  
				)
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
      -----------交易客户数(本年累计)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT))
 SELECT     'TRD_CUST_TOT_TYEAR_GT'                                      as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.TRD_CUST_TOT_TYEAR_GT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE  EXISTS (SELECT 1 
                 FROM (SELECT MAX(TRD_DT) as TRD_DT
                       FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
				       WHERE  BUS_DATE = %d{yyyyMMdd}
				       AND    SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				      ) a
				WHERE t.BUS_DATE = a.TRD_DT	  
				)
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
  
      -----------有效客户数(本年)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT))
 SELECT     'VLD_CUST_TOT_TYEAR_GT'                                      as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.VLD_CUST_TOT_TYEAR_GT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE  EXISTS (SELECT 1 
                 FROM (SELECT MAX(TRD_DT) as TRD_DT
                       FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
				       WHERE  BUS_DATE = %d{yyyyMMdd}
				       AND    SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				      ) a
				WHERE t.BUS_DATE = a.TRD_DT	  
				)
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
       -----------今年开户客户资产(本年)
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT))
 SELECT     'CUST_AST_TOT_TYEAR_GT'                                      as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.CUST_AST_TOT_TYEAR_GT)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
 WHERE  EXISTS (SELECT 1 
                 FROM (SELECT MAX(TRD_DT) as TRD_DT
                       FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
				       WHERE  BUS_DATE = %d{yyyyMMdd}
				       AND    SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				      ) a
				WHERE t.BUS_DATE = a.TRD_DT	  
				)
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 
 
 
        -----------当月开户数
  INSERT INTO DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
 (      CODE	        --指标代码
       ,DIM_MON	        --指标时间维护_月
       ,DIM_ORG	        --指标机构维度
       ,VALUE_STR	    --指标值_字符
       ,VALUE	        --指标值_数字
       ,ETL_DATE	    --数据加载时间   
 ) 
 partition(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT))
 SELECT     'CUST_OPNAC_TOT_TMTH'                                      as CODE
           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
		   ,NULL                                            as DIM_ORG
		   ,NULL                                            as VALUE_STR
		   ,SUM(t.CUST_OPNAC_TOT_TMTH)
		   ,%d{yyyyMMdd}             as ETL_DATE
  FROM        DDW_PROD.T_DDW_F001_BRH_NO_CUST_DATA_STATS  t
  WHERE  EXISTS (SELECT 1 
                 FROM (SELECT MAX(TRD_DT) as TRD_DT
                       FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
				       WHERE  BUS_DATE = %d{yyyyMMdd}
				       AND    SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				      ) a
				WHERE t.BUS_DATE = a.TRD_DT	  
				)
  GROUP BY CODE,DIM_MON,DIM_ORG,VALUE_STR,ETL_DATE
 ; 









 
  
 
 
  

 

------ SELECT    'OPRTG_PAYOUT'      as CODE
------           ,YEAR_MON          as DIM_MON
------		   ,NULL              as DIM_ORG
------		   ,NULL              as VALUE_STR
------		   ,CO_VOL_VAL        as VALUE
------		   ,%d{yyyyMMdd} as ETL_DATE
------		   ,DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),1,0) as IF_DATA
------ FROM      DDW_PROD.F02_FNC_SEC_CO_MG_DATA_STATS_MON
------ WHERE     PRJ_NAME =  '二、营业支出（元）(本期金额）'
------ AND       YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
------ UNION ALL
------ SELECT    'OPRTG_PAYOUT_YOY_RTO'     as CODE
------           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
------		   ,NULL                 as DIM_ORG
------		   ,NULL                 as VALUE_STR
------		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CO_VOL_VAL,0))*1.000/
------            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),CO_VOL_VAL,0)) -1		   
------		   
------              as VALUE
------		   ,%d{yyyyMMdd}         as ETL_DATE
------		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),1,0)) as IF_DATA
------ FROM      DDW_PROD.F02_FNC_SEC_CO_MG_DATA_STATS_MON
------ WHERE     PRJ_NAME =  '二、营业支出（元）(本期金额）'
------ AND       YEAR_MON IN  (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT))
------ UNION ALL
------ SELECT    'OPRTG_PAYOUT_MOM_RTO'     as CODE
------           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
------		   ,NULL                 as DIM_ORG
------		   ,NULL                 as VALUE_STR
------		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CO_VOL_VAL,0))*1.000/
------            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),CO_VOL_VAL,0)) -1		   
------		   
------              as VALUE
------		   ,%d{yyyyMMdd}         as ETL_DATE
------		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),1,0)) as IF_DATA
------ FROM      DDW_PROD.F02_FNC_SEC_CO_MG_DATA_STATS_MON
------ WHERE     PRJ_NAME =  '二、营业支出（元）(本期金额）'
------ AND       YEAR_MON IN  (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
------ UNION ALL
------ SELECT    'OPRTG_PAYOUT_SECCO_RANK'         as CODE
------           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
------		   ,NULL                 as DIM_ORG
------		   ,NULL                 as VALUE_STR
------		   ,CO_RANK		         as VALUE
------		   ,%d{yyyyMMdd}             as ETL_DATE
------		   ,DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),1,0) as IF_DATA
------ FROM      DDW_PROD.F02_FNC_SEC_CO_MG_DATA_STATS_MON
------ WHERE     PRJ_NAME =  '二、营业支出（元）(本期金额）'
------ AND        YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)  
------ UNION ALL
------  SELECT    'BROK_BIZ_INCM'      as CODE
------           ,YEAR_MON          as DIM_MON
------		   ,NULL              as DIM_ORG
------		   ,NULL              as VALUE_STR
------		   ,CO_VOL_VAL        as VALUE
------		   ,%d{yyyyMMdd} as ETL_DATE
------		   ,DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),1,0) as IF_DATA
------ FROM      DDW_PROD.F02_FNC_SEC_CO_MG_DATA_STATS_MON
------ WHERE     PRJ_NAME = '其中：证券经纪业务净收入（元）(本期金额）'
------ AND       YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
------ UNION ALL
------ SELECT    'BROK_BIZ_INCM_YOY_RTO'     as CODE
------           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
------		   ,NULL                 as DIM_ORG
------		   ,NULL                 as VALUE_STR
------		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CO_VOL_VAL,0))*1.000/
------            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),CO_VOL_VAL,0)) -1		   
------		   
------              as VALUE
------		   ,%d{yyyyMMdd}         as ETL_DATE
------		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),1,0)) as IF_DATA
------ FROM      DDW_PROD.F02_FNC_SEC_CO_MG_DATA_STATS_MON
------ WHERE     PRJ_NAME = '其中：证券经纪业务净收入（元）(本期金额）'
------ AND       YEAR_MON IN  (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT))
------ UNION ALL
------ SELECT    'BROK_BIZ_INCM_MOM_RTO'     as CODE
------           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
------		   ,NULL                 as DIM_ORG
------		   ,NULL                 as VALUE_STR
------		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CO_VOL_VAL,0))*1.000/
------            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),CO_VOL_VAL,0)) -1		   
------		   
------              as VALUE
------		   ,%d{yyyyMMdd}         as ETL_DATE
------		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),1,0)) as IF_DATA
------ FROM      DDW_PROD.F02_FNC_SEC_CO_MG_DATA_STATS_MON
------ WHERE     PRJ_NAME = '其中：证券经纪业务净收入（元）(本期金额）'
------ AND       YEAR_MON IN  (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
------ UNION ALL
------ SELECT    'BROK_BIZ_INCM_SECCO_RANK'         as CODE
------           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
------		   ,NULL                 as DIM_ORG
------		   ,NULL                 as VALUE_STR
------		   ,CO_RANK		         as VALUE
------		   ,%d{yyyyMMdd}             as ETL_DATE
------		   ,DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),1,0) as IF_DATA
------ FROM      DDW_PROD.F02_FNC_SEC_CO_MG_DATA_STATS_MON
------ WHERE     PRJ_NAME = '其中：证券经纪业务净收入（元）(本期金额）'
------ AND        YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)   
------ UNION ALL
------  SELECT    'CRD_BIZ_INCM'      as CODE
------           ,YEAR_MON          as DIM_MON
------		   ,NULL              as DIM_ORG
------		   ,NULL              as VALUE_STR
------		   ,CO_VOL_VAL        as VALUE
------		   ,%d{yyyyMMdd} as ETL_DATE
------		   ,DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),1,0) as IF_DATA
------ FROM      DDW_PROD.F02_FNC_SEC_CO_MG_DATA_STATS_MON
------ WHERE     PRJ_NAME = '融资业务利息收入（元）(本期金额）'
------ AND       YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
------ UNION ALL
------ SELECT    'CRD_BIZ_INCM_YOY_RTO'     as CODE
------           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
------		   ,NULL                 as DIM_ORG
------		   ,NULL                 as VALUE_STR
------		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CO_VOL_VAL,0))*1.000/
------            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT),CO_VOL_VAL,0)) -1		   
------		   
------              as VALUE
------		   ,%d{yyyyMMdd}         as ETL_DATE
------		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),1,0)) as IF_DATA
------ FROM      DDW_PROD.F02_FNC_SEC_CO_MG_DATA_STATS_MON
------ WHERE     PRJ_NAME = '融资业务利息收入（元）(本期金额）'
------ AND       YEAR_MON IN  (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-13,0),1,6) as INT))
------ UNION ALL
------ SELECT    'CRD_BIZ_INCM_MOM_RTO'     as CODE
------           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
------		   ,NULL                 as DIM_ORG
------		   ,NULL                 as VALUE_STR
------		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CO_VOL_VAL,0))*1.000/
------            SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT),CO_VOL_VAL,0)) -1		   
------		   
------              as VALUE
------		   ,%d{yyyyMMdd}         as ETL_DATE
------		   ,SUM(DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),1,0)) as IF_DATA
------ FROM      DDW_PROD.F02_FNC_SEC_CO_MG_DATA_STATS_MON
------ WHERE     PRJ_NAME = '融资业务利息收入（元）(本期金额）'
------ AND       YEAR_MON IN  (CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT))
------ UNION ALL
------ SELECT    'CRD_BIZ_INCM_SECCO_RANK'         as CODE
------           ,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)             as DIM_MON
------		   ,NULL                 as DIM_ORG
------		   ,NULL                 as VALUE_STR
------		   ,CO_RANK		         as VALUE
------		   ,%d{yyyyMMdd}             as ETL_DATE
------		   ,DECODE(YEAR_MON,CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT),1,0) as IF_DATA
------ FROM      DDW_PROD.F02_FNC_SEC_CO_MG_DATA_STATS_MON
------ WHERE     PRJ_NAME = '融资业务利息收入（元）(本期金额）'
------ AND        YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) 
------

 
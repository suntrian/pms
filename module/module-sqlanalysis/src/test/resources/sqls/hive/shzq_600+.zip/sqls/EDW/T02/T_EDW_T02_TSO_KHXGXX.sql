 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:个股期权客户限购信息表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TSO_KHXGXX; 
-------插入数据开始-----------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TSO_KHXGXX
(
                                    KHH                                 --客户号                                
                                   ,YYB                                 --营业部                                
                                   ,KHXM                                --客户姓名                               
                                   ,GGQQKH_KHQZ                         --个股期权客户客户群组                         
                                   ,JYS                                 --交易所                                
                                   ,XGED                                --限购额度                               
                                   ,BDRQ                                --变动日期                               
                                   ,MRJE                                --买入金额                               
                                   ,MFXJCS                              --免费询价次数                             
                                   ,XJCSSX                              --询价次数上限                             
                                   ,DRXJCS                              --当日询价次数       
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --营业部                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.KHQZ                                as GGQQKH_KHQZ                         --客户群组                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.XGED                                as XGED                                --限购额度                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.MRJE                                as MRJE                                --买入金额                                
                                   ,t.MFXJCS                              as MFXJCS                              --免费询价次数                              
                                   ,t.XJCSSX                              as XJCSSX                              --询价次数上限                              
                                   ,t.DRXJCS                              as DRXJCS                              --当日询价次数    
                                   ,'GGQQ'	                              as XTBS							   
 FROM      GGQQCX.SOPTION_TSO_KHXGXX t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'GGQQ'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE     t.DT = '%d{yyyyMMdd}';
-------插入数据结束------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TSO_KHXGXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TSO_KHXGXX;
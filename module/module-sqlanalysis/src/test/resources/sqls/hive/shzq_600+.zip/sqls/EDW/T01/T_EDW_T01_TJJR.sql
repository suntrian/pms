 --/* ***************************************** SQL Begin ***************************************** */
 --/* 脚本功能:经纪人表                                                                            */
 --/* 创建人:黄勇华                                                                              */
 --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T01_TJJR ; 
---插入数据开始------------
INSERT OVERWRITE EDW_PROD.T_EDW_T01_TJJR
(
                                    ID                     --主键
                                   ,JJRXM                  --经纪人姓名
                                   ,JJRBH                  --经纪人编号
                                   ,BMLB                   --
                                   ,JJRLB                   --经纪人类别
                                   ,JJRJB                  --经纪人级别
                                   ,BM                     --部门
                                   ,TD                     --团队
                                   ,FJJR                   --父经纪人
                                   ,TJJJR                  --同级经纪人
                                   ,TJJSX                  --
                                   ,RZRQ                   --入职日期
                                   ,LZRQ                   --离职日期
                                   ,HTLX                   --签约合同类型
                                   ,RYHGBZ                 --合规标志
                                   ,SBZH                   --
                                   ,TBTS                   --特别提示
                                   ,JJRYYB                 --营业部
                                   ,YXLB                   --
                                   ,DLQX                   --代理权限
                                   ,HDFW                   --活动范围
                                   ,CYZG                   --从业资格
                                   ,CYKSKM                 --考试科目
                                   ,ZJLBDM                 --证件类别
                                   ,ZJBH                   --证件编号
                                   ,LXSJ                   --联系手机
                                   ,DH                     --电话
                                   ,EMAIL                  --邮箱
                                   ,MSNQQ                  --MSNQQ
                                   ,LXDZ                   --联系地址
                                   ,JTDZ                   --家庭地址
                                   ,YZBM                   --邮政编码
                                   ,BYYX                   --毕业院校
                                   ,BYSJ                   --毕业时间
                                   ,XLDM                   --学历
                                   ,XWDM                   --学位
                                   ,XZ                     --学制
                                   ,XXZY                   --专业信息
                                   ,XBDM                   --性别
                                   ,CSRQ                   --出生日期
                                   ,ZZMM                   --政治面貌
                                   ,TC                     --特长
                                   ,GJDM                   --国家
                                   ,PROVINCE               --省份
                                   ,CITY                   --城市
                                   ,SEC                    --所属辖区
                                   ,ZHZT                   --经纪人账户状态
                                   ,KHRQ                   --开户日期
                                   ,XHRQ                   --销户日期
                                   ,DYYG                   --
                                   ,LSZGJB                 --
                                   ,GTJJR                  --
                                   ,ZZRQ                   --
                                   ,TCFS                   --提成方式
                                   ,YGGH                   --
                                   ,ZHZT_FZ                --
                                   ,RYXXID                 --人员信息主键
                                   ,XTBS
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT                    
                                    t.ID           as ID              --主键
                                   ,t.JJRXM        as JJRXM           --经纪人姓名
                                   ,t.JJRBH        as JJRBH           --经纪人编号
                                   ,t.BMLB         as BMLB            --
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JJRLB AS VARCHAR(20))),'ERR'))   AS VARCHAR(20))    as JJRLB           --经纪人类别
                                   ,t.JJRJB        as JJRJB           --经纪人级别
                                   ,t.BM           as BM              --部门
                                   ,t.TD           as TD              --团队                           
                                   ,t.FJJR         as FJJR            --父经纪人
                                   ,t.TJJJR        as TJJJR           --同级经纪人
                                   ,t.TJJSX        as TJJSX           --
                                   ,t.RZRQ         as RZRQ            --入职日期
                                   ,t.LZRQ         as LZRQ            --离职日期
                                   ,CAST(t.QYHT as STRING)        as QYHT            --签约合同类型
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.HGBZ AS VARCHAR(20))),'ERR'))   AS VARCHAR(20))     as RYHGBZ            --合规标志
                                   ,t.SBZH         as SBZH            --
                                   ,t.TBTS         as TBTS            --特别提示
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))	     as JJRYYB                      --经纪人营业部							   
                                   ,t.YXLB         as YXLB            --
                                   ,t.DLQX         as DLQX            --代理权限
                                   ,t.HDFW         as HDFW            --活动范围
                                   ,t.CYZG         as cyzg            --从业资格
                                   ,CAST(t.KSKM as string) AS KSKM           --考试科目
                                   ,CAST(COALESCE(t7.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))         as ZJLBDM            --证件类别
                                   ,t.ZJBH         as ZJBH            --证件编号
                                   ,t.LXSJ         as LXSJ            --联系手机
                                   ,t.DH           as DH              --电话
                                   ,t.EMAIL        as EMAIL           --邮箱               
                                   ,t.MSNQQ        as MSNQQ           --MSNQQ
                                   ,t.LXDZ         as LXDZ            --联系地址
                                   ,t.JTDZ         as JTDZ            --家庭地址
                                   ,t.YZBM         as YZBM            --邮政编码
                                   ,t.BYYX         as BYYX            --毕业院校
                                   ,t.BYSJ         as BYSJ            --毕业时间                
                                   ,CAST(COALESCE(t8.MBDM,NULLIF(CONCAT('ERR',CAST(t.XL AS VARCHAR(20))),'ERR')) AS VARCHAR(20))           as XLDM              --学历                        
                                   ,CAST(COALESCE(t9.MBDM,NULLIF(CONCAT('ERR',CAST(t.XW AS VARCHAR(20))),'ERR')) AS VARCHAR(20))           as XWDM              --学位
                                   ,t.XZ            as XZ              --学制
                                   ,t.XXZY         as XXZY            --专业信息
                                   ,CASE WHEN XB IS NULL
								         AND LENGTH(REGEXP_REPLACE(NVL(ZJBH,''),' ',''))=18
                                         AND ZJLB = 0
                                         AND MOD(CAST(SUBSTR(REGEXP_REPLACE(NVL(ZJBH,''),' ',''),-2,1) as INT),2) = 0
                                         THEN '2' 
                                         WHEN XB IS NULL
								         AND LENGTH(REGEXP_REPLACE(NVL(ZJBH,''),' ',''))=18
                                         AND ZJLB = 0
                                         AND MOD(CAST(SUBSTR(REGEXP_REPLACE(ZJBH,' ',''),-2,1) as INT),2) = 1
                                         THEN '1' 
                                         WHEN XB IS NULL
								         AND LENGTH(REGEXP_REPLACE(NVL(ZJBH,''),' ',''))=15
                                         AND ZJLB = 0
                                         AND MOD(CAST(SUBSTR(REGEXP_REPLACE(ZJBH,' ',''),-1,1) as INT),2) = 0
                                         THEN '2' 
                                         WHEN XB IS NULL
								         AND LENGTH(REGEXP_REPLACE(NVL(ZJBH,''),' ',''))=15
                                         AND ZJLB = 0
                                         AND MOD(CAST(SUBSTR(REGEXP_REPLACE(ZJBH,' ',''),-1,1) as INT),2) = 1
                                         THEN '1'										 
								         ELSE CAST(COALESCE(t10.MBDM,NULLIF(CONCAT('ERR',CAST(t.XB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))
										 END as XBDM              --性别
                                   ,CASE WHEN (t.CSRQ IS NULL OR CSRQ > = %d{yyyyMMdd} OR LENGTH(NVL(CAST(CSRQ as STRING),'')) < > 8 )								         
										 AND  t.ZJLB = 0
										 AND  LENGTH(REGEXP_REPLACE(NVL(ZJBH,''),' ',''))=18 
										 THEN CAST(SUBSTR(REGEXP_REPLACE(ZJBH,' ',''),7,8) as DECIMAL(38,0)) 
										 WHEN (t.CSRQ IS NULL OR CSRQ > = %d{yyyyMMdd} OR LENGTH(NVL(CAST(CSRQ as STRING),'')) < > 8 )								         
										 AND  t.ZJLB = 0
										 AND  LENGTH(REGEXP_REPLACE(NVL(ZJBH,''),' ',''))=15 
										 THEN CAST(CONCAT('19',SUBSTR(REGEXP_REPLACE(ZJBH,' ',''),7,6)) as DECIMAL(38,0))
										 WHEN TRIM(NVL(ZJBH,'')) = '3210261969080381373' AND CSRQ IS NULL
										 THEN 19690803
										 WHEN TRIM(NVL(ZJBH,'')) = '31011219680306152Ｘ' AND CSRQ IS NULL
										 THEN 19680306
										 WHEN TRIM(NVL(ZJBH,'')) = '12011197110160587' AND CSRQ IS NULL
										 THEN 19711016
										 ELSE CSRQ
                                         END	   as CSRQ            --出生日期
                                   ,CAST(COALESCE(t11.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZZMM AS VARCHAR(20))),'ERR')) AS VARCHAR(20))         as ZZMM            --政治面貌
                                   ,t.TC           as TC              --特长
                                   ,CAST(COALESCE(t12.MBDM,NULLIF(CONCAT('ERR',CAST(t.GJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20))           as GJDM              --国家
                                   ,t.PROVINCE     as PROVINCE        --省份
                                   ,t.CITY         as CITY            --城市
                                   ,t.SEC          as SEC             --所属辖区
                                   ,CAST(COALESCE(t13.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20))         as JJRZHZT            --经纪人账户状态
                                   ,t.KHRQ         as KHRQ            --开户日期
                                   ,t.XHRQ         as XHRQ            --销户日期
                                   ,t.DYYG         as DYYG            --
                                   ,t.LSZGJB       as LSZGJB          --
                                   ,t.GTJJR        as GTJJR           --
                                   ,t.ZZRQ         as ZZRQ            --
                                   ,t.TCFS         as TCFS            --提成方式
                                   ,t.YGGH         as YGGH            --
                                   ,t.ZHZT_FZ      as ZHZT_FZ         --
                                   ,t.RYXXID       as RYXXID          --人员信息主键
                                   ,'CRM'          as XTBS
 FROM           NEWCRM.CRMII_TJJR t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'CRM'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t2
 ON             t2.YXT = 'CRM'
 AND            t2.YDM = CAST(t.JJRLB AS VARCHAR(20))
 AND            t2.dmlx = 'RYLB'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t4
 ON             t4.YXT = 'CRM'
 AND            t4.YDM = CAST(t.HGBZ AS VARCHAR(20))
 AND            t4.dmlx = 'RYHGBZ'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t5
 ON             t5.YXT = 'CRM'
 AND            t5.YDM = CAST(t.CYZG AS VARCHAR(20))
 AND            t5.dmlx = 'CYZG'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t6
 ON             t6.YXT = 'CRM'
 AND            t6.YDM = CAST(t.KSKM AS VARCHAR(20))
 AND            t6.dmlx = 'CYKSKM'                              
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t7
 ON             t7.YXT = 'CRM'
 AND            t7.YDM = CAST(t.ZJLB AS VARCHAR(20))
 AND            t7.dmlx = 'ZJLBDM'                                      
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t8
 ON             t8.YXT = 'CRM'
 AND            t8.YDM = CAST(t.XL AS VARCHAR(20))
 AND            t8.dmlx = 'XLDM'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t9
 ON             t9.YXT = 'CRM'
 AND            t9.YDM = CAST(t.XW AS VARCHAR(20))
 AND            t9.dmlx = 'XWDM'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t10
 ON             t10.YXT = 'CRM'
 AND            t10.YDM = CAST(t.XB AS VARCHAR(20))
 AND            t10.dmlx = 'XBDM'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t11
 ON             t11.YXT = 'CRM'
 AND            t11.YDM = CAST(t.ZZMM AS VARCHAR(20))
 AND            t11.dmlx = 'ZZMM'                                     
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t12
 ON             t12.YXT = 'CRM'
 AND            t12.YDM = CAST(t.GJ AS VARCHAR(20))
 AND            t12.dmlx = 'GJDM'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t13
 ON             t13.YXT = 'CRM'
 AND            t13.YDM = CAST(t.ZHZT AS VARCHAR(20))
 AND            t13.dmlx = 'JJRZHZT'
 WHERE          t.DT = '%d{yyyyMMdd}';
----插入数据结束------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TJJR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T01_TJJR;

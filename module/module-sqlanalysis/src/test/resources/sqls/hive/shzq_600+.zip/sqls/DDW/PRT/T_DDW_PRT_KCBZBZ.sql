 /* ***************************************** SQL Begin ******************************************/
 /* 脚本功能:科创板指标表                                                                    */
 /* 创建人:黄勇华                                                                              */
 /* 创建时间:2018-11-14                                                                       */ 
 TRUNCATE TABLE DDW_PROD.T_DDW_PRT_KCBZBZ ;
 INSERT OVERWRITE DDW_PROD.T_DDW_PRT_KCBZBZ
(                                      BELTO_FILIL    --地区
	                                  ,BRH_NO         --营业部编号
	                                  ,BRH_FULLNM     --营业部名称   
                                      ,ZBMC           --指标名称
									  ,ZBZ            --指标值	
) partition(bus_date = %d{yyyyMMdd})
 
SELECT 
        a1.belto_filil
	   ,t.BRH_NO as BRH_NO
	   ,a1.brh_fullnm
  	   ,'公司客户总数' as ZBMC
       ,SUM(t.CUST_TOT) as ZBZ 
FROM       DDW_PROD.T_DDW_F20_BRH_CUST_STATS_DAY  t
INNER JOIN  DDW_PROD.T_DDW_INR_ORG_BRH  a1
on          t.BRH_NO = a1.BRH_NO
AND          a1.BUS_DATE = %d{yyyyMMdd}
where  t.bus_date = %d{yyyyMMdd}
GROUP BY belto_filil,brh_no,ZBMC,brh_fullnm
UNION ALL
SELECT  a1.belto_filil
	   ,t.BRH_NO    as BRH_NO
	   ,a1.brh_fullnm
       ,'公司有效客户数'       as ZBMC
       ,SUM(QLFD_CUST_TOT_99) as ZBZ 
FROM       DDW_PROD.T_DDW_F20_BRH_CUST_STATS_DAY  t
INNER JOIN  DDW_PROD.T_DDW_INR_ORG_BRH  a1
on          t.BRH_NO = a1.BRH_NO
AND          a1.BUS_DATE = %d{yyyyMMdd}
where  t.bus_date = %d{yyyyMMdd}
GROUP BY belto_filil,brh_no,ZBMC,brh_fullnm
UNION ALL
SELECT  a1.belto_filil
	   ,t.BRH_NO    as BRH_NO
	    ,a1.brh_fullnm
       ,'已开通科创板交易权限的投资者'       as ZBMC
       ,COUNT(DISTINCT CUST_NO )                       as ZBZ 
FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL t
INNER JOIN  DDW_PROD.T_DDW_INR_ORG_BRH  a1
on          t.BRH_NO = a1.BRH_NO
AND          a1.BUS_DATE = %d{yyyyMMdd}
WHERE t.BUS_DATE = %d{yyyyMMdd} 
AND   t.OPN_PRVL = 20
AND %d{yyyyMMdd} BETWEEN  t.opn_dt  AND t.chg_dt
GROUP BY belto_filil,brh_no,ZBMC,brh_fullnm
UNION ALL
SELECT  a1.belto_filil
	   ,t.BRH_NO    as BRH_NO
	  ,a1.brh_fullnm
       ,'已开通两融交易权限的客户数'       as ZBMC
       ,SUM(CRD_CUST_TOT) as ZBZ 
FROM   DDW_PROD.T_DDW_F20_BRH_CUST_STATS_DAY t
INNER JOIN  DDW_PROD.T_DDW_INR_ORG_BRH  a1
on          t.BRH_NO = a1.BRH_NO
AND          a1.BUS_DATE = %d{yyyyMMdd}
where t.bus_date = %d{yyyyMMdd}
GROUP BY belto_filil,brh_no,ZBMC,brh_fullnm
union all
SELECT  a2.belto_filil         
	  ,t.BRH_NO    as BRH_NO
	  ,a2.brh_fullnm
      ,'公司符合开通科创板适当性条件投资者数量'       as ZBMC
      ,SUM(CASE WHEN t.CUST_CGY = '1'
            THEN 1
			WHEN a1.CUST_NO IS NOT NULL
			THEN 1
			ELSE 0
			END) as ZBZ 
			
FROM           DDW_PROD.T_DDW_F00_CUST_CUST_INFO t 
INNER JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                           a2
ON             t.BRH_NO = a2.BRH_NO
AND            a2.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN (SELECT KHH as CUST_NO FROM DDW_PROD.T_DDW_PRT_CIF_TKHZB WHERE ZBDM = '20RRJZC_ZQHGTZZ' AND ZBZ >= 500000) a1
ON    t.CUST_NO = a1.CUST_NO

WHERE t.BUS_DATE =%d{yyyyMMdd}
AND   t.ORDI_CUST_STAT < > '3'
AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
GROUP BY belto_filil,brh_no,ZBMC,brh_fullnm
UNION ALL
SELECT  t.belto_filil
	   ,t.BRH_NO    as BRH_NO 
       ,t.brh_fullnm	   
       ,'开通科创板且开通两融权限的投资者'       as ZBMC
       ,COUNT(1) as ZBZ 
FROM 
(SELECT          t.CUST_NO as CUST_NO             
               ,MIN(NVL(t.OPNAC_DT,99999999)) as OPNAC_DT
              ,MAX(NVL(t.CNCLACT_DT,99999999)) as CNCLACT_DT            
              ,MIN(DECODE(t.CPTL_ACCNT_STAT,'0','0','3','3','0'))  as CPTL_ACCNT_STAT
			  ,a2.brh_no as brh_no
			  ,a2.belto_filil as belto_filil
			  ,a2.brh_fullnm
FROM       DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS t
LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_INFO a1
ON         t.CUST_NO = a1.CUST_NO
AND        t.BUS_DATE = a1.BUS_DATE
LEFT JOIN DDW_PROD.T_DDW_INR_ORG_BRH                    a2
ON        a1.BRH_NO = a2.BRH_NO
AND       a2.BUS_DATE = %d{yyyyMMdd}
WHERE      t.BUS_DATE = %d{yyyyMMdd}
AND        t.SYS_SRC IN ('信用账户')
AND        a2.BRH_NO IS NOT NULL
AND        t.CUST_NO < > '100610335855'
AND       NVL(t.OPNAC_DT,99999999) < = %d{yyyyMMdd}
GROUP BY CUST_NO,brh_no,belto_filil,brh_fullnm ) t
INNER JOIN (select cust_no FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL 
WHERE BUS_DATE = %d{yyyyMMdd} 
AND   OPN_PRVL = 20
AND %d{yyyyMMdd} BETWEEN  opn_dt  AND chg_dt
group by cust_no
) a1
ON  t.CUST_NO = a1.CUST_NO
AND t.CPTL_ACCNT_STAT < > '3'
GROUP BY belto_filil,brh_no,ZBMC,brh_fullnm
 ;
  invalidate metadata DDW_PROD.T_DDW_PRT_KCBZBZ ; 
--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:定期定额申购品种表                                                                   */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T04_TOF_DQDESGPZ;
------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TOF_DQDESGPZ
 (
                                     TADM                                --TA代码                               
                                    ,PZDM                                --品种代码                               
                                    ,PZSM                                --品种说明                               
                                    ,NX                                  --年限                                 
                                    ,SCSGZDJE                            --首次申购下限                             
                                    ,ZDSGJE                              --最低申购下限                             
                                    ,SGJEJS                              --申购金额基数                             
                                    ,MYKKRQ                              --每月扣款日期                             
                                    ,ZDLJWYCS                            --最大累计违约次数                           
                                    ,ZDLXWYCS                            --最大连续违约次数                           
                                    ,BKKBZ                               --是否补扣款                              
                                    ,QYBZ                                --是否需要签约                             
                                    ,QYJJDM                              --签约基金代码    
                                    ,XTBS 								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.TADM                                as TADM                                --TA代码                                
                                    ,t.PZDM                                as PZDM                                --品种代码                                
                                    ,t.PZSM                                as PZSM                                --品种说明                                
                                    ,t.NX                                  as NX                                  --年限                                  
                                    ,t.SCSGZDJE                            as SCSGZDJE                            --首次申购下限                              
                                    ,t.ZDSGJE                              as ZDSGJE                              --最低申购下限                              
                                    ,t.SGJEJS                              as SGJEJS                              --申购金额基数                              
                                    ,t.MYKKRQ                              as MYKKRQ                              --每月扣款日期                              
                                    ,t.ZDLJWYCS                            as ZDLJWYCS                            --最大累计违约次数                            
                                    ,t.ZDLXWYCS                            as ZDLXWYCS                            --最大连续违约次数                            
                                    ,t.BKKBZ                               as BKKBZ                               --是否补扣款                               
                                    ,t.QYBZ                                as QYBZ                                --是否需要签约                              
                                    ,t.QYJJDM                              as QYJJDM                              --签约基金代码 
                                    ,'JZJY'								   
 FROM JZJYCX.OFS_TOF_DQDESGPZ t 
 WHERE t.DT = '%d{yyyyMMdd}';
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TOF_DQDESGPZ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;


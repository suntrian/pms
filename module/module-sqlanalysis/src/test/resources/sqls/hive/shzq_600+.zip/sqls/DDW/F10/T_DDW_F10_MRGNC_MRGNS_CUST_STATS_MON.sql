------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:融资融券客户统计月表                                                                */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

------期初
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP 
 as SELECT CUST_NO
          ,a.CRD_AST                    as STRT_CRD_AST                     --期初信用总资产
		  ,a.CRD_NET_AST                as STRT_CRD_NET_AST                 --期初信用净资产
		  ,a.CRD_CPTL                   as STRT_CRD_CPTL                    --期初信用资金余额
		  ,a.CRD_MKTVAL                 as STRT_CRD_MKTVAL                  --期初信用市值
		  ,a.CRD_MKTVAL_HA              as STRT_CRD_MKTVAL_HA               --期初信用沪A市值
		  ,a.CRD_MKTVAL_SA              as STRT_CRD_MKTVAL_SA               --期初信用深A市值
		  ,a.CRD_MKTVAL_BOND_H          as STRT_CRD_MKTVAL_BOND_H           --期初信用沪债券市值
		  ,a.CRD_MKTVAL_BOND_S          as STRT_CRD_MKTVAL_BOND_S           --期初信用深债券市值
		  ,a.CRD_MKTVAL_FND_H           as STRT_CRD_MKTVAL_FND_H            --期初信用沪场内基金市值
		  ,a.CRD_MKTVAL_FND_S           as STRT_CRD_MKTVAL_FND_S            --期初信用深场内基金市值
		  ,a.CRD_MKTVAL_OTH             as STRT_CRD_MKTVAL_OTH              --期初信用其他市值
		  ,a.CRD_HLD_COST               as STRT_CRD_HLD_COST                --期初信用持仓成本
		  ,a.CRD_GL                     as STRT_CRD_GL                      --期初信用负债
		  ,a.MRGNC_GL                   as STRT_MRGNC_GL                    --期初融资负债
		  ,a.MRGNS_GL                   as STRT_MRGNS_GL                    --期初融券负债
		  ,a.CRD_GL_HA                  as STRT_CRD_GL_HA                   --期初沪A信用负债
		  ,a.CRD_GL_SA                  as STRT_CRD_GL_SA                   --期初深A信用负债
		  ,a.MRGNC_CRD_QUO              as STRT_MRGNC_CRD_QUO               --期初融资授信额度
		  ,a.MRGNS_CRD_QUO              as STRT_MRGNS_CRD_QUO               --期初融券授信额度		
		  ,a.HLD_COST                   as STRT_HLD_COST                    --期初持仓成本		
		  ,a.GNT_RTO                    as STRT_GNT_RTO                     --期初担保比例		
		  ,a.AVL_BOND                   as STRT_AVL_BOND                    --期初可用保证金
		  ,a.CASH_DEP_CRD_MKTVAL        as STRT_CASH_DEP_CRD_MKTVAL         --期初可充抵保证金证券市值
		  ,a.MRGNC_INL_GL               as STRT_MRGNC_INL_GL                --期初融资初始负债
		  ,a.MRGNS_INL_GL               as STRT_MRGNS_INL_GL                --期初融券初始负债
 FROM        DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY   a
 WHERE  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                                    FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                       WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                       AND BUS_DATE = %d{yyyyMMdd}
				                   )  b
                     WHERE  a.BUS_DATE = b.MON_START
				      )
	   AND  SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) 
       ;

 -----期末
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP1
 as SELECT CUST_NO
          ,a.CRD_AST               as FNL_CRD_AST                     --期末信用总资产
		  ,a.CRD_NET_AST           as FNL_CRD_NET_AST                 --期末信用净资产
		  ,a.CRD_CPTL              as FNL_CRD_CPTL                    --期末信用资金余额
		  ,a.CRD_MKTVAL            as FNL_CRD_MKTVAL                  --期末信用市值
		  ,a.CRD_MKTVAL_HA         as FNL_CRD_MKTVAL_HA               --期末信用沪A市值
		  ,a.CRD_MKTVAL_SA         as FNL_CRD_MKTVAL_SA               --期末信用深A市值
		  ,a.CRD_MKTVAL_BOND_H     as FNL_CRD_MKTVAL_BOND_H           --期末信用沪债券市值
		  ,a.CRD_MKTVAL_BOND_S     as FNL_CRD_MKTVAL_BOND_S           --期末信用深债券市值
		  ,a.CRD_MKTVAL_FND_H      as FNL_CRD_MKTVAL_FND_H            --期末信用沪场内基金市值
		  ,a.CRD_MKTVAL_FND_S      as FNL_CRD_MKTVAL_FND_S            --期末信用深场内基金市值
		  ,a.CRD_MKTVAL_OTH        as FNL_CRD_MKTVAL_OTH              --期末信用其他市值
		  ,a.CRD_HLD_COST          as FNL_CRD_HLD_COST                --期末信用持仓成本
		  ,a.CRD_GL                as FNL_CRD_GL                      --期末信用负债
		  ,a.MRGNC_GL              as FNL_MRGNC_GL                    --期末融资负债
		  ,a.MRGNS_GL              as FNL_MRGNS_GL                    --期末融券负债
		  ,a.CRD_GL_HA             as FNL_CRD_GL_HA                   --期末沪A信用负债
		  ,a.CRD_GL_SA             as FNL_CRD_GL_SA                   --期末深A信用负债
		  ,a.MRGNC_CRD_QUO         as FNL_MRGNC_CRD_QUO               --期末融资授信额度
		  ,a.MRGNS_CRD_QUO         as FNL_MRGNS_CRD_QUO               --期末融券授信额度		
		  ,a.HLD_COST              as FNL_HLD_COST                    --期末持仓成本		
		  ,a.GNT_RTO               as FNL_GNT_RTO                     --期末担保比例		
		  ,a.AVL_BOND              as FNL_AVL_BOND                    --期末可用保证金
		  ,a.REP_AMT               as FNL_REP_AMT                     --期末还款金额
		  ,a.REP_AMT               as FNL_REP_QTY                     --期末还券数量
		  ,a.CASH_DEP_CRD_MKTVAL   as FNL_CASH_DEP_CRD_MKTVAL         --期末可充抵保证金证券市值
		  ,a.MRGNC_INL_GL          as FNL_MRGNC_INL_GL                --期末融资初始负债
		  ,a.MRGNS_INL_GL          as FNL_MRGNS_INL_GL                --期末融券初始负债
 FROM        DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY   a
 WHERE       a.BUS_DATE = %d{yyyyMMdd}  ;
 ----月
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP2 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP2
 as SELECT CUST_NO
          ,SUM(MRGNC_FEE)                as MRGNC_FEE                    --融资费用
		  ,SUM(MRGNS_FEE)                as MRGNS_FEE                    --融券费用		
		  ,SUM(MRGNC_TRD_VOL)            as MRGNC_TRD_VOL                --融资交易量   
		  ,SUM(MRGNS_TRD_VOL)            as MRGNS_TRD_VOL                --融券交易量   
		  ,SUM(TRD_VOL)                  as TRD_VOL                      --交易量
		  ,SUM(TRD_VOL_ORDI)             as TRD_VOL_ORDI                 --交易量(普通) 
		  ,SUM(TRD_VOL_CRD)              as TRD_VOL_CRD                  --交易量(信用) 
		  ,SUM(BUYIN_TRD_VOL_ORDI)       as BUYIN_TRD_VOL_ORDI           --买入交易量(普通) 
		  ,SUM(BUYIN_TRD_VOL_CRD)        as BUYIN_TRD_VOL_CRD            --买入交易量(信用)
		  ,SUM(SELL_TRD_VOL_ORDI)        as SELL_TRD_VOL_ORDI            --卖出交易量(普通)
		  ,SUM(SELL_TRD_VOL_CRD)         as SELL_TRD_VOL_CRD             --卖出交易量(信用)
		  ,SUM(S1)                       as S1                           --毛佣金
		  ,SUM(ORDI_TRD_S1)              as ORDI_TRD_S1                  --普通交易毛佣金
		  ,SUM(CRD_TRD_S1)               as CRD_TRD_S1                   --信用交易毛佣金
		  ,SUM(NET_S1)                   as NET_S1                       --净佣金
		  ,SUM(ORDI_TRD_NET_S1)          as ORDI_TRD_NET_S1              --普通交易净佣金
		  ,SUM(CRD_TRD_NET_S1)           as CRD_TRD_NET_S1               --信用交易净佣金
		  ,SUM(MTCH_ITMS)                as MTCH_ITMS                    --成交笔数
		  ,SUM(MRGNC_MTCH_ITMS)          as MRGNC_MTCH_ITMS              --融资成交笔数
		  ,SUM(MRGNS_MTCH_ITMS)          as MRGNS_MTCH_ITMS              --融券成交笔数		
		  ,SUM(TDY_RTN_INT)              as TDM_RTN_INT                  --当月归还利息
          ,SUM(PRDCT_INT)                as PRDCT_INT                    --预计利息
          ,SUM(MRGNC_PRDCT_INT)          as MRGNC_PRDCT_INT              --融资预计利息
          ,SUM(MRGNS_PRDCT_INT)          as MRGNS_PRDCT_INT              --融券预计利息
          ,SUM(TDY_ADDED_CRD_INT)        as TDM_ADDED_CRD_INT            --当月新增信用利息
          ,SUM(TDY_ADDED_MRGNC_INT)      as TDM_ADDED_MRGNC_INT          --当月新增融资利息
		  ,SUM(TDY_ADDED_MRGNS_INT)      as TDM_ADDED_MRGNS_INT          --当月新增融券利息
		  ,SUM(CP_TMS)                   as CP_TMS                       --平仓次数 WTLB IN (71,72)
		  ,SUM(ADD_BOND_TMS)             as ADD_BOND_TMS                 --追保次数 
		  ,SUM(CRD_TFR_IN_AMT)           as CRD_TFR_IN_AMT               --信用转入资金
		  ,SUM(CRD_TURN_OUT_AMT)         as CRD_TURN_OUT_AMT             --信用转出资金
		  ,SUM(CRD_TFR_IN_MKTVAL)        as CRD_TFR_IN_MKTVAL            --信用转入市值
		  ,SUM(CRD_TURN_OUT_MKTVAL)      as CRD_TURN_OUT_MKTVAL          --信用转出市值	
          ,SUM(OVDU_TMS)                 as OVDU_TMS                     --逾期次数		  
		  ,SUM(CRD_PRFT)                 as CRD_PRFT                     --信用盈亏
 FROM        DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY   
 WHERE       SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 GROUP BY    CUST_NO
  ;
  
  ---
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP3 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP3
 as SELECT CUST_NO
           ,SUM(ROUND(a.MRGNC_INL_GL*1.000/c.NUM,2)) as AVG_MRGNC_INL_GL                  --日均融资初始负债
		   ,SUM(ROUND(a.MRGNS_INL_GL*1.000/c.NUM,2)) as AVG_MRGNS_INL_GL                  --日均融券初始负债
 FROM       (SELECT 1 as ID,* FROM  DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY 
             WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
             )			 a
 LEFT JOIN   EDW_PROD.T_EDW_T99_TRD_DATE                     b
 ON          a.BUS_DATE = b.TRD_DT
 AND         b.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN (SELECT 1 as ID,COUNT(1) as NUM 
            FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
            WHERE BUS_DATE = %d{yyyyMMdd}
			AND   SUBSTR(CAST(NAT_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			) c
 ON       a.ID = c.ID
 WHERE        SUBSTR(CAST(b.NAT_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 GROUP BY    CUST_NO
  ;

 
 ------插入数据
  INSERT OVERWRITE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON
(        CUST_NO                              --客户号                 
        ,BRH_NO                               --营业部编号                         
        ,CUST_CGY			                  --客户类别
        ,CRD_LVL                              --信用等级		
		,STRT_CRD_AST                         --期初信用总资产
		,STRT_CRD_NET_AST                     --期初信用净资产
		,STRT_CRD_CPTL                        --期初信用资金余额
		,STRT_CRD_MKTVAL                      --期初信用市值
		,STRT_CRD_MKTVAL_HA                   --期初信用沪A市值
		,STRT_CRD_MKTVAL_SA                   --期初信用深A市值
		,STRT_CRD_MKTVAL_BOND_H               --期初信用沪债券市值
		,STRT_CRD_MKTVAL_BOND_S               --期初信用深债券市值
		,STRT_CRD_MKTVAL_FND_H                --期初信用沪场内基金市值
		,STRT_CRD_MKTVAL_FND_S                --期初信用深场内基金市值
		,STRT_CRD_MKTVAL_OTH                  --期初信用其他市值
		,STRT_CRD_HLD_COST                    --期初信用持仓成本
		,STRT_CRD_GL                          --期初信用负债
		,STRT_MRGNC_GL                        --期初融资负债
		,STRT_MRGNS_GL                        --期初融券负债
		,STRT_CRD_GL_HA                       --期初沪A信用负债
		,STRT_CRD_GL_SA                       --期初深A信用负债
		,STRT_MRGNC_CRD_QUO                   --期初融资授信额度
		,STRT_MRGNS_CRD_QUO                   --期初融券授信额度		
		,STRT_HLD_COST                        --期初持仓成本		
		,STRT_GNT_RTO                         --期初担保比例		
		,STRT_AVL_BOND                        --期初可用保证金
        ,STRT_CASH_DEP_CRD_MKTVAL             --期初可充抵保证金证券市值		
		,FNL_CRD_AST                          --期末信用总资产		
		,FNL_CRD_NET_AST                      --期末信用净资产		
		,FNL_CRD_CPTL                         --期末信用资金余额		
		,FNL_CRD_MKTVAL                       --期末信用市值      
		,FNL_CRD_MKTVAL_HA                    --期末信用沪A市值
		,FNL_CRD_MKTVAL_SA                    --期末信用深A市值
		,FNL_CRD_MKTVAL_BOND_H                --期末信用沪债券市值
		,FNL_CRD_MKTVAL_BOND_S                --期末信用深债券市值		
		,FNL_CRD_MKTVAL_FND_H                 --期末信用沪场内基金市值
		,FNL_CRD_MKTVAL_FND_S                 --期末信用深场内基金市值	
		,FNL_CRD_MKTVAL_OTH                   --期末信用其他市值
		,FNL_CRD_HLD_COST                     --期末信用持仓成本  
		,FNL_CRD_GL                           --期末信用负债
		,FNL_MRGNC_GL                         --期末融资负债		
		,FNL_MRGNS_GL                         --期末融券负债	
		,FNL_CRD_GL_HA                        --期末沪A信用负债
		,FNL_CRD_GL_SA                        --期末深A信用负债		
		,FNL_MRGNC_CRD_QUO                    --期末融资授信额度
		,FNL_MRGNS_CRD_QUO                    --期末融券授信额度
		,FNL_HLD_COST                         --期末持仓成本
		,FNL_GNT_RTO                          --期末担保比例
		,FNL_AVL_BOND                         --期末可用保证金		
		,FNL_REP_AMT                          --期末还款金额
		,FNL_REP_QTY                          --期末还券数量
        ,FNL_CASH_DEP_CRD_MKTVAL              --期末可充抵保证金证券市值		
		,MRGNC_FEE                            --融资费用
		,MRGNS_FEE                            --融券费用		
		,MRGNC_TRD_VOL                        --融资交易量   
		,MRGNS_TRD_VOL                        --融券交易量   
		,TRD_VOL                              --交易量
		,TRD_VOL_ORDI                         --交易量(普通) 
		,TRD_VOL_CRD                          --交易量(信用) 
		,BUYIN_TRD_VOL_ORDI                   --买入交易量(普通) 
		,BUYIN_TRD_VOL_CRD                    --买入交易量(信用)
		,SELL_TRD_VOL_ORDI                    --卖出交易量(普通)
		,SELL_TRD_VOL_CRD                     --卖出交易量(信用)
		,S1                                   --毛佣金
		,ORDI_TRD_S1                          --普通交易毛佣金
		,CRD_TRD_S1                           --信用交易毛佣金
		,NET_S1                               --净佣金
		,ORDI_TRD_NET_S1                      --普通交易净佣金
		,CRD_TRD_NET_S1                       --信用交易净佣金
		,MTCH_ITMS                            --成交笔数
		,MRGNC_MTCH_ITMS                      --融资成交笔数
		,MRGNS_MTCH_ITMS                      --融券成交笔数		
		,TDM_RTN_INT                          --当月归还利息	
		,PRDCT_INT                            --预计利息
		,MRGNC_PRDCT_INT                      --融资预计利息
		,MRGNS_PRDCT_INT                      --融券预计利息
		,TDM_ADDED_CRD_INT                    --当月新增信用利息
		,TDM_ADDED_MRGNC_INT                  --当月新增融资利息
		,TDM_ADDED_MRGNS_INT                  --当月新增融券利息
		,CP_TMS                               --平仓次数 WTLB IN (71,72)
		,ADD_BOND_TMS                         --追保次数 
		,CRD_TFR_IN_AMT                       --信用转入资金
		,CRD_TURN_OUT_AMT                     --信用转出资金
		,CRD_TFR_IN_MKTVAL                    --信用转入市值
		,CRD_TURN_OUT_MKTVAL                  --信用转出市值
        ,OVDU_TMS	                          --逾期次数	
		,CRD_PRFT                             --信用盈亏
		,ETL_DT   
        ,STRT_MRGNC_INL_GL                    --期初融资初始负债
        ,STRT_MRGNS_INL_GL                    --期初融券初始负债
        ,FNL_MRGNC_INL_GL                     --期末融资初始负债
        ,FNL_MRGNS_INL_GL                     --期末融券初始负债
        ,AVG_MRGNC_INL_GL                     --日均融资初始负债
        ,AVG_MRGNS_INL_GL                     --日均融券初始负债		
 ) partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 
 SELECT  t.CUST_NO                              --客户号                 
        ,t.BRH_NO                               --营业部编号                         
        ,t.CUST_CGY			                  --客户类别
        ,a1.XYDJ as CRD_LVL                              --信用等级		
		,NVL(a2.STRT_CRD_AST,0)                         --期初信用总资产
		,NVL(a2.STRT_CRD_NET_AST,0)                     --期初信用净资产
		,NVL(a2.STRT_CRD_CPTL,0)                        --期初信用资金余额
		,NVL(a2.STRT_CRD_MKTVAL,0)                      --期初信用市值
		,NVL(a2.STRT_CRD_MKTVAL_HA,0)                   --期初信用沪A市值
		,NVL(a2.STRT_CRD_MKTVAL_SA,0)                   --期初信用深A市值
		,NVL(a2.STRT_CRD_MKTVAL_BOND_H,0)               --期初信用沪债券市值
		,NVL(a2.STRT_CRD_MKTVAL_BOND_S,0)               --期初信用深债券市值
		,NVL(a2.STRT_CRD_MKTVAL_FND_H,0)                --期初信用沪场内基金市值
		,NVL(a2.STRT_CRD_MKTVAL_FND_S,0)                --期初信用深场内基金市值
		,NVL(a2.STRT_CRD_MKTVAL_OTH,0)                  --期初信用其他市值
		,NVL(a2.STRT_CRD_HLD_COST,0)                    --期初信用持仓成本
		,NVL(a2.STRT_CRD_GL,0)                          --期初信用负债
		,NVL(a2.STRT_MRGNC_GL,0)                        --期初融资负债
		,NVL(a2.STRT_MRGNS_GL,0)                        --期初融券负债
		,NVL(a2.STRT_CRD_GL_HA,0)                       --期初沪A信用负债
		,NVL(a2.STRT_CRD_GL_SA,0)                       --期初深A信用负债
		,NVL(a2.STRT_MRGNC_CRD_QUO,0)                   --期初融资授信额度
		,NVL(a2.STRT_MRGNS_CRD_QUO,0)                   --期初融券授信额度		
		,NVL(a2.STRT_HLD_COST,0)                        --期初持仓成本		
		,NVL(a2.STRT_GNT_RTO,0)                         --期初担保比例		
		,NVL(a2.STRT_AVL_BOND,0)                        --期初可用保证金
        ,NVL(a2.STRT_CASH_DEP_CRD_MKTVAL,0)             --期初可充抵保证金证券市值		
		,NVL(a3.FNL_CRD_AST,0)                          --期末信用总资产		
		,NVL(a3.FNL_CRD_NET_AST,0)                      --期末信用净资产		
		,NVL(a3.FNL_CRD_CPTL,0)                         --期末信用资金余额		
		,NVL(a3.FNL_CRD_MKTVAL,0)                       --期末信用市值      
		,NVL(a3.FNL_CRD_MKTVAL_HA,0)                    --期末信用沪A市值
		,NVL(a3.FNL_CRD_MKTVAL_SA,0)                    --期末信用深A市值
		,NVL(a3.FNL_CRD_MKTVAL_BOND_H,0)                --期末信用沪债券市值
		,NVL(a3.FNL_CRD_MKTVAL_BOND_S,0)                --期末信用深债券市值		
		,NVL(a3.FNL_CRD_MKTVAL_FND_H,0)                 --期末信用沪场内基金市值
		,NVL(a3.FNL_CRD_MKTVAL_FND_S,0)                 --期末信用深场内基金市值	
		,NVL(a3.FNL_CRD_MKTVAL_OTH,0)                   --期末信用其他市值
		,NVL(a3.FNL_CRD_HLD_COST,0)                     --期末信用持仓成本  
		,NVL(a3.FNL_CRD_GL,0)                           --期末信用负债
		,NVL(a3.FNL_MRGNC_GL,0)                         --期末融资负债		
		,NVL(a3.FNL_MRGNS_GL,0)                         --期末融券负债	
		,NVL(a3.FNL_CRD_GL_HA,0)                        --期末沪A信用负债
		,NVL(a3.FNL_CRD_GL_SA,0)                        --期末深A信用负债		
		,NVL(a3.FNL_MRGNC_CRD_QUO,0)                    --期末融资授信额度
		,NVL(a3.FNL_MRGNS_CRD_QUO,0)                    --期末融券授信额度
		,NVL(a3.FNL_HLD_COST,0)                         --期末持仓成本
		,NVL(a3.FNL_GNT_RTO,0)                          --期末担保比例
		,NVL(a3.FNL_AVL_BOND,0)                         --期末可用保证金		
		,NVL(a3.FNL_REP_AMT,0)                          --期末还款金额
		,NVL(a3.FNL_REP_QTY,0)                          --期末还券数量
        ,NVL(a3.FNL_CASH_DEP_CRD_MKTVAL,0)              --期末可充抵保证金证券市值			
		,NVL(a4.MRGNC_FEE,0)                            --融资费用
		,NVL(a4.MRGNS_FEE,0)                            --融券费用		
		,NVL(a4.MRGNC_TRD_VOL,0)                        --融资交易量   
		,NVL(a4.MRGNS_TRD_VOL,0)                        --融券交易量   
		,NVL(a4.TRD_VOL,0)                              --交易量
		,NVL(a4.TRD_VOL_ORDI,0)                         --交易量(普通) 
		,NVL(a4.TRD_VOL_CRD,0)                          --交易量(信用) 
		,NVL(a4.BUYIN_TRD_VOL_ORDI,0)                   --买入交易量(普通) 
		,NVL(a4.BUYIN_TRD_VOL_CRD,0)                    --买入交易量(信用)
		,NVL(a4.SELL_TRD_VOL_ORDI,0)                    --卖出交易量(普通)
		,NVL(a4.SELL_TRD_VOL_CRD,0)                     --卖出交易量(信用)
		,NVL(a4.S1,0)                                   --毛佣金
		,NVL(a4.ORDI_TRD_S1,0)                          --普通交易毛佣金
		,NVL(a4.CRD_TRD_S1,0)                           --信用交易毛佣金
		,NVL(a4.NET_S1,0)                               --净佣金
		,NVL(a4.ORDI_TRD_NET_S1,0)                      --普通交易净佣金
		,NVL(a4.CRD_TRD_NET_S1,0)                       --信用交易净佣金
		,NVL(a4.MTCH_ITMS,0)                            --成交笔数
		,NVL(a4.MRGNC_MTCH_ITMS,0)                      --融资成交笔数
		,NVL(a4.MRGNS_MTCH_ITMS,0)                      --融券成交笔数		
		,NVL(a4.TDM_RTN_INT,0)                          --当月归还利息	
		,NVL(a4.PRDCT_INT,0)                            --预计利息
		,NVL(a4.MRGNC_PRDCT_INT,0)                      --融资预计利息
		,NVL(a4.MRGNS_PRDCT_INT,0)                      --融券预计利息
		,NVL(a4.TDM_ADDED_CRD_INT,0)                    --当月新增信用利息
		,NVL(a4.TDM_ADDED_MRGNC_INT,0)                  --当月新增融资利息
		,NVL(a4.TDM_ADDED_MRGNS_INT,0)                  --当月新增融券利息
		,NVL(a4.CP_TMS,0)                               --平仓次数 WTLB IN (71,72)
		,NVL(a4.ADD_BOND_TMS,0)                         --追保次数 
		,NVL(a4.CRD_TFR_IN_AMT,0)                       --信用转入资金
		,NVL(a4.CRD_TURN_OUT_AMT,0)                     --信用转出资金
		,NVL(a4.CRD_TFR_IN_MKTVAL,0)                    --信用转入市值
		,NVL(a4.CRD_TURN_OUT_MKTVAL,0)                  --信用转出市值
        ,NVL(a4.OVDU_TMS,0)                             --逾期次数		
		,NVL(a4.CRD_PRFT,0)                             --信用盈亏
		,%d{yyyyMMdd}   as ETL_DT
		,NVL(a2.STRT_MRGNC_INL_GL,0)                 --期初融资初始负债
        ,NVL(a2.STRT_MRGNS_INL_GL,0)                 --期初融券初始负债
        ,NVL(a3.FNL_MRGNC_INL_GL,0)                  --期末融资初始负债
        ,NVL(a3.FNL_MRGNS_INL_GL,0)                  --期末融券初始负债
        ,NVL(a5.AVG_MRGNC_INL_GL,0)                  --日均融资初始负债
        ,NVL(a5.AVG_MRGNS_INL_GL,0)                  --日均融券初始负债
 FROM (SELECT CUST_NO,BRH_NO,CUST_CGY 
       FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO 
	   WHERE BUS_DATE = %d{yyyyMMdd}
	   )                                        t		
LEFT JOIN RZRQCX.MARGIN_TXY_KHXX a1
ON        t.CUST_NO = a1.KHH
AND       a1.DT = '%d{yyyyMMdd}'
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP a2
ON       t.CUST_NO = a2.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP1 a3
ON       t.CUST_NO = a3.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP2 a4
ON       t.CUST_NO = a4.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP3 a5
ON       t.CUST_NO = a5.CUST_NO
WHERE COALESCE(a2.CUST_NO,a3.CUST_NO,a4.CUST_NO,a5.CUST_NO) IS NOT NULL ;

----删除
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP1 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP2 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON_TEMP3 ;
 
-----------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON;
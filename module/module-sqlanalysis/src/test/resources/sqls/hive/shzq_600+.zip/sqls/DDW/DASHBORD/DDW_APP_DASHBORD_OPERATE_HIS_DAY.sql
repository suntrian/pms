--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:运营领导驾驶舱历史日表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 ----每个人的总笔数,个人笔数,机构笔数
   DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP ;
  CREATE TABLE RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP 
  as SELECT a.AUDT_PSN_NAME
            ,a.BIZ_CD
			,a.BUS_DATE
			,COUNT(1) as AUDT_ITMS             --审核笔数
			,SUM(DECODE(a.CUST_CGY,'0',1,0)) as IDV_BIZ_ITMS       --个人业务笔数
		    ,SUM(DECODE(a.CUST_CGY,'1',1,0)) as ORG_BIZ_ITMS       --机构业务笔数
	 FROM (SELECT  AUDT_PSN_NAME
                   ,BIZ_CD
			       ,BIZ_APL_ID
			       ,BUS_DATE
				   ,CUST_CGY
	       FROM   DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT
	       WHERE  (OPRT_TP IN (321,322) AND BIZ_APL_STAT IN ('8','9','80','90','42') 
		           AND IF_BIZ_APL_STAT = 1 )
	       OR     OPRT_TP IN (301,302,211)
	       GROUP BY  AUDT_PSN_NAME
                     ,BIZ_CD
			         ,BIZ_APL_ID
			         ,BUS_DATE
				     ,CUST_CGY
          ) a
	GROUP BY  a.AUDT_PSN_NAME
              ,a.BIZ_CD
			  ,a.BUS_DATE
	;
-----每个人的成功笔数,失败笔数,退回笔数
  DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP1 ;
  CREATE TABLE RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP1 
  as SELECT a.AUDT_PSN_NAME
            ,a.BIZ_CD
			,a.BUS_DATE
            ,SUM(CASE WHEN IF_SUCS IN (0,3)
			          THEN 1
				      ELSE 0
				      END
				)      as SUCS_ITMS
			,SUM(CASE WHEN IF_SUCS IN (1,4)
			          THEN 1
				      ELSE 0
				      END
				)      as FALL_ITMS
			,SUM(CASE WHEN IF_SUCS IN (2,3,4)
			          THEN 1
				      ELSE 0
				      END
				)      as RETURN_ITMS
  FROM  (SELECT    AUDT_PSN_NAME
                  ,BIZ_CD
			      ,BIZ_APL_ID
			      ,BUS_DATE
			      ,CASE WHEN OPRT_TP = 301
			            THEN 0
				        WHEN OPRT_TP = 302
				        THEN 1
				        WHEN OPRT_TP IN (321,322)
				        AND  IF_BIZ_APL_STAT = 1
				        AND  BIZ_APL_STAT IN ('8','9','80')
				        THEN 0
				        WHEN OPRT_TP IN (321,322)
				        AND  IF_BIZ_APL_STAT = 1
				        AND  BIZ_APL_STAT IN ('42','99')
				        THEN 1
				        WHEN OPRT_TP IN (211)
				        AND  IF_BIZ_APL_STAT = 1
				        AND  BIZ_APL_STAT IN ('8','9','80')
				        THEN 3
				        WHEN OPRT_TP IN (211)
				        AND  IF_BIZ_APL_STAT = 1
				        AND  BIZ_APL_STAT IN ('42','99')
				        THEN 4
				        WHEN OPRT_TP IN (211)
				        AND  IF_BIZ_APL_STAT = 0				 
				        THEN 2
				        WHEN OPRT_TP IN (211)
				        AND  IF_BIZ_APL_STAT = 1
                        AND  BIZ_APL_STAT NOT IN ('42','99','8','9','80')				  
				        THEN 2
				        ELSE -1
				        END  as IF_SUCS --(0-成功,1-失败,2-退回,3-成功+退回,4-失败+成功,-1-不算)
	FROM   DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT
	GROUP BY      AUDT_PSN_NAME
                  ,BIZ_CD
			      ,BIZ_APL_ID
			      ,BUS_DATE	
                  ,IF_SUCS				  
			) a
 WHERE  a.IF_SUCS < > -1
 GROUP BY    a.AUDT_PSN_NAME
            ,a.BIZ_CD
			,a.BUS_DATE
 ;
-----成功次数,失败次数,退回次数
   DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP2 ;
  CREATE TABLE RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP2
  as SELECT a.AUDT_PSN_NAME
            ,a.BIZ_CD
			,a.BUS_DATE
            ,SUM(CASE WHEN IF_SUCS IN (0,3)
			          THEN 1
				      ELSE 0
				      END
				)      as SUCS_TMS
			,SUM(CASE WHEN IF_SUCS IN (1,4)
			          THEN 1
				      ELSE 0
				      END
				)      as FALL_TMS
			,SUM(CASE WHEN IF_SUCS IN (2,3,4)
			          THEN 1
				      ELSE 0
				      END
				)      as RETURN_TMS
			,SUM(TMS)   as TMS
			,SUM(IDV_TMS) as IDV_TMS
			,SUM(ORG_TMS) as ORG_TMS
			,SUM(TMS1)  as TMS1
  FROM  (SELECT    AUDT_PSN_NAME
                  ,BIZ_CD
			      ,BIZ_APL_ID
			      ,BUS_DATE
			      ,CASE WHEN OPRT_TP = 301
			            THEN 0
				        WHEN OPRT_TP = 302
				        THEN 1				       
				        WHEN OPRT_TP IN (211)
				        AND  IF_BIZ_APL_STAT = 1
				        AND  BIZ_APL_STAT IN ('8','9','80')
				        THEN 3
				        WHEN OPRT_TP IN (211)
				        AND  IF_BIZ_APL_STAT = 1
				        AND  BIZ_APL_STAT IN ('42','99')
				        THEN 4
				        WHEN OPRT_TP IN (211)
				        AND  IF_BIZ_APL_STAT = 0				 
				        THEN 2
				        WHEN OPRT_TP IN (211)
				        AND  IF_BIZ_APL_STAT = 1
                        AND  BIZ_APL_STAT NOT IN ('42','99','8','9','80')				  
				        THEN 2
				        ELSE -1
				        END  as IF_SUCS --(0-成功,1-失败,2-退回,3-成功+退回,4-失败+成功,-1-不算)
					,CASE WHEN audt_ts < 43200
 					      THEN 1
						  ELSE 0 
						  END as TMS
					,CASE WHEN audt_ts < 43200
					      AND  CUST_CGY = '0'
 					      THEN 1
						  ELSE 0 
						  END as IDV_TMS
					,CASE WHEN audt_ts < 43200
					      AND  CUST_CGY = '1'
 					      THEN 1
						  ELSE 0 
						  END as ORG_TMS
					,1 as TMS1
	FROM   DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT
	WHERE  OPRT_TP IN (211,301,302)
	UNION  ALL
	SELECT    AUDT_PSN_NAME
                  ,BIZ_CD
			      ,BIZ_APL_ID
			      ,BUS_DATE
			      ,CASE WHEN OPRT_TP IN (321,322)
				        AND  IF_BIZ_APL_STAT = 1
				        AND  BIZ_APL_STAT IN ('8','9','80')
				        THEN 0
				        WHEN OPRT_TP IN (321,322)
				        AND  IF_BIZ_APL_STAT = 1
				        AND  BIZ_APL_STAT IN ('42','99')
				        THEN 1				       
				        ELSE -1
				        END  as IF_SUCS --(0-成功,1-失败,2-退回,3-成功+退回,4-失败+成功,-1-不算)
				 ,0 as TMS
				 ,0 as IDV_TMS
				 ,0 as ORG_TMS
				 ,1 as TMS1
	FROM   DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT
	WHERE   OPRT_TP IN (321,322)
	GROUP BY AUDT_PSN_NAME
            ,BIZ_CD
			,BIZ_APL_ID
            ,IF_SUCS
            ,BUS_DATE			
			) a
 WHERE  a.IF_SUCS < > -1
 GROUP BY    a.AUDT_PSN_NAME
            ,a.BIZ_CD
			,a.BUS_DATE
 ;
----总时长
   DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP3 ;
  CREATE TABLE RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP3
  as SELECT a.AUDT_PSN_NAME
            ,a.BIZ_CD
			,a.BUS_DATE
			,SUM(CASE WHEN a.AUDT_TS < 43200
    			      THEN a.AUDT_TS
				      ELSE 0
				      END)  as AUDT_TS
			,SUM(CASE WHEN a.AUDT_TS < 43200
			          AND  a.CUST_CGY = '0'
    			      THEN a.AUDT_TS
				      ELSE 0
				      END)  as IDV_AUDT_TS
			,SUM(CASE WHEN a.AUDT_TS < 43200
			          AND  a.CUST_CGY = '1'
    			      THEN a.AUDT_TS
				      ELSE 0
				      END)  as ORG_AUDT_TS
     FROM   DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT a
	 WHERE  OPRT_TP IN (211,301,302) 
	 GROUP BY a.AUDT_PSN_NAME
              ,a.BIZ_CD
			  ,a.BUS_DATE
	;

  
  
  
  INSERT   OVERWRITE RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY
  (
             AUDT_PSN_NAME         --审核人姓名 
            ,BIZ_CD_NAME           --业务名称
            ,AUDT_ITMS             --审核笔数
            ,IDV_BIZ_ITMS          --个人业务笔数
            ,ORG_BIZ_ITMS          --机构业务笔数
            ,RETURN_ITMS           --退回笔数
            ,SUCS_ITMS             --成功笔数
            ,FALL_ITMS             --失败笔数
			,RETURN_TMS            --退回次数
            ,SUCS_TMS              --成功次数
            ,FALL_TMS              --失败次数
			,TMS                   --次数
			,IDV_TMS               --个人次数
			,ORG_TMS               --机构次数
			,TMS1                   --次数1
            ,AUDT_TS               --审核时长
            ,IDV_AUDT_TS           --个人审核时长
			,ORG_AUDT_TS           --机构审核时长
            			
) 
PARTITION( BUS_DATE  )
  SELECT  t.AUDT_PSN_NAME                         as AUDT_PSN_NAME      --审核人姓名
          ,a4.YWMC                                as BIZ_CD_NAME        --业务名称
          ,NVL(t.AUDT_ITMS,0)		              as AUDT_ITMS          --审核笔数
		  ,NVL(t.IDV_BIZ_ITMS,0)                  as IDV_BIZ_ITMS       --个人业务笔数
		  ,NVL(t.ORG_BIZ_ITMS,0)                  as ORG_BIZ_ITMS       --机构业务笔数
          ,NVL(a1.RETURN_ITMS,0)                  as RETURN_ITMS        --退回笔数
		  ,NVL(a1.SUCS_ITMS,0)                    as SUCS_ITMS          --成功笔数
		  ,NVL(a1.FALL_ITMS,0)                    as FALL_ITMS          --失败笔数
		  ,NVL(a2.RETURN_TMS,0)                   as RETURN_TMS         --退回次数
		  ,NVL(a2.SUCS_TMS,0)                     as SUCS_TMS           --成功次数
		  ,NVL(a2.FALL_TMS,0)                     as FALL_TMS           --失败次数
		  ,NVL(a2.TMS,0)                          as TMS                --次数
		  ,NVL(a2.IDV_TMS,0)                      as IDV_TMS            --个人次数
		  ,NVL(a2.ORG_TMS,0)                      as ORG_TMS            --机构次数
		  ,NVL(a2.TMS1,0)                         as TMS1               --次数1
		  ,NVL(a3.AUDT_TS,0)                      as AUDT_TS            --审核时长
		  ,NVL(a3.IDV_AUDT_TS,0)                  as IDV_AUDT_TS        --个人审核时长
		  ,NVL(a3.ORG_AUDT_TS,0)                  as ORG_AUDT_TS        --机构审核时长		 
          ,t.BUS_DATE                      as BUS_DATE
 FROM      RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP t
 LEFT JOIN RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP1 a1
 ON        t.AUDT_PSN_NAME = a1.AUDT_PSN_NAME
 AND       t.BIZ_CD = a1.BIZ_CD
 AND       t.BUS_DATE = a1.BUS_DATE
 LEFT JOIN RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP2 a2
 ON        t.AUDT_PSN_NAME = a2.AUDT_PSN_NAME
 AND       t.BIZ_CD = a2.BIZ_CD
 AND       t.BUS_DATE = a2.BUS_DATE
 LEFT JOIN RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP3 a3
 ON        t.AUDT_PSN_NAME = a3.AUDT_PSN_NAME
 AND       t.BUS_DATE = a3.BUS_DATE
 AND       t.BIZ_CD = a3.BIZ_CD
 LEFT JOIN   EDW_PROD.T_EDW_T99_TYWDM              a4
 ON          t.BIZ_CD = a4.YWDM
 AND         a4.BUS_DATE = %d{yyyyMMdd} 
 ;
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','DDW_APP_DASHBORD_OPERATE_HIS_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
 
 --
 DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP ;
 DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP1 ;
 DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP2 ;
 DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY_TEMP3 ;
    invalidate metadata RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY ;
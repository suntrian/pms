--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:：每日增量插入用户登录数据                                                                      */
  --/* 创建人:程骏                                                                            */
  --/* 创建时间:2017-09-28
  
    ----插入数据--
   INSERT OVERWRITE DDW_PROD.T_DDW_NEW_USER_LOGIN
 (          
              QSMC               ,     --券商名称
              YYBMC              ,     --营业部名称
              ZJZH               ,     --资金账户
              GDMC               ,     -- 股东名称
              CZRQ               ,     --操作日期
              CZSJ               ,     --操作时间
              CZZY               ,     --操作描述
              SJLY               ,     --数据来源
              LOG_IP  			 ,     --登录IP地址
			  LOCAL_IP 			 ,     --本地IP地址
			  SERVER_IP 		 ,     --服务器IP地址
			  PUBLIC_IP  		 ,     --公共IP地址
              MAC                ,     --MAC地址
              DISK               ,     --磁盘序列号
              IMEI               ,     --IMEI
              IMSI               ,     --IMSI
              MOBILE             ,     --手机号
              CLIENT             ,     --客户端
              UUID               ,     --UUID
              SERVER             ,     --服务器
              CZSJC                    --操作时间戳
 ) partition  (bus_date ) 
 SELECT  
              QSMC     ,     --券商名称
              YYBMC     ,     --营业部名称
              ZJZH     ,     --资金账户
              GDMC    ,     -- 股东名称
              t.CZRQ     ,     --操作日期
              CZSJ    ,     --操作时间
              CZZY    ,     --操作描述
              SJLY    ,     --数据来源
              LOG_IP  ,     --登录IP地址
			  LOCAL_IP ,     --本地IP地址
			  SERVER_IP ,     --服务器IP地址
			  PUBLIC_IP  ,     --公共IP地址
              MAC    ,     --MAC地址
              DISK    ,     --磁盘序列号
              IMEI    ,     --IMEI
              IMSI    ,     --IMSI
              MOBILE    ,     --手机号
              CLIENT    ,     --客户端
              UUID    ,     --UUID
              SERVER    ,     --服务器
              CZSJC     ,    --操作时间戳
              CAST(t.CZRQ AS INT) AS BUS_DATE --操作日期
 FROM AIDER_NEW.USER_LOGIN t 
 WHERE    LENGTH(TRIM(t.CZRQ)) > 0
UNION ALL
 SELECT  
              QSMC     ,     --券商名称
              YYBMC     ,     --营业部名称
              ZJZH     ,     --资金账户
              GDMC    ,     -- 股东名称
              t.CZRQ     ,     --操作日期
              CZSJ    ,     --操作时间
              CZZY    ,     --操作描述
              SJLY    ,     --数据来源
              LOG_IP  ,     --登录IP地址
			  LOCAL_IP ,     --本地IP地址
			  SERVER_IP ,     --服务器IP地址
			  PUBLIC_IP  ,     --公共IP地址
              MAC    ,     --MAC地址
              DISK    ,     --磁盘序列号
              IMEI    ,     --IMEI
              IMSI    ,     --IMSI
              MOBILE    ,     --手机号
              CLIENT    ,     --客户端
              UUID    ,     --UUID
              SERVER    ,     --服务器
              CZSJC     ,    --操作时间戳
              CAST(bus_dt as INT) AS BUS_DATE --操作日期
 FROM AIDER_NEW.USER_LOGIN t 
 WHERE    LENGTH(TRIM(t.CZRQ)) = 0 ;
----结束
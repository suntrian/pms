 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:行情表日表                                                                       */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-05-08                                                                        */ 

-- 交易市场(1:场内基金,股票,债券。2:场外基金。3:期权行情,4:OTC产品的净值)---
--数据来源DATA_SRC(1 系统,2 聚源)
-----删除今天的数据---
 ALTER TABLE DDW_PROD.T_DDW_PUB_QOT DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ; 
-----取出有用的行情--	
--创建临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PUB_QOT_TEMP;
 CREATE TABLE  DDW_PROD.T_DDW_PUB_QOT_TEMP  as
 SELECT        a.InfoType
               ,SUBSTR(b.SecurityCode,1,6) as ZQDM
		       ,CAST(CONCAt(substr(a.SplitDay,1,4),substr(a.SplitDay,6,2),substr(a.SplitDay,9,2) ) as INT) as SplitDay
			   ,CASE WHEN SUBSTR(b.SecurityCode,1,3) in ('519','501','502','503','506','500','505','510','511','512','513','518','515')
					 THEN 'SH'
					 WHEN SUBSTR(b.SecurityCode,1,3) IN ('159','160','161','162','163','164','165','166','167','168','169','184','150','151')
					 THEN 'SZ'
					 ELSE 'CWJJ'
					 END   as JYS	  
		       ,a.SplitType
		       ,CAST(CONCAt(substr(a.OutcomeNoticeIssueDate,1,4),substr(a.OutcomeNoticeIssueDate,6,2),substr(a.OutcomeNoticeIssueDate,9,2) ) as INT) as OutcomeNoticeIssueDate
		       ,CAST(CONCAt(substr(a.ChangeRegDate,1,4),substr(a.ChangeRegDate,6,2),substr(a.ChangeRegDate,9,2) ) as INT) as ChangeRegDate
 FROM       FUNDEXT.DBO_MF_SHARESSPLIT a
 LEFT JOIN  FUNDEXT.DBO_MF_FUNDARCHIVES b
 ON         a.INNERCODE = b.INNERCODE
 AND        b.DT = '%d{yyyyMMdd}'
 WHERE      a.DT = '%d{yyyyMMdd}'
 AND        a.InfoType IN (1) and a.SplitType in (4,5,6) 
 AND        CAST(CONCAt(substr(a.SplitDay,1,4),substr(a.SplitDay,6,2),substr(a.SplitDay,9,2) ) as INT) > = 20140101
 AND        CAST(CONCAt(substr(a.ChangeRegDate,1,4),substr(a.ChangeRegDate,6,2),substr(a.ChangeRegDate,9,2) ) as INT) IS NOT NULL
 ;
 ---------
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PUB_QOT_TEMP1;
CREATE TABLE  DDW_PROD.T_DDW_PUB_QOT_TEMP1 as 
SELECT     COALESCE(a.CD,b.CD,c.CD)  as CD
          ,COALESCE(a.NEWST_PRC,b.NEWST_PRC,c.NEWST_PRC)  as NEWST_PRC
		  ,COALESCE(a.BUS_DATE,b.BUS_DATE,c.BUS_DATE)    as BUS_DATE
		  ,2                                             as TRD_MKT
FROM      (SELECT  CD as CD
                  ,BUS_DATE
				  ,NEWST_PRC
                  ,TRD_MKT				  
           FROM   DDW_PROD.T_DDW_PUB_JW_QOT 
		   WHERE  CD NOT LIKE  '%J%'
		   AND    TRD_MKT = 2
		   AND BUS_DATE = %d{yyyyMMdd} 
           )  a
FULL JOIN (SELECT  SUBSTR(CD,1,6) as CD
                  ,BUS_DATE
				  ,NEWST_PRC 
				  ,TRD_MKT
           FROM   DDW_PROD.T_DDW_PUB_JW_QOT 
		   WHERE  SUBSTR(CD,7,1) =  'J'
		   AND    TRD_MKT = 2 
		   AND  SUBSTR(CD,7,2) < >  'JA'   
           AND BUS_DATE = %d{yyyyMMdd} 	
           AND    CD LIKE '%J'		   
          )    b
ON    a.CD = b.CD
AND   a.BUS_DATE = b.BUS_DATE
FULL JOIN (SELECT  SUBSTR(CD,1,6) as CD
                  ,BUS_DATE
				  ,NEWST_PRC 
				  ,TRD_MKT
           FROM   DDW_PROD.T_DDW_PUB_JW_QOT 
		   WHERE  SUBSTR(CD,7,2) =  'JA'
		   AND    TRD_MKT = 2
		   AND    CD LIKE '%JA'
		   AND BUS_DATE = %d{yyyyMMdd} 	
          )    c
ON    NVL(a.CD,b.CD) = c.CD
AND   NVL(a.BUS_DATE,b.BUS_DATE) = c.BUS_DATE
;
 
  INSERT INTO DDW_PROD.T_DDW_PUB_QOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所 
                                  ,NEWST_PRC         --最新价 
                                  ,TRD_UNIT          --交易单位 
                                  ,NEWST_INT         --最新利息
                                  ,NETPRC_TRD_FLG    --净价交易标志
								  ,TRD_MKT           --交易市场
                                  ,DATA_SRC	         --数据来源							  
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT                         t.CPDM    as CD                --代码 
                               ,t.JGDM    as EXG               --交易所 
                               ,CASE WHEN t.CPJZ > 0 
							         THEN t.CPJZ
									 ELSE t.CPJZ_SR 
									 END  as NEWST_PRC         --最新价 
                               ,1         as TRD_UNIT          --交易单位 
                               ,0         as NEWST_INT         --最新利息
                               ,0         as NETPRC_TRD_FLG    --净价交易标志
                               ,4         as TRD_MKT           --交易市场
                               ,1         as DATA_SRC	         --数据来源	
FROM EDW_PROD.T_EDW_T04_TFP_CPJZLS  t
WHERE  t.BUS_DATE = %d{yyyyMMdd} ;							   
---插入数据--
 INSERT INTO DDW_PROD.T_DDW_PUB_QOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所 
                                  ,NEWST_PRC         --最新价 
                                  ,TRD_UNIT          --交易单位 
                                  ,NEWST_INT         --最新利息
                                  ,NETPRC_TRD_FLG    --净价交易标志
								  ,TRD_MKT           --交易市场
                                  ,DATA_SRC	         --数据来源							  
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT   
                    t.ZQDM                   as CD                --代码 
                    ,t.JYS                   as EXG               --交易所
                    ,ROUND(CASE WHEN a1.JJDM IS NOT NULL 
								AND  a2.ZQDM IS NOT NULL
								AND  a2.infotype = 1								
								AND  a2.splittype = 4
								THEN 1
								WHEN a2.ZQDM IS NOT NULL
								AND  a2.infotype = 1
								AND  a2.splittype IN (5,6)
							    THEN 1
								WHEN b.CD IS NOT NULL
								THEN b.NEWST_PRC
								WHEN NVL(t.ZSP,0) = 0 AND NVL(t.ZXJ,0) = 0 AND T.ZQDM = '150677'
								THEN 100
						        ELSE DECODE(NVL(t.ZXJ,0),0,t.ZSP,t.ZXJ) 
						        END,3
						  )                  as NEWST_PRC         --最新价 
                    ,t.JYDW                  as TRD_UNIT          --交易单位 
                    ,t.ZXLX                  as NEWST_INT         --最新利息
                    ,t.JJJYBZ                as NETPRC_TRD_FLG    --净价交易标志
					,1                       as TRD_MKT           --交易市场                
                    ,1                       as DATA_SRC						  
  FROM       EDW_PROD.T_EDW_T04_TZQHQ   t  
  LEFT JOIN  (SELECT    JYS
                       ,ZQDM
					   ,MIN(RQ) as RQ 
			  FROM  JZJYCX.DATACENTER_TZQHQ
              WHERE CJSL > 0
			  AND  JYS IN ('TA','TU')
			  AND RQ >  20170407
			  GROUP BY JYS,ZQDM
              )     c
  ON         t.JYS = c.JYS
  AND        t.ZQDM = c.ZQDM
  LEFT JOIN   (SELECT CD,EXG,TRD_MKT,BUS_DATE,NEWST_PRC 
               FROM DDW_PROD.T_DDW_PUB_JW_QOT 
              GROUP BY CD,EXG,TRD_MKT,BUS_DATE,NEWST_PRC
              )   b
 ON        t.JYS = b.EXG 
 AND       t.JYS IN ('TA','TU')
 AND      t.ZQDM = b.CD
 AND     t.BUS_DATE = b.BUS_DATE
 AND     t.BUS_DATE > = 20170407
 AND     t.BUS_DATE <  NVL(c.RQ,99999999)
LEFT JOIN   EDW_PROD.T_EDW_T04_TFXJJDM_LS     a1
ON          t.JYS = a1.JYS
AND         a1.JJFL = 1
AND         t.ZQDM = a1.JJDM
AND         a1.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN   DDW_PROD.T_DDW_PUB_QOT_TEMP    a2
ON          t.JYS = a2.JYS 
AND         t.ZQDM = a2.ZQDM 
AND         t.BUS_DATE = a2.changeregdate 
WHERE      t.BUS_DATE = %d{yyyyMMdd} 
AND        t.FLAG IN (0,5)
GROUP BY  CD,EXG,NEWST_PRC,TRD_UNIT,NEWST_INT,NETPRC_TRD_FLG,TRD_MKT,DATA_SRC 
  ;
  
-----期权行情----
 INSERT INTO DDW_PROD.T_DDW_PUB_QOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所 
                                  ,NEWST_PRC         --最新价 
                                  ,TRD_UNIT          --交易单位 
                                  ,NEWST_INT         --最新利息
                                  ,NETPRC_TRD_FLG    --净价交易标志
								  ,TRD_MKT           --交易市场
                                  ,DATA_SRC	         --数据来源								  
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                    t.HYDM                   as CD                --代码 
                    ,t.JYS                   as EXG               --交易所
                    ,ROUND(CASE WHEN t.ZXJ = 0 
						  THEN t.ZSP
						  ELSE t.ZXJ
						  END,4)             as NEWST_PRC         --最新价 
                    ,t.HYDW                  as TRD_UNIT          --交易单位 
                    ,0                       as NEWST_INT         --最新利息
                    ,0                       as NETPRC_TRD_FLG    --净价交易标志
					,3                       as TRD_MKT           --交易市场                
                    ,1                       as DATA_SRC                                      
  FROM     EDW_PROD.T_EDW_T04_TSO_QQHQ   t
  WHERE    t.BUS_DATE = %d{yyyyMMdd}
 GROUP BY  CD,EXG,NEWST_PRC,TRD_UNIT,NEWST_INT,NETPRC_TRD_FLG,TRD_MKT,DATA_SRC   ;  
  -----插入场外基金--
   INSERT INTO DDW_PROD.T_DDW_PUB_QOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所 
                                  ,NEWST_PRC         --最新价 
                                  ,TRD_UNIT          --交易单位 
                                  ,NEWST_INT         --最新利息
                                  ,NETPRC_TRD_FLG    --净价交易标志
								  ,TRD_MKT           --交易市场
                                  ,DATA_SRC	         --数据来源								  
) 
 partition(bus_date = %d{yyyyMMdd})
   SELECT 
                     NVL(t.JJDM,a3.CD)                     as CD                --代码 
                    ,NVL(t.TADM,'00')                     as EXG               --交易所
                    ,CASE WHEN a1.JJDM IS NOT NULL 
						  AND  a2.ZQDM IS NOT NULL
						  AND  a2.infotype = 1								
						  AND  a2.splittype = 4
						  THEN 1
						  WHEN a2.ZQDM IS NOT NULL
						  AND  a2.infotype = 1
						  AND  a2.splittype IN (5,6)
						  THEN 1
						  ELSE NVL(ROUND(NVL(a3.newst_prc,t.zxjz),4),1)
						  END                   as NEWST_PRC         --最新价 
                    ,1                          as TRD_UNIT          --交易单位 
                    ,0                          as NEWST_INT         --最新利息
                    ,0                          as NETPRC_TRD_FLG    --净价交易标志
					,2                          as TRD_MKT           --交易市场                
                    ,2                          as DATA_SRC  
                --   ,NVL(t.BUS_DATE,a1.BUS_DATE) as BUS_DATE					
  FROM       EDW_PROD.T_EDW_T04_TOF_JJJZ  t
  FULL JOIN  (SELECT CD,newst_prc,BUS_DATE
              FROM DDW_PROD.T_DDW_PUB_QOT_TEMP1
			  WHERE TRD_MKT = 2
			  AND   BUS_DATE = %d{yyyyMMdd}
			  )    a3
  ON         t.JJDM = a3.CD
  AND        t.BUS_DATE = a3.BUS_DATE
  LEFT JOIN   EDW_PROD.T_EDW_T04_TFXJJDM_LS     a1
  ON          a1.JJFL = 1
  AND         NVL(t.JJDM,a3.CD) = a1.JJDM
  AND         a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN   DDW_PROD.T_DDW_PUB_QOT_TEMP    a2
  ON          NVL(t.JJDM,a3.CD) = a2.ZQDM 
  AND         NVL(t.BUS_DATE,a3.BUS_DATE) = a2.changeregdate 
  WHERE      NVL(t.FLAG,0) IN (0,3)
  AND        NVL(t.BUS_DATE,a3.BUS_DATE)  = %d{yyyyMMdd}
 ;
 --
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PUB_QOT_TEMP;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PUB_QOT_TEMP1;
--
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PUB_QOT_TEMP2;
CREATE TABLE DDW_PROD.T_DDW_PUB_QOT_TEMP2
AS SELECT * FROM DDW_PROD.T_DDW_PUB_QOT WHERE BUS_DATE = %d{yyyyMMdd};

DROP TABLE IF EXISTS DDW_PROD.T_DDW_PUB_QOT_TEMP3;
CREATE TABLE DDW_PROD.T_DDW_PUB_QOT_TEMP3
AS 
SELECT DISTINCT * FROM DDW_PROD.T_DDW_PUB_QOT 
WHERE BUS_DATE IN (SELECT DISTINCT lst_trd_d
                     FROM EDW_PROD.T_EDW_T99_TRD_DATE
					WHERE trd_dt = %d{yyyyMMdd}
				  );

INSERT overwrite DDW_PROD.T_DDW_PUB_QOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所 
                                  ,NEWST_PRC         --最新价 
                                  ,TRD_UNIT          --交易单位 
                                  ,NEWST_INT         --最新利息
                                  ,NETPRC_TRD_FLG    --净价交易标志
								  ,TRD_MKT           --交易市场
                                  ,DATA_SRC	         --数据来源							  
) 
 partition(bus_date)
 SELECT  A.CD        CD        
        ,A.EXG       EXG        
        ,CASE WHEN NVL(A.NEWST_PRC,0) = 0 AND A.exg in('SH','SZ') AND A.trd_mkt = 1
              THEN COALESCE(B.NEWST_PRC,C.NEWST_PRC,0)
			  WHEN NVL(A.NEWST_PRC,0) = 0 AND A.exg in('SH','SZ') AND A.trd_mkt <> 1
			  THEN COALESCE(C.NEWST_PRC,0)
         ELSE A.NEWST_PRC
          END  NEWST_PRC
        ,A.TRD_UNIT
        ,A.NEWST_INT
        ,A.NETPRC_TRD_FLG
        ,A.TRD_MKT AS TRD_MKT
        ,A.DATA_SRC
        ,A.BUS_DATE AS BUS_DATE
FROM DDW_PROD.T_DDW_PUB_QOT_TEMP2 A
LEFT JOIN DDW_PROD.T_DDW_PUB_JW_QOT B
ON A.CD = B.CD
AND A.EXG = B.EXG
AND B.TRD_MKT = 6
AND A.BUS_DATE = B.BUS_DATE
LEFT JOIN DDW_PROD.T_DDW_PUB_QOT_TEMP3 C
ON A.CD = C.CD
AND A.EXG = C.EXG
;

----增加146、149债券行情 BY 20180810 增加138012,138013债券行情 BY 20191017
INSERT INTO DDW_PROD.T_DDW_PUB_QOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所 
                                  ,NEWST_PRC         --最新价 
                                  ,TRD_UNIT          --交易单位 
                                  ,NEWST_INT         --最新利息
                                  ,NETPRC_TRD_FLG    --净价交易标志
								  ,TRD_MKT           --交易市场
                                  ,DATA_SRC	         --数据来源								  
) 
 partition(bus_date = %d{yyyyMMdd})
SELECT
                                   t.ZQDM              
								  ,t.JYS
								  ,NVL(ZXJ,100)
								  ,JYDW
								  ,ZXLX
								  ,JJJYBZ
								  ,1
								  ,1
FROM EDW_PROD.T_EDW_T04_TZQDM t
LEFT JOIN (SELECT ZQDM,JYS FROM  EDW_PROD.T_EDW_T04_TZQHQ   WHERE  BUS_DATE = %d{yyyyMMdd} 
AND        FLAG IN (0,5) AND ZQLB LIKE 'Z%') a1
ON        t.JYS = a1.JYS
AND       t.ZQDM = a1.ZQDM       
WHERE t.BUS_DATE = %d{yyyyMMdd}
AND
( 
    (SUBSTR(t.ZQDM,1,3) IN ('146','149','156') AND t.ZQDM <> '149601') 
 OR (t.ZQDM IN ('139380','135678'))
 OR (t.ZQDM IN ('159967','165053','165007','165046','165047','159997','159998','159955','159993','159992','168154','168155','168266','168249','168450','168451','168600','168625','168796','168797') AND t.JYS = 'SH')
 --OR (ZQDM IN ('138272','138273') AND JYS = 'SZ')
)
AND  a1.ZQDM IS  NULL
;

----增加165904债券行情 BY 20200320
INSERT INTO DDW_PROD.T_DDW_PUB_QOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所 
                                  ,NEWST_PRC         --最新价 
                                  ,TRD_UNIT          --交易单位 
                                  ,NEWST_INT         --最新利息
                                  ,NETPRC_TRD_FLG    --净价交易标志
								  ,TRD_MKT           --交易市场
                                  ,DATA_SRC	         --数据来源								  
) 
 partition(bus_date = %d{yyyyMMdd})
values
(
 '165904'
,'SH'
,100
,10
,0
,1
,1
,1
)
;

----增加165862债券行情 BY 20200421
INSERT INTO DDW_PROD.T_DDW_PUB_QOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所 
                                  ,NEWST_PRC         --最新价 
                                  ,TRD_UNIT          --交易单位 
                                  ,NEWST_INT         --最新利息
                                  ,NETPRC_TRD_FLG    --净价交易标志
								  ,TRD_MKT           --交易市场
                                  ,DATA_SRC	         --数据来源								  
) 
 partition(bus_date = %d{yyyyMMdd})
values
(
 '165862'
,'SH'
,100
,10
,0
,1
,1
,1
)
;

----增加165863债券行情 BY 20200421
INSERT INTO DDW_PROD.T_DDW_PUB_QOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所 
                                  ,NEWST_PRC         --最新价 
                                  ,TRD_UNIT          --交易单位 
                                  ,NEWST_INT         --最新利息
                                  ,NETPRC_TRD_FLG    --净价交易标志
								  ,TRD_MKT           --交易市场
                                  ,DATA_SRC	         --数据来源								  
) 
 partition(bus_date = %d{yyyyMMdd})
values
(
 '165863'
,'SH'
,100
,10
,0
,1
,1
,1
)
;

----增加165989债券行情 BY 20200422
INSERT INTO DDW_PROD.T_DDW_PUB_QOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所 
                                  ,NEWST_PRC         --最新价 
                                  ,TRD_UNIT          --交易单位 
                                  ,NEWST_INT         --最新利息
                                  ,NETPRC_TRD_FLG    --净价交易标志
								  ,TRD_MKT           --交易市场
                                  ,DATA_SRC	         --数据来源								  
) 
 partition(bus_date = %d{yyyyMMdd})
values
(
 '165989'
,'SH'
,100
,10
,0
,1
,1
,1
)
;

----增加165990债券行情 BY 20200422
INSERT INTO DDW_PROD.T_DDW_PUB_QOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所 
                                  ,NEWST_PRC         --最新价 
                                  ,TRD_UNIT          --交易单位 
                                  ,NEWST_INT         --最新利息
                                  ,NETPRC_TRD_FLG    --净价交易标志
								  ,TRD_MKT           --交易市场
                                  ,DATA_SRC	         --数据来源								  
) 
 partition(bus_date = %d{yyyyMMdd})
values
(
 '165990'
,'SH'
,100
,10
,0
,1
,1
,1
)
;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_PUB_QOT_TEMP2;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PUB_QOT_TEMP3;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PUB_QOT_TEMP;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PUB_QOT_TEMP0;

----------------------插入数据结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_QOT',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_QOT;
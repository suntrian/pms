 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360股东账户信息表                                                                      */
  --/* 创建人:程骏                                                                               */
  --/* 创建时间:2017-10-19                                                                        */ 
  /* T_DDW_F02_SHRHLD_INFO	替换为	T_DDW_F00_CUST_SHRHLD_INFO */
  
---------------- 插入集中交易数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_SHRHLD_INFO
 (
	 CUST_NO						--客户号
	,SHRHLD_NO						--股东号
	,BRH_NAME						--营业部
	,CTF_NO							--股东证件编号
	,SHRHLD_REGST_DT	 			--股东登记日期
	,CUST_NAME						--股东姓名
	,EXG							--交易所	
	,SHRHLD_STAT					--股东状态
	,SHRHLD_ASGN_ATTR				--股东指定属性
	,SHRHLD_CTRL_ATTR				--股东控制属性
	,TRD_SCP						--交易范围
	,FSTTM_TRD_DT		 			--首次交易日期           
 ) PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT    t.CUST_NO                                                                 as CUST_NO						--客户号
	      ,t.SHRHLD_NO                                                               as SHRHLD_NO					--股东号
	      ,t.BRH_NAME                                                                as BRH_NAME					--营业部
	      ,t.CTF_NO                                                                  as CTF_NO						--股东证件编号
	      ,t.shrhld_opnac_dt                                                         as SHRHLD_REGST_DT	 			--股东登记日期
	      ,t.CUST_NAME                                                               as CUST_NAME					--股东姓名
	      ,a1.EXG_NAME                                                               as EXG							--交易所	
	      ,a2.SHRHLD_STAT_NAME                                                       as SHRHLD_STAT					--股东状态
	      ,DECODE(t.SHRHLD_ASGN_ATTR,0,'未设置',a3.SHRHLD_ASGN_ATTR_NAME)           as SHRHLD_ASGN_ATTR			--股东指定属性
	      ,DECODE(t.SHRHLD_CTRL_ATTR,0,'未设置',a4.SHRHLD_CTRL_ATTR_NAME)    as SHRHLD_CTRL_ATTR			--股东控制属性
	      ,t.TRD_SCP                                                                 as TRD_SCP						--交易范围
	      ,t.fsttm_trd_dt                                                            as FSTTM_TRD_DT		 		--首次交易日期           
 FROM          DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO             t
 LEFT JOIN     DDW_PROD.V_EXG                            a1
 ON            t.EXG = a1.EXG
 LEFT JOIN     DDW_PROD.V_SHRHLD_STAT                    a2
 ON            t.SHRHLD_STAT = a2.SHRHLD_STAT
 LEFT JOIN     DDW_PROD.V_SHRHLD_ASGN_ATTR               a3
 ON            CAST(t.SHRHLD_ASGN_ATTR as STRING) = a3.SHRHLD_ASGN_ATTR
 LEFT JOIN     DDW_PROD.V_SHRHLD_CTRL_ATTR               a4
 ON            CAST(t.SHRHLD_CTRL_ATTR as STRING) = a4.SHRHLD_CTRL_ATTR
 WHERE         t.BUS_DATE = %d{yyyyMMdd}
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_SHRHLD_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_SHRHLD_INFO;
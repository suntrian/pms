 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:产品账户信息                                                                 */
  --/* 创建人:段智泓                                                                             */
  --/* 创建时间:2018-09-06                                                                 */ 

-------插入数据开始--------------
TRUNCATE TABLE EDW_PROD.T_EDW_T02_TFP_KHTZZH;

INSERT OVERWRITE EDW_PROD.T_EDW_T02_TFP_KHTZZH
(
                       ID                         --ID
                      ,KHH                        --客户ID
                      ,YYB                        --营业部
                      ,FXJG                       --登记机构
                      ,TZZH                       --产品账号
                      ,ZHMC                       --账户名称
                      ,ZHMM                       --账户密码
                      ,JYZH                       --交易帐号
                      ,JSZH                       --结算帐户
                      ,JSLX                       --结算类型
                      ,JSJG                       --结算机构
                      ,FHFS                       --分红方式
                      ,ZHZT                       --账户状态
                      ,ZHSX                       --账户属性
                      ,JYQX                       --交易权限
                      ,ZDSX                       --指定属性
                      ,HYBH                       --会员编号
                      ,PBU                        --交易单元
                      ,JSBZ                       --结算币种
                      ,ZHFXDJ                     --账户风险等级
                      ,FXJB_FXF                   --发行方评测的风险等级
                      ,PCRQ                       --评测日期
                      ,KHRQ                       --开户日期
                      ,XHRQ                       --销户日期
                      ,SJ                         --手机
                      ,DH                         --联系电话
                      ,CZ                         --传真
                      ,DZ                         --通讯地址
                      ,YZBM                       --邮政编码
                      ,KHH_DC                     --客户号DC
                      ,YDSQYBZ                    --约定书签约标志
                      ,KHSX                       --限制属性
                      ,TAZH                       --TA账号
                      ,TAJYZH                     --TA交易账号
                      ,XTBS
)
PARTITION( bus_date = %d{yyyyMMdd})
SELECT                           
                       t.ID    AS ID                      --ID
                      ,t.KHH   AS KHH                     --客户ID
                      ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))         as YYB  --营业部 
                      ,CAST(COALESCE(t5.JGMC,NULLIF(CONCAT('ERR',CAST(t.FXJG  AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))         as FXJG --登记机构
					  ,t.TZZH  AS TZZH                     --产品账号
                      ,t.ZHMC  AS ZHMC                     --账户名称
                      ,t.ZHMM  AS ZHMM                     --账户密码
                      ,t.JYZH  AS JYZH                     --交易帐号
                      ,t.JSZH  AS JSZH                     --结算帐户
                      ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))          AS JSLX --结算类型
                      ,t.JSJG  AS JSJG                     --结算机构
                      ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.FHFS AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))         as FHFS --分红方式 
                      ,t.ZHZT  AS ZHZT                     --账户状态
                      ,t.ZHSX  AS ZHSX                     --账户属性
                      ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYQX AS VARCHAR(20))),'ERR')) AS DECIMAL(22,0))         as JYQX --交易权限
                      ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZDSX AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))         as ZDSX --指定属性
                      ,t.HYBH  AS HYBH                     --会员编号
                      ,t.PBU   AS PBU                      --交易单元
                      ,t.JSBZ  AS JSBZ                     --结算币种
                      ,CAST(COALESCE(t7.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHFXDJ AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0))       as ZHFXDJ --账户风险等级
                      ,t.FXJB_FXF AS FXJB_FXF                  --发行方评测的风险等级
                      ,t.PCRQ     AS PCRQ                    --评测日期
                      ,t.KHRQ     AS KHRQ                    --开户日期
                      ,t.XHRQ     AS XHRQ                    --销户日期
                      ,t.SJ       AS SJ                      --手机
                      ,t.DH       AS DH                      --联系电话
                      ,t.CZ       AS CZ                      --传真
                      ,t.DZ       AS DZ                      --通讯地址
                      ,t.YZBM     AS YZBM                    --邮政编码
                      ,t.KHH_DC   AS KHH_DC                  --客户号DC
                      ,t.YDSQYBZ  AS YDSQYBZ                  --约定书签约标志
                      ,CAST(COALESCE(t8.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20))       as KHSX --限制属性
                      ,t.TAZH     AS TAZH                   --TA账号
                      ,t.TAJYZH   AS TAJYZH                 --TA交易账号
					  ,'OTC'      AS XTBS
FROM           OTCCX.FPSS_TFP_KHTZZH t
LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t1
ON             t1.YXT = 'OTC'
AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2
ON             t2.DMLX = 'OTC_JSLX'
AND            t2.YXT = 'OTC'
AND            t2.YDM = CAST(t.JSLX AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3
ON             t3.DMLX = 'OF_FHFS'
AND            t3.YXT = 'OTC'
AND            t3.YDM = CAST(t.FHFS AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4
ON             t4.DMLX = 'OTC_JYQX'
AND            t4.YXT = 'OTC'
AND            t4.YDM = CAST(t.JYQX AS VARCHAR(20))
LEFT JOIN      OTCCX.PRODUCT_TFP_JGDM                 t5
ON             t5.IBM = t.FXJG
AND            t5.DT = '%d{yyyyMMdd}'
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t6
ON             t6.DMLX = 'GDZDSX'
AND            t6.YXT = 'OTC'
AND            t6.YDM = CAST(t.ZDSX AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t7
ON             t7.DMLX = 'GDZDSX'
AND            t7.YXT = 'OTC'
AND            t7.YDM = CAST(t.ZHFXDJ AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t8
ON             t8.DMLX = 'KHSX'
AND            t8.YXT = 'OTC'
AND            t8.YDM = CAST(t.KHSX AS VARCHAR(20))
WHERE 	       t.DT = '%d{yyyyMMdd}'
;
----------插入数据结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TFP_KHTZZH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TFP_KHTZZH;
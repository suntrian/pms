 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:分级基金权限开通                                                              */
  /* 创建人:程骏                                                                               */
  /* 创建时间:2017-09-15                                                                        */ 


--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_AG_FND_OPNAC_INFO
(        
								 BRH_NO                     --营业部编号      
								,BRH_NAME                   --营业部名称      
								,PRVL_OPEN_DT               --权限开通日期              
								,CUST_NO                    --客户号          
								,CUST_NAME                  --客户姓名        
								,RSK_RVLBOOK                --风险揭示书           
								,RSK_BEAR_ABLTY             --风险承受能力
								,M_LAUND_RSK_LVL            --洗钱风险等级
								,OCC_BRH_NO                 --发生营业部 
                                ,OPEN_FND_AST	            --开通分级基金时资产								
								,SECOND_CARD_VRFCTN         --二代证验证     
								,PRVL_OPEN_AGE              --开通时年龄        
) 
 PARTITION(bus_date)
 SELECT 
					 t.BRH_NO                      --营业部编号
					 ,t.BRH_NAME                   --营业部名称
					 ,t.DT                         --权限开通日期
					 ,t.CUST_NO                    --客户号          
					 ,t.CUST_NAME                  --客户姓名        
					 ,case when a3.yxlx = 20098 then '开通' else '未开通' end            --风险揭示书           
					 ,b1.RSK_BEAR_ABLTY_NAME             --风险承受能力
					 ,b2.M_LAUND_RSK_LVL_NAME            --洗钱风险等级
					 ,cast(t.OCC_BRH_NO AS STRING)			       --发生营业部
					 ,nvl(a2.NET_TOT_AST,0)	            --开通分级基金时资产	
                    -- ,cast(t.OCC_BRH_NO AS STRING)			       --发生营业部 		 
					 ,t.SECOND_CARD_VRFCTN         --二代证验证     
					 ,t.PRVL_OPEN_AGE              --开通时年龄
                     ,CAST(t.BUS_DATE	as INT)          as BUS_DATE				 
  FROM           DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS        t
  LEFT JOIN      DDW_PROD.T_DDW_F00_CUST_CUST_INFO              a1
  ON             t.CUST_NO = a1.CUST_NO
  AND            a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY            a2
  ON                t.CUST_NO = a2.CUST_NO
  AND               t.DT = a2.BUS_DATE
  LEFT JOIN		 YGTCX.EIMAGE_TDA_KHJBDA                       a3
  ON 			 T.CUST_NO = a3.YWXTKHH
  and			 cast(a3.DT as int) = %d{yyyyMMdd}
  and			 a3.yxlx = 20098
  LEFT JOIN 		DDW_PROD.V_RSK_BEAR_ABLTY				b1
  ON				a1.RSK_BEAR_ABLTY = b1.RSK_BEAR_ABLTY 
  LEFT JOIN  DDW_PROD.V_M_LAUND_RSK_LVL            b2
  ON         a1.M_LAUND_RSK_LVL = b2.M_LAUND_RSK_LVL
  WHERE 		 t.BIZ_SBJ =  '21285' 
  AND            t.BUS_DATE = %d{yyyyMMdd}
  ;
  ------结束----
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_AG_FND_OPNAC_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_AG_FND_OPNAC_INFO ;  
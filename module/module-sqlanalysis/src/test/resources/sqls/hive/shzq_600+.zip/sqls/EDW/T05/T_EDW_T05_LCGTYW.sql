------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:柜台业务流程表                                                                */
------/* 创建人:梅杰                                                                               */
------/* 创建时间:2018-05-16 
------/* 增量表                                                                       */ 
--------------插入数据-------------------
ALTER TABLE EDW_PROD.T_EDW_T05_LCGTYW DROP IF EXISTS PARTITION  (BUS_DATE = %d{yyyyMMdd});

INSERT OVERWRITE EDW_PROD.T_EDW_T05_LCGTYW
(
									 ID    					--ID
									,INSTID				
									,TITLE 					--标题
									,YWDM  					--业务代码
									,KHH   					--客户号
									,FQQD  					--发起渠道
									,YWQQID					--业务请求ID
									,JZR   					--见证人
									,JZFS  					--见证方式
									,JZFJH 					--见证房间号
									,BLR   					--办理人
									,FSRQ  					--发生日期
									,FSSJ  					--发生时间
									,FQR   					--发起人
									,CZZD  					--操作站点
									,BLRQ  					--办理日期
									,BLSJ  					--办理时间
									,KHMC  					--客户名称
									,JG						--机构
									,ZJLBDM					--证件类别代码
									,ZJBH  					--证件编号
									,KHFXJB					--客户风险级别
									,KHZT  					--客户状态
									,LGSHGY					--临柜审核柜员
									,XTBS					--系统标识


)
partition(bus_date)
SELECT 
							ID    		as		ID    			--ID					
							,INSTID		as		INSTID          
							,TITLE 		as		TITLE           --标题
							,YWDM  		as		YWDM            --业务代码
							,KHH   		as		KHH             --客户号
							,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.FQQD AS VARCHAR(20))),'ERR')) AS VARCHAR(20))   		as		FQQD            --发起渠道			使用公共代码映射表转换
							,YWQQID		as		YWQQID          --业务请求ID
							,JZR   		as		JZR             --见证人
							,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JZFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20))   		as		JZFS            --见证方式			使用公共代码映射表转换
							,JZFJH 		as		JZFJH           --见证房间号
							,BLR   		as		BLR             --办理人
							,FSRQ  		as		FSRQ            --发生日期
							,FSSJ  		as		FSSJ            --发生时间
							,FQR   		as		FQR             --发起人
							,CZZD  		as		CZZD            --操作站点
							,BLRQ  		as		BLRQ            --办理日期
							,BLSJ  		as		BLSJ            --办理时间
							,KHMC  		as		KHMC            --客户名称
							,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))		as		JG              --营业部				使用公共代码映射表转换
							,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))		as		ZJLBDM          --证件类别代码		使用公共代码映射表转换
							,ZJBH  		as		ZJBH            --证件编号
							,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.FXJB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))		as		KHFXJB          --客户风险级别		使用公共代码映射表转换
							,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  		as		KHZT            --客户状态			使用公共代码映射表转换
							,LGSHGY		as		LGSHGY          --临柜审核柜员
							,'CIF'		as		XTBS            --系统标识
							,CAST(CASE WHEN t7.NAT_DT = t7.TRD_DT
							      THEN t7.TRD_DT
								  WHEN t7.NAT_DT <> t7.TRD_DT
							      THEN t8.TRD_DT
								  ELSE FSRQ
                                  END AS INT) BUS_DATE
FROM 		YGTCX.CIF_LCGTYW			t
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		t1
ON 		t1.YXT='YGT'
AND		t1.YDM= CAST(t.FQQD AS VARCHAR(20))
AND 	t1.DMLX='FQQD'	
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		t2
ON 		t2.YXT='YGT_GT'
AND		t2.YDM= CAST(t.JZFS AS VARCHAR(20))
AND 	t2.DMLX='JZFS'
LEFT JOIN		EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING 		t3
ON 		t3.YXT='CIF'
AND		t3.JGDM= CAST(t.YYB AS VARCHAR(20))
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		t4
ON 		t4.YXT='YGT_GT'
AND		t4.YDM= CAST(t.ZJLB AS VARCHAR(20))
AND 	t4.DMLX='ZJLBDM'
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		t5
ON 		t5.YXT='YGT_GT'
AND		t5.YDM= CAST(t.FXJB AS VARCHAR(20))
AND 	t5.DMLX='KHFXJBDM'
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		t6
ON 		t6.YXT='YGT_GT'
AND		t6.YDM= CAST(t.KHZT AS VARCHAR(20))
AND 	t6.DMLX='KHZTDM'
LEFT JOIN       EDW_PROD.T_EDW_T99_TRD_DATE		            t7
ON              t.FSRQ = t7.NAT_DT
AND             t7.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN       EDW_PROD.T_EDW_T99_TRD_DATE		            t8
ON              t8.lst_trd_d = t7.trd_dt
and             t8.NAT_DT = t8.TRD_DT
AND             t8.BUS_DATE = %d{yyyyMMdd}
WHERE   t.DT = '%d{yyyyMMdd}'
UNION ALL
SELECT 
							ID    		as		ID    			--ID					
							,INSTID		as		INSTID          
							,TITLE 		as		TITLE           --标题
							,YWDM  		as		YWDM            --业务代码
							,KHH   		as		KHH             --客户号
							,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.FQQD AS VARCHAR(20))),'ERR')) AS VARCHAR(20))   		as		FQQD            --发起渠道			使用公共代码映射表转换
							,YWQQID		as		YWQQID          --业务请求ID
							,JZR   		as		JZR             --见证人
							,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JZFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20))   		as		JZFS            --见证方式			使用公共代码映射表转换
							,JZFJH 		as		JZFJH           --见证房间号
							,BLR   		as		BLR             --办理人
							,FSRQ  		as		FSRQ            --发生日期
							,FSSJ  		as		FSSJ            --发生时间
							,FQR   		as		FQR             --发起人
							,CZZD  		as		CZZD            --操作站点
							,BLRQ  		as		BLRQ            --办理日期
							,BLSJ  		as		BLSJ            --办理时间
							,KHMC  		as		KHMC            --客户名称
							,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))		as		JG              --营业部				使用公共代码映射表转换
							,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))		as		ZJLBDM          --证件类别代码		使用公共代码映射表转换
							,ZJBH  		as		ZJBH            --证件编号
							,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.FXJB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))		as		KHFXJB          --客户风险级别		使用公共代码映射表转换
							,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  		as		KHZT            --客户状态			使用公共代码映射表转换
							,LGSHGY		as		LGSHGY          --临柜审核柜员
							,'CIF'		as		XTBS            --系统标识
							,CAST(CASE WHEN t7.NAT_DT = t7.TRD_DT
							      THEN t7.TRD_DT
								  WHEN t7.NAT_DT <> t7.TRD_DT
							      THEN t8.TRD_DT
								  ELSE FSRQ
                                  END AS INT) BUS_DATE
FROM 		YGTCX.CIF_LCGTYW			t
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		t1
ON 		t1.YXT='YGT'
AND		t1.YDM= CAST(t.FQQD AS VARCHAR(20))
AND 	t1.DMLX='FQQD'	
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		t2
ON 		t2.YXT='YGT_GT'
AND		t2.YDM= CAST(t.JZFS AS VARCHAR(20))
AND 	t2.DMLX='JZFS'
LEFT JOIN		EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING 		t3
ON 		t3.YXT='CIF'
AND		t3.JGDM= CAST(t.YYB AS VARCHAR(20))
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		t4
ON 		t4.YXT='YGT_GT'
AND		t4.YDM= CAST(t.ZJLB AS VARCHAR(20))
AND 	t4.DMLX='ZJLBDM'
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		t5
ON 		t5.YXT='YGT_GT'
AND		t5.YDM= CAST(t.FXJB AS VARCHAR(20))
AND 	t5.DMLX='KHFXJBDM'
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		t6
ON 		t6.YXT='YGT_GT'
AND		t6.YDM= CAST(t.KHZT AS VARCHAR(20))
AND 	t6.DMLX='KHZTDM'
LEFT JOIN       EDW_PROD.T_EDW_T99_TRD_DATE		            t7
ON              t.FSRQ = t7.NAT_DT
AND             t7.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN       EDW_PROD.T_EDW_T99_TRD_DATE		            t8
ON              t8.lst_trd_d = t7.trd_dt
and             t8.NAT_DT = t8.TRD_DT
AND             t8.BUS_DATE = %d{yyyyMMdd}
WHERE           EXISTS (SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE a
                         WHERE a.BUS_DATE = %d{yyyyMMdd}
						 AND   a.TRD_DT = %d{yyyyMMdd}
						 AND   CAST(t.DT as INT) = a.LST_TRD_D
                         )
;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_LCGTYW',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_LCGTYW;
 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:科创板客户交易周表                                                                      */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2019-07-22                                                                     */ 
  
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP as
 SELECT     MIN(TRD_DT)    as TRD_DT_WEEK_MIN 
            ,MAX(TRD_DT)   as TRD_DT_WEEK_MAX 
		    ,TYEAR_WHICH_WEEK
			,1 as ID 
  FROM  EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE NAT_DT BETWEEN 20190101 AND 20191231
  AND   BUS_DATE = %d{yyyyMMdd}
  AND   TRD_DT = NAT_DT
  GROUP BY TYEAR_WHICH_WEEK
  HAVING %d{yyyyMMdd} between MIN(TRD_DT)  and MAX(TRD_DT) ;
  
  
  
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP1 as
 SELECT  a.BRH_NO
         ,COUNT(1)  as GT_OPN_CUST_VOL
		 ,SUM(CASE WHEN a.OPN_DT BETWEEN b.TRD_DT_WEEK_MIN AND b.TRD_DT_WEEK_MAX
		           THEN 1
			       ELSE 0
			       END
			 )  as OPN_CUST_VOL
		 	 
			 
			 
 FROM  (SELECT CUST_NO,BRH_NO,MIN(OPN_DT) as OPN_DT,1 as ID 
        FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
		WHERE BUS_DATE = %d{yyyyMMdd} 
		AND   OPN_PRVL = 20
		GROUP BY CUST_NO,BRH_NO,ID
		 ) a
 LEFT JOIN DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP  b
 ON a.ID = b.ID 
 WHERE a.CUST_NO IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL WHERE BUS_DATE = %d{yyyyMMdd} 
		             AND   OPN_PRVL = 20
		             AND   CHG_DT = 99999999
		               )
GROUP BY a.BRH_NO ;	

 
			
			
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP2 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP2 as
 SELECT  a.BRH_NO
         ,SUM(CASE WHEN b.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 ) as GT_LOT_STIB_CUST_VOL
		 ,SUM(CASE WHEN b.CUST_NO IS  NULL
		           AND  c.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 ) as GT_UN_LOT_STIB_TRD_CUST_VOL
		,SUM(CASE WHEN c.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 ) as GT_TRD_CUST_VOL
		,SUM(CASE WHEN d.CUST_NO IS NOT NULL
		          AND  d.TOT_PRET > 0
				  THEN 1
				  ELSE 0
				  END) as GT_PAYOF_CUST_VOL
		,SUM(CASE WHEN d.CUST_NO IS NOT NULL
		          AND  d.TOT_PRET < 0
				  THEN 1
				  ELSE 0
				  END) as GT_LOSS_CUST_VOL
          
		,SUM(CASE WHEN c.CUST_NO IS NOT NULL
		           THEN c.GT_MTCH_VOL 
			       ELSE 0
			       END
			 ) as GT_MTCH_VOL	
        	,SUM(CASE WHEN c.CUST_NO IS NOT NULL
		           THEN c.GT_NET_S1 
			       ELSE 0
			       END
			 ) as GT_NET_S1			 
		,SUM(CASE WHEN e.CUST_NO IS NOT NULL
		           AND e.NUM1 > 0
		           THEN 1 
			       ELSE 0
			       END
			 ) as GT_INVAL_CUST_VOL	
       ,SUM(CASE WHEN e.CUST_NO IS NOT NULL
		           THEN e.NUM 
			       ELSE 0
			       END
			 ) as GT_ODR_VOL
       ,SUM(CASE WHEN e.CUST_NO IS NOT NULL
		           THEN e.NUM1 
			       ELSE 0
			       END
			 ) as GT_INVAL_VOL				 

		
							
			
 FROM   DDW_PROD.T_DDW_F00_CUST_CUST_INFO   a
 LEFT JOIN   (SELECT CUST_NO
              FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
		      WHERE ODR_CGY = 82
              AND   EXG = 'SH'
              AND   SUBSTR(SEC_CD,1,3) = '688'
             GROUP BY CUST_NO		
		     ) b
 ON   a.CUST_NO = b.CUST_NO
  LEFT JOIN   (SELECT CUST_NO,SUM(MTCH_AMT) as GT_MTCH_VOL ,SUM(S1-S11-S12) as GT_NET_S1
              FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
		      WHERE ODR_CGY IN (1,2,57,58,59,60,61,62,63,64,71,78,79)
              AND   EXG = 'SH'
              AND   SUBSTR(SEC_CD,1,3) = '688'
             GROUP BY CUST_NO		
		     ) c
 ON   a.CUST_NO = c.CUST_NO
 LEFT JOIN (SELECT CUST_NO,SUM(TOT_PRET_RMB) as TOT_PRET  FROM DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY
            WHERE EXG = 'SH'
			AND   SUBSTR(SEC_CD,1,3) = '688'
			GROUP BY CUST_NO
           ) d
 ON   a.CUST_NO = d.CUST_NO
 LEFT JOIN   (SELECT CUST_NO,COUNT(1) as NUM
                   ,SUM(CASE WHEN RPT_RSLT = 3
                             AND RSLT_EXPLN LIKE '%价格超出范围%'
							 THEN 1
							 ELSE 0
							 END
						)    as NUM1
              FROM DDW_PROD.T_DDW_F00_TRD_SEC_ODR_DEL_HIS
		      WHERE ODR_CGY IN (1,2,57,58,59,60,61,62,63,64,71,78,79)
              AND   EXG = 'SH'
              AND   SUBSTR(SEC_CD1,1,3) = '688'
			  AND   RPT_RSLT < >  8
             GROUP BY CUST_NO		
		     ) e
 ON   a.CUST_NO = e.CUST_NO
 WHERE a.BUS_DATE = %d{yyyyMMdd}
 GROUP BY a.BRH_NO ;
 
 
 		
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP3 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP3 as
 SELECT  a.BRH_NO
         ,SUM(CASE WHEN b.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 ) as LOT_STIB_CUST_VOL
		 ,SUM(CASE WHEN b.CUST_NO IS  NULL
		           AND  c.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 ) as UN_LOT_STIB_TRD_CUST_VOL
		,SUM(CASE WHEN c.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 ) as TRD_CUST_VOL
		,SUM(CASE WHEN d.CUST_NO IS NOT NULL
		          AND  d.TOT_PRET > 0
				  THEN 1
				  ELSE 0
				  END) as PAYOF_CUST_VOL
		,SUM(CASE WHEN d.CUST_NO IS NOT NULL
		          AND  d.TOT_PRET < 0
				  THEN 1
				  ELSE 0
				  END) as LOSS_CUST_VOL
          
		,SUM(CASE WHEN c.CUST_NO IS NOT NULL
		           THEN c.MTCH_VOL 
			       ELSE 0
			       END
			 ) as MTCH_VOL	
        	,SUM(CASE WHEN c.CUST_NO IS NOT NULL
		           THEN c.NET_S1 
			       ELSE 0
			       END
			 ) as NET_S1			 
		,SUM(CASE WHEN e.CUST_NO IS NOT NULL
		           AND e.NUM1 > 0
		           THEN 1 
			       ELSE 0
			       END
			 ) as INVAL_CUST_VOL	
       ,SUM(CASE WHEN e.CUST_NO IS NOT NULL
		           THEN e.NUM 
			       ELSE 0
			       END
			 ) as ODR_VOL
       ,SUM(CASE WHEN e.CUST_NO IS NOT NULL
		           THEN e.NUM1 
			       ELSE 0
			       END
			 ) as INVAL_VOL				 

		
							
			
 FROM   DDW_PROD.T_DDW_F00_CUST_CUST_INFO   a
 LEFT JOIN   (SELECT a.CUST_NO
              FROM (SELECT 1 AS ID,* 
			        FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
					WHERE ODR_CGY = 82
					AND   EXG = 'SH'
					AND  SUBSTR(SEC_CD,1,3) = '688'
					AND  BUS_DATE > = 20190101
					) a
			  LEFT JOIN  DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP b
			  ON a.ID = b.ID
              WHERE a.BUS_DATE BETWEEN b.TRD_DT_WEEK_MIN AND b.TRD_DT_WEEK_MAX		  
             GROUP BY a.CUST_NO		
		     ) b
 ON   a.CUST_NO = b.CUST_NO
  LEFT JOIN   (SELECT a.CUST_NO
                     ,SUM(a.MTCH_AMT) as MTCH_VOL 
					 ,SUM(a.S1-a.S11-a.S12) as NET_S1
              FROM (SELECT 1 AS ID,* 
			        FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS  
					WHERE ODR_CGY IN (1,2,57,58,59,60,61,62,63,64,71,78,79)
					AND   EXG = 'SH'
					AND  SUBSTR(SEC_CD,1,3) = '688'
					AND  BUS_DATE > = 20190101
					)   a
		      LEFT JOIN  DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP b
			  ON a.ID = b.ID
              WHERE a.BUS_DATE BETWEEN b.TRD_DT_WEEK_MIN AND b.TRD_DT_WEEK_MAX	
             GROUP BY a.CUST_NO		
		     ) c
 ON   a.CUST_NO = c.CUST_NO
 LEFT JOIN (SELECT a.CUST_NO
                  ,SUM(a.TOT_PRET_RMB) as TOT_PRET  
		    FROM (SELECT 1 AS ID,* 
			        FROM DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY 
					WHERE EXG = 'SH'
					AND  SUBSTR(SEC_CD,1,3) = '688'
					AND  BUS_DATE > = 20190101
					) a
			 LEFT JOIN  DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP b
			  ON a.ID = b.ID
              WHERE a.BUS_DATE BETWEEN b.TRD_DT_WEEK_MIN AND b.TRD_DT_WEEK_MAX	
			GROUP BY a.CUST_NO
           ) d
 ON   a.CUST_NO = d.CUST_NO
 LEFT JOIN   (SELECT CUST_NO,COUNT(1) as NUM
                   ,SUM(CASE WHEN RPT_RSLT = 3
                             AND RSLT_EXPLN LIKE '%价格超出范围%'
							 THEN 1
							 ELSE 0
							 END
						)    as NUM1
              FROM (SELECT 1 AS ID,* 
			        FROM DDW_PROD.T_DDW_F00_TRD_SEC_ODR_DEL_HIS
					WHERE EXG = 'SH'
					AND  SUBSTR(SEC_CD1,1,3) = '688'
					AND  BUS_DATE > = 20190101
					AND ODR_CGY IN (1,2,57,58,59,60,61,62,63,64,71,78,79)
					AND   RPT_RSLT < >  8
					) a 
		     LEFT JOIN  DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP b
			  ON a.ID = b.ID
              WHERE a.BUS_DATE BETWEEN b.TRD_DT_WEEK_MIN AND b.TRD_DT_WEEK_MAX	
             GROUP BY a.CUST_NO		
		     ) e
 ON   a.CUST_NO = e.CUST_NO
 WHERE a.BUS_DATE = %d{yyyyMMdd}
 GROUP BY a.BRH_NO ;

  
  
  
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK
(                                BELTO_FILIL                --所属分公司 
					            ,BELTO_FILIL_CDG	        --所属分公司编码
								,BRH_NO 					--营业部编号
								,BRH_NAME                   --营业部名称
								,OPN_CUST_VOL               --开通客户数
								,LOT_STIB_CUST_VOL          --中签客户数
								,UN_LOT_STIB_TRD_CUST_VOL   --未中签客户交易客户数
								,TRD_CUST_VOL               --交易客户数
								,PAYOF_CUST_VOL             --盈利客户数
								,LOSS_CUST_VOL              --亏损客户数
								,INVAL_CUST_VOL             --废单客户数（发生过废单的客户数）
								,ODR_VOL                    --委托数
								,INVAL_VOL                  --废单数
								,MTCH_VOL                   --成交量
								,NET_S1                     --净佣金								
                                ,GT_OPN_CUST_VOL               --累计开通客户数
								,GT_LOT_STIB_CUST_VOL          --累计中签客户数
								,GT_UN_LOT_STIB_TRD_CUST_VOL   --累计未中签客户交易客户数
								,GT_TRD_CUST_VOL               --累计交易客户数
								,GT_PAYOF_CUST_VOL             --累计盈利客户数
								,GT_LOSS_CUST_VOL              --累计亏损客户数
								,GT_INVAL_CUST_VOL             --累计废单客户数（发生过废单的客户数）
								,GT_ODR_VOL                    --累计委托数
								,GT_INVAL_VOL                  --累计废单数
								,GT_MTCH_VOL                   --累计成交量
								,GT_NET_S1                     --累计净佣金
								,trd_dt_week_min     
		                        ,trd_dt_week_max
 )
 PARTITION(WEEK)
 SELECT                          t.BELTO_FILIL                --所属分公司 
					            ,t.BELTO_FILIL_CDG	        --所属分公司编码
								,t.BRH_NO 					--营业部编号
								,t.BRH_FULLNM     as BRH_NAME                   --营业部名称
								,NVL(a1.OPN_CUST_VOL,0)               --开通客户数
								,NVL(a3.LOT_STIB_CUST_VOL,0)          --中签客户数
								,NVL(a3.UN_LOT_STIB_TRD_CUST_VOL,0)   --未中签客户交易客户数
								,NVL(a3.TRD_CUST_VOL,0)               --交易客户数
								,NVL(a3.PAYOF_CUST_VOL,0)             --盈利客户数
								,NVL(a3.LOSS_CUST_VOL,0)              --亏损客户数
								,NVL(a3.INVAL_CUST_VOL,0)             --废单客户数（发生过废单的客户数）
								,NVL(a3.ODR_VOL,0)                    --委托数
								,NVL(a3.INVAL_VOL,0)                  --废单数
								,NVL(a3.MTCH_VOL,0)                   --成交量
								,NVL(a3.NET_S1,0)                     --净佣金								
                                ,NVL(a1.GT_OPN_CUST_VOL,0)               --累计开通客户数
								,NVL(a2.GT_LOT_STIB_CUST_VOL,0)          --累计中签客户数
								,NVL(a2.GT_UN_LOT_STIB_TRD_CUST_VOL,0)   --累计未中签客户交易客户数
								,NVL(a2.GT_TRD_CUST_VOL,0)               --累计交易客户数
								,NVL(a2.GT_PAYOF_CUST_VOL,0)             --累计盈利客户数
								,NVL(a2.GT_LOSS_CUST_VOL,0)              --累计亏损客户数
								,NVL(a2.GT_INVAL_CUST_VOL,0)             --累计废单客户数（发生过废单的客户数）
								,NVL(a2.GT_ODR_VOL,0)                    --累计委托数
								,NVL(a2.GT_INVAL_VOL,0)                  --累计废单数
								,NVL(a2.GT_MTCH_VOL,0)                   --累计成交量
								,NVL(a2.GT_NET_S1,0)                     --累计净佣金
								,a4.trd_dt_week_min     
		                        ,a4.trd_dt_week_max
								,CONCAT('2019','.',CAST(tyear_which_week as STRING)) as WEEK
   FROM (SELECT *,1 as ID 
         FROM  DDW_PROD.T_DDW_INR_ORG_BRH  
         WHERE BUS_DATE = %d{yyyyMMdd}
	    )  t
   LEFT JOIN DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP1 a1
   ON        t.BRH_NO = a1.BRH_NO
   LEFT JOIN DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP2 a2
   ON        t.BRH_NO = a2.BRH_NO
   LEFT JOIN DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP3 a3
   ON        t.BRH_NO = a3.BRH_NO
   LEFT JOIN DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP a4
   ON        t.ID = a4.ID
  ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP1 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP2 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP3 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_STIB_CUST_TRD_WEEK_TEMP4 ;
-----------------------------加载结束--------------------
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_STIB_CUST_TRD_WEEK',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
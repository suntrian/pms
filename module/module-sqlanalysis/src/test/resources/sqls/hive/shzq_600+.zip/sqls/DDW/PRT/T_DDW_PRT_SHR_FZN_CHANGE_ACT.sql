 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:股份冻结和调帐表                                                                      */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30    */
  /*  T_DDW_F05_SYS_ACCNT_DLV_HIS  修改为  T_EDW_T05_TJGMXLS  */
  
  
  
  --------------------------删除临时表------------------
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SHR_FZN_CHANGE_ACT_TEMP;
  --------临时表 二代证验证------

CREATE TABLE  DDW_PROD.T_DDW_PRT_SHR_FZN_CHANGE_ACT_TEMP  AS 
  SELECT 
               T.BUS_DATE                                                           
               ,t.YYB                                          as BRH_NO            --营业部编号  
               ,a6.JGMC                                        as BRH_NAME          --营业部名称									   
               ,t.WTH                                          as ODR_NO            --委托号                                                            
               ,t.KHH                                          as CUST_NO           --客户号                                                                                                 
               ,t.KHXM                                         as CUST_NAME         --客户姓名                                                           
               ,t.JYS                                          as EXG               --交易所                                                            
               ,t.GDH                                          as SHRHLD_NO         --股东号                                                            
               ,t.GDXM                                         as SHRHLD_NAME       --股东姓名                                                           
               ,t.CJRQ                                         as MTCH_DT           --成交日期                                                           
               ,t.CJSJ                                         as MTCH_TM           --成交时间                                                           
               ,CAST (t.WTLB AS STRING)                        as ODR_CGY           --委托类别                                                           
               ,t.WTFS                                         as ODR_MOD           --委托方式                                                           
               ,a1.JYLBMC                                      as TRD_CGY_NAME      --交易类别名称                                                         
               ,t.ZQDM                                         as SEC_CD            --证券代码                                                           
               ,t.ZQMC                                         as SEC_NAME          --证券名称                                                           
               ,t.ZQLB                                         as SEC_CGY           --证券类别                                                           
                                                                                                                                               
               ,t.CJSL                                         as MTCH_QTY          --成交数量                                                           
               
               ,t.BCDJSL                                       as TT_FZN_QTY        --本次冻结数量                                                                                          
               ,t.CJBH                                         as MTCH_NO           --成交编号                                                           
                           
               ,a2.XM                                          as OPRT_TELR         --操作员               
               ,CASE WHEN t.FHGY IS NULL
                     THEN NULL
                     ELSE a3.XM
                     END                                       as RECHK_TELR       --复核柜员
               ,CASE WHEN t.XTBS = 'JZJY'
                     THEN 'ABOSS'      
                     WHEN t.XTBS = 'RZRQ'    
                     THEN 'RZRQ'       
                     END                                       as CGY               --类别                   
               ,CASE  WHEN  a4.BRH_NO IS NOT NULL
                                         THEN '临柜'
                                         ELSE '其他'  
                                         END   as OPRT_MOD         
                                         
                                                                                                                                                                                                         
  FROM          EDW_PROD.T_EDW_T05_TJGMXLS                t
  LEFT JOIN     EDW_PROD.T_EDW_T99_TJYLB                  a1
  ON            t.WTLB = a1.JYLB  
  AND           t.XTBS = a1.XTBS
  AND           t.bus_date = a1.bus_date 
  LEFT JOIN     EDW_PROD.T_EDW_T01_TGYXX                  a2
  ON            t.LOGINID = a2.LOGINID        
  AND           t.XTBS = a2.XTBS
  AND           t.bus_date = a2.bus_date 
  LEFT JOIN     EDW_PROD.T_EDW_T01_TGYXX                  a3
  ON            t.FHGY = a3.LOGINID        
  AND           t.XTBS = a3.XTBS 
  AND           t.bus_date = a3.bus_date  
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                a4
  ON            t.YYB = a4.BRH_NO
  AND           a4.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     EDW_PROD.T_EDW_T03_TJGGL                      a6
  ON            t.YYB = a6.JGDM
  AND           t.bus_date = a6.bus_date
  WHERE         t.bus_date = %d{yyyyMMdd}    
 ;


--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_SHR_FZN_CHANGE_ACT
( 
							        BRH_NO                                 --营业部编号  
								   ,BRH_NAME                               --营业部名称
                                   ,CUST_NO                                --客户号      
                                   ,CUST_NAME                              --客户姓名    
                                   ,EXG                                    --交易所      
                                   ,SHRHLD_NO                              --股东号      
                                   ,MTCH_DT                                --成交日期    
                                   ,ODR_CGY                                --委托类别    
                                   ,TRD_CGY_NAME                           --交易类别名称
                                   ,SEC_CD                                 --证券代码    
                                   ,SEC_NAME                               --证券名称    
                                   ,SEC_CGY                                --证券类别    
                                   ,MTCH_QTY                               --成交数量    
                                   ,TT_FZN_QTY                             --本次冻结数量
                                   ,MTCH_NO                                --成交编号    
                                   ,CGY                                    --类别        
                                   ,OPRT_TELR                              --操作柜员  
                                   ,RECHK_TELR                             --复核柜员								   
                                   ,ACCNT_SRC                              --账户来源 
								   ,CTF_CGY                --开户证件类别
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
								 t.BRH_NO       		  AS BRH_NO                                 --营业部编号
                                ,t.BRH_NAME               AS BRH_NAME                               --营业部名称								 
								,t.CUST_NO                AS CUST_NO                                --客户号      
								,t.CUST_NAME              AS CUST_NAME                              --客户姓名    
								,t.EXG                    AS EXG                                    --交易所      
								,t.SHRHLD_NO              AS SHRHLD_NO                              --股东号      
								,t.MTCH_DT                AS MTCH_DT                                --成交日期    
								,t.ODR_CGY                AS ODR_CGY                                --委托类别    
								,t.TRD_CGY_NAME           AS TRD_CGY_NAME                           --交易类别名称
								,t.SEC_CD                 AS SEC_CD                                 --证券代码    
								,t.SEC_NAME               AS SEC_NAME                               --证券名称    
								,t.SEC_CGY                AS SEC_CGY                                --证券类别    
								,t.MTCH_QTY               AS MTCH_QTY                               --成交数量    
								,t.TT_FZN_QTY             AS TT_FZN_QTY                             --本次冻结数量
								,t.MTCH_NO                AS MTCH_NO                                --成交编号    
								,t.CGY                    AS CGY                                    --类别        
								,t.OPRT_TELR              AS OPRT_TELR                              --操作柜员 
                                ,t.RECHK_TELR             AS RECHK_TELR                             --复核柜员								
								,t.CGY                    AS ACCNT_SRC                              --账户来源
								,a2.CTF_CGY_CD_NAME           AS   CTF_CGY  --开户证件类别
  FROM  		DDW_PROD.T_DDW_PRT_SHR_FZN_CHANGE_ACT_TEMP  	t
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a1
  ON            t.CUST_NO = a1.CUST_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD     a2
  ON            a1.CTF_CGY_CD = a2.CTF_CGY_CD  
  WHERE 		t.bus_date = %d{yyyyMMdd}
  AND           t.OPRT_MOD = '临柜'
  AND           t.MTCH_NO NOT IN ('清除全体持仓','开户认领','非流通股转入','非流通股转出')
  AND           (t.CGY = 'ABOSS' OR t.CGY = 'RZRQ')
  AND           t.ODR_CGY IN ('20','21','97')
;
  

-----------------------------加载结束--------------------


  --------------------------删除临时表------------------
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SHR_FZN_CHANGE_ACT_TEMP;
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_SHR_FZN_CHANGE_ACT',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_SHR_FZN_CHANGE_ACT ;
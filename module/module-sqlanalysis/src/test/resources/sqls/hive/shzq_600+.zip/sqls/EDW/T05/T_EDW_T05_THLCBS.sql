--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:清算红利差别税表                                                                     */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  

TRUNCATE TABLE EDW_PROD.T_EDW_T05_THLCBS ;
---------------- 插入集中交易数据 -----------------------
INSERT  INTO  EDW_PROD.T_EDW_T05_THLCBS
(
                                    CJRQ                                --成交日期                               
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQLB                                --证券类别                               
                                   ,KCRQ                                --开仓日期                               
                                   ,CJJE                                --成交金额                               
                                   ,CJJG                                --成交价格                               
                                   ,JSJ                                 --结算价                                
                                   ,CJSL                                --成交数量                               
                                   ,YSJE                                --实收金额                               
                                   ,CJBH                                --成交编号                               
                                   ,XWDM                                --席位代码                               
                                   ,JSBZDM                              --结算币种                               
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,JSZH                                --结算帐户                               
                                   ,DJRQ                                --通知日期                               
                                   ,SBRQ                                --申报日期                               
                                   ,SBJG                                --申报结果                               
                                   ,ZJDJLSH                             --资金冻结流水号                            
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.CJRQ                                as CJRQ                                --成交日期                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.ZQLB                                as ZQLB                                --证券类别                                
                                   ,t.KCRQ                                as KCRQ                                --开仓日期                                
                                   ,t.CJJE                                as CJJE                                --成交金额                                
                                   ,t.CJJG                                as CJJG                                --成交价格                                
                                   ,t.JSJ                                 as JSJ                                 --结算价                                 
                                   ,t.CJSL                                as CJSL                                --成交数量                                
                                   ,t.YSJE                                as YSJE                                --实收(付)金额                             
                                   ,t.CJBH                                as CJBH                                --成交编号                                
                                   ,t.XWH                                 as XWDM                                --席位代码                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as JSBZDM                              --结算币种                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZJJSLX                              --结算类型                                
                                   ,t.JSJG                                as JSJG                                --结算机构                                
                                   ,t.JSZH                                as JSZH                                --结算帐户                                
                                   ,t.DJRQ                                as DJRQ                                --通知日期                                
                                   ,t.SBRQ                                as SBRQ                                --申报日期                                
                                   ,t.SBJG                                as SBJG                                --申报结果                                
                                   ,t.ZJDJLSH                             as ZJDJLSH                             --资金冻结流水号                             
                                   ,'JZJY'                               as XTBS                                --                                    
 FROM           JZJYCX.SECURITIES_THLCBS 					t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 		t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 		t2 
 ON             t2.DMLX = 'ZJJSLX'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.JSLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING         t3
 ON             t3.YXT = 'JZJY'
 AND            t3.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}' ;
---------------------插入集中交易数据结束--------------
---------------------插入融资融券数据--------------
INSERT  INTO  EDW_PROD.T_EDW_T05_THLCBS
(
                                    CJRQ                                --成交日期                               
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQLB                                --证券类别                               
                                   ,KCRQ                                --开仓日期                               
                                   ,CJJE                                --成交金额                               
                                   ,CJJG                                --成交价格                               
                                   ,JSJ                                 --结算价                                
                                   ,CJSL                                --成交数量                               
                                   ,YSJE                                --实收金额                               
                                   ,CJBH                                --成交编号                               
                                   ,XWDM                                --席位代码                               
                                   ,JSBZDM                              --结算币种                               
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,JSZH                                --结算帐户                               
                                   ,DJRQ                                --通知日期                               
                                   ,SBRQ                                --申报日期                               
                                   ,SBJG                                --申报结果                               
                                   ,ZJDJLSH                             --资金冻结流水号                            
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.CJRQ                                as CJRQ                                --成交日期                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.ZQLB                                as ZQLB                                --证券类别                                
                                   ,t.KCRQ                                as KCRQ                                --开仓日期                                
                                   ,t.CJJE                                as CJJE                                --成交金额                                
                                   ,t.CJJG                                as CJJG                                --成交价格                                
                                   ,t.JSJ                                 as JSJ                                 --结算价                                 
                                   ,t.CJSL                                as CJSL                                --成交数量                                
                                   ,t.YSJE                                as YSJE                                --实收(付)金额                             
                                   ,t.CJBH                                as CJBH                                --成交编号                                
                                   ,t.XWH                                 as XWDM                                --席位代码                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as JSBZDM                              --结算币种                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZJJSLX                              --结算类型                                
                                   ,t.JSJG                                as JSJG                                --结算机构                                
                                   ,t.JSZH                                as JSZH                                --结算帐户                                
                                   ,t.DJRQ                                as DJRQ                                --通知日期                                
                                   ,t.SBRQ                                as SBRQ                                --申报日期                                
                                   ,t.SBJG                                as SBJG                                --申报结果                                
                                   ,t.ZJDJLSH                             as ZJDJLSH                             --资金冻结流水号                             
                                   ,'RZRQ'                               as XTBS                                --                                    
 FROM           RZRQCX.SECURITIES_THLCBS 						t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t2 
 ON             t2.DMLX = 'ZJJSLX'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.JSLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING         t3
 ON             t3.YXT = 'RZRQ'
 AND            t3.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE 			t.DT = '%d{yyyyMMdd}';
---------------------插入融资融券数据结束--------------

---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_THLCBS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_THLCBS;
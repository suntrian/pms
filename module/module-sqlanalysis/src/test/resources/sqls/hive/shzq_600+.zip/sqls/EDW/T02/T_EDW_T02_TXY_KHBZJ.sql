 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户可用保证金表                                                                  */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
   TRUNCATE TABLE EDW_PROD.T_EDW_T02_TXY_KHBZJ;  
----------插入数据开始-------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TXY_KHBZJ
(
                                    RQ                                  --日期                                 
                                   ,KHH                                 --客户号                                
                                   ,HTBH                                --合同编号                               
                                   ,KYBZJ                               --可用保证金                              
                                   ,DBBL                                --维持担保比例                             
                                   ,KYZJ                                --可用资金                               
                                   ,ZQSZ                                --证券市值                               
                                   ,DBSZ                                --担保证券市值                             
                                   ,RZFZ                                --融资负债                               
                                   ,RQFZ                                --融券负债                               
                                   ,YZBZJ                               --应追保证金                              
                                   ,YPCZJ                               --应平仓金额                              
                                   ,KTZC                                --可提资产标准                             
                                   ,ZZC                                 --总资产                                
                                   ,ZFZ                                 --总负债                                
                                   ,JZC                                 --净资产                                
                                   ,CEDBBL                              --超额担保比例                             
                                   ,QZPCBL                              --强制平仓比例                             
                                   ,PCDWBL                              --强平到位比例                             
                                   ,ZBBL                                --追保比例                               
                                   ,ZBDWBL                              --追保到位比例                             
                                   ,WCBL                                --维持保证金比例                            
                                   ,DPBL                                --盯盘保证金比例                            
                                   ,QTBL                                --其他比例                               
                                   ,RZBL                                --融资比例                               
                                   ,RQBL                                --融券比例                               
                                   ,ZBRQ                                --追保日期    
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.RQ                                  as RQ                                  --日期                                  
                                   ,t.HTBH                                as KHH                                 --合同编号                                
                                   ,t.KHH                                 as HTBH                                --客户号                                 
                                   ,t.KYBZJ                               as KYBZJ                               --可用保证金                               
                                   ,t.DBBL                                as DBBL                                --维持担保比例                              
                                   ,t.KYZJ                                as KYZJ                                --可用资金                                
                                   ,t.ZQSZ                                as ZQSZ                                --证券市值                                
                                   ,t.DBSZ                                as DBSZ                                --担保证券市值                              
                                   ,t.RZFZ                                as RZFZ                                --融资负债                                
                                   ,t.RQFZ                                as RQFZ                                --融券负债                                
                                   ,t.YZBZJ                               as YZBZJ                               --应追保证金                               
                                   ,t.YPCZJ                               as YPCZJ                               --应平仓金额                               
                                   ,t.KTZC                                as KTZC                                --可提资产标准                              
                                   ,t.ZZC                                 as ZZC                                 --总资产                                 
                                   ,t.ZFZ                                 as ZFZ                                 --总负债                                 
                                   ,t.JZC                                 as JZC                                 --净资产                                 
                                   ,t.CEDBBL                              as CEDBBL                              --超额担保比例                              
                                   ,t.QZPCBL                              as QZPCBL                              --强制平仓比例                              
                                   ,t.PCDWBL                              as PCDWBL                              --强平到位比例                              
                                   ,t.ZBBL                                as ZBBL                                --追保比例                                
                                   ,t.ZBDWBL                              as ZBDWBL                              --追保到位比例                              
                                   ,t.WCBL                                as WCBL                                --维持保证金比例                             
                                   ,t.DPBL                                as DPBL                                --盯盘保证金比例                             
                                   ,t.QTBL                                as QTBL                                --其他比例                                
                                   ,t.RZBL                                as RZBL                                --融资比例                                
                                   ,t.RQBL                                as RQBL                                --融券比例                                
                                   ,t.ZBRQ                                as ZBRQ                                --追保日期    
                                   ,'RZRQ'                                as XTBS								   
 FROM        RZRQCX.MARGIN_TXY_KHBZJ        t
 WHERE       t.DT = '%d{yyyyMMdd}';
------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TXY_KHBZJ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TXY_KHBZJ;
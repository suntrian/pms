--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:流失客户产品交易统计表                                                               */
--/* 创建人:OYJ                                                                                    */
--/* 创建时间:2019-10-09                                                                           */ 


TRUNCATE TABLE DDW_PROD.T_CUST_LOSS_PROD_TRD_DEL_STATS;

INSERT INTO DDW_PROD.T_CUST_LOSS_PROD_TRD_DEL_STATS
(
 CUST_NO
,KHFXDJ
,PROD_CD
,CPFXDJ
,TRD_ITMS
,TRD_AMT
)
SELECT 
 A.CUST_NO
,CAST(B.CPDJ AS STRING) AS KHFXDJ
,A.PROD_CD
,COALESCE(CONCAT('JJ',CAST(C.JJFXDJ AS STRING)),CONCAT('JR',CAST(D.FXDJ AS STRING)),'') AS CPFXDJ
,COUNT(*) AS CNT
,SUM(CNFM_AMT) AS TRD_AMT
FROM DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS A
LEFT JOIN YGTCX.CIF_TKHSDX B
ON A.CUST_NO = B.KHH
AND B.DT = '%d{yyyyMMdd}'
AND B.SDXLB = 'JJFXCSNL'
LEFT JOIN JZJYCX.OFS_TOF_JJXX C
ON A.PROD_CD = C.JJDM
AND C.DT = '%d{yyyyMMdd}'
LEFT JOIN JZJYCX.JRCP_TJRCP_CPDM D
ON A.PROD_CD = D.CPDM
AND D.DT = '%d{yyyyMMdd}'
WHERE BUS_DATE <= %d{yyyyMMdd}
AND A.PROD_BIZ_CD in ('122','130','139')
AND A.CUST_NO IN (SELECT KHH FROM YGTCX.CIF_TKHXX WHERE DT = '%d{yyyyMMdd}' AND KHLB = 0)
GROUP BY
 A.CUST_NO
,A.PROD_CD
,B.CPDJ
,COALESCE(CONCAT('JJ',CAST(C.JJFXDJ AS STRING)),CONCAT('JR',CAST(D.FXDJ AS STRING)),'')
;

invalidate metadata DDW_PROD.T_CUST_LOSS_PROD_TRD_DEL_STATS;

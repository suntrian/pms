------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:证券代码表                                                                 */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
TRUNCATE TABLE DDW_PROD.T_DDW_PUB_SEC_CD ;
INSERT OVERWRITE DDW_PROD.T_DDW_PUB_SEC_CD
(
                                     EXG                  --交易所  
                                    ,SEC_CD               --证券代码
                                    ,SEC_NAME             --证券名称    								                                   								
                                    ,SEC_CGY              --证券类别
                                    ,SEC_FULLNM           --证券全称
                                    ,BS_LMT               --买卖限制
                                    ,IDSTR_CD             --行业代码
                                    ,IDSTR_NAME           --行业名称
 
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT         t.JYS	         as EXG                  --交易所                           
               ,t.ZQDM           as SEC_CD               --证券代码
               ,t.ZQMC           as SEC_NAME             --证券名称                                          						   
               ,t.ZQLB           as SEC_CGY              --证券类别
               ,t.ZQQC           as SEC_FULLNM           --证券全称
               ,t.MMXZ           as BS_LMT               --买卖限制
               ,t.HYDM           as IDSTR_CD             --行业代码
               ,t.HYMC           as IDSTR_NAME           --行业名称 
 FROM           EDW_PROD.T_EDW_T04_TZQDM                                 t       
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
;		
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_SEC_CD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_SEC_CD ;
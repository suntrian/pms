 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:转融通合约信息表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
    TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZRT_HYXX;
--------插入数据开始--------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZRT_HYXX
(
                                    HYXXLSH                             --合约信息流水号                            
                                   ,ZRT_JSJG                            --转融通结算机构                            
                                   ,FSDX                                --发送对象                               
                                   ,QSRQ                                --清算日期                               
                                   ,WTRQ                                --委托日期                               
                                   ,CJRQ                                --成交日期                               
                                   ,HYBH                                --合约编号                               
                                   ,ZRT_HYLX                            --转融通合约类型                            
                                   ,ZRT_YWLX                            --转融通业务类型                            
                                   ,JYS                                 --交易所                                
                                   ,BZDM                                --币种代码                               
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,GDH                                 --股东号                                
                                   ,XWH                                 --席位                                 
                                   ,QX                                  --期限                                 
                                   ,QXFL                                --期限费率                               
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,HYSL                                --合约数量                               
                                   ,HYJE                                --合约金额                               
                                   ,HYYJLX                              --合约预计利息                             
                                   ,HYYJFX                              --合约预计罚息                             
                                   ,ZRT_HYZT                            --转融通合约状态                            
                                   ,HYDQR                               --合约到期日                              
                                   ,CJBH                                --成交编号                               
                                   ,WTH                                 --委托号                                
                                   ,JSSL                                --交收数量                               
                                   ,JSJE                                --交收金额                               
                                   ,JSBJ                                --交收本金                               
                                   ,JSLX                                --交收利息                               
                                   ,JSFXJE                              --交收罚息金额                             
                                   ,JSWYJ                               --交收违约金                              
                                   ,JSQTF                               --交收其它费                              
                                   ,CHSL                                --偿还数量                               
                                   ,CHJE                                --偿还金额                               
                                   ,CHBJ                                --偿还本金                               
                                   ,CHLX                                --偿还利息                               
                                   ,CHFX                                --偿还罚息                               
                                   ,CHWYJ                               --偿还违约金                              
                                   ,CHQTF                               --偿还其它费                              
                                   ,JGSM                                --说明备注                               
                                   ,ZRT_DDLY                            --转融通订单来源                            
                                   ,XQBH                                --需求编号                               
                                   ,XGRQ                                --修改日期                               
                                   ,ZQBS                                --展期标识                               
                                   ,XJTDDW                              --现金替代单位                             
                                   ,ZQSL                                --展期数量                         
                                   ,ZQJE                                --展期金额                               
                                   ,SYSL                                --剩余数量                               
                                   ,SYJE                                --剩余金额                               
                                   ,BDRQ                                --变动日期                               
                                   ,YDH                                 --约定号                                
                                   ,DFGDH                               --对方股东号                              
                                   ,DFXW                                --对方席位                               
                                   ,ZRT_JYLB                            --转融通交易类别                            
                                   ,ZQJG                                --证券价格                               
                                   ,ZQYJLX                              --证券交易利息   
                                   ,CJLX   
								   ,DSFHYBH
								   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.LSH                                 as HYXXLSH                             --流水号                                 
                                   ,t.JSJG                                as ZRT_JSJG                            --结算机构                                
                                   ,t.FSDX                                as FSDX                                --发送对象                                
                                   ,t.QSRQ                                as QSRQ                                --清算日期                                
                                   ,t.WTRQ                                as WTRQ                                --委托日期                                
                                   ,t.CJRQ                                as CJRQ                                --成交日期                                
                                   ,t.HYBH                                as HYBH                                --合约编号                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.HYLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZRT_HYLX                            --合约类型                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.YWLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZRT_YWLX                            --转融通类别                               
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t7.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.XWH                                 as XWH                                 --席位                                  
                                   ,t.QX                                  as QX                                  --期限                                  
                                   ,t.QXFL                                as QXFL                                --期限费率                                
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.HYSL                                as HYSL                                --合约数量                                
                                   ,t.HYJE                                as HYJE                                --合约金额                                
                                   ,t.HYYJLX                              as HYYJLX                              --合约预计利息                              
                                   ,t.HYYJFX                              as HYYJFX                              --合约预计罚息                              
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.HYZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZRT_HYZT                            --合约状态                                
                                   ,t.HYDQR                               as HYDQR                               --合约到期日                               
                                   ,t.CJBH                                as CJBH                                --成交编号                                
                                   ,t.WTH                                 as WTH                                 --委托号                                 
                                   ,t.JSSL                                as JSSL                                --交收数量                                
                                   ,t.JSJE                                as JSJE                                --交收金额                                
                                   ,t.JSBJ                                as JSBJ                                --交收本金                                
                                   ,t.JSLX                                as JSLX                                --交收利息                                
                                   ,t.JSFXJE                              as JSFXJE                              --交收罚息金额                              
                                   ,t.JSWYJ                               as JSWYJ                               --交收违约金                               
                                   ,t.JSQTF                               as JSQTF                               --交收其它费                               
                                   ,t.CHSL                                as CHSL                                --偿还数量                                
                                   ,t.CHJE                                as CHJE                                --偿还金额                                
                                   ,t.CHBJ                                as CHBJ                                --偿还本金                                
                                   ,t.CHLX                                as CHLX                                --偿还利息                                
                                   ,t.CHFX                                as CHFX                                --偿还罚息                                
                                   ,t.CHWYJ                               as CHWYJ                               --偿还违约金                               
                                   ,t.CHQTF                               as CHQTF                               --偿还其它费                               
                                   ,t.JGSM                                as JGSM                                --说明备注                                
                                   ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.DDLY AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZRT_DDLY                            --合约来源                                
                                   ,t.XQBH                                as XQBH                                --需求编号                                
                                   ,t.XGRQ                                as XGRQ                                --修改日期                                
                                   ,t.ZQBS                                as ZQBS                                --展期标识                                
                                   ,t.XJTDDW                              as XJTDDW                              --现金替代单位                              
                                   ,t.ZQQRSL                              as ZQSL                                --展期数量                                
                                   ,t.ZQQRJE                              as ZQJE                                --展期金额                                
                                   ,t.SYSL                                as SYSL                                --剩余数量                                
                                   ,t.SYJE                                as SYJE                                --剩余金额                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.YDH                                 as YDH                                 --约定号                                 
                                   ,t.DFGDH                               as DFGDH                               --对方股东号                               
                                   ,t.DFXW                                as DFXW                                --对方席位                                
                                   ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZRT_JYLB                            --交易类别                                
                                   ,t.ZQJG                                as ZQJG                                --证券价格                                
                                   ,t.ZQYJLX                              as ZQYJLX                              --证券交易利息  
                                   ,T.CJLX                                as CJLX   
								   ,T.DSFHYBH                             as DSFHYBH
								   ,'RZRQ'                                as XTBS								   
 FROM           RZRQCX.ZRT_TZRT_HYXX                             t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING           t1 
 ON             t1.DMLX = 'ZRT_HYLX'                             
 AND            t1.YXT = 'RZRQ'                                  
 AND            t1.YDM = CAST(t.HYLX AS VARCHAR(20))             
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING           t2 
 ON             t2.DMLX = 'ZRT_YWLX'                             
 AND            t2.YXT = 'RZRQ'                                  
 AND            t2.YDM = CAST(t.YWLB AS VARCHAR(20))             
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING           t3 
 ON             t3.DMLX = 'BZDM'                                 
 AND            t3.YXT = 'RZRQ'                                  
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20))               
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING           t4 
 ON             t4.DMLX = 'ZRT_HYZT'                             
 AND            t4.YXT = 'RZRQ'                                  
 AND            t4.YDM = CAST(t.HYZT AS VARCHAR(20))             
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING           t5 
 ON             t5.DMLX = 'ZRT_DDLY'                             
 AND            t5.YXT = 'RZRQ'                                  
 AND            t5.YDM = CAST(t.DDLY AS VARCHAR(20))             
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING           t6 
 ON             t6.DMLX = 'ZRT_JYLB'                             
 AND            t6.YXT = 'RZRQ'
 AND            t6.YDM = CAST(t.JYLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING              t7
 ON             t7.YXT = 'RZRQ'
 AND            t7.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束-------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZRT_HYXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TZRT_HYXX;
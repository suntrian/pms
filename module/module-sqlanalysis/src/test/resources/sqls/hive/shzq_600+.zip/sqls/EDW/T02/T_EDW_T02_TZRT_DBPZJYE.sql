 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:转融通担保品资金余额表                                                              */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
    TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZRT_DBPZJYE; 
---------插入数据开始-------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZRT_DBPZJYE
(
                                    DZRQ                                --对账日期                               
                                   ,DBZJZH                              --担保资金明细账户                           
                                   ,BZDM                                --币种代码                               
                                   ,ZJYE                                --资金余额                               
                                   ,ZJDJJE                              --资金冻结金额                             
                                   ,DBPZJZ                              --担保品总价值    
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.DZRQ                                as DZRQ                                --对账日期                                
                                   ,t.DBZJZH                              as DBZJZH                              --担保资金明细账户                            
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as BZDM                                --币种                                  
                                   ,t.ZJYE                                as ZJYE                                --资金余额                                
                                   ,t.ZJDJJE                              as ZJDJJE                              --资金冻结金额                              
                                   ,t.DBPZJZ                              as DBPZJZ                              --担保品总价值    
									,'RZRQ'                                as XTBS								   
 FROM           RZRQCX.ZRT_TZRT_DBPZJYE                     t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING      t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
-------插入数据结束--------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZRT_DBPZJYE',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TZRT_DBPZJYE; 
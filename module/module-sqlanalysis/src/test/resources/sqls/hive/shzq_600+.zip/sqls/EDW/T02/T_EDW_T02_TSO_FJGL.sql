 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:个股期权投资者分级管理表                                                           */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
TRUNCATE TABLE EDW_PROD.T_EDW_T02_TSO_FJGL;
--------插入数据开始------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TSO_FJGL
(
                                    SOP_FXJB                            --个股期权投资者级别                          
                                   ,SOP_MMFX                            --期权买卖方向                             
                                   ,SOP_KPCBZ                           --开平仓标志                              
                                   ,QQLXFW                              --允许期权类型范围                           
                                   ,BDBQFW                              --允许备兑标签范围  
								   ,XTBS                                
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.FXJB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as SOP_FXJB                            --风险级别                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.MMFX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as SOP_MMFX                            --买卖方向                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.KPBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SOP_KPCBZ                           --开平仓标志                               
                                   ,t.QQLXFW                              as QQLXFW                              --允许期权类型范围                            
                                   ,t.BDBQFW                              as BDBQFW                              --允许备兑标签范围
                                   ,'GGQQ'                                as XTBS								   
 FROM           GGQQCX.SOPTION_TSO_FJGL t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'SOP_FXJB'
 AND            t1.YXT = 'GGQQ'
 AND            t1.YDM = CAST(t.FXJB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'SOP_MMFX'
 AND            t2.YXT = 'GGQQ'
 AND            t2.YDM = CAST(t.MMFX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'SOP_KPCBZ'
 AND            t3.YXT = 'GGQQ'
 AND            t3.YDM = CAST(t.KPBZ AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TSO_FJGL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TSO_FJGL;
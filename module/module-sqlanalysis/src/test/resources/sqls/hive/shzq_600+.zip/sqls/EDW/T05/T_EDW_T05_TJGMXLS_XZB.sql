 --/* ***************************************** SQL Begin *****************************************  */
  --/* 脚本功能:历史交割明细表修正表                                                                      */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2016-11-02                                                                        */ 
  ALTER TABLE EDW_PROD.T_EDW_T05_TJGMXLS_XZB DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ; 
  
  -----------创建临时表(剔除退市后在交割里面的操作)
  DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_TEMP ;
  CREATE TABLE EDW_PROD.T_EDW_T05_TJGMXLS_XZB_TEMP as
  SELECT  a.KHH
         ,a.KHXM
         ,a.YYB
         ,a.GDH
         ,a.JYS
         ,a.BZDM
		 ,a.ZQLB
         ,CASE WHEN d.zqdm1 is not null
		       THEN d.ZQDM
			   WHEN e.ZQDM IS NOT NULL
			   THEN e.ZQDM
			   ELSE NVL(b.SecurityCode,EDW_PROD.CODE_TRANS_ZQDM(a.JYS,a.ZQDM))
			   END  as ZQDM                         
		 ,a.ZQDM as ZQDM1
         ,a.ZQMC
         ,a.WTFS
         ,a.WTLB
         ,a.CJBH
         ,a.CJRQ
         ,a.CJSL
         ,a.CJJG
         ,a.JSJ
         ,a.LXJG
		 ,a.JSRQ
         ,CASE WHEN a.JYS IN ('SH','SZ') AND a.WTLB = 42 AND a.CJJE < 0
			   THEN 0-CJJE
			   WHEN a.JYS = 'SH' AND a.WTLB = 43 AND SUBSTR(a.ZQDM,1,3) = '519' AND a.CJJE = 0
			   AND  a.S1 =0 AND a.s2 = 0 and a.S3 =0 AND a.S4 = 0 AND a.S5 = 0 AND a.s6 = 0
			   THEN a.YSJE
			   WHEN a.WTLB = 84 AND a.YSJE = 0 AND a.CJBH LIke '%初始合同无效%'
			   THEN 0
			   ELSE a.CJJE
			   END  as CJJE
         ,a.LXJE
         ,a.S1
         ,a.S2     
         ,CAST(CASE WHEN a.JYS = 'SB' AND a.ZQLB = 'GO' AND a.WTLB = 2
		       THEN a.CJJE*0.00005
			   ELSE a.S3
			   END as DECIMAL(38,2))   as S3
         ,a.S4
         ,a.S5
         ,a.S6
         ,a.S11
         ,a.S12
         ,a.S13
         ,a.S15
         ,a.S16
         ,CASE WHEN a.JYS = 'SH'
			    AND  SUBSTR(a.ZQDM,1,3) = '519'
				AND  a.CJBH = '认购结果'
				THEN 0-(a.CJJE+a.S1)
				ELSE a.YSJE
				END  as YSJE
		 ,a.BUS_DATE
		 ,a.YSSL
		 ,a.CZZD1
		 ,a.XTBS
	FROM EDW_PROD.T_EDW_T05_TJGMXLS                       a
	LEFT JOIN (SELECT SecurityCode,ExApplyingCode,DT 
		           FROM   fundext.dbo_MF_FundArchives
				   WHERE length(trim(exapplyingcode))>0
				   AND    securitycode <> exapplyingcode
				   AND    substr(securitycode,7,1) <> 'J'
				   AND    DT =  '%d{yyyyMMdd}'
			   )                                       b
	ON         EDW_PROD.CODE_TRANS_ZQDM(a.JYS,a.ZQDM) = b.ExApplyingCode
	AND        (SUBSTR(a.ZQDM,1,3) = '519' AND a.JYS = 'SH')
	  LEFT JOIN (SELECT      b.SECUCODE             as ZQDM
                              ,b.secumarket          as SC
		                      ,a.onlinepuboffcode    as SGDM
							  ,a.PREFALTCODEH        as PZDM
		                      ,CAST(CONCAt(substr(prefaltpaystartdateh,1,4),substr(prefaltpaystartdateh,6,2),substr(prefaltpaystartdateh,9,2) ) as INT) as PZQSRQ
                              ,CAST(CONCAt(substr(prefaltpayenddateh,1,4),substr(prefaltpayenddateh,6,2),substr(prefaltpayenddateh,9,2) ) as INT)       as PZJZRQ
		                      ,CAST(CONCAt(substr(onlinepuboffdate,1,4),substr(onlinepuboffdate,6,2),substr(onlinepuboffdate,9,2) ) as INT) as SGQSRQ
		                      ,CAST(CASE WHEN LENGTH(TRIM(Exchangeday)) > 0
		                                 THEN CONCAt(substr(Exchangeday,1,4),substr(Exchangeday,6,2),substr(Exchangeday,9,2) )
				                         WHEN LENGTH(TRIM(a.Exchangeday)) = 0 AND LENGTH(TRIM(b.listeddate)) > 0
				                         THEN CONCAt(substr(b.listeddate,1,4),substr(b.listeddate,6,2),substr(b.listeddate,9,2) )
				                         WHEN LENGTH(TRIM(a.Exchangeday)) = 0 AND LENGTH(TRIM(b.listeddate)) = 0
				                         THEN '99999999' 
				                         END  as INT
								    )                          as SSRQ
                             FROM        FUNDEXT.DBO_BOND_CONBDISSUE    a
                             LEFT JOIN   FUNDEXT.DBO_BOND_CODE          b
                             ON          a.INNERCODE = b.INNERCODE
                             AND         a.DT = b.DT
                             WHERE       a.DT = '%d{yyyyMMdd}'
                             AND         (CONCAt(substr(onlinepuboffdate,1,4),substr(onlinepuboffdate,6,2),substr(onlinepuboffdate,9,2) ) > '20140101'
							             OR CONCAt(substr(prefaltpaystartdateh,1,4),substr(prefaltpaystartdateh,6,2),substr(prefaltpaystartdateh,9,2) ) > '20140101'
										 )
                   )                    e
	   ON              (EDW_PROD.CODE_TRANS_RGDMQZ(a.JYS,a.ZQDM) = e.SGDM  OR EDW_PROD.CODE_TRANS_RGDMQZ(a.JYS,a.ZQDM) = e.PZDM)
       AND    a.JYS = DECODE(e.SC,83,'SH',90,'SZ')
  	  -- AND       (    (a.JYS IN ('SH','HB') AND e.SC = 83) 
      --             OR (a.JYS IN ('SZ','SB') AND e.SC = 90)       
       --          )
       AND     a.WTLB = 3
      -- AND   ((a.JYS = 'SH' AND SUBSTR(a.ZQDM,1,3) IN ('754','733','783','743','704','793','764','755','753')) 
		--	        OR (a.JYS = 'SZ' AND SUBSTR(a.ZQDM,1,2) IN ('07','37','08','38')) ) 
	   --AND SUBSTR(a.ZQDM,1,3) IN ('754','733','783','743','704','793','764','755','753','370')
       AND a.BUS_DATE > = e.PZQSRQ 
	   AND a.BUS_DATE < e.SSRQ
	   LEFT JOIN (SELECT  b.SECUCode as ZQDM
		                  ,CASE WHEN b.SecuMarket = 83
                                THEN 'SH'
                                WHEN b.SecuMarket = 90
								THEN 'SZ'
								END as JYS
						  ,a.ApplyCodeOnline as zqdm1
						  ,CAST(CONCAt(substr(a.issuestardate,1,4),substr(a.issuestardate,6,2),substr(a.issuestardate,9,2) ) as INT)   as QSRQ
                          ,CAST(CONCAt(substr(a.IssueEndDate,1,4),substr(a.IssueEndDate,6,2),substr(a.IssueEndDate,9,2) ) as INT)   as JZRQ							  
		           FROM        FUNDEXT.DBO_Bond_Issue          a
                   LEFT JOIN   fundext.dbo_BOND_CODE           b
                   ON          a.INNERCODE = b.INNERCODE
                   AND         a.DT = b.DT
				   WHERE    a.DT = '%d{yyyyMMdd}'
				   AND       CONCAt(substr(a.issuestardate,1,4),substr(a.issuestardate,6,2),substr(a.issuestardate,9,2) ) > '20140101'
				   AND       LENGTH(TRIM(a.applycodeonline))>0
				  )                   d
	ON        a.zqdm = d.zqdm1
	AND       a.jys = d.JYS
	AND       a.BUS_DATE BETWEEN d.QSRQ AND d.JZRQ
    LEFT JOIN  ( SELECT      a.JYS,a.ZQDM,LEAST(a.SSRQ,NVL(b.SSRQ,99999999)) as SSRQ,GREATEST(a.TSRQ,NVL(b.TSRQ,00000000)) as TSRQ
                 FROM        EDW_PROD.T_EDW_T04_TSZQDM a
			     LEFT JOIN  (SELECT * FROM EDW_PROD.T_EDW_T04_TSZQDM
			                  WHERE CPLB = 5
				               AND   ZQDM LIKE '%J'
				             ) b
			     ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
			     AND          a.JYS = b.JYS
			     AND          a.BUS_DATE = b.BUS_DATE 
			    WHERE         a.CPLB IN (1,2,3,4,5,6,7) 
		         AND           a.BUS_DATE = %d{yyyyMMdd}
			   )             c
	ON           a.JYS = c.JYS 
	AND          NVL(NVL(NVL(b.SecurityCode,d.ZQDM),e.ZQDM),EDW_PROD.CODE_TRANS_ZQDM(a.JYS,a.ZQDM)) = c.ZQDM
	WHERE        a.BUS_DATE = %d{yyyyMMdd}
	AND          (c.TSRQ > = %d{yyyyMMdd} OR c.TSRQ IS NULL);  
 -------插入数据
 INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB(
                                    KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号                  
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额 
                                   ,YSSL                     --应收数量								   
                                   ,XTBS                     --账户类别 
                                   ,CZZD1                    --操作终端	                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT                    NVL(a4.KHH,t.KHH)       as KHH                      --客户号                   
                          ,t.KHXM                 as KHXM                    --客户姓名                 
                          ,t.YYB                  as YYB                      --营业部编号                                                 
                          ,t.GDH                  as GDH                    --股东号                  
                          ,t.JYS                  as JYS                         --交易所                                       
                          ,t.BZDM                 as BZDM                       --币种代码                           
                          ,t.ZQLB                 as ZQLB                      --证券类别                                  
                          ,t.ZQDM                 as ZQDM                      --证券代码                 
                          ,t.ZQDM1                as ZQDM1                      --证券代码1                
                          ,t.ZQMC                 as ZQMC                     --证券名称                 
                          ,t.WTFS                 as WTFS                      --委托方式                 
                          ,t.WTLB                 as WTLB                      --委托类别                 
                          ,t.CJBH                 as CJBH                      --成交编号                 
                          ,t.CJRQ                 as CJRQ                      --成交日期                 
                          ,t.JSRQ                 as JSRQ                     --结束日期
						  ,t.CJSL                 as CJSL                     --成交数量                 
                          ,t.CJJG                 as CJJG                     --成交价格                 
                          ,t.JSJ                  as JSJ                     --结算费                  
                          ,t.LXJG                 as LXJG                      --利息价格                 
                          ,CAST(CASE WHEN a2.CD IS NOT NULL AND t.WTLB = 11
						        THEN NVL(ROUND((a2.NEWST_PRC+a2.NEWST_INT*a2.NETPRC_TRD_FLG)*a2.TRD_UNIT*t.CJSL,2),0)
						        WHEN a2.CD IS NOT NULL
						        THEN NVL(ROUND((a2.NEWST_PRC+a2.NEWST_INT*a2.NETPRC_TRD_FLG)*a2.TRD_UNIT*t.CJSL,2),0)
								WHEN a3.ZQDM IS NOT NULL 
								AND  ((t.JYS = 'SH' AND (SUBSTR(t.ZQDM,1,3) IN ('360','600','601','603') OR SUBSTR(t.ZQDM,1,4) IN ('5800','5900')))
                                OR (t.JYS = 'SZ' AND SUBSTR(t.ZQDM,1,3) IN ('000','001','002','003','300','030','031','038','140')))
							    AND t.WTLB = 11
								THEN ROUND(a3.FXJ*t.CJSL,2)
								WHEN a3.ZQDM IS NOT NULL 
								AND  ((t.JYS = 'SH' AND (SUBSTR(t.ZQDM,1,3) IN ('360','600','601','603') OR SUBSTR(t.ZQDM,1,4) IN ('5800','5900')))
                                OR (t.JYS = 'SZ' AND SUBSTR(t.ZQDM,1,3) IN ('000','001','002','003','300','030','031','038','140'))) 
                               THEN ROUND(a3.FXJ*t.CJSL,2)                   							   
                               WHEN t.CJSL > 0 AND t.CJJE = 0 AND t.WTLB IN (7,9,10,15,31,65,66,18,20,47,48,11,21,19)
							   AND ((t.JYS = 'SH' AND SUBSTR(t.ZQDM,1,3) IN ('501','502','500','505','519','510','511','512','513','518') )
                               OR (t.JYS = 'SZ' AND (SUBSTR(t.ZQDM,1,3) IN ('150','151','159','184') OR (SUBSTR(t.ZQDM,1,2) IN ('16')))))
                               AND	t.BUS_DATE < a1.SSRQ						   
                               THEN ROUND(1*t.CJSL,2)
                               ELSE t.CJJE    END as DECIMAL(38,2))   as CJJE                     --成交金额                 
                          ,t.LXJE                 as LXJE                      --利息金额                 
                          ,t.S1                   as S1                           --实收佣金                 
                          ,t.S2                   as S2                           --印花税                   
                          ,t.S3                   as S3                           --过户费                   
                          ,t.S4                   as S4                           --附加费                   
                          ,t.S5                   as S5                           --证管费                   
                          ,t.S6                   as S6                           --交易规费                 
                          ,t.S11                  as S11                          --一级费用-经手费          
                          ,t.S12                  as S12                          --一级费用-证管费          
                          ,t.S13                  as S13                          --一级费用-过户费          
                          ,t.S15                  as S15                          --一级费用-结算费          
                          ,t.S16                  as S16                          --一级费用-风险基金        
                          ,t.YSJE                 as YSJE                     --应收金额
                          ,t.YSSL                 as YSSL                     --应收数量						  
                          ,t.XTBS                 as XTBS                    --账户类别 
                          ,t.CZZD1                as CZZD1	
 
 
 
 FROM         EDW_PROD.T_EDW_T05_TJGMXLS_XZB_TEMP   t
 LEFT JOIN(   SELECT      a.JYS,a.ZQDM,LEAST(a.SSRQ,NVL(b.SSRQ,99999999)) as SSRQ,GREATEST(a.TSRQ,NVL(b.TSRQ,00000000)) as TSRQ
               FROM        EDW_PROD.T_EDW_T04_TSZQDM a
			   LEFT JOIN  (SELECT * FROM EDW_PROD.T_EDW_T04_TSZQDM
			                WHERE CPLB = 5
				            AND   ZQDM LIKE '%J'
				           ) b
			   ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
			   AND          a.JYS = b.JYS
			   AND          a.BUS_DATE = b.BUS_DATE 
			  WHERE         a.CPLB IN (1,2,3,4,5,6,7) 
		      AND           a.BUS_DATE = %d{yyyyMMdd}
			)               a1
	ON      t.JYS = a1.JYS
	AND     t.ZQDM = a1.ZQDM
	LEFT JOIN  DDW_PROD.T_DDW_F04_QOT   a2
	ON         t.JYS = a2.EXG
	AND        t.ZQDM = a2.CD
	AND        a2.trd_mkt = 1
	AND        t.BUS_DATE = a2.BUS_DATE
	AND        ((((t.WTLB IN (7,9,10,15,31,65,66,18,20,47,48,19,21)) OR (t.WTLB IN (18,19) AND t.CJBH IN ('期权行权','证券转换','折算变更','份额变动','收益结转','上市流通','股份转让')) OR (t.WTLB IN (20) AND t.CJBH IN ('开户认领','手工调帐转入')))
	AND        t.CJSL > 0
	AND        t.CJJE = 0) OR (t.WTLB = 11 AND t.CJBH = '转股转入' ))
	AND        t.BUS_DATE BETWEEN a1.SSRQ AND a1.TSRQ
	LEFT JOIN (select SecuCode      as ZQDM
	                 ,IssuePrice    as FXJ
					 ,CASE WHEN PreparedListExchange = 83
                    	   THEN 'SH'
						   WHEN PreparedListExchange = 90
						   THEN 'SZ'
						   END  as JYS 
			   from  fundext.dbo_LC_AShareIPO
			   WHERE DT = '%d{yyyyMMdd}'			 			   
			   )     a3
    ON       t.JYS = a3.JYS
	AND      t.ZQDM = a3.ZQDM
	AND      ((t.WTLB IN (7,9,10,15,31,65,66,18,20,47,48,19,21)
	AND      t.CJSL > 0
	AND      t.CJJE = 0) OR (t.WTLB = 11 AND t.CJBH = '转股转入' ))
	AND      t.BUS_DATE < a1.SSRQ
    LEFT JOIN      EDW_PROD.T_EDW_T99_TWYZZZH a4
    ON             t.KHH = a4.WYZZKHH
    AND            a4.BUS_DATE = %d{yyyyMMdd}
	WHERE    t.BUS_DATE = %d{yyyyMMdd}
	AND      t.YYB NOT IN ('9999','1058','1052','1088')
	AND      SUBSTR(t.KHH,1,1) <> '9';
 -----

----------插入退市的最后一笔转出	
	 INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB(
                                    KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号                  
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额
                                   ,YSSL                    --应收数量								   
                                   ,XTBS                     --账户类别 
                                   ,CZZD1                    --操作终端	                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
SELECT                     t.KHH                  as CUST_NO                      --客户号                   
                          ,t.KHXM                 as CUST_NAME                    --客户姓名                 
                          ,t.YYB                  as BRH_NO                       --营业部编号                              
                          ,t.GDH                  as SHRHLD_NO                    --股东号                  
                          ,t.JYS                  as EXG                          --交易所                                       
                          ,t.BZDM                 as CCY_CD                       --币种代码                           
                          ,t.ZQLB                 as SEC_CGY                      --证券类别                                  
                          ,NVL(a1.SecurityCode,EDW_PROD.CODE_TRANS_ZQDM(t.JYS,t.ZQDM))    as SEC_CD                       --证券代码                 
                          ,t.ZQDM                 as SEC_CD1                      --证券代码1                
                          ,t.ZQMC                 as SEC_NAME                     --证券名称                 
                          ,NULL                   as ODR_MOD                      --委托方式                 
                          ,9999                   as ODR_CGY                      --委托类别                 
                          ,NULL                   as MTCH_NO                      --成交编号                 
                          ,t.BUS_DATE             as MTCH_DT                      --成交日期                 
                           ,t.BUS_DATE                 as JSRQ                     --结束日期
						  ,t.ZQSL                 as MTCH_QTY                     --成交数量                 
                          ,CAST(ROUND(a4.newst_prc,3) as DECIMAL(9,3))           as MTCH_PRC                     --成交价格                 
                          ,0                      as SETL_FEE                     --结算费                  
                          ,0                      as INT_PRC                      --利息价格                 
                          ,CAST(NVL(ROUND((a4.NEWST_PRC+a4.NEWST_INT*a4.NETPRC_TRD_FLG)*a4.TRD_UNIT*t.ZQSL,2),0) as DECIMAL(38,2)) as MTCH_AMT                     --成交金额                 
                          ,0                      as INT_AMT                      --利息金额                 
                          ,0                      as S1                           --实收佣金                 
                          ,0                      as S2                           --印花税                   
                          ,0                      as S3                           --过户费                   
                          ,0                      as S4                           --附加费                   
                          ,0                      as S5                           --证管费                   
                          ,0                      as S6                           --交易规费                 
                          ,0                      as S11                          --一级费用-经手费          
                          ,0                      as S12                          --一级费用-证管费          
                          ,0                      as S13                          --一级费用-过户费          
                          ,0                      as S15                          --一级费用-结算费          
                          ,0                      as S16                          --一级费用-风险基金        
                          ,0                      as RCVB_AMT                     --应收金额
                          ,0-t.ZQSL               as YSSL						  
                          ,t.XTBS                 as ACCNT_CGY                    --账户类别 
                          ,NULL                   as OPRT_CLNT							  
  FROM (SELECT t.* 
        FROM        EDW_PROD.T_EDW_T02_TZQGL       t 
        LEFT JOIN   EDW_PROD.T_EDW_T99_TRD_DATE    a2
        ON         t.BUS_DATE = a2.lst_trd_d
        AND        a2.BUS_DATE = %d{yyyyMMdd}
        AND        a2.TRD_DT = a2.NAT_DT
       WHERE      a2.trd_dt = %d{yyyyMMdd}
       )                                    t
 LEFT JOIN   (SELECT SecurityCode,ExApplyingCode,DT 
		        FROM          fundext.dbo_MF_FundArchives
		        WHERE        length(trim(exapplyingcode))>0
		        AND         securitycode <> exapplyingcode
		        AND         substr(securitycode,7,1) <> 'J'
		        AND          DT =  '%d{yyyyMMdd}'
			 )                                a1
 ON         EDW_PROD.CODE_TRANS_ZQDM(t.JYS,t.ZQDM) = a1.ExApplyingCode
 AND        SUBSTR(t.ZQDM,1,3) = '519' 
 AND        t.JYS = 'SH'
 LEFT JOIN ( SELECT      a.JYS,a.ZQDM,LEAST(a.SSRQ,NVL(b.SSRQ,99999999)) as SSRQ,GREATEST(a.TSRQ,NVL(b.TSRQ,00000000)) as TSRQ
             FROM        EDW_PROD.T_EDW_T04_TSZQDM a
			 LEFT JOIN  (SELECT * FROM EDW_PROD.T_EDW_T04_TSZQDM
			                WHERE CPLB = 5
				            AND   ZQDM LIKE '%J'
				         ) b
			 ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
			 AND          a.JYS = b.JYS
			 AND          a.BUS_DATE = b.BUS_DATE 
			 WHERE        a.CPLB IN (1,2,3,4,5,6,7) 
		     AND          a.BUS_DATE = %d{yyyyMMdd}
			)                                     a3
 ON         t.JYS = a3.JYS
 AND        NVL(a1.SecurityCode,EDW_PROD.CODE_TRANS_ZQDM(t.JYS,t.ZQDM)) = a3.ZQDM 
 LEFT JOIN  DDW_PROD.T_DDW_F04_QOT   a4
 ON         t.JYS = a4.EXG
 AND        NVL(a1.SecurityCode,EDW_PROD.CODE_TRANS_ZQDM(t.JYS,t.ZQDM)) = a4.CD
 AND        a4.trd_mkt = 1
 AND        t.BUS_DATE = a4.BUS_DATE
 WHERE     t.BUS_DATE = a3.TSRQ
 AND       t.ZQSL > 0
 AND       SUBSTR(TRIM(t.GDH),1,2) = 'C9'
 AND      t.YYB NOT IN ('4444','9999','1058','1052','1088')
 AND      SUBSTR(t.KHH,1,1) <> '9'
 ;
--插入一条因为融券负债转入98
 INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB(
                                    KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号                  
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
  								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额
                                   ,YSSL                     --								   
                                   ,XTBS                     --账户类别 
                                   ,CZZD1                    --操作终端	                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd}) 
 SELECT       t.KHH            as KHH             --客户号                                      
        ,t.KHXM          as KHXM            --客户姓名          
		,t.YYB           as YYB             --营业部编号        						  
		,t.GDH           as GDH             --股东号            						  
		,t.JYS           as JYS             --交易所            						  
		,t.BZDM          as BZDM            --币种代码          						  
		,t.ZQLB          as ZQLB            --证券类别          						  
		,t.ZQDM          as ZQDM            --证券代码          						  
		,t.ZQDM          as ZQDM1           --证券代码1         						  
		,t.ZQMC          as ZQMC            --证券名称          						  
		,NULL            as WTFS            --委托方式          						  
		,8888              as WTLB            --委托类别          						  
		,NULL            as CJBH            --成交编号          						  
		,%d{yyyyMMdd}    as CJRQ            --成交日期          						  
		,%d{yyyyMMdd}    as JSRQ                     --结束日期
		,t.RQSL-t.HQSL   as CJSL            --成交数量          						  
		,CAST(ROUND(a4.newst_prc,3) as DECIMAL(9,3))          as CJJG            --成交价格          						  
		,0               as JSJ             --结算费            						  
		,0               as LXJG            --利息价格          						  
		,CAST(NVL(ROUND((a4.NEWST_PRC+a4.NEWST_INT*a4.NETPRC_TRD_FLG)*a4.TRD_UNIT*(t.RQSL-t.HQSL),2),0) as DECIMAL(38,2))             as CJJE            --成交金额          						  
		,0             as LXJE            --利息金额          						  
		,0            as S1              --实收佣金          						  
		,0            as S2              --印花税            						  
		,0            as S3              --过户费            						  
		,0            as S4              --附加费            						  
		,0            as S5              --证管费            						  
		,0            as S6              --交易规费          						  
		,0            as S11             --一级费用-经手费   						  
		,0            as S12             --一级费用-证管费   						  
		,0            as S13             --一级费用-过户费   						  
		,0            as S15             --一级费用-结算费   						  
		,0            as S16             --一级费用-风险基金 						  
        ,0-CAST(NVL(ROUND((a4.NEWST_PRC+a4.NEWST_INT*a4.NETPRC_TRD_FLG)*a4.TRD_UNIT*(t.RQSL-t.HQSL),2),0) as DECIMAL(38,2))	      as YSJE          --应收金额 
        ,t.RQSL-t.HQSL   as YSSL            --		
        ,'JZJY'          as XTBS            --账户类别 
        ,NULL         as CZZD1           --操作终端	         
 FROM        EDW_PROD.T_EDW_T05_TXY_FZXXLS     t 
 LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE    a2
 ON         t.BUS_DATE = a2.lst_trd_d
 AND        a2.BUS_DATE = %d{yyyyMMdd}
 AND        a2.trd_dt = %d{yyyyMMdd}
 AND        a2.TRD_DT = a2.NAT_DT
 LEFT JOIN ( SELECT      a.JYS,a.ZQDM,LEAST(a.SSRQ,NVL(b.SSRQ,99999999)) as SSRQ,GREATEST(a.TSRQ,NVL(b.TSRQ,00000000)) as TSRQ
             FROM        EDW_PROD.T_EDW_T04_TSZQDM a
			 LEFT JOIN  (SELECT * FROM EDW_PROD.T_EDW_T04_TSZQDM
			                WHERE CPLB = 5
				            AND   ZQDM LIKE '%J'
				         ) b
			 ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
			 AND          a.JYS = b.JYS
			 AND          a.BUS_DATE = b.BUS_DATE 
			 WHERE        a.CPLB IN (1,2,3,4,5,6,7) 
		     AND          a.BUS_DATE = %d{yyyyMMdd}
			)                                     a3
 ON         t.JYS = a3.JYS
 AND        t.ZQDM = a3.ZQDM 
 LEFT JOIN  DDW_PROD.T_DDW_F04_QOT   a4
 ON         t.JYS = a4.EXG
 AND        t.ZQDM = a4.CD
 AND        a4.trd_mkt = 1
 AND        t.BUS_DATE = a4.BUS_DATE
 WHERE     t.BUS_DATE = a3.TSRQ
 AND       t.BUS_DATE = a2.lst_trd_d
 AND       t.RQSL-t.HQSL > 0
 AND       t.GDH NOT LIKE 'C9%'
 AND      t.YYB NOT IN ('4444','9999','1058','1052','1088')
 AND      SUBSTR(t.KHH,1,1) <> '9'
 AND      t.JYLB = 64
 ;
 
 --插入一条因为融券负债转入998
 INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB(
                                    KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号                  
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
 								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额 
                                   ,YSSL                        --								   
                                   ,XTBS                     --账户类别 
                                   ,CZZD1                    --操作终端	                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd}) 
 SELECT       t.KHH             as KHH             --客户号                                      
              ,t.KHXM           as KHXM            --客户姓名          
		      ,t.YYB            as YYB             --营业部编号        						  
		      ,NULL             as GDH             --股东号            						  
		      ,DECODE(SUBSTR(t.ZY,45,6),'510300','SH','000858','SZ',t.ZJLY)          as JYS             --交易所            						  
		      ,t.BZDM           as BZDM            --币种代码          						  
		      ,NULL             as ZQLB            --证券类别          						  
		      ,CASE WHEN LENGTH(trim(t.XGPZ)) = 0
                    THEN SUBSTR(t.ZY,45,6)
					ELSE t.XGPZ
					END         as ZQDM            --证券代码          						  
		      ,CASE WHEN LENGTH(trim(t.XGPZ)) = 0
                    THEN SUBSTR(t.ZY,45,6)
					ELSE t.XGPZ
					END         as ZQDM1           --证券代码1         						  
		      ,NULL             as ZQMC            --证券名称          						  
		      ,NULL             as WTFS            --委托方式          						  
		      ,9998              as WTLB            --委托类别          						  
		      ,NULL             as CJBH            --成交编号          						  
		      ,t.BUS_DATE       as CJRQ            --成交日期          						  
		      ,t.BUS_DATE     as JSRQ                     --结束日期
			  ,0                as CJSL            --成交数量          						  
		      ,0                as CJJG            --成交价格          						  
		      ,0                as JSJ             --结算费            						  
		      ,0                as LXJG            --利息价格          						  
		      ,t.SRJE           as CJJE            --成交金额          						  
		      ,0                as LXJE            --利息金额          						  
		      ,0                as S1              --实收佣金          						  
		      ,0                as S2              --印花税            						  
		      ,0                as S3              --过户费            						  
		      ,0                as S4              --附加费            						  
		      ,0                as S5              --证管费            						  
		      ,0                as S6              --交易规费          						  
		      ,0                as S11             --一级费用-经手费   						  
		      ,0                as S12             --一级费用-证管费   						  
		      ,0                as S13             --一级费用-过户费   						  
		      ,0                as S15             --一级费用-结算费   						  
		      ,0                as S16             --一级费用-风险基金 						  
              ,0-t.SRJE	        as YSJE          --应收金额 
              ,0                as YSSL           --			  
              ,'RZRQ'           as XTBS            --账户类别 
              ,NULL             as CZZD1           --操作终端	         
 FROM        EDW_PROD.T_EDW_T05_TZJMXLS     t 
 WHERE     t.BUS_DATE = %d{yyyyMMdd}
 AND      t.YYB NOT IN ('4444','9999','1058','1052','1088')
 AND      SUBSTR(t.KHH,1,1) <> '9'
 AND      t.YWKM = '13157'
 ;
 
 ----------HB托管转出的数据	
	 INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB(
                                    KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号                  
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额
                                   ,YSSL                    --应收数量								   
                                   ,XTBS                     --账户类别 
                                   ,CZZD1                    --操作终端	                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
SELECT                     t.KHH                  as CUST_NO                      --客户号                   
                          ,t.KHXM                 as CUST_NAME                    --客户姓名                 
                          ,t.YYB                  as BRH_NO                       --营业部编号                              
                          ,t.GDH                  as SHRHLD_NO                    --股东号                  
                          ,t.JYS                  as EXG                          --交易所                                       
                          ,t.BZDM                 as CCY_CD                       --币种代码                           
                          ,t.ZQLB                 as SEC_CGY                      --证券类别                                  
                          ,t.zqdm                 as SEC_CD                       --证券代码                 
                          ,t.ZQDM                 as SEC_CD1                      --证券代码1                
                          ,t.ZQMC                 as SEC_NAME                     --证券名称                 
                          ,NULL                   as ODR_MOD                      --委托方式                 
                          ,9999                   as ODR_CGY                      --委托类别                 
                          ,NULL                   as MTCH_NO                      --成交编号                 
                          ,t.BUS_DATE             as MTCH_DT                      --成交日期                 
                          ,t.BUS_DATE             as JSRQ                      --成交日期
						  ,t.ZQSL                 as MTCH_QTY                     --成交数量                 
                          ,CAST(ROUND(a4.newst_prc,3) as DECIMAL(9,3))           as MTCH_PRC                     --成交价格                 
                          ,0                      as SETL_FEE                     --结算费                  
                          ,0                      as INT_PRC                      --利息价格                 
                          ,CAST(NVL(ROUND((a4.NEWST_PRC+a4.NEWST_INT*a4.NETPRC_TRD_FLG)*a4.TRD_UNIT*t.ZQSL,2),0) as DECIMAL(38,2)) as MTCH_AMT                     --成交金额                 
                          ,0                      as INT_AMT                      --利息金额                 
                          ,0                      as S1                           --实收佣金                 
                          ,0                      as S2                           --印花税                   
                          ,0                      as S3                           --过户费                   
                          ,0                      as S4                           --附加费                   
                          ,0                      as S5                           --证管费                   
                          ,0                      as S6                           --交易规费                 
                          ,0                      as S11                          --一级费用-经手费          
                          ,0                      as S12                          --一级费用-证管费          
                          ,0                      as S13                          --一级费用-过户费          
                          ,0                      as S15                          --一级费用-结算费          
                          ,0                      as S16                          --一级费用-风险基金        
                          ,0                      as RCVB_AMT                     --应收金额
                          ,0-t.ZQSL               as YSSL						  
                          ,t.XTBS                 as ACCNT_CGY                    --账户类别 
                          ,NULL                   as OPRT_CLNT							  
  
 FROM        EDW_PROD.T_EDW_T02_TZQGL       t  
 LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE    a2
 ON         t.BUS_DATE = a2.lst_trd_d
 AND        a2.BUS_DATE = %d{yyyyMMdd}
 AND        a2.trd_dt = %d{yyyyMMdd}
 AND         a2.TRD_DT = a2.NAT_DT
 LEFT JOIN ( SELECT  a.KHH,a.BUS_DATE,a.ZQDM,a.jys,a.gdh,b.lst_trd_d as BUS_DATE1 
              FROM       EDW_PROD.T_EDW_T05_TJGMXLS a
              LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE b
              on   a.BUS_DATE = b.TRD_DT
              AND   b.BUS_DATE = %d{yyyyMMdd}
              AND  b.TRD_DT = b.NAT_DT			  
              where  a.WTLB = 10 
			   AND   a.JYS = 'HB'
			   AND   a.BUS_DATE = %d{yyyyMMdd}
			   AND   b.TRD_DT = b.NAT_DT
			  GROUP BY a.KHH,a.BUS_DATE,a.ZQDM,a.jys,a.gdh,b.lst_trd_d
			)                                     a3
 ON         t.JYS = a3.JYS
 AND        t.GDH = a3.GDH
 AND        t.KHH = a3.KHH
 LEFT JOIN  DDW_PROD.T_DDW_F04_QOT   a4
 ON         t.JYS = a4.EXG
 AND        t.ZQDM = a4.CD
 AND        a4.trd_mkt = 1
 AND        t.BUS_DATE = a4.BUS_DATE
 WHERE     t.BUS_DATE = a3.BUS_DATE1
 AND       t.BUS_DATE = a2.lst_trd_d
 AND       t.ZQSL > 0
 AND       t.GDH NOT LIKE 'C9%'
 AND      t.YYB NOT IN ('4444','9999','1058','1052','1088')
 AND      SUBSTR(t.KHH,1,1) <> '9'
 AND      t.JYS = 'HB'
 ;
 
 
 --------三板上市的一条转入
  INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB(
                                    KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号                  
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额
                                   ,YSSL                    --应收数量								   
                                   ,XTBS                     --账户类别 
                                   ,CZZD1                    --操作终端	                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
SELECT                     t.KHH                  as CUST_NO                      --客户号                   
                          ,t.KHXM                 as CUST_NAME                    --客户姓名                 
                          ,t.YYB                  as BRH_NO                       --营业部编号                              
                          ,t.GDH                  as SHRHLD_NO                    --股东号                  
                          ,t.JYS                  as EXG                          --交易所                                       
                          ,t.BZDM                 as CCY_CD                       --币种代码                           
                          ,t.ZQLB                 as SEC_CGY                      --证券类别                                  
                          ,t.zqdm                 as SEC_CD                       --证券代码                 
                          ,t.ZQDM                 as SEC_CD1                      --证券代码1                
                          ,t.ZQMC                 as SEC_NAME                     --证券名称                 
                          ,NULL                   as ODR_MOD                      --委托方式                 
                          ,8888                   as ODR_CGY                      --委托类别                 
                          ,NULL                   as MTCH_NO                      --成交编号                 
                          ,t.BUS_DATE             as MTCH_DT                      --成交日期                 
                          ,t.BUS_DATE             as JSRQ                      --成交日期
						  ,t.ZQSL                 as MTCH_QTY                     --成交数量                 
                          ,CAST(ROUND(a2.ZSP,3) as DECIMAL(9,3))           as MTCH_PRC                     --成交价格                 
                          ,0                      as SETL_FEE                     --结算费                  
                          ,0                      as INT_PRC                      --利息价格                 
                          ,CAST(NVL(ROUND((a2.ZSP+a2.ZXLX*a2.JJJYBZ)*a2.JYDW*t.ZQSL,2),0) as DECIMAL(38,2)) as MTCH_AMT                     --成交金额                 
                          ,0                      as INT_AMT                      --利息金额                 
                          ,0                      as S1                           --实收佣金                 
                          ,0                      as S2                           --印花税                   
                          ,0                      as S3                           --过户费                   
                          ,0                      as S4                           --附加费                   
                          ,0                      as S5                           --证管费                   
                          ,0                      as S6                           --交易规费                 
                          ,0                      as S11                          --一级费用-经手费          
                          ,0                      as S12                          --一级费用-证管费          
                          ,0                      as S13                          --一级费用-过户费          
                          ,0                      as S15                          --一级费用-结算费          
                          ,0                      as S16                          --一级费用-风险基金        
                          ,0                      as RCVB_AMT                     --应收金额
                          ,t.ZQSL                 as YSSL						  
                          ,t.XTBS                 as ACCNT_CGY                    --账户类别 
                          ,NULL                   as OPRT_CLNT							  
  
 FROM        EDW_PROD.T_EDW_T02_TZQGL       t  
 LEFT JOIN   EDW_PROD.T_EDW_T04_TSZQDM      a1
 ON          t.JYS = a1.JYS 
 AND         t.ZQDM = a1.ZQDM
 AND         a1.CPLB = 6
 AND         a1.BUS_DATE =  %d{yyyyMMdd}
 LEFT JOIN   EDW_PROD.T_EDW_T04_TZQHQ        a2
 ON          t.JYS = a2.JYS
 AND         t.ZQDM = a2.ZQDM
 AND         t.BUS_DATE = a2.BUS_DATE
 WHERE      t.BUS_DATE = %d{yyyyMMdd}
 AND        t.BUS_DATE = a1.SSRQ
 AND        a1.ZQDM IS NOT NULL
 AND        t.ZQSL > 0
 AND        t.GDH NOT LIKE 'C9%'
 AND        t.YYB NOT IN ('4444','9999','1058','1052','1088')
 AND        SUBSTR(t.KHH,1,1) <> '9'
 AND        t.JYS IN ('TA','TU')
 ;
 
 
 
 
 ------删除临时表
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_TEMP ;

---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TJGMXLS_XZB',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ; 
invalidate metadata EDW_PROD.T_EDW_T05_TJGMXLS_XZB;
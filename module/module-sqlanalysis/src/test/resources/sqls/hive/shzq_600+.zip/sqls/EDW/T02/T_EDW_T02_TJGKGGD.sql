 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:机构控股股东表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TJGKGGD; 
-------插入数据开始-----------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TJGKGGD(
                                    JGKGID                              --机构控股主键                             
                                   ,KHH                                 --客户号                                
                                   ,KZRMC                               --控制人名称                              
                                   ,KZRLX                               --控制人类型                              
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,ZJQSRQ                              --证件起始日期                             
                                   ,ZJJZRQ                              --证件截止日期                             
                                   ,GJDM                                --国籍代码                               
                                   ,LXDH                                --联系电话                               
                                   ,MOBILE                              --手机                                 
                                   ,EMAIL                               --EMAIL                              
                                   ,ZRCDFS                              --责任承担方式                             
                                   ,DJRQ                                --登记日期                               
                                   ,BDRQ                                --变动日期    
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.ID                                  as JGKGID                              --ID                                  
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KZRMC                               as KZRMC                               --控制人名称                               
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.KZRLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as KZRLX                               --控制人类型                               
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,t.ZJQSRQ                              as ZJQSRQ                              --证件起始日期                              
                                   ,t.ZJJZRQ                              as ZJJZRQ                              --证件截止日期                              
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.GJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as GJDM                                --国籍                                  
                                   ,t.DH                                  as LXDH                                --联系电话                                
                                   ,t.SJ                                  as MOBILE                              --手机                                  
                                   ,t.EMAIL                               as EMAIL                               --EMAIL                               
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZRCDFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as ZRCDFS                              --责任承担方式                              
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期   
                                   ,'YGT_GT'							  as XTBS
 FROM           YGTCX.CIF_TJGKGGD                      t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'KZRLX'
 AND            t1.YXT = 'YGT_GT'
 AND            t1.YDM = CAST(t.KZRLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2
 ON             t2.DMLX = 'ZJLBDM'
 AND            t2.YXT = 'YGT_GT'
 AND            t2.YDM = CAST(t.ZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'GJDM'
 AND            t3.YXT = 'YGT'
 AND            t3.YDM = CAST(t.GJ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4
 ON             t4.DMLX = 'ZRCDFS'
 AND            t4.YXT = 'YGT_GT'
 AND            t4.YDM = CAST(t.ZRCDFS AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TJGKGGD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TJGKGGD;

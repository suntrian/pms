------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:组合基金比例明细信息表                                                                    */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2018-11-30

INSERT OVERWRITE DDW_PROD.T_DDW_PROD_FND_COMBO_RTO_DTL_INFO
(
                   GROUP_ID
                  ,GROUP_NM
                  ,FND_SEQ
                  ,FND_CD
                  ,FND_NM
                  ,FND_CGY_CD_LEV1
                  ,FND_CGY_NM_LEV1
                  ,FND_PCT	  
) PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT         CAST(T.GROUP_ID AS STRING)     AS GROUP_ID
              ,T1.GROUP_NAME                  AS GROUP_NM
              ,CAST(T2.FUND_SEQ AS STRING)    AS FND_SEQ
			  ,T.fund_code                    AS FND_CD
			  ,T3.FUND_ABBR                   AS FND_NM
			  ,T3.FIRST_CATEGORY              AS FND_CGY_CD_LEV1
			  ,T3.FIRST_CATEGORY_NAME         AS FND_CGY_NM_LEV1
			  ,CAST(T.SHARE AS DECIMAL(38,6)) AS FND_PCT
FROM          EDW_PROD.T_EDW_T04_GROUP_NV_FUND  T
LEFT JOIN     (SELECT DISTINCT GROUP_ID,GROUP_NAME,BUS_DATE 
              FROM EDW_PROD.T_EDW_T04_GROUP_INFO)     T1
ON            T.GROUP_ID = T1.GROUP_ID
AND           T.BUS_DATE = T1.BUS_DATE
LEFT JOIN     (SELECT  DISTINCT GROUP_ID,FUND_SEQ,fund_code,BUS_DATE
               FROM     EDW_PROD.T_EDW_T04_GROUP_FUND_REL
              )    T2
ON            T.GROUP_ID = T2.GROUP_ID
AND           T.fund_code = T2.fund_code
AND           T.BUS_DATE = T2.BUS_DATE
LEFT JOIN     (SELECT DISTINCT fund_code,FUND_ABBR,FIRST_CATEGORY,FIRST_CATEGORY_NAME,BUS_DATE
               FROM EDW_PROD.T_EDW_T04_FUND_INFO) T3
ON            T2.fund_code = T3.fund_code
AND           T2.BUS_DATE  = T3.BUS_DATE
;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PROD_FND_COMBO_RTO_DTL_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PROD_FND_COMBO_RTO_DTL_INFO ;
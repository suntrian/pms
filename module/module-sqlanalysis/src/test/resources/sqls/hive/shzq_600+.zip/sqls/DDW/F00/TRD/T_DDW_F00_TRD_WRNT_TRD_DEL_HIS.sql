 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:期权交易明细历史表                                                         */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */ 
  


--------------插入数据-------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
(
                 EVNT_SEQNBR                --事件序号	      
                ,DLV_INF_CGY                --交割资料类别	       
				,ODR_NO                     --委托合同号	      
				,PRT_ODR_NO                 --申报委托号	      
                ,CUST_NO                    --客户号	          
                ,CUST_NAME                  --客户姓名	      
                ,SHRHLD_NO                  --股东号	          
                ,SHRHLD_NAME                --股东姓名	      
                ,EXG                        --交易所	          
                ,CCY_CD                     --结算币种	      
                ,ODR_MOD                    --委托方式	      
				,BRH_NO                     --营业部	          
                ,WRNT_CTC_CD                --期权合约代码	  
				,WRNT_CTC_SHRTNM            --期权合约简称	  
				,WRNT_SEC_TP                --标的证券品种	  
                ,WRNT_TP                    --期权类型	      
				,WRNT_BS_DRCT               --期权买卖方向	  
				,WRNT_OPN_CP_FLG            --期权开平仓标志	  
                ,WRNT_CVD_LABL              --备兑标签	      
                ,WRNT_SRCPTY                --期权发起方	      
				,MTCH_DT                    --成交日期	      
				,MTCH_QTY                   --成交数量	      
                ,SEC_CD                     --证券代码          
                ,SEC_QTY                    --证券数量          
                ,MTCH_PRC                   --成交价格	      
				,MTCH_AMT                   --成交金额	      
				,S1                         --实收佣金	      
                ,S2                         --印花税	          
				,S3                         --过户费	          
				,S4                         --附加费     	      
				,S5                         --结算费	          
				,S6                         --交易规费	      
				,RCVB_AMT                   --实收金额	      
                ,S11                        --一级费用_经手费	  
                ,S12                        --一级费用_证管费	  
                ,S13                        --一级费用_过户费	  
                ,S15                        --一级费用_结算费	  
                ,S16                        --一级费用_风险基金
				,END_DATE                   --结束日期
                ,OPRT_CLNT                  --操作终端  
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT             t.SEQNO	                as EVNT_SEQNBR                --事件序号	      
                   ,t.JGZLLB	            as DLV_INF_CGY                --交割资料类别	            
                   ,t.WTH	                as ODR_NO                     --委托合同号	      
                   ,t.SBWTH	                as PRT_ODR_NO                 --申报委托号	      
                   ,t.KHH	                as CUST_NO                    --客户号	          
                   ,t.KHXM	                as CUST_NAME                    --客户姓名	      
                   ,t.GDH  	                as SHRHLD_NO                  --股东号	          
                   ,t.GDXM	                as SHRHLD_NAME                --股东姓名	      
                   ,t.JYS	                as EXG                        --交易所	          
                   ,t.JSBZDM	            as CCY_CD                     --结算币种	      
                   ,t.WTFS	                as ODR_MOD                    --委托方式	      
                   ,t.YYB	                as BRH_NO                     --营业部	          
                   ,t.HYDM	                as WRNT_CTC_CD                --期权合约代码	  
                   ,t.HYMC	                as WRNT_CTC_SHRTNM            --期权合约简称	  
                   ,t.SOP_BDZQPZ	        as WRNT_SEC_TP                --标的证券品种	  
                   ,t.SOP_QQLX	            as WRNT_TP                    --期权类型	      
                   ,t.SOP_MMFX	            as WRNT_BS_DRCT               --期权买卖方向	  
                   ,t.SOP_KPCBZ	            as WRNT_OPN_CP_FLG            --期权开平仓标志	  
                   ,t.SOP_BDBQ	            as WRNT_CVD_LABL              --备兑标签	      
                   ,t.SOP_FQF	            as WRNT_SRCPTY                --期权发起方	      
                   ,t.CJRQ	                as MTCH_DT                    --成交日期	      
                   ,NVL(t.CJSL,0)	        as MTCH_QTY                   --成交数量	      
                   ,t.ZQDM                  as SEC_CD                     --证券代码          
                   ,ROUND(CASE WHEN t.CJJG = 0
							   THEN 0
							   ELSE t.CJJE/t.CJJG
							   END,2 
						  )                 as SEC_QTY                    --证券数量          
                   ,NVL(t.CJJG,0)	        as MTCH_PRC                   --成交价格	      
                   ,NVL(t.CJJE,0)	        as MTCH_AMT                   --成交金额	      
                   ,NVL(t.S1,0)	            as S1                         --实收佣金	      
                   ,NVL(t.YHS,0)	        as S2                         --印花税	          
                   ,NVL(t.S3,0)	            as S3                         --过户费	          
                   ,NVL(t.S4,0)	            as S4                         --附加费     	      
                   ,NVL(t.S5,0)       	    as S5                         --结算费	          
                   ,NVL(t.S6,0)	            as S6                         --交易规费	      
                   ,NVL(t.YSJE,0)	        as RCVB_AMT                   --实收金额	      
                   ,NVL(t.S11,0)	        as S11                        --一级费用_经手费	  
                   ,NVL(t.S12,0)	        as S12                        --一级费用_证管费	  
                   ,NVL(t.S13,0)	        as S13                        --一级费用_过户费	  
				   ,NVL(t.S15,0)            as S15                        --一级费用_结算费	  
				   ,NVL(t.S16,0)            as S16                        --一级费用_风险基金
				   ,t.JSRQ                  as END_DATE	
				   ,t.CZZD1                 as OPRT_CLNT                  --操作终端  
 FROM          EDW_PROD.T_EDW_T05_TSO_JGMXLS                                                t
 WHERE         t.BUS_DATE =  %d{yyyyMMdd} 			   
 ;				   				  				   
---------------- 插入数据结束 -----------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_TRD_WRNT_TRD_DEL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS ;
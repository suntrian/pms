--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:分级基金代码                                                                           */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */ 


 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TFXJJDM
 (
             JYS               --交易所
            ,ZQDM              --证券代码
            ,JJDM              --基金代码
            ,JJJC              --基金名称
            ,FSRQ              --发生日期
            ,CFZT              --
            ,JJZT              --基金状态
            ,ZHZT              --账户状态
            ,JJJZ              --基金净值
            ,LJJZ              --累计净值
            ,CFBL              --
            ,ZDHBSL            --
            ,ZDCFSL            --
            ,TADM              --TA代码
            ,XGRQ              --修改日期
            ,FXRDM             --
            ,NOTE              --备注
			,JJFL              --基金分类
            ,XTBS              --系统标识 
 ) 
 PARTITION( bus_date = %d{yyyyMMdd}) 
 SELECT      t.JYS      as JYS            --交易所
            ,t.ZQDM     as ZQDM           --证券代码
            ,t.JJDM     as JJDM           --基金代码
            ,t.JJJC     as JJJC           --基金名称
            ,t.FSRQ     as FSRQ           --发生日期
            ,t.CFZT     as CFZT           --
            ,t.JJZT     as JJZT           --基金状态
            ,t.ZHZT     as ZHZT           --账户状态
            ,t.JJJZ     as JJJZ           --基金净值
            ,t.LJJZ     as LJJZ           --累计净值
            ,t.CFBL     as CFBL           --
            ,t.ZDHBSL   as ZDHBSL         --
            ,t.ZDCFSL   as ZDCFSL         --
            ,t.TADM     as TADM           --TA代码
            ,t.XGRQ     as XGRQ           --修改日期
            ,t.FXRDM    as FXRDM          --
            ,t.NOTE     as NOTE           --备注
			,ROW_NUMBER() OVER(PARTITION BY t.ZQDM ORDER BY t.JJDM)  as JJFL
            ,'JZJY'     as XTBS           --系统标识 
 FROM  JZJYCX.SECURITIES_TJJHQ   t 
 WHERE  DT = '%d{yyyyMMdd}'
 AND    t.ZQDM < > t.JJDM
 UNION ALL
  SELECT      t.JYS      as JYS            --交易所
            ,t.ZQDM     as ZQDM           --证券代码
            ,t.JJDM     as JJDM           --基金代码
            ,t.JJJC     as JJJC           --基金名称
            ,t.FSRQ     as FSRQ           --发生日期
            ,t.CFZT     as CFZT           --
            ,t.JJZT     as JJZT           --基金状态
            ,t.ZHZT     as ZHZT           --账户状态
            ,t.JJJZ     as JJJZ           --基金净值
            ,t.LJJZ     as LJJZ           --累计净值
            ,t.CFBL     as CFBL           --
            ,t.ZDHBSL   as ZDHBSL         --
            ,t.ZDCFSL   as ZDCFSL         --
            ,t.TADM     as TADM           --TA代码
            ,t.XGRQ     as XGRQ           --修改日期
            ,t.FXRDM    as FXRDM          --
            ,t.NOTE     as NOTE           --备注
			,0          as JJFL
            ,'JZJY'     as XTBS           --系统标识 
 FROM  JZJYCX.SECURITIES_TJJHQ   t 
 WHERE  DT = '%d{yyyyMMdd}'
 AND    t.ZQDM = t.JJDM
 ;
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TFXJJDM',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
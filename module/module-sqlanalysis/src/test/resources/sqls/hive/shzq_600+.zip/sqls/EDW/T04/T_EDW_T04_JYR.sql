--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:交易日表                                                                             */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
  TRUNCATE TABLE EDW_PROD.T_EDW_T04_JYR; 
------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T04_JYR
(
                                    RQ                                  --日期                                 
                                   ,ZQJYRBS_SH                          --沪A证券交易日标识                          
                                   ,ZQJYRBS_SZ                          --深A证券交易日标识                          
                                   ,ZQJYRBS_HB                          --沪B证券交易日标识                          
                                   ,ZQJYRBS_SB                          --深B证券交易日标识                          
                                   ,ZQJYRBS_TA                          --转A证券交易日标识                          
                                   ,ZQJYRBS_TU                          --转U证券交易日标识                          
                                   ,ZQJYRBS_HK                          --沪港通证券交易日标识                         
                                   ,ZQJYRBS_SK                          --深港通证券交易日标识    
								   ,JJJYRBS                             --基金交易日标识
								   ,JRCPJYRBS                           --金融产品交易日标识
                                   ,XTBS								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT                              a1.RQ                  as RQ
                                    ,a1.ZQJYRBS_SH          as ZQJYRBS_SH
 									,a1.ZQJYRBS_SZ          as ZQJYRBS_SZ
 									,a1.ZQJYRBS_HB          as ZQJYRBS_HB
 									,a1.ZQJYRBS_SB          as ZQJYRBS_SB
 									,a1.ZQJYRBS_TA          as ZQJYRBS_TA
 									,a1.ZQJYRBS_TU          as ZQJYRBS_TU
 									,a1.ZQJYRBS_HK          as ZQJYRBS_HK
 									,a1.ZQJYRBS_SK          as ZQJYRBS_SK
 									,t1.JYRBS               as JJJYRBS
 									,t2.JYRBS               as JRCPJYRBS
 									,'JZJY'                 as XTBS
 FROM				(SELECT 
 								 t.RQ                                                             as RQ                                     --日期                                  
 								,MAX(CASE WHEN t.JYS = 'SH'    THEN t.JYRBS END)                  as ZQJYRBS_SH                             --                                    
 								,MAX(CASE WHEN t.JYS = 'SZ'    THEN t.JYRBS END)                  as ZQJYRBS_SZ                         	--                                    
 								,MAX(CASE WHEN t.JYS = 'HB'    THEN t.JYRBS END)                  as ZQJYRBS_HB                             --                                    
 								,MAX(CASE WHEN t.JYS = 'SB'    THEN t.JYRBS END)                  as ZQJYRBS_SB                             --                                    
 								,MAX(CASE WHEN t.JYS = 'TA'    THEN t.JYRBS END)                  as ZQJYRBS_TA                             --                                    
 								,MAX(CASE WHEN t.JYS = 'TU'    THEN t.JYRBS END)                  as ZQJYRBS_TU                             --                                    
 								,MAX(CASE WHEN t.JYS = 'HK'    THEN t.JYRBS END)                  as ZQJYRBS_HK                             --                                    
 								,MAX(CASE WHEN t.JYS = 'SK'    THEN t.JYRBS END)                  as ZQJYRBS_SK  
                                ,t.DT								
					FROM JZJYCX.SECURITIES_TJYR t
					GROUP BY t.RQ,t.DT
					ORDER BY t.RQ,t.DT
					) 												a1
 LEFT JOIN 			JZJYCX.OFS_TOF_JYR 								t1
 ON 				a1.RQ = t1.RQ
 AND                a1.DT = t1.DT
 LEFT JOIN 			JZJYCX.JRCP_TJRCP_JYR 							t2
 ON 				a1.RQ = t2.RQ
 AND                a1.DT = t2.DT
 WHERE 				a1.DT = '%d{yyyyMMdd}'
;
-------插入数据结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_JYR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;




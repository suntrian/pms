 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:境外客户资金表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2019-02-13                                                                        */ 

 
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_FRGN_CUST_CPTL_TEMP;
 CREATE TABLE DDW_PROD.T_DDW_PRT_FRGN_CUST_CPTL_TEMP as
  SELECT  t.CITY_CD
       ,b1.CITY_CD_NAME
	   ,t.BRH_NO
	   ,t.BRH_NAME
	   ,t.CUST_NO
	   ,t.CUST_NAME
	   
FROM        DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
INNER JOIN  DDW_PROD.T_DDW_INR_ORG_BRH  a1
ON          t.BRH_NO = a1.BRH_NO
AND         a1.BUS_DATE = %d{yyyyMMdd}
INNER JOIN( SELECT CUST_NO  
            FROM DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO 
			WHERE SHRHLD_OPNAC_DT <= %d{yyyyMMdd} 
			AND BUS_DATE = %d{yyyyMMdd} 
			AND ((SHRHLD_NO LIKE 'C90%' 
			AND EXG = 'HB') 
			OR (SHRHLD_NO LIKE '270%' 
			    AND EXG = 'SB')
			OR (SHRHLD_NO LIKE '47%' 
			    AND EXG = 'TU'))
			GROUP BY CUST_NO
			
			)                        a2
ON          t.CUST_NO = a2.CUST_NO
			
LEFT JOIN( SELECT CUST_NO  
            FROM DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO 
			WHERE SHRHLD_OPNAC_DT <= %d{yyyyMMdd} 
			AND BUS_DATE = %d{yyyyMMdd} 
			AND ((SHRHLD_NO LIKE 'C99%' 
			AND EXG = 'HB') 
			OR (SUBSTR(SHRHLD_NO,1,3) IN ('287','487')
			    AND EXG = 'SB'))
			GROUP BY CUST_NO
			
			)                        a3
ON          t.CUST_NO = a3.CUST_NO
LEFT JOIN   DDW_PROD.V_CITY_CD             b1
ON          t.CITY_CD = b1.CITY_CD
WHERE  t.BUS_DATE = %d{yyyyMMdd}
AND    t.ORDI_CUST_STAT < > '3'
AND    NVL(t.CITY_CD,'0') NOT IN ('0','156') 
AND    a3.CUST_NO IS NULL ;  


 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_FRGN_CUST_CPTL_TEMP1;
 CREATE TABLE DDW_PROD.T_DDW_PRT_FRGN_CUST_CPTL_TEMP1 as
SELECT  t.KHH   as CUST_NO
       ,SUM(DECODE(t.BZDM,'RMB',t.ZHYE,0)) as CPTL_BAL_RMB
	   ,SUM(DECODE(t.BZDM,'HKD',t.ZHYE,0)) as CPTL_BAL_HKD
       ,SUM(DECODE(t.BZDM,'USD',t.ZHYE,0)) as CPTL_BAL_USD
	   ,SUM(DECODE(t.BZDM,'RMB',NVL(a1.CPTL_CHG,0),0))    as CPTL_CHG_RMB
	   ,SUM(DECODE(t.BZDM,'HKD',NVL(a1.CPTL_CHG,0),0))    as CPTL_CHG_HKD
       ,SUM(DECODE(t.BZDM,'USD',NVL(a1.CPTL_CHG,0),0))    as CPTL_CHG_USD
	   
	   ,SUM(DECODE(t.BZDM,'RMB',t.LXJS+t.ZHYE*(EDW_PROD.G_DATE_COMPARE_DATE(CAST(a2.NAT_DT AS STRING),'yyyyMMdd',CAST(t.BDRQ AS STRING),'yyyyMMdd')+1),0))    as INT_CDN_NUM_RMB
	   ,SUM(DECODE(t.BZDM,'HKD',t.LXJS+t.ZHYE*(EDW_PROD.G_DATE_COMPARE_DATE(CAST(a2.NAT_DT AS STRING),'yyyyMMdd',CAST(t.BDRQ AS STRING),'yyyyMMdd')+1),0))    as INT_CDN_NUM_HKD
       ,SUM(DECODE(t.BZDM,'USD',t.LXJS+t.ZHYE*(EDW_PROD.G_DATE_COMPARE_DATE(CAST(a2.NAT_DT AS STRING),'yyyyMMdd',CAST(t.BDRQ AS STRING),'yyyyMMdd')+1),0))    as INT_CDN_NUM_USD
	   
	   ,SUM(DECODE(t.BZDM,'RMB',(t.LXJS+t.ZHYE*(EDW_PROD.G_DATE_COMPARE_DATE(CAST(a2.NAT_DT AS STRING),'yyyyMMdd',CAST(t.BDRQ AS STRING),'yyyyMMdd')+1))*0.0035/365,0))    as PRDCT_INT_RMB
	   ,SUM(DECODE(t.BZDM,'HKD',(t.LXJS+t.ZHYE*(EDW_PROD.G_DATE_COMPARE_DATE(CAST(a2.NAT_DT AS STRING),'yyyyMMdd',CAST(t.BDRQ AS STRING),'yyyyMMdd')+1))*0.0001/365,0))    as PRDCT_INT_HKD
       ,SUM(DECODE(t.BZDM,'USD',(t.LXJS+t.ZHYE*(EDW_PROD.G_DATE_COMPARE_DATE(CAST(a2.NAT_DT AS STRING),'yyyyMMdd',CAST(t.BDRQ AS STRING),'yyyyMMdd')+1))*0.0005/365,0))    as PRDCT_INT_USD

	   
FROM   EDW_PROD.T_EDW_T02_TZJZH  t 
LEFT JOIN (SELECT CNTR_CPTL_ACCNT
                 ,CCY_CD
				 ,CUST_NO
                 ,SUM(INCM_AMT-PAY_AMT) as CPTL_CHG 
           FROM DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS 
           WHERE SUBSTR(BIZ_SBJ,1,3) = '105'
		   AND   SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		   GROUP BY CNTR_CPTL_ACCNT,CCY_CD,CUST_NO
		   )                     a1
ON         t.KHH = a1.CUST_NO
AND        t.GTZJZH = a1.CNTR_CPTL_ACCNT
AND        t.BZDM = a1.CCY_CD
LEFT JOIN (SELECT SUBSTR(CAST(NAT_DT as STRING),1,6) as MON
                  ,MAX(NAT_DT) as NAT_DT
            FROM EDW_PROD.T_EDW_T99_TRD_DATE
			WHERE BUS_DATE = %d{yyyyMMdd}
			AND NAT_DT >= 20190101
			GROUP BY  MON
			)          a2
ON    SUBSTR(CAST(t.BUS_DATE  as STRING),1,6) = a2.MON
WHERE t.BUS_DATE = %d{yyyyMMdd}
GROUP BY CUST_NO ;



 INSERT OVERWRITE DDW_PROD.T_DDW_PRT_FRGN_CUST_CPTL
 (
                                    CITY_CD                --国籍代码
                                  , CITY_CD_NAME           --国籍名称
                                  , BRH_NO                 --营业部
                                  , BRH_NAME               --营业部名称
                                  , CUST_NO                --客户号
                                  , CUST_NAME              --客户姓名
                                  , CPTL_BAL_RMB           --资金余额(人民币)
                                  , CPTL_CHG_RMB           --资金变动(人民币)
								  , INT_CDN_NUM_RMB        --利息积数(人民币)
                                  , PRDCT_INT_RMB          --预计利息(人民币)
								  , CPTL_BAL_HKD           --资金余额(港币)
								  , CPTL_CHG_HKD           --资金变动(港币)
								  , INT_CDN_NUM_HKD        --利息积数(港币)
								  , PRDCT_INT_HKD          --预计利息(港币)      
								  , CPTL_BAL_USD           --资金余额(美元)
								  , CPTL_CHG_USD           --资金变动(美元)
								  , INT_CDN_NUM_USD        --利息积数(美元)
								  , PRDCT_INT_USD          --预计利息(美元)
                                
 ) 
 PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT                             t.CITY_CD                                 --国籍代码
                                  , t.CITY_CD_NAME                            --国籍名称
                                  , t.BRH_NO                                  --营业部
                                  , t.BRH_NAME                                --营业部名称
                                  , t.CUST_NO                                 --客户号
                                  , t.CUST_NAME                               --客户姓名
                                  , ROUND(NVL(a1.CPTL_BAL_RMB,0),2)           --资金余额(人民币)
                                  , ROUND(NVL(a1.CPTL_CHG_RMB,0),2)           --资金变动(人民币)
								  , ROUND(NVL(a1.INT_CDN_NUM_RMB,0),2)        --利息积数(人民币)
                                  , ROUND(NVL(a1.PRDCT_INT_RMB,0),2)          --预计利息(人民币)
								  , ROUND(NVL(a1.CPTL_BAL_HKD,0),2)           --资金余额(港币)
								  , ROUND(NVL(a1.CPTL_CHG_HKD,0),2)           --资金变动(港币)
								  , ROUND(NVL(a1.INT_CDN_NUM_HKD,0),2)        --利息积数(港币)
								  , ROUND(NVL(a1.PRDCT_INT_HKD,0),2)          --预计利息(港币)      
								  , ROUND(NVL(a1.CPTL_BAL_USD,0),2)           --资金余额(美元)
								  , ROUND(NVL(a1.CPTL_CHG_USD,0),2)           --资金变动(美元)
								  , ROUND(NVL(a1.INT_CDN_NUM_USD,0),2)        --利息积数(美元)
								  , ROUND(NVL(a1.PRDCT_INT_USD,0),2)          --预计利息(美元)
 FROM      DDW_PROD.T_DDW_PRT_FRGN_CUST_CPTL_TEMP    t
 LEFT JOIN DDW_PROD.T_DDW_PRT_FRGN_CUST_CPTL_TEMP1   a1
 ON        t.CUST_NO = a1.CUST_NO ;
 
 ----删除临时表
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_FRGN_CUST_CPTL_TEMP;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_FRGN_CUST_CPTL_TEMP1;
  
  ---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_DDW_PRT_FRGN_CUST_CPTL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_FRGN_CUST_CPTL ;
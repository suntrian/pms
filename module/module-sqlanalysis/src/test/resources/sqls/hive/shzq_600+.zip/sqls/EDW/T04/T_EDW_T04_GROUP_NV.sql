------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:组合净值及日涨跌幅表                                                                    */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

 
 --清除数据
 --TRUNCATE TABLE EDW_PROD.T_EDW_T04_GROUP_NV;
 
 ------插入数据
  INSERT OVERWRITE EDW_PROD.T_EDW_T04_GROUP_NV
(
              GROUP_ID               --组合id
		     ,GROUP_NV               --组合净值
		     ,GROUP_NV_DAILY_GROWTH  --净值日涨跌幅
		     ,UPDATE_TIME          
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     
              GROUP_ID               --组合id
		     ,GROUP_NV               --组合净值
		     ,GROUP_NV_DAILY_GROWTH  --净值日涨跌幅
		     ,UPDATE_TIME 
FROM JJLC.GROUP_NV
WHERE DT = '%d{yyyyMMdd}';

 ----删除临时表

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_GROUP_NV',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;



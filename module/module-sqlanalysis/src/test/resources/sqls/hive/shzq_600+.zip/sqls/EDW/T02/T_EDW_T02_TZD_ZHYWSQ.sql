 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:中登账户业务申请表                                                                */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
---插入数据开始------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZD_ZHYWSQ
(
                                    TZD_ZHYWSQ_ID                       --中登账户业务申请主键                         
                                   ,SQBH                                --申请编号                               
                                   ,SQRQ                                --申请日期                               
                                   ,SQSJ                                --申请时间                               
                                   ,ZD_JYS                              --中登交易所                                
                                   ,YWLB                                --中登账户业务类别                               
                                   ,CZLB                                --操作类别                               
                                   ,CDBZ                                --撤单标志                               
                                   ,YYB                                 --营业部                                
                                   ,SQGY                                --申请柜员                               
                                   ,SHGY                                --审核柜员                               
                                   ,SHYJ                                --审核意见                               
                                   ,KHJGDM                              --开户机构代码                             
                                   ,KHWDDM                              --开户网点代码                             
                                   ,KHH                                 --客户号                                
                                   ,CLBZ                                --处理标志                               
                                   ,JGSM                                --结果说明                               
                                   ,YWPZBS                              --业务凭证报送                             
                                   ,SBRQ                                --申报日期                               
                                   ,SBSJ                                --申报时间                               
                                   ,YWPH                                --业务批号                               
                                   ,WF_ID                               --WF_ID                              
                                   ,YMTH                                --一码通账户号码                            
                                   ,KHMC                                --客户名称                               
                                   ,KHLB                                --客户类别                               
                                   ,GJDM                                --国籍代码                               
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,ZJJZRQ                              --证件截止日期                             
                                   ,ZJDZ                                --证件地址                               
                                   ,FZZJLBDM                            --辅助证件类别代码                           
                                   ,FZZJBH                              --辅助证件编号                             
                                   ,FZZJJZRQ                            --辅助证件截止日期                           
                                   ,FZZJDZ                              --辅助证件地址                             
                                   ,KH_KHFS                             --开户_开户方式                            
                                   ,CSRQ                                --出生日期                               
                                   ,XBDM                                --性别代码                               
                                   ,XLDM                                --学历代码                               
                                   ,ZYDM                                --职业代码                               
                                   ,MZDM                                --民族代码                               
                                   ,YGT_JGLB                            --一柜通机构类别                            
                                   ,ZBSXDM                              --资本属性代码                             
                                   ,GYSX                                --国有属性                               
                                   ,JGJC                                --机构简称                               
                                   ,YWMC                                --英文名称                               
                                   ,GSWZ                                --公司网址                               
                                   ,FRDBXM                              --法定代表人姓名                            
                                   ,FRDBZJLBDM                          --法定代表人证件类别                          
                                   ,FRDBZJBH                            --法定代表人证件编号                          
                                   ,LXRXM                               --联系人姓名                              
                                   ,LXRZJLBDM                           --联系人证件类别代码                          
                                   ,LXRZJBH                             --联系人证件编号                            
                                   ,YDDH                                --移动电话                               
                                   ,GDDH                                --固定电话                               
                                   ,CZHM                                --传真号码                               
                                   ,LXDZ                                --联系地址                               
                                   ,LXYB                                --联系邮编                               
                                   ,DZYX                                --电子邮箱                               
                                   ,DXFWBS                              --开通短信服务标识                           
                                   ,WLFWBS                              --开通网络服务标识                           
                                   ,WLFWMM                              --网络服务密码                             
                                   ,ZDZH_ZHLB                           --中登账户账户类别                           
                                   ,ZQZH                                --证券账号                               
                                   ,XYMTH                               --新一码通账户号码                           
                                   ,XZJLBDM                             --新证件类别代码                            
                                   ,XZJBH                               --新证件编号                              
                                   ,PHZQZH                              --配号证券账号                             
                                   ,JSCYR                               --结算参与人                              
                                   ,XWH                                 --交易单元                               
                                   ,YYBBM                               --营业部编码                              
                                   ,ZD_SDXLB                            --中登适当性类别                            
                                   ,QYLB2                               --签约类别                               
                                   ,QYRQ                                --签约日期                               
                                   ,ZRCDFS                              --责任承担方式                             
                                   ,JCXZLB                              --解除限制类别                             
                                   ,BYZD1                               --保留字段1                              
                                   ,BYZD2                               --保留字段2                              
                                   ,BYZD3                               --保留字段3                              
                                   ,YWQQID                              --业务请求主键                             
                                   ,YWQQCLID                            --业务请求处理主键                           
                                   ,CLZT                                --CLZT                               
                                   ,CLCX                                --CLCX                               
                                   ,CPJC                                --产品简称                               
                                   ,CPDQR                               --CPDQR                              
                                   ,CPLB                                --产品类别                               
                                   ,GLRMC                             --关联人名称                              
                                   ,GLRZJLB                             --关联人证件类别                            
                                   ,GLRZJBH                             --关联人证件编号                            
                                   ,TGRMC                               --托管人名称                              
                                   ,TGRZJLBDM                           --托管人证件类别代码                          
                                   ,TGRZJBH                             --托管人证件编号 
                                   ,XTBS								   
) 
PARTITION( bus_date =  %d{yyyyMMdd})	
SELECT 
                                    t.ID                                  as TZD_ZHYWSQ_ID                       --ID                                  
                                   ,t.SQBH                                as SQBH                                --申请编号                                
                                   ,t.SQRQ                                as SQRQ                                --申请日期                                
                                   ,t.SQSJ                                as SQSJ                                --申请时间                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as JYS                                 --交易所                                 
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.YWLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZDZH_YWLB                                --业务类别                                
                                   ,t.CZLB                                as CZLB                                --操作类别                                
                                   ,t.CDBZ                                as CDBZ                                --撤单标志                                
                                   ,CAST(COALESCE(t24.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                 as YYB                                 --营业部                                 
                                   ,t.SQGY                                as SQGY                                --申请柜员                                
                                   ,t.SHGY                                as SHGY                                --审核柜员                                
                                   ,t.SHYJ                                as SHYJ                                --审核意见                                
                                   ,t.KHJGDM                              as KHJGDM                              --开户机构代码                              
                                   ,t.KHWDDM                              as KHWDDM                              --开户网点代码                              
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.CLBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as CLBZ                                --处理标志                                
                                   ,t.JGSM                                as JGSM                                --结果说明                                
                                   ,t.YWPZBS                              as YWPZBS                              --业务凭证报送                              
                                   ,t.SBRQ                                as SBRQ                                --申报日期                                
                                   ,t.SBSJ                                as SBSJ                                --申报时间                                
                                   ,t.YWPH                                as YWPH                                --业务批号                                
                                   ,t.WF_ID                               as WF_ID                               --                                    
                                   ,t.YMTH                                as YMTH                                --一码通账户号码                             
                                   ,t.KHMC                                as KHMC                                --客户名称                                
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as KHLB                                --客户类别                                
                                   ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.GJDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as GJDM                                --国籍代码                                
                                   ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,t.ZJJZRQ                              as ZJJZRQ                              --证件截止日期                              
                                   ,t.ZJDZ                                as ZJDZ                                --证件地址                                
                                   ,CAST(COALESCE(t7.MBDM,NULLIF(CONCAT('ERR',CAST(t.FZZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as FZZJLBDM                            --辅助证件类别                              
                                   ,t.FZZJBH                              as FZZJBH                              --辅助证件编号                              
                                   ,t.FZZJJZRQ                            as FZZJJZRQ                            --辅助证件截止日期                            
                                   ,t.FZZJDZ                              as FZZJDZ                              --辅助证件地址                              
                                   ,CAST(COALESCE(t8.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as KH_KHFS                             --开户方式                                
                                   ,t.CSRQ                                as CSRQ                                --出生日期                                
                                   ,CAST(COALESCE(t9.MBDM,NULLIF(CONCAT('ERR',CAST(t.XB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as XBDM                                --性别                                  
                                   ,CAST(COALESCE(t10.MBDM,NULLIF(CONCAT('ERR',CAST(t.XLDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as XLDM                                --学历代码                                
                                   ,CAST(COALESCE(t11.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZYXZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZYDM                                --职业性质                                
                                   ,CAST(COALESCE(t12.MBDM,NULLIF(CONCAT('ERR',CAST(t.MZDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as MZDM                                --民族代码                                
                                   ,CAST(COALESCE(t13.MBDM,NULLIF(CONCAT('ERR',CAST(t.JGLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as YGT_JGLB                            --机构类别                                
                                   ,CAST(COALESCE(t14.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZBSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as ZBSXDM                              --资本属性                                
                                   ,CAST(COALESCE(t15.MBDM,NULLIF(CONCAT('ERR',CAST(t.GYSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as GYSX                                --国有属性                                
                                   ,t.JGJC                                as JGJC                                --机构简称                                
                                   ,t.YWMC                                as YWMC                                --英文名称                                
                                   ,t.GSWZ                                as GSWZ                                --公司网址                                
                                   ,t.FRXM                                as FRDBXM                              --法定代表人姓名                             
                                   ,CAST(COALESCE(t16.MBDM,NULLIF(CONCAT('ERR',CAST(t.FRZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as FRDBZJLBDM                          --法定代表人证件类别                           
                                   ,t.FRZJBH                              as FRDBZJBH                            --法定代表人证件编号                           
                                   ,t.LXRXM                               as LXRXM                               --联系人姓名                               
                                   ,CAST(COALESCE(t17.MBDM,NULLIF(CONCAT('ERR',CAST(t.LXRZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as LXRZJLBDM                           --联系人证件类别                             
                                   ,t.LXRZJBH                             as LXRZJBH                             --联系人证件编号                             
                                   ,t.YDDH                                as YDDH                                --移动电话                                
                                   ,t.GDDH                                as GDDH                                --固定电话                                
                                   ,t.CZHM                                as CZHM                                --传真号码                                
                                   ,t.LXDZ                                as LXDZ                                --联系地址                                
                                   ,t.LXYB                                as LXYB                                --联系邮编                                
                                   ,t.DZYX                                as DZYX                                --电子邮箱                                
                                   ,t.DXFWBS                              as DXFWBS                              --开通短信服务标识                            
                                   ,t.WLFWBS                              as WLFWBS                              --开通网络服务标识                            
                                   ,t.WLMM                                as WLFWMM                              --网络服务密码                              
                                   ,CAST(COALESCE(t18.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as ZDZH_ZHLB                           --账户类别                                
                                   ,t.ZQZH                                as ZQZH                                --证券账号                                
                                   ,t.XYMTH                               as XYMTH                               --新一码通账户号码                            
                                   ,CAST(COALESCE(t19.MBDM,NULLIF(CONCAT('ERR',CAST(t.XZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as XZJLBDM                             --新证件类别                               
                                   ,t.XZJBH                               as XZJBH                               --新证件编号                               
                                   ,t.PHZQZH                              as PHZQZH                              --配号证券账号                              
                                   ,t.JSCYR                               as JSCYR                               --结算参与人                               
                                   ,t.JYDY                                as XWH                                 --交易单元                                
                                   ,t.YYBBM                               as YYBBM                               --营业部编码                               
                                   ,CAST(COALESCE(t20.MBDM,NULLIF(CONCAT('ERR',CAST(t.SDXLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as ZD_SDXLB                            --适当性类别                               
                                   ,CAST(COALESCE(t21.MBDM,NULLIF(CONCAT('ERR',CAST(t.QYLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as QYLB2                               --签约类别                                
                                   ,t.QYRQ                                as QYRQ                                --签约日期                                
                                   ,t.HHCDFS                              as ZRCDFS                              --承担责任方式                              
                                   ,t.JCXZLB                              as JCXZLB                              --解除限制类别                              
                                   ,t.BYZD1                               as BYZD1                               --保留字段1                               
                                   ,t.BYZD2                               as BYZD2                               --保留字段2                               
                                   ,t.BYZD3                               as BYZD3                               --保留字段3                               
                                   ,t.YWQQID                              as YWQQID                              --业务请求ID                              
                                   ,t.YWQQCLID                            as YWQQCLID                            --业务请求处理ID                            
                                   ,t.CLZT                                as CLZT                                --                                    
                                   ,t.CLCX                                as CLCX                                --                                    
                                   ,t.CPJC                                as CPJC                                --产品简称                                
                                   ,t.CPDQR                               as CPDQR                               --                                    
                                   ,t.CPLB                                as CPLB                                --产品类别                                
                                   ,t.GLRMC                               as GLRMC                                --关联人名称                               
                                   ,CAST(COALESCE(t22.MBDM,NULLIF(CONCAT('ERR',CAST(t.GLRZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as GLRZJLB                             --关联人证件类别                             
                                   ,t.GLRZJBH                             as GLRZJBH                             --关联人证件编号                             
                                   ,t.TGRMC                               as TGRMC                               --托管人名称                               
                                   ,CAST(COALESCE(t23.MBDM,NULLIF(CONCAT('ERR',CAST(t.TGRZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                             as TGRZJLBDM                           --托管人证件类别                             
                                   ,t.TGRZJBH                             as TGRZJBH                             --托管人证件编号    
                                   ,'YGT_ZDZH'								   
 FROM  			YGTCX.CIF_TZD_ZHYWSQ t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'ZD_JYS'
 AND            t1.YXT = 'YGT_ZDZH'
 AND            t1.YDM = CAST(t.JYS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'ZDZH_YWLB'
 AND            t2.YXT = 'YGT_ZDZH'
 AND            t2.YDM = CAST(t.YWLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'CLBZ'
 AND            t3.YXT = 'YGT_ZDZH'
 AND            t3.YDM = CAST(t.CLBZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
 ON             t4.DMLX = 'KHLB'
 AND            t4.YXT = 'YGT_ZDZH'
 AND            t4.YDM = CAST(t.KHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t5 
 ON             t5.DMLX = 'GJDM'
 AND            t5.YXT = 'YGT_ZDSH'
 AND            t5.YDM = CAST(t.GJDM AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t6
 ON             t6.DMLX = 'ZJLBDM'
 AND            t6.YXT = 'YGT_ZDZH'
 AND            t6.YDM = CAST(t.ZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t7
 ON             t7.DMLX = 'ZJLBDM'
 AND            t7.YXT = 'YGT_ZDZH'
 AND            t7.YDM = CAST(t.FZZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t8 
 ON             t8.DMLX = 'KH_KHFS'
 AND            t8.YXT = 'YGT_ZDZH'
 AND            t8.YDM = CAST(t.KHFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t9
 ON             t9.DMLX = 'XBDM'
 AND            t9.YXT = 'YGT_ZDZH'
 AND            t9.YDM = CAST(t.XB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t10
 ON             t10.DMLX = 'XLDM'
 AND            t10.YXT = 'YGT_ZDZH'
 AND            t10.YDM = CAST(t.XLDM AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t11 
 ON             t11.DMLX = 'ZYDM'
 AND            t11.YXT = 'YGT_ZDZH'
 AND            t11.YDM = CAST(t.ZYXZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t12 
 ON             t12.DMLX = 'MZDM'
 AND            t12.YXT = 'YGT_ZDZH'
 AND            t12.YDM = CAST(t.MZDM AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t13 
 ON             t13.DMLX = 'YGT_JGLB'
 AND            t13.YXT = 'YGT_ZDZH'
 AND            t13.YDM = CAST(t.JGLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t14 
 ON             t14.DMLX = 'ZBSXDM'
 AND            t14.YXT = 'YGT_ZDZH'
 AND            t14.YDM = CAST(t.ZBSX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t15
 ON             t15.DMLX = 'GYSX'
 AND            t15.YXT = 'YGT_ZDZH'
 AND            t15.YDM = CAST(t.GYSX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t16
 ON             t16.DMLX = 'ZJLBDM'
 AND            t16.YXT = 'YGT_ZDZH'
 AND            t16.YDM = CAST(t.FRZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t17
 ON             t17.DMLX = 'ZJLBDM'
 AND            t17.YXT = 'YGT_ZDZH'
 AND            t17.YDM = CAST(t.LXRZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t18 
 ON             t18.DMLX = 'ZDZH_ZHLB'
 AND            t18.YXT = 'YGT_ZDZH'
 AND            t18.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t19
 ON             t19.DMLX = 'ZJLBDM'
 AND            t19.YXT = 'YGT_ZDZH'
 AND            t19.YDM = CAST(t.XZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t20 
 ON             t20.DMLX = 'ZD_SDXLB'
 AND            t20.YXT = 'YGT_ZDZH'
 AND            t20.YDM = CAST(t.SDXLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t21 
 ON             t21.DMLX = 'QYLB2'
 AND            t21.YXT = 'YGT_ZDZH'
 AND            t21.YDM = CAST(t.QYLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t22
 ON             t22.DMLX = 'ZJLBDM'
 AND            t22.YXT = 'YGT_ZDZH'
 AND            t22.YDM = CAST(t.GLRZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t23
 ON             t23.DMLX = 'ZJLBDM'
 AND            t23.YXT = 'YGT_ZDZH'
 AND            t23.YDM = CAST(t.TGRZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t24
 ON             t24.YXT = 'CIF'
 AND            t24.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          CAST(t.DT AS INT) = ( SELECT MAX(LST_TRD_D) FROM EDW_PROD.T_EDW_T99_TRD_DATE WHERE NAT_DT = %d{yyyyMMdd} AND BUS_DATE = %d{yyyyMMdd} ) ;
	------------插入结束------------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZD_ZHYWSQ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TZD_ZHYWSQ;
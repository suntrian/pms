------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:机构客户信息表                                                                       */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 


--------------插入数据-------------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_ORG_CUST_INFO
(                                   CUST_NO                                --客户号     
                                   ,CPTL_ATTR_CD                           --资本属性代码  
                                   ,STOWN_ATTR_CD                          --国有属性代码  
                                   ,LSTD_ATTR_CD                           --上市属性代码                                
                                   ,ETP_CGY_CD                             --企业类别代码  
                                   ,IDSTR_CD                               --行业代码                                                                           
                                   ,ORG_CUST_ORG_CGY                       --机构客户机构类别
                                   ,PR_FND_ADMIN_NO                        --私募基金管理人编码
								   ,MG_SCP                                 --经营范围	           
								   ,RGST_CPTL                              --注册资本
                                   ,AGNT_NAME                              --代理人姓名								   
								   ,ORG_CD_CTF                             --组织机构代码证         
								   ,ORG_CD_CTF_EXPR_DT                     --组织机构代码证截止日期
								   ,NTNLTAX_REGST_CTF                      --国税税务登记证	       
								   ,NTNLTAX_REGST_CTF_EXPR_DT              --国税税务登记证截止日期
								   ,TZX_REGST_CTF                          --地税税务登记证	       
								   ,TZX_REGST_CTF_EXPR_DT                  --地税税务登记证截止日期 
								   ,LGLPSN_CGY_CD                          --法人类别代码
								   ,LGLPSN_BHAF_NAME                       --法定代表人姓名         
								   ,LGLPSN_BHAF_CTF_CGY                    --法定代表人证件类别	   
								   ,LGLPSN_BHAF_CTF_NO                     --法定代表人证件编号     
								   ,LGLPSN_BHAF_CTF_EXPR_DT                --法定代表人证件截止日期
								   ,ATTN_NAME                              --经办人姓名	           
								   ,ATTN_CTF_CGY                           --经办人证件类别	       
								   ,ATTN_CTF_NO                            --经办人证件编号	       
								   ,ATTN_CTF_EXPR_DT                       --经办人证件截止日期	   
								   ,HOLD_SHRHLD_NAME                       --控制人名称	           
								   ,HOLD_SHRHLD_CTF_CGY                    --控制人证件类别代码	   
								   ,HOLD_SHRHLD_CTF_NO                     --控制人证件编号	       
								   ,HOLD_SHRHLD_CTF_EXPR_DT                --控制人证件截止日期	
                                   ,PROD_CGY                               --产品类别
                                   ,CUST_ESP_HINT                          --客户特别提示								   
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT                 t.KHH                      as CUST_NO                                --客户号     
                        ,t.ZBSXDM                  as CPTL_ATTR_CD                           --资本属性代码  
                        ,t.GYSX                    as STOWN_ATTR_CD                          --国有属性代码  
                        ,t.SSSXDM                  as LSTD_ATTR_CD                           --上市属性代码               
                        ,t.QYLBDM                  as ETP_CGY_CD                             --企业类别代码  
                        ,t.HYLB                    as IDSTR_CD                               --行业代码                   
                        ,t.YGT_JGLB                as ORG_CUST_ORG_CGY                       --机构客户机构类别
                        ,t.SMJJGLRBM               as PR_FND_ADMIN_NO                        --私募基金管理人编码
                        ,t.JGJYFW	               as MG_SCP                                 --经营范围	           
                        ,t.JGZCZB	               as RGST_CPTL                              --注册资本	 
                        ,a1.DLRMC                  as AGNT_NAME                              --代理人姓名						
                        ,t.ZZJGDM	               as ORG_CD_CTF                             --组织机构代码证         
                        ,t.ZZJGDMJZRQ	           as ORG_CD_CTF_EXPR_DT                     --组织机构代码证截止日期
                        ,t.GSSWDJZ	               as NTNLTAX_REGST_CTF                      --国税税务登记证	       
                        ,t.GSSWDJZJZRQ	           as NTNLTAX_REGST_CTF_EXPR_DT              --国税税务登记证截止日期
                        ,t.DSSWDJZ	               as TZX_REGST_CTF                          --地税税务登记证	       
                        ,t.DSSWDJZJZRQ	           as TZX_REGST_CTF_EXPR_DT                  --地税税务登记证截止日期
                        ,t.FRLBDM                  as LGLPSN_CGY_CD                          --法人类别代码						
                        ,t.FRDBXM	               as LGLPSN_BHAF_NAME                       --法定代表人姓名         
                        ,t.FRDBZJLBDM	           as LGLPSN_BHAF_CTF_CGY                    --法定代表人证件类别	   
                        ,t.FRDBZJBH	               as LGLPSN_BHAF_CTF_NO                     --法定代表人证件编号     
                        ,t.FRDBZJJZRQ	           as LGLPSN_BHAF_CTF_EXPR_DT                --法定代表人证件截止日期
                        ,t.JBRXM	               as ATTN_NAME                              --经办人姓名	           
                        ,t.JBRZJLBDM	           as ATTN_CTF_CGY                           --经办人证件类别	       
                        ,t.JBRZJBH  	           as ATTN_CTF_NO                            --经办人证件编号	       
                        ,t.JBRZJJZRQ	           as ATTN_CTF_EXPR_DT                       --经办人证件截止日期	   
                        ,a2.KZRMC	               as HOLD_SHRHLD_NAME                       --控制人名称	           
                        ,a2.ZJLBDM	               as HOLD_SHRHLD_CTF_CGY                    --控制人证件类别代码	   
		                ,a2.ZJBH	               as HOLD_SHRHLD_CTF_NO                     --控制人证件编号	       
                        ,a2.ZJJZRQ	               as HOLD_SHRHLD_CTF_EXPR_DT                --控制人证件截止日期
                        ,t.CPBZ                    as PROD_CGY                               --产品类别
                        ,NULL                      as CUST_ESP_HINT                          --客户特别提示						
  FROM          EDW_PROD.T_EDW_T01_TJGKHXX                                 t        
  LEFT JOIN ( SELECT  a.KHH
                      ,a.DLRMC
             FROM ( SELECT KHH
			              ,DLRMC
						  ,ROW_NUMBER() OVER(PARTITION BY KHH ORDER BY DLRID DESC) as NUM
			       FROM    EDW_PROD.T_EDW_T01_TDLR
				   WHERE BUS_DATE = %d{yyyyMMdd} 
				   ) a
             WHERE a.NUM = 1
	        )                                                             a1
 ON           t.KHH = a1.KHH
 LEFT JOIN    ( SELECT a.KHH
                      ,a.ZJLBDM
		              ,a.KZRMC
					  ,a.ZJBH
					  ,a.ZJJZRQ
                FROM ( SELECT KHH
				              ,KZRMC
				              ,ZJLBDM
				              ,ZJBH
				              ,ZJJZRQ
							  ,ROW_NUMBER() OVER(PARTITION BY KHH ORDER BY JGKGID DESC) as NUM
				       FROM EDW_PROD.T_EDW_T02_TJGKGGD 
				       WHERE BUS_DATE = %d{yyyyMMdd}
				      )     a
                WHERE a.NUM = 1
               )                       a2
 ON           t.KHH = a2.KHH                                                      --取出最近的控制股东姓名 
 WHERE        t.BUS_DATE = %d{yyyyMMdd} 

;
		
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_ORG_CUST_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_ORG_CUST_INFO ;
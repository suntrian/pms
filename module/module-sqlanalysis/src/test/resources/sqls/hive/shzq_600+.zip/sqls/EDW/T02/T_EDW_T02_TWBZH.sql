 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:外部帐户信息表                                                                */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                       */
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TWBZH; 
--------插入数据开始--------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TWBZH(
                                    KHH                                 --客户号                                
                                   ,WBJGDM                              --外部机构代码                             
                                   ,WBZH                                --外部帐户                               
                                   ,BZDM                                --币种代码                               
                                   ,JGLB                                --机构类别                               
                                   ,ZHMC                                --帐户名称                               
                                   ,WBZHYWFW                            --外部帐户业务范围                           
                                   ,DJRQ                                --登记日期                               
                                   ,XHRQ                                --销户日期                               
                                   ,WBZHZT                              --外部帐户状态                             
                                   ,BDKYZJ                              --本地可用资金                             
                                   ,DJJE                                --登记金额                               
                                   ,ZRSZ                                --昨日市值                               
                                   ,CKKY                                --参考外部可用资金                           
                                   ,CKKQ                                --参考外部可取资金                           
                                   ,CKDJ                                --参考外部冻结资金                           
                                   ,CKYE                                --参考外部余额                             
                                   ,YEGXSJ                              --余额更新时间                             
                                   ,ZJJYRQ                              --资金交易日期                             
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.JGDM                                as WBJGDM                              --机构代码                                
                                   ,t.WBZH                                as WBZH                                --外部帐户                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.JGLB                                as JGLB                                --机构类别                                
                                   ,t.ZHMC                                as ZHMC                                --帐户名称                                
                                   ,t.YWFW                                as WBZHYWFW                            --业务范围                                
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.XHRQ                                as XHRQ                                --销户日期                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as WBZHZT                              --帐户状态                                
                                   ,t.BDKYZJ                              as BDKYZJ                              --本地可用资金                              
                                   ,t.DJJE                                as DJJE                                --登记金额                                
                                   ,t.ZRSZ                                as ZRSZ                                --昨日市值                                
                                   ,t.CKKY                                as CKKY                                --参考外部可用资金                            
                                   ,t.CKKQ                                as CKKQ                                --参考外部可取资金                            
                                   ,t.CKDJ                                as CKDJ                                --参考外部冻结资金                            
                                   ,t.CKYE                                as CKYE                                --参考外部余额                              
                                   ,t.YEGXSJ                              as YEGXSJ                              --余额更新时间                              
                                   ,t.ZJJYRQ                              as ZJJYRQ                              --资金交易日期                              
                                   ,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
 FROM           JZJYCX.DATACENTER_TWBZH                t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'WBZHZT'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.ZHZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t3
 ON             t3.YXT = 'JZJY'
 AND            t3.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
-------插入数据结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TWBZH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TWBZH;
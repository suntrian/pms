 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:个股期权合约持仓历史表                                                             */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 

-------插入数据开始
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TSO_HYCC
(
                                    KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --客户营业部                              
                                   ,KHQZ                                --客户群组                               
                                   ,GDH                                 --股东号                                
                                   ,ZZHBM                               --子账户编码                              
                                   ,JYS                                 --交易所                                
                                   ,BZDM                                --币种代码                               
                                   ,HYDM                                --期权合约代码                             
                                   ,HYMC                                --期权合约简称                             
                                   ,SOP_QQLX                            --期权类型                               
                                   ,ZQLX                                --标的证券类型                             
                                   ,ZQDM                                --标的证券                               
                                   ,ZQMC                                --标的证券名称                             
                                   ,SOP_MMFX                            --买卖方向                               
                                   ,SOP_BDBQ                            --备兑标签                               
                                   ,ZQSL                                --合约数量                               
                                   ,DJSL                                --冻结数量                               
                                   ,KCWTSL                              --当日开仓委托数量                           
                                   ,PCWTSL                              --当日平仓委托数量                           
                                   ,KCCJSL                              --当日开仓成交数量                           
                                   ,PCCJSL                              --当日平仓成交数量                           
                                   ,KCCJJE                              --当日开仓成交金额                           
                                   ,PCCJJE                              --当日卖出成交金额                           
                                   ,KCRQ                                --开仓日期                               
                                   ,BDRQ                                --变动日期                               
                                   ,KCJE                                --买入金额                               
                                   ,KCSL                                --买入数量                               
                                   ,PCJE                                --卖出金额                               
                                   ,PCSL                                --卖出数量                               
                                   ,CCCB                                --持仓成本金额                             
                                   ,TBCB                                --摊薄成本金额                             
                                   ,SXYK                                --累计盈亏                               
                                   ,XQYK                                --行权盈亏                               
                                   ,BZJ                                 --占用保证金                              
                                   ,BZJ_YJ                              --登记公司保证金                            
                                   ,ZXSZ                                --最新市值                               
                                   ,COMPUTES                            --计算列                                
                                   ,ZHSL                                --组合数量                               
                                   ,ZHWTSL                              --组合委托数量                             
                                   ,ZHCJSL                              --组合成交数量                             
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期  
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t5.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.ZZHBM                               as ZZHBM                               --子账户编码                               
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                    as BZDM                                --币种                                  
                                   ,t.HYDM                                as HYDM                                --期权合约代码                              
                                   ,t.HYMC                                as HYMC                                --期权合约简称                              
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.QQLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SOP_QQLX                            --期权合约类型                              
                                   ,t.ZQLX                                as ZQLX                                --标的证券类型                              
                                   ,t.ZQDM                                as ZQDM                                --标的证券                                
                                   ,t.ZQMC                                as ZQMC                                --标的证券名称                              
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.MMFX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SOP_MMFX                            --买卖方向                                
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.BDBQ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SOP_BDBQ                            --备兑期权标志                              
                                   ,t.ZQSL                                as ZQSL                                --合约数量                                
                                   ,t.DJSL                                as DJSL                                --冻结数量                                
                                   ,t.KCWTSL                              as KCWTSL                              --当日开仓委托数量                            
                                   ,t.PCWTSL                              as PCWTSL                              --当日平仓委托数量                            
                                   ,t.KCCJSL                              as KCCJSL                              --当日开仓成交数量                            
                                   ,t.PCCJSL                              as PCCJSL                              --当日平仓成交数量                            
                                   ,t.KCCJJE                              as KCCJJE                              --当日开仓成交金额                            
                                   ,t.PCCJJE                              as PCCJJE                              --当日卖出成交金额                            
                                   ,t.KCRQ                                as KCRQ                                --开仓日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.KCJE                                as KCJE                                --买入金额                                
                                   ,t.KCSL                                as KCSL                                --买入数量                                
                                   ,t.PCJE                                as PCJE                                --卖出金额                                
                                   ,t.PCSL                                as PCSL                                --卖出数量                                
                                   ,t.CCCB                                as CCCB                                --持仓成本金额                              
                                   ,t.TBCB                                as TBCB                                --摊薄成本金额                              
                                   ,t.SXYK                                as SXYK                                --累计盈亏                                
                                   ,t.XQYK                                as XQYK                                --行权盈亏                                
                                   ,t.BZJ                                 as BZJ                                 --占用保证金                               
                                   ,t.BZJ_YJ                              as BZJ_YJ                              --登记公司保证金                             
                                   ,t.ZXSZ                                as ZXSZ                                --最新市值                                
                                   ,t.COMPUTES                            as COMPUTES                            --计算列                                 
                                   ,t.ZHSL                                as ZHSL                                --组合数量                                
                                   ,t.ZHWTSL                              as ZHWTSL                              --组合委托数量                              
                                   ,t.ZHCJSL                              as ZHCJSL                              --组合成交数量                              
                                   ,%d{yyyyMMdd}                          as KSRQ                                --                                    
                                   ,%d{yyyyMMdd}                          as JSRQ                                --         
                                   ,'GGQQ'                                as  XTBS								   
 FROM           GGQQCX.DATACENTER_TSO_HYCC             t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'GGQQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'SOP_QQLX'
 AND            t2.YXT = 'GGQQ'
 AND            t2.YDM = CAST(t.QQLX AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'SOP_MMFX'
 AND            t3.YXT = 'GGQQ'
 AND            t3.YDM = CAST(t.MMFX AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
 ON             t4.DMLX = 'SOP_BDBQ'
 AND            t4.YXT = 'GGQQ'
 AND            t4.YDM = CAST(t.BDBQ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t5
 ON             t5.YXT = 'GGQQ'
 AND            t5.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
 -----插入数据结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TSO_HYCC',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TSO_HYCC;
	
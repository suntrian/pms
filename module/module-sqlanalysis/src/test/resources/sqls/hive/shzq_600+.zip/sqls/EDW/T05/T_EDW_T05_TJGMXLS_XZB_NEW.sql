 --/* ***************************************** SQL Begin *****************************************  */
  --/* 脚本功能:历史交割明细表修正表                                                                      */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2016-11-02                                                                        */ 
  ALTER TABLE EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ; 
  -----
  --1.上海债券认购款的委托类别代码修改(80-83) 代码区段  '751970' AND '751999'
  --2.深圳债券认购款的委托类别代码修改(1-83)  代码区段  '101650' AND '101699'
  --3.上海基金认购款的委托类别代码修改(41(CJBH:认购结果)-83) 代码区段 SUBSTR(ZQDM,1,3) IN ('501','502','503')
  
  --4.上海基金认购款的委托类别代码修改(41(CJBH:认购确认)-80 ,CJJE = 0-YSJE) 
  --增加一条81 取WTLB = 41 CJBH = '认购结果' (修改 41-81) CJJE = CJJE+YSJE,S1 = 0
  --修改 取WTLB = 41 CJBH = '认购结果' (修改 41-83) CJJE = CJJE-S1,YSJE = -CJJE 代码区段SUBSTR(ZQDM,1,3) IN('519')
  
  --5.深圳基金认购款的委托类别代码修改(41-80(CJBH:申购扣款)),(41-83(CJBH:认购确认)) 代码区段SUBSTR(ZQDM,1,3) IN ('159','16')
  --5.上海基金认购款的委托类别代码修改41-83 代码区段SUBSTR(ZQDM,1,3) IN ('510','511','512','513') 
 --暂时无上海基金518区段代码的认购
---6.修改JYS IN ('SH','SZ') WTLB = 42 CJJE< 0 修改内容:CJJE = 0-CJJE 
---7.修改JYS IN ('SH','SZ') WTLB = 43 AND SUBSTR(a.ZQDM,1,3) = '519' AND a.CJJE = 0 AND  a.S1 =0 AND a.s2 = 0 AND a.S3 =0 
---8.WTLB = 20 CJBH IN ('开户认领','债券手工转入：代保管托管转入','债券手工转入','手工调帐转入')
---9.WTLB = 21 CJBH IN ('内部转户','债券手工转出：债券手','债券手工转出')
----8,WTLB = 18 CJBH IN ('分拆合并','股份调账','特殊股份调账','债券存券')
----CJBH IN ('上市流通','权益转入','转流通股','期权行权','证券转换','确权转入')而且有一条19，21 CJBH 为('非流通转出')对应 
----10.WTLB = 18 CJBH IN ('债券存券','股份转让','期权行权','证券转换')
----11.WTLB = 19 CJBH IN ('期权行权','证券转换','股份转让','余额调整')
----12.WTLB IN (18,19) AND CJBH = '余额调整' AND JYS = 'HB'

--------创建转债申购或者配债的转换代码
   DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP0 ;
   CREATE TABLE EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP0    as
   SELECT       b.SECUCODE                              as ZQDM
                ,DECODE(b.secumarket,83,'SH',90,'SZ')   as JYS
		        ,a.onlinepuboffcode                     as SGDM
				,a.PREFALTCODEH                         as PZDM	
                ,CAST(CONCAt(substr(OnLinePubOffDate,1,4),substr(OnLinePubOffDate,6,2),substr(OnLinePubOffDate,9,2) ) as INT)  as SWSGRQ 
                ,c.SSRQ                   as SSRQ
                ,c.TSRQ	             as TSRQ			
   FROM        FUNDEXT.DBO_BOND_CONBDISSUE    a
   LEFT JOIN   FUNDEXT.DBO_BOND_CODE          b
   ON          a.INNERCODE = b.INNERCODE
   AND         b.DT = '%d{yyyyMMdd}'
   LEFT JOIN   EDW_PROD.T_EDW_T04_TSZQDM  c
   ON          b.SECUCODE = c.ZQDM
   AND         DECODE(b.secumarket,83,'SH',90,'SZ') = c.JYS
   AND         c.BUS_DATE = %d{yyyyMMdd}   
   WHERE       a.DT = '%d{yyyyMMdd}'
   AND         (CONCAt(substr(onlinepuboffdate,1,4),substr(onlinepuboffdate,6,2),substr(onlinepuboffdate,9,2) ) > '20140101'
				OR CONCAt(substr(prefaltpaystartdateh,1,4),substr(prefaltpaystartdateh,6,2),substr(prefaltpaystartdateh,9,2) ) > '20140101'
				)
   AND        b.secumarket IN (83,90)
    AND   %d{yyyyMMdd} BETWEEN NVL(CAST(CONCAt(substr(OnLinePubOffDate,1,4),substr(OnLinePubOffDate,6,2),substr(OnLinePubOffDate,9,2) ) as INT),99999999) AND  NVL(c.SSRQ,99999999);

-------创建债券认购的转换代码   
   DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP1;
   CREATE TABLE EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP1					
   as  SELECT        b.SECUCode                            as ZQDM
                    ,DECODE(b.secumarket,83,'SH',90,'SZ')  as JYS
		            ,a.ApplyCodeOnline                        as RGDM		 
                    ,CAST(CONCAt(substr(a.issuestardate,1,4),substr(a.issuestardate,6,2),substr(a.issuestardate,9,2) ) as INT)   as QSRQ                   						  						  
                    ,CAST(CONCAt(substr(a.IssueEndDate,1,4),substr(a.IssueEndDate,6,2),substr(a.IssueEndDate,9,2) ) as INT)   as JZRQ 
					,c.SSRQ                  as SSRQ
                    ,c.TSRQ  	             as TSRQ	
	   FROM        FUNDEXT.DBO_Bond_Issue          a
       LEFT JOIN   fundext.dbo_BOND_CODE           b
       ON          a.INNERCODE = b.INNERCODE
       AND         b.DT = '%d{yyyyMMdd}'
	   LEFT JOIN   EDW_PROD.T_EDW_T04_TSZQDM  c
       ON          b.SECUCODE = c.ZQDM
       AND         DECODE(b.secumarket,83,'SH',90,'SZ') = c.JYS
       AND         c.BUS_DATE = %d{yyyyMMdd} 
	WHERE  CAST(CONCAt(substr(a.issuestardate,1,4),substr(a.issuestardate,6,2),substr(a.issuestardate,9,2) ) as INT) > = 20140101
    AND    b.secumarket IN (83,90)
    AND	   a.DT = '%d{yyyyMMdd}'
	;

 ---------------修正18,19 折算变更,比例变更
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP ;
 CREATE TABLE EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP as
 SELECT          a.SEQNO         --事件序号
                ,a.WTH           --委托号
                ,a.KHH           --客户号           
                ,a.KHXM          --客户姓名          
                ,a.YYB           --营业部编号                                                
                ,a.GDH           --股东号
				,a.GDXM          --股东姓名
                ,a.JYS           --交易所
                ,a.BZDM          --币种代码
				,a.ZQLB          --证券类别
				,a.BCSL          
                ,CASE WHEN b.ExApplyingCode IS NOT NULL
			          THEN b.SecurityCode
				      WHEN c.ZQDM IS NOT NULL
				      THEN c.ZQDM
				      WHEN d.ZQDM IS NOT NULL
				      THEN d.ZQDM
					  WHEN e.IssueCODE IS NOT NULL
					  THEN  e.secucode
				      ELSE EDW_PROD.CODE_TRANS_ZQDM(a.JYS,a.ZQDM)
				      END  as ZQDM          --证券代码
                ,a.ZQDM as ZQDM1         --证券代码1
                ,a.ZQMC          --证券名称
                ,a.WTFS          --委托方式
                ,CASE WHEN a.WTLB = 1 
			          AND  a.JYS = 'SZ' 
                      AND  a.ZQDM BETWEEN '101650' AND '101699'
                      THEN 80
				      WHEN a.WTLB = 41
				      AND  a.JYS = 'SH'
				      AND  SUBSTR(a.ZQDM,1,3) = '519'
				      AND  a.CJBH = '认购确认'
				      THEN 80
				      WHEN a.WTLB = 41
				      AND  a.JYS = 'SH'
				      AND  SUBSTR(a.ZQDM,1,3) IN ('519','501','502','503','506')
				      AND  a.CJBH = '认购结果'
				      THEN 83
				      WHEN a.WTLB = 41
				      AND  a.JYS = 'SH'
				      AND  SUBSTR(a.ZQDM,1,3) IN ('510','511','512','513','518','515')				 
				      THEN 80
                      WHEN a.WTLB = 41
				      AND  a.JYS = 'SZ'
				      AND  SUBSTR(a.ZQDM,1,3) IN ('159','160','161','162','163','164','165','166','167','168','169')
                      AND  a.CJBH = '申购扣款'				  
				      THEN 80
				      WHEN a.WTLB = 41
				      AND  a.JYS = 'SZ'
				      AND  SUBSTR(a.ZQDM,1,3) IN ('159','160','161','162','163','164','165','166','167','168','169')
                      AND  a.CJBH = '认购确认'				  
				      THEN 83
				      ELSE a.WTLB
				      END      as WTLB --委托类别
				,a.CJBH          --成交编号
				,a.CJRQ          --成交日期
				,a.JSRQ          --结束日期
				,a.CJSL          --成交数量
                ,a.CJJG          --成交价格
				,a.JSJ           --结算费
				,a.LXJG          --利息价格
				,CASE WHEN a.WTLB = 41
				      AND  a.JYS = 'SH'
				      AND  SUBSTR(a.ZQDM,1,3) = '519'
				      AND  a.CJBH = '认购确认'
			          THEN 0-a.YSJE
			          WHEN a.WTLB = 41
				      AND  a.JYS = 'SH'
				      AND  SUBSTR(a.ZQDM,1,3) = '519'
				      AND  a.CJBH = '认购结果'
				      THEN a.CJJE-a.S1
                      WHEN a.JYS IN ('SH','SZ') 
				      AND  a.WTLB = 42 
				      AND  a.CJJE < 0
			          THEN 0-a.CJJE
				      WHEN a.JYS = 'SH' 
				      AND a.WTLB = 43 
				      AND SUBSTR(a.ZQDM,1,3) = '519' 
				      AND a.CJJE = 0
			          AND a.S1 =0 
				      AND a.s2 = 0 
				      AND a.S3 =0 
				      AND a.S4 = 0 
				      AND a.S5 = 0 
				      AND a.s6 = 0
			          THEN a.YSJE
				      WHEN a.WTLB = 84 
				      AND a.YSJE = 0
				      AND a.CJBH LIke '%初始合同无效%'
				      THEN 0
				      ELSE a.CJJE
				      END   as CJJE          --成交金额
				,a.LXJE          --利息金额
				,a.S1            --实收佣金
				,a.S2            --印花税
				,CAST(CASE WHEN a.JYS = 'SB' 
				           AND  a.ZQLB = 'GO' 
						   AND  a.WTLB = 2
		                   THEN a.CJJE*0.00005
			               ELSE a.S3
			               END as DECIMAL(38,2)
					 )  as S3           --过户费
				,a.S4            --附加费
				,a.S5            --证管费
				,a.S6            --交易规费
                ,a.S11           --一级费用-经手费
                ,a.S12           --一级费用-证管费
                ,a.S13           --一级费用-过户费
                ,a.S15           --一级费用-结算费
                ,a.S16           --一级费用-风险基金
                ,CASE WHEN  a.JYS = 'SH'
			          AND  SUBSTR(a.ZQDM,1,3) = '519'
				      AND  a.CJBH = '认购结果'
				      THEN 0-a.CJJE
				      ELSE a.YSJE
				      END       as YSJE		  --收金额
				,a.YSSL                          
				,a.CZZD1         --操作终端
				,a.XTBS          --账户类别
FROM        EDW_PROD.T_EDW_T05_TJGMXLS    a
LEFT JOIN   (SELECT      SecurityCode
                         ,ExApplyingCode,DT 
		      FROM       fundext.dbo_MF_FundArchives
			  WHERE      LENGTH(TRIM(NVL(exapplyingcode,'')))>0
			  AND        securitycode < > exapplyingcode
		      AND        SUBSTR(securitycode,7,1) <> 'J'
			  AND        DT =  '%d{yyyyMMdd}'
			   )                                         b
 ON          a.ZQDM = b.ExApplyingCode
 AND        (SUBSTR(a.ZQDM,1,3) = '519' AND a.JYS = 'SH')
 LEFT JOIN    EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP0        c
 ON           ((DECODE(SUBSTR(a.ZQDM,1,3),'743',CONCAT('733',SUBSTR(a.ZQDM,4,3)),'793',CONCAT('783',SUBSTR(a.ZQDM,4,3)),'755',CONCAT('754',SUBSTR(a.ZQDM,4,3)),a.ZQDM) = c.SGDM  AND %d{yyyyMMdd} BETWEEN c.SWSGRQ AND c.SSRQ)
               OR (a.ZQDM = c.PZDM  AND %d{yyyyMMdd} BETWEEN c.SWSGRQ AND c.TSRQ))
 AND          a.JYS = c.JYS 
 LEFT JOIN    EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP1        d
 ON           a.ZQDM = TRIM(d.RGDM)  
 AND          a.JYS = d.JYS
 AND          %d{yyyyMMdd} BETWEEN d.QSRQ AND d.JZRQ   
 LEFT JOIN ( SELECT CONCAt(substr(a.paydate,1,4),substr(a.paydate,6,2),substr(a.paydate,9,2) ) as paydate
                   ,NVL(CONCAt(substr(a.NEWSHARELISTDT,1,4),substr(a.NEWSHARELISTDT,6,2),substr(a.NEWSHARELISTDT,9,2) ),'99999999') as NEWSHARELISTDT
				   ,b.secucode
				   ,a.IssueCODE
             FROM   FUNDEXT.DBO_NQ_IPOISSUE  a
			 LEFT JOIN FUNDEXT.DBO_NQ_SECUMAIN b
			 ON        a.DT = b.DT
			 AND       a.INNERCODE = b.INNERCODE
			 WHERE    a.DT = '%d{yyyyMMdd}'
			 AND   '%d{yyyyMMdd}' BETWEEN CONCAt(substr(a.paydate,1,4),substr(a.paydate,6,2),substr(a.paydate,9,2) )  AND NVL(CONCAt(substr(a.NEWSHARELISTDT,1,4),substr(a.NEWSHARELISTDT,6,2),substr(a.NEWSHARELISTDT,9,2) ),'99999999')
			 AND a.IssueCODE is not null
             )   e
 ON a.ZQDM = e.IssueCODE
 AND SUBSTR(a.ZQDM,1,3) = '889'
 AND  a.JYS IN ('TA','TU')
 WHERE         a.BUS_DATE = %d{yyyyMMdd} ;    


 --- 修改CJBH
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP2 ;
 CREATE TABLE EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP2 as
  SELECT         a.SEQNO         --事件序号
                ,a.WTH           --委托号
                ,a.KHH           --客户号           
                ,a.KHXM          --客户姓名          
                ,a.YYB           --营业部编号                                                
                ,a.GDH           --股东号
				,a.GDXM          --股东姓名
                ,a.JYS           --交易所
                ,a.BZDM          --币种代码
				,a.ZQLB          --证券类别
                ,CASE WHEN a.WTLB IN (29,30)
			     AND SUBSTR(a.ZQLB,1,1) = 'E'
				 AND SUBSTR(a.ZQDM,1,3) IN ('510','511','512','513','518','515')
				 AND SUBSTR(a.ZQDM,6,1) IN ('1','2','5')
				 THEN CONCAT(SUBSTR(a.ZQDM,1,5),'0')
				 ELSE a.ZQDM
				 END   as ZQDM--证券代码
                ,a.ZQDM1         --证券代码1
                ,a.ZQMC          --证券名称
                ,a.WTFS          --委托方式
                ,CASE WHEN  a.WTLB = 16
			     AND   a.CJBH = '股份托管'
				 AND   a.JYS = 'SK'
				 AND   SUBSTR(a.ZQDM1,1,3) = '029'
				 THEN  18				 
				 WHEN  a.WTLB = 18
			     AND   a.CJBH = '上市转入'
				 AND   a.JYS = 'SB'
				 AND   SUBSTR(a.ZQDM1,1,3) = '299'	  
				 THEN  8888	 
				 WHEN  a.WTLB = 18
			     AND   a.CJBH = '余额调整'
				 AND   a.JYS = 'HB'
				 AND   SUBSTR(a.GDH,1,2) = 'C9'	  
				 THEN  0
                 WHEN  a.WTLB = 19
			     AND   a.CJBH = '撤销指定'
				 AND   a.JYS = 'SH'
				 AND   SUBSTR(a.ZQDM1,1,1) IN ('5','6')
				 THEN 0
				 WHEN  a.WTLB = 20
			     AND   a.CJBH = '手工调账转入'
				 AND   (a.BCSL = 0 OR SUBSTR(a.GDH,1,2) = 'C9')
				 THEN 0
				 WHEN  a.WTLB = 21
			     AND   a.CJBH = '手工调账转出'
				 AND    SUBSTR(a.GDH,1,2) = 'C9'
				 THEN  0
				 WHEN  a.WTLB IN (18,19)
			     AND   a.CJBH = '收购现金对价'
				 AND   a.JYS = 'HK'
				 THEN 0
				 WHEN a.WTLB IN (18,19)
				 AND   a.JYS IN ('SH','SZ')
				 AND   a.CJBH = '证券转换'
				 AND   a.ZQLB LIKE 'Z%'
				 THEN 0
				 WHEN a.WTLB IN (20)
				 AND   a.YSSL < 0
				 AND   a.CJBH = '清除全体持仓'
				 THEN  21
				 ELSE a.WTLB
				 END   	  as WTLB          --委托类别
				,CASE WHEN a.WTLB IN (18,19)
				      AND  a.CJBH IN  ('折算变更','比例变更')
					  AND  b.InfoType IN (1,5)
                      AND  b.SplitType IN (3,7,8)
                      THEN '证券转换'
                      WHEN a.WTLB IN (18,19)
				      AND  a.CJBH IN  ('折算变更','比例变更')
					  AND  b.InfoType IN (1)
                      AND  b.SplitType IN (4)
                      THEN '定期折算'					  
					  WHEN a.WTLB IN (18,19)
				      AND  a.CJBH IN  ('折算变更','比例变更')
					  AND  b.InfoType IN (1)
                      AND  b.SplitType IN (5)
                      THEN '基金上折'	
					  WHEN a.WTLB IN (18,19)
				      AND  a.CJBH IN  ('折算变更','比例变更')
					  AND  b.InfoType IN (1)
                      AND  b.SplitType IN (6)
                      THEN '基金下折'
					  WHEN a.WTLB IN (18,19)
				      AND  a.CJBH IN  ('折算变更','比例变更')
					  AND  b.InfoType IN (1)
                      AND  b.SplitType IN (2,11)
                      THEN '基金自身折算'
					  WHEN a.WTLB IN (18,19)
				      AND  a.CJBH IN  ('强行调增','强行调减')
					  AND  b.InfoType IN (4)
                      AND  b.SplitType IN (14)
                      THEN '证券转换'
					  WHEN  a.WTLB = 16
					  AND   a.CJBH = '股份托管'
					  AND   a.JYS = 'SK'
					  AND   SUBSTR(a.ZQDM1,1,3) = '029'
					  THEN '供股权流通'				
					  WHEN  a.WTLB = 18
					  AND   (a.CJBH IN ('撤销指定','冻结流通','非交易过户','解冻流通','收益结转','指定余额') OR LENGTH(TRIM(NVL(a.CJBH,'')))=0)
					  AND   a.ZQLB IN ('A1','Z6')
					  AND   SUBSTR(a.ZQDM1,1,1) = '7'
					  THEN '权益转入'
					  WHEN  a.WTLB = 18
					  AND   a.CJBH = '供配上市'
					  AND   a.JYS IN ('SK','HK')
					  THEN '配股上市' 
					  WHEN  a.WTLB = 18
					  AND   a.CJBH IN ('上市流通','权益转入','转流通股')
					  AND   c.GDH IS NOT NULL
					  THEN '非流通上市'					 
                      WHEN  a.WTLB = 19
					  AND   LENGTH(TRIM(NVL(a.CJBH,''))) = 0  
					  AND   a.JYS IN ('SH','SZ')
					  AND   a.ZQLB IN ('A4','C4')
                      THEN '权益转出' 
                      WHEN  a.WTLB = 19
					  AND   (a.CJBH IN ('撤销指定','冻结流通','非交易过户','解冻流通','配债上市','上市流通','收益结转') OR LENGTH(TRIM(NVL(a.CJBH,'')))=0)
					  AND   a.ZQLB IN ('A1','Z6')
					  AND   SUBSTR(a.ZQDM1,1,1) = '7'
					  THEN '权益转出'
					  WHEN  a.WTLB = 19
					  AND   a.CJBH IN ('冻结流通','解冻流通','上市流通','收益结转') 
					  AND   a.JYS = 'SH'
					  AND   SUBSTR(a.ZQDM1,1,1) IN ('5','6')
					  THEN '退出结算'					  
					  WHEN  a.WTLB = 19
					  AND   a.CJBH IN ('供配权摘牌','配权摘牌') 
					  AND   a.JYS IN ('HK','SK')
					  AND   SUBSTR(a.ZQDM1,1,3) IN ('029')
					  THEN  '供股权摘牌'					  
					  WHEN  a.WTLB = 19
					  AND   a.CJBH IN ('股份托管') 
					  AND   a.JYS = 'SH'
					  AND   SUBSTR(a.ZQDM1,1,1) IN ('5','6')
					  THEN  '上市转出'
					  WHEN  a.WTLB = 19
					  AND   a.CJBH IN ('退出结算') 
					  AND   a.JYS = 'SZ'
					  AND   SUBSTR(a.ZQDM1,1,2) IN ('08','38')
					  THEN  '权益转出'					  
					  WHEN  a.WTLB = 20
					  AND   a.CJBH IN ('开户认领') 
					  AND   d.GDH IS NOT NULL
					  THEN  '内部转户'
					  WHEN  a.WTLB = 18
					  AND   SUBSTR(a.ZQMC,1,2) IN ('XD','XR','DR')
					  AND  a.JYS = 'SH'
					  AND  CJBH = '上市流通'
					  THEN '红利份额'
				      ELSE a.CJBH				  
					  END      as CJBH          --成交编号
				,a.CJRQ          --成交日期
				,a.JSRQ          --结束日期
				,a.CJSL          --成交数量
                ,a.CJJG          --成交价格
				,a.JSJ           --结算费
				,a.LXJG          --利息价格
				,CASE WHEN a.WTLB = 43 
				      AND  a.CJBH = '基金清盘'
					  THEN a.YSJE
					  ELSE a.CJJE
					  END  as CJJE --成交金额
				,a.LXJE          --利息金额
				,a.S1            --实收佣金
				,a.S2            --印花税
				,a.S3            --过户费
				,a.S4            --附加费
				,a.S5            --证管费
				,a.S6            --交易规费
                ,a.S11           --一级费用-经手费
                ,a.S12           --一级费用-证管费
                ,a.S13           --一级费用-过户费
                ,a.S15           --一级费用-结算费
                ,a.S16           --一级费用-风险基金
                ,a.YSJE          --收金额
				,CASE WHEN a.WTLB IN (20)
				      AND   a.YSSL < 0
				      AND   a.CJBH = '清除全体持仓'
					  THEN  0 - a.YSSL
					  ELSE  a.YSSL
					  END   as YSSL                          
				,a.CZZD1         --操作终端
				,a.XTBS          --账户类别
 FROM         EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP   a 
 LEFT  JOIN   (SELECT      a.InfoType
                           ,SUBSTR(b.SecurityCode,1,6) as ZQDM
		                   ,CAST(CONCAt(substr(a.SplitDay,1,4),substr(a.SplitDay,6,2),substr(a.SplitDay,9,2) ) as INT) as SplitDay
		                   ,a.SplitType
						   ,CASE WHEN SUBSTR(b.SecurityCode,1,3) IN ('500','501','502','503','505','510','511','512','513','518','519','515','506')
						         THEN 'SH'
								 WHEN SUBSTR(b.SecurityCode,1,3) IN ('184','150','151','159','160','161','162','163','164','165','166','167','168','169')
                                 THEN 'SZ'
                                 END  as JYS								 
		                   ,CAST(CONCAt(substr(a.OutcomeNoticeIssueDate,1,4),substr(a.OutcomeNoticeIssueDate,6,2),substr(a.OutcomeNoticeIssueDate,9,2) ) as INT) as OutcomeNoticeIssueDate
		                   ,CAST(CONCAt(substr(a.ChangeRegDate,1,4),substr(a.ChangeRegDate,6,2),substr(a.ChangeRegDate,9,2) ) as INT) as ChangeRegDate
               FROM       FUNDEXT.DBO_MF_SHARESSPLIT a
               LEFT JOIN  FUNDEXT.DBO_MF_FUNDARCHIVES b
               ON         a.INNERCODE = b.INNERCODE
               AND        b.DT = '%d{yyyyMMdd}'
               WHERE      a.DT = '%d{yyyyMMdd}'			  
               AND        CAST(CONCAt(substr(a.SplitDay,1,4),substr(a.SplitDay,6,2),substr(a.SplitDay,9,2) ) as INT) > = 20140101    
               AND        a.InfoType IN (1,4,5)
			   AND        a.SplitType IN (2,3,4,5,6,7,8,14,11)
			  )                                      b
 ON           a.ZQDM = b.ZQDM 
 AND          a.JYS = b.JYS
 AND          ((b.ChangeRegDate = %d{yyyyMMdd} AND   b.InfoType = 1 AND b.SplitType IN (4,5,6))
 OR           (b.InfoType IN (1,4,5) AND b.SplitType IN (2,3,7,8,14,11) AND  %d{yyyyMMdd} BETWEEN b.SplitDay AND NVL(b.OutcomeNoticeIssueDate,b.ChangeRegDate))
              )
 LEFT JOIN (SELECT DISTINCT GDH,ZQDM,0-YSSL as CJSL
            FROM   EDW_PROD.T_EDW_T05_TJGMXLS
            WHERE  BUS_DATE = %d{yyyyMMdd}
            AND    WTLB  = 21
            AND    CJBH = '非流通股转出'			
            )           c
 ON          a.GDH = c.GDH
 AND         a.ZQDM = c.ZQDM
 AND         a.CJSL = c.CJSL
  LEFT JOIN (SELECT DISTINCT GDH,ZQDM,CJSL as CJSL
            FROM   EDW_PROD.T_EDW_T05_TJGMXLS
            WHERE  BUS_DATE = %d{yyyyMMdd}
            AND    WTLB  = 21
            AND    CJBH = '内部转户'			
            )           d
 ON          a.GDH = d.GDH
 AND         a.ZQDM = d.ZQDM
 AND         a.CJSL = d.CJSL 
 LEFT JOIN (SELECT KHH,JYS,ZQDM 
            FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP 
			WHERE   ZQDM1 LIKE '889%' 
			AND     WTLB  = 19
			AND     CJBH = '上市转出'
			GROUP BY KHH,JYS,ZQDM
			)  e
 ON a.KHH = e.KHH
 AND a.JYS = e.JYS
 AND a.ZQDM = e.ZQDM
 ;

-------正常修正 
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP3  ;
 CREATE TABLE EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP3 as
   SELECT        a.SEQNO         --事件序号
                ,a.WTH           --委托号
                ,a.KHH           --客户号           
                ,a.KHXM          --客户姓名          
                ,a.YYB           --营业部编号                                                
                ,a.GDH           --股东号
				,a.GDXM          --股东姓名
                ,a.JYS           --交易所
                ,a.BZDM          --币种代码
				,a.ZQLB          --证券类别
                ,a.ZQDM          --证券代码
                ,a.ZQDM1         --证券代码1
                ,a.ZQMC          --证券名称
                ,a.WTFS          --委托方式
                ,CASE WHEN  a.WTLB = 18
			          AND   a.CJBH = '确权转入'
				      AND   a.JYS = 'TA'
				      AND   p.ZQDM IS NOT NULL
				      THEN  18
				      WHEN a.WTLB = 18				      
					  AND  a.CJBH IN ('拆分合并','非交易过户','股份调账','股份转让','期权行权','确权转入','收购股份对价','余额调整','证券转换','定期折算')
					  AND  %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ 
					  THEN 8888
					  WHEN a.WTLB = 18	     
					  AND  a.CJBH IN ('拆分合并','非交易过户','股份调账','期权行权','股份转让','确权转入','收购股份对价','余额调整','证券转换','定期折算')
					  AND  %d{yyyyMMdd} < b.SSRQ
					  THEN 4444
					  WHEN a.WTLB = 18	AND c.ZQDM IS NULL       
					  AND  a.CJBH IN ('上市流通','新股上市') AND a.JYS = 'SH'
					  AND  %d{yyyyMMdd} < =   NVL(b.SSRQ,99999999)
					  THEN 9
					  WHEN a.WTLB = 18	AND c.ZQDM IS NULL       
					  AND  a.CJBH IN ('上市流通','新股上市') AND a.JYS = 'SZ'
					  AND  %d{yyyyMMdd} < =  NVL(b.SSRQ,99999999)
					  THEN 15
					  WHEN a.WTLB = 20
					  AND  a.CJBH IN ('手工调账转入','内部转户')
					  AND  %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
					  THEN 8888
					  WHEN a.WTLB = 20 
					  AND  a.CJBH IN ('手工调账转入','内部转户')
					  AND  %d{yyyyMMdd} < b.SSRQ 
					  THEN 4444
					  WHEN a.WTLB = 20
					  AND  a.CJBH IN ('开户认领')
					  AND  %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
					  THEN 6666
					  WHEN a.WTLB = 20				 
					  AND  a.CJBH IN ('开户认领')
					  AND  %d{yyyyMMdd} < b.SSRQ 
					  THEN 15
					  WHEN a.WTLB = 18
					  AND  a.CJBH IN ('非流通上市')
					  AND %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
					  THEN 6666
					  WHEN a.WTLB = 18					 
					  AND  a.CJBH IN ('非流通上市')
					  AND %d{yyyyMMdd} < b.SSRQ 
					  THEN 15
					  WHEN a.WTLB = 19
					  AND  a.CJBH IN ('拆分合并','期权行权','收购股份注销','退出结算','证券转换','定期折算')
					  AND  %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
					  THEN 9999
					  WHEN a.WTLB = 19
					  AND  a.CJBH IN ('拆分合并','期权行权','收购股份注销','退出结算','证券转换','定期折算')
					  AND  %d{yyyyMMdd} < b.SSRQ 
					  THEN 5555
					  WHEN a.WTLB = 19 AND e.ZQDM IS  NULL
					  AND  a.CJBH IN ('股份调账')
					  AND  %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
					  THEN 9999
					  WHEN a.WTLB = 19 AND e.ZQDM IS  NULL
					  AND  a.CJBH IN ('股份调账')
					  AND  %d{yyyyMMdd} < b.SSRQ 
					  THEN 5555
					  WHEN a.WTLB = 19
					  AND  a.CJBH IN ('非交易过户','股份转让','转非流通')
					  AND  %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
					  THEN 7777
					  WHEN a.WTLB = 19
					  AND  a.CJBH IN ('非交易过户','股份转让','转非流通')					 
					  AND  %d{yyyyMMdd} < b.SSRQ 
					  THEN 7
					  WHEN a.WTLB = 19
					  AND  a.CJBH IN ('退出结算')
                      AND  a.JYS IN ('TA','TU')					  
					  THEN 9999
					  WHEN a.WTLB = 21
					  AND  a.CJBH IN ('手工调账转出','内部转户')
					  AND  %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
					  THEN 9999
					  WHEN a.WTLB = 21
					  AND  a.CJBH IN ('手工调账转出','内部转户')
					  AND  %d{yyyyMMdd} < b.SSRQ 					 
					  THEN 5555
					  WHEN a.WTLB = 31 AND d.ZQDM IS NULL
					  AND a.YSSL > 0
					  THEN 8888
					  WHEN a.WTLB = 31 AND d.ZQDM IS NULL
					  AND  a.YSSL < 0
					  THEN 9999
					  WHEN a.WTLB = 31 
					  AND  a.YSSL = 0
					  THEN 93
					  WHEN a.WTLB = 65 
                      AND  a.YSSL > 0					  
					  THEN 8888
					  WHEN a.WTLB = 47 AND %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
                      AND  a.YSSL > 0					  
					  THEN 8888
					  WHEN a.WTLB = 47 AND %d{yyyyMMdd} < b.SSRQ 
                      AND  a.YSSL > 0					  
					  THEN 4444
					  WHEN a.WTLB = 47 AND %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
                      AND  a.YSSL < 0					  
					  THEN 9999
					  WHEN a.WTLB = 47 AND %d{yyyyMMdd} < b.SSRQ 
                      AND  a.YSSL < 0					  
					  THEN 5555
					  WHEN a.WTLB = 48 AND %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
                      AND  a.YSSL > 0					  
					  THEN 8888
					  WHEN a.WTLB = 48 AND %d{yyyyMMdd} < b.SSRQ 
                      AND  a.YSSL > 0					  
					  THEN 4444
					  WHEN a.WTLB = 48 AND %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
                      AND  a.YSSL < 0					  
					  THEN 9999
					  WHEN a.WTLB = 48 AND %d{yyyyMMdd} < b.SSRQ 
                      AND  a.YSSL < 0					  
					  THEN 5555					  
					  WHEN a.WTLB = 66 	
                      AND  a.YSSL < 0					  
					  THEN 9999	
                      WHEN a.WTLB = 11 AND %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
                      AND  a.YSSL > 0					  
					  THEN 8888
					  WHEN a.WTLB = 11 AND %d{yyyyMMdd} < b.SSRQ 
                      AND  a.YSSL > 0					  
					  THEN 4444
					  WHEN a.WTLB = 11 AND %d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ
                      AND  a.YSSL < 0					  
					  THEN 9999
					  WHEN a.WTLB = 11 AND %d{yyyyMMdd} < b.SSRQ 
                      AND  a.YSSL < 0					  
					  THEN 5555
                      WHEN a.WTLB = 76
				      AND  a.CJSL > = 0 
					  AND  a.CJBH IN ('要约资金','要约/回售')
                      THEN 2					  
					  WHEN a.WTLB = 29                                       
                      AND  SUBSTR(a.ZQLB,1,1) = 'E'	
					  AND  n.ZQDM IS NULL
					  THEN 1111
					  WHEN a.WTLB = 30                                       
                      AND  SUBSTR(a.ZQLB,1,1) = 'E'	
					  AND  n.ZQDM IS NULL
					  THEN 2222
 					  ELSE a.WTLB
					  END  as WTLB  --委托类别
				,a.CJBH          --成交编号
				,a.CJRQ          --成交日期
				,a.JSRQ          --结束日期
				,CASE WHEN a.WTLB = 17
				      AND  a.CJSL = 0 
					  AND  f.ZQDM IS NOT NULL
					  THEN f.CJSL
					  WHEN a.WTLB = 76
				      AND  a.CJSL = 0 
					  AND  a.CJBH = '要约资金'
					  AND  m.ZQDM IS NOT NULL
					  THEN m.CJSL
					  ELSE a.CJSL
					  END as CJSL  --成交数量
                ,a.CJJG          --成交价格
				,a.JSJ           --结算费
				,a.LXJG          --利息价格
				,CASE WHEN a.WTLB = 11
                      THEN 0
					  ELSE a.CJJE
					  END   as CJJE--成交金额
				,a.LXJE          --利息金额
				,a.S1            --实收佣金
				,a.S2            --印花税
				,a.S3            --过户费
				,a.S4            --附加费
				,a.S5            --证管费
				,a.S6            --交易规费
                ,a.S11           --一级费用-经手费
                ,a.S12           --一级费用-证管费
                ,a.S13           --一级费用-过户费
                ,a.S15           --一级费用-结算费
                ,a.S16           --一级费用-风险基金
                ,CASE WHEN a.WTLB = 11
                      THEN 0
					  ELSE a.YSJE
					  END as YSJE          --收金额
				,a.YSSL                          
				,a.CZZD1         --操作终端
				,a.XTBS          --账户类别 
 FROM        EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP2  a
 LEFT JOIN      (   SELECT     NVL(a.JYS,b.JYS) as JYS
                              ,NVL(a.ZQDM,b.ZQDM) as ZQDM
							  ,LEAST(NVL(a.SSRQ,99999999),NVL(b.SSRQ,99999999)) as SSRQ
							  ,GREATEST(NVL(a.TSRQ,00000000),NVL(b.TSRQ,00000000)) as TSRQ
                    FROM      (SELECT JYS,ZQDM,SSRQ,TSRQ 
					           FROM EDW_PROD.T_EDW_T04_TSZQDM
							   WHERE BUS_DATE = %d{yyyyMMdd}
							   AND   CPLB IN (1,2,3,4,5,6,7,9)
							   AND   ZQDM NOT LIKE '%J'
							   ) a
			        FULL JOIN  (SELECT JYS,SUBSTR(ZQDM,1,6) as ZQDM,MIN(SSRQ) as SSRQ,MAX(TSRQ) as TSRQ,BUS_DATE FROM EDW_PROD.T_EDW_T04_TSZQDM
			                     WHERE CPLB = 5
				                 AND   ZQDM LIKE '%J'
								 AND BUS_DATE = %d{yyyyMMdd}
								 GROUP BY JYS,ZQDM,BUS_DATE
				                ) b
				    ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
				    AND          a.JYS = b.JYS			
                   )                              b
 ON          a.JYS = b.JYS
 AND         a.ZQDM = b.ZQDM
 LEFT JOIN  (SELECT KHH,JYS,ZQDM as ZQDM FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
             WHERE WTLB IN (83,41)
			 GROUP BY KHH,JYS,ZQDM
           )   c
 ON          a.JYS = c.JYS
 AND         a.ZQDM = c.ZQDM
 AND          a.KHH = c.KHH 
 LEFT JOIN  (SELECT KHH,JYS,ZQDM,BUS_DATE,CJSL,GDH FROM EDW_PROD.T_EDW_T05_TJGMXLS
             WHERE WTLB = 70
			 AND   BUS_DATE = %d{yyyyMMdd}
			 GROUP BY KHH,JYS,ZQDM,BUS_DATE,CJSL,GDH
           )   d
 ON           a.JYS = d.JYS
 AND          a.ZQDM = d.ZQDM
 AND          a.KHH = d.KHH 
 AND          a.GDH = d.GDH
 AND          a.CJSL = d.CJSL
 AND          a.WTLB = 31
  LEFT JOIN  (SELECT KHH,JYS,ZQDM,CJSL,GDH FROM EDW_PROD.T_EDW_T05_TJGMXLS
             WHERE WTLB = 17
			 AND   BUS_DATE = %d{yyyyMMdd}
			 GROUP BY KHH,JYS,ZQDM,CJSL,GDH
           )   e
 ON           a.JYS = e.JYS
 AND          a.ZQDM = e.ZQDM
 AND          a.KHH = e.KHH 
 AND          a.GDH = e.GDH
 AND          a.CJSL = e.CJSL
 AND          a.WTLB = 19
 LEFT JOIN (SELECT KHH,JYS,ZQDM,SUM(0-YSSL) as CJSL 
            FROM   EDW_PROD.T_EDW_T05_TJGMXLS
            WHERE  WTLB = 19 
			AND CJBH = '股份注销' 
			AND BUS_DATE = %d{yyyyMMdd}
			GROUP BY KHH,JYS,ZQDM
			) f
 ON    a.khh = f.khh
 AND   a.jys = f.jys
 AND   a.zqdm = f.zqdm
 LEFT JOIN (SELECT KHH,JYS,ZQDM,SUM(0-YSSL) as CJSL 
            FROM   EDW_PROD.T_EDW_T05_TJGMXLS
            WHERE  WTLB = 76 
			AND CJBH = '要约过户'  
			AND BUS_DATE = %d{yyyyMMdd}
			GROUP BY KHH,JYS,ZQDM
			) m
 ON    a.khh = m.khh
 AND   a.jys = m.jys
 AND   a.zqdm = m.zqdm
 LEFT JOIN (SELECT SecurityCode  as zqdm
            FROM   FUNDEXT.DBO_MF_FundArchives 
			WHERE  TYPE = 4 
			AND investmenttype = 7 
			AND  DT = '%d{yyyyMMdd}'
			GROUP BY SecurityCode
			) n 
 ON    a.WTLB IN (29,30)
 AND   SUBSTR(a.ZQLB,1,1) = 'E'
 AND   a.ZQDM = n.ZQDM
  LEFT JOIN (SELECT KHH,JYS,ZQDM 
            FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP2 
			WHERE   ZQDM1 LIKE '889%' 
			AND     WTLB  = 19
			AND     CJBH = '上市转出'
			GROUP BY KHH,JYS,ZQDM
			)  p
 ON a.KHH = p.KHH
 AND a.JYS = p.JYS
 AND a.ZQDM = p.ZQDM
 ;

 ------
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP4  ;
 CREATE TABLE EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP4 as
   SELECT        a.SEQNO         --事件序号
                ,a.WTH           --委托号
                ,a.KHH           --客户号           
                ,a.KHXM          --客户姓名          
                ,a.YYB           --营业部编号                                                
                ,a.GDH           --股东号
				,a.GDXM          --股东姓名
                ,a.JYS           --交易所
                ,a.BZDM          --币种代码
				,a.ZQLB          --证券类别
                ,a.ZQDM          --证券代码
                ,a.ZQDM1         --证券代码1
                ,a.ZQMC          --证券名称
                ,a.WTFS          --委托方式
                ,a.WTLB  --委托类别
				,a.CJBH          --成交编号
				,a.CJRQ          --成交日期
				,a.JSRQ          --结束日期
				,a.CJSL          --成交数量
                ,a.CJJG          --成交价格
				,a.JSJ           --结算费
				,a.LXJG          --利息价格
				,CASE WHEN b.CD IS NOT NULL
				      AND  a.CJSL > 0
					  AND  a.CJJE = 0
					  AND  a.WTLB IN (7,9,10,15,16,31,65,66,18,19,20,21,4444,5555,6666,7777,8888,9999)
					  THEN NVL(ROUND((b.NEWST_PRC+b.NEWST_INT*b.NETPRC_TRD_FLG)*b.TRD_UNIT*a.CJSL*NVL(e.zhhl,1),2),0)
					  WHEN b.CD IS NULL
					  AND  c.ZQDM IS NOT NULL
					  AND  a.CJSL > 0
					  AND  a.CJJE = 0
					  AND a.WTLB IN (7,9,10,15,16,31,65,66,18,19,20,21,4444,5555,6666,7777,8888,9999)
					  THEN NVL(c.FXJ*a.CJSL*NVL(e.zhhl,1),0)
					  WHEN b.CD IS NULL
					  AND  f.ZQDM IS NOT NULL
					  AND  a.CJSL > 0
					  AND  a.CJJE = 0
					  AND a.WTLB IN (7,9,10,15,16,31,65,66,18,19,20,21,4444,5555,6666,7777,8888,9999)
					  THEN NVL(f.FXJ*a.CJSL*NVL(e.zhhl,1),0)
					  WHEN a.CJSL > 0 
					  AND a.CJJE = 0 
					  AND ((a.JYS = 'SH' AND SUBSTR(a.ZQDM,1,3) IN ('501','502','500','505','506','519','510','511','512','513','518','515') )
                      OR (a.JYS = 'SZ' AND (SUBSTR(a.ZQDM,1,3) IN ('150','151','159','184') OR (SUBSTR(a.ZQDM,1,2) IN ('16')))))
					  AND b.CD IS NULL
                      AND c.ZQDM IS NULL
					  AND a.WTLB IN (7,9,10,15,16,31,65,66,18,19,20,21,4444,5555,6666,7777,8888,9999)
                      THEN a.CJSL*1
                      WHEN a.CJSL > 0 
					  AND a.CJJE = 0 
                      AND b.CD IS NULL
                      AND c.ZQDM IS NULL
					  AND d.ZQDM IS NOT NULL
					  THEN a.CJSL*d.JYDW*d.FXJ*NVL(e.zhhl,1)
                      ELSE a.CJJE 
					  END  as CJJE
				,a.LXJE          --利息金额
				,a.S1            --实收佣金
				,a.S2            --印花税
				,a.S3            --过户费
				,a.S4            --附加费
				,a.S5            --证管费
				,a.S6            --交易规费
                ,a.S11           --一级费用-经手费
                ,a.S12           --一级费用-证管费
                ,a.S13           --一级费用-过户费
                ,a.S15           --一级费用-结算费
                ,a.S16           --一级费用-风险基金
                ,a.YSJE          --收金额
				,a.YSSL                          
				,a.CZZD1         --操作终端
				,a.XTBS          --账户类别 
 FROM        EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP3  a
 LEFT JOIN   DDW_PROD.T_DDW_PUB_QOT                b
 ON          a.JYS = b.EXG
 AND         a.ZQDM = b.CD
 AND         b.trd_mkt = 1
 AND         b.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  (SELECT   SecuCode      as ZQDM
	                 ,MAX(IssuePrice)    as FXJ
					 ,CASE WHEN PreparedListExchange = 83
                    	   THEN 'SH'
						   WHEN PreparedListExchange = 90
						   THEN 'SZ'
						   END  as JYS 
			   FROM  fundext.dbo_LC_AShareIPO
			   WHERE DT = '%d{yyyyMMdd}'
               AND   PreparedListExchange IN (83,90)
               AND 	IssuePrice IS NOT NULL
               GROUP BY JYS,ZQDM			   
			   )     c
 ON       a.JYS = c.JYS
 AND      a.ZQDM = c.ZQDM
 LEFT JOIN ( SELECT        b.SECUCode                            as ZQDM
                          ,DECODE(b.secumarket,83,'SH',90,'SZ')  as JYS
		                  ,NVL(a.issueprice,100)                 as FXJ		 
                          ,CASE WHEN b.secumarket = 90
                                THEN 1
                                WHEN b.secumarket = 83 
								AND b.SECUCode = '009701'
                                THEN 1
                                ELSE 10 
                                END   as JYDW								
             FROM        FUNDEXT.DBO_Bond_Issue          a
             LEFT JOIN   fundext.dbo_BOND_CODE           b
             ON          a.INNERCODE = b.INNERCODE
             AND         b.DT = '%d{yyyyMMdd}'
			 WHERE       b.secumarket IN (83,90)
			 AND         a.DT = '%d{yyyyMMdd}'
	        )             d
 ON       a.JYS = d.JYS
 AND      a.ZQDM = d.ZQDM
 LEFT JOIN EDW_PROD.T_EDW_T99_HLZH e
 ON    a.JYS IN ('HK','SK')
 AND   e.BUS_DATE = %d{yyyyMMdd}
 AND   e.bzdm = 'HKD'
 LEFT JOIN  (SELECT   SecuCode      as ZQDM
	                 ,MAX(NVL(IssuePrice,0))    as FXJ
					 ,'SH'  as JYS 
			   FROM  FUNDEXT.DBO_LC_STIBIPOISSUE
			   WHERE DT = '%d{yyyyMMdd}'              
               AND 	IssuePrice IS NOT NULL
               GROUP BY JYS,ZQDM			   
			   )     f
 ON       a.JYS = f.JYS
 AND      a.ZQDM = f.ZQDM
 ;
 
 
 
 
 
 
 
 
 ----------插入上海基金为519认购代码41 加条81
  INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
         (                          SEQNO                    --事件序号
                                   ,WTH                      --委托号
                                   ,KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号
                                   ,GDXM                      --股东姓名							   
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额 
                                   ,YSSL                     --应收数量								   
                                   ,CZZD1                    --操作终端	
                                   ,XTBS                     --账户类别                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT                    SEQNO                                     as SEQNO 
                          ,WTH                                       as WTH
                          ,NVL(a1.KHH,t.KHH)                         as KHH                      --客户号                   
                          ,t.KHXM                                    as KHXM                    --客户姓名                 
                          ,t.YYB                                     as YYB                      --营业部编号                                                 
                          ,t.GDH                                     as GDH                    --股东号                  
                          ,t.GDXM                                    as GDXM
						  ,t.JYS                                     as JYS                         --交易所                                       
                          ,t.BZDM                                    as BZDM                       --币种代码                           
                          ,t.ZQLB                                    as ZQLB                      --证券类别                                  
                          ,EDW_PROD.CODE_TRANS_ZQDM(t.JYS,t.ZQDM)    as ZQDM                      --证券代码                 
                          ,t.ZQDM                                    as ZQDM1                      --证券代码1                
                          ,t.ZQMC                                    as ZQMC                     --证券名称                 
                          ,t.WTFS                                    as WTFS                      --委托方式                 
                          ,81                                        as WTLB                      --委托类别                 
                          ,'认购退保'                                as CJBH                      --成交编号                 
                          ,t.CJRQ                                    as CJRQ                      --成交日期                 
                          ,t.JSRQ                                    as JSRQ                     --结束日期
						  ,0                                         as CJSL                     --成交数量                 
                          ,t.CJJG                                    as CJJG                     --成交价格                 
                          ,t.JSJ                                     as JSJ                     --结算费                  
                          ,t.LXJG                                    as LXJG                      --利息价格                 
                          ,NVL(t.CJJE,0)+NVL(t.YSJE,0)               as CJJE                     --成交金额                 
                          ,t.LXJE                                    as LXJE                      --利息金额                 
                          ,0                                         as S1                           --实收佣金                 
                          ,0                                         as S2                           --印花税                   
                          ,t.S3                                      as S3                           --过户费                   
                          ,t.S4                                      as S4                           --附加费                   
                          ,t.S5                                      as S5                           --证管费                   
                          ,t.S6                                      as S6                           --交易规费                 
                          ,t.S11                                     as S11                          --一级费用-经手费          
                          ,t.S12                                     as S12                          --一级费用-证管费          
                          ,t.S13                                     as S13                          --一级费用-过户费          
                          ,t.S15                                     as S15                          --一级费用-结算费          
                          ,t.S16                                     as S16                          --一级费用-风险基金        
                          ,NVL(t.CJJE,0)+NVL(t.YSJE,0)               as YSJE                     --应收金额
                          ,0                                         as YSSL                     --应收数量						  
                          ,t.CZZD1                                   as CZZD1 
                          ,t.XTBS                                    as XTBS          						  
 FROM           EDW_PROD.T_EDW_T05_TJGMXLS       t
 LEFT JOIN      EDW_PROD.T_EDW_T99_TWYZZZH       a1
 ON             t.KHH = a1.WYZZKHH
 AND            a1.BUS_DATE = %d{yyyyMMdd}      
 WHERE          t.JYS = 'SH'
 AND            SUBSTR(t.ZQDM,1,3) = '519'
 AND            t.CJBH = '认购结果'
 AND            t.BUS_DATE = %d{yyyyMMdd}
 ;
 
 
 --------WTLB = 11的金额
 INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
         (                          SEQNO                    --事件序号
                                   ,WTH                      --委托号
                                   ,KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号
                                   ,GDXM                      --股东姓名							   
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额 
                                   ,YSSL                     --应收数量								   
                                   ,CZZD1                    --操作终端	
                                   ,XTBS                     --账户类别                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT                    SEQNO                                     as SEQNO 
                          ,WTH                                       as WTH
                          ,NVL(a1.KHH,t.KHH)                         as KHH                      --客户号                   
                          ,t.KHXM                                    as KHXM                    --客户姓名                 
                          ,t.YYB                                     as YYB                      --营业部编号                                                 
                          ,t.GDH                                     as GDH                    --股东号                  
                          ,t.GDXM                                    as GDXM
						  ,t.JYS                                     as JYS                         --交易所                                       
                          ,t.BZDM                                    as BZDM                       --币种代码                           
                          ,t.ZQLB                                    as ZQLB                      --证券类别                                  
                          ,EDW_PROD.CODE_TRANS_ZQDM(t.JYS,t.ZQDM)    as ZQDM                      --证券代码                 
                          ,t.ZQDM                                    as ZQDM1                      --证券代码1                
                          ,t.ZQMC                                    as ZQMC                     --证券名称                 
                          ,t.WTFS                                    as WTFS                      --委托方式                 
                          ,93                                        as WTLB                      --委托类别                 
                          ,CJBH                                      as CJBH                      --成交编号                 
                          ,t.CJRQ                                    as CJRQ                      --成交日期                 
                          ,t.JSRQ                                    as JSRQ                     --结束日期
						  ,0                                         as CJSL                     --成交数量                 
                          ,t.CJJG                                    as CJJG                     --成交价格                 
                          ,t.JSJ                                     as JSJ                     --结算费                  
                          ,t.LXJG                                    as LXJG                      --利息价格                 
                          ,t.CJJE                                    as CJJE                     --成交金额                 
                          ,t.LXJE                                    as LXJE                      --利息金额                 
                          ,0                                         as S1                           --实收佣金                 
                          ,0                                         as S2                           --印花税                   
                          ,t.S3                                      as S3                           --过户费                   
                          ,t.S4                                      as S4                           --附加费                   
                          ,t.S5                                      as S5                           --证管费                   
                          ,t.S6                                      as S6                           --交易规费                 
                          ,t.S11                                     as S11                          --一级费用-经手费          
                          ,t.S12                                     as S12                          --一级费用-证管费          
                          ,t.S13                                     as S13                          --一级费用-过户费          
                          ,t.S15                                     as S15                          --一级费用-结算费          
                          ,t.S16                                     as S16                          --一级费用-风险基金        
                          ,t.YSJE                                    as YSJE                     --应收金额
                          ,0                                         as YSSL                     --应收数量						  
                          ,t.CZZD1                                   as CZZD1 
                          ,t.XTBS                                    as XTBS          						  
 FROM           EDW_PROD.T_EDW_T05_TJGMXLS       t
 LEFT JOIN      EDW_PROD.T_EDW_T99_TWYZZZH       a1
 ON             t.KHH = a1.WYZZKHH
 AND            a1.BUS_DATE = %d{yyyyMMdd}      
 WHERE          t.WTLB = 11 AND t.CJJE >0
 AND            t.BUS_DATE = %d{yyyyMMdd}
 ;

-----插入定期折算A基金的转出
 INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
         (                          SEQNO                    --事件序号
                                   ,WTH                      --委托号
                                   ,KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号                  
                                   ,GDXM                     --股东姓名
								   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额 
                                   ,YSSL                     --应收数量								                                       
                                   ,CZZD1                    --操作终端
                                   ,XTBS                     --账户类别								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT       t.SEQNO       as SEQNO          --事件序号
            ,t.WTH         as WTH            --委托号
            ,t.KHH         as KHH            --客户号                              
            ,t.KHXM        as KHXM           --客户姓名                               
            ,t.YYB         as YYB            --营业部编号                                                                                    
            ,t.GDH         as GDH            --股东号
            ,t.GDXM        as GDXM           --股东姓名			
            ,t.JYS         as JYS            --交易所                   
            ,t.BZDM        as BZDM           --币种代码                   
            ,t.ZQLB        as ZQLB           --证券类别                     
            ,a1.JJDM       as ZQDM           --证券代码                  
            ,a1.JJDM       as ZQDM1          --证券代码1                   
            ,t.ZQMC        as ZQMC           --证券名称                  
            ,t.WTFS        as WTFS           --委托方式                       
            ,CASE WHEN t.WTLB = 8888
			      THEN 9999
				  ELSE 8888
				  END      as WTLB           --委托类别                   
            ,t.CJBH        as CJBH           --成交编号                   
            ,t.CJRQ        as CJRQ           --成交日期                     
            ,t.JSRQ        as JSRQ           --结束日期
			,0             as CJSL           --成交数量                   
            ,t.CJJG        as CJJG           --成交价格                   
            ,t.JSJ         as JSJ            --结算费                  
            ,t.LXJG        as LXJG           --利息价格                   
            ,CAST(t.CJJE as DECIMAL(38,2))        as CJJE           --成交金额                   
            ,t.LXJE        as LXJE           --利息金额                   
            ,t.S1          as S1             --实收佣金                   
            ,t.S2          as S2             --印花税                   
            ,t.S3          as S3             --过户费                   
            ,t.S4          as S4             --附加费                   
            ,t.S5          as S5             --证管费                   
            ,t.S6          as S6             --交易规费                   
            ,t.S11         as S11            --一级费用-经手费                   
            ,t.S12         as S12            --一级费用-证管费                   
            ,t.S13         as S13            --一级费用-过户费                   
            ,t.S15         as S15            --一级费用-结算费                  
            ,t.S16         as S16            --一级费用-风险基金                   
            ,t.YSJE	       as YSJE	         --应收金额 
            ,t.YSSL        as YSSL           --应收数量								                                       
            ,t.CZZD1       as CZZD1          --操作终端
            ,t.XTBS        as XTBS           --账户类别	
 FROM        EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP4  t
 LEFT JOIN   EDW_PROD.T_EDW_T04_TFXJJDM_LS    a1
 ON          t.ZQDM = a1.ZQDM
 AND         a1.JJFL = 1 
 AND         a1.BUS_DATE = %d{yyyyMMdd}
 WHERE       t.WTLB IN (8888,9999)
 AND         t.CJBH = '定期折算'
 ;
 
 ----插入数据
   INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
         (                          SEQNO                    --事件序号
                                   ,WTH                      --委托号
                                   ,KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号
                                   ,GDXM                      --股东姓名							   
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额 
                                   ,YSSL                     --应收数量								   
                                   ,CZZD1                    --操作终端	
                                   ,XTBS                     --账户类别                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT                    SEQNO                                     as SEQNO 
                          ,WTH                                       as WTH
                          ,NVL(a1.KHH,t.KHH)                         as KHH                      --客户号                   
                          ,t.KHXM                                    as KHXM                    --客户姓名                 
                          ,t.YYB                                     as YYB                      --营业部编号                                                 
                          ,t.GDH                                     as GDH                    --股东号                  
                          ,t.GDXM                                    as GDXM
						  ,t.JYS                                     as JYS                         --交易所                                       
                          ,t.BZDM                                    as BZDM                       --币种代码                           
                          ,t.ZQLB                                    as ZQLB                      --证券类别                                  
                          ,t.ZQDM                                    as ZQDM                      --证券代码                 
                          ,t.ZQDM1                                    as ZQDM1                      --证券代码1                
                          ,t.ZQMC                                    as ZQMC                     --证券名称                 
                          ,t.WTFS                                    as WTFS                      --委托方式                 
                          ,t.WTLB                                    as WTLB                      --委托类别                 
                          ,t.CJBH                                    as CJBH                      --成交编号                 
                          ,t.CJRQ                                    as CJRQ                      --成交日期                 
                          ,t.JSRQ                                    as JSRQ                     --结束日期
						  ,t.CJSL                                    as CJSL                     --成交数量                 
                          ,t.CJJG                                    as CJJG                     --成交价格                 
                          ,t.JSJ                                     as JSJ                     --结算费                  
                          ,t.LXJG                                    as LXJG                      --利息价格                 
                          ,CAST(CASE WHEN t.WTLB = 1111
						        AND  t.YSJE > 0
								THEN 0-t.YSJE
								WHEN t.WTLB = 2222
								AND  t.YSJE < 0
								THEN t.YSJE
								ELSE NVL(t.CJJE,0)
								END as DECIMAL(38,2)) 						         as CJJE                     --成交金额                 
                          ,t.LXJE                                    as LXJE                      --利息金额                 
                          ,t.S1                                      as S1                           --实收佣金                 
                          ,t.S2                                      as S2                           --印花税                   
                          ,t.S3                                      as S3                           --过户费                   
                          ,t.S4                                      as S4                           --附加费                   
                          ,t.S5                                      as S5                           --证管费                   
                          ,t.S6                                      as S6                           --交易规费                 
                          ,t.S11                                     as S11                          --一级费用-经手费          
                          ,t.S12                                     as S12                          --一级费用-证管费          
                          ,t.S13                                     as S13                          --一级费用-过户费          
                          ,t.S15                                     as S15                          --一级费用-结算费          
                          ,t.S16                                     as S16                          --一级费用-风险基金        
                          ,NVL(t.YSJE,0)                             as YSJE                     --应收金额
                          ,t.YSSL                                    as YSSL                     --应收数量						  
                          ,t.CZZD1                                   as CZZD1 
                          ,t.XTBS                                    as XTBS          						  
 FROM           EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP4       t
 LEFT JOIN      EDW_PROD.T_EDW_T99_TWYZZZH            a1
 ON             t.KHH = a1.WYZZKHH
 AND            a1.BUS_DATE = %d{yyyyMMdd}     
 ;
 -----------------基金上下折插入
  DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP5;
 CREATE TABLE EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP5
 as  SELECT        a.InfoType
               ,SUBSTR(b.SecurityCode,1,6) as ZQDM
		       ,CAST(CONCAt(substr(a.SplitDay,1,4),substr(a.SplitDay,6,2),substr(a.SplitDay,9,2) ) as INT) as SplitDay
			   ,CASE WHEN SUBSTR(b.SecurityCode,1,3) in ('519','501','502','503','500','505','506','510','511','512','513','518','515')
					 THEN 'SH'
					 WHEN SUBSTR(b.SecurityCode,1,3) IN ('159','160','161','162','163','164','165','166','167','168','169','184','150','151')
					 THEN 'SZ'
					 ELSE 'CWJJ'
					 END   as JYS	  
		       ,a.SplitType
			   ,a.splitratio
			   ,a.afsplitratio
		       ,CAST(CONCAt(substr(a.ChangeRegDate,1,4),substr(a.ChangeRegDate,6,2),substr(a.ChangeRegDate,9,2) ) as INT) as ChangeRegDate
 FROM       FUNDEXT.DBO_MF_SHARESSPLIT a
 LEFT JOIN  FUNDEXT.DBO_MF_FUNDARCHIVES b
 ON         a.INNERCODE = b.INNERCODE
 AND        b.DT = '%d{yyyyMMdd}'
 WHERE      a.DT = '%d{yyyyMMdd}'
 AND        a.InfoType IN (1) and a.SplitType in (5,6) 
 AND        CAST(CONCAt(substr(a.ChangeRegDate,1,4),substr(a.ChangeRegDate,6,2),substr(a.ChangeRegDate,9,2) ) as INT) IS NOT NULL
 ;
 
 
  DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP6;
 CREATE TABLE EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP6
 as SELECT
            t.ZQDM
		   ,t.JYS
		   ,CASE WHEN t.InfoType = 1 
		         AND  t.SplitType = 5
				 THEN '基金上折'
				 WHEN t.InfoType = 1 
		         AND  t.SplitType = 6
				 THEN '基金下折'
				 END  CJBH
		   ,t.splitratio
		   ,t.afsplitratio 
		   ,t.ChangeRegDate as BUS_DATE
		   ,CASE WHEN a1.ZQDM IS NOT NULL
		         THEN 0
				 WHEN a2.JJDM IS NOT NULL AND a1.ZQDM IS NULL
				 THEN a2.JJFL
				 END  as JJFL
		  ,NVL(a1.ZQDM,a2.ZQDM) as ZQDM_0
    FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP5 t
	LEFT JOIN (SELECT ZQDM FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS
	           WHERE BUS_DATE = %d{yyyyMMdd}
	           GROUP BY ZQDM
	           )      a1
	ON         t.ZQDM = a1.ZQDM
		LEFT JOIN (SELECT ZQDM,JJDM,JJFL FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS
	           WHERE BUS_DATE = %d{yyyyMMdd}
	           GROUP BY ZQDM,JJDM,JJFL
	           )      a2
	ON         t.ZQDM = a2.JJDM
	WHERE t.ChangeRegDate > 20140101
	;
   DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP7;
 CREATE TABLE EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP7
 as SELECT   
       MAX(DECODE(a.JJFL,0,a.splitratio,0))   as splitratio_0
      ,MAX(DECODE(a.JJFL,1,a.splitratio,0))	  as splitratio_1
      ,MAX(DECODE(a.JJFL,2,a.splitratio,0))	  as splitratio_2
	  ,MAX(DECODE(a.JJFL,0,a.afsplitratio,0))   as afsplitratio_0
      ,MAX(DECODE(a.JJFL,1,a.afsplitratio,0))	  as afsplitratio_1
      ,MAX(DECODE(a.JJFL,2,a.afsplitratio,0))	  as afsplitratio_2
      ,a.JYS       
	  ,MAX(DECODE(a.JJFL,1,a.ZQDM,'0'))	      as ZQDM_1
	  ,MAX(DECODE(a.JJFL,2,a.ZQDM,'0'))	      as ZQDM_2
	  ,a.CJBH
	  ,a.BUS_DATE
	  ,a.ZQDM_0  as ZQDM_0
 FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP6   a
 WHERE a.BUS_DATE = %d{yyyyMMdd}
 GROUP BY a.JYS,a.CJBH,a.BUS_DATE,a.ZQDM_0 ;
 
 ----基金上折
 INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
         (                          SEQNO                    --事件序号
                                   ,WTH                      --委托号
                                   ,KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号
                                   ,GDXM                      --股东姓名							   
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额 
                                   ,YSSL                     --应收数量								   
                                   ,CZZD1                    --操作终端	
                                   ,XTBS                     --账户类别                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd}  )
 SELECT                             NULL                     --事件序号
                                   ,NULL                     --委托号
                                   ,t.KHH                      --客户号                              
                                   ,t.KHXM                     --客户姓名                               
                                   ,t.YYB                      --营业部编号                                                                                    
                                   ,t.GDH                      --股东号
                                   ,NULL                     --股东姓名							   
                                   ,t.JYS                      --交易所                   
                                   ,t.BZDM                     --币种代码                   
                                   ,t.ZQLB                     --证券类别                     
                                   ,t.ZQDM                     --证券代码                  
                                   ,t.ZQDM as ZQDM1                    --证券代码1                   
                                   ,t.ZQMC                     --证券名称                  
                                   ,NULL                     --委托方式                       
                                   ,9999			         --委托类别                   
                                   ,'基金上折'               --成交编号                   
                                   ,NULL                     --成交日期                     
                                   ,NULL                     --结束日期
								   ,0     --成交数量                   
                                   ,0                     --成交价格                   
                                   ,0                      --结算费                  
                                   ,0                     --利息价格                   
                                   ,ROUND(CASE WHEN a2.BUS_DATE IS NOT NULL
								         THEN ROUND(ZQSL*(a2.afsplitratio_1-1),0)
								         WHEN a3.BUS_DATE IS NOT NULL
								         THEN ROUND(ZQSL*(a3.afsplitratio_2-1),0)
								         ELSE 0
										 END,2)              --成交金额                   
                                   ,0                     --利息金额                   
                                   ,0                       --实收佣金                   
                                   ,0                       --印花税                   
                                   ,0                       --过户费                   
                                   ,0                       --附加费                   
                                   ,0                       --证管费                   
                                   ,0                     --交易规费                   
                                   ,0                     --一级费用-经手费                   
                                   ,0                     --一级费用-证管费                   
                                   ,0                     --一级费用-过户费                   
                                   ,0                     --一级费用-结算费                  
                                   ,0                     --一级费用-风险基金                   
                                   ,0	                --应收金额 
                                   ,0                     --应收数量								   
                                   ,NULL                    --操作终端	
                                   ,t.XTBS                     --账户类别 
								 --  ,CAST(a1.TRD_DT as INT)   as BUS_DATE
FROM       EDW_PROD.T_EDW_T02_TZQGL      t
LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE   a1
ON         a1.BUS_DATE = %d{yyyyMMdd}
AND        a1.TRD_DT = a1.NAT_DT
AND        t.BUS_DATE = a1.lst_trd_d
LEFT JOIN  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP7 a2
ON         t.ZQDM = a2.ZQDM_1
AND        a1.TRD_DT = a2.BUS_DATE
AND        a2.zqdm_1 < > '0'
AND        a2.CJBH = '基金上折'
AND        t.JYS = a2.JYS
LEFT JOIN  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP7 a3
ON         t.ZQDM = a3.ZQDM_2
AND        a1.TRD_DT = a3.BUS_DATE
AND        a3.zqdm_1 < > '0'
AND        a3.CJBH = '基金上折'
AND        t.JYS = a3.JYS
WHERE   NVL(a2.BUS_DATE,a3.BUS_DATE) IS NOT NULL
AND     CAST(a1.TRD_DT as INT) = %d{yyyyMMdd} ;

INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
         (                          SEQNO                    --事件序号
                                   ,WTH                      --委托号
                                   ,KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号
                                   ,GDXM                      --股东姓名							   
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额 
                                   ,YSSL                     --应收数量								   
                                   ,CZZD1                    --操作终端	
                                   ,XTBS                     --账户类别                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd} )
 SELECT                             NULL                     --事件序号
                                   ,NULL                     --委托号
                                   ,t.KHH                      --客户号                              
                                   ,t.KHXM                     --客户姓名                               
                                   ,t.YYB                      --营业部编号                                                                                    
                                   ,t.GDH                      --股东号
                                   ,NULL                     --股东姓名							   
                                   ,t.JYS                      --交易所                   
                                   ,t.BZDM                     --币种代码                   
                                   ,t.ZQLB                     --证券类别                     
                                   ,NVL(a2.ZQDM_0,a3.ZQDM_0) as ZQDM                     --证券代码                  
                                   ,NVL(a2.ZQDM_0,a3.ZQDM_0) as ZQDM1                    --证券代码1                   
                                   ,t.ZQMC                     --证券名称                  
                                   ,NULL                     --委托方式                       
                                   ,8888			         --委托类别                   
                                   ,'基金上折'               --成交编号                   
                                   ,NULL                     --成交日期                     
                                   ,NULL                     --结束日期
								   ,0     --成交数量                   
                                   ,0                     --成交价格                   
                                   ,0                      --结算费                  
                                   ,0                     --利息价格                   
                                   ,ROUND(CASE WHEN a2.BUS_DATE IS NOT NULL
								         THEN ROUND(ZQSL*(a2.afsplitratio_1-1),0)
								         WHEN a3.BUS_DATE IS NOT NULL
								         THEN ROUND(ZQSL*(a3.afsplitratio_2-1),0)
								         ELSE 0
										 END,2)               --成交金额                   
                                   ,0                     --利息金额                   
                                   ,0                       --实收佣金                   
                                   ,0                       --印花税                   
                                   ,0                       --过户费                   
                                   ,0                       --附加费                   
                                   ,0                       --证管费                   
                                   ,0                     --交易规费                   
                                   ,0                     --一级费用-经手费                   
                                   ,0                     --一级费用-证管费                   
                                   ,0                     --一级费用-过户费                   
                                   ,0                     --一级费用-结算费                  
                                   ,0                     --一级费用-风险基金                   
                                   ,0	                --应收金额 
                                   ,0                     --应收数量								   
                                   ,NULL                    --操作终端	
                                   ,t.XTBS                     --账户类别 
								  -- ,CAST(a1.TRD_DT as INT)  as BUS_DATE
FROM       EDW_PROD.T_EDW_T02_TZQGL      t
LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE   a1
ON         a1.BUS_DATE = %d{yyyyMMdd}
AND        a1.TRD_DT = a1.NAT_DT
AND        t.BUS_DATE = a1.lst_trd_d
LEFT JOIN  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP7 a2
ON         t.ZQDM = a2.ZQDM_1
AND        a1.TRD_DT = a2.BUS_DATE
AND        a2.zqdm_1 < > '0'
AND        a2.CJBH = '基金上折'
AND        t.JYS = a2.JYS
LEFT JOIN  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP7 a3
ON         t.ZQDM = a3.ZQDM_2
AND        a1.TRD_DT = a3.BUS_DATE
AND        a3.zqdm_1 < > '0'
AND        a3.CJBH = '基金上折'
AND        t.JYS = a3.JYS
WHERE   NVL(a2.BUS_DATE,a3.BUS_DATE) IS NOT NULL
AND     CAST(a1.TRD_DT as INT) = %d{yyyyMMdd} ;




------------------------基金下折
INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
         (                          SEQNO                    --事件序号
                                   ,WTH                      --委托号
                                   ,KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号
                                   ,GDXM                      --股东姓名							   
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额 
                                   ,YSSL                     --应收数量								   
                                   ,CZZD1                    --操作终端	
                                   ,XTBS                     --账户类别                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd} )
 SELECT                             NULL                     --事件序号
                                   ,NULL                     --委托号
                                   ,t.KHH                      --客户号                              
                                   ,t.KHXM                     --客户姓名                               
                                   ,t.YYB                      --营业部编号                                                                                    
                                   ,t.GDH                      --股东号
                                   ,NULL                     --股东姓名							   
                                   ,t.JYS                      --交易所                   
                                   ,t.BZDM                     --币种代码                   
                                   ,t.ZQLB                     --证券类别                     
                                   ,t.ZQDM                     --证券代码                  
                                   ,t.ZQDM as ZQDM1                    --证券代码1                   
                                   ,t.ZQMC                     --证券名称                  
                                   ,NULL                     --委托方式                       
                                   ,9999			         --委托类别                   
                                   ,'基金下折'               --成交编号                   
                                   ,NULL                     --成交日期                     
                                   ,NULL                     --结束日期
								   ,0     --成交数量                   
                                   ,0                     --成交价格                   
                                   ,0                      --结算费                  
                                   ,0                     --利息价格                   
                                   ,ROUND(CASE WHEN a2.BUS_DATE IS NOT NULL
								         THEN ROUND(ZQSL*a2.afsplitratio_1-ZQSL*a2.afsplitratio_2,0)						         
								         ELSE 0
										 END,2)              --成交金额                   
                                   ,0                     --利息金额                   
                                   ,0                       --实收佣金                   
                                   ,0                       --印花税                   
                                   ,0                       --过户费                   
                                   ,0                       --附加费                   
                                   ,0                       --证管费                   
                                   ,0                     --交易规费                   
                                   ,0                     --一级费用-经手费                   
                                   ,0                     --一级费用-证管费                   
                                   ,0                     --一级费用-过户费                   
                                   ,0                     --一级费用-结算费                  
                                   ,0                     --一级费用-风险基金                   
                                   ,0	                --应收金额 
                                   ,0                     --应收数量								   
                                   ,NULL                    --操作终端	
                                   ,t.XTBS                     --账户类别 
								 --,CAST(a1.TRD_DT as INT)   as BUS_DATE
FROM       EDW_PROD.T_EDW_T02_TZQGL      t
LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE   a1
ON         a1.BUS_DATE = %d{yyyyMMdd}
AND        a1.TRD_DT = a1.NAT_DT
AND        t.BUS_DATE = a1.lst_trd_d
LEFT JOIN  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP7 a2
ON         t.ZQDM = a2.ZQDM_1
AND        a1.TRD_DT = a2.BUS_DATE
AND        a2.zqdm_1 < > '0'
AND        a2.CJBH = '基金下折'
AND        t.JYS = a2.JYS
WHERE   a2.BUS_DATE IS NOT NULL
AND      a1.TRD_DT  = %d{yyyyMMdd};



INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
         (                          SEQNO                    --事件序号
                                   ,WTH                      --委托号
                                   ,KHH                      --客户号                              
                                   ,KHXM                     --客户姓名                               
                                   ,YYB                      --营业部编号                                                                                    
                                   ,GDH                      --股东号
                                   ,GDXM                      --股东姓名							   
                                   ,JYS                      --交易所                   
                                   ,BZDM                     --币种代码                   
                                   ,ZQLB                     --证券类别                     
                                   ,ZQDM                     --证券代码                  
                                   ,ZQDM1                    --证券代码1                   
                                   ,ZQMC                     --证券名称                  
                                   ,WTFS                     --委托方式                       
                                   ,WTLB                     --委托类别                   
                                   ,CJBH                     --成交编号                   
                                   ,CJRQ                     --成交日期                     
                                   ,JSRQ                     --结束日期
								   ,CJSL                     --成交数量                   
                                   ,CJJG                     --成交价格                   
                                   ,JSJ                      --结算费                  
                                   ,LXJG                     --利息价格                   
                                   ,CJJE                     --成交金额                   
                                   ,LXJE                     --利息金额                   
                                   ,S1                       --实收佣金                   
                                   ,S2                       --印花税                   
                                   ,S3                       --过户费                   
                                   ,S4                       --附加费                   
                                   ,S5                       --证管费                   
                                   ,S6                       --交易规费                   
                                   ,S11                      --一级费用-经手费                   
                                   ,S12                      --一级费用-证管费                   
                                   ,S13                      --一级费用-过户费                   
                                   ,S15                      --一级费用-结算费                  
                                   ,S16                      --一级费用-风险基金                   
                                   ,YSJE	                --应收金额 
                                   ,YSSL                     --应收数量								   
                                   ,CZZD1                    --操作终端	
                                   ,XTBS                     --账户类别                                   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd}  )
 SELECT                             NULL                     --事件序号
                                   ,NULL                     --委托号
                                   ,t.KHH                      --客户号                              
                                   ,t.KHXM                     --客户姓名                               
                                   ,t.YYB                      --营业部编号                                                                                    
                                   ,t.GDH                      --股东号
                                   ,NULL                     --股东姓名							   
                                   ,t.JYS                      --交易所                   
                                   ,t.BZDM                     --币种代码                   
                                   ,t.ZQLB                     --证券类别                     
                                   ,a2.ZQDM_0 as ZQDM                     --证券代码                  
                                   ,a2.ZQDM_0 as ZQDM1                    --证券代码1                   
                                   ,t.ZQMC                     --证券名称                  
                                   ,NULL                     --委托方式                       
                                   ,8888			         --委托类别                   
                                   ,'基金下折'               --成交编号                   
                                   ,NULL                     --成交日期                     
                                   ,NULL                     --结束日期
								   ,0     --成交数量                   
                                   ,0                     --成交价格                   
                                   ,0                      --结算费                  
                                   ,0                     --利息价格                   
                                   ,ROUND(CASE WHEN a2.BUS_DATE IS NOT NULL
								         THEN ROUND(ZQSL*a2.afsplitratio_1-ZQSL*a2.afsplitratio_2,0)						         
								         ELSE 0
										 END,2)               --成交金额                   
                                   ,0                     --利息金额                   
                                   ,0                       --实收佣金                   
                                   ,0                       --印花税                   
                                   ,0                       --过户费                   
                                   ,0                       --附加费                   
                                   ,0                       --证管费                   
                                   ,0                     --交易规费                   
                                   ,0                     --一级费用-经手费                   
                                   ,0                     --一级费用-证管费                   
                                   ,0                     --一级费用-过户费                   
                                   ,0                     --一级费用-结算费                  
                                   ,0                     --一级费用-风险基金                   
                                   ,0	                --应收金额 
                                   ,0                     --应收数量								   
                                   ,NULL                    --操作终端	
                                   ,t.XTBS                     --账户类别 
								  -- ,CAST(a1.TRD_DT as INT)  as BUS_DATE
FROM       EDW_PROD.T_EDW_T02_TZQGL      t
LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE   a1
ON         a1.BUS_DATE = %d{yyyyMMdd}
AND        a1.TRD_DT = a1.NAT_DT
AND        t.BUS_DATE = a1.lst_trd_d
LEFT JOIN  EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP7 a2
ON         t.ZQDM = a2.ZQDM_1
AND        a1.TRD_DT = a2.BUS_DATE
AND        a2.zqdm_1 < > '0'
AND        a2.CJBH = '基金下折'
AND        t.JYS = a2.JYS
WHERE      a2.BUS_DATE IS NOT NULL
AND      a1.TRD_DT  = %d{yyyyMMdd};
 
----删除临时表 
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP1  ;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP0  ;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP2  ;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP3  ;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP4  ;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP_TEMP  ;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP5  ;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP6  ;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW_TEMP7  ;
 
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TJGMXLS_XZB_NEW',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW;
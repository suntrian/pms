 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:开户报表_普通账户_营业部表                                                      */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-11-14                                                                        */ 

------期初创建临时表1  
 INSERT OVERWRITE DDW_PROD.T_DDW_PRT_ORDI_OPNAC_ACCNT_BRH
 (
                                    FILIL_NAME                --分公司
								   ,BRH_NO                   --营业部编码
								   ,BRH_NAME                 --营业部名称 
                                   ,STRT_CUST_ACTA           --期初客户数								   
                                   ,FNL_CUST_ACTA            --期末客户数
								   ,OPNAC_ACTA               --开户数
								   ,CNCLACT_ACTA             --销户数
								   ,T3IP_SIGN_ACTA           --三方签约客户数
								   ,T3IP_UN_SIGN_ACTA        --三方未签约客户数
								   ,N_QLFD_ACTA              --不合格客户数
								   ,SLEEP_ACTA               --休眠客户数
								   ,UN_MG_ACTA               --非经账户
								   ,CNTR_OPNAC_ACTA          --柜台开户客户数
								   ,ONLINE_OPNAC_ACTA        --网上开户客户数
								   ,TV_WTNS_OPNAC_ACTA       --视频见证开户客户数
								   ,TWO_PSN_OPNAC_ACTA       --双人见证开户客户数							
                                   ,DATA_SRC                 --数据来源                     
) 
PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT 
                                    a1.BELTO_FILIL     as FILIL_NAME                --分公司
								   ,t.YYB              as BRH_NO                   --营业部编码
								   ,a1.BRH_SHRTNM      as BRH_NAME                 --营业部名称   
                                   ,SUM(CASE WHEN t.DT = '%d{yyyyMMdd}'
								             THEN 0
										     ELSE 1
										     END
									   )              as STRT_CUST_ACTA                --期末客户数								   
                                   ,SUM(CASE WHEN t.DT = '%d{yyyyMMdd}'
								             AND  t.KHZT < > 3
								             THEN 1
										     ELSE 0
										     END
									   )              as FNL_CUST_ACTA                --期末客户数
								   ,SUM(CASE WHEN t.KHRQ = %d{yyyyMMdd}
								             AND t.DT = '%d{yyyyMMdd}'
								             THEN 1
										     ELSE 0
										     END
									   )               as OPNAC_ACTA               --开户数
								   ,SUM(CASE WHEN t.XHRQ = %d{yyyyMMdd}
								             AND t.DT = '%d{yyyyMMdd}'
								             AND  t.KHZT = 3
								             THEN 1
										     ELSE 0
										     END
									   )               as CNCLACT_ACTA             --销户数
								   ,SUM(CASE WHEN t.KHZT NOT IN (3,99)
								             AND t.DT = '%d{yyyyMMdd}'
								             THEN 1
										     ELSE 0
										     END
									   )               as T3IP_SIGN_ACTA           --三方签约客户数
								   ,SUM(CASE WHEN t.KHZT = 99
								             AND t.DT = '%d{yyyyMMdd}'
								             THEN 1
										     ELSE 0
										     END
									   )               as T3IP_UN_SIGN_ACTA        --三方未签约客户数
								   ,SUM(CASE WHEN t.KHZT < > 3
								             AND  t.FXJB NOT IN (0,1,2,8,19,7,10,20)
											 AND t.DT = '%d{yyyyMMdd}'
								             THEN 1
										     ELSE 0
										     END
									   )               as N_QLFD_ACTA              --不合格客户数
								   ,SUM(CASE WHEN t.KHZT < > 3
								             AND  t.FXJB  IN (7,10)
											 AND t.DT = '%d{yyyyMMdd}'
								             THEN 1
										     ELSE 0
										     END
									   )                as SLEEP_ACTA               --休眠客户数
								   ,SUM(CASE WHEN t.KHZT < > 3
								             AND  t.FXJB  IN (20)
											 AND t.DT = '%d{yyyyMMdd}'
								             THEN 1
										     ELSE 0
										     END
									   )                as UN_MG_ACTA               --非经账户
								   ,SUM(CASE WHEN a3.KHFS = 1
								             AND t.DT = '%d{yyyyMMdd}'
								             THEN 1
										     ELSE 0
										     END
									   )               as CNTR_OPNAC_ACTA          --柜台开户客户数
								   ,SUM(CASE WHEN a3.KHFS = 3
								             AND t.DT = '%d{yyyyMMdd}'
								             THEN 1
										     ELSE 0
										     END
									   )               as ONLINE_OPNAC_ACTA        --网上开户客户数
								   ,SUM(CASE WHEN a3.KHFS = 2
								             AND t.DT = '%d{yyyyMMdd}'
								             THEN 1
										     ELSE 0
										     END
									   )               as TV_WTNS_OPNAC_ACTA       --视频见证开户客户数
								   ,SUM(CASE WHEN a3.KHFS = 4
								             AND t.DT = '%d{yyyyMMdd}'
								             THEN 1
										     ELSE 0
										     END
									   )               as TWO_PSN_OPNAC_ACTA       --双人见证开户客户数							
                                   ,'所有客户'         as DATA_SRC                 --数据来源                    
 FROM       JZJYCX.DATACENTER_TKHXX  t
 INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH   a1
 ON         t.YYB = a1.BRH_NO
 AND        a1.BUS_DATE = %d{yyyyMMdd}
 INNER JOIN  EDW_PROD.T_EDW_T99_TRD_DATE a2
 ON         a2.TRD_DT = %d{yyyyMMdd}
 AND        a2.NAT_DT = a2.TRD_DT
 AND        a2.BUS_DATE = %d{yyyyMMdd}
 AND        CAST(t.DT as INT) > = a2.LST_TRD_D
 AND        CAST(t.DT as INT) < = a2.TRD_DT
 INNER JOIN YGTCX.CIF_TKHXX    a3
 ON         t.KHH = a3.KHH
 AND        a3.DT = '%d{yyyyMMdd}'
 WHERE      t.khh NOT IN ('100610335855')
 AND        t.KHRQ IS NOT NULL 
 GROUP BY FILIL_NAME
          ,BRH_NO    
          ,BRH_NAME 
		  ,DATA_SRC ;
 
-----------------------加载结束----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_ORDI_OPNAC_ACCNT_BRH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_ORDI_OPNAC_ACCNT_BRH ; 
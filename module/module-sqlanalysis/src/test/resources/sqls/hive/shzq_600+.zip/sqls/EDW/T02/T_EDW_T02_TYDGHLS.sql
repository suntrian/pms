 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:约定购回历史表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
--------插入数据开始-----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TYDGHLS
(
                                    RQ                                  --日期                                 
                                   ,YDGH_BH                             --约定购回编号                             
                                   ,XYBH                                --协议编号                               
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,CJSL                                --成交数量                               
                                   ,CJJE                                --成交金额                               
                                   ,YGHJE                               --购回金额                               
                                   ,JSJE                                --初始交易金额                             
                                   ,CJRQ                                --初始交易日期                             
                                   ,QSRQ                                --初始清算日期                             
                                   ,YDYSZ                               --抵押市值                               
                                   ,WTH                                 --委托号                                
                                   ,SBWTH                               --申报委托号                              
                                   ,CJBH                                --成交编号                               
                                   ,JSBZ                                --交收标志                               
                                   ,YYJGHRQ                             --预计购回日期                             
                                   ,GHRQ                                --购回日期                               
                                   ,JSRQ                                --交收日期                               
                                   ,WTLB                                --委托类别                               
                                   ,YGHJG                               --购回价格                               
                                   ,QYBH                                --权益编号                               
                                   ,QYDJRQ                              --权益登记日                              
                                   ,SBXW                                --申报席位                               
                                   ,SYBZ                                --顺延标志                               
                                   ,LYJBL                               --履约金比例                              
                                   ,STEP                                --STEP字段     
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
select 
                                    t.RQ                                  as RQ                                  --日期                                  
                                   ,t.BH                                  as YDGH_BH                             --编号                                  
                                   ,t.XYBH                                as XYBH                                --协议编号                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.CJSL                                as CJSL                                --成交数量                                
                                   ,t.CJJE                                as CJJE                                --成交金额                                
                                   ,t.GHJE                                as YGHJE                               --购回金额                                
                                   ,t.JSJE                                as JSJE                                --初始交易金额                              
                                   ,t.CJRQ                                as CJRQ                                --初始交易日期                              
                                   ,t.QSRQ                                as QSRQ                                --初始清算日期                              
                                   ,t.DYSZ                                as YDYSZ                               --抵押市值                                
                                   ,t.WTH                                 as WTH                                 --委托号                                 
                                   ,t.SBWTH                               as SBWTH                               --申报委托号                               
                                   ,t.CJBH                                as CJBH                                --成交编号                                
                                   ,t.JSBZ                                as JSBZ                                --交收标志                                
                                   ,t.YJGHRQ                              as YYJGHRQ                             --预计购回日期                              
                                   ,t.GHRQ                                as GHRQ                                --购回日期                                
                                   ,t.JSRQ                                as JSRQ                                --交收日期                                
                                   ,t.WTLB                                as WTLB                                --委托类别                                
                                   ,t.GHJG                                as YGHJG                               --购回价格                                
                                   ,t.QYBH                                as QYBH                                --权益编号                                
                                   ,t.QYDJRQ                              as QYDJRQ                              --权益登记日                               
                                   ,t.SBXW                                as SBXW                                --申报席位                                
                                   ,t.SYBZ                                as SYBZ                                --顺延标志                                
                                   ,t.LYJBL                               as LYJBL                               --履约金比例                               
                                   ,t.STEP                                as STEP                                --STEP字段    
                                   ,'JZJY'                                as XTBS								   
 FROM          JZJYCX.DATACENTER_TYDGHLS       t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'JZJY'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE         t.DT = '%d{yyyyMMdd}';
----插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TYDGHLS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TYDGHLS;
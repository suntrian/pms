------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户生命周期                                                                  */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2018-11-16 

ALTER  TABLE  DDW_PROD.T_DDW_CUST_LCS_STATAS DROP IF EXISTS PARTITION(BUS_DATE = %d{yyyyMMdd});

---------------
DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP  ;
CREATE TABLE DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP as
SELECT   t.CUST_NO
        ,t.OPNAC_DT
		,t.CUST_STAT
		,CASE WHEN t.CNCLACT_DT < = 19000101
		      THEN NULL
			  WHEN t.CUST_STAT <> '3'
			  THEN NULL
			  ELSE t.CNCLACT_DT
			  END  as CNCLACT_DT
        ,t.FSTTM_DT_AST_1000
        ,t.CRD_OPNAC_DT
        ,t.WRNT_OPNAC_DT
        ,t.H_K_OPNAC_DT
		,t.STR_FND_OPNAC_DT
		,t.REPO_MRGNS_OPNAC_DT
		,t.CASH_PROD_OPNAC_DT
		,t.CASH_PROD_FSTTM_TRD_DT
		,t.QOT_REPO_OPNAC_DT
		,t.NEW_T3BOD_OPNAC_DT
		,t.BOND_QLFD_IVSM_OPNAC_DT
		,t.STIB_OPNAC_DT
		,t.RSK_BEAR_ABLTY
		,t.SH_WRNT_OPNAC_DT
		,t.SZ_WRNT_OPNAC_DT
		,t.NEW_T3BOD_OPNAC_DT_1
	    ,t.NEW_T3BOD_OPNAC_DT_2
	    ,t.NEW_T3BOD_OPNAC_DT_3
		,t.RGST_GEM_OPNAC_DT
		,a4.JJQY
        ,NVL(a1.SBZJ,99999999)     as SBZJ
        ,NVL(a11.LRJH,99999999)     as LRJH
        ,NVL(a2.GGJH,99999999)     as GGJH
        ,NVL(a2.FJJJJH,99999999)   as FJJJJH
        ,NVL(a2.HGJH,99999999)     as HGJH 
        ,NVL(a2.KCBJH,99999999)    as KCBJH
        ,NVL(a3.JJJH,99999999)	   as JJJH
		,NVL(a5.TZZPDRQ,99999999)  as TZZPDRQ
		,NVL(a6.CPRQ,99999999)     as CPRQ
		,NVL(a7.BDRQ,99999999)     as BDRQ
		,NVL(a8.HSQQJH,99999999)   as HSQQJH
		,NVL(a8.SSQQJH,99999999)   as SSQQJH
		,NVL(a9.ZJGMRQ,99999999)   as ZJGMRQ
		,NVL(a10.BDRQ,99999999)     as XMBDRQ
FROM (SELECT  CUST_NO
             ,OPNAC_DT
			 ,CUST_STAT
			 ,CNCLACT_DT
			 ,FSTTM_DT_AST_1000
			 ,CRD_OPNAC_DT
			 ,WRNT_OPNAC_DT
			 ,H_K_OPNAC_DT
			 ,STR_FND_OPNAC_DT
			 ,REPO_MRGNS_OPNAC_DT
			 ,CASH_PROD_OPNAC_DT
			 ,CASH_PROD_FSTTM_TRD_DT
			 ,QOT_REPO_OPNAC_DT
			 ,NEW_T3BOD_OPNAC_DT
			 ,BOND_QLFD_IVSM_OPNAC_DT
			 ,STIB_OPNAC_DT
			 ,RSK_BEAR_ABLTY
			 ,SH_WRNT_OPNAC_DT
			 ,SZ_WRNT_OPNAC_DT
			 ,NEW_T3BOD_OPNAC_DT_1
			 ,NEW_T3BOD_OPNAC_DT_2
			 ,NEW_T3BOD_OPNAC_DT_3
			 ,RGST_GEM_OPNAC_DT
      FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL
	  WHERE BUS_DATE = %d{yyyyMMdd}
	  --AND   CUST_STAT = '0'
     )                        t
LEFT JOIN (SELECT   KHH as CUST_NO
                   ,MIN(BUS_DATE) AS SBZJ 
          FROM     EDW_PROD.T_EDW_T05_TZJMXLS
		  WHERE    SUBSTR(YWKM,1,3) = '101'
		  AND      BUS_DATE < = %d{yyyyMMdd}
		  GROUP BY KHH
		  ) a1
ON     t.CUST_NO = a1.CUST_NO
LEFT JOIN (SELECT     KHH
                     ,MIN(CASE WHEN a.WTLB IN (61,62,63,64,71,72)
					           AND a.XTBS = 'RZRQ'
						       THEN a.CJRQ
						       ELSE 99999999
						       END 
						 ) as LRJH
					,MIN(CASE WHEN a.WTLB IN (1,2)
					          AND a.XTBS = 'JZJY'
						      AND a.JYS IN ('HK','SK')
							  THEN a.CJRQ
						      ELSE 99999999
						      END 
						 ) as GGJH
					,MIN(CASE WHEN a.WTLB IN (1,2,41,42,43,62,80,81,83)					          
						      AND a.JYS IN ('SH','SZ')
							  AND b.ZQDM IS NOT NULL
							  THEN a.CJRQ
							  WHEN a.WTLB IN (1,2,41,42,43,62,80,81,83)					          
						      AND a.JYS IN ('SH','SZ')
							  AND c.ZQDM IS NOT NULL
							  THEN a.CJRQ
						      ELSE 99999999
						      END 
						 ) as FJJJJH
					,MIN(CASE WHEN a.WTLB = 5
					          AND  SUBSTR(a.ZQLB,1,1) = 'H'
							  THEN a.CJRQ
							  
						      ELSE 99999999
						      END
					    ) as HGJH
					,MIN(CASE WHEN a.JYS = 'SH'
                              AND SUBSTR(a.ZQDM,1,3) IN ('688','689')
                              AND a.WTLB IN (1,2,57,58,59,60,61,62,63,64,71,72,78,79,178,179) 
	                          THEN a.CJRQ
						      ELSE 99999999
						      END
	                     ) as KCBJH
           FROM       EDW_PROD.T_EDW_T05_TJGMXLS a
		   LEFT JOIN (SELECT ZQDM FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS WHERE JSRQ = 99999999 AND BUS_DATE = %d{yyyyMMdd} GROUP BY ZQDM) b
		   ON        a.ZQDM = b.ZQDM
		   AND       SUBSTR(a.ZQLB,1,1) IN ('L','E','J','T')
		   LEFT JOIN (SELECT JJDM as ZQDM FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS WHERE JSRQ = 99999999 AND BUS_DATE = %d{yyyyMMdd} GROUP BY ZQDM) c
		   ON        a.ZQDM = c.ZQDM
		   AND       SUBSTR(a.ZQLB,1,1) IN ('L','E','J','T')
		   WHERE      a.JYS IN ('HK','SK','SH','SZ')
		   AND        a.WTLB IN(1,2,61,62,63,64,71,72,41,42,43,80,81,83,5,57,58,59,60,78,79,178,179)
		   AND        a.CJJE > 0
		   AND      a.BUS_DATE < = %d{yyyyMMdd}
		   GROUP BY   a.KHH
		   ) a2
ON  t.CUST_NO = a2.KHH
LEFT JOIN (SELECT     KHH,MIN(QRRQ) AS JJJH
           FROM       EDW_PROD.T_EDW_T05_TOF_JJJGLS T1
		   WHERE      YWDM LIKE '139%'
		   AND        QRJE > 0
		   AND        BUS_DATE < = %d{yyyyMMdd}
		   GROUP BY   KHH
		   ) a3	
ON  t.CUST_NO = a3.KHH	
LEFT JOIN  (SELECT KHH,MIN(NVL(KSRQ,20140101)) AS JJQY
           FROM   EDW_PROD.T_EDW_T02_TOF_DQDESGXY
		   WHERE  BUS_DATE = %d{yyyyMMdd}
		   GROUP  BY KHH
		   )   a4
ON  t.CUST_NO = a4.KHH
LEFT JOIN (SELECT KHH,MIN(TZZPDRQ) AS TZZPDRQ
            FROM EDW_PROD.T_EDW_T99_TKHYWSX
            WHERE GT_TZZFLDM <> '0'
			GROUP BY KHH
			) a5
ON t.CUST_NO = a5.KHH
LEFT JOIN (SELECT KHH,MIN(CPRQ) AS CPRQ
            FROM EDW_PROD.T_EDW_T99_TKHSDX
		    WHERE SDXLBDM = 'JJFXCSNL'
            AND   CPDJ = 11
			GROUP BY KHH
			)   a6
ON   t.CUST_NO = a6.KHH
LEFT JOIN (SELECT KHH,MIN(BDRQ) AS BDRQ
            FROM JZJYCX.GFZHGL_TZJZH
            WHERE BDRQ <> 0
			AND   DT = '%d{yyyyMMdd}'
			GROUP BY KHH
			) a7
ON   t.CUST_NO = a7.KHH
LEFT JOIN (SELECT KHH
                 ,MIN(CASE WHEN JYS = 'SH'
                           THEN CJRQ
						   ELSE 99999999
						   END
				     ) AS HSQQJH
				 ,MIN(CASE WHEN JYS = 'SZ'
                           THEN CJRQ
						   ELSE 99999999
						   END
				     ) AS SSQQJH
           FROM   EDW_PROD.T_EDW_T05_TSO_JGMXLS
		   WHERE  SOP_MMFX IN ('1','2')
		   AND    SOP_KPCBZ IN ('O','C')
		   AND    CJJE > 0
		   AND    JYS IN ('SH','SZ')
		   AND        BUS_DATE < = %d{yyyyMMdd}
		   GROUP BY KHH
		   )	 a8
ON   t.CUST_NO = a8.KHH	
LEFT JOIN (SELECT CUST_NO,MAX(CNFM_DT) as ZJGMRQ
           FROM DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS
		   WHERE IF_TRD = 1
		   AND   CNFM_AMT > 0
		   AND   BUS_DATE < = %d{yyyyMMdd} 
		   GROUP BY CUST_NO
			) a9
ON   t.CUST_NO = a9.CUST_NO	   
LEFT JOIN ( SELECT KHH,MIN(BDRQ) AS BDRQ
             FROM JZJYCX.GFZHGL_TZJZH
              WHERE BDRQ <> 0 AND DT = '%d{yyyyMMdd}'
			 GROUP BY KHH
			 ) a10
ON   t.CUST_NO = a10.KHH
LEFT JOIN  (SELECT   KHH,MIN(CJRQ) AS LRJH 
           FROM     RZRQCX.DATACENTER_TJGMXLS
           WHERE    WTLB IN (61,62,63,64,71,72)
		   AND      CJJE > 0
		   AND  dt < = '%d{yyyyMMdd}'
		   GROUP BY KHH
		   ) a11
ON   t.CUST_NO = a11.KHH
;	   





DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP1  ;
CREATE TABLE DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP1 as
SELECT   COALESCE(a.CUST_NO,b.CUST_NO,c.CUST_NO,d.CUST_NO) as CUST_NO
        ,COALESCE(a.BUS_DATE,b.BUS_DATE,c.BUS_DATE,d.BUS_DATE) as BUS_DATE
		,COALESCE(a.CUST_NO,b.CUST_NO,c.CUST_NO) as CUST_NO1
FROM (SELECT  CUST_NO
             ,MTCH_DT as BUS_DATE
      FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
      WHERE MTCH_AMT > 0
      AND  IF_TRD = 1
      AND BUS_DATE < = %d{yyyyMMdd}
      AND CUST_NO IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP WHERE  CUST_STAT = '0')
      GROUP BY CUST_NO,BUS_DATE
     ) a
FULL JOIN (SELECT   CUST_NO
                   ,CNFM_DT as BUS_DATE
           FROM DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS
           WHERE  CNFM_AMT > 0
           AND    IF_TRD = 1
		   AND BUS_DATE < = %d{yyyyMMdd}
           AND   CUST_NO IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP WHERE  CUST_STAT = '0')
           GROUP BY CUST_NO,BUS_DATE
           ) b
ON a.BUS_DATE = b.BUS_DATE
AND a.CUST_NO = b.CUST_NO
FULL JOIN (SELECT   CUST_NO
                   ,MTCH_DT as BUS_DATE
           FROM DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
           WHERE  MTCH_AMT > 0
		   AND BUS_DATE < = %d{yyyyMMdd}
           AND   CUST_NO IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP WHERE  CUST_STAT = '0')
           GROUP BY CUST_NO,BUS_DATE
           ) c
ON NVL(a.BUS_DATE,b.BUS_DATE) = c.BUS_DATE
AND NVL(a.CUST_NO,b.CUST_NO) = c.CUST_NO
FULL JOIN(SELECT CUST_NO,OPNAC_DT as BUS_DATE FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP WHERE OPNAC_DT  IS  NOT NULL) d
ON COALESCE(a.CUST_NO,b.CUST_NO,c.CUST_NO) = d.CUST_NO
AND COALESCE(a.BUS_DATE,b.BUS_DATE,c.BUS_DATE) = d.BUS_DATE
;




DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP2  ;
CREATE TABLE DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP2 as
SELECT CUST_NO
       ,BUS_DATE as DT1
	   ,EDW_PROD.G_DATE_ADD_STR(CAST(BUS_DATE as STRING),'yyyyMMdd','yyyyMMdd',0,6,0) as DT2
	   ,ROW_NUMBER()OVER(PARTITION BY CUST_NO ORDER BY CUST_NO,BUS_DATE) as NUM
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP1
;



---------创建临时表4 投资偏好------------




DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP3  ;
CREATE TABLE DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP3 as
SELECT 
         CUST_NO
        ,LABEL_VALUE
        ,BUS_DATE
       --,ROW_NUMBER()OVER(PARTITION BY CUST_NO ORDER BY BUS_DATE) NUM
FROM DDW_PROD.T_DDW_LM_LABEL_V_C_HIS
WHERE LABEL_ID = '8b6c8a85b0014e8384a884a8f8ceb7ee'
AND   LABEL_VALUE IS NOT NULL
AND   BUS_DATE = %d{yyyyMMdd}
AND   SUBSTR(CUST_NO,1,4) IN (SELECT BRH_NO FROM RPT_DB.V_BRH_NO)
AND   CUST_NO NOT IN ('100610335855')
;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP6  ;
CREATE TABLE DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP6 as
SELECT 
         CUST_NO
        ,LABEL_VALUE
        ,BUS_DATE
       --,ROW_NUMBER()OVER(PARTITION BY CUST_NO ORDER BY BUS_DATE) NUM
FROM DDW_PROD.T_DDW_LM_LABEL_V_C_HIS
WHERE LABEL_ID = '8b6c8a85b0014e8384a884a8f8ceb7ee'
AND   LABEL_VALUE IS NOT NULL
AND   BUS_DATE IN (SELECT  LST_TRD_D FROM RPT_DB.V_TRD_DT WHERE TRD_DT = NAT_DT AND TRD_DT = %d{yyyyMMdd})
AND   SUBSTR(CUST_NO,1,4) IN (SELECT BRH_NO FROM RPT_DB.V_BRH_NO)
AND   CUST_NO NOT IN ('100610335855')
;

---------创建临时表5 佣金调整------------
DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP4  ;
CREATE TABLE DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP4 as
SELECT 
         KHH
		,YJDJFS
        ,DJRQ
        ,ROW_NUMBER()OVER(PARTITION BY KHH ORDER BY DJRQ) NUM
FROM  EDW_PROD.T_EDW_T02_TYJDJDX_KH;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP5  ;
CREATE TABLE DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP5 as
SELECT 
         KHH
		,YJDJFS
        ,DJRQ
        ,ROW_NUMBER()OVER(PARTITION BY KHH ORDER BY DJRQ)-1 NUM
FROM  EDW_PROD.T_EDW_T02_TYJDJDX_KH;



---开始插入数据
 --开户成功日期
 INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
 (
                 CUST_NO          --客户号
 			   ,IMPO_PHS_CD      --重要阶段代码
 			   ,IMPO_PHS_DSC     --重要阶段描述
 			   ,DT               --重要阶段业务日期
 )
 PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT              T.CUST_NO     
 			       ,'001'                       AS IMPO_PHS_CD 
 			       ,'开户日期'                  AS IMPO_PHS_DSC
 			       ,CAST(t.OPNAC_DT AS STRING) AS DT
 FROM                DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP t
 WHERE               t.OPNAC_DT IS NOT NULL
 AND                  t.CUST_STAT = '0'
 ;

   --销户日期
   INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
   (
                   CUST_NO          --客户号
   			   ,IMPO_PHS_CD      --重要阶段代码
   			   ,IMPO_PHS_DSC     --重要阶段描述
   			   ,DT               --重要阶段业务日期 
   )
   PARTITION(BUS_DATE = %d{yyyyMMdd})
   SELECT              T.CUST_NO     
   			       ,'002'                       AS IMPO_PHS_CD 
   			       ,'销户日期'                  AS IMPO_PHS_DSC
   			       ,CAST(t.CNCLACT_DT AS STRING) AS DT
   FROM                DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP t
   WHERE               t.CNCLACT_DT IS NOT NULL
   ;




--首笔资金转入日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期  
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'003'                       AS IMPO_PHS_CD 
			       ,'首笔资金转入日期'          AS IMPO_PHS_DSC
			       ,CAST(t.SBZJ AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP  t
WHERE               t.SBZJ IS NOT NULL
AND                 t.CUST_STAT = '0'
AND                  t.SBZJ < > 99999999
;

--首笔交易日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'004'                       AS IMPO_PHS_CD 
			       ,'首笔交易日期'              AS IMPO_PHS_DSC
			       ,CAST(a1.DT AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP  t
INNER JOIN           (SELECT CUST_NO1 as CUST_NO,MIN(BUS_DATE) AS DT
                     FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP1
					 WHERE CUST_NO1 IS NOT NULL
                     GROUP BY CUST_NO)   a1
ON                  T.CUST_NO = a1.CUST_NO	
WHERE t.CUST_STAT = '0'		  

;

   --变为有效户日期
   INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
   (
                   CUST_NO          --客户号
   			   ,IMPO_PHS_CD      --重要阶段代码
   			   ,IMPO_PHS_DSC     --重要阶段描述
   			   ,DT               --重要阶段业务日期
   )
   PARTITION(BUS_DATE = %d{yyyyMMdd})
   SELECT              T.CUST_NO     
   			       ,'005'                                AS IMPO_PHS_CD 
   			       ,'变为有效户日期'                     AS IMPO_PHS_DSC
   			       ,CAST(t.FSTTM_DT_AST_1000 AS STRING)     AS DT
   FROM                DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP t		  
   WHERE               t.FSTTM_DT_AST_1000 IS NOT NULL
   AND                 t.CUST_STAT = '0'
   ;

--两融开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'006'                                AS IMPO_PHS_CD 
			       ,'两融开通日期'                       AS IMPO_PHS_DSC
			       ,CAST(t.CRD_OPNAC_DT AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP t
WHERE               t.CUST_STAT = '0'
AND                 t.CRD_OPNAC_DT IS NOT NULL ;



--两融激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'007'                                AS IMPO_PHS_CD 
			       ,'两融激活日期'                       AS IMPO_PHS_DSC
			       ,CAST(t.LRJH AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.LRJH < > 99999999
;

----股票期权开通日期
--INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
--(
--                CUST_NO          --客户号
--			   ,IMPO_PHS_CD      --重要阶段代码
--			   ,IMPO_PHS_DSC     --重要阶段描述
--			   ,DT               --重要阶段业务日期
--)
--PARTITION(BUS_DATE = %d{yyyyMMdd})
--SELECT              T.CUST_NO     
--			       ,'008'                                AS IMPO_PHS_CD 
--			       ,'股票期权开通日期'                         AS IMPO_PHS_DSC
--			       ,CAST(T1.GPKT AS STRING)     AS DT
--FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
--LEFT JOIN (SELECT   CUST_NO,MIN(OPNAC_DT) AS GPKT
--           FROM     DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
--           WHERE    SYS_SRC = '期权账户'
--		   AND    BUS_DATE = %d{yyyyMMdd}
--		   GROUP BY CUST_NO) T1
--ON         T.CUST_NO = T1.CUST_NO
--WHERE               T.ORDI_CUST_STAT = '0'
--AND                 T.BUS_DATE = %d{yyyyMMdd}
--AND                 T1.GPKT IS NOT NULL
--;

----股票期权激活日期
--INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
--(
--                CUST_NO          --客户号
--			   ,IMPO_PHS_CD      --重要阶段代码
--			   ,IMPO_PHS_DSC     --重要阶段描述
--			   ,DT               --重要阶段业务日期
--)
--PARTITION(BUS_DATE = %d{yyyyMMdd})
--SELECT              T.CUST_NO     
--			       ,'009'                                AS IMPO_PHS_CD 
--			       ,'股票期权激活日期'                         AS IMPO_PHS_DSC
--			       ,CAST(T1.GPJH AS STRING)     AS DT
--FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
--LEFT JOIN (SELECT KHH,MIN(CJRQ) AS GPJH
--           FROM   EDW_PROD.T_EDW_T05_TSO_JGMXLS
--		   WHERE  SOP_MMFX IN ('1','2')
--		   AND    SOP_KPCBZ IN ('O','C')
--		   AND    CJJE > 0
--		   GROUP BY KHH
--		   ) T1
--ON         T.CUST_NO = T1.KHH
--WHERE               T.ORDI_CUST_STAT = '0'
--AND                 T.BUS_DATE = %d{yyyyMMdd}
--AND                 T1.GPJH IS NOT NULL
--;

--港股通开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'010'                                AS IMPO_PHS_CD 
			       ,'港股通开通日期'                     AS IMPO_PHS_DSC
			       ,CAST(t.H_K_OPNAC_DT AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP  t
WHERE t.CUST_STAT = '0'
AND   t.H_K_OPNAC_DT IS NOT NULL
;

--港股通激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'011'                                AS IMPO_PHS_CD 
			       ,'港股通激活日期'                     AS IMPO_PHS_DSC
			       ,CAST(t.GGJH AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.GGJH < > 99999999
;

--基金定投开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'012'                                AS IMPO_PHS_CD 
			       ,'基金定投开通日期'                   AS IMPO_PHS_DSC
			       ,CAST(t.JJQY AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP  t
WHERE   t.CUST_STAT = '0' 
AND     t.JJQY IS NOT NULL
;

--基金定投激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'013'                                AS IMPO_PHS_CD 
			       ,'基金定投激活日期'                   AS IMPO_PHS_DSC
			       ,CAST(t.JJJH AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.JJJH < > 99999999
;


--分级基金开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'014'                                AS IMPO_PHS_CD 
			       ,'分级基金开通日期'                   AS IMPO_PHS_DSC
			       ,CAST(t.STR_FND_OPNAC_DT AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.STR_FND_OPNAC_DT IS NOT NULL
;

--分级基金激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'015'                                AS IMPO_PHS_CD 
			       ,'分级基金激活日期'                   AS IMPO_PHS_DSC
			       ,CAST(t.FJJJJH AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.FJJJJH < > 99999999
;

--回购融券开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'016'                                AS IMPO_PHS_CD 
			       ,'回购融券开通日期'                   AS IMPO_PHS_DSC
			       ,CAST(t.REPO_MRGNS_OPNAC_DT AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.REPO_MRGNS_OPNAC_DT IS NOT NULL
;

--回购融券激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'017'                                AS IMPO_PHS_CD 
			       ,'回购融券激活日期'                   AS IMPO_PHS_DSC
			       ,CAST(t.HGJH AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.HGJH < > 99999999
;

--现金添利开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'018'                                AS IMPO_PHS_CD 
			       ,'现金添利开通日期'                   AS IMPO_PHS_DSC
			       ,CAST(t.CASH_PROD_OPNAC_DT AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.CASH_PROD_OPNAC_DT IS NOT NULL
;

--现金添利激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'019'                                AS IMPO_PHS_CD 
			       ,'现金添利激活日期'                   AS IMPO_PHS_DSC
			       ,CAST(t.CASH_PROD_FSTTM_TRD_DT AS STRING) AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.CASH_PROD_FSTTM_TRD_DT IS NOT NULL
;

--聚赢快线(报价回购)开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'020'                                AS IMPO_PHS_CD 
			       ,'聚赢快线(报价回购)开通日期'         AS IMPO_PHS_DSC
			       ,CAST(t.QOT_REPO_OPNAC_DT AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.QOT_REPO_OPNAC_DT IS NOT NULL
;

--新三板合格投资者(股转交易)开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'021'                                AS IMPO_PHS_CD 
			       ,'新三板合格投资者(股转交易)开通日期' AS IMPO_PHS_DSC
			       ,CAST(t.NEW_T3BOD_OPNAC_DT AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.NEW_T3BOD_OPNAC_DT IS NOT NULL
;

--债券合格投资者开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'022'                                AS IMPO_PHS_CD 
			       ,'债券合格投资者开通日期'             AS IMPO_PHS_DSC
			       ,CAST(t.BOND_QLFD_IVSM_OPNAC_DT AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.BOND_QLFD_IVSM_OPNAC_DT IS NOT NULL
;

--科创板权限开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'023'                                   AS IMPO_PHS_CD 
			       ,'科创板开通日期'                        AS IMPO_PHS_DSC
			       ,CAST(t.STIB_OPNAC_DT AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.STIB_OPNAC_DT IS NOT NULL
;


--科创板权限激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'024'                                   AS IMPO_PHS_CD 
			       ,'科创板激活日期'                        AS IMPO_PHS_DSC
			       ,CAST(t.KCBJH AS STRING)                AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.KCBJH < > 99999999
;


--沪伦通开通日期

--沪伦通激活日期




--最近一次购买理财产品
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'025'                                AS IMPO_PHS_CD 
			       ,'最近一次购买理财产品'               AS IMPO_PHS_DSC
			       ,CAST(t.ZJGMRQ AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.ZJGMRQ < > 99999999
;

--订阅咨询服务产品（聚赢理财）



--客户沉寂
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'026'                                AS IMPO_PHS_CD 
			       ,'客户沉寂'                           AS IMPO_PHS_DSC
			       ,CAST(a1.DT2 AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
INNER JOIN (SELECT    a.CUST_NO               AS CUST_NO1                    
          		    ,a.DT2                   AS DT2          		    
          FROM      DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP2 a
          LEFT JOIN DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP2 b
          ON        a.CUST_NO = b.CUST_NO
          AND       a.NUM = b.NUM - 1
          WHERE     CAST(a.DT2 AS STRING) < CAST(NVL(CAST(b.DT1 AS STRING),'%d{yyyyMMdd}') AS STRING)
          ) a1
ON t.CUST_NO = a1.CUST_NO1
WHERE  t.CUST_STAT = '0'
;

--客户复苏
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'027'                                AS IMPO_PHS_CD 
			       ,'客户复苏'                           AS IMPO_PHS_DSC
			       ,CAST(a1.DT11 AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
INNER JOIN (SELECT    a.CUST_NO               AS CUST_NO1                    
          		    ,a.DT1                    AS  DT11       		    
          FROM      DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP2 a
          LEFT JOIN DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP2 b
          ON        a.CUST_NO = b.CUST_NO
          AND       a.NUM = b.NUM - 1
          WHERE     CAST(a.DT2 AS STRING) < CAST(b.DT1 AS STRING)
          ) a1
ON t.CUST_NO = a1.CUST_NO1
WHERE  t.CUST_STAT = '0'
;

--佣金调整
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'028'                                AS IMPO_PHS_CD 
			       ,'佣金调整'                           AS IMPO_PHS_DSC
			       ,CAST(a1.DJRQ AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP t
INNER JOIN (
           SELECT     a.KHH
					  ,b.DJRQ
           FROM        DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP4  a
           INNER JOIN   DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP5  b
           ON          a.KHH = b.KHH
           AND         a.NUM = b.NUM
		   WHERE       a.YJDJFS < > b.YJDJFS
          ) a1
ON t.CUST_NO = a1.KHH
WHERE  t.CUST_STAT = '0'


;

--客户投诉
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'029'                                AS IMPO_PHS_CD 
			       ,'客户投诉'                           AS IMPO_PHS_DSC
			       ,CAST(T1.TSSJ AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP   t
LEFT JOIN (SELECT KHH,CONCAT(SUBSTR(TSSJ,1,4),SUBSTR(TSSJ,6,2),SUBSTR(TSSJ,9,2)) as TSSJ 
           FROM C5CX.ECIF_LCKHTSBD where DT = '%d{yyyyMMdd}'
          )T1
ON T.CUST_NO = cast(T1.KHH as string)
WHERE T1.TSSJ IS NOT NULL
AND    t.CUST_STAT = '0'
;

--客户成为专业投资者
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'030'                                AS IMPO_PHS_CD 
			       ,'客户成为专业投资者'                 AS IMPO_PHS_DSC
			       ,CAST(CAST(t.TZZPDRQ AS DECIMAL(38,0)) AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.TZZPDRQ < > 99999999
;

--客户风险承受能力保守型（最低类别）
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO
			       ,'031'                                AS IMPO_PHS_CD 
			       ,'客户风险承受能力保守型（最低类别）' AS IMPO_PHS_DSC
			       ,CAST(t.CPRQ AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.CPRQ < > 99999999
;

--客户星级变动
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'032'                                AS IMPO_PHS_CD 
			       ,'客户星级变动'                       AS IMPO_PHS_DSC
			       ,CAST(T1.KHXJBDRQ AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
INNER JOIN  (SELECT  CUST_NO,BUS_DATE AS KHXJBDRQ
            FROM DDW_PROD.T_DDW_LM_CUST_STAR_LVL_CHG_STATS) T1
ON T.CUST_NO = T1.CUST_NO
WHERE t.CUST_STAT = '0'
;

--成为休眠账户
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'033'                                AS IMPO_PHS_CD 
			       ,'成为休眠账户'                       AS IMPO_PHS_DSC
			       ,CAST(t.BDRQ AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.BDRQ < > 99999999
;

--休眠激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'034'                                AS IMPO_PHS_CD 
			       ,'休眠激活日期'                       AS IMPO_PHS_DSC
			       ,MIN(CAST(a1.DT1 AS STRING))     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP  t
INNER JOIN DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP2 a1
ON        t.CUST_NO = a1.CUST_NO
WHERE   t.CUST_STAT = '0' 
AND     t.XMBDRQ < > 99999999
AND     t.XMBDRQ < a1.DT1
GROUP BY t.CUST_NO;


			

--投资偏好变化
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'035'                                AS IMPO_PHS_CD 
			       ,'投资偏好变化'                       AS IMPO_PHS_DSC
			       ,'%d{yyyyMMdd}'     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
INNER JOIN  (  SELECT 
                         a.CUST_NO
						,b.BUS_DATE as TZPHBH
            FROM        DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP3 a
            INNER JOIN   DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP6 b
            ON          a.CUST_NO  = b.CUST_NO
			WHERE       a.LABEL_VALUE < > b.LABEL_VALUE
             ) a1
ON          t.CUST_NO = a1.CUST_NO
WHERE       t.CUST_STAT = '0'
;

INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'035'                                AS IMPO_PHS_CD 
			       ,'投资偏好变化'                       AS IMPO_PHS_DSC
			       ,a1.DT     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
INNER JOIN  ( SELECT * 
              FROM DDW_PROD.T_DDW_CUST_LCS_STATAS 
			  WHERE IMPO_PHS_CD = '035' 
			  AND BUS_DATE IN (SELECT  LST_TRD_D FROM RPT_DB.V_TRD_DT WHERE TRD_DT = NAT_DT AND TRD_DT = %d{yyyyMMdd})
			 ) a1
ON          t.CUST_NO = a1.CUST_NO
WHERE       t.CUST_STAT = '0'
;


----沪市期权开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'036'                                AS IMPO_PHS_CD 
			       ,'沪市期权开通日期'                   AS IMPO_PHS_DSC
			       ,CAST(t.SH_WRNT_OPNAC_DT AS STRING)            AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.SH_WRNT_OPNAC_DT IS NOT NULL
;

----深市期权开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'037'                                AS IMPO_PHS_CD 
			       ,'深市期权开通日期'                   AS IMPO_PHS_DSC
			       ,CAST(t.SZ_WRNT_OPNAC_DT AS STRING)            AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.SZ_WRNT_OPNAC_DT IS NOT NULL
;

----沪市期权激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'038'                                AS IMPO_PHS_CD 
			       ,'沪市期权激活日期'                   AS IMPO_PHS_DSC
			       ,CAST(t.HSQQJH AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.HSQQJH < > 99999999
;

----深市期权激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'039'                                AS IMPO_PHS_CD 
			       ,'深市期权激活日期'                   AS IMPO_PHS_DSC
			       ,CAST(t.SSQQJH AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.SSQQJH < > 99999999
;


--股转一类合格投资者开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'040'                                            AS IMPO_PHS_CD 
			       ,'股转一类合格投资者开通日期'                     AS IMPO_PHS_DSC
			       ,CAST(t.NEW_T3BOD_OPNAC_DT_1 AS STRING)                      AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.NEW_T3BOD_OPNAC_DT_1 IS NOT NULL
;

--股转二类合格投资者开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'041'                                            AS IMPO_PHS_CD 
			       ,'股转二类合格投资者开通日期'                     AS IMPO_PHS_DSC
			       ,CAST(t.NEW_T3BOD_OPNAC_DT_2 AS STRING)                      AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.NEW_T3BOD_OPNAC_DT_2 IS NOT NULL
;

--股转三类合格投资者开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'042'                                            AS IMPO_PHS_CD 
			       ,'股转三类合格投资者开通日期'                     AS IMPO_PHS_DSC
			       ,CAST(t.NEW_T3BOD_OPNAC_DT_3 AS STRING)                      AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.NEW_T3BOD_OPNAC_DT_3 IS NOT NULL
;


--注册制创业板权限开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO          --客户号
			   ,IMPO_PHS_CD      --重要阶段代码
			   ,IMPO_PHS_DSC     --重要阶段描述
			   ,DT               --重要阶段业务日期
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'043'                                   AS IMPO_PHS_CD 
			       ,'注册制创业板开通日期'                        AS IMPO_PHS_DSC
			       ,CAST(t.RGST_GEM_OPNAC_DT AS STRING)     AS DT
FROM DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP T
WHERE   t.CUST_STAT = '0' 
AND     t.RGST_GEM_OPNAC_DT IS NOT NULL
;


------插入数据结束

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_LCS_STATAS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
invalidate metadata DDW_PROD.T_DDW_CUST_LCS_STATAS;

---------删除临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP1;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP2;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP3;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP4;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP5;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_LCS_STATAS_TEMP6;
 --/* ***************************************** SQL Begin ***************************************** */
 --/* 脚本功能:合规分类评价_经纪人                                                                            */
 --/* 创建人:黄勇华                                                                              */
 --/* 创建时间:2019-02-15                                                                       */ 
 INSERT OVERWRITE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_BRK
( 
								 CL              --分类
								 ,FINE           --细类
								 ,INCUM_PSN_NUM  --在职人数
								 ,RSG_PSN_NUM    --离职人数
								 ,ETL_DT       
) PARTITION(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT))
 SELECT  '年龄结构'  as CL --分类
         ,CASE WHEN AGE < = 30
		       AND  AGE > = 0
	           THEN '30岁及以下'
			   WHEN AGE > = 31
			   AND  AGE < = 35
			   THEN '31-35'
			   WHEN AGE > = 36
			   AND  AGE < = 40
			   THEN '36-40'
			   WHEN AGE > = 41
			   AND  AGE < = 45
			   THEN '41-45'
			   WHEN AGE > = 46
			   AND  AGE < = 50
			   THEN '46-50'
			   WHEN AGE > = 51
			   AND  AGE < = 54
			   THEN '51-54'
			   WHEN AGE > = 55			 
			   THEN '55岁及以上'
			   ELSE '其他'
			   END as FINE --细类
	    ,SUM(CASE WHEN ZHZT = '0' 
		          THEN 1
			      ELSE 0
			      END
			)         as INCUM_PSN_NUM --在职人数
	    ,SUM(CASE WHEN SUBSTR(CAST(NVL(LZRQ,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		          THEN 1
			      ELSE 0
			      END
			)         as RSG_PSN_NUM --离职人数
	  ,%d{yyyyMMdd}
FROM 
(SELECT  ID
       ,CEIL(EDW_PROD.G_DATE_COMPARE_DATE(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'31'),'yyyyMMdd',CAST(NVL(CSRQ,99999999) AS STRING),'yyyyMMdd')/365) as AGE
       ,RZRQ
	   ,LZRQ
	   ,ZHZT
FROM EDW_PROD.T_EDW_T01_TJJR
WHERE BUS_DATE = %d{yyyyMMdd} 
AND  JJRLB = '103'
AND  (ZHZT = '0'  OR (SUBSTR(CAST(NVL(LZRQ,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)) )
)   t
GROUP BY CL,FINE
UNION ALL
SELECT '文化结构' as CL --分类
       ,CASE WHEN XLDM = '1'
	         THEN '博士'
			 WHEN XLDM = '2'
			 THEN '硕士'
			 WHEN XLDM = '3'
			 THEN '本科'
			 WHEN XLDM = '4'
			 THEN '专科'
			 WHEN XLDM IN ('5','6')
			 THEN '高中及中专'
			 WHEN XLDM IN ('7','8') OR XLDM IS NULL
			 THEN '初中以下'			
			 END as FINE --细类
	    ,SUM(CASE WHEN ZHZT = '0' 
		          THEN 1
			      ELSE 0
			      END
			)         as INCUM_PSN_NUM --在职人数
	    ,SUM(CASE WHEN SUBSTR(CAST(NVL(LZRQ,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		          THEN 1
			      ELSE 0
			      END
			)         as RSG_PSN_NUM --离职人数
			,%d{yyyyMMdd}
FROM 
(SELECT  ID
       ,XLDM
       ,RZRQ
	   ,LZRQ
	   ,ZHZT
FROM EDW_PROD.T_EDW_T01_TJJR
WHERE BUS_DATE = %d{yyyyMMdd}
AND  JJRLB = '103'
AND  (ZHZT = '0'  OR (SUBSTR(CAST(NVL(LZRQ,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)) )
 
)   t
GROUP BY CL,FINE

UNION ALL 
SELECT '性别' as CL --分类
       ,CASE WHEN XBDM = '1'
	         THEN '男'
			 WHEN XBDM = '2'
			 THEN '女'
			 ELSE '其他'
			 END as FINE --细类
	    ,SUM(CASE WHEN ZHZT = '0' 
		          THEN 1
			      ELSE 0
			      END
			)         as INCUM_PSN_NUM --在职人数
	    ,SUM(CASE WHEN SUBSTR(CAST(NVL(LZRQ,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		          THEN 1
			      ELSE 0
			      END
			)         as RSG_PSN_NUM --离职人数
		,%d{yyyyMMdd}
FROM 
(SELECT  ID
       ,XBDM
       ,RZRQ
	   ,ZHZT
	   ,LZRQ
FROM EDW_PROD.T_EDW_T01_TJJR
WHERE BUS_DATE = %d{yyyyMMdd}
AND  JJRLB = '103'
AND  (ZHZT = '0'  OR (SUBSTR(CAST(NVL(LZRQ,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)) )
 
)   t
GROUP BY CL,FINE
UNION ALL

SELECT '户籍' as CL --分类
       ,CASE WHEN GJDM IN ('156')
	         AND  CAST(PROVINCE as STRING) LIKE '310%'
	         THEN '上海户籍'
			 WHEN GJDM IN ('156')
	         AND  CAST(PROVINCE as STRING) NOT LIKE '310%'
	         THEN '外省市户籍'
			 WHEN GJDM NOT IN ('156')    
	         THEN '境外'
			 ELSE '其他'
			 END as FINE --细类
	    ,SUM(CASE WHEN ZHZT = '0' 
		          THEN 1
			      ELSE 0
			      END
			)         as INCUM_PSN_NUM --在职人数
	    ,SUM(CASE WHEN SUBSTR(CAST(NVL(LZRQ,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		          THEN 1
			      ELSE 0
			      END
			)         as RSG_PSN_NUM --离职人数
		,%d{yyyyMMdd}
FROM 
(SELECT  ID
       ,GJDM
	   ,PROVINCE
	   ,ZHZT
       ,RZRQ
	   ,LZRQ
FROM EDW_PROD.T_EDW_T01_TJJR
WHERE BUS_DATE = %d{yyyyMMdd}
AND  JJRLB = '103'
AND  (ZHZT = '0'  OR (SUBSTR(CAST(NVL(LZRQ,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)) )
 
)   t
GROUP BY CL,FINE

UNION ALL
SELECT '政治面貌' as CL --分类
       ,CASE WHEN ZZMM = '3'
	         THEN '中共党员'
			 WHEN NVL(ZZMM,'1') < > '3'          
	         THEN '非中共党员'			
			 END as FINE --细类
	    ,SUM(CASE WHEN ZHZT = '0' 
		          THEN 1
			      ELSE 0
			      END
			)         as INCUM_PSN_NUM --在职人数
	    ,SUM(CASE WHEN SUBSTR(CAST(NVL(LZRQ,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		          THEN 1
			      ELSE 0
			      END
			)         as RSG_PSN_NUM --离职人数
			,%d{yyyyMMdd}
FROM 
(SELECT  ID
	   ,ZZMM
	   ,ZHZT
       ,RZRQ
	   ,LZRQ
FROM EDW_PROD.T_EDW_T01_TJJR
WHERE BUS_DATE = %d{yyyyMMdd}
AND  JJRLB = '103'
AND  (ZHZT = '0'  OR (SUBSTR(CAST(NVL(LZRQ,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)) )

)   t
GROUP BY CL,FINE ;


INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_COMPL_CL_EVAL_BRK',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_BRK ;
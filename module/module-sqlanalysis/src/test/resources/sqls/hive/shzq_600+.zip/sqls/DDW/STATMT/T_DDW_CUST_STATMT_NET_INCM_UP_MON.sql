--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户对账单收益率截止月表                                                                     */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-08-07                                                                        */ 
----
 --ALTER TABLE DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_UP_MON DROP IF EXISTS PARTITION (YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,6) as INT) ) ; 
-------创建临时表
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_UP_MON_TEMP;
       CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_UP_MON_TEMP as
	  SELECT t.CUST_NO
	       ,ROUND((t.TOL_YLD+t.ADJ_YLD)*1.000000/t.TOL_AST_AVG,6) as NET_INCM
		   ,t.TOL_AST
		   ,t.AMT_BAL
        ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON	  
		FROM
      (SELECT  CUST_NO
	          ,SUM(TOL_AST-TOL_GL) as TOL_AST  --总资产(包括负债)
			  ,SUM(AMT_BAL+UPNY_AMT)                         as AMT_BAL  --净资金
             ,SUM(a.TOL_YLD) as TOL_YLD
             ,SUM(a.ADJ_YLD) as ADJ_YLD			 
             ,AVG(a.TOL_AST+a.TURN_OUT_MKTVAL+a.TURN_OUT_AMT)	  as TOL_AST_AVG		 
 FROM 		DDW_PROD.T_DDW_CUST_STATMT_DAY    a	
 WHERE      BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01')  as INT)
 AND        BUS_DATE < = %d{yyyyMMdd}
 AND        EXISTS (SELECT 1 FROM   DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
                            WHERE     (b.ORDI_CUST_STAT < > '3' OR b.ORDI_CNCLACT_DT > %d{yyyyMMdd})
							AND       a.CUST_NO = b.CUST_NO
							AND       b.BUS_DATE = %d{yyyyMMdd}							
					)   
 GROUP BY CUST_NO
 )  t
 WHERE (t.TOL_AST_AVG > 100 
 OR   (t.TOL_AST_AVG > =0 AND TOL_YLD < > 0))	
  ;
  
 
 ---插入数据
  INSERT 	OVERWRITE DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_UP_MON
 (
                                  
                                 CUST_NO             --客户号 
                                ,NET_INCM            --收益率 
                                ,AVG_POS             --平均仓位
								,TOL_YLD_M           --月总收益
                                ,ETL_DT              --加载日期  							  
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT 
            t.CUST_NO	                  	                                                 as CUST_NO             --客户号 
           ,CAST(t.NET_INCM as DECIMAL(38,6))*100                                                as NET_INCM            --收益率 
		   ,CAST(NVL(((t.TOL_AST-t.AMT_BAL)-NVL(a2.sec_newst_mktval,0))*1.000000/(t.TOL_AST-NVL(a2.sec_newst_mktval,0)),0) as DECIMAL(38,6))*100           as AVG_POS             --平均仓位
		   ,NVL(a1.TOL_YLD,0)                                                                as TOL_YLD_M           --月总收益
           ,%d{yyyyMMdd}                                                                     as ETL_DT              --加载日期 							  
 FROM       DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_UP_MON_TEMP   t
 LEFT JOIN  DDW_PROD.T_DDW_CUST_STATMT_MON                    a1
 ON         t.CUST_NO = a1.CUST_NO
 AND        a1.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)
 LEFT JOIN (SELECT CUST_NO,SUM(sec_mktval) as sec_newst_mktval
            FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
			WHERE SUBSTR(SEC_CGY,1,1) IN ('H','Z')
			AND   SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			GROUP BY CUST_NO
			)   a2
ON          t.CUST_NO = a2.CUST_NO
			
 
;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_UP_MON_TEMP;

-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_STATMT_NET_INCM_UP_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

invalidate metadata DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_UP_MON;
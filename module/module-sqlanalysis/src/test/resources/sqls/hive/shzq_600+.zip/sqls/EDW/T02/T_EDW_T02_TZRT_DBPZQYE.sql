 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:转融通担保品证券余额表                                                              */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZRT_DBPZQYE;
-------插入数据结束--------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZRT_DBPZQYE
(
                                    DZRQ                       --对账日期                         
                                   ,GDH                        --担保证券账户                       
                                   ,JYS                        --交易所                          
                                   ,ZQDM                       --证券代码                         
                                   ,ZQMC                       --证券名称                         
                                   ,ZQLB                       --证券类别                         
                                   ,ZQSL                       --证券数量                         
                                   ,DJSL                       --冻结数量                         
                                   ,ZQJG                       --证券价格                         
                                   ,ZQJZ                       --证券价值                         
                                   ,ZSL                        --折算率                          
                                   ,XTBS                         								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.DZRQ                         as DZRQ                       --对账日期                                    
                                   ,t.GDH                          as GDH                        --担保证券账户                                   
                                   ,t.JYS                          as JYS                        --交易所                                          
                                   ,t.ZQDM                         as ZQDM                       --证券代码                                        
                                   ,t.ZQMC                         as ZQMC                       --证券名称                                        
                                   ,t.ZQLB                         as ZQLB                       --证券类别                                       
                                   ,t.ZQSL                         as ZQSL                       --证券数量                                        
                                   ,t.DJSL                         as DJSL                       --冻结数量                                         
                                   ,t.ZQJG                         as ZQJG                       --证券价格                                      
                                   ,t.ZQJZ                         as ZQJZ                       --证券价值                                        
                                   ,t.ZSL                          as ZSL                        --折算率                                          
                                   ,'RZRQ'					       as XTBS                         					
 FROM     		RZRQCX.ZRT_TZRT_DBPZQYE t
 WHERE          t.DT = '%d{yyyyMMdd}';
-------插入数据结束------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZRT_DBPZQYE',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TZRT_DBPZQYE;
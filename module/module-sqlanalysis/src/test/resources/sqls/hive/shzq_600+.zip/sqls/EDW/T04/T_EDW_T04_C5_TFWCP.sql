 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:岗位成员表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
-----------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T04_C5_TFWCP(
                      ID        
                     ,CPML      
                     ,CPMC      
                     ,CPBM      
                     ,XH        
                     ,CPZT      
                     ,CPMS      
                     ,KXCPSL    
                     ,SJRQ      
                     ,XSTB      
                     ,CPLX      
                     ,SXZDSL    
                     ,CPSX      
                     ,CPFXDJ    
                     ,FWDX      
                     ,DZFS      
                     ,YWFW      
                     ,SFFXTS    
                     ,YYBFW     
                     ,SFRX      
                     ,SFCX      
                     ,SFXCP     
                     ,SFQY      
                     ,TJZS      
                     ,GLR       
                     ,KHJB      
                     ,CPCLLB    
                     ,CPFL      
                     ,CPLY      
                     ,KFRY      
                     ,TGJS      
                     ,TZLN      
                     ,MZTK      
                     ,YXQ       
                     ,EJFL        
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                      t.ID        
                     ,t.CPML      
                     ,t.CPMC      
                     ,t.CPBM      
                     ,t.XH        
                     ,t.CPZT      
                     ,t.CPMS      
                     ,t.KXCPSL    
                     ,t.SJRQ      
                     ,t.XSTB      
                     ,t.CPLX      
                     ,t.SXZDSL    
                     ,t.CPSX      
                     ,t.CPFXDJ    
                     ,t.FWDX      
                     ,t.DZFS      
                     ,t.YWFW      
                     ,t.SFFXTS    
                     ,t.YYBFW     
                     ,t.SFRX      
                     ,t.SFCX      
                     ,t.SFXCP     
                     ,t.SFQY      
                     ,t.TJZS      
                     ,t.GLR       
                     ,t.KHJB      
                     ,t.CPCLLB    
                     ,t.CPFL      
                     ,t.CPLY      
                     ,t.KFRY      
                     ,t.TGJS      
                     ,t.TZLN      
                     ,t.MZTK      
                     ,t.YXQ       
                     ,t.EJFL          
 FROM       C5CX.SPIF_TFWCP    t
 WHERE      t.DT = '%d{yyyyMMdd}';
----插入数据结束--------------
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:质押回购历史表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 

-------插入数据开始--------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZYHGLS
(
                                    RQ                                  --日期                                 
                                   ,ZYHGBH                              --质押回购编号                             
                                   ,XYBH                                --协议编号                               
                                   ,HTBH                                --合同编号                               
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,GFXZ                                --股份性质                               
                                   ,WTLB                                --委托类别                               
                                   ,CJSL                                --成交数量                               
                                   ,CJJG                                --成交价格                               
                                   ,CJJE                                --成交金额                               
                                   ,YGHJE                               --购回金额                               
                                   ,JSJE                                --交收金额                               
                                   ,SGSL                                --申购金额                               
                                   ,QTJE                                --红利金额                               
                                   ,FHJE                                --返还金额                               
                                   ,CJRQ                                --成交日期                               
                                   ,QSRQ                                --清算日期                               
                                   ,YDYSZ                               --抵押市值                               
                                   ,WTH                                 --委托号                                
                                   ,SBWTH                               --申报委托号                              
                                   ,CJBH                                --成交编号                               
                                   ,JSBZ                                --交收标志                               
                                   ,JSSL                                --交收数量                               
                                   ,SYBZ                                --顺延标志                               
                                   ,YYJGHRQ                             --预计购回日期                             
                                   ,GHRQ                                --购回日期                               
                                   ,JSRQ                                --交收日期                               
                                   ,STEP                                --STEP字段                             
                                   ,XWH                                 --席位号                                
                                   ,DZLX                                --代转利息                               
                                   ,JXRQ                                --结息日期                               
                                   ,JXJE                                --结息金额                               
                                   ,ZYBH                                --质押编号                               
                                   ,WTFS                                --委托方式                               
                                   ,CPDM                                --产品代码                               
                                   ,ZDSY                                --自动顺延标志                             
                                   ,GHFS                                --购回方式                               
                                   ,ZJYT                                --资金用途                               
                                   ,FXJE                                --罚息金额                               
                                   ,NBZT                                --合约日间状态                             
                                   ,TDLX                                --通道类型                               
                                   ,LYJBL                               --履约金比例 
                                   ,TZLX 
								   ,ZJGLZH
								   ,ZXBZ		                        --增信标志
								   ,WYJ
								   ,QTFY								 
								   ,XTBS  	 								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.RQ                                  as RQ                                  --日期                                  
                                   ,t.BH                                  as ZYHGBH                              --编号                                  
                                   ,t.XYBH                                as XYBH                                --协议编号                                
                                   ,t.HTBH                                as HTBH                                --合同编号                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.GFXZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as GFXZ                                --股份性质                                
                                   ,t.WTLB                                as WTLB                                --委托类别                                
                                   ,t.CJSL                                as CJSL                                --成交数量                                
                                   ,t.CJJG                                as CJJG                                --成交价格                                
                                   ,t.CJJE                                as CJJE                                --成交金额                                
                                   ,t.GHJE                                as YGHJE                               --购回金额                                
                                   ,t.JSJE                                as JSJE                                --交收金额                                
                                   ,t.SGSL                                as SGSL                                --申购金额                                
                                   ,t.HLJE                                as QTJE                                --红利金额                                
                                   ,t.FHJE                                as FHJE                                --返还金额                                
                                   ,t.CJRQ                                as CJRQ                                --成交日期                                
                                   ,t.QSRQ                                as QSRQ                                --清算日期                                
                                   ,t.DYSZ                                as YDYSZ                               --抵押市值                                
                                   ,t.WTH                                 as WTH                                 --委托号                                 
                                   ,t.SBWTH                               as SBWTH                               --申报委托号                               
                                   ,t.CJBH                                as CJBH                                --成交编号                                
                                   ,t.JSBZ                                as JSBZ                                --交收标志                                
                                   ,t.JSSL                                as JSSL                                --交收数量                                
                                   ,t.SYBZ                                as SYBZ                                --顺延标志                                
                                   ,t.YJGHRQ                              as YYJGHRQ                             --预计购回日期                              
                                   ,t.GHRQ                                as GHRQ                                --购回日期                                
                                   ,t.JSRQ                                as JSRQ                                --交收日期                                
                                   ,t.STEP                                as STEP                                --STEP字段                              
                                   ,t.XWH                                 as XWH                                 --席位号                                 
                                   ,t.DZLX                                as DZLX                                --代转利息                                
                                   ,t.JXRQ                                as JXRQ                                --结息日期                                
                                   ,t.JXJE                                as JXJE                                --结息金额                                
                                   ,t.ZYBH                                as ZYBH                                --质押编号                                
                                   ,t.WTFS                                as WTFS                                --委托方式                                
                                   ,t.CPDM                                as CPDM                                --产品代码                                
                                   ,t.ZDSY                                as ZDSY                                --自动顺延标志                              
                                   ,t.GHFS                                as GHFS_c                              --购回方式                                
                                   ,t.ZJYT                                as ZJYT                                --资金用途                                
                                   ,t.FXJE                                as FXJE                                --罚息金额                                
                                   ,t.NBZT                                as NBZT                                --合约日间状态                              
                                   ,t.TDLX                                as TDLX                                --通道类型                                
                                   ,t.LYJBL                               as LYJBL                               --履约金比例
                                   ,0                                     as TZLX
								   ,t.ZJGLZH	                          as ZJGLZH       
								   ,CAST(t.ZXBZ	AS DECIMAL(38,0))						  	  as ZXBZ                                --增信标志
								   ,CAST(t.WYJ	AS DECIMAL(38,2))						  	  as WYJ
								   ,CAST(t.QTFY	AS DECIMAL(38,2))						  	  as QTFY
                                   ,'JZJY'                                as XTBS								   
 FROM           JZJYCX.DATACENTER_TZYHGLS t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'GFXZ'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.GFXZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t2
 ON             t2.YXT = 'JZJY'
 AND            t2.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
--------插入数据结束-----------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZYHGLS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata EDW_PROD.T_EDW_T02_TZYHGLS;
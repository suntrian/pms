--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:运营领导驾驶舱历史月表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_MON_TEMP;
  CREATE TABLE RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_MON_TEMP 
  as
  SELECT   SUBSTR(CAST(t.BUS_DATE as STRING),1,6) as YEAR_MON  
          ,SUM(AUDT_ITMS)		           as AUDT_ITMS          --审核笔数
		  ,SUM(IDV_BIZ_ITMS)               as IDV_BIZ_ITMS       --个人业务笔数
		  ,SUM(ORG_BIZ_ITMS)               as ORG_BIZ_ITMS       --机构业务笔数
          ,SUM(RETURN_ITMS)                as RETURN_ITMS        --退回笔数
		  ,SUM(SUCS_ITMS)                  as SUCS_ITMS          --成功笔数
		  ,SUM(FALL_ITMS)                  as FALL_ITMS          --失败笔数
		  ,SUM(RETURN_TMS)                 as RETURN_TMS         --退回次数
		  ,SUM(SUCS_TMS)                   as SUCS_TMS           --成功次数
		  ,SUM(FALL_TMS)                   as FALL_TMS           --失败次数
		  ,SUM(TMS)                        as TMS                --次数
		  ,SUM(IDV_TMS)                    as IDV_TMS            --个人次数
		  ,SUM(ORG_TMS)                    as ORG_TMS            --机构次数
		  ,SUM(TMS1)                       as TMS1               --次数
		  ,SUM(AUDT_TS)                    as AUDT_TS            --审核时长 
		  ,SUM(IDV_AUDT_TS)                as IDV_AUDT_TS        --个人审核时长 
		  ,SUM(ORG_AUDT_TS)                as ORG_AUDT_TS        --机构审核时长 
 FROM        RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY t
 WHERE      SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 OR        SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
 GROUP BY    YEAR_MON
  ; 
  DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_MON_TEMP1;
  CREATE TABLE RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_MON_TEMP1 
  as
  SELECT   SUBSTR(CAST(t.BUS_DATE as STRING),1,6) as YEAR_MON                          
           ,COUNT(DISTINCT AUDT_PSN_NAME )        as PSN_NUM
 FROM        RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_DAY t
 WHERE      SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 OR        SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
 GROUP BY    YEAR_MON
  ; 
  INSERT   OVERWRITE RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_MON
  (
             AUDT_ITMS            --审核笔数
            ,IDV_BIZ_ITMS         --个人业务笔数
            ,ORG_BIZ_ITMS         --机构业务笔数
            ,RETURN_ITMS          --退回笔数
            ,SUCS_ITMS            --成功笔数
            ,FALL_ITMS            --失败笔数
			,RETURN_TMS           --退回次数
            ,SUCS_TMS             --成功次数
            ,FALL_TMS             --失败次数			
			,TMS1                 --次数
            ,AUDT_TS              --审核时长
			,PSN_AVG_AUDT_TS      --人均审核时长
            ,AVG_AUDT_TS          --单次审核时长
            ,AVG_IDV_AUDT_TS      --个人单次时长
			,AVG_ORG_AUDT_TS      --机构单次时长
) 
PARTITION( YEAR_MON  )
  SELECT   t.AUDT_ITMS		              as AUDT_ITMS          --审核笔数
		  ,t.IDV_BIZ_ITMS                 as IDV_BIZ_ITMS       --个人业务笔数
		  ,t.ORG_BIZ_ITMS                 as ORG_BIZ_ITMS       --机构业务笔数
          ,t.RETURN_TMS                   as RETURN_ITMS        --退回笔数
		  ,t.SUCS_TMS                     as SUCS_ITMS          --成功笔数
		  ,t.FALL_TMS                     as FALL_ITMS          --失败笔数
		  ,t.RETURN_TMS                   as RETURN_TMS         --退回次数
		  ,t.SUCS_TMS                     as SUCS_TMS           --成功次数
		  ,t.FALL_TMS                     as FALL_TMS           --失败次数
		  ,t.TMS1                         as TMS1               --次数
		  ,t.AUDT_TS                      as AUDT_TS            --审核时长 
          ,ROUND(t.AUDT_TS/a1.PSN_NUM,2)  as PSN_AVG_AUDT_TS    --人均审核时长
		  ,ROUND(t.AUDT_TS/t.TMS,2)       as AVG_AUDT_TS        --单次时长
		  ,ROUND(t.IDV_AUDT_TS/t.IDV_TMS,2)       as AVG_IDV_AUDT_TS        --个人单次时长
		  ,ROUND(t.ORG_AUDT_TS/t.ORG_TMS,2)       as AVG_ORG_AUDT_TS        --机构单次时长
		  ,CAST(t.YEAR_MON as INT)             as YEAR_MON
 FROM        RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_MON_TEMP t
 LEFT JOIN   RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_MON_TEMP1 a1
 ON          t.YEAR_MON = a1.YEAR_MON 
 ;
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','DDW_APP_DASHBORD_OPERATE_HIS_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
 
 DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_MON_TEMP;
 DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_MON_TEMP1;
   invalidate metadata RPT_DB.DDW_APP_DASHBORD_OPERATE_HIS_MON ;
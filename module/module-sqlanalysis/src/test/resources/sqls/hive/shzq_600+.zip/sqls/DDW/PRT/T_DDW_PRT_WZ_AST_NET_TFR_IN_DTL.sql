 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:温州分公司客户资产净流入明细表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */  

  

  
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_WZ_AST_NET_TFR_IN_DTL
(             BELTO_FILIL_CDG         --地区编号
			 ,BELTO_FILIL             --地区名称
			 ,BRH_NO                  --营业部编号
			 ,BRH_SHRTNM              --营业部名称
			 ,CUST_NO                 --客户号
			 ,CUST_NAME               --客户姓名
			 ,FNL_ORDI_AST	           --期末普通资产
			 ,FNL_CRD_AST             --期末信用资产
			 ,FNL_WRNT_AST            --期末期权资产
			 ,FNL_CRD_GL              --信用负债
			 ,ORDI_NET_TFR_IN_AMT     --普通账户资产净流入
			 ,CRD_NET_TFR_IN_AMT      --信用账户资产净流入
			 ,WRNT_NET_TFR_IN_AMT     --期权账户资产净流入
			 ,NET_TFR_IN_AMT          --总资产净流入
)		
 PARTITION(YEAR_MON )
  SELECT       a1.BELTO_FILIL_CDG                          --地区编号
              ,a1.BELTO_FILIL                             --地区名称
              ,a2.BRH_NO                                   --营业部编号
              ,a1.BRH_SHRTNM                              --营业部名称
              ,t.CUST_NO                                  --客户号
              ,a2.CUST_NAME                               --客户姓名
              ,t.FNL_ORDI_AST	                          --期末普通资产
			  ,t.FNL_CRD_AST                              --期末信用资产
			  ,t.FNL_WRNT_AST                             --期末期权资产
			  ,(t.FNL_ORDI_GL+t.FNL_CRD_GL) as FNL_CRD_GL --信用负债
			  ,t.ORDI_NET_TFR_IN_AMT                        --普通账户资产净流入
			  ,t.CRD_NET_TFR_IN_AMT                         --信用账户资产净流入
			  ,t.WRNT_NET_TFR_IN_AMT                        --期权账户资产净流入
			  ,t.NET_TFR_IN_AMT                             --总资产净流入
			  ,t.YEAR_MON             as YEAR_MON
  FROM        DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON  t
  INNER JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_INFO                a2
  ON          t.CUST_NO = a2.CUST_NO
  AND         a2.BUS_DATE = %d{yyyyMMdd}
  INNER JOIN  DDW_PROD.T_DDW_INR_ORG_BRH                a1
  ON          a2.BRH_NO = a1.BRH_NO
  AND         a1.BUS_DATE = %d{yyyyMMdd}
  WHERE       a1.BELTO_FILIL_CDG = '0032'
  ;
-----------------------------加载结束--------------------
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_WZ_AST_NET_TFR_IN_DTL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_WZ_AST_NET_TFR_IN_DTL ;
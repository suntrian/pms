------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:基金代码表                                                                      */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
TRUNCATE TABLE DDW_PROD.T_DDW_PUB_FND_CD ;
INSERT OVERWRITE DDW_PROD.T_DDW_PUB_FND_CD
(
                                   FND_CD             --基金代码  
                                  ,TA_CD              --TA代码    
                                  ,SPNSR_CD           --发起人代码                      
                                  ,ADMIN_CD           --管理人代码
								  ,CSTN_CD            --托管人代码
                                  ,FND_NAME           --基金名称  
                                  ,FND_FULLNM         --基金全称  							                                   								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT         t.JJDM		    as FND_CD             --基金代码                           
               ,t.TADM	        as TA_CD              --TA代码    
               ,t.FQRDM	        as SPNSR_CD           --发起人代码  	                                        						    
               ,t.GLRDM	        as ADMIN_CD           --管理人代码
               ,t.TGRDM	        as CSTN_CD            --托管人代码
               ,t.JJMC	        as FND_NAME           --基金名称  
               ,t.JJQC	        as FND_FULLNM         --基金全称  	
 FROM           EDW_PROD.T_EDW_T04_TOF_JJXX                                 t       
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_FND_CD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_FND_CD;
 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360期权账户信息表                                                                      */
  --/* 创建人:程骏                                                                               */
  --/* 创建时间:2017-10-19                                                                        */ 
  /* T_DDW_F01_CUST_INFO	替换为	T_DDW_F00_CUST_CUST_INFO */
  
---------------- 插入集中交易数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_WRNT_INFO
 (
	 CUST_NO			--客户号            
	,CUST_NAME			--客户姓名姓名      
	,BRH_NAME			--营业部名称        
	,WRNT_OPNAC_DT		--开户日期          
	,WRNT_CUST_STAT		--客户状态          
	,WRNT_IVSTR_LVL		--个股期权投资者级别
	,WRNT_IVSTR_CL		--个股期权投资者分类     
 ) PARTITION( BUS_DATE = %d{yyyyMMdd})
  SELECT     t.CUST_NO                           as CUST_NO			    --客户号            
	        ,t.CUST_NAME                         as CUST_NAME			--客户姓名姓名      
	        ,t.BRH_NAME                          as BRH_NAME			--营业部名称        
	        ,a1.GGQQKH_KHRQ                      as WRNT_OPNAC_DT		--开户日期          
	        ,a3.CUST_STAT_NAME                   as WRNT_CUST_STAT		--客户状态          
	        ,a4.WRNT_IVSTR_LVL_NAME              as WRNT_IVSTR_LVL		--个股期权投资者级别
	        ,a5.WRNT_IVSTR_GL_NAME               as WRNT_IVSTR_CL		--个股期权投资者分类   
 FROM        DDW_PROD.T_DDW_F00_CUST_CUST_INFO     t
 LEFT JOIN   EDW_PROD.T_EDW_T01_TKHXX         a1
 ON          t.CUST_NO = a1.KHH
 AND         t.BUS_DATE = a1.BUS_DATE 
 LEFT JOIN   EDW_PROD.T_EDW_T01_TKHQQXX       a2
 ON          t.CUST_NO = a2.KHH
 AND         t.BUS_DATE = a2.BUS_DATE
 LEFT JOIN   DDW_PROD.V_CUST_STAT             a3
 ON          a1.GGQQKH_KHZTDM = a3.CUST_STAT
 LEFT JOIN   DDW_PROD.V_WRNT_IVSTR_LVL A4
 ON          a2.sop_fxjb = a4.WRNT_IVSTR_LVL
 LEFT JOIN   DDW_PROD.V_WRNT_IVSTR_GL         a5
 ON          a2.sop_tzzfl = a5.WRNT_IVSTR_GL
 WHERE       t.BUS_DATE = %d{yyyyMMdd}
 AND         a2.KHH IS NOT NULL 
		;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_WRNT_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_WRNT_INFO;
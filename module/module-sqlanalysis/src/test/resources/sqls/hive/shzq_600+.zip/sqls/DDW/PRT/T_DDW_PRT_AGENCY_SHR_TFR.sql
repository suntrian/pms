 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:代办股份转让(确权)表                                                                      */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 


--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_AGENCY_SHR_TFR
(
									 BRH_NO									 --营业部编号			
									,BRH_NAME                                --营业部名称
									,ODR_SEQNBR                              --委托序号
									,HOST_SECCO                              --主办券商
									,AGENCY_SECCO                            --代办券商
									,SEAT_CD                                 --席位代码
									,SEC_CD                                  --证券代码
									,M_BOD_SHRHLD_CD                         --主板股东代码
									,T3BOD_SHRHLD_CD                         --三板股东代码
									,SHRNUM                                  --股数
									,CTF_NO                                  --证件号码
									,SHRHLD_NAME                             --股东姓名
									,COMM_ADDR                               --通讯地址
									,TEL_NO                                  --电话号码
									,ODR_DT                                  --委托日期
									,ODR_TM                                  --委托时间
									,BIZ_CGY                                 --业务类别
									,OPRT_TELR                               --操作柜员
									,CHRG_ACTNO                              --收费账号
									,T3BOD_ODR_DEAL_FLG                      --三板委托处理标志
									,DEAL_RSLT                               --处理结果
									,RIGHT_RSLT                              --确权结果
									,SECOND_CARD_VRFCTN                      --二代证验证                               
                                    ,CTF_CGY                                 --证件类别
								 ) 
 PARTITION(bus_date)
 SELECT 
                  t.BRH_NO                       AS BRH_NO					      --营业部编号		     
                 ,t.BRH_NAME                     AS BRH_NAME                       --营业部名称            
                 ,t.ODR_SEQNBR                   AS ODR_SEQNBR                     --委托序号              
                 ,t.HOST_SECCO                   AS HOST_SECCO                     --主办券商              
                 ,t.AGENCY_SECCO                 AS AGENCY_SECCO                   --代办券商              
                 ,t.SEAT_CD                      AS SEAT_CD                        --席位代码              
                 ,t.SEC_CD                       AS SEC_CD                         --证券代码              
                 ,t.M_BOD_SHRHLD_CD              AS M_BOD_SHRHLD_CD                --主板股东代码          
                 ,t.T3BOD_SHRHLD_CD              AS T3BOD_SHRHLD_CD                --三板股东代码          
                 ,t.SHRNUM                       AS SHRNUM                         --股数                  
                 ,t.CTF_NO                       AS CTF_NO                         --证件号码              
                 ,t.SHRHLD_NAME                  AS SHRHLD_NAME                    --股东姓名              
                 ,t.COMM_ADDR                    AS COMM_ADDR                      --通讯地址              
                 ,t.TEL_NO                       AS TEL_NO                         --电话号码              
                 ,t.ODR_DT                       AS ODR_DT                         --委托日期              
                 ,t.ODR_TM                       AS ODR_TM                         --委托时间              
                 ,t.BIZ_CGY                      AS BIZ_CGY                        --业务类别              
                 ,t.OPRT_TELR                    AS OPRT_TELR                      --操作柜员              
                 ,t.CHRG_ACTNO                   AS CHRG_ACTNO                     --收费账号              
                 ,t.T3BOD_ODR_DEAL_FLG           AS T3BOD_ODR_DEAL_FLG             --三板委托处理标志      
                 ,a1.T3BOD_ODR_DEAL_FLG_NAME     AS DEAL_RSLT                      --处理结果              
                 ,t.RIGHT_RSLT                   AS RIGHT_RSLT                     --确权结果              
                 ,t.SECOND_CARD_VRFCTN           AS SECOND_CARD_VRFCTN             --二代证验证               
                 ,a4.CTF_CGY_CD_NAME             AS CTF_CGY                        --证件类别
				 ,t.BUS_DATE                     AS BUS_DATE				 
  FROM  		DDW_PROD.T_DDW_F00_TRD_T3BOD_RIGHT_ODR_DEL_HIS  	t
  LEFT JOIN     DDW_PROD.V_T3BOD_ODR_DEAL_FLG               a1
  ON            t.T3BOD_ODR_DEAL_FLG = a1.T3BOD_ODR_DEAL_FLG
  LEFT JOIN     (SELECT SHRHLD_NO,CUST_NO FROM (
                 select SHRHLD_NO,CUST_NO,row_number()over(partition by SHRHLD_NO order by SHRHLD_OPNAC_DT) NUM
                 from DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO
                 where bus_date = %d{yyyyMMdd}
                 )t
				 where num = 1
                )a2
  ON            trim(t.T3BOD_SHRHLD_CD) = trim(a2.SHRHLD_NO)
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a3
  ON            A2.CUST_NO = a3.CUST_NO
  AND           a3.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD     a4
  ON            a3.CTF_CGY_CD = a4.CTF_CGY_CD
  WHERE 		t.T3BOD_ODR_DEAL_FLG = '1'
  UNION ALL
  SELECT 
                  t.BRH_NO                       AS BRH_NO					      --营业部编号		     
                 ,t.BRH_NAME                     AS BRH_NAME                       --营业部名称            
                 ,t.ODR_SEQNBR                   AS ODR_SEQNBR                     --委托序号              
                 ,t.HOST_SECCO                   AS HOST_SECCO                     --主办券商              
                 ,t.AGENCY_SECCO                 AS AGENCY_SECCO                   --代办券商              
                 ,t.SEAT_CD                      AS SEAT_CD                        --席位代码              
                 ,t.SEC_CD                       AS SEC_CD                         --证券代码              
                 ,t.M_BOD_SHRHLD_CD              AS M_BOD_SHRHLD_CD                --主板股东代码          
                 ,t.T3BOD_SHRHLD_CD              AS T3BOD_SHRHLD_CD                --三板股东代码          
                 ,t.SHRNUM                       AS SHRNUM                         --股数                  
                 ,t.CTF_NO                       AS CTF_NO                         --证件号码              
                 ,t.SHRHLD_NAME                  AS SHRHLD_NAME                    --股东姓名              
                 ,t.COMM_ADDR                    AS COMM_ADDR                      --通讯地址              
                 ,t.TEL_NO                       AS TEL_NO                         --电话号码              
                 ,t.ODR_DT                       AS ODR_DT                         --委托日期              
                 ,t.ODR_TM                       AS ODR_TM                         --委托时间              
                 ,t.BIZ_CGY                      AS BIZ_CGY                        --业务类别              
                 ,t.OPRT_TELR                    AS OPRT_TELR                      --操作柜员              
                 ,t.CHRG_ACTNO                   AS CHRG_ACTNO                     --收费账号              
                 ,t.T3BOD_ODR_DEAL_FLG           AS T3BOD_ODR_DEAL_FLG             --三板委托处理标志      
                 ,a1.T3BOD_ODR_DEAL_FLG_NAME     AS DEAL_RSLT                      --处理结果              
                 ,t.RIGHT_RSLT                   AS RIGHT_RSLT                     --确权结果              
                 ,t.SECOND_CARD_VRFCTN           AS SECOND_CARD_VRFCTN             --二代证验证              
                 ,a4.CTF_CGY_CD_NAME             AS CTF_CGY
                 ,t.BUS_DATE                     AS BUS_DATE			
				 
  FROM  		DDW_PROD.T_DDW_F00_TRD_T3BOD_RIGHT_ODR_DEL_HIS  	t
  LEFT JOIN     DDW_PROD.V_T3BOD_ODR_DEAL_FLG               a1
  ON            t.T3BOD_ODR_DEAL_FLG = a1.T3BOD_ODR_DEAL_FLG
  LEFT JOIN     (SELECT SHRHLD_NO,CUST_NO FROM (
                 select SHRHLD_NO,CUST_NO,row_number()over(partition by SHRHLD_NO order by SHRHLD_OPNAC_DT) NUM
                 from DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO
                 where bus_date = %d{yyyyMMdd}
                 )t
				 where num = 1
                )a2
  ON            trim(t.T3BOD_SHRHLD_CD) = trim(a2.SHRHLD_NO)
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a3
  ON            A2.CUST_NO = a3.CUST_NO
  AND           a3.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD     a4
  ON            a3.CTF_CGY_CD = a4.CTF_CGY_CD
  WHERE 		 t.T3BOD_ODR_DEAL_FLG <> '1'
  AND           NOT EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_TRD_T3BOD_RIGHT_ODR_DEL_HIS b
                            WHERE t.ODR_DT = b.ODR_DT AND t.CHRG_ACTNO = b.CHRG_ACTNO AND t.SEC_CD = b.SEC_CD AND t.BIZ_CGY = b.BIZ_CGY  AND b.T3BOD_ODR_DEAL_FLG = '1' )
 ;
-----------------------------加载结束--------------------
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_AGENCY_SHR_TFR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_AGENCY_SHR_TFR;
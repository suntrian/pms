------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户信息表                                                                       */
------/* 创建人:常静静                                                                               */
------/* 创建时间:2018-08-29                                                                        */ 


--------------插入数据-------------------
INSERT OVERWRITE DDW_PROD.T_DDW_LM_CUST_BAS_ATTR
(                                   CUST_NO                                	--1. 客户号
                                   ,CUST_NAME                              	--2. 客户名称
                                   ,CUST_CGY                               	--3. 客户类型
                                   ,CUST_STAT                              	--4. 客户状态
                                   ,GJDM 	 							   	--5. 国籍代码
                                   ,MZDM                                   	--6. 民族代码
                                   ,GNDR_CD                                	--7. 性别代码
                                   ,AGE       								--8. 年龄
                                   ,OCP_CD									--9. 职业
                                   ,EDU_CD       							--10. 学历
                                   ,MARG_STAT_CD							--11. 婚姻状况
                                   ,ORDI_OPNAC_DT       					--12. 普通账户开户日期
                                   ,CRD_OPNAC_DT       						--13. 信用账户开户日期
                                   ,WRNT_OPNAC_DT       					--14. 期权账户开户日期
                                   ,ORDI_OPNAC_DEDLN						--15. 普通账户开户日期期限
                                   ,CRD_OPNAC_DEDLN       					--16. 信用账户开户日期期限
                                   ,WRNT_OPNAC_DEDLN       					--17. 期权账户开户日期期限
                                   ,OPNAC_MOD								--18. 开户方式
                                   ,CTF_CGY_CD       						--19. 证件类型
                                   ,CTF_EXPR_DT       						--20. 证件有效期
                                   ,PROVINCE								--21. 省份
                                   ,IDSTR_CD       							--22. 行业代码
                                   ,ORG_CUST_ORG_CGY						--23. 机构类别代码
                                   ,ETP_CGY_CD       						--24. 企业类别代码
                                   ,CTCT_MOD       							--25. 联系方式
                                   ,DEPMGT_BANK       						--26. 存管银行
                                   ,CTRL_ATTR       						--27. 控制属性
                                   ,BRTH       								--28. 客户生日
                                   ,CUST_RLN       							--29. 客户关系
                                   ,SVC_USR									--30. 服务人员
                                   ,SVC_TEAM       							--31. 服务团队
                                   ,PERF_CNDT       						--32. 履约情况
                                   ,IVSTR_CL								--33. 投资者分类
                                   ,ZYYXRQ       							--34. 专业投资者有效日期
                                   ,YXRQ       								--35. 有效日期
                                   ,RSK_BEAR_ABLTY							--36. 风险承受能力
                                   ,IVSM_CL       							--37. 投资品种
                                   ,IVSM_DEDLN								--38. 投资期限
                                   ,EXPD_YLD       							--39. 预期收益
                                   ,XQFXDJ       							--40. 洗钱风险等
                                   ,A_STK_PRVL								--41. 开通A股
                                   ,B_STK_PRVL       						--42. 开通B股
                                   ,GEM_PRVL       							--43. 开通创业板
                                   ,STRU_FND_PRVL							--44. 开通分级基金
                                   ,HSK_STK_PRVL       						--45. 开通港股通
                                   ,SHR_TFR_PRVL       						--46. 开通股转交易
                                   ,BOND_QLFD_IVSTR							--47. 开通债券合格投资者
                                   ,REPO_MRGNS_PRVL       					--48. 开通回购融券
                                   ,CASH_FND_PRVL							--49. 开通现金添利
                                   ,QOT_REPO_PRVL       					--50. 开通报价回购
                                   ,MRGNC_MRGNS_PRVL       					--51. 开通融资融券
                                   ,STK_PLG_PRVL       						--52. 开通股票质押
                                   ,PROMS_RPHS_PRVL       					--53. 开通约定购回
                                   ,STK_WRNT_PRVL       					--54. 开通股票期权
                                   ,FND_PRVL       							--55. 开通基金账户
                                   ,MNY_ACCNT_PRVL       					--56. 开通理财账户
                                   ,FND_FIXINV_PRVL       					--57. 签约基金定投
                                   ,OPN_BIZ_CL       						--58. 开通业务品种
                                   ,FSTTM_MTCH_DT       					--59. 首次成交日期
                                   ,IVSM_EXP       							--60. 投资经验

)
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
        T1.CUST_NO                                                                                                  --1. 客户号
	   ,T1.CUST_NAME                                                                                                --2. 客户名称
	   ,CASE WHEN T3.CUST_NO IS NOT NULL AND NVL(T3.PROD_CGY,0) = 1 THEN 2
	         WHEN T3.CUST_NO IS NOT NULL AND NVL(T3.PROD_CGY,0) <> 1 THEN 1
	    ELSE 0 END AS CUST_CGY                                                                                      --3. 客户类型
	   ,T4.YGT_KHZTDM AS CUST_STAT                                                                                  --4. 客户状态
	   ,NVL(T1.CITY_CD,'#') AS GJDM                                                                                 --5. 国籍代码
	   ,NVL(T1.NATN_CD,'#') AS MZDM                                                                                 --6. 民族代码
	   ,NVL(T1.GNDR_CD,'#') AS GNDR_CD                                                                              --7. 性别代码
	   ,CASE WHEN CAST(SUBSTR('%d{yyyyMMdd}',5,2) AS INT) > CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(T5.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
             THEN CAST(SUBSTR('%d{yyyyMMdd}',1,4) AS INT) - CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),1,4) AS INT)
             WHEN CAST(SUBSTR('%d{yyyyMMdd}',5,2) AS INT) < CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(T5.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
             THEN CAST(SUBSTR('%d{yyyyMMdd}',1,4) AS INT) - CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),1,4) AS INT) - 1
             WHEN CAST(SUBSTR('%d{yyyyMMdd}',5,2) AS INT) = CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(T5.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
              AND CAST(SUBSTR('%d{yyyyMMdd}',7,2) AS INT) >= CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),7,2) AS INT)
            THEN CAST(SUBSTR('%d{yyyyMMdd}',1,4) AS INT) - CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),1,4) AS INT)
            WHEN CAST(SUBSTR('%d{yyyyMMdd}',5,2) AS INT) = CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(T5.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
             AND CAST(SUBSTR('%d{yyyyMMdd}',7,2) AS INT) < CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),7,2) AS INT)
            THEN CAST(SUBSTR('%d{yyyyMMdd}',1,4) AS INT) - CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),1,4) AS INT) - 1
        ELSE 0 END AS AGE                                                                                           --8. 年龄
	   ,REPLACE(NVL(T1.OCP_CD,'0'),'ERR','') AS OCP_CD                                                              --9. 职业
	   ,NVL(T1.EDU_CD,'10000') AS EDU_CD                                                                            --10. 学历
	   ,NVL(T1.MARG_STAT_CD,'0') AS MARG_STAT_CD                                                                    --11. 婚姻状况
	   ,CASE WHEN T1.ORDI_OPNAC_DT BETWEEN 10000101 AND 99991231 THEN T1.ORDI_OPNAC_DT
	    ELSE 99991231 END AS ORDI_OPNAC_DT                                                                          --12.普通账户开户日期
	   ,CASE WHEN T19.KHRQ_RZRQ BETWEEN 10000101 AND 99991231 THEN T19.KHRQ_RZRQ
	    ELSE 99991231 END AS CRD_OPNAC_DT                                                                           --13.信用账户开户日期
	   ,CASE WHEN T18.KHRQ_GGQQ BETWEEN 10000101 AND 99991231 THEN T18.KHRQ_GGQQ
	    ELSE 99991231 END AS WRNT_OPNAC_DT                                                                          --14.期权账户开户日期
       ,CASE WHEN T1.ORDI_OPNAC_DT BETWEEN 10000101 AND 99991231
             THEN DATEDIFF( CAST(CONCAT( SUBSTR('%d{yyyyMMdd}',1,4)
                                              ,'-'
                                              ,SUBSTR('%d{yyyyMMdd}',5,2)
                                              ,'-'
                                              ,SUBSTR('%d{yyyyMMdd}',7,2)
                                             ) AS TIMESTAMP
                                      )
                                 ,CAST(CONCAT( SUBSTR(CAST(T1.ORDI_OPNAC_DT AS STRING),1,4)
                                              ,'-'
                                              ,SUBSTR(CAST(T1.ORDI_OPNAC_DT AS STRING),5,2)
                                              ,'-'
                                              ,SUBSTR(CAST(T1.ORDI_OPNAC_DT AS STRING),7,2)
                                             ) AS TIMESTAMP
                                      )
                                )
        ELSE -1 END AS ORDI_OPNAC_DEDLN                                                                              --15.普通账户开户日期期限
	   ,CASE WHEN T1.CRD_OPNAC_DT BETWEEN 10000101 AND 99991231
             THEN DATEDIFF(CAST(CONCAT( SUBSTR('%d{yyyyMMdd}',1,4)
                                              ,'-'
                                              ,SUBSTR('%d{yyyyMMdd}',5,2)
                                              ,'-'
                                              ,SUBSTR('%d{yyyyMMdd}',7,2)
                                             ) AS TIMESTAMP
                                      )
                                 ,CAST(CONCAT( SUBSTR(CAST(T19.KHRQ_RZRQ AS STRING),1,4)
                                              ,'-'
                                              ,SUBSTR(CAST(T19.KHRQ_RZRQ AS STRING),5,2)
                                              ,'-'
                                              ,SUBSTR(CAST(T19.KHRQ_RZRQ AS STRING),7,2)
                                             ) AS TIMESTAMP
                                      )
                                )
        ELSE -1 END AS CRD_OPNAC_DEDLN                                                                               --16.信用账户开户日期期限
	   ,CASE WHEN T18.KHRQ_GGQQ BETWEEN 10000101 AND 99991231
             THEN DATEDIFF(CAST(CONCAT( SUBSTR('%d{yyyyMMdd}',1,4)
                                              ,'-'
                                              ,SUBSTR('%d{yyyyMMdd}',5,2)
                                              ,'-'
                                              ,SUBSTR('%d{yyyyMMdd}',7,2)
                                             ) AS TIMESTAMP
                                      )
                                 ,CAST(CONCAT( SUBSTR(CAST(T18.KHRQ_GGQQ AS STRING),1,4)
                                              ,'-'
                                              ,SUBSTR(CAST(T18.KHRQ_GGQQ AS STRING),5,2)
                                              ,'-'
                                              ,SUBSTR(CAST(T18.KHRQ_GGQQ AS STRING),7,2)
                                             ) AS TIMESTAMP
                                      )
                                )
        ELSE -1 END AS WRNT_OPNAC_DEDLN                                                                              --17.期权账户开户日期期限
	   ,NVL(T1.OPNAC_MOD,'0') AS OPNAC_MOD                                                                          --18.开户方式
	   ,NVL(T1.CTF_CGY_CD,'#') AS CTF_CGY_CD                                                                        --19.证件类型
	   ,NVL(T1.CTF_EXPR_DT,0) AS CTF_EXPR_DT                                                                        --20.证件有效期
	   ,CASE WHEN LENGTH(NVL(T4.PROVINCE,'')) <> 6 THEN NVL(T2.BELTO_PROV,'#') ELSE T4.PROVINCE END AS PROVINCE     --21.省份
       ,NVL(T3.IDSTR_CD,'#') AS IDSTR_CD                                                                            --22.行业代码
	   ,NVL(T3.ORG_CUST_ORG_CGY,'#') AS ORG_CUST_ORG_CGY                                                            --23.机构类别代码
	   ,NVL(T3.ETP_CGY_CD,'#') AS ETP_CGY_CD                                                                        --24.企业类别代码
	   ,COALESCE(T1.PHONE,T1.CTCT_TEL,T4.EMAIL,'#') AS CTCT_MOD                                                     --25.联系方式
	   ,NVL(T1.DEPMGT_BANK,'#') AS DEPMGT_BANK                                                                      --26.存管银行
	   ,REPLACE(NVL(T1.CTRL_ATTR,'#'),'ERR','') AS CTRL_ATTR                                                        --27.控制属性
	   ,NVL(T5.CSRQ,0) AS BRTH                                                                                      --28.客户生日
	   ,NVL(T6.FWGXLX,'#') AS CUST_RLN                                                                              --29.客户关系
	   ,NVL(T6.RYXX,'#') AS SVC_USR                                                                                 --30.服务人员
	   ,NVL(T6.TD,'#') AS SVC_TEAM                                                                                  --31.服务团队
	   ,CASE WHEN T7.KHH IS NOT NULL THEN '0' ELSE '1' END AS PERF_CNDT                                             --32.履约情况
	   ,NVL(T8.TZZFL,0) AS IVSTR_CL                                                                                 --33.投资者分类
	   ,NVL(T8.TZZPDYXQ,0) AS ZYYXRQ                                                                                --34.专业投资者有效日期
	   ,NVL(T9.YXRQ,0) AS YXRQ                                                                                      --35.有效日期
	   ,NVL(T1.RSK_BEAR_ABLTY,'#') AS RSK_BEAR_ABLTY                                                                --36.风险承受能力
	   ,NVL(T8.TZPZ,'#') AS IVSM_CL                                                                                 --37.投资品种
	   ,NVL(T8.TZQX,999) AS IVSM_DEDLN                                                                                --38.投资期限
	   ,NVL(CAST(T8.YQSY AS INT),0) AS EXPD_YLD                                                                     --39.预期收益
	   ,NVL(T8.XQFXDJ,0) AS XQFXDJ                                                                                  --40.洗钱风险等
	   ,NVL(T10.A_STK_PRVL,'0') AS A_STK_PRVL                                                                       --41.开通A股
	   ,NVL(T10.B_STK_PRVL,'0') AS B_STK_PRVL                                                                       --42.开通B股
	   ,NVL(T11.GEM_PRVL,'0') AS GEM_PRVL                                                                           --43.开通创业板
	   ,NVL(T11.STRU_FND_PRVL,'0') AS STRU_FND_PRVL                                                                 --44.开通分级基金
	   ,NVL(T10.HSK_STK_PRVL,'0') AS HSK_STK_PRVL                                                                   --45.开通港股通
	   ,NVL(T11.SHR_TFR_PRVL,'0') AS SHR_TFR_PRVL                                                                   --46.开通股转交易
	   ,NVL(T11.BOND_QLFD_IVSTR,'0') AS BOND_QLFD_IVSTR                                                             --47.开通债券合格投资者
	   ,NVL(T11.REPO_MRGNS_PRVL,'0') AS REPO_MRGNS_PRVL                                                             --48.开通回购融券
	   ,NVL(T12.CASH_FND_PRVL,'0') AS CASH_FND_PRVL                                                                 --49.开通现金添利
	   ,NVL(T11.QOT_REPO_PRVL,'0') AS QOT_REPO_PRVL                                                                 --50.开通报价回购
	   ,NVL(T13.MRGNC_MRGNS_PRVL,'0') AS MRGNC_MRGNS_PRVL                                                           --51.开通融资融券
	   ,NVL(T11.STK_PLG_PRVL,'0') AS STK_PLG_PRVL                                                                   --52.开通股票质押
	   ,NVL(T11.PROMS_RPHS_PRVL,'0') AS PROMS_RPHS_PRVL                                                             --53.开通约定购回
	   ,NVL(T13.STK_WRNT_PRVL,'0') AS STK_WRNT_PRVL                                                                 --54.开通股票期权
	   ,NVL(T10.FND_PRVL,'0') AS FND_PRVL                                                                           --55.开通基金账户
	   ,NVL(T14.MNY_ACCNT_PRVL,'0') AS MNY_ACCNT_PRVL                                                               --56.开通理财账户
	   ,NVL(T15.FND_FIXINV_PRVL,'0') AS FND_FIXINV_PRVL                                                             --57.签约基金定投
	   ,NVL(T16.OPN_BIZ_CL,'#') AS OPN_BIZ_CL                                                                       --58.开通业务品种
	   ,NVL(T17.FSTTM_MTCH_DT,0) AS FSTTM_MTCH_DT                                                                   --59.首次成交日期
	   ,CASE WHEN T17.FSTTM_MTCH_DT BETWEEN 10000101 AND 99991231
             THEN DATEDIFF(CAST(CONCAT( SUBSTR('%d{yyyyMMdd}',1,4)
                                              ,'-'
                                              ,SUBSTR('%d{yyyyMMdd}',5,2)
                                              ,'-'
                                              ,SUBSTR('%d{yyyyMMdd}',7,2)
                                             ) AS TIMESTAMP
                                      )
                                 ,CAST(CONCAT( SUBSTR(CAST(T17.FSTTM_MTCH_DT AS STRING),1,4)
                                              ,'-'
                                              ,SUBSTR(CAST(T17.FSTTM_MTCH_DT AS STRING),5,2)
                                              ,'-'
                                              ,SUBSTR(CAST(T17.FSTTM_MTCH_DT AS STRING),7,2)
                                             ) AS TIMESTAMP
                                      )
                                )
        ELSE -1 END AS IVSM_EXP                                                                                      --60.投资经验
FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T1.BRH_NO = T2.BRH_NO
AND T2.BUS_DATE = T1.BUS_DATE
LEFT JOIN DDW_PROD.T_DDW_F00_CUST_ORG_CUST_INFO T3
ON T1.CUST_NO = T3.CUST_NO
AND T3.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN EDW_PROD.T_EDW_T01_TKHXX T4
ON T1.CUST_NO = T4.KHH
AND T4.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN     EDW_PROD.T_EDW_T01_TGRKHXX T5
ON T1.CUST_NO = T5.KHH 
AND T5.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN (
            SELECT A.KHH,A.FWGXLX,B.RYXX,C.TD
			FROM
            (SELECT KHH
                  ,GROUP_CONCAT(DISTINCT CAST(FWGXLX AS STRING),';') AS FWGXLX
		      FROM EDW_PROD.T_EDW_T01_TKHGX
             WHERE BUS_DATE = %d{yyyyMMdd} AND RYZHZT = '0'
            GROUP BY KHH
			) A
			LEFT JOIN 
			(
			  SELECT KHH
                    ,GROUP_CONCAT(DISTINCT CAST(RYXX AS STRING),';') AS RYXX
		        FROM EDW_PROD.T_EDW_T01_TKHGX
               WHERE BUS_DATE = %d{yyyyMMdd} AND RYZHZT = '0'
              GROUP BY KHH
			) B
			ON A.KHH = B.KHH
			LEFT JOIN 
			(
			  SELECT KHH
                    ,GROUP_CONCAT(DISTINCT CAST(TD AS STRING),';') AS TD
		        FROM EDW_PROD.T_EDW_T01_TKHGX
               WHERE BUS_DATE = %d{yyyyMMdd} AND RYZHZT = '0'
              GROUP BY KHH
			) C
            ON A.KHH = C.KHH
          ) T6
ON T1.CUST_NO = T6.KHH
LEFT JOIN EDW_PROD.T_EDW_T99_TWYZZZH T7
ON T1.CUST_NO = T7.KHH
AND T7.BUS_DATE=%d{yyyyMMdd}
LEFT JOIN YGTCX.CIF_TKHYWSX T8
ON T1.CUST_NO = T8.KHH
AND T8.DT = '%d{yyyyMMdd}'
LEFT JOIN EDW_PROD.T_EDW_T99_TKHSDXSX T9
ON T1.CUST_NO = T9.KHH
AND T9.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN 
         (
           SELECT KHH
		         ,MAX(CASE WHEN GDZHLB IN ('1','3') THEN '1' ELSE '0' END) AS A_STK_PRVL
				 ,MAX(CASE WHEN GDZHLB IN('4','5','6') THEN '1' ELSE '0' END) AS B_STK_PRVL
				 ,MAX(CASE WHEN GDZHLB IN('9','10') THEN '1' ELSE '0' END) AS HSK_STK_PRVL
				 ,MAX(CASE WHEN GDZHLB = '1' THEN '1' ELSE '0' END) AS FND_PRVL
		     FROM EDW_PROD.T_EDW_T02_TKHJYQX
			WHERE BUS_DATE = %d{yyyyMMdd}
			  AND GDZHLB IN ('1','3','4','5','6','9','10')
			  AND JYQX =1
			GROUP BY KHH
         ) T10
ON T1.CUST_NO = T10.KHH
LEFT JOIN 
         (
		   SELECT
		          CUST_NO
				 ,MAX(CASE WHEN OPN_PRVL = 7 THEN '1' ELSE '0' END) AS GEM_PRVL
				 ,MAX(CASE WHEN OPN_PRVL = 117 THEN '1' ELSE '0' END) AS STRU_FND_PRVL
				 ,MAX(CASE WHEN OPN_PRVL = 6 THEN '1' ELSE '0' END) AS SHR_TFR_PRVL
				 ,MAX(CASE WHEN OPN_PRVL = 12 THEN '1' ELSE '0' END) AS BOND_QLFD_IVSTR
				 ,MAX(CASE WHEN OPN_PRVL = 3 THEN '1' ELSE '0' END) AS REPO_MRGNS_PRVL
				 ,MAX(CASE WHEN OPN_PRVL = 101 THEN '1' ELSE '0' END) AS QOT_REPO_PRVL
				 ,MAX(CASE WHEN OPN_PRVL = 106 THEN '1' ELSE '0' END) AS STK_PLG_PRVL
				 ,MAX(CASE WHEN OPN_PRVL = 102 THEN '1' ELSE '0' END) AS PROMS_RPHS_PRVL
             FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
			 WHERE BUS_DATE = %d{yyyyMMdd}
			   AND %d{yyyyMMdd} >= OPN_DT
               AND CHG_DT > %d{yyyyMMdd}
			   AND OPN_PRVL IN (3,6,7,12,101,102,106,117)
			 GROUP BY CUST_NO
         ) T11
ON T1.CUST_NO = T11.CUST_NO
LEFT JOIN 
         (
		   SELECT DISTINCT CUST_NO,'1' AS CASH_FND_PRVL
		   FROM DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL
		   WHERE BUS_DATE = %d{yyyyMMdd} AND TML_DT > %d{yyyyMMdd}
		 ) T12
ON T1.CUST_NO = T12.CUST_NO
LEFT JOIN
         (
           SELECT CUST_NO,MAX(CASE WHEN SYS_SRC = '信用账户' THEN '1' ELSE '0' END) AS MRGNC_MRGNS_PRVL
		         ,MAX(CASE WHEN SYS_SRC = '期权账户' THEN '1' ELSE '0' END) AS STK_WRNT_PRVL
             FROM DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
            WHERE BUS_DATE = %d{yyyyMMdd}
              AND SYS_SRC IN ('信用账户','期权账户')
              AND CPTL_ACCNT_STAT <> '3'
         GROUP BY CUST_NO
         ) T13
ON T1.CUST_NO = T13.CUST_NO
LEFT JOIN
         (
           SELECT DISTINCT KHH,'1' AS MNY_ACCNT_PRVL
             FROM EDW_PROD.T_EDW_T02_TJRCP_CPZH
            WHERE BUS_DATE = %d{yyyyMMdd}
              AND JRCP_ZHZT = 0
	     ) T14
ON T1.CUST_NO = T14.KHH
LEFT JOIN 
         (
		   SELECT DISTINCT KHH,'1' AS FND_FIXINV_PRVL
             FROM EDW_PROD.T_EDW_T02_TOF_DQDESGXY
            WHERE BUS_DATE = %d{yyyyMMdd} 
			AND OF_DQDEXYZT IN ('0','10')
		 ) T15
ON T1.CUST_NO = T15.KHH
LEFT JOIN
         (
		   SELECT CUST_NO
                 ,GROUP_CONCAT(DISTINCT CAST(OPN_PRVL AS STRING),';') AS OPN_BIZ_CL
		     FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
		    WHERE BUS_DATE = %d{yyyyMMdd}
			  AND %d{yyyyMMdd} >= OPN_DT 
              AND CHG_DT > %d{yyyyMMdd}
           GROUP BY CUST_NO
		 ) T16
ON T1.CUST_NO = T16.CUST_NO
LEFT JOIN
         (
           --SELECT KHH,COALESCE(MIN(SCJYRQ),MIN(CAST(BGSSCJYRQ AS INT))) AS FSTTM_MTCH_DT FROM EDW_PROD.T_EDW_T02_TGDH GROUP BY KHH
		   SELECT T1.KHH AS KHH,T2.SCJYRQ AS FSTTM_MTCH_DT
           FROM YGTCX.CIF_TKHXX T1
           LEFT JOIN 
           (
             SELECT ZJLB,ZJBH,MIN(SCJYRQ) AS SCJYRQ
             FROM YGTCX.CIF_TZD_GDCXJG
             WHERE DT = '%d{yyyyMMdd}'
             AND NVL(SCJYRQ,0) > 0
             GROUP BY ZJLB,ZJBH
           ) T2
           ON T1.ZJLB = T2.ZJLB
           AND T1.ZJBH = T2.ZJBH
           WHERE DT = '%d{yyyyMMdd}'
         ) T17
ON T1.CUST_NO = T17.KHH
LEFT JOIN 
        (
          SELECT KHH,MIN(KHRQ) AS KHRQ_GGQQ
          FROM EDW_PROD.T_EDW_T02_TZJZH
          WHERE BUS_DATE = %d{yyyyMMdd}
          AND XTBS = 'GGQQ'
          AND ZJZHZT <> '3'
		  GROUP BY KHH
        ) T18
ON T1.CUST_NO = T18.KHH
LEFT JOIN 
        (
          SELECT KHH,MIN(KHRQ) AS KHRQ_RZRQ
          FROM EDW_PROD.T_EDW_T02_TZJZH
          WHERE BUS_DATE = %d{yyyyMMdd}
          AND XTBS = 'RZRQ'
          AND ZJZHZT <> '3'
		  GROUP BY KHH
        ) T19
ON T1.CUST_NO = T19.KHH
WHERE T1.BUS_DATE = %d{yyyyMMdd}
;


INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_LM_CUST_BAS_ATTR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
invalidate metadata DDW_PROD.T_DDW_LM_CUST_BAS_ATTR;
---------------- 插入数据结束 -----------------------
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户现金添利产品签约明细                                                            */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2018-07-30                                                                        */ 
ALTER TABLE DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ; 
-----取昨日变动的
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP 
as SELECT      t.CUST_NO               --客户号
              ,t.CUST_NAME             --客户姓名
              ,t.BRH_NO                --营业部
              ,t.BRH_NAME              --营业部名称
              ,t.CTF_NO                --证件号码
              ,t.SIGN_DT               --签约日期
              ,t.TML_DT                --解约日期
              ,t.FSTTM_TRD_DT               --首次交易日期			  
FROM  DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL t
INNER JOIN (SELECT LST_TRD_D 
            FROM    EDW_PROD.T_EDW_T99_TRD_DATE
            WHERE   BUS_DATE = %d{yyyyMMdd}
			AND TRD_DT = %d{yyyyMMdd} 
			GROUP BY LST_TRD_D
			)   a1
ON    t.BUS_DATE = a1.LST_TRD_D
WHERE t.TML_DT < > 99999999
;

 ---取昨天未变动的客户临时表 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP1 ;
CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP1 
as SELECT      t.CUST_NO               --客户号
              ,t.CUST_NAME             --客户姓名
              ,t.BRH_NO                --营业部
              ,t.BRH_NAME              --营业部名称
              ,t.CTF_NO                --证件号码
              ,t.SIGN_DT               --签约日期
              ,t.TML_DT                --解约日期
              ,t.FSTTM_TRD_DT          --首次交易日期				  
FROM  DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL t
INNER JOIN (SELECT LST_TRD_D 
            FROM    EDW_PROD.T_EDW_T99_TRD_DATE
            WHERE   BUS_DATE = %d{yyyyMMdd}
			AND TRD_DT = %d{yyyyMMdd}
            GROUP BY LST_TRD_D			  
			)   a1
ON    t.BUS_DATE = a1.LST_TRD_D
WHERE t.TML_DT = 99999999
;	
---------取今天数据	
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP2; 
 CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP2
 as SELECT     t.KHH            as CUST_NO               --客户号
              ,a1.KHXM           as CUST_NAME             --客户姓名
              ,a2.BRH_NO        as BRH_NO                --营业部
              ,a2.BRH_SHRTNM    as BRH_NAME              --营业部名称
              ,a1.ZJBH          as CTF_NO                --证件号码
              ,t.QYRQ           as SIGN_DT               --签约日期
              ,CASE WHEN a1.JZJYKH_KHZTDM = '3'
			        THEN a1.JZJYKH_XHRQ
					ELSE 99999999 
					END        as TML_DT                --解约日期           
FROM         EDW_PROD.T_EDW_T02_TOF_ELCHTXY t
LEFT JOIN    EDW_PROD.T_EDW_T01_TKHXX    a1
ON           t.KHH = a1.KHH
AND          a1.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN DDW_PROD.T_DDW_INR_ORG_BRH a2
ON           a1.YYB = a2.BRH_NO
AND          a2.BUS_DATE = %d{yyyyMMdd}
WHERE       t.BUS_DATE = %d{yyyyMMdd}
AND         t.JJDM = 'A30003'
;	 
--取首字交易日期
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP3 ;
CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP3 as
SELECT MIN(FSTTM_TRD_DT) as FSTTM_TRD_DT
      ,CUST_NO
FROM 
(SELECT    KHH            as CUST_NO
         ,MIN(bus_date)  as FSTTM_TRD_DT
FROM  EDW_PROD.T_EDW_T02_TOF_JJFE
WHERE JJDM = 'A30003'
AND  JJSL > 0
AND  BUS_DATE < = %d{yyyyMMdd}
GROUP BY CUST_NO
UNION ALL
SELECT   CUST_NO
        ,MIN(CASH_PROD_FSTTM_TRD_DT) as FSTTM_TRD_DT
FROM DDW_PROD.T_DDW_CFG_CASH_PROD
GROUP BY CUST_NO
) t
GROUP BY t.CUST_NO ;
-------插入数据昨日变动的
 INSERT INTO DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL
(
               CUST_NO               --客户号
              ,CUST_NAME             --客户姓名
              ,BRH_NO                --营业部
              ,BRH_NAME              --营业部名称
              ,CTF_NO                --证件号码
              ,SIGN_DT               --签约日期
              ,TML_DT                --解约日期
              ,FSTTM_TRD_DT          --首次交易日期
              ,FNL_HLD_SHR           --期末持有数量   
)PARTITION(BUS_DATE = %d{yyyyMMdd}) 
SELECT         t.CUST_NO                    --客户号
              ,t.CUST_NAME                  --客户姓名
              ,t.BRH_NO                     --营业部
              ,t.BRH_NAME                   --营业部名称
              ,t.CTF_NO                     --证件号码
              ,t.SIGN_DT                    --签约日期
              ,t.TML_DT                     --解约日期
              ,t.FSTTM_TRD_DT               --首次交易日期
			  ,0 as FNL_HLD_SHR           --期末持有数量
FROM DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP t ;
-------插入数据今天数据的  
 INSERT INTO DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL
(
               CUST_NO               --客户号
              ,CUST_NAME             --客户姓名
              ,BRH_NO                --营业部
              ,BRH_NAME              --营业部名称
              ,CTF_NO                --证件号码
              ,SIGN_DT               --签约日期
              ,TML_DT                --解约日期
              ,FSTTM_TRD_DT          --首次交易日期
              ,FNL_HLD_SHR           --期末持有数量   
)PARTITION(BUS_DATE = %d{yyyyMMdd}) 
SELECT         t.CUST_NO                    --客户号
              ,t.CUST_NAME                  --客户姓名
              ,t.BRH_NO                     --营业部
              ,t.BRH_NAME                   --营业部名称
              ,t.CTF_NO                     --证件号码
              ,LEAST(NVL(t.SIGN_DT,99999999),NVL(a1.SIGN_DT,99999999)) as SIGN_DT                    --签约日期
              ,t.TML_DT                     --解约日期
              ,NVL(a2.FSTTM_TRD_DT,a1.FSTTM_TRD_DT)               --首次交易日期
			  ,NVL(a3.JJSL,0) as FNL_HLD_SHR           --期末持有数量
FROM DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP2 t
LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP1 a1
ON         t.CUST_NO = a1.CUST_NO
LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP3 a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN   (SELECT     KHH       as CUST_NO
                       ,SUM(JJSL) as JJSL
             FROM EDW_PROD.T_EDW_T02_TOF_JJFE
             WHERE JJDM = 'A30003'
             AND  JJSL > 0
			 AND  bus_date = %d{yyyyMMdd}
			 GROUP BY KHH
			 )     a3  
 ON 	t.CUST_NO = a3.CUST_NO
WHERE NOT EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP b
                  WHERE  t.CUST_NO = b.CUST_NO
				  AND    t.SIGN_DT = b.SIGN_DT
				  AND    t.TML_DT = b.TML_DT
                  )
;  
---插入昨日未变化，今天变化的
 INSERT INTO DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL
(
               CUST_NO               --客户号
              ,CUST_NAME             --客户姓名
              ,BRH_NO                --营业部
              ,BRH_NAME              --营业部名称
              ,CTF_NO                --证件号码
              ,SIGN_DT               --签约日期
              ,TML_DT                --解约日期
              ,FSTTM_TRD_DT          --首次交易日期
              ,FNL_HLD_SHR           --期末持有数量   
)PARTITION(BUS_DATE = %d{yyyyMMdd}) 
SELECT         t.CUST_NO                    --客户号
              ,t.CUST_NAME                  --客户姓名
              ,t.BRH_NO                     --营业部
              ,t.BRH_NAME                   --营业部名称
              ,t.CTF_NO                     --证件号码
              ,LEAST(NVL(t.SIGN_DT,99999999),NVL(a1.SIGN_DT,99999999)) as SIGN_DT                    --签约日期
              ,%d{yyyyMMdd}                     --解约日期
              ,t.FSTTM_TRD_DT              --首次交易日期
			  ,0 as FNL_HLD_SHR           --期末持有数量
FROM DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP1 t
LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP2 a1
ON         t.CUST_NO = a1.CUST_NO
WHERE a1.CUST_NO IS NULL
;  
--
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP2 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP1 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL_TEMP3 ;

  
 ----------------------插入数据结束--------------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_CASH_PROD_SIGN_DTL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL ;

-- /* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户基本信息表                                                               		*/
 -- /* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */  

------插入数据
--TRUNCATE TABLE EDW_PROD.T_EDW_T01_TKHXX;
 INSERT OVERWRITE EDW_PROD.T_EDW_T01_TKHXX
 (                        KHH                                                     --客户号                 
                         ,KHXM                                                    --客户简称                
                         ,KHQC                                                    --客户名称                
                         ,ZJLBDM                                                  --证件类别代码              
                         ,ZJBH                                                    --证件编号                
                         ,ZJDZ                                                    --证件地址                
                         ,ZJQSRQ                                                  --证件起始日期              
                         ,ZJJZRQ                                                  --证件截止日期              
                         ,ZJDZYB                                                  --证件地址邮编              
                         ,LXDH                                                    --联系电话                
                         ,PROVINCE                                                --省份                  
                         ,CITY                                                    --城市                  
                         ,SEC                                                     --所在辖区                
                         ,LXDZ                                                    --联系地址                
                         ,YZBM                                                    --邮政编码                
                         ,JZJYKH_WTFSFW                                           --集中交易客户委托方式范围        
                         ,GGQQKH_WTFSFW                                           --个股期权客户委托方式范围        
                         ,RZRQKH_WTFSFW                                           --融资融券客户委托方式范围        
                         ,JZJYKH_FWXMFW                                           --集中交易客户服务项目范围        
                         ,GGQQKH_FWXMFW                                           --个股期权客户服务项目范围        
                         ,RZRQKH_FWXMFW                                           --融资融券客户服务项目范围        
                         ,JZJYKH_CPXMFW                                           --集中交易客户产品项目范围        
                         ,GGQQKH_CPXMFW                                           --个股期权客户产品项目范围        
                         ,RZRQKH_CPXMFW                                           --融资融券客户产品项目范围        
                         ,YGT_KHRQ                                                --一柜通客户开户日期           
                         ,JZJYKH_KHRQ                                             --集中交易客户开户日期          
                         ,GGQQKH_KHRQ                                             --个股期权客户开户日期          
                         ,RZRQKH_KHRQ                                            --融资融券客户开户日期          
                         ,YGT_XHRQ                                                --一柜通客户销户日期           
                         ,JZJYKH_XHRQ                                             --集中交易客户销户日期          
                         ,GGQQKH_XHRQ                                             --个股期权客户销户日期          
                         ,RZRQKH_XHRQ                                             --融资融券客户销户日期          
                         ,YGT_KHZTDM                                              --一柜通客户客户状态代码         
                         ,JZJYKH_KHZTDM                                           --集中交易客户客户状态代码        
                         ,GGQQKH_KHZTDM                                           --个股期权客户客户状态代码        
                         ,RZRQKH_KHZTDM                                           --融资融券客户客户状态代码        
                         ,YYB                                                     --营业部                 
                         ,JZJY_SXRQ                                               --集中交易生效日期            
                         ,JZJYKH_TBTS                                             --集中交易客户特别提示          
                         ,GGQQKH_TBTS                                             --个股期权客户特别提示          
                         ,RZRQKH_TBTS                                             --融资融券客户特别提示          
                         ,JZJYKH_KHQZ                                             --集中交易客户客户群组          
                         ,GGQQKH_KHQZ                                             --个股期权客户客户群组          
                         ,RZRQKH_KHQZ                                             --融资融券客户客户群组          
                         ,GSFLDM                                                  --公司分类代码              
                         ,KHFXJB                                                  --客户风险级别              
                         ,FXCSNL                                                  --风险承受能力              
                         ,KHLB                                                    --客户类别                
                         ,XLDM                                                    --学历代码                
                         ,ZYDM                                                    --职业代码                
                         ,GJDM                                                    --国籍代码                
                         ,EMAIL                                                   --EMAIL               
                         ,SJ                                                      --手机                  
                         ,XBDM                                                    --性别代码                
                         ,KHKH                                                    --客户卡号                
                         ,JZJYKH_KHSX                                             --集中交易客户客户属性          
                         ,GGQQKH_KHSX                                             --个股期权客户客户属性          
                         ,RZRQKH_KHSX                                             --融资融券客户客户属性          
                         ,KH_KHFS                                                 --开户_开户方式             
                         ,TBSM                                                    --特别说明                
                         ,YMTH                                                    --一码通账户号码      
                         ,ZJYXQ
						 ,ZJDLSJ
						 ,ZJDLFS
						 ,ZJDLZD
						 ,CID
						 ,XTBS
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                  t.KHH                                           as KHH                                                     --客户号                               
                                  ,t.KHJC                                         as KHXM                                                    --客户简称                              
                                  ,t.KHMC                                         as KHQC                                                    --客户名称                              
                                  ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                         as ZJLBDM                                                  --证件类别代码                            
                                  ,t.ZJBH                                         as ZJBH                                                    --证件编号                              
                                  ,t.ZJDZ                                         as ZJDZ                                                    --证件地址                              
                                  ,t.ZJQSRQ                                       as ZJQSRQ                                                  --证件起始日期                            
                                  ,t.ZJJZRQ                                       as ZJJZRQ                                                  --证件截止日期                            
                                  ,t.ZJDZYB                                       as ZJDZYB                                                  --证件地址邮编                            
                                  ,t.DH                                           as LXDH                                                    --联系电话                              
                                  ,a1.PROVINCE                                    as PROVINCE                                                --省份                                
                                  ,a1.CITY                                        as CITY                                                    --城市                                
                                  ,a1.SEC                                         as SEC                                                     --所在辖区                              
                                  ,t.DZ                                           as LXDZ                                                    --联系地址                              
                                  ,t.YZBM                                         as YZBM                                                    --邮政编码                              
                                  ,a1.WTFSFW                                      as JZJYKH_WTFSFW                                           --集中交易客户委托方式范围                      
                                  ,a2.WTFSFW                                      as GGQQKH_WTFSFW                                           --个股期权客户委托方式范围                      
                                  ,a3.WTFSFW                                      as RZRQKH_WTFSFW                                           --融资融券客户委托方式范围                      
                                  ,a1.FWXMFW                                      as JZJYKH_FWXMFW                                           --集中交易客户服务项目范围                      
                                  ,a2.FWXMFW                                      as GGQQKH_FWXMFW                                           --个股期权客户服务项目范围                      
                                  ,a3.FWXMFW                                      as RZRQKH_FWXMFW                                           --融资融券客户服务项目范围                      
                                  ,a1.CPXMFW                                      as JZJYKH_CPXMFW                                           --集中交易客户产品项目范围                      
                                  ,a2.CPXMFW                                      as GGQQKH_CPXMFW                                           --个股期权客户产品项目范围                      
                                  ,a3.CPXMFW                                      as RZRQKH_CPXMFW                                           --融资融券客户产品项目范围                      
                                  ,t.KHRQ                                         as YGT_KHRQ                                                --一柜通客户开户日期                         
                                  ,a1.KHRQ                                        as JZJYKH_KHRQ                                             --集中交易客户开户日期                        
                                  ,a2.KHRQ                                        as GGQQKH_KHRQ                                             --个股期权客户开户日期                        
                                  ,a3.KHRQ                                        as RZRQKH_CKHRQ                                            --融资融券客户开户日期                        
                                  ,t.XHRQ                                         as YGT_XHRQ                                                --一柜通客户销户日期                         
                                  ,a1.XHRQ                                        as JZJYKH_XHRQ                                             --集中交易客户销户日期                        
                                  ,a2.XHRQ                                        as GGQQKH_XHRQ                                             --个股期权客户销户日期                        
                                  ,a3.XHRQ                                        as RZRQKH_XHRQ                                             --融资融券客户销户日期                        
                                  ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                         as YGT_KHZTDM                                              --一柜通客户客户状态代码                       
                                  ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(a1.KHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                         as JZJYKH_KHZTDM                                           --集中交易客户客户状态代码                      
                                  ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(a2.KHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                         as GGQQKH_KHZTDM                                           --个股期权客户客户状态代码                      
                                  ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(a3.KHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                         as RZRQKH_KHZTDM                                           --融资融券客户客户状态代码                      
                                  ,CAST(COALESCE(t12.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                           as YYB                                                     --营业部                               
                                  ,CASE WHEN a6.JZJYKH_KHZTDM = '99' AND    a1.KHZT = 0 THEN  %d{yyyyMMdd} END                                      as JZJY_SXRQ                                               --集中交易生效日期                          
                                  ,a1.TBTS                                        as JZJYKH_TBTS                                             --集中交易客户特别提示                        
                                  ,a2.TBTS                                        as GGQQKH_TBTS                                             --个股期权客户特别提示                        
                                  ,a3.TBTS                                        as RZRQKH_TBTS                                             --融资融券客户特别提示                        
                                  ,a1.KHQZ                                        as JZJYKH_KHQZ                                             --集中交易客户客户群组                        
                                  ,a2.KHQZ                                        as GGQQKH_KHQZ                                             --个股期权客户客户群组                        
                                  ,a3.KHQZ                                        as RZRQKH_KHQZ                                             --融资融券客户客户群组                        
                                  ,a1.GSFL                                        as GSFLDM                                                  --公司分类代码                            
                                  ,a4.SXZ                                         as KHFXJB                                                  --客户风险级别                            
                                  ,CAST(a5.CPDJ AS VARCHAR(300))                  as FXCSNL                                                  --风险承受能力                            
                                  ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                         as KHLB                                                    --客户类别                              
                                  ,CAST(COALESCE(t7.MBDM,NULLIF(CONCAT('ERR',CAST(a7.XLDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                         as XLDM                                                    --学历代码                              
                                  ,CAST(COALESCE(t8.MBDM,NULLIF(CONCAT('ERR',CAST(a7.ZYDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                          as ZYDM                                                    --职业代码                              
                                  ,CAST(COALESCE(t9.MBDM,NULLIF(CONCAT('ERR',CAST(t.GJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                            as GJDM                                                    --国籍代码                              
                                  ,t.EMAIL                                        as EMAIL                                                   --EMAIL                             
                                  ,t.SJ                                           as SJ                                                      --手机                                
                                  ,CAST(COALESCE(t10.MBDM,NULLIF(CONCAT('ERR',CAST(a7.XB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                            as XBDM                                                    --性别代码                              
                                  ,a8.KHKH                                         as KHKH                                                    --客户卡号                              
                                  ,a1.KHSX                                        as JZJYKH_KHSX                                             --集中交易客户客户属性                        
                                  ,a2.KHSX                                        as GGQQKH_KHSX                                             --个股期权客户客户属性                        
                                  ,a3.KHSX                                        as RZRQKH_KHSX                                             --融资融券客户客户属性                        
                                  ,CAST(COALESCE(t11.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                         as KH_KHFS                                                 --开户_开户方式                           
                                  ,t.TBSM                                         as TBSM                                                    --特别说明                              
                                  ,t.YMTH                                         as YMTH
                                  ,a2.ZJYXQ                                        as ZJYXQ								  --一码通账户号码                           
                                  ,a1.ZJDLSJ                                       as ZJDLSJ
								  ,a1.ZJDLFS                                       as ZJDLFS
								  ,a1.ZJDLZD                                       as ZJDLZD
								  ,t.CID                                           as CID
								  ,'YGT_GT,JZJY,GGQQ,RZRQ'                        as XTBS                                                                                        
 FROM            YGTCX.CIF_TKHXX                              t  
 LEFT  JOIN      JZJYCX.DATACENTER_TKHXX                      a1
 ON              t.KHH = a1.KHH   AND t.DT = a1.DT 
 LEFT  JOIN      GGQQCX.DATACENTER_TKHXX                      a2
 ON              t.KHH = a2.KHH AND t.DT = a2.DT 
 LEFT  JOIN      RZRQCX.DATACENTER_TKHXX                      a3
 ON              t.KHH = a3.KHH AND t.DT = a3.DT 
 LEFT  JOIN      YGTCX.cif_TGRKHXX                            a7 
 ON              t.KHH = a7.KHH AND t.DT = a7.DT 
 LEFT  JOIN     ( SELECT   KHH
                           ,SXZ
                           ,SXDM
				           ,DT
                  FROM    YGTCX.CIF_TKHSX  
                  WHERE   SXDM = 'KHFXJB'                    
                )                                             a4
 ON             t.KHH = a4.KHH   AND t.DT = a4.DT      
 LEFT  JOIN    ( SELECT   KHH
                          ,SDXLB
                          ,CPDJ
			              ,DT
                 FROM    YGTCX.CIF_TKHSDX
                 WHERE   SDXLB = 'JJFXCSNL'
               )                                              a5
 ON          	t.KHH = a5.KHH    AND t.DT = a5.DT   
 LEFT  JOIN   ( SELECT   KHH
                        ,JZJYKH_KHZTDM
                FROM     EDW_PROD.T_EDW_T01_TKHXX               
                WHERE    BUS_DATE IN (SELECT LST_TRD_D FROM EDW_PROD.T_EDW_T99_TRD_DATE WHERE NAT_DT = %d{yyyyMMdd})
              )                                               a6
 ON          	t.khh = a6.khh
 LEFT  JOIN     YGTCX.cif_TKHYWSX                             a8
 ON             t.KHH = a8.KHH AND t.DT = a8.DT
 LEFT  JOIN     EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t1 
 ON             t1.DMLX = 'ZJLBDM'
 AND            t1.YXT = 'YGT_GT'
 AND            t1.YDM = CAST(t.ZJLB AS VARCHAR(20))
 LEFT  JOIN     EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t2 
 ON             t2.DMLX = 'KHZTDM'
 AND            t2.YXT = 'YGT_GT'
 AND            t2.YDM = CAST(t.KHZT AS VARCHAR(20))
 LEFT  JOIN     EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t3 
 ON             t3.DMLX = 'KHZTDM'
 AND            t3.YXT = 'JZJY'
 AND            t3.YDM = CAST(a1.KHZT AS VARCHAR(20))
 LEFT  JOIN     EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t4 
 ON             t4.DMLX = 'KHZTDM'
 AND            t4.YXT = 'GGQQ'
 AND            t4.YDM = CAST(a2.KHZT AS VARCHAR(20))
 LEFT  JOIN     EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t5 
 ON             t5.DMLX = 'KHZTDM'
 AND            t5.YXT = 'RZRQ'
 AND            t5.YDM = CAST(a3.KHZT AS VARCHAR(20))
 LEFT  JOIN     EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t6 
 ON             t6.DMLX = 'KHLB'
 AND            t6.YXT = 'YGT_GT'
 AND            t6.YDM = CAST(t.KHLB AS VARCHAR(20))
 LEFT  JOIN     EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t7 
 ON             t7.DMLX = 'XLDM'
 AND            t7.YXT = 'YGT_GT'
 AND            t7.YDM = CAST(a7.XLDM AS VARCHAR(20))
 LEFT  JOIN     EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t8 
 ON             t8.DMLX = 'ZYDM'
 AND            t8.YXT = 'YGT_GT'
 AND            t8.YDM = CAST(a7.ZYDM AS VARCHAR(20))
 LEFT  JOIN     EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t9 
 ON             t9.DMLX = 'GJDM'
 AND            t9.YXT = 'YGT'
 AND            t9.YDM = CAST(t.GJ AS VARCHAR(20))
 LEFT  JOIN     EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t10 
 ON             t10.DMLX = 'XBDM'
 AND            t10.YXT = 'YGT_GT'
 AND            t10.YDM = CAST(a7.XB AS VARCHAR(20))
 LEFT  JOIN     EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t11 
 ON             t11.DMLX = 'KH_KHFS'
 AND            t11.YXT = 'YGT_GT'
 AND            t11.YDM = CAST(t.KHFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t12
 ON             t12.YXT = 'CIF'
 AND            t12.JGDM = CAST(t.YYB AS VARCHAR(20))           
 WHERE          t.DT = '%d{yyyyMMdd}' 
;
-------插入数据结束

----
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TKHXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T01_TKHXX;
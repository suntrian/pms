 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:优先股表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-04-23                                                                        */ 
 

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_PRTY_STK
(
								    BRH_NO                      --营业部编号  
                                   ,BRH_NAME                    --营业部名称  
                                   ,OPN_DT                      --开户日期
								   ,CUST_NO                     --客户号 
								   ,CUST_NAME                   --客户姓名    
								   ,CTF_CGY                     --证件类别  	
 								   ,RSK_BEAR_ABLTY              --风险承受能力
								   ,M_LAUND_RSK_LVL             --洗钱风险等级
)		
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
								 t.BRH_NO			  		 AS BRH_NO                      --营业部编号  
								,t.BRH_NAME                  AS BRH_NAME                    --营业部名称  
								,t.APL_DT                    AS OPN_DT                      --开户日期
								,t.CUST_NO                   AS CUST_NO                     --客户号 
								,a1.CUST_NAME                AS CUST_NAME                   --客户姓名    
								,b4.CTF_CGY_CD_NAME          AS CTF_CGY                     --证件类别  	
								,b3.RSK_BEAR_ABLTY_NAME      AS RSK_BEAR_ABLTY              --风险承受能力
                                ,b6.M_LAUND_RSK_LVL_NAME     AS M_LAUND_RSK_LVL             --洗钱风险等级
  
  
  FROM  		DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_RQM_HIS 	t
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a1
  ON            t.CUST_NO = a1.CUST_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_RSK_BEAR_ABLTY                    b3
  ON            a1.RSK_BEAR_ABLTY = b3.RSK_BEAR_ABLTY    
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD                   		b4
  ON            t.CTF_CGY_CD = b4.CTF_CGY_CD	
  LEFT JOIN    DDW_PROD.V_M_LAUND_RSK_LVL            b6
  ON           a1.M_LAUND_RSK_LVL = b6.M_LAUND_RSK_LVL   
  WHERE 		t.bus_date = %d{yyyyMMdd}
  AND           t.BIZ_CD IN ('20344','20355') 
  ;

 
-----------------------------加载结束--------------------
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_PRTY_STK',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_PRTY_STK;
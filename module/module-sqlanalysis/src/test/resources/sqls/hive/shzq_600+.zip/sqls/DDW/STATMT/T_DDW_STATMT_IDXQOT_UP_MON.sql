--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:指数行情截至月表                                                                       */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-08-07                                                                        */ 
----
 --ALTER TABLE DDW_PROD.T_DDW_STATMT_IDXQOT_UP_MON DROP IF EXISTS PARTITION (YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,6) as INT) ) ; 
 
 DROP TABLE  IF EXISTS DDW_PROD.T_DDW_STATMT_IDXQOT_UP_MON_TMP1;
 CREATE TABLE DDW_PROD.T_DDW_STATMT_IDXQOT_UP_MON_TMP1
 AS
 SELECT 
        NVL(T1.SEC_CD,T2.SEC_CD) AS ZQDM                --证券代码
	   ,NVL(T1.EXG,T2.EXG) AS JYS                         --交易所
	   ,NVL(T1.NEWST_PRC,T2.NEWST_PRC) AS ZXJ       --最新价
	   ,NVL(T1.BUS_DATE,T2.BUS_DATE) AS RQ
 FROM 
 (
   SELECT 
           T.ZQDM	                  										as SEC_CD         		--证券代码 
           ,T.JYS                   										as EXG               	--交易所
           ,ROUND(CASE WHEN  T.ZXJ IS NOT NULL 
 					         THEN T.ZXJ
						     ELSE T.ZSP
						     END,3) 	      								as NEWST_PRC         	--最新价
		    ,CAST(DT AS INT) AS BUS_DATE
  FROM 		JZJYCX.datacenter_TZQHQ    T
  WHERE 		T.ZQDM='000000' 
  AND         T.JYS IN ('SH','SZ') 
  AND         CAST(DT AS INT) = (SELECT  MAX(TRD_DT) as RQ
                   FROM    EDW_PROD.T_EDW_T99_TRD_DATE   
			       WHERE SUBSTR(CAST(TRD_DT as STRING),1,4) =  SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4) 
				   AND    BUS_DATE = %d{yyyyMMdd}
			      )
) T1
FULL JOIN 
(
  SELECT     '000000' AS SEC_CD
           ,CASE WHEN INNERCODE = 1 THEN'SH' ELSE 'SZ' END AS EXG
           ,CAST(CLOSEPRICE AS DECIMAL(18,3)) AS NEWST_PRC
		   ,CAST(DT AS INT) AS BUS_DATE
  FROM FUNDEXT.DBO_QT_INDEXQUOTE T1
  WHERE CAST(DT AS INT) = (SELECT  MAX(TRD_DT) as RQ
                   FROM    EDW_PROD.T_EDW_T99_TRD_DATE   
			       WHERE SUBSTR(CAST(TRD_DT as STRING),1,4) =  SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4) 
				   AND    BUS_DATE = %d{yyyyMMdd}
			      )
  AND INNERCODE IN( 1055,1)
) T2
ON T1.SEC_CD = T2.SEC_CD
AND T1.EXG = T2.EXG
and T1.BUS_DATE= T2.BUS_DATE
UNION ALL
SELECT 
        NVL(T1.SEC_CD,T2.SEC_CD) AS ZQDM                --证券代码
	   ,NVL(T1.EXG,T2.EXG) AS JYS                         --交易所
	   ,NVL(T1.NEWST_PRC,T2.NEWST_PRC) AS ZXJ       --最新价
	   ,NVL(T1.BUS_DATE,T2.BUS_DATE) AS RQ
 FROM 
 (
   SELECT 
           T.ZQDM	                  										as SEC_CD         		--证券代码 
           ,T.JYS                   										as EXG               	--交易所
           ,ROUND(CASE WHEN  T.ZXJ IS NOT NULL 
 					         THEN T.ZXJ
						     ELSE T.ZSP
						     END,3) 	      								as NEWST_PRC         	--最新价
		    ,CAST(DT AS INT) AS BUS_DATE
  FROM 		JZJYCX.datacenter_TZQHQ    T
  WHERE 		T.ZQDM='000000' 
  AND         T.JYS IN ('SH','SZ') 
  AND         CAST(DT AS INT) = %d{yyyyMMdd}
) T1
FULL JOIN 
(
  SELECT     '000000' AS SEC_CD
           ,CASE WHEN INNERCODE = 1 THEN'SH' ELSE 'SZ' END AS EXG
           ,CAST(CLOSEPRICE AS DECIMAL(18,3)) AS NEWST_PRC
		   ,CAST(DT AS INT) AS BUS_DATE
  FROM FUNDEXT.DBO_QT_INDEXQUOTE T1
  WHERE CAST(DT AS INT) = %d{yyyyMMdd}
  AND INNERCODE IN( 1055,1)
) T2
ON T1.SEC_CD = T2.SEC_CD
AND T1.EXG = T2.EXG
AND T1.BUS_DATE= T2.BUS_DATE
;
  
  INSERT OVERWRITE DDW_PROD.T_DDW_STATMT_IDXQOT_UP_MON
 (
                                   SEC_CD             --证券代码 
                                  ,EXG                --交易所                                   
                                  ,YEAR_START_PRC     --年初价格
                                  ,MON_END_PRC        --月末价格								  
                                  ,SEC_PRCCHG         --涨跌幅 
                                  ,ETL_DT             --加载日期								  
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT 
           CASE WHEN t.JYS = 'SH' 
		        AND  t.ZQDM = '000000'
				THEN '999999'
				WHEN t.JYS = 'SZ' 
		        AND  t.ZQDM = '000000'
				THEN '399001'
				END                                            as SEC_CD         		--证券代码 
           ,t.JYS                   	                       as EXG               	--交易所
		   ,ROUND(t.YEAR_START_PRC,3)                          as YEAR_START_PRC        --月初价格
           ,ROUND(t.MON_END_PRC,3)                             as MON_END_PRC           --月末价格								  
           ,ROUND(t.MON_END_PRC*1.0000/t.YEAR_START_PRC-1,4)*100 as SEC_PRCCHG            --涨跌幅 
           ,%d{yyyyMMdd}                                       as ETL_DT                --加载日期
 FROM (SELECT   t.JYS
               ,t.ZQDM
               ,SUM(CASE WHEN t.RQ = a2.RQ
		                 THEN t.ZXJ
			             ELSE 0
			             END)             as YEAR_START_PRC     --月初价格
               ,SUM(CASE WHEN t.RQ = %d{yyyyMMdd}
 		                 THEN t.ZXJ
				         ELSE 0
				         END)            as MON_END_PRC       --月末价格
       FROM 	JZJYCX.DATACENTER_TZQHQ    t
       LEFT JOIN  (SELECT  MAX(TRD_DT) as RQ
                   FROM    EDW_PROD.T_EDW_T99_TRD_DATE   
			       WHERE SUBSTR(CAST(TRD_DT as STRING),1,4) =  SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4) 
				   AND    BUS_DATE = %d{yyyyMMdd}
			      )  a2
       ON          t.RQ = a2.RQ
       WHERE 		t.ZQDM='000000' 
       AND         t.JYS IN ('SH','SZ') 
       AND          (t.RQ = a2.RQ OR t.RQ = %d{yyyyMMdd})
      GROUP BY     t.ZQDM,t.JYS
   )  t
UNION ALL
 SELECT 
           t.ZQDM	                  	                       as SEC_CD         		--证券代码 
           ,t.JYS                   	                       as EXG               	--交易所
		   ,ROUND(t.YEAR_START_PRC,3)                          as YEAR_START_PRC        --年初价格
           ,ROUND(t.MON_END_PRC,3)                             as MON_END_PRC           --月末价格								  
           ,ROUND(t.MON_END_PRC*1.0000/t.YEAR_START_PRC-1,4)*100     as SEC_PRCCHG            --涨跌幅 
           ,%d{yyyyMMdd}                                       as ETL_DT                --加载日期
 FROM (SELECT   'SZ'       as JYS
               ,'399006'   as ZQDM
               ,SUM(CAST(CASE WHEN t.RQ = a2.RQ
		                 THEN t.PrevClosePrice
			             ELSE 0
			             END as DECIMAL(38,3)))             as YEAR_START_PRC     --月初价格
               ,SUM(CAST(CASE WHEN t.RQ = %d{yyyyMMdd}
 		                 THEN t.ClosePrice
				         ELSE 0
				         END as DECIMAL(38,3)))            as MON_END_PRC       --月末价格
       FROM 	(SELECT   CAST(CONCAT(SUBSTR(t.tradingday,1,4),SUBSTR(t.tradingday,6,2),SUBSTR(t.tradingday,9,2)) as INT) as RQ,PrevClosePrice,ClosePrice
	             FROM    FUNDEXT.DBO_QT_IndexQuote t
	             WHERE   INNERCODE = 11089
				 GROUP BY RQ,PrevClosePrice,ClosePrice	   
	               )     t
       LEFT JOIN  (SELECT  MIN(TRD_DT) as RQ
                   FROM    EDW_PROD.T_EDW_T99_TRD_DATE   
			       WHERE SUBSTR(CAST(TRD_DT as STRING),1,4) =  SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,4) 
				   AND    BUS_DATE = %d{yyyyMMdd}
			      )  a2
       ON          t.RQ = a2.RQ

       WHERE 	  (t.RQ = a2.RQ OR t.RQ = %d{yyyyMMdd})
      GROUP BY     ZQDM,JYS
   )  t
;

-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_STATMT_IDXQOT_UP_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_STATMT_IDXQOT_UP_MON;  
--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:融资融券保证金比例表                                                                 */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T04_TXY_BZJBL;
------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TXY_BZJBL
 (
                                     BZDM                                --币种代码                               
                                    ,CEDBBL                              --超额担保比例                             
                                    ,QZPCBL                              --强制平仓比例                             
                                    ,PCDWBL                              --强平到位比例                             
                                    ,ZBBL                                --追保比例                               
                                    ,ZBDWBL                              --追保到位比例                             
                                    ,WCBL                                --维持保证金比例                            
                                    ,DPBL                                --盯盘保证金比例                            
                                    ,QTBL                                --其它比例                               
                                    ,XGRQ                                --修改日期                               
                                    ,GYH                                 --修改柜员                               
                                    ,RZBL                                --融资比例                               
                                    ,RQBL                                --融券比例                               
                                    ,ZXRZFDLL                            --专项融资浮动利率                           
                                    ,ZXRQFDLL                            --专项融券浮动利率  
                                    ,XTBS								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.CEDBBL                              as CEDBBL                              --超额担保比例                              
                                   ,t.QZPCBL                              as QZPCBL                              --强制平仓比例                              
                                   ,t.PCDWBL                              as PCDWBL                              --强平到位比例                              
                                   ,t.ZBBL                                as ZBBL                                --追保比例                                
                                   ,t.ZBDWBL                              as ZBDWBL                              --追保到位比例                              
                                   ,t.WCBL                                as WCBL                                --维持保证金比例                             
                                   ,t.DPBL                                as DPBL                                --盯盘保证金比例                             
                                   ,t.QTBL                                as QTBL                                --其它比例                                
                                   ,t.XGRQ                                as XGRQ                                --修改日期                                
                                   ,t.GYH                                 as GYH                                 --修改柜员                                
                                   ,t.RZBL                                as RZBL                                --融资比例                                
                                   ,t.RQBL                                as RQBL                                --融券比例                                
                                   ,t.ZXRZFDLL                            as ZXRZFDLL                            --专项融资浮动利率                            
                                   ,t.ZXRQFDLL                            as ZXRQFDLL                            --专项融券浮动利率  
                                   ,'RZRQ'								   
 FROM 			RZRQCX.MARGIN_TXY_BZJBL 					t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 		t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 WHERE 			t.DT = '%d{yyyyMMdd}';
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TXY_BZJBL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
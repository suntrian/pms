------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:柜台业务流程客户信息修改表                                                                */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2018-07-03
------/* 增量表                                                                       */ 
--------------插入数据-------------------
INSERT OVERWRITE EDW_PROD.T_EDW_T05_LCGTYW_KHXXXG
(
									 ID
									,INSTID
									,TITLE
									,YWDM
									,KHH
									,FQQD
									,YWQQID
									,KHMC
									,JG
									,ZJLBDM
									,ZJBH
									,KHZT
									,FSRQ
									,FSSJ
									,FQR
									,CZZD
									,BLRQ
									,BLSJ
									,BLR
									,IFTB
									,KHFXJB
									,JZR
									,JZFS
									,JZFJH
									,ZJQSRQ
									,ZJJZRQ
									,XTBS
)
partition(bus_date)
SELECT                              
                                     t.ID         as      ID              --ID
									,t.INSTID     as      INSTID          
									,t.TITLE      as      TITLE           --标题
									,t.YWDM       as      YWDM            --业务代码
									,t.KHH        as      KHH             --客户号
									,CAST(COALESCE(a1.MBDM,NULLIF(CONCAT('ERR',CAST(t.FQQD AS VARCHAR(20))),'ERR')) AS VARCHAR(20))   		as		FQQD            --发起渠道
									,t.YWQQID		as		YWQQID          --业务请求ID
									,t.KHMC  		as		KHMC            --客户名称
									,CAST(COALESCE(a3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))		as		JG              --营业部
									,CAST(COALESCE(a4.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))		as		ZJLBDM              --证件类别代码
									,t.ZJBH  		as		ZJBH            --证件编号
									,CAST(COALESCE(a6.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  		as		KHZT            --客户状态
									,t.FSRQ  		as		FSRQ            --发生日期
									,t.FSSJ  		as		FSSJ            --发生时间
									,t.FQR   		as		FQR             --发起人
							        ,t.CZZD       as      CZZD            --操作站点
							        ,t.BLRQ       as      BLRQ            --办理日期
							        ,t.BLSJ       as      BLSJ            --办理时间
									,t.BLR   		as		BLR             --办理人
									,t.IFTB       as      IFTB            
									,CAST(COALESCE(a5.MBDM,NULLIF(CONCAT('ERR',CAST(t.FXJB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))		as		KHFXJB              --客户风险级别
									,t.JZR   		as		JZR             --见证人
									,CAST(COALESCE(a2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JZFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20))   		as		JZFS            --见证方式
									,t.JZFJH 		as		JZFJH           --见证房间号
									,t.ZJQSRQ     as      ZJQSRQ          --起始日期
									,t.ZJJZRQ     as      ZJJZRQ          --截止日期
									,'CIF'		as		XTBS            --系统标识
									,CAST(CASE WHEN a7.NAT_DT = a7.TRD_DT
							                   THEN a7.TRD_DT
								               WHEN a7.NAT_DT <> a7.TRD_DT
							                   THEN a8.TRD_DT
								               ELSE FSRQ
                                               END AS INT   ) BUS_DATE  --日期
FROM 		    YGTCX.CIF_LCGTYW_KHXXXG			            t
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		a1
ON 		        a1.YXT='YGT'
AND		        a1.YDM= CAST(t.FQQD AS VARCHAR(20))
AND 	        a1.DMLX='FQQD'	
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		a2
ON 		        a2.YXT='YGT_GT'
AND		        a2.YDM= CAST(t.JZFS AS VARCHAR(20))
AND 	        a2.DMLX='JZFS'
LEFT JOIN		EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING 		a3
ON 		        a3.YXT='CIF'
AND		        a3.JGDM= CAST(t.YYB AS VARCHAR(20))
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		a4
ON 		        a4.YXT='YGT_GT'
AND		        a4.YDM= CAST(t.ZJLB AS VARCHAR(20))
AND 	        a4.DMLX='ZJLBDM'
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		a5
ON 		        a5.YXT='YGT_GT'
AND		        a5.YDM= CAST(t.FXJB AS VARCHAR(20))
AND 	        a5.DMLX='KHFXJBDM'
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		a6
ON 		        a6.YXT='YGT_GT'
AND		        a6.YDM= CAST(t.KHZT AS VARCHAR(20))
AND 	        a6.DMLX='KHZTDM'
LEFT JOIN       EDW_PROD.T_EDW_T99_TRD_DATE		            a7
ON              t.FSRQ = a7.NAT_DT
AND             a7.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN       EDW_PROD.T_EDW_T99_TRD_DATE		            a8
ON              a8.lst_trd_d = a7.trd_dt
and             a8.NAT_DT = a8.TRD_DT
AND             a8.BUS_DATE = %d{yyyyMMdd}
WHERE   t.DT = '%d{yyyyMMdd}'
UNION ALL
SELECT                              
                                     t.ID         as      ID              --ID
									,t.INSTID     as      INSTID          
									,t.TITLE      as      TITLE           --标题
									,t.YWDM       as      YWDM            --业务代码
									,t.KHH        as      KHH             --客户号
									,CAST(COALESCE(a1.MBDM,NULLIF(CONCAT('ERR',CAST(t.FQQD AS VARCHAR(20))),'ERR')) AS VARCHAR(20))   		as		FQQD            --发起渠道
									,t.YWQQID		as		YWQQID          --业务请求ID
									,t.KHMC  		as		KHMC            --客户名称
									,CAST(COALESCE(a3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))		as		JG              --营业部
									,CAST(COALESCE(a4.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))		as		ZJLBDM              --证件类别代码
									,t.ZJBH  		as		ZJBH            --证件编号
									,CAST(COALESCE(a6.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  		as		KHZT            --客户状态
									,t.FSRQ  		as		FSRQ            --发生日期
									,t.FSSJ  		as		FSSJ            --发生时间
									,t.FQR   		as		FQR             --发起人
							        ,t.CZZD       as      CZZD            --操作站点
							        ,t.BLRQ       as      BLRQ            --办理日期
							        ,t.BLSJ       as      BLSJ            --办理时间
									,t.BLR   		as		BLR             --办理人
									,t.IFTB       as      IFTB            
									,CAST(COALESCE(a5.MBDM,NULLIF(CONCAT('ERR',CAST(t.FXJB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))		as		KHFXJB              --客户风险级别
									,t.JZR   		as		JZR             --见证人
									,CAST(COALESCE(a2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JZFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20))   		as		JZFS            --见证方式
									,t.JZFJH 		as		JZFJH           --见证房间号
									,t.ZJQSRQ     as      ZJQSRQ          --起始日期
									,t.ZJJZRQ     as      ZJJZRQ          --截止日期
									,'CIF'		as		XTBS            --系统标识
									,CAST(CASE WHEN a7.NAT_DT = a7.TRD_DT
							                   THEN a7.TRD_DT
								               WHEN a7.NAT_DT <> a7.TRD_DT
							                   THEN a8.TRD_DT
								               ELSE FSRQ
                                               END AS INT   ) BUS_DATE  --日期
FROM 		    YGTCX.CIF_LCGTYW_KHXXXG			            t
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		a1
ON 		        a1.YXT='YGT'
AND		        a1.YDM= CAST(t.FQQD AS VARCHAR(20))
AND 	        a1.DMLX='FQQD'	
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		a2
ON 		        a2.YXT='YGT_GT'
AND		        a2.YDM= CAST(t.JZFS AS VARCHAR(20))
AND 	        a2.DMLX='JZFS'
LEFT JOIN		EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING 		a3
ON 		        a3.YXT='CIF'
AND		        a3.JGDM= CAST(t.YYB AS VARCHAR(20))
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		a4
ON 		        a4.YXT='YGT_GT'
AND		        a4.YDM= CAST(t.ZJLB AS VARCHAR(20))
AND 	        a4.DMLX='ZJLBDM'
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		a5
ON 		        a5.YXT='YGT_GT'
AND		        a5.YDM= CAST(t.FXJB AS VARCHAR(20))
AND 	        a5.DMLX='KHFXJBDM'
LEFT JOIN		EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING		a6
ON 		        a6.YXT='YGT_GT'
AND		        a6.YDM= CAST(t.KHZT AS VARCHAR(20))
AND 	        a6.DMLX='KHZTDM'
LEFT JOIN       EDW_PROD.T_EDW_T99_TRD_DATE		            a7
ON              t.FSRQ = a7.NAT_DT
AND             a7.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN       EDW_PROD.T_EDW_T99_TRD_DATE		            a8
ON              a8.lst_trd_d = a7.trd_dt
and             a8.NAT_DT = a8.TRD_DT
AND             a8.BUS_DATE = %d{yyyyMMdd}
WHERE           EXISTS (SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE a
                         WHERE a.BUS_DATE = %d{yyyyMMdd}
						 AND   a.TRD_DT = %d{yyyyMMdd}
						 AND   CAST(t.DT as INT) = a.LST_TRD_D
                         )
;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_LCGTYW_KHXXXG',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_LCGTYW_KHXXXG;
------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:自营成交回报汇总表                                                                  */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2017-12-29                                                                        */ 

--------------插入数据-------------------
INSERT OVERWRITE RISK_INDEX.HISBUSINESSSUMARY
(
         L_DATE                                 --发生日期               
        ,L_FUND_ID                              --基金编号	             
        ,VC_FUND_NAME                           --基金名称               
        ,VC_REPORT_CODE                         --证券代码               
        ,VC_STOCK_NAME                          --证券名称               
        ,C_ENTRUST_DIRECTION                    --委托方向               
        ,L_CURRENT_AMOUNT                       --持仓                   
        ,EN_LAST_PRICE                          --最新价                 
        ,EN_AVG_PRICE                           --市场成交均价           
        ,L_DEAL_AMOUNT                          --成交数量               
        ,EN_DEAL_BALANCE                        --成交金额               
        ,L_DEAL_COUNT                           --成交次数               
        ,EN_DEAL_MIN_PRICE                      --成交最低价             
        ,EN_DEAL_MAX_PRICE                      --成交最高价             
        ,EN_DEAL_BALANCE_RATE1                  --成交均价               
        ,EN_DEAL_AVG_BALANCE                    --成交均价(全价)         
        ,C_MARKET_NO                            --交易市场               
        ,L_MARKET_DEAL_AMOUNT                   --市场成交数量           
        ,L_DEAL_AMOUNT_RATE                     --数量成交比例(%)        
        ,EN_MARKET_DEAL_BALANCE                 --市场成交金额           
        ,VC_COMBI_NO                            --组合编号               
        ,VC_COMBI_NAME                          --组合名称               
        ,L_ENTRUST_AMOUNT                       --委托数量               
        ,EN_MAX_PRICE                           --市场最高价             
        ,EN_MIN_PRICE                           --市场最低价             
        ,VC_OPERATOR_NAME                       --交易员                 
        ,L_ENTRUST_COUNT                        --委托次数               
        ,C_ASSET_CLASS                          --资产类别               
        ,EN_YIELD_RATIO                         --涨跌幅(%)              
        ,EN_DEAL_BALANCE_RATE2                  --金额成交比例(%)        
        ,PRICE_DIFF_RATE                        --价格差额比例(%)        
        ,L_ENTRUST_AMOUNT1                       --指令数量            
        ,L_ASSET_ID                             --资产单元序号     								
        ,VC_COMBI_NAME1                          --                    
        ,VC_ASSET_NAME                          --资产单元名称           
        ,VC_CURRENCY_NO                         --币种                   
        ,VC_SEAT_ID                             --交易席位               
        ,INVEST_TYPE                            --投资类型               
        ,VC_ASSET_NO                            --资产单元编号           
        ,VC_STOCKHOLDER_ID                      --股东代码               
        ,DEAL_AMOUNT_HOLD_RATE                  --成交量占昨日持仓量(%)  
        ,OPERATOR                               --指令下达人             
        ,VC_CURRENCY_NO1                        --本币币种            
        ,EN_DEAL_BALANCE1                       --本币成交金额        
        ,OPERATE_LEVEL                          --指令操作级别           
        ,WORKGROUP_TYPE                         --账户组类型             
        ,WORKGROUP                              --账户组                 
        ,DEAL_BALANCE_VALUE_RATE                --成交金额占净值         
        ,SEC_NO                                 --券商编号(%)            
        ,SEC_NAME                               --券商名称   		     
        ,BUSINESS_TYPE                          --业务分类				 
        ,IS_ETF_BQ                              --是否ETF补券            
        ,EN_DEAL_BALANCE2                        --发生金额(全价)        
        ,EN_OPEN_PRICE                          --今开盘价               
        ,IS_FORCED_ENTRUST                      --是否强平委托           
        ,OPERATOR1                              --代下达人               
        ,IS_FORCED                              --是否强平               
)
partition (DT = '%d{yyyyMMdd}')
SELECT
                        CAST(EDW_PROD.G_DATE_CONVERT_INT(CAST(t.L_DATE AS INT),'yyyyMMdd','yyyy-MM-dd') AS VARCHAR(64) )                                                  AS  L_DATE                            
                       ,t.L_FUND_ID                                                                     AS  L_FUND_ID                         
                       ,a4.VC_FUND_NAME                                                                 AS  VC_FUND_NAME                      
                       ,a2.VC_REPORT_CODE                                                               AS  VC_REPORT_CODE                    
                       ,a2.VC_STOCK_NAME                                                                AS  VC_STOCK_NAME                     
                       ,CAST(a8.SOURCE_NAME AS VARCHAR(40))                                             AS  C_ENTRUST_DIRECTION               
                       ,CAST(NVL(a1.L_CURRENT_AMOUNT,0) AS DECIMAL(16,2))                               AS  L_CURRENT_AMOUNT                  
                       ,CAST(NVL(a2.EN_LAST_PRICE,0)  AS DECIMAL(12,4))                                 AS  EN_LAST_PRICE                     
                       ,CAST(NVL(a2.EN_AVG_PRICE,0)   AS DECIMAL(12,4))                                 AS  EN_AVG_PRICE                      
                       ,t.L_DEAL_AMOUNT                                                                 AS  L_DEAL_AMOUNT                     
                       ,t.EN_DEAL_BALANCE                                                               AS  EN_DEAL_BALANCE                   
                       ,a5.L_DEAL_COUNT                                                                 AS  L_DEAL_COUNT                      
                       ,CAST(NVL(a5.EN_DEAL_MIN_PRICE,0) AS DECIMAL(12,4))                              AS  EN_DEAL_MIN_PRICE                 
                       ,CAST(NVL(a5.EN_DEAL_MAX_PRICE,0) AS DECIMAL(12,4))                              AS  EN_DEAL_MAX_PRICE                 
                       ,CAST(DECODE(NVL(t.L_DEAL_AMOUNT,0),0,0,t.EN_DEAL_BALANCE/t.L_DEAL_AMOUNT)       AS DECIMAL(12,4))                AS  EN_DEAL_BALANCE_RATE1             
                       ,CAST(DECODE(NVL(t.L_DEAL_AMOUNT,0),0,0,t.EN_DEAL_BALANCE/t.L_DEAL_AMOUNT)       AS  DECIMAL(12,4))                AS  EN_DEAL_AVG_BALANCE               
                       ,t.C_MARKET_NO                                                                   AS  C_MARKET_NO                       
                       ,CAST(NVL(a2.L_MARKET_DEAL_AMOUNT,0)  AS DECIMAL(16,2))                          AS  L_MARKET_DEAL_AMOUNT              
                       ,CAST(DECODE(NVL(a2.L_MARKET_DEAL_AMOUNT,0),0,0,t.L_DEAL_AMOUNT/a2.L_MARKET_DEAL_AMOUNT)   AS DECIMAL(12,4))           AS  L_DEAL_AMOUNT_RATE                
                       ,CAST(NVL(a2.EN_MARKET_DEAL_BALANCE,0) AS DECIMAL(16,2))                         AS  EN_MARKET_DEAL_BALANCE            
                       ,a3.VC_COMBI_NO                                                                  AS  VC_COMBI_NO                       
                       ,a3.VC_COMBI_NAME                                                                AS  VC_COMBI_NAME                     
                       ,CAST(NVL(a6.L_ENTRUST_AMOUNT,0) AS DECIMAL(16,2))                               AS  L_ENTRUST_AMOUNT                  
                       ,CAST(NVL(a2.EN_MAX_PRICE,0) AS DECIMAL(12,4))                                   AS  EN_MAX_PRICE                      
                       ,CAST(NVL(a2.EN_MIN_PRICE,0) AS DECIMAL(12,4))                                   AS  EN_MIN_PRICE                      
                       ,NULL                                                                            AS  VC_OPERATOR_NAME                  
                       ,a6.L_ENTRUST_COUNT                                                              AS  L_ENTRUST_COUNT                   
                       ,a2.C_ASSET_CLASS                                                                AS  C_ASSET_CLASS                     
                       ,CAST(NVL(a2.EN_YIELD_RATIO,0) AS DECIMAL(12,4))                                 AS  EN_YIELD_RATIO                    
                       ,CAST(DECODE(NVL(a2.EN_MARKET_DEAL_BALANCE,0),0,0,t.EN_DEAL_BALANCE/a2.EN_MARKET_DEAL_BALANCE) AS DECIMAL(12,4))       AS  EN_DEAL_BALANCE_RATE2             
                       ,NULL                                                                            AS  PRICE_DIFF_RATE                   
                       ,CAST(NVL(a6.L_ENTRUST_AMOUNT,0) AS DECIMAL(16,2))                               AS  L_ENTRUST_AMOUNT1                 
                       ,a3.L_ASSET_ID                                                                   AS  L_ASSET_ID                        						
                       ,a3.VC_COMBI_NAME                                                                AS  VC_COMBI_NAME1                    
                       ,a7.VC_ASSET_NAME                                                                AS  VC_ASSET_NAME                     
                       ,t.VC_CURRENCY_NO                                                                AS  VC_CURRENCY_NO                    
                       ,t.VC_SEAT_ID                                                                    AS  VC_SEAT_ID                        
                       ,NULL                                                                            AS  INVEST_TYPE                       
                       ,CAST(a7.VC_ASSET_NO AS VARCHAR(32))                                             AS  VC_ASSET_NO                       
                       ,CAST(t.VC_STOCKHOLDER_ID AS BIGINT)                                             AS  VC_STOCKHOLDER_ID                 
                       ,NULL                                                                            AS  DEAL_AMOUNT_HOLD_RATE             
                       ,NULL                                                                            AS  OPERATOR                          
                       ,t.VC_CURRENCY_NO                                                                AS  VC_CURRENCY_NO1                   
                       ,t.EN_DEAL_BALANCE                                                               AS  EN_DEAL_BALANCE1                  
                       ,NULL                                                                            AS  OPERATE_LEVEL                     
                       ,NULL                                                                            AS  WORKGROUP_TYPE                    
                       ,NULL                                                                            AS  WORKGROUP                         
                       ,NULL                                                                            AS  DEAL_BALANCE_VALUE_RATE           
                       ,NULL                                                                            AS  SEC_NO                            
                       ,CAST('上海证券' AS VARCHAR(256))                                                AS  SEC_NAME                          
                       ,CAST('交易所业务' AS VARCHAR(32))                                               AS  BUSINESS_TYPE                     
                       ,CAST('不是ETF补券指令' AS VARCHAR(64))                                          AS  IS_ETF_BQ                         
                       ,t.EN_DEAL_BALANCE                                                               AS  EN_DEAL_BALANCE2                  
                       ,CAST(NVL(a2.EN_OPEN_PRICE,0) AS DECIMAL(12,4))                                  AS  EN_OPEN_PRICE                     
                       ,CAST('非强平' AS VARCHAR(64))                                                   AS  IS_FORCED_ENTRUST                 
                       ,NULL                                                                            AS  OPERATOR1                         
                       ,CAST('否' AS VARCHAR(64))                                                       AS  IS_FORCED                         																								
FROM                    HSO32_ZY.TRADE_THISBUSINESSSUMMARY                        t 
LEFT JOIN               HSO32_ZY.TRADE_THISFUNDSTOCK                              a1 
ON                      T.L_DATE                   = a1.L_DATE                                  					
AND                     T.L_FUND_ID                = a1.L_FUND_ID                                          
AND                     T.VC_INTER_CODE            = a1.VC_INTER_CODE                            
AND                     T.VC_STOCKHOLDER_ID        = a1.VC_STOCKHOLDER_ID
AND                     a1.DT                      = '%d{yyyyMMdd}'
LEFT JOIN               HSO32_ZY.TRADE_THISSTOCKINFO                              a2 
ON                      a2.L_DATE                  = T.L_DATE                                        
AND                     a2.VC_INTER_CODE           = T.VC_INTER_CODE                          
AND                     a2.C_MARKET_NO             = T.C_MARKET_NO
AND                     a2.DT                      = '%d{yyyyMMdd}'		
LEFT JOIN               HSO32_ZY.TRADE_TCOMBI                                     a3 
ON                      a3.L_FUND_ID               = T.L_FUND_ID                          
AND                     a3.L_COMBI_ID              = T.L_BASECOMBI_ID                  
LEFT JOIN               HSO32_ZY.TRADE_TFUNDINFO                                  a4 
ON                      a4.L_FUND_ID               = T.L_FUND_ID
AND                     a4.DT                      = '%d{yyyyMMdd}'
LEFT JOIN               (SELECT       a.L_DATE 
		                             ,COUNT(a.VC_INTER_CODE)   AS L_DEAL_COUNT
					      			 ,MIN(a.EN_DEAL_PRICE)     AS EN_DEAL_MIN_PRICE
					      			 ,MAX(a.EN_DEAL_PRICE)     AS EN_DEAL_MAX_PRICE
					      			 ,a.L_OPERATOR_NO
					      			 ,a.L_FUND_ID
					      			 ,a.L_BASECOMBI_ID
					      			 ,a.VC_REPORT_CODE
					      			 ,a.VC_INTER_CODE
					      			 ,a.C_ENTRUST_DIRECTION 
					     FROM         HSO32_ZY.TRADE_THISREALDEAL                a
                         WHERE        a.DT = '%d{yyyyMMdd}'						
					     GROUP BY     a.L_DATE
					      	         ,a.L_FUND_ID
					      			 ,a.L_BASECOMBI_ID
					      			 ,a.VC_REPORT_CODE
					      			 ,a.VC_INTER_CODE
					      			 ,a.C_ENTRUST_DIRECTION
					      			 ,a.L_OPERATOR_NO )                         a5
ON                      a5.L_DATE              = T.L_DATE 
AND                     a5.L_FUND_ID           = T.L_FUND_ID 
AND                     a5.L_BASECOMBI_ID      = T.L_BASECOMBI_ID 
AND                     a5.VC_INTER_CODE       = T.VC_INTER_CODE 
AND                     a5.C_ENTRUST_DIRECTION = T.C_ENTRUST_DIRECTION		
LEFT JOIN              (SELECT       a.L_DATE 
		                            ,COUNT(a.VC_INTER_CODE)   AS L_ENTRUST_COUNT
									,SUM(a.L_ENTRUST_AMOUNT)  AS L_ENTRUST_AMOUNT
									,a.L_FUND_ID
									,a.L_BASECOMBI_ID
									,a.VC_INTER_CODE
									,a.C_MARKET_NO
									,a.C_ENTRUST_DIRECTION  
						FROM        HSO32_ZY.TRADE_THISENTRUSTS                 a
						WHERE       a.DT = '%d{yyyyMMdd}'
						GROUP BY    a.L_DATE
						           ,a.L_FUND_ID
								   ,a.L_BASECOMBI_ID
								   ,a.VC_INTER_CODE
								   ,a.C_MARKET_NO
								   ,a.C_ENTRUST_DIRECTION )                    a6
ON                      a6.L_DATE              = T.L_DATE 
AND                     a6.L_FUND_ID           = T.L_FUND_ID 
AND                     a6.L_BASECOMBI_ID      = T.L_BASECOMBI_ID 
AND                     a6.VC_INTER_CODE       = T.VC_INTER_CODE 
AND                     a6.C_MARKET_NO         = T.C_MARKET_NO 
AND                     a6.C_ENTRUST_DIRECTION = T.C_ENTRUST_DIRECTION
LEFT JOIN               HSO32_ZY.TRADE_TASSET                                  a7 
ON                      a7.L_ASSET_ID          = a3.L_ASSET_ID   
AND                     a7.L_FUND_ID           = a3.L_FUND_ID
and                     a7.DT                  = '%d{yyyyMMdd}'
LEFT JOIN               HSFK.HSMAN_TZENTRUSTDIRECTION_MAPPING                   a8
ON                      a8.VERSION             = 88
AND                    trim(t.C_ENTRUST_DIRECTION)  = TRIM(a8.SOURCE_CODE)
WHERE                   t.L_DATE               = %d{yyyyMMdd}
AND                     cast(t.L_FUND_ID as STRING )           <>'2001'
---------------- 插入数据结束 -----------------------





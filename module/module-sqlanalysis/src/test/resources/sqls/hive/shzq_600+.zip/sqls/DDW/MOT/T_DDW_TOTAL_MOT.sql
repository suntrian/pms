--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:总监控                                                                     */
--/* 创建人:刘桂汝                                                                                 */
--/* 创建时间:2017-09-04                                                                          */  

------------------------删除今天的数据-------------
 ALTER TABLE DDW_PROD.T_DDW_TOTAL_MOT DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd}); 
------------------------删除今天的数据结束------------------------

------插入数据 表1---------------
 INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
            TABLE_NAME          --表名                              
            ,ERR_CGY            --错误标识                             
                                   --,BUS_DATE                                 --时间                               
 ) 
 PARTITION(bus_date = %d{yyyyMMdd})
 SELECT      'T_DDW_QOT_MOT'
             ,1
 FROM   (SELECT  COUNT(1) as num
         FROM    DDW_PROD.T_DDW_QOT_MOT 
         WHERE   BUS_DATE = %d{yyyyMMdd}
         ) t 
 WHERE  t.NUM > 0;
 
------插入数据 表2---------------
INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
          TABLE_NAME                               --表名                              
         ,ERR_CGY                                  --标志位                            
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_ORIG_TAR_NUM_MOT'
             ,1
 FROM (SELECT   COUNT(1) as num
       FROM     DDW_PROD.T_ORIG_TAR_NUM_MOT 
       WHERE    BUS_DATE = %d{yyyyMMdd}
       AND      IF_EQUAL = 0
       ) t 
 WHERE t.NUM > 0;
 
 ------插入数据 表3---------------
INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
            TABLE_NAME                               --表名                              
           ,ERR_CGY                                  --标志位                            
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_DDW_CD_SECTION_ADD_MOT'
             ,1
 FROM  (SELECT  COUNT(1) as num
        FROM    DDW_PROD.T_DDW_CD_SECTION_ADD_MOT 
        WHERE   BUS_DATE = %d{yyyyMMdd}
       ) t 
 WHERE t.num > 0;
 
 ------插入数据 表4---------------
 INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
                  TABLE_NAME                               --表名                              
                 ,ERR_CGY                                  --标志位                            
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_DDW_CUST_STATMTD_MOT'
            ,1
 FROM  (SELECT  COUNT(1) as num
        FROM    DDW_PROD.T_DDW_CUST_STATMTD_MOT 
        WHERE   BUS_DATE = %d{yyyyMMdd}
        ) t  
 WHERE t.num > 0;
 
 ------插入数据 表5---------------
 INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
              TABLE_NAME                               --表名                              
             ,ERR_CGY                                  --标志位                             
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_DDW_SEC_CD_PFX_TRD_CGY_MOT'
             ,1
 FROM  (SELECT  COUNT(1) as num
        FROM    DDW_PROD.T_DDW_SEC_CD_PFX_TRD_CGY_MOT 
        WHERE   BUS_DATE = %d{yyyyMMdd}
       ) t 
 WHERE t.num > 0;
 
  ------插入数据 表6---------------
 INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
              TABLE_NAME                               --表名                              
             ,ERR_CGY                                  --标志位                             
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_DDW_PER_PRET_STK_MOT'
             ,1
 FROM  (SELECT  COUNT(1) as num
        FROM    DDW_PROD.T_DDW_PER_PRET_STK_MOT 
        WHERE   BUS_DATE = %d{yyyyMMdd}
       ) t 
 WHERE t.num > 0;
 
 
  ------插入数据 表7---------------
 INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
              TABLE_NAME                               --表名                              
             ,ERR_CGY                                  --标志位                             
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_DDW_CPTL_DTL_BIZ_SBJ_MOT'
             ,1
 FROM  (SELECT  COUNT(1) as num
        FROM    DDW_PROD.T_DDW_CPTL_DTL_BIZ_SBJ_MOT 
        WHERE   BUS_DATE = %d{yyyyMMdd}
       ) t 
 WHERE t.num > 0;
 
 
 ------插入数据 表8---------------
 INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
              TABLE_NAME                               --表名                              
             ,ERR_CGY                                  --标志位                             
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_DDW_HLD_CD_DLSTG_EXCPT_MOT'
             ,1
 FROM  (SELECT  COUNT(1) as num
        FROM    DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT 
        WHERE   BUS_DATE = %d{yyyyMMdd}
       ) t 
 WHERE t.num > 0;
 
 
 ------插入数据 表9---------------
 INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
              TABLE_NAME                               --表名                              
             ,ERR_CGY                                  --标志位                             
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_DDW_HLD_VAR_MOT'
             ,1
 FROM  (SELECT  COUNT(1) as num
        FROM    DDW_PROD.T_DDW_HLD_VAR_MOT 
        WHERE   BUS_DATE = %d{yyyyMMdd}
       ) t 
 WHERE t.num > 0;
 
 
 ------插入数据 表10---------------
 INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
              TABLE_NAME                               --表名                              
             ,ERR_CGY                                  --标志位                             
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_DDW_KZXTYDM_MOT'
             ,1
 FROM  (SELECT  COUNT(1) as num
        FROM    DDW_PROD.T_DDW_KZXTYDM_MOT 
        WHERE   BUS_DATE = %d{yyyyMMdd}
       ) t 
 WHERE t.num > 0;
 
 
 ------插入数据 表11---------------
 INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
              TABLE_NAME                               --表名                              
             ,ERR_CGY                                  --标志位                             
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_DDW_NWT_MKTVAL_MOT'
             ,1
 FROM  (SELECT  COUNT(1) as num
        FROM    DDW_PROD.T_DDW_NWT_MKTVAL_MOT 
        WHERE   BUS_DATE = %d{yyyyMMdd}
       ) t 
 WHERE t.num > 0;
 
 -----
  
 ------插入数据 表12---------------
 INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
              TABLE_NAME                               --表名                              
             ,ERR_CGY                                  --标志位                             
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_ODS_DATA_WARNG_MOT'
             ,1
 FROM  (SELECT  COUNT(1) as num
        FROM    DDW_PROD.T_ODS_DATA_WARNG_MOT 
        WHERE   BUS_DATE = %d{yyyyMMdd}
       ) t 
 WHERE t.num > 0;
 
 ------插入数据 表13---------------
 INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
              TABLE_NAME                               --表名                              
             ,ERR_CGY                                  --标志位                             
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_DDW_IF_TRD_DT_MOT'
             ,1
 FROM  (SELECT  COUNT(1) as num
        FROM    DDW_PROD.T_DDW_IF_TRD_DT_MOT 
       ) t 
 WHERE t.num > 0;
 
 ------插入数据 表14---------------
 INSERT INTO DDW_PROD.T_DDW_TOTAL_MOT
 (
              TABLE_NAME                               --表名                              
             ,ERR_CGY                                  --标志位                             
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT      'T_EDW_TRAN_CODE_ERR'
             ,1
 FROM  (SELECT  COUNT(1) as num
        FROM    EDW_PROD.T_EDW_TRAN_CODE_ERR 
       ) t 
 WHERE t.num > 0;
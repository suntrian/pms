 --/* ***************************************** SQL Begin ***************************************** */
 --/* 脚本功能:客户对账单月表                                                          				*/
 --/* 创建人:黄勇华                                                                             	*/
 --/* 创建时间:2017-05-03  																			*/
 ---删除临时表
-----创建月持有股票的只数
 DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP1;
 CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP1   as
 SELECT a.CUST_NO
       ,SUM(CASE WHEN a.EXG IN ('SH','HK','HB')
	         THEN 1
			 ELSE 0
			 END
		)    as HLD_SH_STK
	   ,SUM(CASE WHEN a.EXG IN ('SZ','SK','SB')
	         THEN 1
			 ELSE 0
			 END
		   )    as HLD_SZ_STK
 FROM(SELECT    a.CUST_NO,a.EXG,a.SEC_CD 
      FROM       DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS  a
	  LEFT JOIN  (SELECT  EXG
	                      ,SEC_CD_PFX
						  ,SEC_CL_CD 
				 FROM  DDW_PROD.T_DDW_CFG_SEC_TRD_CL
				 GROUP BY EXG,SEC_CD_PFX,SEC_CL_CD
			      )                                b
      ON        a.EXG = b.EXG
      AND       SUBSTR(a.SEC_CD,1,3) = b.SEC_CD_PFX
      WHERE    SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
	   AND     a.EXG IN ('SH','SZ','HK','SK','HB','SB')
       AND     b.SEC_CD_PFX IS NOT NULL
	   AND     b.SEC_CL_CD IN ('001','002','003','004','005','063','015','016','054','055','056','057','058','059','060','061','062','012','013')  ----
     GROUP BY   CUST_NO,EXG,SEC_CD
     )  a
 GROUP BY a.CUST_NO; 
 -----创建持有场外基金和金融产品的只数
  DROP TABLE  IF EXISTS  DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP2;
 CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP2 as
 SELECT  a.CUST_NO
        ,SUM(CASE WHEN a.PROD_CGY = 9
                  THEN 1
				  ELSE 0
				  END
		     )                 as HLD_FNCL_PROD
      	,SUM(CASE WHEN a.PROD_CGY = 8
                  THEN 1
				  ELSE 0
				  END
		     )		     as HLD_OTC_FND
 FROM   (SELECT    CUST_NO,PROD_CD,PROD_CGY  
          FROM     DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS
		  WHERE   SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
          GROUP BY   CUST_NO,PROD_CD,PROD_CGY   
        )    a
 GROUP BY a.CUST_NO;	  
	  --------创建临时表3(对账单月表月初资产)
	   DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP3;
       CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP3 as
	   SELECT       a.CUST_NO
	               ,a.TOL_AST      as TOL_AST_START_M   
	  
	   FROM        DDW_PROD.T_DDW_CUST_STATMT_DAY    a
	   WHERE  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                                    FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                       WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                       AND BUS_DATE = %d{yyyyMMdd}
				                   )  b
                     WHERE  a.BUS_DATE = b.MON_START
				      )
	  AND  SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)        
       ;     
	 ---------创建临时表4  
	  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP4;
       CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP4 as
	  SELECT t.*,ROW_NUMBER() OVER(ORDER BY (TOL_YLD+ADJ_YLD)*1.000000/DECODE(TOL_AST_AVG,0,9999999999,TOL_AST_AVG) DESC) as RANK1
        ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON	  from 
      (SELECT  CUST_NO
	          ,SUM(CASE WHEN a.BUS_DATE = %d{yyyyMMdd}
			            THEN a.TOL_AST
				        ELSE 0
				        END)      as TOL_AST_END_M
             ,SUM(CASE WHEN a.BUS_DATE = %d{yyyyMMdd}
			           THEN a.TOL_GL
				       ELSE 0
				       END)		as TOL_GL_END_M
             ,SUM(CASE WHEN a.BUS_DATE = %d{yyyyMMdd}
			           THEN a.AMT_BAL
				       ELSE 0
				       END)    as CPTL_BAL_END_M				   
             ,SUM(CASE WHEN a.BUS_DATE = %d{yyyyMMdd}
			           THEN a.UPNY_AMT
				       ELSE 0
				       END)    as UPNY_BAL_END_M
             ,SUM(a.TOL_YLD) as TOL_YLD
			 ,SUM(a.STK_YLD) as STK_YLD
             ,SUM(a.MNY_PROD_YLD) as MNY_PROD_YLD
             ,SUM(a.WRNT_YLD) as WRNT_YLD
			 ,SUM(a.OTH_YLD+a.int_yld) as OTH_YLD
			 ,SUM(a.TFR_IN_MKTVAL) as TFR_IN_MKTVAL
			 ,SUM(a.TURN_OUT_MKTVAL) as TURN_OUT_MKTVAL
			 ,SUM(a.NET_FLW_IN_AMT) as NET_FLW_IN_AMT
			 ,SUM(a.TFR_IN_AMT)     as TFR_IN_AMT
			 ,SUM(a.TURN_OUT_AMT)   as TURN_OUT_AMT
			 ,SUM(a.FND_SCRP_ITMS)  as FND_SCRP_ITMS
			 ,SUM(a.FND_RDMPT_ITMS) as FND_RDMPT_ITMS
			 ,SUM(a.FNCL_PROD_SCRP_ITMS) as FNCL_PROD_SCRP_ITMS
			 ,SUM(a.FNCL_PROD_RDMPT_ITMS) as FNCL_PROD_RDMPT_ITMS
			 ,SUM(a.LOT_SH_STK) as LOT_SH_STK
			 ,SUM(a.LOT_SZ_STK) as LOT_SZ_STK
			 ,SUM(a.STK_TRD_TMS) as STK_TRD_TMS
			 ,SUM(a.STK_TRD_VOL) as STK_TRD_VOL
			 ,SUM(a.STK_BUYIN_TMS) as STK_BUYIN_TMS
			 ,SUM(a.STK_SELL_TMS) as STK_SELL_TMS
             ,AVG(a.TOL_AST+a.TURN_OUT_MKTVAL+a.TURN_OUT_AMT)	  as TOL_AST_AVG
             ,SUM(a.ADJ_YLD)     as ADJ_YLD			 
 FROM 		DDW_PROD.T_DDW_CUST_STATMT_DAY    a	
 WHERE      BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01')  as INT)
 AND        BUS_DATE < = %d{yyyyMMdd}
 AND        EXISTS (SELECT 1 FROM   DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
                            WHERE     ( b.ORDI_CUST_STAT < > '3' OR b.ORDI_CNCLACT_DT > %d{yyyyMMdd})
							AND       a.CUST_NO = b.CUST_NO
							AND       b.BUS_DATE = %d{yyyyMMdd}	
					)   
 GROUP BY CUST_NO
 )  t
 WHERE (t.TOL_AST_AVG > 100 
 OR   (t.TOL_AST_AVG > =0 AND t.TOL_YLD < > 0))
  ;

  	 ---------创建临时表4  
	  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP5;
       CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP5 as
	  SELECT count(1) as TOL_RANK,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON   from 
      (SELECT  CUST_NO
             ,SUM(a.TOL_YLD) as TOL_YLD  
             ,AVG(a.TOL_AST+a.TURN_OUT_MKTVAL+a.TURN_OUT_AMT)	  as TOL_AST_AVG
            			 
 FROM 		DDW_PROD.T_DDW_CUST_STATMT_DAY    a	
 WHERE      BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01')  as INT)
 AND        BUS_DATE < = %d{yyyyMMdd}
 AND        EXISTS (SELECT 1 FROM   DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
                            WHERE     (b.ORDI_CUST_STAT < > '3' OR b.ORDI_CNCLACT_DT > %d{yyyyMMdd})
							AND       a.CUST_NO = b.CUST_NO
							AND       b.BUS_DATE = %d{yyyyMMdd}				 
					)   
 GROUP BY CUST_NO
 )  t
 WHERE (t.TOL_AST_AVG > 100 
 OR   (t.TOL_AST_AVG > =0 AND TOL_YLD < > 0))
  ;						
						
						
	  

  
 INSERT OVERWRITE DDW_PROD.T_DDW_CUST_STATMT_MON
  (       CUST_NO   				        --客户号         		
         ,CUST_NAME                         --客户姓名              
         ,BRH_NO                            --营业部编号            
         ,BRH_NAME                          --营业部名称            
         ,TOL_AST_START_M                   --月初总资产            
         ,TOL_AST_END_M                     --月末总资产
         ,TOL_GL_END_M                      --月末负债				
         ,CPTL_BAL_END_M                    --月末资金余额
         ,UPNY_BAL_END_M                    --月末在途资金			
         ,TOL_YLD                           --总的收益
		 ,MON_NET_INCM                      --月收益率
         ,STK_YLD                           --股票收益
         ,MNY_PROD_YLD                      --理财产品收益
         ,WRNT_YLD                          --期权收益
         ,OTH_YLD                           --其他收益
         ,TFR_IN_MKTVAL                     --转入市值
         ,TURN_OUT_MKTVAL                   --转出市值
         ,NET_FLW_IN_AMT                    --净流入资金
         ,TFR_IN_AMT                        --转入资金
         ,TURN_OUT_AMT                      --转出资金
         ,HLD_OTC_FND                       --持有场外基金(只)
         ,FND_SCRP_ITMS                     --场外基金认购笔数
         ,FND_RDMPT_ITMS                    --场外基金赎回笔数
         ,HLD_FNCL_PROD                     --持有金融产品(只)
         ,FNCL_PROD_SCRP_ITMS               --金融产品认购笔数
         ,FNCL_PROD_RDMPT_ITMS              --金融产品赎回笔数
         ,HLD_SH_STK                        --持有上海股票(只)
         ,HLD_SZ_STK                        --持有深圳股票(只)
         ,LOT_SH_STK                        --中签上海股票(只)
         ,LOT_SZ_STK                        --中签深圳股票(只)
         ,STK_TRD_TMS                       --总交易次数
         ,STK_TRD_VOL                       --股票交易量
         ,STK_BUYIN_TMS                     --股票买入交易次数
         ,STK_SELL_TMS                      --股票卖出交易次数
         ,AST_RANK                          --资产排名
         ,TRD_RANK                          --交易排名
         ,YLD_RANK                          --收益排名
         ,YLD_RANK_RTO                      --收益排名战胜率
         ,BUS_DATE 
 ) partition(YEAR_MON =  CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT     t.CUST_NO   				                      as CUST_NO   				     --客户号         		
           ,a5.CUST_NAME                                      as CUST_NAME                   --客户姓名              
           ,a5.BRH_NO                                         as BRH_NO                      --营业部编号            
           ,a5.BRH_NAME                                       as BRH_NAME                    --营业部名称            
           ,NVL(a3.TOL_AST_START_M,0)                         as TOL_AST_START_M             --月初总资产            
           ,t.TOL_AST_END_M                                   as TOL_AST_END_M               --月末总资产
           ,t.TOL_GL_END_M                                    as TOL_GL_END_M            	 --月末负债				
           ,t.CPTL_BAL_END_M                                  as CPTL_BAL_END_M              --月末资金余额
           ,t.UPNY_BAL_END_M                                  as UPNY_BAL_END_M          	 --月末在途资金			
           ,t.TOL_YLD                                         as TOL_YLD                     --总的收益
           ,ROUND((t.TOL_YLD+t.ADJ_YLD)*1.000000/t.TOL_AST_AVG,6)    as MON_NET_INCM                --收益率
		   ,t.STK_YLD                                         as STK_YLD                     --股票收益
           ,t.MNY_PROD_YLD                                    as MNY_PROD_YLD                --理财产品收益
           ,t.WRNT_YLD                                        as WRNT_YLD                    --期权收益
           ,t.OTH_YLD                                         as OTH_YLD                     --其他收益
           ,t.TFR_IN_MKTVAL                                   as TFR_IN_MKTVAL               --转入市值
           ,t.TURN_OUT_MKTVAL                                 as TURN_OUT_MKTVAL             --转出市值
           ,t.NET_FLW_IN_AMT                                  as NET_FLW_IN_AMT              --净流入资金
           ,t.TFR_IN_AMT                                      as TFR_IN_AMT                  --转入资金
           ,t.TURN_OUT_AMT                                    as TURN_OUT_AMT                --转出资金           
           ,NVL(a2.HLD_OTC_FND,0)                             as HLD_OTC_FND                 --持有场外基金(只)                                                         --持有场外基金(只)    
		   ,t.FND_SCRP_ITMS                                   as FND_SCRP_ITMS               --场外基金认购笔数
           ,t.FND_RDMPT_ITMS                                  as FND_RDMPT_ITMS              --场外基金赎回笔数
           ,NVL(a2.HLD_FNCL_PROD,0)                           as HLD_FNCL_PROD               --持有金融产品(只)		   
           ,t.FNCL_PROD_SCRP_ITMS                             as FNCL_PROD_SCRP_ITMS         --金融产品认购笔数                                 
		   ,t.FNCL_PROD_RDMPT_ITMS                            as FNCL_PROD_RDMPT_ITMS        --金融产品赎回笔数
		   ,NVL(a1.HLD_SH_STK,0)                              as HLD_SH_STK                  --持有上海股票(只)
		   ,NVL(a1.HLD_SZ_STK,0)                              as HLD_SZ_STK                  --持有深圳股票(只)
           ,t.LOT_SH_STK                                      as LOT_SH_STK                  --中签上海股票(只)
           ,t.LOT_SZ_STK                                      as LOT_SZ_STK                  --中签深圳股票(只)
           ,t.STK_TRD_TMS                                     as STK_TRD_TMS                 --总交易次数
           ,t.STK_TRD_VOL                                     as STK_TRD_VOL                 --股票交易量
           ,t.STK_BUYIN_TMS                                   as STK_BUYIN_TMS               --股票买入交易次数
           ,t.STK_SELL_TMS                                    as STK_SELL_TMS                --股票卖出交易次数
           ,ROW_NUMBER() OVER(ORDER BY t.TOL_AST_END_M DESC)  as AST_RANK                    --资产排名
           ,ROW_NUMBER() OVER(ORDER BY t.STK_TRD_VOL DESC)    as TRD_RANK                    --交易排名
           ,ROW_NUMBER() OVER(ORDER BY t.TOL_YLD  DESC)       as YLD_RANK                    --收益排名
           ,CAST(round((a4.TOL_RANK-t.RANK1+1)*1.00/a4.TOL_RANK,4) as DECIMAL(38,4))              as YLD_RANK_RTO                      --收益排名战胜率
           ,%d{yyyyMMdd}                                               as BUS_DATE            
		                                                                                 
 FROM           DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP4      t                               
 LEFT JOIN      DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP1     a1                               
 ON             t.CUST_NO = a1.CUST_NO                                                   
 LEFT JOIN      DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP2     a2
 ON             t.CUST_NO = a2.CUST_NO
 LEFT JOIN      DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP3     a3
 ON             t.CUST_NO = a3.CUST_NO
 LEFT JOIN      DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP5     a4
 ON             t.YEAR_MON = a4.YEAR_MON
 LEFT JOIN      DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a5
 ON             t.CUST_NO = a5.CUST_NO
 AND            a5.BUS_DATE =%d{yyyyMMdd}
 ;  
 
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP1;
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP2;
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP3;
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP4;
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MON_TEMP5;
  
-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_STATMT_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  
  invalidate metadata DDW_PROD.T_DDW_CUST_STATMT_MON;
  
  
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:产品账户信息                                                                 */
  --/* 创建人:段智泓                                                                             */
  --/* 创建时间:2018-09-06                                                                 */ 

-------插入数据开始--------------
TRUNCATE TABLE EDW_PROD.T_EDW_T02_TFP_CPXX_LC;

INSERT OVERWRITE EDW_PROD.T_EDW_T02_TFP_CPXX_LC
(
                       ID          --ID
                      ,CPDM        --产品代码
                      ,CPFL        --产品分类
                      ,CPMC        --产品名称
                      ,CPJZ        --产品净值
                      ,LJJZ        --累计净值
                      ,ZSP         --昨收盘
                      ,ZXJ         --最新价
                      ,CLRQ        --成立日期
                      ,DQRQ        --到期日期
                      ,FXGM        --发行规模(万)
                      ,CPGM        --产品规模(万)
                      ,YQSYL       --预期年化收益率%
                      ,SJSYL       --实际年化收益率%
                      ,SYLX        --收益类型
                      ,CPLX        --产品类型
                      ,TZFG        --投资风格
                      ,ZJTX        --资金投向
                      ,CPPJ        --产品评级
                      ,FXJG        --发行机构
                      ,GLJG        --管理机构
                      ,JJS         --经纪商
                      ,CPJL        --产品经理
                      ,JZZS        --基准指数
                      ,NTS         --年天数
                      ,JZRQ        --净值日期
                      ,ZCBZBL      --
                      ,QXRQ        --
                      ,DFRQ        --兑付日期
                      ,DWMZ        --单位面值
                      ,XTBS        --系统标识
)
PARTITION( bus_date = %d{yyyyMMdd})
SELECT                           
                       t.ID             AS ID         --ID
                      ,t.CPDM           AS CPDM       --产品代码
                      ,t.CPFL           AS CPFL       --产品分类
                      ,t.CPMC           AS CPMC       --产品名称
                      ,t.CPJZ           AS CPJZ       --产品净值
                      ,t.LJJZ           AS LJJZ       --累计净值
                      ,t.ZSP            AS ZSP        --昨收盘
                      ,t.ZXJ            AS ZXJ        --最新价
                      ,t.CLRQ           AS CLRQ       --成立日期
                      ,t.DQRQ           AS DQRQ       --到期日期
                      ,t.FXGM           AS FXGM       --发行规模(万)
                      ,t.CPGM           AS CPGM       --产品规模(万)
                      ,t.YQSYL          AS YQSYL      --预期年化收益率%
                      ,t.SJSYL          AS SJSYL      --实际年化收益率%
                      ,t.SYLX           AS SYLX       --收益类型
                      ,t.CPLX           AS CPLX       --产品类型
                      ,t.TZFG           AS TZFG       --投资风格
                      ,t.ZJTX           AS ZJTX       --资金投向
                      ,t.CPPJ           AS CPPJ       --产品评级
                      ,t.FXJG           AS FXJG       --发行机构
                      ,t.GLJG           AS GLJG       --管理机构
                      ,t.JJS            AS JJS        --经纪商
                      ,t.CPJL           AS CPJL       --产品经理
                      ,t.JZZS           AS JZZS       --基准指数
                      ,t.NTS            AS NTS        --年天数
                      ,t.JZRQ           AS JZRQ       --净值日期
                      ,t.ZCBZBL         AS ZCBZBL     --
                      ,t.QXRQ           AS QXRQ       --
                      ,t.DFRQ           AS DFRQ       --兑付日期
                      ,t.DWMZ           AS DWMZ       --单位面值
                      ,'OTC'            AS XTBS       --系统标识
FROM                  OTCCX.PRODUCT_TFP_CPXX_LC t
WHERE 	              t.DT = '%d{yyyyMMdd}'
;
----------插入数据结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TFP_CPXX_LC',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TFP_CPXX_LC;
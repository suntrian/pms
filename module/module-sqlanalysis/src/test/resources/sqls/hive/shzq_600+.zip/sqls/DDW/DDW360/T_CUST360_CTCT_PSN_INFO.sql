 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360联系人信息表                                                                      */
  --/* 创建人:程骏                                                                               */
  --/* 创建时间:2017-10-19                                                                        */ 
   /* T_DDW_F01_CTCT_PSN_INFO 替换为 T_DDW_F00_CUST_CTCT_PSN_INFO */
  
---------------- 插入集中交易数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_CTCT_PSN_INFO
 (
	 CUST_NO				    		    --客户号
    ,CTCT_PSN_NAME		    				--联系人名称
    ,CTF_CGY								--证件类别
    ,CTF_NO		      						--证件号码
    ,CTF_EXPR_DT		    				--证件截止日期
    ,CTCT_ADDR								--联系地址
    ,CTCT_TEL			  					--联系电话
    ,PHONE			  						--手机
    ,RLN_EXPLN			  					--联系说明           
 ) PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT      t.CUST_NO	         as CUST_NO			    		        --客户号
            ,t.CTCT_PSN_NAME	 as CTCT_PSN_NAME	    				--联系人名称
            ,a1.CTF_CGY_CD_NAME	 as CTF_CGY_CD_NAME					    --证件类别
            ,t.CTF_NO		     as CTF_NO      						--证件号码
            ,t.CTF_EXPR_DT		 as CTF_EXPR_DT    			        	--证件截止日期
            ,t.CTCT_ADDR		 as CTCT_ADDR						    --联系地址
            ,t.CTCT_TEL			 as CTCT_TEL 					        --联系电话
            ,t.PHONE			 as PHONE						        --手机
            ,t.RLN_EXPLN         as RLN_EXPLN			  				--联系说明       
 FROM         DDW_PROD.T_DDW_F00_CUST_CTCT_PSN_INFO     t
 LEFT JOIN    DDW_PROD.V_CTF_CGY_CD                a1
 ON           t.CTF_CGY_CD = a1.CTF_CGY_CD
 WHERE        t.BUS_DATE = %d{yyyyMMdd}
		;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_CTCT_PSN_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_CTCT_PSN_INFO;
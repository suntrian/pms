 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:证件过期客户信息表                                                                     */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 

  TRUNCATE TABLE DDW_PROD.T_DDW_PRT_CTF_EXPIRE_CUST_INFO;
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CTF_EXPIRE_CUST_INFO
(        
								 BRH_NO               --营业部编号  
								,BRH_NAME             --营业部名称  
								,CUST_NO              --客户号      
								,CUST_NAME            --客户姓名    
								,CTF_EXPR_DT          --证件截止日期
								,CTRL_ATTR            --控制属性    
								,M_LAUND_RSK_LVL      --洗钱风险等级
								,REMRK                --备注        
								,RSK_LVL              --风险级别    						   						 				
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
					 t.BRH_NO                              AS BRH_NO               --营业部编号      
					,a2.brh_shrtnm                            AS BRH_NAME             --营业部名称      
					,t.CUST_NO                             AS CUST_NO              --客户号          
					,t.CUST_NAME                           AS CUST_NAME            --客户姓名        
					,t.CTF_EXPR_DT                         AS CTF_EXPR_DT          --证件截止日期    
					,t.CTRL_ATTR                           AS CTRL_ATTR            --控制属性        
					,b2.M_LAUND_RSK_LVL_NAME             AS M_LAUND_RSK_LVL      --洗钱风险等级    
					,CASE WHEN t.CTF_EXPR_DT <= CAST(EDW_PROD.g_date_add_int(%d{yyyyMMdd},'yyyyMMdd','yyyyMMdd',0,-6,0) AS INT) 
                          THEN '六个月'
                          ELSE NULL
                          END                           AS REMRK                --备注          
			        ,b1.CUST_RSK_LVL_NAME                           AS RSK_LVL              --风险级别      
  FROM  	 DDW_PROD.T_DDW_F00_CUST_CUST_INFO     t
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                a2
  ON            t.BRH_NO = a2.BRH_NO
  AND           a2.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN 	DDW_PROD.V_CUST_RSK_LVL						b1
  ON				t.CUST_RSK_LVL = b1.CUST_RSK_LVL
  LEFT JOIN  DDW_PROD.V_M_LAUND_RSK_LVL            b2
  ON         t.M_LAUND_RSK_LVL = b2.M_LAUND_RSK_LVL
  WHERE 	t.bus_date = %d{yyyyMMdd}
  AND       t.CUST_RSK_LVL IN ('0','1','2','8','19')
  AND       (t.CTF_EXPR_DT < = %d{yyyyMMdd} OR t.CTF_EXPR_DT IS NULL)
  AND       t.ORDI_CUST_STAT<>'3'
  AND       a2.BRH_NO IS NOT NULL
  ;
  ------结束----

 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_CTF_EXPIRE_CUST_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
     invalidate metadata DDW_PROD.T_DDW_PRT_CTF_EXPIRE_CUST_INFO; 
------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:外部机构TA公司表                                                                    */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
TRUNCATE TABLE DDW_PROD.T_DDW_EXTN_ORG_TA_CO ;
INSERT OVERWRITE DDW_PROD.T_DDW_EXTN_ORG_TA_CO
(
                                     TA_CD                        --TA代码
                                    ,TA_FULLNM                    --TA全称
                                    ,TA_SHRTNM                    --TA简称									                                   								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT         t.TADM             as TA_CD                        --TA代码                          
               ,t.TAJGMC           as TA_FULLNM                    --TA全称
               ,t.TAJGJC           as TA_SHRTNM                    --TA简称                                         						   
 FROM           EDW_PROD.T_EDW_T03_TOF_TAXX                                 t       
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
;		
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_EXTN_ORG_TA_CO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
       invalidate metadata DDW_PROD.T_DDW_EXTN_ORG_TA_CO ;
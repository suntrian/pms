------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户交易收入日表                                                                */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 


----创建交割临时临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP as
 SELECT        a.CUST_NO
              ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
			                 THEN a.S1*b.ZHHL
							 WHEN b.BZDM IS  NULL
			                 AND  a.SYS_SRC = '普通账户'
			                 THEN a.S1
					         ELSE 0
					         END,2) as DECIMAL(38,2)
					))                         as ORDI_S1_INCM_RMB                        --普通账户佣金收入(人民币)
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'			                 
			                 THEN a.S1
					         ELSE 0
					         END as DECIMAL(38,2)
					))                         as CRD_S1_INCM                             --信用账户佣金收入

			   ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                  AND  a.SYS_SRC = '普通账户'
							  AND  c.EXG IS NULL
			                  THEN a.S1*b.ZHHL
							  WHEN b.BZDM IS  NULL
			                  AND  a.SYS_SRC = '普通账户'
							  AND  c.EXG IS NULL
			                  THEN a.S1
					          ELSE 0
					          END,2) as DECIMAL(38,2)
					))                        as ORDI_S1_INCM_OTH_RMB                    --普通账户佣金收入_其他(包括权证等)
			   ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))                         as S1_INCM_HA                              --佣金收入_沪A主板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '001'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))                           as ORDI_S1_INCM_HA                         --普通账户佣金收入_沪A主板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '001'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))                        as CRD_S1_INCM_HA                          --信用账户佣金收入_沪A主板
			   ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))                     as S1_INCM_SA                              --佣金收入_深A主板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '002'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))                    as ORDI_S1_INCM_SA                         --普通账户佣金收入_深A主板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '002'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))           as CRD_S1_INCM_SA                          --信用账户佣金收入_深A主板
			   ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))           as S1_INCM_SMS                             --佣金收入_中小板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '003'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_S1_INCM_SMS                        --普通账户佣金收入_中小板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '003'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))   as CRD_S1_INCM_SMS                         --信用账户佣金收入_中小板
			   ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))      as S1_INCM_GEM                             --佣金收入_创业板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '004'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as ORDI_S1_INCM_GEM                        --普通账户佣金收入_创业板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '004'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as CRD_S1_INCM_GEM                         --信用账户佣金收入_创业板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '005'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))   as ORDI_S1_INCM_HB_USD                     --普通账户佣金收入_沪B_美元
				,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
							 AND  c.SEC_CL_CD = '005'
			                 THEN a.S1*b.ZHHL					
					         ELSE 0
					         END,2) as DECIMAL(38,2)
					))     as ORDI_S1_INCM_HB_RMB                   --普通账户佣金收入_沪B_人民币	
					
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '063'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_S1_INCM_SB_HKD                     --普通账户佣金收入_深B_港币
			   ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
							 AND  c.SEC_CL_CD = '063'
			                 THEN a.S1*b.ZHHL					
					         ELSE 0
					         END,2) as DECIMAL(38,2)
					))     as ORDI_S1_INCM_SB_RMB                   --普通账户佣金收入_深B_人民币	
			    ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '015'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_S1_INCM_HK                         --普通账户佣金收入_沪港通
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '016'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_S1_INCM_SK                         --普通账户佣金收入_深港通
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('006','008')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as ORDI_S1_INCM_TA                         --普通账户佣金收入_三板A股
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('007')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_S1_INCM_TU_USD                     --普通账户佣金收入_三板B股_美元
			    ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
							 AND  c.SEC_CL_CD = '007'
			                 THEN a.S1*b.ZHHL					
					         ELSE 0
					         END,2) as DECIMAL(38,2)
					))     as ORDI_S1_INCM_TU_RMB                   --普通账户佣金收入_三板B股_人民币
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('011','009','010')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_S1_INCM_REPO                       --普通账户佣金收入_回购
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_S1_INCM_EXG_FND                    --普通账户佣金收入_场内基金收入
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('054','059')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_S1_INCM_CLS_FND                    --普通账户佣金收入_封闭式基金
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('057','061')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as ORDI_S1_INCM_ETF_FND                    --普通账户佣金收入_ETF
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('055','060','062')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as ORDI_S1_INCM_OPN_FND                    --普通账户佣金收入_开放式
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('056')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as ORDI_S1_INCM_LOF_FND                    --普通账户佣金收入_LOF
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('058')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					)) as ORDI_S1_INCM_FOF_FND                    --普通账户佣金收入_FOF
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					)) CRD_S1_INCM_EXG_FND                     --信用账户佣金收入_场内基金收入
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('054','059')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as CRD_S1_INCM_CLS_FND                     --信用账户佣金收入_封闭式基金
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('057','061')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as CRD_S1_INCM_ETF_FND                     --信用账户佣金收入_ETF
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('055','060','062')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))   as CRD_S1_INCM_OPN_FND                     --信用账户佣金收入_开放式
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('056')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as CRD_S1_INCM_LOF_FND                     --信用账户佣金收入_LOF
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('058')
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as CRD_S1_INCM_FOF_FND                     --信用账户佣金收入_FOF
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD BETWEEN '017' AND '053'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_S1_INCM_BOND                       --普通账户佣金收入_债券
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD BETWEEN '017' AND '053'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))   as CRD_S1_INCM_BOND                        --信用账户佣金收入_债券
			   ,SUM(CAST(ROUND(CASE WHEN a.EXG IN ('HK','SK')
			                        AND b.BZDM IS NULL
			                        AND  a.SYS_SRC = '普通账户'
							        THEN a.S1
									WHEN a.EXG = 'SZ'
									AND  a.SYS_SRC = '普通账户'
									AND  c.SEC_CL_CD IN ('002','003','004')
									THEN a.S1+a.S3-a.S11-a.S12-a.S13
			                        WHEN b.BZDM IS NOT NULL
			                        AND  a.SYS_SRC = '普通账户'
			                        THEN (a.S1-a.S11-a.s12)*b.ZHHL
							        WHEN b.BZDM IS  NULL
			                        AND  a.SYS_SRC = '普通账户'
							        AND   a.EXG NOT IN ('HK','SK')
			                        THEN a.S1-a.S11-a.s12
					                ELSE 0
					                END,2) as DECIMAL(38,2)
					))                         as ORDI_NET_S1_INCM_RMB                        --普通账户净佣金收入(人民币)
			  ,SUM(CAST(CASE WHEN a.EXG = 'SZ'
							 AND  a.SYS_SRC = '信用账户'
							 AND  c.SEC_CL_CD IN ('002','003','004')
							 THEN a.S1+a.S3-a.S11-a.S12-a.S13
                             WHEN a.SYS_SRC = '信用账户'			                 
							 THEN a.S1-a.S11-a.s12
					         ELSE 0
					         END as DECIMAL(38,2)
					))                         as CRD_NET_S1_INCM                             --信用账户净佣金收入

			   ,SUM(CAST(ROUND(CASE WHEN a.EXG IN ('HK','SK')
			                  AND b.BZDM IS NULL
			                  AND  a.SYS_SRC = '普通账户'
							  AND  c.EXG IS NULL
							 THEN a.S1
							 WHEN a.EXG = 'SZ'
							 AND  a.SYS_SRC = '普通账户'
							 AND  c.SEC_CL_CD IN ('002','003','004')
							 AND  c.EXG IS NULL
							 THEN a.S1+a.S3-a.S11-a.S12-a.S13							 
			                 WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
							 AND  c.EXG IS NULL
			                 THEN (a.S1-a.S11-a.s12)*b.ZHHL				
							 WHEN b.BZDM IS  NULL
			                 AND  a.SYS_SRC = '普通账户'
							 AND   a.EXG NOT IN ('HK','SK')
							 AND  c.EXG IS NULL
			                 THEN a.S1-a.S11-a.s12
					         ELSE 0
					         END,2) as DECIMAL(38,2)
					))                        as ORDI_NET_S1_INCM_OTH_RMB                    --普通账户净佣金收入_其他(包括权证等)
			   ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))                         as NET_S1_INCM_HA                              --净佣金收入_沪A主板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '001'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))                           as ORDI_NET_S1_INCM_HA                         --普通账户净佣金收入_沪A主板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '001'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))                        as CRD_NET_S1_INCM_HA                          --信用账户净佣金收入_沪A主板
			   ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
			                  THEN a.S1+a.S3-a.S11-a.S12-a.S13
					          ELSE 0
					          END as DECIMAL(38,2)
					))                     as NET_S1_INCM_SA                              --净佣金收入_深A主板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '002'
			                  THEN a.S1+a.S3-a.S11-a.S12-a.S13
					          ELSE 0
					          END as DECIMAL(38,2)
					))                    as ORDI_NET_S1_INCM_SA                         --普通账户净佣金收入_深A主板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '002'
			                  THEN a.S1+a.S3-a.S11-a.S12-a.S13
					          ELSE 0
					          END as DECIMAL(38,2)
					))           as CRD_NET_S1_INCM_SA                          --信用账户净佣金收入_深A主板
			   ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
			                  THEN a.S1+a.S3-a.S11-a.S12-a.S13
					          ELSE 0
					          END as DECIMAL(38,2)
					))           as NET_S1_INCM_SMS                             --净佣金收入_中小板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '003'
			                  THEN a.S1+a.S3-a.S11-a.S12-a.S13
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_NET_S1_INCM_SMS                        --普通账户净佣金收入_中小板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '003'
			                  THEN a.S1+a.S3-a.S11-a.S12-a.S13
					          ELSE 0
					          END as DECIMAL(38,2)
					))   as CRD_NET_S1_INCM_SMS                         --信用账户净佣金收入_中小板
			   ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
			                  THEN a.S1+a.S3-a.S11-a.S12-a.S13
					          ELSE 0
					          END as DECIMAL(38,2)
					))      as NET_S1_INCM_GEM                             --净佣金收入_创业板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '004'
			                  THEN a.S1+a.S3-a.S11-a.S12-a.S13
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as ORDI_NET_S1_INCM_GEM                        --普通账户净佣金收入_创业板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '004'
			                  THEN a.S1+a.S3-a.S11-a.S12-a.S13
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as CRD_NET_S1_INCM_GEM                         --信用账户净佣金收入_创业板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '005'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))   as ORDI_NET_S1_INCM_HB_USD                     --普通账户净佣金收入_沪B_美元
			     ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
							 AND  c.SEC_CL_CD = '005'
			                 THEN (a.S1-a.S11-a.s12)*b.ZHHL					
					         ELSE 0
					         END,2) as DECIMAL(38,2)
					))     as ORDI_NET_S1_INCM_HB_RMB                   --普通账户净佣金收入_沪B_人民币
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '063'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_NET_S1_INCM_SB_HKD                     --普通账户净佣金收入_深B_港币
			   ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
							 AND  c.SEC_CL_CD = '063'
			                 THEN (a.S1-a.S11-a.s12)*b.ZHHL					
					         ELSE 0
					         END,2) as DECIMAL(38,2)
					))     as ORDI_NET_S1_INCM_SB_RMB                   --普通账户净佣金收入_深B_人民币
			    ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '015'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_NET_S1_INCM_HK                         --普通账户净佣金收入_沪港通
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '016'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_NET_S1_INCM_SK                         --普通账户净佣金收入_深港通
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('006','008')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as ORDI_NET_S1_INCM_TA                         --普通账户净佣金收入_三板A股
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('007')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_NET_S1_INCM_TU_USD                     --普通账户净佣金收入_三板B股_美元
			    ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
							 AND  c.SEC_CL_CD = '007'
			                 THEN (a.S1-a.S11-a.s12)*b.ZHHL					
					         ELSE 0
					         END,2) as DECIMAL(38,2)
					))     as ORDI_NET_S1_INCM_TU_RMB                   --普通账户净佣金收入_三板B股_人民币
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('011','009','010')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_NET_S1_INCM_REPO                       --普通账户净佣金收入_回购
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_NET_S1_INCM_EXG_FND                    --普通账户净佣金收入_场内基金收入
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('054','059')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_NET_S1_INCM_CLS_FND                    --普通账户净佣金收入_封闭式基金
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('057','061')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as ORDI_NET_S1_INCM_ETF_FND                    --普通账户净佣金收入_ETF
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('055','060','062')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as ORDI_NET_S1_INCM_OPN_FND                    --普通账户净佣金收入_开放式
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('056')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as ORDI_NET_S1_INCM_LOF_FND                    --普通账户净佣金收入_LOF
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('058')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					)) as ORDI_NET_S1_INCM_FOF_FND                    --普通账户净佣金收入_FOF
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					)) as CRD_NET_S1_INCM_EXG_FND                     --信用账户净佣金收入_场内基金收入
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('054','059')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as CRD_NET_S1_INCM_CLS_FND                     --信用账户净佣金收入_封闭式基金
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('057','061')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as CRD_NET_S1_INCM_ETF_FND                     --信用账户净佣金收入_ETF
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('055','060','062')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))   as CRD_NET_S1_INCM_OPN_FND                     --信用账户净佣金收入_开放式
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('056')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as CRD_NET_S1_INCM_LOF_FND                     --信用账户净佣金收入_LOF
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('058')
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as CRD_NET_S1_INCM_FOF_FND                     --信用账户净佣金收入_FOF
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD BETWEEN '017' AND '053'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_NET_S1_INCM_BOND                       --普通账户净佣金收入_债券
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD BETWEEN '017' AND '053'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))   as CRD_NET_S1_INCM_BOND                        --信用账户净佣金收入_债券	
             ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
			                 THEN (a.S1+a.S2+a.S3+a.S4+a.S5+a.S6)*b.ZHHL
							 WHEN b.BZDM IS  NULL
			                 AND  a.SYS_SRC = '普通账户'
			                 THEN (a.S1+a.S2+a.S3+a.S4+a.S5+a.S6)
					         ELSE 0
					         END,2) as DECIMAL(38,2)
					))                         as ORDI_TRD_FEE_RMB                        --普通账户交易费用(人民币)
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'			                 
			                 THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					         ELSE 0
					         END as DECIMAL(38,2)
					))                         as CRD_TRD_FEE                            --信用账户交易费用

			   ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                  AND  a.SYS_SRC = '普通账户'
							  AND  c.EXG IS NULL
			                  THEN (a.S1+a.S2+a.S3+a.S4+a.S5+a.S6)*b.ZHHL
							  WHEN b.BZDM IS  NULL
			                  AND  a.SYS_SRC = '普通账户'
							  AND  c.EXG IS NULL
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END,2) as DECIMAL(38,2)
					))                        as ORDI_TRD_FEE_OTH_RMB                    --普通账户交易费用_其他(包括权证等)
			   ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))                         as TRD_FEE_HA                              --交易费用_沪A主板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '001'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))                           as ORDI_TRD_FEE_HA                         --普通账户交易费用_沪A主板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '001'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))                        as CRD_TRD_FEE_HA                          --信用账户交易费用_沪A主板
			   ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))                     as TRD_FEE_SA                              --交易费用_深A主板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '002'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))                    as ORDI_TRD_FEE_SA                         --普通账户交易费用_深A主板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '002'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))           as CRD_TRD_FEE_SA                          --信用账户交易费用_深A主板
			   ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))           as TRD_FEE_SMS                             --交易费用_中小板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '003'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_TRD_FEE_SMS                        --普通账户交易费用_中小板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '003'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))   as CRD_TRD_FEE_SMS                         --信用账户交易费用_中小板
			   ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))      as TRD_FEE_GEM                             --交易费用_创业板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '004'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as ORDI_TRD_FEE_GEM                        --普通账户交易费用_创业板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '004'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as CRD_TRD_FEE_GEM                         --信用账户交易费用_创业板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '005'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))   as ORDI_TRD_FEE_HB_USD                     --普通账户交易费用_沪B_美元
				 ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
							 AND  c.SEC_CL_CD = '005'
			                 THEN (a.S1+a.S2+a.S3+a.S4+a.S5+a.S6)*b.ZHHL					
					         ELSE 0
					         END,2) as DECIMAL(38,2)
					))     as ORDI_TRD_FEE_HB_RMB                   --普通账户交易费用_沪B_人民币
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '063'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_TRD_FEE_SB_HKD                     --普通账户交易费用_深B_港币
				 ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
							 AND  c.SEC_CL_CD = '063'
			                 THEN (a.S1+a.S2+a.S3+a.S4+a.S5+a.S6)*b.ZHHL					
					         ELSE 0
					         END,2) as DECIMAL(38,2)
					))     as ORDI_TRD_FEE_SB_RMB                   --普通账户交易费用_深B_人民币
			    ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '015'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_TRD_FEE_HK                         --普通账户交易费用_沪港通
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '016'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_TRD_FEE_SK                         --普通账户交易费用_深港通
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('006','008')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as ORDI_TRD_FEE_TA                         --普通账户交易费用_三板A股
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('007')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_TRD_FEE_TU_USD                     --普通账户交易费用_三板B股_美元
				,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
							 AND  c.SEC_CL_CD = '007'
			                 THEN (a.S1+a.S2+a.S3+a.S4+a.S5+a.S6)*b.ZHHL					
					         ELSE 0
					         END,2) as DECIMAL(38,2)
					))     as ORDI_TRD_FEE_TU_RMB                   --普通账户交易费用_三板B股_人民币
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('011','009','010')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_TRD_FEE_REPO                       --普通账户交易费用_回购
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_TRD_FEE_EXG_FND                    --普通账户交易费用_场内基金
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('054','059')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_TRD_FEE_CLS_FND                    --普通账户交易费用_封闭式基金
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('057','061')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as ORDI_TRD_FEE_ETF_FND                    --普通账户交易费用_ETF
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('055','060','062')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as ORDI_TRD_FEE_OPN_FND                    --普通账户交易费用_开放式
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('056')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as ORDI_TRD_FEE_LOF_FND                    --普通账户交易费用_LOF
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD IN ('058')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					)) as ORDI_TRD_FEE_FOF_FND                    --普通账户交易费用_FOF
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					)) as CRD_TRD_FEE_EXG_FND                     --信用账户交易费用_场内基金
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('054','059')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as CRD_TRD_FEE_CLS_FND                     --信用账户交易费用_封闭式基金
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('057','061')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as CRD_TRD_FEE_ETF_FND                     --信用账户交易费用_ETF
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('055','060','062')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))   as CRD_TRD_FEE_OPN_FND                     --信用账户交易费用_开放式
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('056')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))  as CRD_TRD_FEE_LOF_FND                     --信用账户交易费用_LOF
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD IN ('058')
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as CRD_TRD_FEE_FOF_FND                     --信用账户交易费用_FOF
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD BETWEEN '017' AND '053'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))    as ORDI_TRD_FEE_BOND                       --普通账户交易费用_债券
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD BETWEEN '017' AND '053'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))   as CRD_TRD_FEE_BOND                        --信用账户交易费用_债券					
                ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))      as TRD_FEE_STIB_AK                             --交易费用_AK科创板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '012'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as ORDI_TRD_FEE_STIB_AK                        --普通账户交易费用_AK科创板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '012'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as CRD_TRD_FEE_STIB_AK                         --信用账户交易费用_AK科创板
			     ,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))      as TRD_FEE_STIB_RK                             --交易费用_RK科创CDR
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD = '013'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as ORDI_TRD_FEE_STIB_RK                        --普通账户交易费用_RK科创CDR
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD = '013'
			                  THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as CRD_TRD_FEE_STIB_RK                         --信用账户交易费用_RK科创CDR
				
				,SUM(CAST(CASE WHEN c.SEC_CL_CD =  '012'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))      as NET_S1_INCM_STIB_AK                             --净佣金收入_AK科创板
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD =  '012'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as ORDI_NET_S1_INCM_STIB_AK                        --普通账户净佣金收入_AK科创板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD =  '012'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as CRD_NET_S1_INCM_STIB_AK                         --信用账户净佣金收入_AK科创板
				,SUM(CAST(CASE WHEN c.SEC_CL_CD =  '012'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))      as S1_INCM_STIB_AK                             --佣金收入_AK科创板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD =  '012'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as ORDI_S1_INCM_STIB_AK                        --普通账户佣金收入_AK科创板
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD =  '012'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as CRD_S1_INCM_STIB_AK                         --信用账户佣金收入_AK科创板
				                 ,SUM(CAST(CASE WHEN c.SEC_CL_CD =  '013'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))      as NET_S1_INCM_STIB_RK                             --净佣金收入_RK科创CDR
			  ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD =  '013'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as ORDI_NET_S1_INCM_STIB_RK                        --普通账户净佣金收入_RK科创CDR
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD =  '013'
			                  THEN a.S1-a.S11-a.s12
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as CRD_NET_S1_INCM_STIB_RK                         --信用账户净佣金收入_RK科创CDR
				,SUM(CAST(CASE WHEN c.SEC_CL_CD =  '013'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))      as S1_INCM_STIB_RK                             --佣金收入_RK科创CDR
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '普通账户'
							  AND  c.SEC_CL_CD =  '013'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as ORDI_S1_INCM_STIB_RK                        --普通账户佣金收入_RK科创CDR
			   ,SUM(CAST(CASE WHEN a.SYS_SRC = '信用账户'
							  AND  c.SEC_CL_CD =  '013'
			                  THEN a.S1
					          ELSE 0
					          END as DECIMAL(38,2)
					))     as CRD_S1_INCM_STIB_RK                         --信用账户佣金收入_RK科创CDR
			 
			  ,SUM(CASE WHEN a.ODR_CGY IN (61,62,63,64,71,72)
                       AND  a.SYS_SRC = '信用账户'
                       THEN a.S1
                       ELSE 0
                       END
                 )   as CRD_CRD_TRD_S1          --信用账户信用交易佣金
			 ,SUM(CASE WHEN a.EXG = 'TA'
                       AND  a.SYS_SRC = '普通账户'
					   AND  SUBSTR(a.SEC_CD,1,2) IN ('43','83','87')					  
                       THEN a.S1
                       ELSE 0
                       END
                 )   as NEW_TA_TRD_S1         --新三板交易佣金
			 ,SUM(CASE WHEN d.JJDM IS NOT NULL			          
                       THEN a.S1
                       ELSE 0
                       END
                 )   as CLS_FND_TRD_S1         --分级基金交易佣金			
			
             ,SUM(CASE WHEN a.ODR_CGY IN (61,62,63,64,71,72)
                       AND  a.SYS_SRC = '信用账户'
                       THEN a.S1-a.S11-a.s12
                       ELSE 0
                       END
                 )   as CRD_CRD_TRD_NET_S1    --信用账户信用交易净佣金
			 ,SUM(CASE WHEN a.EXG = 'TA'
                       AND  a.SYS_SRC = '普通账户'
					   AND  SUBSTR(a.SEC_CD,1,2) IN ('43','83','87')
                       THEN a.S1-a.S11-a.s12
                       ELSE 0
                       END
                 )   as NEW_TA_TRD_NET_S1       --新三板交易净佣金
			 ,SUM(CASE WHEN d.JJDM IS NOT NULL
                       THEN a.S1-a.S11-a.s12
                       ELSE 0
                       END
                 )   as CLS_FND_TRD_NET_S1     --分级基金交易净佣金	
              
             ,SUM(CASE WHEN a.ODR_CGY IN (61,62,63,64,71,72)
                       AND  a.SYS_SRC = '信用账户'
                       THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
                       ELSE 0
                       END
                 )   as CRD_CRD_TRD_FEE        --信用账户信用交易费用
			 ,SUM(CASE WHEN a.EXG = 'TA'
                       AND  a.SYS_SRC = '普通账户'
					   AND  SUBSTR(a.SEC_CD,1,2) IN ('43','83','87')
                       THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
                       ELSE 0
                       END
                 )   as NEW_TA_TRD_FEE          --新三板交易费用
			 ,SUM(CASE WHEN d.JJDM IS NOT NULL
                       THEN a.S1+a.S2+a.S3+a.S4+a.S5+a.S6
                       ELSE 0
                       END
                 )   as CLS_FND_TRD_FEE     --分级基金交易费用		  
					
 FROM        DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS                 a
 LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH                             b
 ON             a.CCY_CD = b.BZDM
 AND            b.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN    (SELECT DISTINCT EXG,SEC_CD_PFX,SEC_CGY_PFX,SEC_CL_CD FROM DDW_PROD.T_DDW_CFG_SEC_TRD_CL   )                    c
 ON             a.EXG = c.EXG
 AND            SUBSTR(a.SEC_CD,1,3) = c.SEC_CD_PFX
 AND            (SUBSTR(a.SEC_CGY,1,1) = c.SEC_CGY_PFX
 OR             SUBSTR(a.SEC_CGY,1,3) = c.SEC_CGY_PFX)
 LEFT JOIN (SELECT JYS,JJDM FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS WHERE BUS_DATE = %d{yyyyMMdd} AND JSRQ = 99999999) d
 ON        a.SEC_CD = d.JJDM
 AND       a.EXG = d.JYS
 WHERE         a.BUS_DATE = %d{yyyyMMdd}
 GROUP BY  a.CUST_NO ;
 
 -----产品的明细
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP1 as
 SELECT  CUST_NO
        ,SUM(CASE WHEN PROD_BIZ_CD < > '600'
		          THEN CMSN_FEE 
			      ELSE 0-CMSN_FEE
			      END
		    )   as PROD_CMSN_FEE                  --普通账户手续费
		
        ,SUM(CASE WHEN PROD_BIZ_CD < > '600'
		          AND  PROD_CGY = 8
				  AND  SUBSTR(PROD_CD,1,1) < > 'A'
				  AND  SUBSTR(PROD_CD,1,2) < > '95'
		          THEN CMSN_FEE 
				  WHEN PROD_BIZ_CD = '600'
		          AND  PROD_CGY = 8
				  AND  SUBSTR(PROD_CD,1,1) < > 'A'
				  AND  SUBSTR(PROD_CD,1,2) < > '95'
		          THEN 0-CMSN_FEE 
			      ELSE 0
			      END
		    )     as AGN_FND_CMSN_FEE          --代销基金手续费
        ,SUM(CASE WHEN PROD_BIZ_CD < > '600'
		          AND  PROD_CGY = 8
				  AND  SUBSTR(PROD_CD,1,1) = 'A'
		          THEN CMSN_FEE 
				  WHEN PROD_BIZ_CD = '600'
		          AND  PROD_CGY = 8
				  AND  SUBSTR(PROD_CD,1,1) = 'A'
		          THEN 0-CMSN_FEE 
			      ELSE 0
			      END
		    )      as GS_PROD_CMSN_FEE          --公司产品手续费
        ,SUM(CASE WHEN PROD_BIZ_CD < > '600'
		          AND  PROD_CGY = 8				 
				  AND  SUBSTR(PROD_CD,1,2) = '95'
		          THEN CMSN_FEE 
				  WHEN PROD_BIZ_CD = '600'
		          AND  PROD_CGY = 8
				  AND  SUBSTR(PROD_CD,1,2) = '95'
		          THEN 0-CMSN_FEE 
			      ELSE 0
			      END
		    )        as GJ_PROD_CMSN_FEE          --国君产品手续费
		  ,SUM(CASE WHEN  PROD_CGY = 11				 				  
		            THEN CMSN_FEE 				 
			        ELSE 0
			        END
		    )        as OTC_PROD_CMSN_FEE          --OTC产品手续费
		 
		 ,SUM(CASE WHEN PROD_BIZ_CD = '130'
		          THEN CNFM_AMT 
			      ELSE 0
			      END
		    )   as PROD_SCRP_AMT                 --产品认购金额		

         ,SUM(CASE WHEN PROD_BIZ_CD = '122'
		          THEN CNFM_AMT 
			      ELSE 0
			      END
		    )   as PROD_PRCH_AMT                 --产品申购金额	
		 ,SUM(CASE WHEN PROD_BIZ_CD IN ('142','124','150')
		          THEN CNFM_AMT 
			      ELSE 0
			      END
		    )   as PROD_FIXINV_AMT                 --产品定投金额	

		  ,SUM(CASE WHEN PROD_BIZ_CD = '139'
		          THEN CNFM_AMT 
			      ELSE 0
			      END
		    )   as PROD_RDMPT_AMT                 --产品赎回金额
		
		 ,SUM(CASE WHEN PROD_BIZ_CD = '130'
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) < >  'A'
				   AND  SUBSTR(PROD_CD,1,2) < >  '95'
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )    as AGN_FND_SCRP_AMT                    --代销基金认购金额
		,SUM(CASE WHEN PROD_BIZ_CD = '122'
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) < >  'A'
				   AND  SUBSTR(PROD_CD,1,2) < >  '95'
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )   as AGN_FND_PRCH_AMT                    --代销基金申购金额
		,SUM(CASE WHEN PROD_BIZ_CD = '139'
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) < >  'A'
				   AND  SUBSTR(PROD_CD,1,2) < >  '95'
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )    as AGN_FND_FIXINV_AMT                  --代销基金定投金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('142','124','150')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) < >  'A'
				   AND  SUBSTR(PROD_CD,1,2) < >  '95'
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )    as AGN_FND_RDMPT_AMT                   --代销基金赎回金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('130')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) =  'A'
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )  as GS_PROD_SCRP_AMT                    --公司产品认购金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('122')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) =  'A'
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )  as GS_PROD_PRCH_AMT                    --公司产品申购金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('139')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) =  'A'
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )   as GS_PROD_FIXINV_AMT                  --公司产品定投金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('124','142','150')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) =  'A'
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )   as GS_PROD_RDMPT_AMT                   --公司产品赎回金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('130')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,2) =  '95'
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )   as GJ_PROD_SCRP_AMT                    --国君产品认购金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('122')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,2) =  '95'
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )  as GJ_PROD_PRCH_AMT                    --国君产品申购金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('139')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,2) =  '95'
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )   as GJ_PROD_FIXINV_AMT                  --国君产品定投金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('142','124')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,2) =  '95'
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )   as GJ_PROD_RDMPT_AMT                   --国君产品赎回金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('130')
		           AND  PROD_CGY = 9				  
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )  as BANK_PROD_SCRP_AMT                  --银行产品认购金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('122','139')
		           AND  PROD_CGY = 9				  
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )  as BANK_PROD_PRCH_AMT                  --银行产品申购金额		
		,SUM(CASE WHEN PROD_BIZ_CD IN ('124','142','150')
		           AND  PROD_CGY = 9				  
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )   as BANK_PROD_RDMPT_AMT                 --银行产品赎回金额	
		
        ,SUM(CASE WHEN PROD_BIZ_CD IN ('130')
		           AND  PROD_CGY = 11				  
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )  as OTC_PROD_SCRP_AMT                  --OTC产品认购金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('122','139')
		           AND  PROD_CGY = 11				  
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )  as OTC_PROD_PRCH_AMT                  --OTC产品申购金额		
		,SUM(CASE WHEN PROD_BIZ_CD IN ('124','142','150')
		           AND  PROD_CGY = 11			  
		           THEN cnfm_amt 
			       ELSE 0
			       END
		     )   as OTC_PROD_RDMPT_AMT                 --OTC产品赎回金额			
			 
			 
		,SUM(CASE WHEN PROD_BIZ_CD = '130'
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) < >  'A'
				   AND  SUBSTR(PROD_CD,1,2) < >  '95'
		           THEN 1 
			       ELSE 0
			       END
		     )    as AGN_FND_SCRP_ITMS                    --代销基金认购笔数
		,SUM(CASE WHEN PROD_BIZ_CD = '122'
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) < >  'A'
				   AND  SUBSTR(PROD_CD,1,2) < >  '95'
		           THEN 1 
			       ELSE 0
			       END
		     )   as AGN_FND_PRCH_ITMS                    --代销基金申购笔数
		,SUM(CASE WHEN PROD_BIZ_CD = '139'
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) < >  'A'
				   AND  SUBSTR(PROD_CD,1,2) < >  '95'
		           THEN 1 
			       ELSE 0
			       END
		     )    as AGN_FND_FIXINV_ITMS                  --代销基金定投笔数
		,SUM(CASE WHEN PROD_BIZ_CD IN ('142','124')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) < >  'A'
				   AND  SUBSTR(PROD_CD,1,2) < >  '95'
		           THEN 1 
			       ELSE 0
			       END
		     )    as AGN_FND_RDMPT_ITMS                   --代销基金赎回笔数
		,SUM(CASE WHEN PROD_BIZ_CD IN ('130')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) =  'A'
		           THEN 1 
			       ELSE 0
			       END
		     )  as GS_PROD_SCRP_ITMS                    --公司产品认购笔数
		,SUM(CASE WHEN PROD_BIZ_CD IN ('122')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) =  'A'
		           THEN 1 
			       ELSE 0
			       END
		     )  as GS_PROD_PRCH_ITMS                    --公司产品申购笔数
		,SUM(CASE WHEN PROD_BIZ_CD IN ('139')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) =  'A'
		           THEN 1 
			       ELSE 0
			       END
		     )   as GS_PROD_FIXINV_ITMS                  --公司产品定投笔数
		,SUM(CASE WHEN PROD_BIZ_CD IN ('124','142','150')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,1) =  'A'
		           THEN 1 
			       ELSE 0
			       END
		     )   as GS_PROD_RDMPT_ITMS                   --公司产品赎回笔数
		,SUM(CASE WHEN PROD_BIZ_CD IN ('130')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,2) =  '95'
		           THEN 1 
			       ELSE 0
			       END
		     )   as GJ_PROD_SCRP_ITMS                    --国君产品认购笔数
		,SUM(CASE WHEN PROD_BIZ_CD IN ('122')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,2) =  '95'
		           THEN 1 
			       ELSE 0
			       END
		     )  as GJ_PROD_PRCH_ITMS                    --国君产品申购笔数
		,SUM(CASE WHEN PROD_BIZ_CD IN ('139')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,2) =  '95'
		           THEN 1 
			       ELSE 0
			       END
		     )   as GJ_PROD_FIXINV_ITMS                  --国君产品定投笔数
		,SUM(CASE WHEN PROD_BIZ_CD IN ('142','124','150')
		           AND  PROD_CGY = 8
				   AND  SUBSTR(PROD_CD,1,2) =  '95'
		           THEN 1 
			       ELSE 0
			       END
		     )   as GJ_PROD_RDMPT_ITMS                   --国君产品赎回笔数
		,SUM(CASE WHEN PROD_BIZ_CD IN ('130')
		           AND  PROD_CGY = 9				  
		           THEN 1 
			       ELSE 0
			       END
		     )  as BANK_PROD_SCRP_ITMS                  --银行产品认购笔数
		,SUM(CASE WHEN PROD_BIZ_CD IN ('122','139')
		           AND  PROD_CGY = 9				  
		           THEN 1 
			       ELSE 0
			       END
		     )  as BANK_PROD_PRCH_ITMS                  --银行产品申购笔数		
		,SUM(CASE WHEN PROD_BIZ_CD IN ('124','142','150')
		           AND  PROD_CGY = 9				  
		           THEN 1 
			       ELSE 0
			       END
		     )   as BANK_PROD_RDMPT_ITMS                 --银行产品赎回笔数
			 
		,SUM(CASE WHEN PROD_BIZ_CD IN ('130')
		           AND  PROD_CGY = 11				  
		           THEN 1 
			       ELSE 0
			       END
		     )  as OTC_PROD_SCRP_ITMS                  --OTC产品认购笔数
		,SUM(CASE WHEN PROD_BIZ_CD IN ('122','139')
		           AND  PROD_CGY = 11				  
		           THEN 1 
			       ELSE 0
			       END
		     )  as OTC_PROD_PRCH_ITMS                  --OTC产品申购笔数		
		,SUM(CASE WHEN PROD_BIZ_CD IN ('124','142','150')
		           AND  PROD_CGY = 11				  
		           THEN 1 
			       ELSE 0
			       END
		     )   as OTC_PROD_RDMPT_ITMS                 --OTC产品赎回笔数			 
 FROM  DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS   a
 WHERE         a.BUS_DATE = %d{yyyyMMdd}
 GROUP BY a.CUST_NO ;
 
--交易量与交易笔数 
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP2 ;
   CREATE TABLE DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP2 as
   SELECT CUST_NO
		,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.BS_DRCT IN (1,2,3)
			           THEN a.MTCH_AMT*b.ZHHL
					   WHEN b.BZDM IS  NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.BS_DRCT IN (1,2,3)
			           THEN a.MTCH_AMT
					   WHEN b.BZDM IS NOT NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1,2)
			           THEN a.MTCH_AMT*b.ZHHL
					   WHEN b.BZDM IS  NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1,2)
			           THEN a.MTCH_AMT
					   ELSE 0
					   END,2) as DECIMAL(38,2)
			))     as ORDI_TRD_VOL_RMB                    --普通账户交易量(人民币)
	  ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.BS_DRCT IN (1,2)
			           THEN a.MTCH_AMT*b.ZHHL
					   WHEN b.BZDM IS  NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.BS_DRCT IN (1,2)
			           THEN a.MTCH_AMT
					   WHEN b.BZDM IS NOT NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1,2)
			           THEN a.MTCH_AMT*b.ZHHL
					   WHEN b.BZDM IS  NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1,2)
			           THEN a.MTCH_AMT
					   ELSE 0
					   END,2) as DECIMAL(38,2)
			))     as ORDI_TRD_VOL_RMB_80                    --普通账户交易量(人民币)(不包含申购交易量)			
	   ,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.BS_DRCT = 1
			           THEN a.MTCH_AMT*b.ZHHL
					   WHEN b.BZDM IS  NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.BS_DRCT = 1
			           THEN a.MTCH_AMT
					   WHEN b.BZDM IS NOT NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1)
			           THEN a.MTCH_AMT*b.ZHHL
					   WHEN b.BZDM IS  NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1)
			           THEN a.MTCH_AMT
					   ELSE 0
					   END,2) as DECIMAL(38,2)
			))    as ORDI_TRD_VOL_RMB_BUYIN              --普通账户交易量(人民币)_买入
		,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.BS_DRCT = 2
			           THEN a.MTCH_AMT*b.ZHHL
					   WHEN b.BZDM IS  NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.BS_DRCT = 2
			           THEN a.MTCH_AMT
					   WHEN b.BZDM IS NOT NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (2)
			           THEN a.MTCH_AMT*b.ZHHL
					   WHEN b.BZDM IS  NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (2)
			           THEN a.MTCH_AMT
					   ELSE 0
					   END,2) as DECIMAL(38,2)
			))   as ORDI_TRD_VOL_RMB_SELL               --普通账户交易量(人民币)_卖出
			,SUM(CAST(ROUND(CASE WHEN b.BZDM IS NOT NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.BS_DRCT = 3
			           THEN a.MTCH_AMT*b.ZHHL
					   WHEN b.BZDM IS  NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.BS_DRCT = 3
			           THEN a.MTCH_AMT					  
					   ELSE 0
					   END,2) as DECIMAL(38,2)
			))   as ORDI_TRD_VOL_RMB_PRCH              --普通账户交易量(人民币)_申购
			
			
		,SUM(CAST(CASE WHEN  a.SYS_SRC = '信用账户'
					   AND  c.BS_DRCT IN (1,2,3)
			           THEN a.MTCH_AMT					   
					   WHEN  a.SYS_SRC = '信用账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1,2)
			           THEN a.MTCH_AMT
					   ELSE 0
					   END as DECIMAL(38,2)
			))           as CRD_TRD_VOL                         --信用账户交易量
		,SUM(CAST(CASE WHEN  a.SYS_SRC = '信用账户'
					   AND  c.BS_DRCT IN (1,2)
			           THEN a.MTCH_AMT					   
					   WHEN  a.SYS_SRC = '信用账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1,2)
			           THEN a.MTCH_AMT
					   ELSE 0
					   END as DECIMAL(38,2)
			))           as CRD_TRD_VOL_80                         --信用账户交易量(不包含申购交易量)
		,SUM(CAST(CASE WHEN  a.SYS_SRC = '信用账户'
					   AND  c.BS_DRCT = 1
			           THEN a.MTCH_AMT					   
					   WHEN  a.SYS_SRC = '信用账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1)
			           THEN a.MTCH_AMT
					   ELSE 0
					   END as DECIMAL(38,2)
			))   as CRD_TRD_VOL_BUYIN                   --信用账户交易量_买入
		,SUM(CAST(CASE WHEN  a.SYS_SRC = '信用账户'
					   AND  c.BS_DRCT = 2
			           THEN a.MTCH_AMT					   
					   WHEN  a.SYS_SRC = '信用账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (2)
			           THEN a.MTCH_AMT
					   ELSE 0
					   END as DECIMAL(38,2)
			))  as CRD_TRD_VOL_SELL                    --信用账户交易量_卖出
		,SUM(CAST(CASE WHEN  a.SYS_SRC = '信用账户'
					   AND  c.BS_DRCT = 3
			           THEN a.MTCH_AMT					   
					   ELSE 0
					   END as DECIMAL(38,2)
			))  as CRD_TRD_VOL_PRCH                    --信用账户交易量_申购

		,SUM(CAST(ROUND(CASE WHEN a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1,2)
					   AND   b.BZDM IS  NOT NULL
			           THEN a.MTCH_AMT*b.ZHHL
					   WHEN b.BZDM IS  NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1,2)
			           THEN a.MTCH_AMT
					   ELSE 0
					   END,2) as DECIMAL(38,2)
			))            as ORDI_TRD_VOL_OTH_RMB                --普通账户交易量_其他(包括权证等)
		,SUM(CAST(ROUND(CASE WHEN a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1)
					   AND  b.BZDM IS NOT  NULL
			           THEN a.MTCH_AMT*b.ZHHL
					   WHEN b.BZDM IS  NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (1)
			           THEN a.MTCH_AMT
					   ELSE 0
					   END,2) as DECIMAL(38,2)
			))  as ORDI_TRD_VOL_OTH_RMB_BUYIN          --普通账户交易量_其他(包括权证等)_买入
		,SUM(CAST(ROUND(CASE WHEN a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (2)
					   AND b.BZDM IS NOT NULL
			           THEN a.MTCH_AMT*b.ZHHL
					   WHEN b.BZDM IS  NULL
			           AND  a.SYS_SRC = '普通账户'
					   AND  c.EXG IS  NULL
					   AND  a.ODR_CGY IN (2)
			           THEN a.MTCH_AMT
					   ELSE 0
					   END,2) as DECIMAL(38,2)
			))    as ORDI_TRD_VOL_OTH_RMB_SELL           --普通账户交易量_其他(包括权证等)_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))     as TRD_VOL_HA                          --交易量_沪A主板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))     as TRD_VOL_HA_80                          --交易量_沪A主板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_HA_BUYIN                    --交易量_沪A主板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_HA_SELL                     --交易量_沪A主板_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_HA_PRCH                     --交易量_沪A主板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))  as ORDI_TRD_VOL_HA                     --普通账户交易量_沪A主板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))  as ORDI_TRD_VOL_HA_80                     --普通账户交易量_沪A主板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_HA_BUYIN               --普通账户交易量_沪A主板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))  as ORDI_TRD_VOL_HA_SELL                --普通账户交易量_沪A主板_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))  as ORDI_TRD_VOL_HA_PRCH                --普通账户交易量_沪A主板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_HA                      --信用账户交易量_沪A主板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_HA_80                      --信用账户交易量_沪A主板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_HA_BUYIN                --信用账户交易量_沪A主板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_HA_SELL                 --信用账户交易量_沪A主板_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_HA_PRCH                 --信用账户交易量_沪A主板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                --AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_SA                          --交易量_深A主板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                --AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_SA_80                          --交易量_深A主板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                --AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_SA_BUYIN                    --交易量_深A主板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                --AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_SA_SELL                     --交易量_深A主板_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '001'
		                --AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_SA_PRCH                     --交易量_深A主板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SA                     --普通账户交易量_深A主板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SA_80                     --普通账户交易量_深A主板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SA_BUYIN               --普通账户交易量_深A主板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SA_SELL                --普通账户交易量_深A主板_卖出
			,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SA_PRCH                --普通账户交易量_深A主板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_SA                      --信用账户交易量_深A主板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_SA_80                      --信用账户交易量_深A主板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_SA_BUYIN                --信用账户交易量_深A主板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_SA_SELL                 --信用账户交易量_深A主板_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '002'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_SA_PRCH                 --信用账户交易量_深A主板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		               -- AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_SMS                         --交易量_中小板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		               -- AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_SMS_80                         --交易量_中小板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		               -- AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_SMS_BUYIN                   --交易量_中小板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		               -- AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_SMS_SELL                    --交易量_中小板_卖出
			,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		               -- AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_SMS_PRCH                    --交易量_中小板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SMS                    --普通账户交易量_中小板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SMS_80                    --普通账户交易量_中小板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SMS_BUYIN              --普通账户交易量_中小板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SMS_SELL               --普通账户交易量_中小板_卖出
			,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SMS_PRCH               --普通账户交易量_中小板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_SMS                     --信用账户交易量_中小板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_SMS_80                     --信用账户交易量_中小板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_SMS_BUYIN               --信用账户交易量_中小板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_SMS_SELL                --信用账户交易量_中小板_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '003'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_SMS_PRCH                --信用账户交易量_中小板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		               
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_GEM                         --交易量_创业板
			,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		               
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_GEM_80                         --交易量_创业板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		               -- AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_GEM_BUYIN                   --交易量_创业板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		               -- AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_GEM_SELL                    --交易量_创业板_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		               -- AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_GEM_PRCH                    --交易量_创业板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_GEM                    --普通账户交易量_创业板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_GEM_80                    --普通账户交易量_创业板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_GEM_BUYIN              --普通账户交易量_创业板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_GEM_SELL               --普通账户交易量_创业板_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_GEM_PRCH               --普通账户交易量_创业板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_GEM                     --信用账户交易量_创业板
					,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_GEM_80                     --信用账户交易量_创业板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_GEM_BUYIN               --信用账户交易量_创业板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_GEM_SELL                --信用账户交易量_创业板_卖出
			,SUM(CAST(CASE WHEN c.SEC_CL_CD = '004'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_GEM_PRCH               --信用账户交易量_创业板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '005'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_HB_USD                 --普通账户交易量_沪B_美元
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '005'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_HB_USD_BUYIN           --普通账户交易量_沪B_美元_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '005'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_HB_USD_SELL            --普通账户交易量_沪B_美元_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '063'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) ORDI_TRD_VOL_SB_HKD                 --普通账户交易量_深B_港币
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '063'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SB_HKD_BUYIN           --普通账户交易量_深B_港币_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '063'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SB_HKD_SELL            --普通账户交易量_深B_港币_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '015'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_HK                     --普通账户交易量_沪港通
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '015'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_HK_BUYIN               --普通账户交易量_沪港通_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '015'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_HK_SELL                --普通账户交易量_沪港通_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '016'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SK                     --普通账户交易量_深港通
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '016'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SK_BUYIN               --普通账户交易量_深港通_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '016'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_SK_SELL                --普通账户交易量_深港通_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('006','008')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_TA                     --普通账户交易量_三板A股
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('006','008')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_TA_BUYIN               --普通账户交易量_三板A股_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('006','008')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_TA_SELL                --普通账户交易量_三板A股_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('007')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_TU_USD                 --普通账户交易量_三板B股_美元
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('007')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_TU_USD_BUYIN           --普通账户交易量_三板B股_美元_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('007')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_TU_USD_SELL            --普通账户交易量_三板B股_美元_卖出
		,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD = '005'
		       AND a.SYS_SRC = '普通账户'
		       AND  c.BS_DRCT IN (1,2)
			   AND  b.BZDM IS NOT NULL
			   THEN a.MTCH_AMT*b.ZHHL
			   ELSE 0
			   END,2) as DECIMAL(38,2)
			)) as ORDI_TRD_VOL_HB_RMB                 --普通账户交易量_沪B_人民币
,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD = '005'
		        AND a.SYS_SRC = '普通账户'
		        AND  c.BS_DRCT IN (1)
				AND  b.BZDM IS NOT NULL
			    THEN a.MTCH_AMT*b.ZHHL
				ELSE 0
				END,2) as DECIMAL(38,2)
			)) as ORDI_TRD_VOL_HB_RMB_BUYIN           --普通账户交易量_沪B_人民币_买入
,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD = '005'
		        AND a.SYS_SRC = '普通账户'
		        AND  c.BS_DRCT IN (2)
				AND  b.BZDM IS NOT NULL
			    THEN a.MTCH_AMT*b.ZHHL
				ELSE 0
				END,2) as DECIMAL(38,2)
	)) as ORDI_TRD_VOL_HB_RMB_SELL            --普通账户交易量_沪B_人民币_卖出
	
,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD = '063'
		       AND a.SYS_SRC = '普通账户'
		       AND  c.BS_DRCT IN (1,2)
			   AND  b.BZDM IS NOT NULL
			   THEN a.MTCH_AMT*b.ZHHL
			   ELSE 0
			   END,2) as DECIMAL(38,2)
			)) as ORDI_TRD_VOL_SB_RMB                 --普通账户交易量_深B_人民币
,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD = '063'
		        AND a.SYS_SRC = '普通账户'
		        AND  c.BS_DRCT IN (1)
				AND  b.BZDM IS NOT NULL
			    THEN a.MTCH_AMT*b.ZHHL
				ELSE 0
				END,2) as DECIMAL(38,2)
			)) as ORDI_TRD_VOL_SB_RMB_BUYIN           --普通账户交易量_深B_人民币_买入
,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD = '063'
		        AND a.SYS_SRC = '普通账户'
		        AND  c.BS_DRCT IN (2)
				AND  b.BZDM IS NOT NULL
			    THEN a.MTCH_AMT*b.ZHHL
				ELSE 0
				END,2) as DECIMAL(38,2)
	)) as ORDI_TRD_VOL_SB_RMB_SELL            --普通账户交易量_深B_人民币_卖出
	

	,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD = '007'
		       AND a.SYS_SRC = '普通账户'
		       AND  c.BS_DRCT IN (1,2)
			   AND  b.BZDM IS NOT NULL
			   THEN a.MTCH_AMT*b.ZHHL
			   ELSE 0
			   END,2) as DECIMAL(38,2)
			)) as ORDI_TRD_VOL_TU_RMB                 --普通账户交易量_三板B股_人民币
,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD = '007'
		        AND a.SYS_SRC = '普通账户'
		        AND  c.BS_DRCT IN (1)
				AND  b.BZDM IS NOT NULL
			    THEN a.MTCH_AMT*b.ZHHL
				ELSE 0
				END,2) as DECIMAL(38,2)
			)) as ORDI_TRD_VOL_TU_RMB_BUYIN           --普通账户交易量_三板B股_人民币_买入
,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD = '007'
		        AND a.SYS_SRC = '普通账户'
		        AND  c.BS_DRCT IN (2)
				AND  b.BZDM IS NOT NULL
			    THEN a.MTCH_AMT*b.ZHHL
				ELSE 0
				END,2) as DECIMAL(38,2)
	)) as ORDI_TRD_VOL_TU_RMB_SELL             --普通账户交易量_三板B股_人民币_卖出
		,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD IN ('011','009','010')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END,2) as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_REPO                   --普通账户交易量_回购
		,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD IN ('011','009','010')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END,2) as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_REPO_BUYIN             --普通账户交易量_回购_买入
		,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD IN ('011','009','010')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END,2) as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_REPO_SELL              --普通账户交易量_回购_卖出
		,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END,2) as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_EXG_FND                --普通账户交易量_场内基金
		,SUM(CAST(ROUND(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END,2) as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_EXG_FND_BUYIN          --普通账户交易量_场内基金_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_EXG_FND_SELL           --普通账户交易量_场内基金_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('054','059')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_CLS_FND                --普通账户交易量_封闭式基金
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('054','059')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_CLS_FND_BUYIN          --普通账户交易量_封闭式基金_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('054','059')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_CLS_FND_SELL           --普通账户交易量_封闭式基金_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('057','061')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_ETF_FND                --普通账户交易量_ETF
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('057','061')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_ETF_FND_BUYIN          --普通账户交易量_ETF_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('057','061')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_ETF_FND_SELL           --普通账户交易量_ETF_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('055','060','062')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_OPN_FND                --普通账户交易量_开放式
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('055','060','062')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_OPN_FND_BUYIN          --普通账户交易量_开放式_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('055','060','062')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_OPN_FND_SELL           --普通账户交易量_开放式_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('056')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_LOF_FND                --普通账户交易量_LOF
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('056')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_LOF_FND_BUYIN          --普通账户交易量_LOF_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('056')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_LOF_FND_SELL           --普通账户交易量_LOF_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('058')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_FOF_FND                --普通账户交易量_FOF
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('058')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_FOF_FND_BUYIN          --普通账户交易量_FOF_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('058')
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_FOF_FND_SELL           --普通账户交易量_FOF_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_EXG_FND                --信用账户交易量_场内基金
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_EXG_FND_BUYIN          --信用账户交易量_场内基金_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_EXG_FND_SELL           --信用账户交易量_场内基金_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('054','059')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_CLS_FND                --信用账户交易量_封闭式基金
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('054','059')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_CLS_FND_BUYIN          --信用账户交易量_封闭式基金_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('054','059')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_CLS_FND_SELL           --信用账户交易量_封闭式基金_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('057','061')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_ETF_FND                --信用账户交易量_ETF
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('057','061')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_ETF_FND_BUYIN          --信用账户交易量_ETF_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('057','061')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_ETF_FND_SELL           --信用账户交易量_ETF_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('055','060','062')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_OPN_FND                --信用账户交易量_开放式
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('055','060','062')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_OPN_FND_BUYIN          --信用账户交易量_开放式_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('055','060','062')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_OPN_FND_SELL           --信用账户交易量_开放式_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('056')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_LOF_FND                --信用账户交易量_LOF
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('056')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_LOF_FND_BUYIN          --信用账户交易量_LOF_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('056')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_LOF_FND_SELL           --信用账户交易量_LOF_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('058')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_FOF_FND                --信用账户交易量_FOF
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('058')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_FOF_FND_BUYIN          --信用账户交易量_FOF_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('058')
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_FOF_FND_SELL           --信用账户交易量_FOF_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_BOND                   --普通账户交易量_债券
		,SUM(CAST(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_BOND_80                   --普通账户交易量_债券(不包含债券的申购)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_BOND_BUYIN             --普通账户交易量_债券_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_BOND_SELL              --普通账户交易量_债券_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_BOND_PRCH              --普通账户交易量_债券_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_BOND                    --信用账户交易量_债券	
		,SUM(CAST(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_BOND_80                    --信用账户交易量_债券(不包含债券的申购)	
		,SUM(CAST(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_BOND_BUYIN              --信用账户交易量_债券_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_BOND_SELL               --信用账户交易量_债券_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_BOND_PRCH               --信用账户交易量_债券_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))     as TRD_VOL_AK                          --交易量_AK科创板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))     as TRD_VOL_AK_80                          --交易量_AK科创板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_AK_BUYIN                    --交易量_AK科创板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_AK_SELL                     --交易量_AK科创板_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_AK_PRCH                     --交易量_AK科创板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))  as ORDI_TRD_VOL_AK                     --普通账户交易量_AK科创板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))  as ORDI_TRD_VOL_AK_80                     --普通账户交易量_AK科创板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_AK_BUYIN               --普通账户交易量_AK科创板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))  as ORDI_TRD_VOL_AK_SELL                --普通账户交易量_AK科创板_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))  as ORDI_TRD_VOL_AK_PRCH                --普通账户交易量_AK科创板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_AK                      --信用账户交易量_AK科创板
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_AK_80                      --信用账户交易量_AK科创板(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_AK_BUYIN                --信用账户交易量_AK科创板_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_AK_SELL                 --信用账户交易量_AK科创板_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '012'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_AK_PRCH                 --信用账户交易量_AK科创板_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))     as TRD_VOL_RK                          --交易量_RK科创CDR
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))     as TRD_VOL_RK_80                          --交易量_RK科创CDR(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_RK_BUYIN                    --交易量_RK科创CDR_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_RK_SELL                     --交易量_RK科创CDR_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as TRD_VOL_RK_PRCH                     --交易量_RK科创CDR_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))  as ORDI_TRD_VOL_RK                     --普通账户交易量_RK科创CDR
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))  as ORDI_TRD_VOL_RK_80                     --普通账户交易量_RK科创CDR(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as ORDI_TRD_VOL_RK_BUYIN               --普通账户交易量_RK科创CDR_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))  as ORDI_TRD_VOL_RK_SELL                --普通账户交易量_RK科创CDR_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND a.SYS_SRC = '普通账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					))  as ORDI_TRD_VOL_RK_PRCH                --普通账户交易量_RK科创CDR_申购
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2,3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_RK                      --信用账户交易量_RK科创CDR
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1,2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_RK_80                      --信用账户交易量_RK科创CDR(不包含申购交易量)
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (1)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_RK_BUYIN                --信用账户交易量_RK科创CDR_买入
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (2)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_RK_SELL                 --信用账户交易量_RK科创CDR_卖出
		,SUM(CAST(CASE WHEN c.SEC_CL_CD = '013'
		                AND a.SYS_SRC = '信用账户'
		                AND  c.BS_DRCT IN (3)
			            THEN a.MTCH_AMT
					    ELSE 0
					    END as DECIMAL(38,2)
					)) as CRD_TRD_VOL_RK_PRCH                 --信用账户交易量_RK科创CDR_申购
		
		    ,SUM(CASE WHEN a.ODR_CGY IN (61,62,63,64,71,72)
                       AND  a.SYS_SRC = '信用账户'
                       THEN a.MTCH_AMT
                       ELSE 0
                       END
                 )   as CRD_CRD_TRD_VOL      --信用账户信用交易量
			 ,SUM(CASE WHEN a.EXG = 'TA'
                       AND  a.SYS_SRC = '普通账户'
					   AND  SUBSTR(a.SEC_CD,1,2) IN ('43','83','87')
					   AND  c.BS_DRCT IN (1,2)
                       THEN a.MTCH_AMT
                       ELSE 0
                       END
                 )   as NEW_TA_TRD_VOL         --新三板交易量
			 ,SUM(CASE WHEN d.JJDM IS NOT NULL
			           AND  c.BS_DRCT IN (1,2)
                       THEN a.MTCH_AMT
                       ELSE 0
                       END
                 )   as CLS_FND_TRD_VOL        --分级基金交易量
 FROM        DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS                 a
 LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH                             b
 ON             a.CCY_CD = b.BZDM
 AND            b.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN    DDW_PROD.T_DDW_CFG_SEC_TRD_CL                      c
 ON             a.EXG = c.EXG
 AND            SUBSTR(a.SEC_CD,1,3) = c.SEC_CD_PFX
 AND            (SUBSTR(a.SEC_CGY,1,1) = c.SEC_CGY_PFX
 OR             SUBSTR(a.SEC_CGY,1,3) = c.SEC_CGY_PFX)
 AND            a.ODR_CGY = c.TRD_CGY
  LEFT JOIN (SELECT JYS,JJDM FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS WHERE BUS_DATE = %d{yyyyMMdd} AND JSRQ = 99999999) d
 ON        a.SEC_CD = d.JJDM
 AND       a.EXG = d.JYS
 WHERE         a.BUS_DATE = %d{yyyyMMdd}
 GROUP BY  a.CUST_NO  ;
 --交易笔数
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP3 ;
   CREATE TABLE DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP3 as
   SELECT  CUST_NO
           ,SUM(CASE WHEN  a.SYS_SRC = '普通账户'
					 AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 WHEN   a.SYS_SRC = '普通账户'
					 AND  c.EXG IS  NULL
					 AND  a.ODR_CGY IN (1,2)
			         THEN 1
					 ELSE 0
					 END
			    ) as ORDI_TRD_ITMS                        --普通账户交易笔数
			   ,SUM(CASE WHEN  a.SYS_SRC = '普通账户'
					 AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 WHEN   a.SYS_SRC = '普通账户'
					 AND  c.EXG IS  NULL
					 AND  a.ODR_CGY IN (1,2)
			         THEN 1
					 ELSE 0
					 END
			    ) as ORDI_TRD_ITMS_80                        --普通账户交易笔数(不包含申购的笔数)
           ,SUM(CASE WHEN  a.SYS_SRC = '信用账户'
					 AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 WHEN   a.SYS_SRC = '信用账户'
					 AND  c.EXG IS  NULL
					 AND  a.ODR_CGY IN (1,2)
			         THEN 1
					 ELSE 0
					 END
			    ) as CRD_TRD_ITMS                         --信用账户交易笔数
		        ,SUM(CASE WHEN  a.SYS_SRC = '信用账户'
					 AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 WHEN   a.SYS_SRC = '信用账户'
					 AND  c.EXG IS  NULL
					 AND  a.ODR_CGY IN (1,2)
			         THEN 1
					 ELSE 0
					 END
			    ) as CRD_TRD_ITMS_80                         --信用账户交易笔数(不包含申购的笔数)
           ,SUM(CASE WHEN   a.SYS_SRC = '普通账户'
					 AND  c.EXG IS  NULL
					 AND  a.ODR_CGY IN (1,2)
			         THEN 1
					 ELSE 0
					 END
			    ) as ORDI_TRD_ITMS_OTH                    --普通账户交易笔数_其他(包括权证等)
           ,SUM(CASE WHEN c.SEC_CL_CD = '001'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_HA                          --交易笔数_沪A主板
		   ,SUM(CASE WHEN c.SEC_CL_CD = '001'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_HA_80                          --交易笔数_沪A主板(不包含申购的笔数)
           ,SUM(CASE WHEN c.SEC_CL_CD = '001'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_HA                     --普通账户交易笔数_沪A主板
		   ,SUM(CASE WHEN c.SEC_CL_CD = '001'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_HA_80                     --普通账户交易笔数_沪A主板(不包含申购的笔数)
           ,SUM(CASE WHEN c.SEC_CL_CD = '001'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_HA                      --信用账户交易笔数_沪A主板
			,SUM(CASE WHEN c.SEC_CL_CD = '001'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_HA_80                      --信用账户交易笔数_沪A主板(不包含申购的笔数)
           ,SUM(CASE WHEN c.SEC_CL_CD = '002'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_SA                          --交易笔数_深A主板
			 ,SUM(CASE WHEN c.SEC_CL_CD = '002'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_SA_80                          --交易笔数_深A主板(不包含申购的笔数)
           ,SUM(CASE WHEN c.SEC_CL_CD = '002'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_SA                     --普通账户交易笔数_深A主板
			,SUM(CASE WHEN c.SEC_CL_CD = '002'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_SA_80                     --普通账户交易笔数_深A主板(不包含申购的笔数)
           ,SUM(CASE WHEN c.SEC_CL_CD = '002'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_SA                      --信用账户交易笔数_深A主板
			,SUM(CASE WHEN c.SEC_CL_CD = '002'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_SA_80                      --信用账户交易笔数_深A主板(不包含申购的笔数)
           ,SUM(CASE WHEN c.SEC_CL_CD = '003'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_SMS                         --交易笔数_中小板
		       ,SUM(CASE WHEN c.SEC_CL_CD = '003'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_SMS_80                         --交易笔数_中小板(不包含申购的笔数)
           ,SUM(CASE WHEN c.SEC_CL_CD = '003'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_SMS                    --普通账户交易笔数_中小板
			 ,SUM(CASE WHEN c.SEC_CL_CD = '003'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_SMS_80                    --普通账户交易笔数_中小板(不包含申购的笔数)
            ,SUM(CASE WHEN c.SEC_CL_CD = '003'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_SMS                     --信用账户交易笔数_中小板
			,SUM(CASE WHEN c.SEC_CL_CD = '003'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_SMS_80                     --信用账户交易笔数_中小板(不包含申购的笔数)
                 ,SUM(CASE WHEN c.SEC_CL_CD = '004'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_GEM                         --交易笔数_创业板
				   ,SUM(CASE WHEN c.SEC_CL_CD = '004'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_GEM_80                         --交易笔数_创业板(不包含申购的笔数)
           ,SUM(CASE WHEN c.SEC_CL_CD = '004'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_GEM                    --普通账户交易笔数_创业板
			,SUM(CASE WHEN c.SEC_CL_CD = '004'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_GEM_80                    --普通账户交易笔数_创业板(不包含申购的笔数)
            ,SUM(CASE WHEN c.SEC_CL_CD = '004'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_GEM                     --信用账户交易笔数_创业板
			 ,SUM(CASE WHEN c.SEC_CL_CD = '004'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_GEM_80                     --信用账户交易笔数_创业板(不包含申购的笔数)
           ,SUM(CASE WHEN c.SEC_CL_CD = '005'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_HB                     --普通账户交易笔数_沪B_美元
           ,SUM(CASE WHEN c.SEC_CL_CD = '063'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_SB                     --普通账户交易笔数_深B_港币
           ,SUM(CASE WHEN c.SEC_CL_CD = '015'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_HK                     --普通账户交易笔数_沪港通
           ,SUM(CASE WHEN c.SEC_CL_CD = '016'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_SK                     --普通账户交易笔数_深港通
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('006','008')
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_TA                     --普通账户交易笔数_三板A股
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('007')
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_TU                     --普通账户交易笔数_三板B股
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('011','009','010')
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
                     END 
					 ) as ORDI_TRD_ITMS_REPO                   --普通账户交易笔数_回购
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_EXG_FND                --普通账户交易笔数_场内基金
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('054','059')
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_CLS_FND                --普通账户交易笔数_封闭式基金
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('057','061')
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_ETF_FND                --普通账户交易笔数_ETF
           ,SUM(CASE WHEN c.SEC_CL_CD IN('055','060','062')
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_OPN_FND                --普通账户交易笔数_开放式
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('056')
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_LOF_FND                --普通账户交易笔数_LOF
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('058')
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_FOF_FND                --普通账户交易笔数_FOF
          ,SUM(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_EXG_FND                --信用账户交易笔数_场内基金
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('054','059')
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_CLS_FND                --信用账户交易笔数_封闭式基金
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('057','061')
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_ETF_FND                --信用账户交易笔数_ETF
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('055','060','062')
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_OPN_FND                --信用账户交易笔数_开放式
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('056')
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_LOF_FND                --信用账户交易笔数_LOF
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('058')
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_FOF_FND                --信用账户交易笔数_FOF
           ,SUM(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 )   as ORDI_TRD_ITMS_BOND               --普通账户交易笔数_债券
			 ,SUM(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 )   as ORDI_TRD_ITMS_BOND_80               --普通账户交易笔数_债券(不包含债券申购)
           ,SUM(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 )  as CRD_TRD_ITMS_BOND                    --信用账户交易笔数_债券	
			  ,SUM(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 )  as CRD_TRD_ITMS_BOND_80                    --信用账户交易笔数_债券(不包含债券申购)
                        ,SUM(CASE WHEN c.SEC_CL_CD = '012'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_STIB_AK                                 --交易笔数_AK科创板
		 ,SUM(CASE WHEN c.SEC_CL_CD = '012'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_STIB_AK_80                              --交易笔数_AK科创板(不包含申购的笔数)
           ,SUM(CASE WHEN c.SEC_CL_CD = '012'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_STIB_AK                            --普通账户交易笔数_AK科创板
			,SUM(CASE WHEN c.SEC_CL_CD = '012'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_STIB_AK_80                         --普通账户交易笔数_AK科创板(不包含申购的笔数)
            ,SUM(CASE WHEN c.SEC_CL_CD = '012'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_STIB_AK                             --信用账户交易笔数_AK科创板
			 ,SUM(CASE WHEN c.SEC_CL_CD = '012'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_STIB_AK_80                          --信用账户交易笔数_AK科创板(不包含申购的笔数)
                        ,SUM(CASE WHEN c.SEC_CL_CD = '013'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_STIB_RK                                 --交易笔数_RK科创CDR
		 ,SUM(CASE WHEN c.SEC_CL_CD = '013'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_STIB_RK_80                              --交易笔数_RK科创CDR(不包含申购的笔数)
           ,SUM(CASE WHEN c.SEC_CL_CD = '013'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_STIB_RK                            --普通账户交易笔数_RK科创CDR
			,SUM(CASE WHEN c.SEC_CL_CD = '013'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_STIB_RK_80                         --普通账户交易笔数_RK科创CDR(不包含申购的笔数)
            ,SUM(CASE WHEN c.SEC_CL_CD = '013'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2,3)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_STIB_RK                             --信用账户交易笔数_RK科创CDR
			 ,SUM(CASE WHEN c.SEC_CL_CD = '013'
		             AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1,2)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_STIB_RK_80                          --信用账户交易笔数_RK科创CDR(不包含申购的笔数)
             ,SUM(CASE WHEN a.ODR_CGY IN (61,62,63,64,71,72)
                       AND  a.SYS_SRC = '信用账户'
                       THEN 1
                       ELSE 0
                       END
                 )   as CRD_CRD_TRD_ITMS       --信用账户信用交易笔数
			 ,SUM(CASE WHEN a.EXG = 'TA'
                       AND  a.SYS_SRC = '普通账户'
					   AND  SUBSTR(a.SEC_CD,1,2) IN ('43','83','87')
					   AND  c.BS_DRCT IN (1,2)
                       THEN 1
                       ELSE 0
                       END
                 )   as NEW_TA_TRD_ITMS       --新三板交易笔数
			 ,SUM(CASE WHEN d.JJDM IS NOT NULL
			           AND  c.BS_DRCT IN (1,2)
                       THEN 1
                       ELSE 0
                       END
                 )   as CLS_FND_TRD_ITMS    --分级基金交易笔数
			 ,SUM(CASE WHEN c.SEC_CL_CD = '001'
		    AND  c.BS_DRCT IN (1)
			THEN 1
			ELSE 0
			END
	 ) as TRD_ITMS_HA_BUYIN                          --交易笔数_沪A主板_买入
 ,SUM(CASE WHEN c.SEC_CL_CD = '001'
		    AND  c.BS_DRCT IN (2)
			THEN 1
			ELSE 0
			END
	 ) as TRD_ITMS_HA_SELL                          --交易笔数_沪A主板_卖出	 
 ,SUM(CASE WHEN c.SEC_CL_CD = '001'
		    AND  c.BS_DRCT IN (3)
			THEN 1
			ELSE 0
			END
	 ) as TRD_ITMS_HA_PRCH                          --交易笔数_沪A主板_申购
,SUM(CASE WHEN c.SEC_CL_CD = '002'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1)
			         THEN 1
					 ELSE 0
					 END
	) as TRD_ITMS_SA_BUYIN                          --交易笔数_深A主板_买入
,SUM(CASE WHEN c.SEC_CL_CD = '002'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (2)
			         THEN 1
					 ELSE 0
					 END
	) as TRD_ITMS_SA_SELL                          --交易笔数_深A主板_卖出

,SUM(CASE WHEN c.SEC_CL_CD = '002'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (3)
			         THEN 1
					 ELSE 0
					 END
	) as TRD_ITMS_SA_PRCH                          --交易笔数_深A主板_申购

,SUM(CASE WHEN c.SEC_CL_CD = '003'
		             --AND a.SYS_SRC = '信用账户'
		   AND  c.BS_DRCT IN (1)
		   THEN 1
		   ELSE 0
		   END
	) as TRD_ITMS_SMS_BUYIN                          --交易笔数_中小板_买入	
,SUM(CASE WHEN c.SEC_CL_CD = '003'
		             --AND a.SYS_SRC = '信用账户'
		   AND  c.BS_DRCT IN (2)
		   THEN 1
		   ELSE 0
		   END
	) as TRD_ITMS_SMS_SELL                         --交易笔数_中小板_卖出		
,SUM(CASE WHEN c.SEC_CL_CD = '003'
		             --AND a.SYS_SRC = '信用账户'
		   AND  c.BS_DRCT IN (3)
		   THEN 1
		   ELSE 0
		   END
	) as TRD_ITMS_SMS_PRCH                         --交易笔数_中小板_申购	
,SUM(CASE WHEN c.SEC_CL_CD = '004'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_GEM_BUYIN                         --交易笔数_创业板_买入
,SUM(CASE WHEN c.SEC_CL_CD = '004'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (2)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_GEM_SELL                         --交易笔数_创业板_卖出
,SUM(CASE WHEN c.SEC_CL_CD = '004'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (3)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_GEM_PRCH                         --交易笔数_创业板_申购
 ,SUM(CASE WHEN c.SEC_CL_CD = '012'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_STIB_AK_BUYIN                                 --交易笔数_AK科创板_买入
 ,SUM(CASE WHEN c.SEC_CL_CD = '012'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (2)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_STIB_AK_SELL                                 --交易笔数_AK科创板_卖出
 ,SUM(CASE WHEN c.SEC_CL_CD = '012'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (3)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_STIB_AK_PRCH                                 --交易笔数_AK科创板_申购
 ,SUM(CASE WHEN c.SEC_CL_CD = '013'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (1)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_STIB_RK_BUYIN                                 --交易笔数_RK科创CDR_买入
,SUM(CASE WHEN c.SEC_CL_CD = '013'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (2)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_STIB_RK_SELL                                 --交易笔数_RK科创CDR_卖出					 
,SUM(CASE WHEN c.SEC_CL_CD = '013'
		             --AND a.SYS_SRC = '信用账户'
		             AND  c.BS_DRCT IN (3)
			         THEN 1
					 ELSE 0
					 END
					 ) as TRD_ITMS_STIB_RK_PRCH                                 --交易笔数_RK科创CDR_申购					 
					 
,SUM(CASE WHEN c.SEC_CL_CD = '005'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_HB_BUYIN                     --普通账户交易笔数_沪B_买入
,SUM(CASE WHEN c.SEC_CL_CD = '005'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_HB_SELL                     --普通账户交易笔数_沪B_卖出
,SUM(CASE WHEN c.SEC_CL_CD = '063'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_SB_BUYIN                     --普通账户交易笔数_深B_买入
,SUM(CASE WHEN c.SEC_CL_CD = '063'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_SB_SELL                     --普通账户交易笔数_深B_卖出
,SUM(CASE WHEN c.SEC_CL_CD = '015'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_HK_BUYIN                     --普通账户交易笔数_沪港通_买入
           ,SUM(CASE WHEN c.SEC_CL_CD = '016'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_SK_BUYIN                     --普通账户交易笔数_深港通_买入
,SUM(CASE WHEN c.SEC_CL_CD = '015'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_HK_SELL                     --普通账户交易笔数_沪港通_卖出
           ,SUM(CASE WHEN c.SEC_CL_CD = '016'
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_SK_SELL                     --普通账户交易笔数_深港通_卖出
 ,SUM(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_EXG_FND_BUYIN                --普通账户交易笔数_场内基金_买入
 ,SUM(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (2)
			         THEN 1
					 ELSE 0
					 END
					 ) as ORDI_TRD_ITMS_EXG_FND_SELL                --普通账户交易笔数_场内基金_卖出					 
,SUM(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
		             AND a.SYS_SRC = '普通账户'
		             AND  c.BS_DRCT IN (1)
			         THEN 1
					 ELSE 0
					 END
					 ) as CRD_TRD_ITMS_EXG_FND_BUYIN                --信用账户交易笔数_场内基金_买入
 ,SUM(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
		   AND a.SYS_SRC = '普通账户'
		   AND  c.BS_DRCT IN (2)
		   THEN 1
		   ELSE 0
		   END
	) as CRD_TRD_ITMS_EXG_FND_SELL                --信用账户交易笔数_场内基金_卖出					 
					 
					 
					 
					 
		 
                    

				 
  FROM        DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS                 a
 LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH                             b
 ON             a.CCY_CD = b.BZDM
 AND            b.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN    DDW_PROD.T_DDW_CFG_SEC_TRD_CL                      c
 ON             a.EXG = c.EXG
 AND            SUBSTR(a.SEC_CD,1,3) = c.SEC_CD_PFX
 AND            (SUBSTR(a.SEC_CGY,1,1) = c.SEC_CGY_PFX
 OR             SUBSTR(a.SEC_CGY,1,3) = c.SEC_CGY_PFX)
 AND            a.ODR_CGY = c.TRD_CGY
 LEFT JOIN (SELECT JYS,JJDM FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS WHERE BUS_DATE = %d{yyyyMMdd} AND JSRQ = 99999999) d
 ON        a.SEC_CD = d.JJDM
 AND       a.EXG = d.JYS
 WHERE         a.BUS_DATE = %d{yyyyMMdd}
 GROUP BY  a.CUST_NO  ;					 
---期权
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP4 ;
   CREATE TABLE DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP4 as
   SELECT  CUST_NO
           ,SUM(MTCH_QTY)                            as WRNT_TRD_CNTS                       --期权账户交易张数
		   ,SUM(MTCH_AMT)                            as WRNT_TRD_VOL                        --期权账户交易量
           ,SUM(S1)                                  as WRNT_S1_INCM                        --期权账户佣金收入
		   ,SUM(S1-s11-s15)                          as WRNT_NET_S1_INCM                    --期权账户净佣金收入
		   ,SUM(S1+S2+S3+S4+S5+S6)                   as WRNT_TRD_FEE                        --期权账户交易费用
		   ,SUM(DECODE(wrnt_bs_drct,'1',1,'2',1,0))  as WRNT_TRD_ITMS                       --期权账户交易笔数
		   ,SUM(DECODE(wrnt_bs_drct,'1',mtch_amt,0)) as WRNT_TRD_VOL_BUYIN                  --期权账户交易量_买入
		   ,SUM(DECODE(wrnt_bs_drct,'2',mtch_amt,0)) as WRNT_TRD_VOL_SELL                   --期权账户交易量_卖出
		   ,SUM(DECODE(wrnt_bs_drct,'1',MTCH_QTY,0)) as WRNT_TRD_CNTS_BUYIN                 --期权账户交易张数_买入
		   ,SUM(DECODE(wrnt_bs_drct,'2',MTCH_QTY,0)) as WRNT_TRD_CNTS_SELL                  --期权账户交易张数_卖出
		   ,sum(CASE WHEN wrnt_bs_drct = '1' 
		         AND  wrnt_opn_cp_flg = 'O'
				 THEN mtch_amt
				 ELSE 0
				 END)                                  as WRNT_TRD_VOL_BUYIN_O               --期权账户交易量_买入_开仓
		   ,SUM(CASE WHEN wrnt_bs_drct = '1' 
		         AND  wrnt_opn_cp_flg = 'C'
				 THEN mtch_amt
				 ELSE 0
				 END)                                  as WRNT_TRD_VOL_BUYIN_C               --期权账户交易量_买入_平仓
		   ,SUM(CASE WHEN wrnt_bs_drct = '2' 
		         AND  wrnt_opn_cp_flg = 'O'
				 THEN mtch_amt
				 ELSE 0
				 END)                                  as WRNT_TRD_VOL_SELL_O               --期权账户交易量_卖出_开仓
		   ,SUM(CASE WHEN wrnt_bs_drct = '2' 
		         AND  wrnt_opn_cp_flg = 'C'
				 THEN mtch_amt
				 ELSE 0
				 END)                                  as WRNT_TRD_VOL_SELL_C               --期权账户交易量_卖出_平仓
			,SUM(CASE WHEN wrnt_bs_drct = '1' 
		         AND  wrnt_opn_cp_flg = 'O'
				 THEN MTCH_QTY
				 END)                                  as WRNT_TRD_CNTS_BUYIN_O               --期权账户交易张数_买入_开仓
		   ,SUM(CASE WHEN wrnt_bs_drct = '1' 
		         AND  wrnt_opn_cp_flg = 'C'
				 THEN MTCH_QTY
				 ELSE 0
				 END)                                  as WRNT_TRD_CNTS_BUYIN_C               --期权账户交易张数_买入_平仓
		   ,SUM(CASE WHEN wrnt_bs_drct = '2' 
		         AND  wrnt_opn_cp_flg = 'O'
				 THEN MTCH_QTY
				 ELSE 0
				 END)                                  as WRNT_TRD_CNTS_SELL_O               --期权账户交易张数_卖出_开仓
		   ,SUM(CASE WHEN wrnt_bs_drct = '2' 
		         AND  wrnt_opn_cp_flg = 'C'
				 THEN MTCH_QTY
				 ELSE 0
				 END)                                  as WRNT_TRD_CNTS_SELL_C               --期权账户交易张数_卖出_平仓
           ,SUM(DECODE(EXG,'SH',MTCH_QTY,0))         as WRNT_TRD_CNTS_SH        --期权账户交易张数(SH)
		   ,SUM(DECODE(EXG,'SH',MTCH_AMT,0))         as WRNT_TRD_VOL_SH                        --期权账户交易量(SH)
           ,SUM(DECODE(EXG,'SH',S1,0))               as WRNT_S1_INCM_SH                        --期权账户佣金收入(SH)
		   ,SUM(DECODE(EXG,'SH',S1-s11-s15,0))       as WRNT_NET_S1_INCM_SH                    --期权账户净佣金收入(SH)
		   ,SUM(DECODE(EXG,'SH',S1+S2+S3+S4+S5+S6,0))as WRNT_TRD_FEE_SH                        --期权账户交易费用(SH)
		   ,SUM(CASE WHEN EXG = 'SH'
		             AND wrnt_bs_drct = '1'
					 THEN 1
					 WHEN EXG = 'SH'
		             AND wrnt_bs_drct = '2'
					 THEN 1
					 ELSE 0
					 END)                            as WRNT_TRD_ITMS_SH                       --期权账户交易笔数(SH)
		    ,SUM(CASE WHEN EXG = 'SH'
		             AND wrnt_bs_drct = '1'
					 THEN MTCH_AMT					
					 ELSE 0
					 END)                           as WRNT_TRD_VOL_BUYIN_SH                  --期权账户交易量_买入(SH)
            ,SUM(CASE WHEN EXG = 'SH'
		             AND wrnt_bs_drct = '2'
					 THEN MTCH_AMT					
					 ELSE 0
					 END)  as WRNT_TRD_VOL_SELL_SH                   --期权账户交易量_卖出(SH)
			,SUM(CASE WHEN EXG = 'SH'
		             AND wrnt_bs_drct = '1'
					 THEN MTCH_QTY					
					 ELSE 0
					 END) as  WRNT_TRD_CNTS_BUYIN_SH                 --期权账户交易张数_买入(SH)
			,SUM(CASE WHEN EXG = 'SH'
		             AND wrnt_bs_drct = '2'
					 THEN MTCH_QTY					
					 ELSE 0
					 END)	 as WRNT_TRD_CNTS_SELL_SH                  --期权账户交易张数_卖出(SH)	 
					 
		  
		   ,sum(CASE WHEN wrnt_bs_drct = '1' 
		         AND  wrnt_opn_cp_flg = 'O'
				 and  EXG = 'SH'
				 THEN mtch_amt
				 ELSE 0
				 END)                                  as WRNT_TRD_VOL_BUYIN_O_SH               --期权账户交易量_买入_开仓(SH)
		   ,SUM(CASE WHEN wrnt_bs_drct = '1' 
		         AND  wrnt_opn_cp_flg = 'C'
				 AND EXG = 'SH'
				 THEN mtch_amt
				 ELSE 0
				 END)                                  as WRNT_TRD_VOL_BUYIN_C_SH               --期权账户交易量_买入_平仓(SH)
		   ,SUM(CASE WHEN wrnt_bs_drct = '2' 
		         AND  wrnt_opn_cp_flg = 'O'
				  AND EXG = 'SH'
				 THEN mtch_amt
				 ELSE 0
				 END)                                  as WRNT_TRD_VOL_SELL_O_SH               --期权账户交易量_卖出_开仓(SH)
		   ,SUM(CASE WHEN wrnt_bs_drct = '2' 
		         AND  wrnt_opn_cp_flg = 'C'
				  AND EXG = 'SH'
				 THEN mtch_amt
				 ELSE 0
				 END)                                  as WRNT_TRD_VOL_SELL_C_SH               --期权账户交易量_卖出_平仓(SH)
			,SUM(CASE WHEN wrnt_bs_drct = '1' 
		         AND  wrnt_opn_cp_flg = 'O'
				  AND EXG = 'SH'
				 THEN MTCH_QTY
				 END)                                  as WRNT_TRD_CNTS_BUYIN_O_SH               --期权账户交易张数_买入_开仓(SH)
		   ,SUM(CASE WHEN wrnt_bs_drct = '1' 
		         AND  wrnt_opn_cp_flg = 'C'
				  AND EXG = 'SH'
				 THEN MTCH_QTY
				 ELSE 0
				 END)                                  as WRNT_TRD_CNTS_BUYIN_C_SH               --期权账户交易张数_买入_平仓(SH)
		   ,SUM(CASE WHEN wrnt_bs_drct = '2' 
		         AND  wrnt_opn_cp_flg = 'O'
				  AND EXG = 'SH'
				 THEN MTCH_QTY
				 ELSE 0
				 END)                                  as WRNT_TRD_CNTS_SELL_O_SH               --期权账户交易张数_卖出_开仓(SH)
		   ,SUM(CASE WHEN wrnt_bs_drct = '2' 
		         AND  wrnt_opn_cp_flg = 'C'
				  AND EXG = 'SH'
				 THEN MTCH_QTY
				 ELSE 0
				 END)                                  as WRNT_TRD_CNTS_SELL_C_SH               --期权账户交易张数_卖出_平仓(SH)
		   ,SUM(DECODE(EXG,'SZ',MTCH_QTY,0))         as WRNT_TRD_CNTS_SZ        --期权账户交易张数(SZ)
		   ,SUM(DECODE(EXG,'SZ',MTCH_AMT,0))         as WRNT_TRD_VOL_SZ                        --期权账户交易量(SZ)
           ,SUM(DECODE(EXG,'SZ',S1,0))               as WRNT_S1_INCM_SZ                        --期权账户佣金收入(SZ)
		   ,SUM(DECODE(EXG,'SZ',S1-s11-s15,0))       as WRNT_NET_S1_INCM_SZ                    --期权账户净佣金收入(SZ)
		   ,SUM(DECODE(EXG,'SZ',S1+S2+S3+S4+S5+S6,0))as WRNT_TRD_FEE_SZ                        --期权账户交易费用(SZ)
		   ,SUM(CASE WHEN EXG = 'SZ'
		             AND wrnt_bs_drct = '1'
					 THEN 1
					 WHEN EXG = 'SZ'
		             AND wrnt_bs_drct = '2'
					 THEN 1
					 ELSE 0
					 END)                            as WRNT_TRD_ITMS_SZ                       --期权账户交易笔数(SZ)
		    ,SUM(CASE WHEN EXG = 'SZ'
		             AND wrnt_bs_drct = '1'
					 THEN MTCH_AMT					
					 ELSE 0
					 END)                           as WRNT_TRD_VOL_BUYIN_SZ                  --期权账户交易量_买入(SZ)
            ,SUM(CASE WHEN EXG = 'SZ'
		             AND wrnt_bs_drct = '2'
					 THEN MTCH_AMT					
					 ELSE 0
					 END)  as WRNT_TRD_VOL_SELL_SZ                   --期权账户交易量_卖出(SZ)
			,SUM(CASE WHEN EXG = 'SZ'
		             AND wrnt_bs_drct = '1'
					 THEN MTCH_QTY					
					 ELSE 0
					 END) as  WRNT_TRD_CNTS_BUYIN_SZ                 --期权账户交易张数_买入(SZ)
			,SUM(CASE WHEN EXG = 'SZ'
		             AND wrnt_bs_drct = '2'
					 THEN MTCH_QTY					
					 ELSE 0
					 END)	 as WRNT_TRD_CNTS_SELL_SZ                  --期权账户交易张数_卖出(SZ)	 
					 
		  
		   ,sum(CASE WHEN wrnt_bs_drct = '1' 
		         AND  wrnt_opn_cp_flg = 'O'
				 and  EXG = 'SZ'
				 THEN mtch_amt
				 ELSE 0
				 END)                                  as WRNT_TRD_VOL_BUYIN_O_SZ               --期权账户交易量_买入_开仓(SZ)
		   ,SUM(CASE WHEN wrnt_bs_drct = '1' 
		         AND  wrnt_opn_cp_flg = 'C'
				 AND EXG = 'SZ'
				 THEN mtch_amt
				 ELSE 0
				 END)                                  as WRNT_TRD_VOL_BUYIN_C_SZ               --期权账户交易量_买入_平仓(SZ)
		   ,SUM(CASE WHEN wrnt_bs_drct = '2' 
		         AND  wrnt_opn_cp_flg = 'O'
				  AND EXG = 'SZ'
				 THEN mtch_amt
				 ELSE 0
				 END)                                  as WRNT_TRD_VOL_SELL_O_SZ               --期权账户交易量_卖出_开仓(SZ)
		   ,SUM(CASE WHEN wrnt_bs_drct = '2' 
		         AND  wrnt_opn_cp_flg = 'C'
				  AND EXG = 'SZ'
				 THEN mtch_amt
				 ELSE 0
				 END)                                  as WRNT_TRD_VOL_SELL_C_SZ               --期权账户交易量_卖出_平仓(SZ)
			,SUM(CASE WHEN wrnt_bs_drct = '1' 
		         AND  wrnt_opn_cp_flg = 'O'
				  AND EXG = 'SZ'
				 THEN MTCH_QTY
				 END)                                  as WRNT_TRD_CNTS_BUYIN_O_SZ               --期权账户交易张数_买入_开仓(SZ)
		   ,SUM(CASE WHEN wrnt_bs_drct = '1' 
		         AND  wrnt_opn_cp_flg = 'C'
				  AND EXG = 'SZ'
				 THEN MTCH_QTY
				 ELSE 0
				 END)                                  as WRNT_TRD_CNTS_BUYIN_C_SZ               --期权账户交易张数_买入_平仓(SZ)
		   ,SUM(CASE WHEN wrnt_bs_drct = '2' 
		         AND  wrnt_opn_cp_flg = 'O'
				  AND EXG = 'SZ'
				 THEN MTCH_QTY
				 ELSE 0
				 END)                                  as WRNT_TRD_CNTS_SELL_O_SZ               --期权账户交易张数_卖出_开仓(SZ)
		   ,SUM(CASE WHEN wrnt_bs_drct = '2' 
		         AND  wrnt_opn_cp_flg = 'C'
				  AND EXG = 'SZ'
				 THEN MTCH_QTY
				 ELSE 0
				 END)                                  as WRNT_TRD_CNTS_SELL_C_SZ               --期权账户交易张数_卖出_平仓(SZ)	 
		 
   FROM    DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
   WHERE   BUS_DATE = %d{yyyyMMdd}
   GROUP BY  CUST_NO  ;	
--客户交易收入表
INSERT OVERWRITE DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
(        CUST_NO                                     --客户号                 
        ,BRH_NO                                      --营业部编号                         
        ,CUST_CGY			                         --客户类别
		,CRD_MRGNC_MRGNS_PRDCT_INT                   --信用账户融资融券预计利息    
        ,CRD_MRGNC_MRGNS_RTN_INT                     --信用账户融资融券归还利息
		,ORDI_PLG_REPO_PRDCT_INT                     --普通账户质押回购预计利息
        ,ORDI_PLG_REPO_RTN_INT                       --普通账户质押回购归还利息
		,ORDI_S1_INCM_RMB                            --普通账户佣金收入(人民币)
        ,CRD_S1_INCM                                 --信用账户佣金收入
        ,ORDI_S1_INCM_OTH_RMB                        --普通账户佣金收入_其他(包括权证等)
        ,S1_INCM_HA                                  --佣金收入_沪A主板
        ,ORDI_S1_INCM_HA                             --普通账户佣金收入_沪A主板
        ,CRD_S1_INCM_HA                              --信用账户佣金收入_沪A主板
        ,S1_INCM_SA                                  --佣金收入_深A主板
        ,ORDI_S1_INCM_SA                             --普通账户佣金收入_深A主板
        ,CRD_S1_INCM_SA                              --信用账户佣金收入_深A主板
        ,S1_INCM_SMS                                 --佣金收入_中小板
        ,ORDI_S1_INCM_SMS                            --普通账户佣金收入_中小板
        ,CRD_S1_INCM_SMS                             --信用账户佣金收入_中小板
        ,S1_INCM_GEM                                 --佣金收入_创业板
        ,ORDI_S1_INCM_GEM                            --普通账户佣金收入_创业板
        ,CRD_S1_INCM_GEM                             --信用账户佣金收入_创业板
        ,ORDI_S1_INCM_HB_USD                         --普通账户佣金收入_沪B_美元
        ,ORDI_S1_INCM_SB_HKD                         --普通账户佣金收入_深B_港币
        ,ORDI_S1_INCM_HK                             --普通账户佣金收入_沪港通
        ,ORDI_S1_INCM_SK                             --普通账户佣金收入_深港通
        ,ORDI_S1_INCM_TA                             --普通账户佣金收入_三板A股
        ,ORDI_S1_INCM_TU_USD                         --普通账户佣金收入_三板B股_美元
        ,ORDI_S1_INCM_REPO                           --普通账户佣金收入_回购
        ,ORDI_S1_INCM_EXG_FND                        --普通账户佣金收入_场内基金收入
        ,ORDI_S1_INCM_CLS_FND                        --普通账户佣金收入_封闭式基金
        ,ORDI_S1_INCM_ETF_FND                        --普通账户佣金收入_ETF
        ,ORDI_S1_INCM_OPN_FND                        --普通账户佣金收入_开放式
        ,ORDI_S1_INCM_LOF_FND                        --普通账户佣金收入_LOF
        ,ORDI_S1_INCM_FOF_FND                        --普通账户佣金收入_FOF
        ,CRD_S1_INCM_EXG_FND                         --信用账户佣金收入_场内基金收入
        ,CRD_S1_INCM_CLS_FND                         --信用账户佣金收入_封闭式基金
        ,CRD_S1_INCM_ETF_FND                         --信用账户佣金收入_ETF
        ,CRD_S1_INCM_OPN_FND                         --信用账户佣金收入_开放式
        ,CRD_S1_INCM_LOF_FND                         --信用账户佣金收入_LOF
        ,CRD_S1_INCM_FOF_FND                         --信用账户佣金收入_FOF
        ,ORDI_S1_INCM_BOND                           --普通账户佣金收入_债券
        ,CRD_S1_INCM_BOND                            --信用账户佣金收入_债券
        ,ORDI_NET_S1_INCM_RMB                        --普通账户净佣金收入(人民币)
        ,CRD_NET_S1_INCM                             --信用账户净佣金收入
        ,ORDI_NET_S1_INCM_OTH_RMB                    --普通账户净佣金收入_其他(包括权证等)
        ,NET_S1_INCM_HA                              --净佣金收入_沪A主板
        ,ORDI_NET_S1_INCM_HA                         --普通账户净佣金收入_沪A主板
        ,CRD_NET_S1_INCM_HA                          --信用账户净佣金收入_沪A主板
        ,NET_S1_INCM_SA                              --净佣金收入_深A主板
        ,ORDI_NET_S1_INCM_SA                         --普通账户净佣金收入_深A主板
        ,CRD_NET_S1_INCM_SA                          --信用账户净佣金收入_深A主板
        ,NET_S1_INCM_SMS                             --净佣金收入_中小板
        ,ORDI_NET_S1_INCM_SMS                        --普通账户净佣金收入_中小板
        ,CRD_NET_S1_INCM_SMS                         --信用账户净佣金收入_中小板
        ,NET_S1_INCM_GEM                             --净佣金收入_创业板
        ,ORDI_NET_S1_INCM_GEM                        --普通账户净佣金收入_创业板
        ,CRD_NET_S1_INCM_GEM                         --信用账户净佣金收入_创业板
        ,ORDI_NET_S1_INCM_HB_USD                     --普通账户净佣金收入_沪B_美元
        ,ORDI_NET_S1_INCM_SB_HKD                     --普通账户净佣金收入_深B_港币
        ,ORDI_NET_S1_INCM_HK                         --普通账户净佣金收入_沪港通
        ,ORDI_NET_S1_INCM_SK                         --普通账户净佣金收入_深港通
        ,ORDI_NET_S1_INCM_TA                         --普通账户净佣金收入_三板A股
        ,ORDI_NET_S1_INCM_TU_USD                     --普通账户净佣金收入_三板B股_美元
        ,ORDI_NET_S1_INCM_REPO                       --普通账户净佣金收入_回购
        ,ORDI_NET_S1_INCM_EXG_FND                    --普通账户净佣金收入_场内基金收入
        ,ORDI_NET_S1_INCM_CLS_FND                    --普通账户净佣金收入_封闭式基金
        ,ORDI_NET_S1_INCM_ETF_FND                    --普通账户净佣金收入_ETF
        ,ORDI_NET_S1_INCM_OPN_FND                    --普通账户净佣金收入_开放式
        ,ORDI_NET_S1_INCM_LOF_FND                    --普通账户净佣金收入_LOF
        ,ORDI_NET_S1_INCM_FOF_FND                    --普通账户净佣金收入_FOF
        ,CRD_NET_S1_INCM_EXG_FND                     --信用账户净佣金收入_场内基金收入
        ,CRD_NET_S1_INCM_CLS_FND                     --信用账户净佣金收入_封闭式基金
        ,CRD_NET_S1_INCM_ETF_FND                     --信用账户净佣金收入_ETF
        ,CRD_NET_S1_INCM_OPN_FND                     --信用账户净佣金收入_开放式
        ,CRD_NET_S1_INCM_LOF_FND                     --信用账户净佣金收入_LOF
        ,CRD_NET_S1_INCM_FOF_FND                     --信用账户净佣金收入_FOF
        ,ORDI_NET_S1_INCM_BOND                       --普通账户净佣金收入_债券
        ,CRD_NET_S1_INCM_BOND                        --信用账户净佣金收入_债券	
        ,ORDI_TRD_FEE_RMB                            --普通账户交易费用(人民币)
        ,CRD_TRD_FEE                                 --信用账户交易费用
        ,ORDI_TRD_FEE_OTH_RMB                        --普通账户交易费用_其他(包括权证等)
        ,TRD_FEE_HA                                  --交易费用_沪A主板
        ,ORDI_TRD_FEE_HA                             --普通账户交易费用_沪A主板
        ,CRD_TRD_FEE_HA                              --信用账户交易费用_沪A主板
        ,TRD_FEE_SA                                  --交易费用_深A主板
        ,ORDI_TRD_FEE_SA                             --普通账户交易费用_深A主板
        ,CRD_TRD_FEE_SA                              --信用账户交易费用_深A主板
        ,TRD_FEE_SMS                                 --交易费用_中小板
        ,ORDI_TRD_FEE_SMS                            --普通账户交易费用_中小板
        ,CRD_TRD_FEE_SMS                             --信用账户交易费用_中小板
        ,TRD_FEE_GEM                                 --交易费用_创业板
        ,ORDI_TRD_FEE_GEM                            --普通账户交易费用_创业板
        ,CRD_TRD_FEE_GEM                             --信用账户交易费用_创业板
        ,ORDI_TRD_FEE_HB_USD                         --普通账户交易费用_沪B_美元
        ,ORDI_TRD_FEE_SB_HKD                         --普通账户交易费用_深B_港币
        ,ORDI_TRD_FEE_HK                             --普通账户交易费用_沪港通
        ,ORDI_TRD_FEE_SK                             --普通账户交易费用_深港通
        ,ORDI_TRD_FEE_TA                             --普通账户交易费用_三板A股
        ,ORDI_TRD_FEE_TU_USD                         --普通账户交易费用_三板B股_美元
        ,ORDI_TRD_FEE_REPO                           --普通账户交易费用_回购
        ,ORDI_TRD_FEE_EXG_FND                        --普通账户交易费用_场内基金
        ,ORDI_TRD_FEE_CLS_FND                        --普通账户交易费用_封闭式基金
        ,ORDI_TRD_FEE_ETF_FND                        --普通账户交易费用_ETF
        ,ORDI_TRD_FEE_OPN_FND                        --普通账户交易费用_开放式
        ,ORDI_TRD_FEE_LOF_FND                        --普通账户交易费用_LOF
        ,ORDI_TRD_FEE_FOF_FND                        --普通账户交易费用_FOF
        ,CRD_TRD_FEE_EXG_FND                         --信用账户交易费用_场内基金
        ,CRD_TRD_FEE_CLS_FND                         --信用账户交易费用_封闭式基金
        ,CRD_TRD_FEE_ETF_FND                         --信用账户交易费用_ETF
        ,CRD_TRD_FEE_OPN_FND                         --信用账户交易费用_开放式
        ,CRD_TRD_FEE_LOF_FND                         --信用账户交易费用_LOF
        ,CRD_TRD_FEE_FOF_FND                         --信用账户交易费用_FOF
        ,ORDI_TRD_FEE_BOND                           --普通账户交易费用_债券
        ,CRD_TRD_FEE_BOND                            --信用账户交易费用_债券					 
        ,PROD_CMSN_FEE                               --产品手续费
        ,AGN_FND_CMSN_FEE                            --代销基金手续费
        ,GS_PROD_CMSN_FEE                            --公司产品手续费
        ,GJ_PROD_CMSN_FEE                            --国君产品手续费
        ,OTC_PROD_CMSN_FEE                           --OTC产品手续费
        ,PROD_SCRP_AMT                               --产品认购金额		
        ,PROD_PRCH_AMT                               --产品申购金额	
        ,PROD_FIXINV_AMT                             --产品定投金额	
        ,PROD_RDMPT_AMT                              --产品赎回金额
        ,AGN_FND_SCRP_AMT                            --代销基金认购金额
        ,AGN_FND_PRCH_AMT                            --代销基金申购金额
        ,AGN_FND_FIXINV_AMT                          --代销基金定投金额
        ,AGN_FND_RDMPT_AMT                           --代销基金赎回金额
        ,GS_PROD_SCRP_AMT                            --公司产品认购金额
        ,GS_PROD_PRCH_AMT                            --公司产品申购金额
        ,GS_PROD_FIXINV_AMT                          --公司产品定投金额
        ,GS_PROD_RDMPT_AMT                           --公司产品赎回金额
        ,GJ_PROD_SCRP_AMT                            --国君产品认购金额
        ,GJ_PROD_PRCH_AMT                            --国君产品申购金额
        ,GJ_PROD_FIXINV_AMT                          --国君产品定投金额
        ,GJ_PROD_RDMPT_AMT                           --国君产品赎回金额
        ,BANK_PROD_SCRP_AMT                          --银行产品认购金额
        ,BANK_PROD_PRCH_AMT                          --银行产品申购金额		
        ,BANK_PROD_RDMPT_AMT                         --银行产品赎回金额	
        ,OTC_PROD_SCRP_AMT                           --OTC产品认购金额
        ,OTC_PROD_PRCH_AMT                           --OTC产品申购金额		
        ,OTC_PROD_RDMPT_AMT                          --OTC产品赎回金额			
        ,AGN_FND_SCRP_ITMS                           --代销基金认购笔数
        ,AGN_FND_PRCH_ITMS                           --代销基金申购笔数
        ,AGN_FND_FIXINV_ITMS                         --代销基金定投笔数
        ,AGN_FND_RDMPT_ITMS                          --代销基金赎回笔数
        ,GS_PROD_SCRP_ITMS                           --公司产品认购笔数
        ,GS_PROD_PRCH_ITMS                           --公司产品申购笔数
        ,GS_PROD_FIXINV_ITMS                         --公司产品定投笔数
        ,GS_PROD_RDMPT_ITMS                          --公司产品赎回笔数
        ,GJ_PROD_SCRP_ITMS                           --国君产品认购笔数
        ,GJ_PROD_PRCH_ITMS                           --国君产品申购笔数
        ,GJ_PROD_FIXINV_ITMS                         --国君产品定投笔数
        ,GJ_PROD_RDMPT_ITMS                          --国君产品赎回笔数
        ,BANK_PROD_SCRP_ITMS                         --银行产品认购笔数
        ,BANK_PROD_PRCH_ITMS                         --银行产品申购笔数		
        ,BANK_PROD_RDMPT_ITMS                        --银行产品赎回笔数
        ,OTC_PROD_SCRP_ITMS                          --OTC产品认购笔数
        ,OTC_PROD_PRCH_ITMS                          --OTC产品申购笔数		
        ,OTC_PROD_RDMPT_ITMS                         --OTC产品赎回笔数			 
        ,ORDI_TRD_VOL_RMB                            --普通账户交易量(人民币)
        ,ORDI_TRD_VOL_RMB_80                         --普通账户交易量(人民币)(不包含申购交易量)			
        ,ORDI_TRD_VOL_RMB_BUYIN                      --普通账户交易量(人民币)_买入
        ,ORDI_TRD_VOL_RMB_SELL                       --普通账户交易量(人民币)_卖出
        ,ORDI_TRD_VOL_RMB_PRCH                       --普通账户交易量(人民币)_申购
        ,CRD_TRD_VOL                                 --信用账户交易量
        ,CRD_TRD_VOL_80                              --信用账户交易量(不包含申购交易量)
        ,CRD_TRD_VOL_BUYIN                           --信用账户交易量_买入
        ,CRD_TRD_VOL_SELL                            --信用账户交易量_卖出
        ,CRD_TRD_VOL_PRCH                            --信用账户交易量_申购
        ,ORDI_TRD_VOL_OTH_RMB                        --普通账户交易量_其他(包括权证等)
        ,ORDI_TRD_VOL_OTH_RMB_BUYIN                  --普通账户交易量_其他(包括权证等)_买入
        ,ORDI_TRD_VOL_OTH_RMB_SELL                   --普通账户交易量_其他(包括权证等)_卖出
        ,TRD_VOL_HA                                  --交易量_沪A主板
        ,TRD_VOL_HA_80                               --交易量_沪A主板(不包含申购交易量)
        ,TRD_VOL_HA_BUYIN                            --交易量_沪A主板_买入
        ,TRD_VOL_HA_SELL                             --交易量_沪A主板_卖出
        ,TRD_VOL_HA_PRCH                             --交易量_沪A主板_申购
        ,ORDI_TRD_VOL_HA                             --普通账户交易量_沪A主板
        ,ORDI_TRD_VOL_HA_80                          --普通账户交易量_沪A主板(不包含申购交易量)
        ,ORDI_TRD_VOL_HA_BUYIN                       --普通账户交易量_沪A主板_买入
        ,ORDI_TRD_VOL_HA_SELL                        --普通账户交易量_沪A主板_卖出
        ,ORDI_TRD_VOL_HA_PRCH                        --普通账户交易量_沪A主板_申购
        ,CRD_TRD_VOL_HA                              --信用账户交易量_沪A主板
        ,CRD_TRD_VOL_HA_80                           --信用账户交易量_沪A主板(不包含申购交易量)
        ,CRD_TRD_VOL_HA_BUYIN                        --信用账户交易量_沪A主板_买入
        ,CRD_TRD_VOL_HA_SELL                         --信用账户交易量_沪A主板_卖出
        ,CRD_TRD_VOL_HA_PRCH                         --信用账户交易量_沪A主板_申购
        ,TRD_VOL_SA                                  --交易量_深A主板
        ,TRD_VOL_SA_80                               --交易量_深A主板(不包含申购交易量)
        ,TRD_VOL_SA_BUYIN                            --交易量_深A主板_买入
        ,TRD_VOL_SA_SELL                             --交易量_深A主板_卖出
        ,TRD_VOL_SA_PRCH                             --交易量_深A主板_申购
        ,ORDI_TRD_VOL_SA                             --普通账户交易量_深A主板
        ,ORDI_TRD_VOL_SA_80                          --普通账户交易量_深A主板(不包含申购交易量)
        ,ORDI_TRD_VOL_SA_BUYIN                       --普通账户交易量_深A主板_买入
        ,ORDI_TRD_VOL_SA_SELL                        --普通账户交易量_深A主板_卖出
        ,ORDI_TRD_VOL_SA_PRCH                        --普通账户交易量_深A主板_申购
        ,CRD_TRD_VOL_SA                              --信用账户交易量_深A主板
        ,CRD_TRD_VOL_SA_80                           --信用账户交易量_深A主板(不包含申购交易量)
        ,CRD_TRD_VOL_SA_BUYIN                        --信用账户交易量_深A主板_买入
        ,CRD_TRD_VOL_SA_SELL                         --信用账户交易量_深A主板_卖出
        ,CRD_TRD_VOL_SA_PRCH                         --信用账户交易量_深A主板_申购
        ,TRD_VOL_SMS                                 --交易量_中小板
        ,TRD_VOL_SMS_80                              --交易量_中小板(不包含申购交易量)
        ,TRD_VOL_SMS_BUYIN                           --交易量_中小板_买入
        ,TRD_VOL_SMS_SELL                            --交易量_中小板_卖出
        ,TRD_VOL_SMS_PRCH                            --交易量_中小板_申购
        ,ORDI_TRD_VOL_SMS                            --普通账户交易量_中小板
        ,ORDI_TRD_VOL_SMS_80                         --普通账户交易量_中小板(不包含申购交易量)
        ,ORDI_TRD_VOL_SMS_BUYIN                      --普通账户交易量_中小板_买入
        ,ORDI_TRD_VOL_SMS_SELL                       --普通账户交易量_中小板_卖出
        ,ORDI_TRD_VOL_SMS_PRCH                       --普通账户交易量_中小板_申购
        ,CRD_TRD_VOL_SMS                             --信用账户交易量_中小板
        ,CRD_TRD_VOL_SMS_80                          --信用账户交易量_中小板(不包含申购交易量)
        ,CRD_TRD_VOL_SMS_BUYIN                       --信用账户交易量_中小板_买入
        ,CRD_TRD_VOL_SMS_SELL                        --信用账户交易量_中小板_卖出
        ,CRD_TRD_VOL_SMS_PRCH                        --信用账户交易量_中小板_申购
        ,TRD_VOL_GEM                                 --交易量_创业板
        ,TRD_VOL_GEM_80                              --交易量_创业板(不包含申购交易量)
        ,TRD_VOL_GEM_BUYIN                           --交易量_创业板_买入
        ,TRD_VOL_GEM_SELL                            --交易量_创业板_卖出
        ,TRD_VOL_GEM_PRCH                            --交易量_创业板_申购
        ,ORDI_TRD_VOL_GEM                            --普通账户交易量_创业板
        ,ORDI_TRD_VOL_GEM_80                         --普通账户交易量_创业板(不包含申购交易量)
        ,ORDI_TRD_VOL_GEM_BUYIN                      --普通账户交易量_创业板_买入
        ,ORDI_TRD_VOL_GEM_SELL                       --普通账户交易量_创业板_卖出
        ,ORDI_TRD_VOL_GEM_PRCH                       --普通账户交易量_创业板_申购
        ,CRD_TRD_VOL_GEM                             --信用账户交易量_创业板
        ,CRD_TRD_VOL_GEM_80                          --信用账户交易量_创业板(不包含申购交易量)
        ,CRD_TRD_VOL_GEM_BUYIN                       --信用账户交易量_创业板_买入
        ,CRD_TRD_VOL_GEM_SELL                        --信用账户交易量_创业板_卖出
        ,CRD_TRD_VOL_GEM_PRCH                        --信用账户交易量_创业板_申购
        ,ORDI_TRD_VOL_HB_USD                         --普通账户交易量_沪B_美元
        ,ORDI_TRD_VOL_HB_USD_BUYIN                   --普通账户交易量_沪B_美元_买入
        ,ORDI_TRD_VOL_HB_USD_SELL                    --普通账户交易量_沪B_美元_卖出
        ,ORDI_TRD_VOL_SB_HKD                         --普通账户交易量_深B_港币
        ,ORDI_TRD_VOL_SB_HKD_BUYIN                   --普通账户交易量_深B_港币_买入
        ,ORDI_TRD_VOL_SB_HKD_SELL                    --普通账户交易量_深B_港币_卖出
        ,ORDI_TRD_VOL_HK                             --普通账户交易量_沪港通
        ,ORDI_TRD_VOL_HK_BUYIN                       --普通账户交易量_沪港通_买入
        ,ORDI_TRD_VOL_HK_SELL                        --普通账户交易量_沪港通_卖出
        ,ORDI_TRD_VOL_SK                             --普通账户交易量_深港通
        ,ORDI_TRD_VOL_SK_BUYIN                       --普通账户交易量_深港通_买入
        ,ORDI_TRD_VOL_SK_SELL                        --普通账户交易量_深港通_卖出
        ,ORDI_TRD_VOL_TA                             --普通账户交易量_三板A股
        ,ORDI_TRD_VOL_TA_BUYIN                       --普通账户交易量_三板A股_买入
        ,ORDI_TRD_VOL_TA_SELL                        --普通账户交易量_三板A股_卖出
        ,ORDI_TRD_VOL_TU_USD                         --普通账户交易量_三板B股_美元
        ,ORDI_TRD_VOL_TU_USD_BUYIN                   --普通账户交易量_三板B股_美元_买入
        ,ORDI_TRD_VOL_TU_USD_SELL                    --普通账户交易量_三板B股_美元_卖出
        ,ORDI_TRD_VOL_REPO                           --普通账户交易量_回购
        ,ORDI_TRD_VOL_REPO_BUYIN                     --普通账户交易量_回购_买入
        ,ORDI_TRD_VOL_REPO_SELL                      --普通账户交易量_回购_卖出
        ,ORDI_TRD_VOL_EXG_FND                        --普通账户交易量_场内基金
        ,ORDI_TRD_VOL_EXG_FND_BUYIN                  --普通账户交易量_场内基金_买入
        ,ORDI_TRD_VOL_EXG_FND_SELL                   --普通账户交易量_场内基金_卖出
        ,ORDI_TRD_VOL_CLS_FND                        --普通账户交易量_封闭式基金
        ,ORDI_TRD_VOL_CLS_FND_BUYIN                  --普通账户交易量_封闭式基金_买入
        ,ORDI_TRD_VOL_CLS_FND_SELL                   --普通账户交易量_封闭式基金_卖出
        ,ORDI_TRD_VOL_ETF_FND                        --普通账户交易量_ETF
        ,ORDI_TRD_VOL_ETF_FND_BUYIN                  --普通账户交易量_ETF_买入
        ,ORDI_TRD_VOL_ETF_FND_SELL                   --普通账户交易量_ETF_卖出
        ,ORDI_TRD_VOL_OPN_FND                        --普通账户交易量_开放式
        ,ORDI_TRD_VOL_OPN_FND_BUYIN                  --普通账户交易量_开放式_买入
        ,ORDI_TRD_VOL_OPN_FND_SELL                   --普通账户交易量_开放式_卖出
        ,ORDI_TRD_VOL_LOF_FND                        --普通账户交易量_LOF
        ,ORDI_TRD_VOL_LOF_FND_BUYIN                  --普通账户交易量_LOF_买入
        ,ORDI_TRD_VOL_LOF_FND_SELL                   --普通账户交易量_LOF_卖出
        ,ORDI_TRD_VOL_FOF_FND                        --普通账户交易量_FOF
        ,ORDI_TRD_VOL_FOF_FND_BUYIN                  --普通账户交易量_FOF_买入
        ,ORDI_TRD_VOL_FOF_FND_SELL                   --普通账户交易量_FOF_卖出
        ,CRD_TRD_VOL_EXG_FND                         --信用账户交易量_场内基金
        ,CRD_TRD_VOL_EXG_FND_BUYIN                   --信用账户交易量_场内基金_买入
        ,CRD_TRD_VOL_EXG_FND_SELL                    --信用账户交易量_场内基金_卖出
        ,CRD_TRD_VOL_CLS_FND                         --信用账户交易量_封闭式基金
        ,CRD_TRD_VOL_CLS_FND_BUYIN                   --信用账户交易量_封闭式基金_买入
        ,CRD_TRD_VOL_CLS_FND_SELL                    --信用账户交易量_封闭式基金_卖出
        ,CRD_TRD_VOL_ETF_FND                         --信用账户交易量_ETF
        ,CRD_TRD_VOL_ETF_FND_BUYIN                   --信用账户交易量_ETF_买入
        ,CRD_TRD_VOL_ETF_FND_SELL                    --信用账户交易量_ETF_卖出
        ,CRD_TRD_VOL_OPN_FND                         --信用账户交易量_开放式
        ,CRD_TRD_VOL_OPN_FND_BUYIN                   --信用账户交易量_开放式_买入
        ,CRD_TRD_VOL_OPN_FND_SELL                    --信用账户交易量_开放式_卖出
        ,CRD_TRD_VOL_LOF_FND                         --信用账户交易量_LOF
        ,CRD_TRD_VOL_LOF_FND_BUYIN                   --信用账户交易量_LOF_买入
        ,CRD_TRD_VOL_LOF_FND_SELL                    --信用账户交易量_LOF_卖出
        ,CRD_TRD_VOL_FOF_FND                         --信用账户交易量_FOF
        ,CRD_TRD_VOL_FOF_FND_BUYIN                   --信用账户交易量_FOF_买入
        ,CRD_TRD_VOL_FOF_FND_SELL                    --信用账户交易量_FOF_卖出
        ,ORDI_TRD_VOL_BOND                           --普通账户交易量_债券
        ,ORDI_TRD_VOL_BOND_80                        --普通账户交易量_债券(不包含债券的申购)
        ,ORDI_TRD_VOL_BOND_BUYIN                     --普通账户交易量_债券_买入
        ,ORDI_TRD_VOL_BOND_SELL                      --普通账户交易量_债券_卖出
        ,ORDI_TRD_VOL_BOND_PRCH                      --普通账户交易量_债券_申购
        ,CRD_TRD_VOL_BOND                            --信用账户交易量_债券	
        ,CRD_TRD_VOL_BOND_80                         --信用账户交易量_债券(不包含债券的申购)	
        ,CRD_TRD_VOL_BOND_BUYIN                      --信用账户交易量_债券_买入
        ,CRD_TRD_VOL_BOND_SELL                       --信用账户交易量_债券_卖出
        ,CRD_TRD_VOL_BOND_PRCH                       --信用账户交易量_债券_申购
        ,ORDI_TRD_ITMS                               --普通账户交易笔数
        ,ORDI_TRD_ITMS_80                            --普通账户交易笔数(不包含申购的笔数)
        ,CRD_TRD_ITMS                                --信用账户交易笔数
        ,CRD_TRD_ITMS_80                             --信用账户交易笔数(不包含申购的笔数)
        ,ORDI_TRD_ITMS_OTH                           --普通账户交易笔数_其他(包括权证等)
        ,TRD_ITMS_HA                                 --交易笔数_沪A主板
        ,TRD_ITMS_HA_80                              --交易笔数_沪A主板(不包含申购的笔数)
        ,ORDI_TRD_ITMS_HA                            --普通账户交易笔数_沪A主板
        ,ORDI_TRD_ITMS_HA_80                         --普通账户交易笔数_沪A主板(不包含申购的笔数)
        ,CRD_TRD_ITMS_HA                             --信用账户交易笔数_沪A主板
        ,CRD_TRD_ITMS_HA_80                          --信用账户交易笔数_沪A主板(不包含申购的笔数)
        ,TRD_ITMS_SA                                 --交易笔数_深A主板
        ,TRD_ITMS_SA_80                              --交易笔数_深A主板(不包含申购的笔数)
        ,ORDI_TRD_ITMS_SA                            --普通账户交易笔数_深A主板
        ,ORDI_TRD_ITMS_SA_80                         --普通账户交易笔数_深A主板(不包含申购的笔数)
        ,CRD_TRD_ITMS_SA                             --信用账户交易笔数_深A主板
        ,TRD_ITMS_SMS                                --交易笔数_中小板
        ,TRD_ITMS_SMS_80                             --交易笔数_中小板(不包含申购的笔数)
        ,ORDI_TRD_ITMS_SMS                           --普通账户交易笔数_中小板
        ,ORDI_TRD_ITMS_SMS_80                        --普通账户交易笔数_中小板(不包含申购的笔数)
        ,CRD_TRD_ITMS_SMS                            --信用账户交易笔数_中小板
        ,CRD_TRD_ITMS_SMS_80                         --信用账户交易笔数_中小板(不包含申购的笔数)
        ,TRD_ITMS_GEM                                --交易笔数_创业板
        ,TRD_ITMS_GEM_80                             --交易笔数_创业板(不包含申购的笔数)
        ,ORDI_TRD_ITMS_GEM                           --普通账户交易笔数_创业板
        ,ORDI_TRD_ITMS_GEM_80                        --普通账户交易笔数_创业板(不包含申购的笔数)
        ,CRD_TRD_ITMS_GEM                            --信用账户交易笔数_创业板
        ,CRD_TRD_ITMS_GEM_80                         --信用账户交易笔数_创业板(不包含申购的笔数)
        ,ORDI_TRD_ITMS_HB                            --普通账户交易笔数_沪B
        ,ORDI_TRD_ITMS_SB                            --普通账户交易笔数_深B
        ,ORDI_TRD_ITMS_HK                            --普通账户交易笔数_沪港通
        ,ORDI_TRD_ITMS_SK                            --普通账户交易笔数_深港通
        ,ORDI_TRD_ITMS_TA                            --普通账户交易笔数_三板A股
        ,ORDI_TRD_ITMS_TU                            --普通账户交易笔数_三板B股
        ,ORDI_TRD_ITMS_REPO                          --普通账户交易笔数_回购
        ,ORDI_TRD_ITMS_EXG_FND                       --普通账户交易笔数_场内基金
        ,ORDI_TRD_ITMS_CLS_FND                       --普通账户交易笔数_封闭式基金
        ,ORDI_TRD_ITMS_ETF_FND                       --普通账户交易笔数_ETF
        ,ORDI_TRD_ITMS_OPN_FND                       --普通账户交易笔数_开放式
        ,ORDI_TRD_ITMS_LOF_FND                       --普通账户交易笔数_LOF
        ,ORDI_TRD_ITMS_FOF_FND                       --普通账户交易笔数_FOF
        ,CRD_TRD_ITMS_EXG_FND                        --信用账户交易笔数_场内基金
        ,CRD_TRD_ITMS_CLS_FND                        --信用账户交易笔数_封闭式基金
        ,CRD_TRD_ITMS_ETF_FND                        --信用账户交易笔数_ETF
        ,CRD_TRD_ITMS_OPN_FND                        --信用账户交易笔数_开放式
        ,CRD_TRD_ITMS_LOF_FND                        --信用账户交易笔数_LOF
        ,CRD_TRD_ITMS_FOF_FND                        --信用账户交易笔数_FOF
        ,ORDI_TRD_ITMS_BOND                          --普通账户交易笔数_债券
        ,ORDI_TRD_ITMS_BOND_80                       --普通账户交易笔数_债券(不包含债券申购)
        ,CRD_TRD_ITMS_BOND                           --信用账户交易笔数_债券	
        ,CRD_TRD_ITMS_BOND_80                        --信用账户交易笔数_债券(不包含债券申购)	
        ,WRNT_TRD_CNTS                               --期权账户交易张数
        ,WRNT_TRD_VOL                                --期权账户交易量
        ,WRNT_S1_INCM                                --期权账户佣金收入
        ,WRNT_NET_S1_INCM                            --期权账户净佣金收入
        ,WRNT_TRD_FEE                                --期权账户交易费用
        ,WRNT_TRD_ITMS                               --期权账户交易笔数
        ,WRNT_TRD_VOL_BUYIN                          --期权账户交易量_买入
        ,WRNT_TRD_VOL_SELL                           --期权账户交易量_卖出
        ,WRNT_TRD_CNTS_BUYIN                         --期权账户交易张数_买入
        ,WRNT_TRD_CNTS_SELL                          --期权账户交易张数_卖出
        ,WRNT_TRD_VOL_BUYIN_O                        --期权账户交易量_买入_开仓
        ,WRNT_TRD_VOL_BUYIN_C                        --期权账户交易量_买入_平仓
        ,WRNT_TRD_VOL_SELL_O                         --期权账户交易量_卖出_开仓
        ,WRNT_TRD_VOL_SELL_C                         --期权账户交易量_卖出_平仓
        ,WRNT_TRD_CNTS_BUYIN_O                       --期权账户交易张数_买入_开仓
        ,WRNT_TRD_CNTS_BUYIN_C                       --期权账户交易张数_买入_平仓
        ,WRNT_TRD_CNTS_SELL_O                        --期权账户交易张数_卖出_开仓
        ,WRNT_TRD_CNTS_SELL_C                        --期权账户交易张数_卖出_平仓
		,TOT_S1                                      --总佣金
		,TOT_NET_S1                                  --总净佣金
		,TOT_INCM_OFFER                              --总收入贡献
		,ORDI_S1_INCM_HB_RMB                         --普通账户佣金收入_沪B_人民币
		,ORDI_S1_INCM_SB_RMB                         --普通账户佣金收入_深B_人民币
		,ORDI_S1_INCM_TU_RMB                         --普通账户佣金收入_三板B股_人民币
		,ORDI_NET_S1_INCM_HB_RMB                     --普通账户净佣金收入_沪B_人民币
		,ORDI_NET_S1_INCM_SB_RMB                     --普通账户净佣金收入_深B_人民币
		,ORDI_NET_S1_INCM_TU_RMB                     --普通账户净佣金收入_三板B股_人民币
		,ORDI_TRD_FEE_HB_RMB                         --普通账户交易费用_沪B_人民币
		,ORDI_TRD_FEE_SB_RMB                         --普通账户交易费用_深B_人民币
		,ORDI_TRD_FEE_TU_RMB                         --普通账户交易费用_三板B股_人民币
		,ORDI_TRD_VOL_HB_RMB                         --普通账户交易量_沪B_人民币
		,ORDI_TRD_VOL_HB_RMB_BUYIN                   --普通账户交易量_沪B_人民币_买入
		,ORDI_TRD_VOL_HB_RMB_SELL                    --普通账户交易量_沪B_人民币_卖出
		,ORDI_TRD_VOL_SB_RMB                         --普通账户交易量_深B_人民币
		,ORDI_TRD_VOL_SB_RMB_BUYIN                   --普通账户交易量_深B_人民币_买入
		,ORDI_TRD_VOL_SB_RMB_SELL                    --普通账户交易量_深B_人民币_卖出
		,ORDI_TRD_VOL_TU_RMB                         --普通账户交易量_三板B股_人民币
		,ORDI_TRD_VOL_TU_RMB_BUYIN                   --普通账户交易量_三板B股_人民币_买入
		,ORDI_TRD_VOL_TU_RMB_SELL                    --普通账户交易量_三板B股_人民币_卖出
		,ORDI_S1_INCM_STIB_AK                             --普通账户佣金收入_AK科创板
		,CRD_S1_INCM_STIB_AK                              --信用账户佣金收入_AK科创板
		,S1_INCM_STIB_AK                                  --佣金收入_AK科创板
        ,ORDI_S1_INCM_STIB_RK                             --普通账户佣金收入_RK科创CDR
		,CRD_S1_INCM_STIB_RK                              --信用账户佣金收入_RK科创CDR
		,S1_INCM_STIB_RK                                  --佣金收入_RK科创CDR
		,ORDI_NET_S1_INCM_STIB_AK                         --普通账户净佣金收入_AK科创板
		,CRD_NET_S1_INCM_STIB_AK                          --信用账户净佣金收入_AK科创板
		,NET_S1_INCM_STIB_AK                              --净佣金收入_AK科创板
        ,ORDI_NET_S1_INCM_STIB_RK                         --普通账户净佣金收入_RK科创CDR
		,CRD_NET_S1_INCM_STIB_RK                          --信用账户净佣金收入_RK科创CDR
		,NET_S1_INCM_STIB_RK                              --净佣金收入_RK科创CDR
		,ORDI_TRD_FEE_STIB_AK                             --普通账户交易费用_AK科创板
		,CRD_TRD_FEE_STIB_AK                              --信用账户交易费用_AK科创板
		,TRD_FEE_STIB_AK                                  --交易费用_AK科创板
        ,ORDI_TRD_FEE_STIB_RK                             --普通账户交易费用_RK科创CDR
		,CRD_TRD_FEE_STIB_RK                              --信用账户交易费用_RK科创CDR
		,TRD_FEE_STIB_RK                                  --交易费用_RK科创CDR		
		,TRD_VOL_AK                                       --交易量_AK科创板
        ,TRD_VOL_AK_80                                    --交易量_AK科创板(不包含申购交易量)
        ,TRD_VOL_AK_BUYIN                                 --交易量_AK科创板_买入
        ,TRD_VOL_AK_SELL                                  --交易量_AK科创板_卖出
        ,TRD_VOL_AK_PRCH                                  --交易量_AK科创板_申购
		,ORDI_TRD_VOL_AK                                  --普通账户交易量_AK科创板
        ,ORDI_TRD_VOL_AK_80                               --普通账户交易量_AK科创板(不包含申购交易量)
        ,ORDI_TRD_VOL_AK_BUYIN                            --普通账户交易量_AK科创板_买入
        ,ORDI_TRD_VOL_AK_SELL                             --普通账户交易量_AK科创板_卖出
        ,ORDI_TRD_VOL_AK_PRCH                             --普通账户交易量_AK科创板_申购
        ,CRD_TRD_VOL_AK                                   --信用账户交易量_AK科创板
        ,CRD_TRD_VOL_AK_80                                --信用账户交易量_AK科创板(不包含申购交易量)
        ,CRD_TRD_VOL_AK_BUYIN                             --信用账户交易量_AK科创板_买入
        ,CRD_TRD_VOL_AK_SELL                              --信用账户交易量_AK科创板_卖出
        ,CRD_TRD_VOL_AK_PRCH                              --信用账户交易量_AK科创板_申购		
		,TRD_VOL_RK                                       --交易量_RK科创CDR
        ,TRD_VOL_RK_80                                    --交易量_RK科创CDR(不包含申购交易量)
        ,TRD_VOL_RK_BUYIN                                 --交易量_RK科创CDR_买入
        ,TRD_VOL_RK_SELL                                  --交易量_RK科创CDR_卖出
        ,TRD_VOL_RK_PRCH                                  --交易量_RK科创CDR_申购
		,ORDI_TRD_VOL_RK                                  --普通账户交易量_RK科创CDR
        ,ORDI_TRD_VOL_RK_80                               --普通账户交易量_RK科创CDR(不包含申购交易量)
        ,ORDI_TRD_VOL_RK_BUYIN                            --普通账户交易量_RK科创CDR_买入
        ,ORDI_TRD_VOL_RK_SELL                             --普通账户交易量_RK科创CDR_卖出
        ,ORDI_TRD_VOL_RK_PRCH                             --普通账户交易量_RK科创CDR_申购
        ,CRD_TRD_VOL_RK                                   --信用账户交易量_RK科创CDR
        ,CRD_TRD_VOL_RK_80                                --信用账户交易量_RK科创CDR(不包含申购交易量)
        ,CRD_TRD_VOL_RK_BUYIN                             --信用账户交易量_RK科创CDR_买入
        ,CRD_TRD_VOL_RK_SELL                              --信用账户交易量_RK科创CDR_卖出
        ,CRD_TRD_VOL_RK_PRCH                              --信用账户交易量_RK科创CDR_申购		
		,TRD_ITMS_STIB_AK                                 --交易笔数_AK科创板
        ,TRD_ITMS_STIB_AK_80                              --交易笔数_AK科创板(不包含申购的笔数)
		,ORDI_TRD_ITMS_STIB_AK                            --普通账户交易笔数_AK科创板
        ,ORDI_TRD_ITMS_STIB_AK_80                         --普通账户交易笔数_AK科创板(不包含申购的笔数)
        ,CRD_TRD_ITMS_STIB_AK                             --信用账户交易笔数_AK科创板
        ,CRD_TRD_ITMS_STIB_AK_80                          --信用账户交易笔数_AK科创板(不包含申购的笔数)
	    ,TRD_ITMS_STIB_RK                                 --交易笔数_RK科创CDR
        ,TRD_ITMS_STIB_RK_80                              --交易笔数_RK科创CDR(不包含申购的笔数)
		,ORDI_TRD_ITMS_STIB_RK                            --普通账户交易笔数_RK科创CDR
        ,ORDI_TRD_ITMS_STIB_RK_80                         --普通账户交易笔数_RK科创CDR(不包含申购的笔数)
        ,CRD_TRD_ITMS_STIB_RK                             --信用账户交易笔数_RK科创CDR
        ,CRD_TRD_ITMS_STIB_RK_80                          --信用账户交易笔数_RK科创CDR(不包含申购的笔数)
        ,CRD_CRD_TRD_VOL                                  --信用账户信用交易量
        ,CRD_CRD_TRD_S1                                   --信用账户信用交易佣金
        ,CRD_CRD_TRD_NET_S1                               --信用账户信用交易净佣金
        ,CRD_CRD_TRD_FEE                                  --信用账户信用交易费用
        ,CRD_CRD_TRD_ITMS                                 --信用账户信用交易笔数
        ,NEW_TA_TRD_VOL                                   --新三板交易量
        ,NEW_TA_TRD_S1                                    --新三板交易佣金
        ,NEW_TA_TRD_NET_S1                                --新三板交易净佣金
        ,NEW_TA_TRD_FEE                                   --新三板交易费用
        ,NEW_TA_TRD_ITMS                                  --新三板交易笔数
        ,CLS_FND_TRD_VOL                                  --分级基金交易量
        ,CLS_FND_TRD_S1                                   --分级基金交易佣金
        ,CLS_FND_TRD_NET_S1                               --分级基金交易净佣金
        ,CLS_FND_TRD_FEE                                  --分级基金交易费用
        ,CLS_FND_TRD_ITMS                                 --分级基金交易笔数
		,TRD_VOL_ASTK                                      --A股交易量
		,TRD_VOL_ASTK_BUYIN                                --A股交易量_买入
		,TRD_VOL_ASTK_SELL                                 --A股交易量_卖出
		,TRD_VOL_ASTK_PRCH                                 --A股交易量_申购
		,TRD_VOL_BSTK                                      --B股交易量
		,TRD_VOL_BSTK_BUYIN                                --B股交易量_买入
		,TRD_VOL_BSTK_SELL                                 --B股交易量_卖出
		,TRD_VOL_HK_STK                                    --港股交易量
		,TRD_VOL_HK_STK_BUYIN                              --港股交易量_买入
		,TRD_VOL_HK_STK_SELL                               --港股交易量_卖出
		,TRD_VOL_EXG_FND                                   --场内基金的交易量
		,TRD_VOL_EXG_FND_BUYIN                             --场内基金的交易量_买入
		,TRD_VOL_EXG_FND_SELL                              --场内基金的交易量_卖出		
		,S1_ASTK                                           --A股佣金
		,S1_BSTK                                           --B股佣金
		,S1_HK_STK                                         --港股佣金
		,S1_EXG_FND                                        --场内基金佣金
		,NET_S1_ASTK                                       --A股净佣金
		,NET_S1_BSTK                                       --B股净佣金
		,NET_S1_HK_STK                                     --港股净佣金
		,NET_S1_EXG_FND                                    --场内基金净佣金		
		,TRD_ITMS_ASTK                                     --A股交易笔数
		,TRD_ITMS_ASTK_BUYIN                               --A股交易笔数_买入
		,TRD_ITMS_ASTK_SELL                                --A股交易笔数_卖出
		,TRD_ITMS_ASTK_PRCH                                --A股交易笔数_申购
		,TRD_ITMS_BSTK                                     --B股交易笔数
		,TRD_ITMS_BSTK_BUYIN                               --B股交易笔数_买入
		,TRD_ITMS_BSTK_SELL                                --B股交易笔数_卖出
		,TRD_ITMS_HK_STK                                   --港股交易笔数
		,TRD_ITMS_HK_STK_BUYIN                             --港股交易笔数_买入
		,TRD_ITMS_HK_STK_SELL                              --港股交易笔数_卖出
		,TRD_ITMS_EXG_FND                                  --场内基金的交易笔数
		,TRD_ITMS_EXG_FND_BUYIN                            --场内基金的交易笔数_买入
		,TRD_ITMS_EXG_FND_SELL                             --场内基金的交易笔数_卖出
        ,WRNT_TRD_CNTS_SH               --期权账户交易张数(SH)
        ,WRNT_TRD_VOL_SH                        --期权账户交易量(SH)
        ,WRNT_S1_INCM_SH                        --期权账户佣金收入(SH)
        ,WRNT_NET_S1_INCM_SH                    --期权账户净佣金收入(SH)
        ,WRNT_TRD_FEE_SH                        --期权账户交易费用(SH)
        ,WRNT_TRD_ITMS_SH                       --期权账户交易笔数(SH)
        ,WRNT_TRD_VOL_BUYIN_SH                  --期权账户交易量_买入(SH)
        ,WRNT_TRD_VOL_SELL_SH                   --期权账户交易量_卖出(SH)
        ,WRNT_TRD_CNTS_BUYIN_SH                 --期权账户交易张数_买入(SH)
        ,WRNT_TRD_CNTS_SELL_SH                  --期权账户交易张数_卖出(SH)	 					
        ,WRNT_TRD_VOL_BUYIN_O_SH                --期权账户交易量_买入_开仓(SH)
        ,WRNT_TRD_VOL_BUYIN_C_SH                --期权账户交易量_买入_平仓(SH)
        ,WRNT_TRD_VOL_SELL_O_SH                 --期权账户交易量_卖出_开仓(SH)
        ,WRNT_TRD_VOL_SELL_C_SH                 --期权账户交易量_卖出_平仓(SH)
        ,WRNT_TRD_CNTS_BUYIN_O_SH               --期权账户交易张数_买入_开仓(SH)
        ,WRNT_TRD_CNTS_BUYIN_C_SH               --期权账户交易张数_买入_平仓(SH)
        ,WRNT_TRD_CNTS_SELL_O_SH                --期权账户交易张数_卖出_开仓(SH)
        ,WRNT_TRD_CNTS_SELL_C_SH                --期权账户交易张数_卖出_平仓(SH)
        ,WRNT_TRD_CNTS_SZ                       --期权账户交易张数(SZ)
        ,WRNT_TRD_VOL_SZ                        --期权账户交易量(SZ)
        ,WRNT_S1_INCM_SZ                        --期权账户佣金收入(SZ)
        ,WRNT_NET_S1_INCM_SZ                    --期权账户净佣金收入(SZ)
        ,WRNT_TRD_FEE_SZ                        --期权账户交易费用(SZ)
        ,WRNT_TRD_ITMS_SZ                       --期权账户交易笔数(SZ)
        ,WRNT_TRD_VOL_BUYIN_SZ                  --期权账户交易量_买入(SZ)
        ,WRNT_TRD_VOL_SELL_SZ                   --期权账户交易量_卖出(SZ)
        ,WRNT_TRD_CNTS_BUYIN_SZ                 --期权账户交易张数_买入(SZ)
        ,WRNT_TRD_CNTS_SELL_SZ                  --期权账户交易张数_卖出(SZ)	 					 
        ,WRNT_TRD_VOL_BUYIN_O_SZ                --期权账户交易量_买入_开仓(SZ)
        ,WRNT_TRD_VOL_BUYIN_C_SZ                --期权账户交易量_买入_平仓(SZ)
        ,WRNT_TRD_VOL_SELL_O_SZ                 --期权账户交易量_卖出_开仓(SZ)
        ,WRNT_TRD_VOL_SELL_C_SZ                 --期权账户交易量_卖出_平仓(SZ)
        ,WRNT_TRD_CNTS_BUYIN_O_SZ               --期权账户交易张数_买入_开仓(SZ)
        ,WRNT_TRD_CNTS_BUYIN_C_SZ               --期权账户交易张数_买入_平仓(SZ)
        ,WRNT_TRD_CNTS_SELL_O_SZ                --期权账户交易张数_卖出_开仓(SZ)
        ,WRNT_TRD_CNTS_SELL_C_SZ                --期权账户交易张数_卖出_平仓(SZ)
		,CRD_TRD_ITMS_SA_80                     --信用账户交易笔数_深A主板(不包含申购的笔数)
		
	
)PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT  t.CUST_NO                                     --客户号                 
        ,t.BRH_NO                                      --营业部编号                         
        ,t.CUST_CGY			                           --客户类别
		,NVL(a8.CRD_MRGNC_MRGNS_PRDCT_INT,0)           --信用账户融资融券预计利息    
        ,NVL(a9.CRD_MRGNC_MRGNS_RTN_INT,0)             --信用账户融资融券归还利息
		,NVL(a6.ORDI_PLG_REPO_PRDCT_INT,0)             --普通账户质押回购预计利息
        ,NVL(a7.ORDI_PLG_REPO_RTN_INT,0)               --普通账户质押回购归还利息
		,NVL(a1.ORDI_S1_INCM_RMB,0)                            --普通账户佣金收入(人民币)
        ,NVL(a1.CRD_S1_INCM,0)                                 --信用账户佣金收入
        ,NVL(a1.ORDI_S1_INCM_OTH_RMB,0)                        --普通账户佣金收入_其他(包括权证等)
        ,NVL(a1.S1_INCM_HA,0)                                  --佣金收入_沪A主板
        ,NVL(a1.ORDI_S1_INCM_HA,0)                             --普通账户佣金收入_沪A主板
        ,NVL(a1.CRD_S1_INCM_HA,0)                              --信用账户佣金收入_沪A主板
        ,NVL(a1.S1_INCM_SA,0)                                  --佣金收入_深A主板
        ,NVL(a1.ORDI_S1_INCM_SA,0)                             --普通账户佣金收入_深A主板
        ,NVL(a1.CRD_S1_INCM_SA,0)                              --信用账户佣金收入_深A主板
        ,NVL(a1.S1_INCM_SMS,0)                                 --佣金收入_中小板
        ,NVL(a1.ORDI_S1_INCM_SMS,0)                            --普通账户佣金收入_中小板
        ,NVL(a1.CRD_S1_INCM_SMS,0)                             --信用账户佣金收入_中小板
        ,NVL(a1.S1_INCM_GEM,0)                                 --佣金收入_创业板
        ,NVL(a1.ORDI_S1_INCM_GEM,0)                            --普通账户佣金收入_创业板
        ,NVL(a1.CRD_S1_INCM_GEM,0)                             --信用账户佣金收入_创业板
        ,NVL(a1.ORDI_S1_INCM_HB_USD,0)                         --普通账户佣金收入_沪B_美元
        ,NVL(a1.ORDI_S1_INCM_SB_HKD,0)                         --普通账户佣金收入_深B_港币
        ,NVL(a1.ORDI_S1_INCM_HK,0)                             --普通账户佣金收入_沪港通
        ,NVL(a1.ORDI_S1_INCM_SK,0)                             --普通账户佣金收入_深港通
        ,NVL(a1.ORDI_S1_INCM_TA,0)                             --普通账户佣金收入_三板A股
        ,NVL(a1.ORDI_S1_INCM_TU_USD,0)                         --普通账户佣金收入_三板B股_美元
        ,NVL(a1.ORDI_S1_INCM_REPO,0)                           --普通账户佣金收入_回购
        ,NVL(a1.ORDI_S1_INCM_EXG_FND,0)                        --普通账户佣金收入_场内基金收入
        ,NVL(a1.ORDI_S1_INCM_CLS_FND,0)                        --普通账户佣金收入_封闭式基金
        ,NVL(a1.ORDI_S1_INCM_ETF_FND,0)                        --普通账户佣金收入_ETF
        ,NVL(a1.ORDI_S1_INCM_OPN_FND,0)                        --普通账户佣金收入_开放式
        ,NVL(a1.ORDI_S1_INCM_LOF_FND,0)                        --普通账户佣金收入_LOF
        ,NVL(a1.ORDI_S1_INCM_FOF_FND,0)                        --普通账户佣金收入_FOF
        ,NVL(a1.CRD_S1_INCM_EXG_FND,0)                         --信用账户佣金收入_场内基金收入
        ,NVL(a1.CRD_S1_INCM_CLS_FND,0)                         --信用账户佣金收入_封闭式基金
        ,NVL(a1.CRD_S1_INCM_ETF_FND,0)                         --信用账户佣金收入_ETF
        ,NVL(a1.CRD_S1_INCM_OPN_FND,0)                         --信用账户佣金收入_开放式
        ,NVL(a1.CRD_S1_INCM_LOF_FND,0)                         --信用账户佣金收入_LOF
        ,NVL(a1.CRD_S1_INCM_FOF_FND,0)                         --信用账户佣金收入_FOF
        ,NVL(a1.ORDI_S1_INCM_BOND,0)                           --普通账户佣金收入_债券
        ,NVL(a1.CRD_S1_INCM_BOND,0)                            --信用账户佣金收入_债券
        ,NVL(a1.ORDI_NET_S1_INCM_RMB,0)                        --普通账户净佣金收入(人民币)
        ,NVL(a1.CRD_NET_S1_INCM,0)                             --信用账户净佣金收入
        ,NVL(a1.ORDI_NET_S1_INCM_OTH_RMB,0)                    --普通账户净佣金收入_其他(包括权证等)
        ,NVL(a1.NET_S1_INCM_HA,0)                              --净佣金收入_沪A主板
        ,NVL(a1.ORDI_NET_S1_INCM_HA,0)                         --普通账户净佣金收入_沪A主板
        ,NVL(a1.CRD_NET_S1_INCM_HA,0)                          --信用账户净佣金收入_沪A主板
        ,NVL(a1.NET_S1_INCM_SA,0)                              --净佣金收入_深A主板
        ,NVL(a1.ORDI_NET_S1_INCM_SA,0)                         --普通账户净佣金收入_深A主板
        ,NVL(a1.CRD_NET_S1_INCM_SA,0)                          --信用账户净佣金收入_深A主板
        ,NVL(a1.NET_S1_INCM_SMS,0)                             --净佣金收入_中小板
        ,NVL(a1.ORDI_NET_S1_INCM_SMS,0)                        --普通账户净佣金收入_中小板
        ,NVL(a1.CRD_NET_S1_INCM_SMS,0)                         --信用账户净佣金收入_中小板
        ,NVL(a1.NET_S1_INCM_GEM,0)                             --净佣金收入_创业板
        ,NVL(a1.ORDI_NET_S1_INCM_GEM,0)                        --普通账户净佣金收入_创业板
        ,NVL(a1.CRD_NET_S1_INCM_GEM,0)                         --信用账户净佣金收入_创业板
        ,NVL(a1.ORDI_NET_S1_INCM_HB_USD,0)                     --普通账户净佣金收入_沪B_美元
        ,NVL(a1.ORDI_NET_S1_INCM_SB_HKD,0)                     --普通账户净佣金收入_深B_港币
        ,NVL(a1.ORDI_NET_S1_INCM_HK,0)                         --普通账户净佣金收入_沪港通
        ,NVL(a1.ORDI_NET_S1_INCM_SK,0)                         --普通账户净佣金收入_深港通
        ,NVL(a1.ORDI_NET_S1_INCM_TA,0)                         --普通账户净佣金收入_三板A股
        ,NVL(a1.ORDI_NET_S1_INCM_TU_USD,0)                     --普通账户净佣金收入_三板B股_美元
        ,NVL(a1.ORDI_NET_S1_INCM_REPO,0)                       --普通账户净佣金收入_回购
        ,NVL(a1.ORDI_NET_S1_INCM_EXG_FND,0)                    --普通账户净佣金收入_场内基金收入
        ,NVL(a1.ORDI_NET_S1_INCM_CLS_FND,0)                    --普通账户净佣金收入_封闭式基金
        ,NVL(a1.ORDI_NET_S1_INCM_ETF_FND,0)                    --普通账户净佣金收入_ETF
        ,NVL(a1.ORDI_NET_S1_INCM_OPN_FND,0)                    --普通账户净佣金收入_开放式
        ,NVL(a1.ORDI_NET_S1_INCM_LOF_FND,0)                    --普通账户净佣金收入_LOF
        ,NVL(a1.ORDI_NET_S1_INCM_FOF_FND,0)                    --普通账户净佣金收入_FOF
        ,NVL(a1.CRD_NET_S1_INCM_EXG_FND,0)                     --信用账户净佣金收入_场内基金收入
        ,NVL(a1.CRD_NET_S1_INCM_CLS_FND,0)                     --信用账户净佣金收入_封闭式基金
        ,NVL(a1.CRD_NET_S1_INCM_ETF_FND,0)                     --信用账户净佣金收入_ETF
        ,NVL(a1.CRD_NET_S1_INCM_OPN_FND,0)                     --信用账户净佣金收入_开放式
        ,NVL(a1.CRD_NET_S1_INCM_LOF_FND,0)                     --信用账户净佣金收入_LOF
        ,NVL(a1.CRD_NET_S1_INCM_FOF_FND,0)                     --信用账户净佣金收入_FOF
        ,NVL(a1.ORDI_NET_S1_INCM_BOND,0)                       --普通账户净佣金收入_债券
        ,NVL(a1.CRD_NET_S1_INCM_BOND,0)                        --信用账户净佣金收入_债券	
        ,NVL(a1.ORDI_TRD_FEE_RMB,0)                            --普通账户交易费用(人民币)
        ,NVL(a1.CRD_TRD_FEE,0)                                 --信用账户交易费用
        ,NVL(a1.ORDI_TRD_FEE_OTH_RMB,0)                        --普通账户交易费用_其他(包括权证等)
        ,NVL(a1.TRD_FEE_HA,0)                                  --交易费用_沪A主板
        ,NVL(a1.ORDI_TRD_FEE_HA,0)                             --普通账户交易费用_沪A主板
        ,NVL(a1.CRD_TRD_FEE_HA,0)                              --信用账户交易费用_沪A主板
        ,NVL(a1.TRD_FEE_SA,0)                                  --交易费用_深A主板
        ,NVL(a1.ORDI_TRD_FEE_SA,0)                             --普通账户交易费用_深A主板
        ,NVL(a1.CRD_TRD_FEE_SA,0)                              --信用账户交易费用_深A主板
        ,NVL(a1.TRD_FEE_SMS,0)                                 --交易费用_中小板
        ,NVL(a1.ORDI_TRD_FEE_SMS,0)                            --普通账户交易费用_中小板
        ,NVL(a1.CRD_TRD_FEE_SMS,0)                             --信用账户交易费用_中小板
        ,NVL(a1.TRD_FEE_GEM,0)                                 --交易费用_创业板
        ,NVL(a1.ORDI_TRD_FEE_GEM,0)                            --普通账户交易费用_创业板
        ,NVL(a1.CRD_TRD_FEE_GEM,0)                             --信用账户交易费用_创业板
        ,NVL(a1.ORDI_TRD_FEE_HB_USD,0)                         --普通账户交易费用_沪B_美元
        ,NVL(a1.ORDI_TRD_FEE_SB_HKD,0)                         --普通账户交易费用_深B_港币
        ,NVL(a1.ORDI_TRD_FEE_HK,0)                             --普通账户交易费用_沪港通
        ,NVL(a1.ORDI_TRD_FEE_SK,0)                             --普通账户交易费用_深港通
        ,NVL(a1.ORDI_TRD_FEE_TA,0)                             --普通账户交易费用_三板A股
        ,NVL(a1.ORDI_TRD_FEE_TU_USD,0)                         --普通账户交易费用_三板B股_美元
        ,NVL(a1.ORDI_TRD_FEE_REPO,0)                           --普通账户交易费用_回购
        ,NVL(a1.ORDI_TRD_FEE_EXG_FND,0)                        --普通账户交易费用_场内基金
        ,NVL(a1.ORDI_TRD_FEE_CLS_FND,0)                        --普通账户交易费用_封闭式基金
        ,NVL(a1.ORDI_TRD_FEE_ETF_FND,0)                        --普通账户交易费用_ETF
        ,NVL(a1.ORDI_TRD_FEE_OPN_FND,0)                        --普通账户交易费用_开放式
        ,NVL(a1.ORDI_TRD_FEE_LOF_FND,0)                        --普通账户交易费用_LOF
        ,NVL(a1.ORDI_TRD_FEE_FOF_FND,0)                        --普通账户交易费用_FOF
        ,NVL(a1.CRD_TRD_FEE_EXG_FND,0)                         --信用账户交易费用_场内基金
        ,NVL(a1.CRD_TRD_FEE_CLS_FND,0)                         --信用账户交易费用_封闭式基金
        ,NVL(a1.CRD_TRD_FEE_ETF_FND,0)                         --信用账户交易费用_ETF
        ,NVL(a1.CRD_TRD_FEE_OPN_FND,0)                         --信用账户交易费用_开放式
        ,NVL(a1.CRD_TRD_FEE_LOF_FND,0)                         --信用账户交易费用_LOF
        ,NVL(a1.CRD_TRD_FEE_FOF_FND,0)                         --信用账户交易费用_FOF
        ,NVL(a1.ORDI_TRD_FEE_BOND,0)                           --普通账户交易费用_债券
        ,NVL(a1.CRD_TRD_FEE_BOND,0)                            --信用账户交易费用_债券					 
        ,NVL(a2.PROD_CMSN_FEE,0)                               --产品手续费
        ,NVL(a2.AGN_FND_CMSN_FEE,0)                            --代销基金手续费
        ,NVL(a2.GS_PROD_CMSN_FEE,0)                            --公司产品手续费
        ,NVL(a2.GJ_PROD_CMSN_FEE,0)                            --国君产品手续费
        ,NVL(a2.OTC_PROD_CMSN_FEE,0)                           --OTC产品手续费
        ,NVL(a2.PROD_SCRP_AMT,0)                               --产品认购金额		
        ,NVL(a2.PROD_PRCH_AMT,0)                               --产品申购金额	
        ,NVL(a2.PROD_FIXINV_AMT,0)                             --产品定投金额	
        ,NVL(a2.PROD_RDMPT_AMT,0)                              --产品赎回金额
        ,NVL(a2.AGN_FND_SCRP_AMT,0)                            --代销基金认购金额
        ,NVL(a2.AGN_FND_PRCH_AMT,0)                            --代销基金申购金额
        ,NVL(a2.AGN_FND_FIXINV_AMT,0)                          --代销基金定投金额
        ,NVL(a2.AGN_FND_RDMPT_AMT,0)                           --代销基金赎回金额
        ,NVL(a2.GS_PROD_SCRP_AMT,0)                            --公司产品认购金额
        ,NVL(a2.GS_PROD_PRCH_AMT,0)                            --公司产品申购金额
        ,NVL(a2.GS_PROD_FIXINV_AMT,0)                          --公司产品定投金额
        ,NVL(a2.GS_PROD_RDMPT_AMT,0)                           --公司产品赎回金额
        ,NVL(a2.GJ_PROD_SCRP_AMT,0)                            --国君产品认购金额
        ,NVL(a2.GJ_PROD_PRCH_AMT,0)                            --国君产品申购金额
        ,NVL(a2.GJ_PROD_FIXINV_AMT,0)                          --国君产品定投金额
        ,NVL(a2.GJ_PROD_RDMPT_AMT,0)                           --国君产品赎回金额
        ,NVL(a2.BANK_PROD_SCRP_AMT,0)                          --银行产品认购金额
        ,NVL(a2.BANK_PROD_PRCH_AMT,0)                          --银行产品申购金额		
        ,NVL(a2.BANK_PROD_RDMPT_AMT,0)                         --银行产品赎回金额	
        ,NVL(a2.OTC_PROD_SCRP_AMT,0)                           --OTC产品认购金额
        ,NVL(a2.OTC_PROD_PRCH_AMT,0)                           --OTC产品申购金额		
        ,NVL(a2.OTC_PROD_RDMPT_AMT,0)                          --OTC产品赎回金额			
        ,NVL(a2.AGN_FND_SCRP_ITMS,0)                           --代销基金认购笔数
        ,NVL(a2.AGN_FND_PRCH_ITMS,0)                           --代销基金申购笔数
        ,NVL(a2.AGN_FND_FIXINV_ITMS,0)                         --代销基金定投笔数
        ,NVL(a2.AGN_FND_RDMPT_ITMS,0)                          --代销基金赎回笔数
        ,NVL(a2.GS_PROD_SCRP_ITMS,0)                           --公司产品认购笔数
        ,NVL(a2.GS_PROD_PRCH_ITMS,0)                           --公司产品申购笔数
        ,NVL(a2.GS_PROD_FIXINV_ITMS,0)                         --公司产品定投笔数
        ,NVL(a2.GS_PROD_RDMPT_ITMS,0)                          --公司产品赎回笔数
        ,NVL(a2.GJ_PROD_SCRP_ITMS,0)                           --国君产品认购笔数
        ,NVL(a2.GJ_PROD_PRCH_ITMS,0)                           --国君产品申购笔数
        ,NVL(a2.GJ_PROD_FIXINV_ITMS,0)                         --国君产品定投笔数
        ,NVL(a2.GJ_PROD_RDMPT_ITMS,0)                          --国君产品赎回笔数
        ,NVL(a2.BANK_PROD_SCRP_ITMS,0)                         --银行产品认购笔数
        ,NVL(a2.BANK_PROD_PRCH_ITMS,0)                         --银行产品申购笔数		
        ,NVL(a2.BANK_PROD_RDMPT_ITMS,0)                        --银行产品赎回笔数
        ,NVL(a2.OTC_PROD_SCRP_ITMS,0)                          --OTC产品认购笔数
        ,NVL(a2.OTC_PROD_PRCH_ITMS,0)                          --OTC产品申购笔数		
        ,NVL(a2.OTC_PROD_RDMPT_ITMS,0)                         --OTC产品赎回笔数			 
        ,NVL(a3.ORDI_TRD_VOL_RMB,0)                            --普通账户交易量(人民币)
        ,NVL(a3.ORDI_TRD_VOL_RMB_80,0)                         --普通账户交易量(人民币)(不包含申购交易量)			
        ,NVL(a3.ORDI_TRD_VOL_RMB_BUYIN,0)                      --普通账户交易量(人民币)_买入
        ,NVL(a3.ORDI_TRD_VOL_RMB_SELL,0)                       --普通账户交易量(人民币)_卖出
        ,NVL(a3.ORDI_TRD_VOL_RMB_PRCH,0)                       --普通账户交易量(人民币)_申购
        ,NVL(a3.CRD_TRD_VOL,0)                                 --信用账户交易量
        ,NVL(a3.CRD_TRD_VOL_80,0)                              --信用账户交易量(不包含申购交易量)
        ,NVL(a3.CRD_TRD_VOL_BUYIN,0)                           --信用账户交易量_买入
        ,NVL(a3.CRD_TRD_VOL_SELL,0)                            --信用账户交易量_卖出
        ,NVL(a3.CRD_TRD_VOL_PRCH,0)                            --信用账户交易量_申购
        ,NVL(a3.ORDI_TRD_VOL_OTH_RMB,0)                        --普通账户交易量_其他(包括权证等)
        ,NVL(a3.ORDI_TRD_VOL_OTH_RMB_BUYIN,0)                  --普通账户交易量_其他(包括权证等)_买入
        ,NVL(a3.ORDI_TRD_VOL_OTH_RMB_SELL,0)                   --普通账户交易量_其他(包括权证等)_卖出
        ,NVL(a3.TRD_VOL_HA,0)                                  --交易量_沪A主板
        ,NVL(a3.TRD_VOL_HA_80,0)                               --交易量_沪A主板(不包含申购交易量)
        ,NVL(a3.TRD_VOL_HA_BUYIN,0)                            --交易量_沪A主板_买入
        ,NVL(a3.TRD_VOL_HA_SELL,0)                             --交易量_沪A主板_卖出
        ,NVL(a3.TRD_VOL_HA_PRCH,0)                             --交易量_沪A主板_申购
        ,NVL(a3.ORDI_TRD_VOL_HA,0)                             --普通账户交易量_沪A主板
        ,NVL(a3.ORDI_TRD_VOL_HA_80,0)                          --普通账户交易量_沪A主板(不包含申购交易量)
        ,NVL(a3.ORDI_TRD_VOL_HA_BUYIN,0)                       --普通账户交易量_沪A主板_买入
        ,NVL(a3.ORDI_TRD_VOL_HA_SELL,0)                        --普通账户交易量_沪A主板_卖出
        ,NVL(a3.ORDI_TRD_VOL_HA_PRCH,0)                        --普通账户交易量_沪A主板_申购
        ,NVL(a3.CRD_TRD_VOL_HA,0)                              --信用账户交易量_沪A主板
        ,NVL(a3.CRD_TRD_VOL_HA_80,0)                           --信用账户交易量_沪A主板(不包含申购交易量)
        ,NVL(a3.CRD_TRD_VOL_HA_BUYIN,0)                        --信用账户交易量_沪A主板_买入
        ,NVL(a3.CRD_TRD_VOL_HA_SELL,0)                         --信用账户交易量_沪A主板_卖出
        ,NVL(a3.CRD_TRD_VOL_HA_PRCH,0)                         --信用账户交易量_沪A主板_申购
        ,NVL(a3.TRD_VOL_SA,0)                                  --交易量_深A主板
        ,NVL(a3.TRD_VOL_SA_80,0)                               --交易量_深A主板(不包含申购交易量)
        ,NVL(a3.TRD_VOL_SA_BUYIN,0)                            --交易量_深A主板_买入
        ,NVL(a3.TRD_VOL_SA_SELL,0)                             --交易量_深A主板_卖出
        ,NVL(a3.TRD_VOL_SA_PRCH,0)                             --交易量_深A主板_申购
        ,NVL(a3.ORDI_TRD_VOL_SA,0)                             --普通账户交易量_深A主板
        ,NVL(a3.ORDI_TRD_VOL_SA_80,0)                          --普通账户交易量_深A主板(不包含申购交易量)
        ,NVL(a3.ORDI_TRD_VOL_SA_BUYIN,0)                       --普通账户交易量_深A主板_买入
        ,NVL(a3.ORDI_TRD_VOL_SA_SELL,0)                        --普通账户交易量_深A主板_卖出
        ,NVL(a3.ORDI_TRD_VOL_SA_PRCH,0)                        --普通账户交易量_深A主板_申购
        ,NVL(a3.CRD_TRD_VOL_SA,0)                              --信用账户交易量_深A主板
        ,NVL(a3.CRD_TRD_VOL_SA_80,0)                           --信用账户交易量_深A主板(不包含申购交易量)
        ,NVL(a3.CRD_TRD_VOL_SA_BUYIN,0)                        --信用账户交易量_深A主板_买入
        ,NVL(a3.CRD_TRD_VOL_SA_SELL,0)                         --信用账户交易量_深A主板_卖出
        ,NVL(a3.CRD_TRD_VOL_SA_PRCH,0)                         --信用账户交易量_深A主板_申购
        ,NVL(a3.TRD_VOL_SMS,0)                                 --交易量_中小板
        ,NVL(a3.TRD_VOL_SMS_80,0)                              --交易量_中小板(不包含申购交易量)
        ,NVL(a3.TRD_VOL_SMS_BUYIN,0)                           --交易量_中小板_买入
        ,NVL(a3.TRD_VOL_SMS_SELL,0)                            --交易量_中小板_卖出
        ,NVL(a3.TRD_VOL_SMS_PRCH,0)                            --交易量_中小板_申购
        ,NVL(a3.ORDI_TRD_VOL_SMS,0)                            --普通账户交易量_中小板
        ,NVL(a3.ORDI_TRD_VOL_SMS_80,0)                         --普通账户交易量_中小板(不包含申购交易量)
        ,NVL(a3.ORDI_TRD_VOL_SMS_BUYIN,0)                      --普通账户交易量_中小板_买入
        ,NVL(a3.ORDI_TRD_VOL_SMS_SELL,0)                       --普通账户交易量_中小板_卖出
        ,NVL(a3.ORDI_TRD_VOL_SMS_PRCH,0)                       --普通账户交易量_中小板_申购
        ,NVL(a3.CRD_TRD_VOL_SMS,0)                             --信用账户交易量_中小板
        ,NVL(a3.CRD_TRD_VOL_SMS_80,0)                          --信用账户交易量_中小板(不包含申购交易量)
        ,NVL(a3.CRD_TRD_VOL_SMS_BUYIN,0)                       --信用账户交易量_中小板_买入
        ,NVL(a3.CRD_TRD_VOL_SMS_SELL,0)                        --信用账户交易量_中小板_卖出
        ,NVL(a3.CRD_TRD_VOL_SMS_PRCH,0)                        --信用账户交易量_中小板_申购
        ,NVL(a3.TRD_VOL_GEM,0)                                 --交易量_创业板
        ,NVL(a3.TRD_VOL_GEM_80,0)                              --交易量_创业板(不包含申购交易量)
        ,NVL(a3.TRD_VOL_GEM_BUYIN,0)                           --交易量_创业板_买入
        ,NVL(a3.TRD_VOL_GEM_SELL,0)                            --交易量_创业板_卖出
        ,NVL(a3.TRD_VOL_GEM_PRCH,0)                            --交易量_创业板_申购
        ,NVL(a3.ORDI_TRD_VOL_GEM,0)                            --普通账户交易量_创业板
        ,NVL(a3.ORDI_TRD_VOL_GEM_80,0)                         --普通账户交易量_创业板(不包含申购交易量)
        ,NVL(a3.ORDI_TRD_VOL_GEM_BUYIN,0)                      --普通账户交易量_创业板_买入
        ,NVL(a3.ORDI_TRD_VOL_GEM_SELL,0)                       --普通账户交易量_创业板_卖出
        ,NVL(a3.ORDI_TRD_VOL_GEM_PRCH,0)                       --普通账户交易量_创业板_申购
        ,NVL(a3.CRD_TRD_VOL_GEM,0)                             --信用账户交易量_创业板
        ,NVL(a3.CRD_TRD_VOL_GEM_80,0)                          --信用账户交易量_创业板(不包含申购交易量)
        ,NVL(a3.CRD_TRD_VOL_GEM_BUYIN,0)                       --信用账户交易量_创业板_买入
        ,NVL(a3.CRD_TRD_VOL_GEM_SELL,0)                        --信用账户交易量_创业板_卖出
        ,NVL(a3.CRD_TRD_VOL_GEM_PRCH,0)                        --信用账户交易量_创业板_申购
        ,NVL(a3.ORDI_TRD_VOL_HB_USD,0)                         --普通账户交易量_沪B_美元
        ,NVL(a3.ORDI_TRD_VOL_HB_USD_BUYIN,0)                   --普通账户交易量_沪B_美元_买入
        ,NVL(a3.ORDI_TRD_VOL_HB_USD_SELL,0)                    --普通账户交易量_沪B_美元_卖出
        ,NVL(a3.ORDI_TRD_VOL_SB_HKD,0)                         --普通账户交易量_深B_港币
        ,NVL(a3.ORDI_TRD_VOL_SB_HKD_BUYIN,0)                   --普通账户交易量_深B_港币_买入
        ,NVL(a3.ORDI_TRD_VOL_SB_HKD_SELL,0)                    --普通账户交易量_深B_港币_卖出
        ,NVL(a3.ORDI_TRD_VOL_HK,0)                             --普通账户交易量_沪港通
        ,NVL(a3.ORDI_TRD_VOL_HK_BUYIN,0)                       --普通账户交易量_沪港通_买入
        ,NVL(a3.ORDI_TRD_VOL_HK_SELL,0)                        --普通账户交易量_沪港通_卖出
        ,NVL(a3.ORDI_TRD_VOL_SK,0)                             --普通账户交易量_深港通
        ,NVL(a3.ORDI_TRD_VOL_SK_BUYIN,0)                       --普通账户交易量_深港通_买入
        ,NVL(a3.ORDI_TRD_VOL_SK_SELL,0)                        --普通账户交易量_深港通_卖出
        ,NVL(a3.ORDI_TRD_VOL_TA,0)                             --普通账户交易量_三板A股
        ,NVL(a3.ORDI_TRD_VOL_TA_BUYIN,0)                       --普通账户交易量_三板A股_买入
        ,NVL(a3.ORDI_TRD_VOL_TA_SELL,0)                        --普通账户交易量_三板A股_卖出
        ,NVL(a3.ORDI_TRD_VOL_TU_USD,0)                         --普通账户交易量_三板B股_美元
        ,NVL(a3.ORDI_TRD_VOL_TU_USD_BUYIN,0)                   --普通账户交易量_三板B股_美元_买入
        ,NVL(a3.ORDI_TRD_VOL_TU_USD_SELL,0)                    --普通账户交易量_三板B股_美元_卖出
        ,NVL(a3.ORDI_TRD_VOL_REPO,0)                           --普通账户交易量_回购
        ,NVL(a3.ORDI_TRD_VOL_REPO_BUYIN,0)                     --普通账户交易量_回购_买入
        ,NVL(a3.ORDI_TRD_VOL_REPO_SELL,0)                      --普通账户交易量_回购_卖出
        ,NVL(a3.ORDI_TRD_VOL_EXG_FND,0)                        --普通账户交易量_场内基金
        ,NVL(a3.ORDI_TRD_VOL_EXG_FND_BUYIN,0)                  --普通账户交易量_场内基金_买入
        ,NVL(a3.ORDI_TRD_VOL_EXG_FND_SELL,0)                   --普通账户交易量_场内基金_卖出
        ,NVL(a3.ORDI_TRD_VOL_CLS_FND,0)                        --普通账户交易量_封闭式基金
        ,NVL(a3.ORDI_TRD_VOL_CLS_FND_BUYIN,0)                  --普通账户交易量_封闭式基金_买入
        ,NVL(a3.ORDI_TRD_VOL_CLS_FND_SELL,0)                   --普通账户交易量_封闭式基金_卖出
        ,NVL(a3.ORDI_TRD_VOL_ETF_FND,0)                        --普通账户交易量_ETF
        ,NVL(a3.ORDI_TRD_VOL_ETF_FND_BUYIN,0)                  --普通账户交易量_ETF_买入
        ,NVL(a3.ORDI_TRD_VOL_ETF_FND_SELL,0)                   --普通账户交易量_ETF_卖出
        ,NVL(a3.ORDI_TRD_VOL_OPN_FND,0)                        --普通账户交易量_开放式
        ,NVL(a3.ORDI_TRD_VOL_OPN_FND_BUYIN,0)                  --普通账户交易量_开放式_买入
        ,NVL(a3.ORDI_TRD_VOL_OPN_FND_SELL,0)                   --普通账户交易量_开放式_卖出
        ,NVL(a3.ORDI_TRD_VOL_LOF_FND,0)                        --普通账户交易量_LOF
        ,NVL(a3.ORDI_TRD_VOL_LOF_FND_BUYIN,0)                  --普通账户交易量_LOF_买入
        ,NVL(a3.ORDI_TRD_VOL_LOF_FND_SELL,0)                   --普通账户交易量_LOF_卖出
        ,NVL(a3.ORDI_TRD_VOL_FOF_FND,0)                        --普通账户交易量_FOF
        ,NVL(a3.ORDI_TRD_VOL_FOF_FND_BUYIN,0)                  --普通账户交易量_FOF_买入
        ,NVL(a3.ORDI_TRD_VOL_FOF_FND_SELL,0)                   --普通账户交易量_FOF_卖出
        ,NVL(a3.CRD_TRD_VOL_EXG_FND,0)                         --信用账户交易量_场内基金
        ,NVL(a3.CRD_TRD_VOL_EXG_FND_BUYIN,0)                   --信用账户交易量_场内基金_买入
        ,NVL(a3.CRD_TRD_VOL_EXG_FND_SELL,0)                    --信用账户交易量_场内基金_卖出
        ,NVL(a3.CRD_TRD_VOL_CLS_FND,0)                         --信用账户交易量_封闭式基金
        ,NVL(a3.CRD_TRD_VOL_CLS_FND_BUYIN,0)                   --信用账户交易量_封闭式基金_买入
        ,NVL(a3.CRD_TRD_VOL_CLS_FND_SELL,0)                    --信用账户交易量_封闭式基金_卖出
        ,NVL(a3.CRD_TRD_VOL_ETF_FND,0)                         --信用账户交易量_ETF
        ,NVL(a3.CRD_TRD_VOL_ETF_FND_BUYIN,0)                   --信用账户交易量_ETF_买入
        ,NVL(a3.CRD_TRD_VOL_ETF_FND_SELL,0)                    --信用账户交易量_ETF_卖出
        ,NVL(a3.CRD_TRD_VOL_OPN_FND,0)                         --信用账户交易量_开放式
        ,NVL(a3.CRD_TRD_VOL_OPN_FND_BUYIN,0)                   --信用账户交易量_开放式_买入
        ,NVL(a3.CRD_TRD_VOL_OPN_FND_SELL,0)                    --信用账户交易量_开放式_卖出
        ,NVL(a3.CRD_TRD_VOL_LOF_FND,0)                         --信用账户交易量_LOF
        ,NVL(a3.CRD_TRD_VOL_LOF_FND_BUYIN,0)                   --信用账户交易量_LOF_买入
        ,NVL(a3.CRD_TRD_VOL_LOF_FND_SELL,0)                    --信用账户交易量_LOF_卖出
        ,NVL(a3.CRD_TRD_VOL_FOF_FND,0)                         --信用账户交易量_FOF
        ,NVL(a3.CRD_TRD_VOL_FOF_FND_BUYIN,0)                   --信用账户交易量_FOF_买入
        ,NVL(a3.CRD_TRD_VOL_FOF_FND_SELL,0)                    --信用账户交易量_FOF_卖出
        ,NVL(a3.ORDI_TRD_VOL_BOND,0)                           --普通账户交易量_债券
        ,NVL(a3.ORDI_TRD_VOL_BOND_80,0)                        --普通账户交易量_债券(不包含债券的申购)
        ,NVL(a3.ORDI_TRD_VOL_BOND_BUYIN,0)                     --普通账户交易量_债券_买入
        ,NVL(a3.ORDI_TRD_VOL_BOND_SELL,0)                      --普通账户交易量_债券_卖出
        ,NVL(a3.ORDI_TRD_VOL_BOND_PRCH,0)                      --普通账户交易量_债券_申购
        ,NVL(a3.CRD_TRD_VOL_BOND,0)                            --信用账户交易量_债券	
        ,NVL(a3.CRD_TRD_VOL_BOND_80,0)                         --信用账户交易量_债券(不包含债券的申购)	
        ,NVL(a3.CRD_TRD_VOL_BOND_BUYIN,0)                      --信用账户交易量_债券_买入
        ,NVL(a3.CRD_TRD_VOL_BOND_SELL,0)                       --信用账户交易量_债券_卖出
        ,NVL(a3.CRD_TRD_VOL_BOND_PRCH,0)                       --信用账户交易量_债券_申购
        ,NVL(a4.ORDI_TRD_ITMS,0)                               --普通账户交易笔数
        ,NVL(a4.ORDI_TRD_ITMS_80,0)                            --普通账户交易笔数(不包含申购的笔数)
        ,NVL(a4.CRD_TRD_ITMS,0)                                --信用账户交易笔数
        ,NVL(a4.CRD_TRD_ITMS_80,0)                             --信用账户交易笔数(不包含申购的笔数)
        ,NVL(a4.ORDI_TRD_ITMS_OTH,0)                           --普通账户交易笔数_其他(包括权证等)
        ,NVL(a4.TRD_ITMS_HA,0)                                 --交易笔数_沪A主板
        ,NVL(a4.TRD_ITMS_HA_80,0)                              --交易笔数_沪A主板(不包含申购的笔数)
        ,NVL(a4.ORDI_TRD_ITMS_HA,0)                            --普通账户交易笔数_沪A主板
        ,NVL(a4.ORDI_TRD_ITMS_HA_80,0)                         --普通账户交易笔数_沪A主板(不包含申购的笔数)
        ,NVL(a4.CRD_TRD_ITMS_HA,0)                             --信用账户交易笔数_沪A主板
        ,NVL(a4.CRD_TRD_ITMS_HA_80,0)                          --信用账户交易笔数_沪A主板(不包含申购的笔数)
        ,NVL(a4.TRD_ITMS_SA,0)                                 --交易笔数_深A主板
        ,NVL(a4.TRD_ITMS_SA_80,0)                              --交易笔数_深A主板(不包含申购的笔数)
        ,NVL(a4.ORDI_TRD_ITMS_SA,0)                            --普通账户交易笔数_深A主板
        ,NVL(a4.ORDI_TRD_ITMS_SA_80,0)                         --普通账户交易笔数_深A主板(不包含申购的笔数)
        ,NVL(a4.CRD_TRD_ITMS_SA,0)                             --信用账户交易笔数_深A主板
        ,NVL(a4.TRD_ITMS_SMS,0)                                --交易笔数_中小板
        ,NVL(a4.TRD_ITMS_SMS_80,0)                             --交易笔数_中小板(不包含申购的笔数)
        ,NVL(a4.ORDI_TRD_ITMS_SMS,0)                           --普通账户交易笔数_中小板
        ,NVL(a4.ORDI_TRD_ITMS_SMS_80,0)                        --普通账户交易笔数_中小板(不包含申购的笔数)
        ,NVL(a4.CRD_TRD_ITMS_SMS,0)                            --信用账户交易笔数_中小板
        ,NVL(a4.CRD_TRD_ITMS_SMS_80,0)                         --信用账户交易笔数_中小板(不包含申购的笔数)
        ,NVL(a4.TRD_ITMS_GEM,0)                                --交易笔数_创业板
        ,NVL(a4.TRD_ITMS_GEM_80,0)                             --交易笔数_创业板(不包含申购的笔数)
        ,NVL(a4.ORDI_TRD_ITMS_GEM,0)                           --普通账户交易笔数_创业板
        ,NVL(a4.ORDI_TRD_ITMS_GEM_80,0)                        --普通账户交易笔数_创业板(不包含申购的笔数)
        ,NVL(a4.CRD_TRD_ITMS_GEM,0)                            --信用账户交易笔数_创业板
        ,NVL(a4.CRD_TRD_ITMS_GEM_80,0)                         --信用账户交易笔数_创业板(不包含申购的笔数)
        ,NVL(a4.ORDI_TRD_ITMS_HB,0)                            --普通账户交易笔数_沪B
        ,NVL(a4.ORDI_TRD_ITMS_SB,0)                            --普通账户交易笔数_深B
        ,NVL(a4.ORDI_TRD_ITMS_HK,0)                            --普通账户交易笔数_沪港通
        ,NVL(a4.ORDI_TRD_ITMS_SK,0)                            --普通账户交易笔数_深港通
        ,NVL(a4.ORDI_TRD_ITMS_TA,0)                            --普通账户交易笔数_三板A股
        ,NVL(a4.ORDI_TRD_ITMS_TU,0)                            --普通账户交易笔数_三板B股
        ,NVL(a4.ORDI_TRD_ITMS_REPO,0)                          --普通账户交易笔数_回购
        ,NVL(a4.ORDI_TRD_ITMS_EXG_FND,0)                       --普通账户交易笔数_场内基金
        ,NVL(a4.ORDI_TRD_ITMS_CLS_FND,0)                       --普通账户交易笔数_封闭式基金
        ,NVL(a4.ORDI_TRD_ITMS_ETF_FND,0)                       --普通账户交易笔数_ETF
        ,NVL(a4.ORDI_TRD_ITMS_OPN_FND,0)                       --普通账户交易笔数_开放式
        ,NVL(a4.ORDI_TRD_ITMS_LOF_FND,0)                       --普通账户交易笔数_LOF
        ,NVL(a4.ORDI_TRD_ITMS_FOF_FND,0)                       --普通账户交易笔数_FOF
        ,NVL(a4.CRD_TRD_ITMS_EXG_FND,0)                        --信用账户交易笔数_场内基金
        ,NVL(a4.CRD_TRD_ITMS_CLS_FND,0)                        --信用账户交易笔数_封闭式基金
        ,NVL(a4.CRD_TRD_ITMS_ETF_FND,0)                        --信用账户交易笔数_ETF
        ,NVL(a4.CRD_TRD_ITMS_OPN_FND,0)                        --信用账户交易笔数_开放式
        ,NVL(a4.CRD_TRD_ITMS_LOF_FND,0)                        --信用账户交易笔数_LOF
        ,NVL(a4.CRD_TRD_ITMS_FOF_FND,0)                        --信用账户交易笔数_FOF
        ,NVL(a4.ORDI_TRD_ITMS_BOND,0)                          --普通账户交易笔数_债券
        ,NVL(a4.ORDI_TRD_ITMS_BOND_80,0)                       --普通账户交易笔数_债券(不包含债券申购)
        ,NVL(a4.CRD_TRD_ITMS_BOND,0)                           --信用账户交易笔数_债券	
        ,NVL(a4.CRD_TRD_ITMS_BOND_80,0)                        --信用账户交易笔数_债券(不包含债券申购)	
        ,NVL(a5.WRNT_TRD_CNTS,0)                               --期权账户交易张数
        ,NVL(a5.WRNT_TRD_VOL,0)                                --期权账户交易量
        ,NVL(a5.WRNT_S1_INCM,0)                                --期权账户佣金收入
        ,NVL(a5.WRNT_NET_S1_INCM,0)                            --期权账户净佣金收入
        ,NVL(a5.WRNT_TRD_FEE,0)                                --期权账户交易费用
        ,NVL(a5.WRNT_TRD_ITMS,0)                               --期权账户交易笔数
        ,NVL(a5.WRNT_TRD_VOL_BUYIN,0)                          --期权账户交易量_买入
        ,NVL(a5.WRNT_TRD_VOL_SELL,0)                           --期权账户交易量_卖出
        ,NVL(a5.WRNT_TRD_CNTS_BUYIN,0)                         --期权账户交易张数_买入
        ,NVL(a5.WRNT_TRD_CNTS_SELL,0)                          --期权账户交易张数_卖出
        ,NVL(a5.WRNT_TRD_VOL_BUYIN_O,0)                        --期权账户交易量_买入_开仓
        ,NVL(a5.WRNT_TRD_VOL_BUYIN_C,0)                        --期权账户交易量_买入_平仓
        ,NVL(a5.WRNT_TRD_VOL_SELL_O,0)                         --期权账户交易量_卖出_开仓
        ,NVL(a5.WRNT_TRD_VOL_SELL_C,0)                         --期权账户交易量_卖出_平仓
        ,NVL(a5.WRNT_TRD_CNTS_BUYIN_O,0)                       --期权账户交易张数_买入_开仓
        ,NVL(a5.WRNT_TRD_CNTS_BUYIN_C,0)                       --期权账户交易张数_买入_平仓
        ,NVL(a5.WRNT_TRD_CNTS_SELL_O,0)                        --期权账户交易张数_卖出_开仓
        ,NVL(a5.WRNT_TRD_CNTS_SELL_C,0)                        --期权账户交易张数_卖出_平仓
		,NVL(a1.ORDI_S1_INCM_RMB,0)+NVL(a1.CRD_S1_INCM,0)+NVL(a5.WRNT_S1_INCM,0) as TOT_S1                                      --总佣金
		,NVL(a1.ORDI_NET_S1_INCM_RMB,0)+NVL(a1.CRD_NET_S1_INCM,0)+NVL(a5.WRNT_NET_S1_INCM,0) as TOT_NET_S1                                  --总净佣金
		,NVL(a1.ORDI_NET_S1_INCM_RMB,0)+NVL(a1.CRD_NET_S1_INCM,0)+NVL(a5.WRNT_NET_S1_INCM,0)+NVL(a9.CRD_MRGNC_MRGNS_RTN_INT,0)+NVL(a7.ORDI_PLG_REPO_RTN_INT,0)+NVL(a2.PROD_CMSN_FEE,0)    as TOT_INCM_OFFER                              --总收入贡献
		,NVL(a1.ORDI_S1_INCM_HB_RMB,0)                         --普通账户佣金收入_沪B_人民币
		,NVL(a1.ORDI_S1_INCM_SB_RMB,0)                         --普通账户佣金收入_深B_人民币
		,NVL(a1.ORDI_S1_INCM_TU_RMB,0)                         --普通账户佣金收入_三板B股_人民币
		,NVL(a1.ORDI_NET_S1_INCM_HB_RMB,0)                     --普通账户净佣金收入_沪B_人民币
		,NVL(a1.ORDI_NET_S1_INCM_SB_RMB,0)                     --普通账户净佣金收入_深B_人民币
		,NVL(a1.ORDI_NET_S1_INCM_TU_RMB,0)                     --普通账户净佣金收入_三板B股_人民币
		,NVL(a1.ORDI_TRD_FEE_HB_RMB,0)                         --普通账户交易费用_沪B_人民币
		,NVL(a1.ORDI_TRD_FEE_SB_RMB,0)                         --普通账户交易费用_深B_人民币
		,NVL(a1.ORDI_TRD_FEE_TU_RMB,0)                         --普通账户交易费用_三板B股_人民币
		,NVL(a3.ORDI_TRD_VOL_HB_RMB,0)                         --普通账户交易量_沪B_人民币
		,NVL(a3.ORDI_TRD_VOL_HB_RMB_BUYIN,0)                   --普通账户交易量_沪B_人民币_买入
		,NVL(a3.ORDI_TRD_VOL_HB_RMB_SELL,0)                    --普通账户交易量_沪B_人民币_卖出
		,NVL(a3.ORDI_TRD_VOL_SB_RMB,0)                         --普通账户交易量_深B_人民币
		,NVL(a3.ORDI_TRD_VOL_SB_RMB_BUYIN,0)                   --普通账户交易量_深B_人民币_买入
		,NVL(a3.ORDI_TRD_VOL_SB_RMB_SELL,0)                    --普通账户交易量_深B_人民币_卖出
		,NVL(a3.ORDI_TRD_VOL_TU_RMB,0)                         --普通账户交易量_三板B股_人民币
		,NVL(a3.ORDI_TRD_VOL_TU_RMB_BUYIN,0)                   --普通账户交易量_三板B股_人民币_买入
		,NVL(a3.ORDI_TRD_VOL_TU_RMB_SELL,0)                    --普通账户交易量_三板B股_人民币_卖出
        
		,NVL(a1.ORDI_S1_INCM_STIB_AK,0)                             --普通账户佣金收入_AK科创板
		,NVL(a1.CRD_S1_INCM_STIB_AK,0)                              --信用账户佣金收入_AK科创板
		,NVL(a1.S1_INCM_STIB_AK,0)                                  --佣金收入_AK科创板
        ,NVL(a1.ORDI_S1_INCM_STIB_RK,0)                             --普通账户佣金收入_RK科创CDR
		,NVL(a1.CRD_S1_INCM_STIB_RK,0)                              --信用账户佣金收入_RK科创CDR
		,NVL(a1.S1_INCM_STIB_RK,0)                                  --佣金收入_RK科创CDR
		,NVL(a1.ORDI_NET_S1_INCM_STIB_AK,0)                         --普通账户净佣金收入_AK科创板
		,NVL(a1.CRD_NET_S1_INCM_STIB_AK,0)                          --信用账户净佣金收入_AK科创板
		,NVL(a1.NET_S1_INCM_STIB_AK,0)                              --净佣金收入_AK科创板
        ,NVL(a1.ORDI_NET_S1_INCM_STIB_RK,0)                         --普通账户净佣金收入_RK科创CDR
		,NVL(a1.CRD_NET_S1_INCM_STIB_RK,0)                          --信用账户净佣金收入_RK科创CDR
		,NVL(a1.NET_S1_INCM_STIB_RK,0)                              --净佣金收入_RK科创CDR
		,NVL(a1.ORDI_TRD_FEE_STIB_AK,0)                             --普通账户交易费用_AK科创板
		,NVL(a1.CRD_TRD_FEE_STIB_AK,0)                              --信用账户交易费用_AK科创板
		,NVL(a1.TRD_FEE_STIB_AK,0)                                  --交易费用_AK科创板
        ,NVL(a1.ORDI_TRD_FEE_STIB_RK,0)                             --普通账户交易费用_RK科创CDR
		,NVL(a1.CRD_TRD_FEE_STIB_RK,0)                              --信用账户交易费用_RK科创CDR
		,NVL(a1.TRD_FEE_STIB_RK,0)                                  --交易费用_RK科创CDR		
		,NVL(a3.TRD_VOL_AK,0)                                       --交易量_AK科创板
        ,NVL(a3.TRD_VOL_AK_80,0)                                    --交易量_AK科创板(不包含申购交易量)
        ,NVL(a3.TRD_VOL_AK_BUYIN,0)                                 --交易量_AK科创板_买入
        ,NVL(a3.TRD_VOL_AK_SELL,0)                                  --交易量_AK科创板_卖出
        ,NVL(a3.TRD_VOL_AK_PRCH,0)                                  --交易量_AK科创板_申购
		,NVL(a3.ORDI_TRD_VOL_AK,0)                                  --普通账户交易量_AK科创板
        ,NVL(a3.ORDI_TRD_VOL_AK_80,0)                               --普通账户交易量_AK科创板(不包含申购交易量)
        ,NVL(a3.ORDI_TRD_VOL_AK_BUYIN,0)                            --普通账户交易量_AK科创板_买入
        ,NVL(a3.ORDI_TRD_VOL_AK_SELL,0)                             --普通账户交易量_AK科创板_卖出
        ,NVL(a3.ORDI_TRD_VOL_AK_PRCH,0)                             --普通账户交易量_AK科创板_申购
        ,NVL(a3.CRD_TRD_VOL_AK,0)                                   --信用账户交易量_AK科创板
        ,NVL(a3.CRD_TRD_VOL_AK_80,0)                                --信用账户交易量_AK科创板(不包含申购交易量)
        ,NVL(a3.CRD_TRD_VOL_AK_BUYIN,0)                             --信用账户交易量_AK科创板_买入
        ,NVL(a3.CRD_TRD_VOL_AK_SELL,0)                              --信用账户交易量_AK科创板_卖出
        ,NVL(a3.CRD_TRD_VOL_AK_PRCH,0)                              --信用账户交易量_AK科创板_申购		
		,NVL(a3.TRD_VOL_RK,0)                                       --交易量_RK科创CDR
        ,NVL(a3.TRD_VOL_RK_80,0)                                    --交易量_RK科创CDR(不包含申购交易量)
        ,NVL(a3.TRD_VOL_RK_BUYIN,0)                                 --交易量_RK科创CDR_买入
        ,NVL(a3.TRD_VOL_RK_SELL,0)                                  --交易量_RK科创CDR_卖出
        ,NVL(a3.TRD_VOL_RK_PRCH,0)                                  --交易量_RK科创CDR_申购
		,NVL(a3.ORDI_TRD_VOL_RK,0)                                  --普通账户交易量_RK科创CDR
        ,NVL(a3.ORDI_TRD_VOL_RK_80,0)                               --普通账户交易量_RK科创CDR(不包含申购交易量)
        ,NVL(a3.ORDI_TRD_VOL_RK_BUYIN,0)                            --普通账户交易量_RK科创CDR_买入
        ,NVL(a3.ORDI_TRD_VOL_RK_SELL,0)                             --普通账户交易量_RK科创CDR_卖出
        ,NVL(a3.ORDI_TRD_VOL_RK_PRCH,0)                             --普通账户交易量_RK科创CDR_申购
        ,NVL(a3.CRD_TRD_VOL_RK,0)                                   --信用账户交易量_RK科创CDR
        ,NVL(a3.CRD_TRD_VOL_RK_80,0)                                --信用账户交易量_RK科创CDR(不包含申购交易量)
        ,NVL(a3.CRD_TRD_VOL_RK_BUYIN,0)                             --信用账户交易量_RK科创CDR_买入
        ,NVL(a3.CRD_TRD_VOL_RK_SELL,0)                              --信用账户交易量_RK科创CDR_卖出
        ,NVL(a3.CRD_TRD_VOL_RK_PRCH,0)                              --信用账户交易量_RK科创CDR_申购		
		,NVL(a4.TRD_ITMS_STIB_AK,0)                                 --交易笔数_AK科创板
        ,NVL(a4.TRD_ITMS_STIB_AK_80,0)                              --交易笔数_AK科创板(不包含申购的笔数)
		,NVL(a4.ORDI_TRD_ITMS_STIB_AK,0)                            --普通账户交易笔数_AK科创板
        ,NVL(a4.ORDI_TRD_ITMS_STIB_AK_80,0)                         --普通账户交易笔数_AK科创板(不包含申购的笔数)
        ,NVL(a4.CRD_TRD_ITMS_STIB_AK,0)                             --信用账户交易笔数_AK科创板
        ,NVL(a4.CRD_TRD_ITMS_STIB_AK_80,0)                          --信用账户交易笔数_AK科创板(不包含申购的笔数)
	    ,NVL(a4.TRD_ITMS_STIB_RK,0)                                 --交易笔数_RK科创CDR
        ,NVL(a4.TRD_ITMS_STIB_RK_80,0)                              --交易笔数_RK科创CDR(不包含申购的笔数)
		,NVL(a4.ORDI_TRD_ITMS_STIB_RK,0)                            --普通账户交易笔数_RK科创CDR
        ,NVL(a4.ORDI_TRD_ITMS_STIB_RK_80,0)                         --普通账户交易笔数_RK科创CDR(不包含申购的笔数)
        ,NVL(a4.CRD_TRD_ITMS_STIB_RK,0)                             --信用账户交易笔数_RK科创CDR
        ,NVL(a4.CRD_TRD_ITMS_STIB_RK_80,0)                          --信用账户交易笔数_RK科创CDR(不包含申购的笔数)
        ,NVL(a3.CRD_CRD_TRD_VOL,0)                                  --信用账户信用交易量
        ,NVL(a1.CRD_CRD_TRD_S1,0)                                   --信用账户信用交易佣金
        ,NVL(a1.CRD_CRD_TRD_NET_S1,0)                               --信用账户信用交易净佣金
        ,NVL(a1.CRD_CRD_TRD_FEE,0)                                  --信用账户信用交易费用
        ,NVL(a4.CRD_CRD_TRD_ITMS,0)                                 --信用账户信用交易笔数
        ,NVL(a3.NEW_TA_TRD_VOL,0)                                   --新三板交易量
        ,NVL(a1.NEW_TA_TRD_S1,0)                                    --新三板交易佣金
        ,NVL(a1.NEW_TA_TRD_NET_S1,0)                                --新三板交易净佣金
        ,NVL(a1.NEW_TA_TRD_FEE,0)                                   --新三板交易费用
        ,NVL(a4.NEW_TA_TRD_ITMS,0)                                  --新三板交易笔数
        ,NVL(a3.CLS_FND_TRD_VOL,0)                                  --分级基金交易量
        ,NVL(a1.CLS_FND_TRD_S1,0)                                   --分级基金交易佣金
        ,NVL(a1.CLS_FND_TRD_NET_S1,0)                               --分级基金交易净佣金
        ,NVL(a1.CLS_FND_TRD_FEE,0)                                  --分级基金交易费用
        ,NVL(a4.CLS_FND_TRD_ITMS,0)                                 --分级基金交易笔数
        ,NVL(a3.TRD_VOL_HA,0)+NVL(a3.TRD_VOL_SA,0)+NVL(a3.TRD_VOL_SMS,0)+NVL(a3.TRD_VOL_GEM,0)+NVL(a3.TRD_VOL_AK,0)+NVL(a3.TRD_VOL_RK,0)                        
        ,NVL(a3.TRD_VOL_HA_BUYIN,0)+NVL(a3.TRD_VOL_SA_BUYIN,0)+NVL(a3.TRD_VOL_SMS_BUYIN,0)+NVL(a3.TRD_VOL_GEM_BUYIN,0)+NVL(a3.TRD_VOL_AK_BUYIN,0)+NVL(a3.TRD_VOL_RK_BUYIN,0)		                
        ,NVL(a3.TRD_VOL_HA_SELL,0)+NVL(a3.TRD_VOL_SA_SELL,0)+NVL(a3.TRD_VOL_SMS_SELL,0)+NVL(a3.TRD_VOL_GEM_SELL,0)+NVL(a3.TRD_VOL_AK_SELL,0)+NVL(a3.TRD_VOL_RK_SELL,0)		                
        ,NVL(a3.TRD_VOL_HA_PRCH,0)+NVL(a3.TRD_VOL_SA_PRCH,0)+NVL(a3.TRD_VOL_SMS_PRCH,0)+NVL(a3.TRD_VOL_GEM_PRCH,0)+NVL(a3.TRD_VOL_AK_PRCH,0)+NVL(a3.TRD_VOL_RK_PRCH,0)	                     
        ,NVL(a3.ORDI_TRD_VOL_HB_RMB,0)+NVL(a3.ORDI_TRD_VOL_SB_RMB,0)		                 
        ,NVL(a3.ORDI_TRD_VOL_HB_RMB_BUYIN,0)+NVL(a3.ORDI_TRD_VOL_SB_RMB_BUYIN,0) 		                       
        ,NVL(a3.ORDI_TRD_VOL_HB_RMB_SELL,0)+NVL(a3.ORDI_TRD_VOL_SB_RMB_SELL,0)		              
        ,NVL(a3.ORDI_TRD_VOL_HK,0)+NVL(a3.ORDI_TRD_VOL_SK,0)		
        ,NVL(a3.ORDI_TRD_VOL_HK_BUYIN,0)+NVL(a3.ORDI_TRD_VOL_SK_BUYIN,0)		     
        ,NVL(a3.ORDI_TRD_VOL_HK_SELL,0)+NVL(a3.ORDI_TRD_VOL_SK_SELL,0)		            
        ,NVL(a3.ORDI_TRD_VOL_EXG_FND,0)+NVL(a3.CRD_TRD_VOL_EXG_FND,0)	   
        ,NVL(a3.ORDI_TRD_VOL_EXG_FND_BUYIN,0)+NVL(a3.CRD_TRD_VOL_EXG_FND_BUYIN,0)		
        ,NVL(a3.ORDI_TRD_VOL_EXG_FND_SELL,0)+NVL(a3.CRD_TRD_VOL_EXG_FND_SELL,0)		          	
        ,NVL(a1.S1_INCM_HA,0)+NVL(a1.S1_INCM_SA,0)+NVL(a1.S1_INCM_SMS,0)+NVL(a1.S1_INCM_GEM,0)+NVL(a1.S1_INCM_STIB_AK,0)+NVL(a1.S1_INCM_STIB_RK,0)		                    
        ,NVL(a1.ORDI_S1_INCM_HB_RMB,0)+NVL(a1.ORDI_S1_INCM_SB_RMB,0)		              
        ,NVL(a1.ORDI_S1_INCM_HK,0)+NVL(a1.ORDI_S1_INCM_SK,0)		          
        ,NVL(a1.ORDI_S1_INCM_EXG_FND,0)+NVL(a1.CRD_S1_INCM_EXG_FND,0)		              
        ,NVL(a1.NET_S1_INCM_HA,0)+NVL(a1.NET_S1_INCM_SA,0)+NVL(a1.NET_S1_INCM_GEM,0)+NVL(a1.NET_S1_INCM_SMS,0)+NVL(a1.NET_S1_INCM_STIB_AK,0)+NVL(a1.NET_S1_INCM_STIB_RK,0)		                      
        ,NVL(a1.ORDI_NET_S1_INCM_HB_RMB,0)+NVL(a1.ORDI_NET_S1_INCM_SB_RMB,0)		             
        ,NVL(a1.ORDI_NET_S1_INCM_HK,0)+NVL(a1.ORDI_NET_S1_INCM_SK,0)		       
        ,NVL(a1.ORDI_NET_S1_INCM_EXG_FND,0)+NVL(a1.CRD_NET_S1_INCM_EXG_FND,0)		                 
        ,NVL(a4.TRD_ITMS_HA,0)+NVL(a4.TRD_ITMS_SA,0)+NVL(a4.TRD_ITMS_SMS,0)+NVL(a4.TRD_ITMS_GEM,0)+NVL(a4.TRD_ITMS_STIB_AK,0)+NVL(a4.TRD_ITMS_STIB_RK,0)		
        ,NVL(a4.TRD_ITMS_HA_BUYIN,0)+NVL(a4.TRD_ITMS_SA_BUYIN,0)+NVL(a4.TRD_ITMS_SMS_BUYIN,0)+NVL(a4.TRD_ITMS_GEM_BUYIN,0)+NVL(a4.TRD_ITMS_STIB_AK_BUYIN,0)+NVL(a4.TRD_ITMS_STIB_RK_BUYIN,0)		      
        ,NVL(a4.TRD_ITMS_HA_SELL,0)+NVL(a4.TRD_ITMS_SA_SELL,0)+NVL(a4.TRD_ITMS_SMS_SELL,0)+NVL(a4.TRD_ITMS_GEM_SELL,0)+NVL(a4.TRD_ITMS_STIB_AK_SELL,0)+NVL(a4.TRD_ITMS_STIB_RK_SELL,0)			
        ,NVL(a4.TRD_ITMS_HA_PRCH,0)+NVL(a4.TRD_ITMS_SA_PRCH,0)+NVL(a4.TRD_ITMS_SMS_PRCH,0)+NVL(a4.TRD_ITMS_GEM_PRCH,0)+NVL(a4.TRD_ITMS_STIB_AK_PRCH,0)+NVL(a4.TRD_ITMS_STIB_RK_PRCH,0)	 		
        ,NVL(a4.ORDI_TRD_ITMS_HB,0)+NVL(a4.ORDI_TRD_ITMS_SB,0)		        
        ,NVL(a4.ORDI_TRD_ITMS_HB_BUYIN,0)+NVL(a4.ORDI_TRD_ITMS_SB_BUYIN,0)		            
        ,NVL(a4.ORDI_TRD_ITMS_HB_SELL,0)+NVL(a4.ORDI_TRD_ITMS_SB_SELL,0)		                  
        ,NVL(a4.ORDI_TRD_ITMS_HK,0)+NVL(a4.ORDI_TRD_ITMS_SK,0)		          
        ,NVL(a4.ORDI_TRD_ITMS_HK_BUYIN,0)+NVL(a4.ORDI_TRD_ITMS_SK_BUYIN,0)	         
        ,NVL(a4.ORDI_TRD_ITMS_HK_SELL,0)+NVL(a4.ORDI_TRD_ITMS_SK_SELL,0)		  
        ,NVL(a4.ORDI_TRD_ITMS_EXG_FND,0)+NVL(a4.CRD_TRD_ITMS_EXG_FND,0)		              
        ,NVL(a4.ORDI_TRD_ITMS_EXG_FND_BUYIN,0)+NVL(a4.CRD_TRD_ITMS_EXG_FND_BUYIN,0)		                
        ,NVL(a4.ORDI_TRD_ITMS_EXG_FND_SELL,0)+NVL(a4.CRD_TRD_ITMS_EXG_FND_SELL,0)
        ,NVL(a5.WRNT_TRD_CNTS_SH,0)               --期权账户交易张数(SH)
        ,NVL(a5.WRNT_TRD_VOL_SH,0)                        --期权账户交易量(SH)
        ,NVL(a5.WRNT_S1_INCM_SH,0)                        --期权账户佣金收入(SH)
        ,NVL(a5.WRNT_NET_S1_INCM_SH,0)                    --期权账户净佣金收入(SH)
        ,NVL(a5.WRNT_TRD_FEE_SH,0)                        --期权账户交易费用(SH)
        ,NVL(a5.WRNT_TRD_ITMS_SH,0)                       --期权账户交易笔数(SH)
        ,NVL(a5.WRNT_TRD_VOL_BUYIN_SH,0)                  --期权账户交易量_买入(SH)
        ,NVL(a5.WRNT_TRD_VOL_SELL_SH,0)                   --期权账户交易量_卖出(SH)
        ,NVL(a5.WRNT_TRD_CNTS_BUYIN_SH,0)                 --期权账户交易张数_买入(SH)
        ,NVL(a5.WRNT_TRD_CNTS_SELL_SH,0)                  --期权账户交易张数_卖出(SH)	 					
        ,NVL(a5.WRNT_TRD_VOL_BUYIN_O_SH,0)                --期权账户交易量_买入_开仓(SH)
        ,NVL(a5.WRNT_TRD_VOL_BUYIN_C_SH,0)                --期权账户交易量_买入_平仓(SH)
        ,NVL(a5.WRNT_TRD_VOL_SELL_O_SH,0)                 --期权账户交易量_卖出_开仓(SH)
        ,NVL(a5.WRNT_TRD_VOL_SELL_C_SH,0)                 --期权账户交易量_卖出_平仓(SH)
        ,NVL(a5.WRNT_TRD_CNTS_BUYIN_O_SH,0)               --期权账户交易张数_买入_开仓(SH)
        ,NVL(a5.WRNT_TRD_CNTS_BUYIN_C_SH,0)               --期权账户交易张数_买入_平仓(SH)
        ,NVL(a5.WRNT_TRD_CNTS_SELL_O_SH,0)                --期权账户交易张数_卖出_开仓(SH)
        ,NVL(a5.WRNT_TRD_CNTS_SELL_C_SH,0)                --期权账户交易张数_卖出_平仓(SH)
        ,NVL(a5.WRNT_TRD_CNTS_SZ,0)                       --期权账户交易张数(SZ)
        ,NVL(a5.WRNT_TRD_VOL_SZ,0)                        --期权账户交易量(SZ)
        ,NVL(a5.WRNT_S1_INCM_SZ,0)                        --期权账户佣金收入(SZ)
        ,NVL(a5.WRNT_NET_S1_INCM_SZ,0)                    --期权账户净佣金收入(SZ)
        ,NVL(a5.WRNT_TRD_FEE_SZ,0)                        --期权账户交易费用(SZ)
        ,NVL(a5.WRNT_TRD_ITMS_SZ,0)                       --期权账户交易笔数(SZ)
        ,NVL(a5.WRNT_TRD_VOL_BUYIN_SZ,0)                  --期权账户交易量_买入(SZ)
        ,NVL(a5.WRNT_TRD_VOL_SELL_SZ,0)                   --期权账户交易量_卖出(SZ)
        ,NVL(a5.WRNT_TRD_CNTS_BUYIN_SZ,0)                 --期权账户交易张数_买入(SZ)
        ,NVL(a5.WRNT_TRD_CNTS_SELL_SZ,0)                  --期权账户交易张数_卖出(SZ)	 					 
        ,NVL(a5.WRNT_TRD_VOL_BUYIN_O_SZ,0)                --期权账户交易量_买入_开仓(SZ)
        ,NVL(a5.WRNT_TRD_VOL_BUYIN_C_SZ,0)                --期权账户交易量_买入_平仓(SZ)
        ,NVL(a5.WRNT_TRD_VOL_SELL_O_SZ,0)                 --期权账户交易量_卖出_开仓(SZ)
        ,NVL(a5.WRNT_TRD_VOL_SELL_C_SZ,0)                 --期权账户交易量_卖出_平仓(SZ)
        ,NVL(a5.WRNT_TRD_CNTS_BUYIN_O_SZ,0)               --期权账户交易张数_买入_开仓(SZ)
        ,NVL(a5.WRNT_TRD_CNTS_BUYIN_C_SZ,0)               --期权账户交易张数_买入_平仓(SZ)
        ,NVL(a5.WRNT_TRD_CNTS_SELL_O_SZ,0)                --期权账户交易张数_卖出_开仓(SZ)
        ,NVL(a5.WRNT_TRD_CNTS_SELL_C_SZ,0)                --期权账户交易张数_卖出_平仓(SZ)
        ,NVL(a4.CRD_TRD_ITMS_SA_80,0)                     --信用账户交易笔数_深A主板(不包含申购的笔数)		
 FROM  (SELECT CUST_NO
               ,BRH_NO
			   ,CUST_CGY
        FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO  
		WHERE BUS_DATE = %d{yyyyMMdd}
		)  t
 LEFT JOIN DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP a1
 ON        t.CUST_NO = a1.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP1 a2
 ON        t.CUST_NO = a2.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP2 a3
 ON        t.CUST_NO = a3.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP3 a4
 ON        t.CUST_NO = a4.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP4 a5
 ON        t.CUST_NO = a5.CUST_NO
 LEFT JOIN (SELECT CUST_NO,SUM(ORDI_ACCT_GL_ADD_PRINP)  as ORDI_PLG_REPO_PRDCT_INT
            FROM   DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS
            WHERE  BUS_DATE = %d{yyyyMMdd}
			GROUP BY CUST_NO )                 a6
 ON         t.CUST_NO = a6.CUST_NO
 LEFT JOIN (SELECT KHH as CUST_NO,SUM(JXJE) as ORDI_PLG_REPO_RTN_INT FROM EDW_PROD.T_EDW_T02_TZYHGLS
            WHERE  BUS_DATE = %d{yyyyMMdd}
			AND    JXRQ = %d{yyyyMMdd}
			GROUP BY CUST_NO
			)   a7
 ON        t.CUST_NO = a7.CUST_NO	
 LEFT JOIN (SELECT CUST_NO,SUM(CRD_ACCT_ADDED_GL_INT)  as CRD_MRGNC_MRGNS_PRDCT_INT
            FROM   DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS
            WHERE  BUS_DATE = %d{yyyyMMdd}
			GROUP BY CUST_NO )                 a8
 ON         t.CUST_NO = a8.CUST_NO
 LEFT JOIN (SELECT KHH as CUST_NO,SUM(DRGHLX) as CRD_MRGNC_MRGNS_RTN_INT FROM EDW_PROD.T_EDW_T05_TXY_FZXXLS
            WHERE  BUS_DATE = %d{yyyyMMdd}
			GROUP BY CUST_NO
			)   a9
 ON        t.CUST_NO = a9.CUST_NO 
WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_INR_ORG_BRH b
              WHERE  b.BUS_DATE = %d{yyyyMMdd}
			  AND   t.BRH_NO = b.BRH_NO
             )
AND   t.CUST_NO < > '100610335855'
AND COALESCE(a1.CUST_NO,a2.CUST_NO,a3.CUST_NO,a4.CUST_NO,a5.CUST_NO,a6.CUST_NO,a7.CUST_NO,a8.CUST_NO,a9.CUST_NO) IS NOT NULL 
;
 
----删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP  ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP2  ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP1  ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP3  ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY_TEMP4  ;
 
-----------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_CUST_TRD_INCM_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

 invalidate metadata DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY;
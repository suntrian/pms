/* ***************************************** SQL Begin *****************************************  */
/* 脚本功能:批量移行表                                                                      	  */
/* 创建人:黄勇华                                                                              	  */
/* 创建时间:2016-11-30                                                                        	  */ 
/* T_DDW_F05_CIF_CUST_OPE_DETAIL  修改为   T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS             */


--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_BTCH_MOV
( 
								 BRH_NO							 --营业部编号
								,BRH_NAME                        --营业部名称
								,OCC_BRH_NO                      --发生营业部
								,DT                              --日期
								,CUST_NO                         --客户号
								,CUST_NAME                       --客户姓名
								,BIZ_SBJ                         --业务科目
								,BIZ_SBJ_NAME                    --业务科目名称
								,ABST                            --摘要
								,OPRT_TELR                       --操作柜员
								,SECOND_CARD_VRFCTN              --二代证验证
								,OPRT_MOD                        --操作方式
                                    ,CTF_CGY                    --开户证件类别
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
								 t.BRH_NO					 AS BRH_NO							--营业部编号
								,t.BRH_NAME                  AS BRH_NAME                        --营业部名称
								,t.OCC_BRH_NO                AS OCC_BRH_NO                      --发生营业部
								,t.DT                        AS DT                              --日期
								,t.CUST_NO                   AS CUST_NO                         --客户号
								,t.CUST_NAME                 AS CUST_NAME                       --客户姓名
								,t.BIZ_SBJ                   AS BIZ_SBJ                         --业务科目
								,t.BIZ_SBJ_NAME              AS BIZ_SBJ_NAME                    --业务科目名称
								,t.ABST                      AS ABST                            --摘要
								,t.OPRT_TELR                 AS OPRT_TELR                       --操作柜员
								,t.SECOND_CARD_VRFCTN   	 AS SECOND_CARD_VRFCTN              --二代证验证
								,t.OPRT_MOD                  AS OPRT_MOD                        --操作方式
      				,a2.CTF_CGY_CD_NAME           AS   CTF_CGY  --开户证件类别
FROM  		DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS  	t
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a1
  ON            t.CUST_NO = a1.CUST_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD     a2
  ON            a1.CTF_CGY_CD = a2.CTF_CGY_CD
  WHERE 		t.bus_date = %d{yyyyMMdd}
  AND           t.BIZ_SBJ = '20329'
  AND           t.OPRT_MOD IN ('掌厅','指E通')
  ;
 
-----------------------------加载结束--------------------
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_BTCH_MOV',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_BTCH_MOV; 
 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360产品账户持仓明细表                                                          */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-10-27                                                                       */ 
  /* T_DDW_F02_PROD_HLD_DTL	替换为	T_DDW_F00_AST_PROD_HLD_DTL_HIS */
  /* T_DDW_F04_QOT	替换为	T_DDW_PUB_QOT */
  


---------------- 插入数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_PROD_ACCNT_HLD_DTL
 (
	 CUST_NO                   --客户号               
	,CUST_NAME                 --客户姓名        
	,BRH_NAME                  --营业部名称      
	,PROD_ACTNO                --产品账号
	,PROD_CD                   --产品代码
	,PROD_NAME                 --产品简称
	,CCY_CD_NAME               --币种代码
	,PROD_SHR_QTY              --份额数量
	,PROD_NEWST_MKTVAL         --产品最新市值
	,PROD_NAV                  --产品净值
	,PROD_CGY                  --产品来源
	,PROD_RSK_LVL              --产品风险等级
 )PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT      t.CUST_NO                as CUST_NO                   --客户号               
            ,t.CUST_NAME              as CUST_NAME                 --客户姓名        
            ,a1.JGMC                  as BRH_NAME                  --营业部名称      
            ,t.PROD_ACTNO             as PROD_ACTNO                --产品账号
            ,t.PROD_CD                as PROD_CD                   --产品代码
            ,t.PROD_NAME              as PROD_NAME                 --产品简称
            ,a4.CCY_CD_NAME           as CCY_CD_NAME               --币种代码
            ,t.PROD_SHR_QTY           as PROD_SHR_QTY              --份额数量
            ,t.PROD_NEWST_MKTVAL      as PROD_NEWST_MKTVAL         --产品最新市值
            ,NVL(a5.NEWST_PRC,1)      as PROD_NAV                  --产品净值
            ,DECODE(PROD_CGY,9,'金融产品',8,'场外基金')           as PROD_CGY                  --产品来源
            ,NULL                     as PROD_RSK_LVL              --产品风险等级
 FROM         DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS       t
 LEFT JOIN    EDW_PROD.T_EDW_T03_TJGGL             a1
 ON           t.BRH_NO = a1.JGDM
 AND          t.BUS_DATE = a1.BUS_DATE
 LEFT JOIN    DDW_PROD.V_CCY_CD                    a4
 ON           t.CCY_CD = a4.CCY_CD
 LEFT JOIN    DDW_PROD.T_DDW_PUB_QOT               a5
 ON          t.PROD_CD = a5.CD
 AND          a5.trd_mkt = 2
 AND          t.bus_date = a5.BUS_DATE 
 WHERE        t.BUS_DATE = %d{yyyyMMdd}
 
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_PROD_ACCNT_HLD_DTL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_PROD_ACCNT_HLD_DTL;
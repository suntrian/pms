 --/* ***************************************** SQL Begin ***************************************** */
 --/* 脚本功能:客户星级变动统计表                                                                   */
 --/* 创建人:oyj                                                                                    */
 --/* 创建时间:2017-11-05                                                                           */ 

INSERT OVERWRITE DDW_PROD.T_DDW_LM_CUST_STAR_LVL_CHG_STATS
(
 CUST_NO
,CUST_STAR_LVL_CD_LASTDAY
,CUST_STAR_LVL_DSC_LASTDAY
,CUST_STAR_LVL_CD_TDY
,CUST_STAR_LVL_DSC_TDY
,CUST_STAR_LVL_CHG_DSC
,CUST_STAR_VLD_DT
)
partition(BUS_DATE = %d{yyyyMMdd})
SELECT
       NVL(T1.CUST_NO,T2.CUST_NO) AS CUST_NO
	  ,T1.LABEL_VALUE AS CUST_STAR_LVL_CD_LASTDAY
	  ,T1.BIZ_DESC AS CUST_STAR_LVL_DSC_LASTDAY
	  ,T2.LABEL_VALUE AS CUST_STAR_LVL_CD_TDY
	  ,T2.BIZ_DESC AS CUST_STAR_LVL_DSC_TDY
	  ,CASE WHEN NVL(T1.LABEL_VALUE,'') < NVL(T2.LABEL_VALUE,'')
	        THEN '升级'
			WHEN NVL(T1.LABEL_VALUE,'') > NVL(T2.LABEL_VALUE,'')
			THEN '降级'
	   END AS CUST_STAR_LVL_CHG_DSC
	  ,NVL(T2.BIZ_TIME_RANGE_END,T1.BIZ_TIME_RANGE_END) AS CUST_STAR_VLD_DT
FROM
(
SELECT 
         A.CUST_NO
        ,A.LABEL_ID
        ,A.LABEL_VALUE
		,T.BIZ_DESC
		,A.BIZ_TIME_RANGE_END
FROM DDW_PROD.T_DDW_LM_LABEL_V_C_HIS A
LEFT JOIN DDW_PROD.T_DDW_LM_LABEL_DM T
ON A.LABEL_VALUE = T.LABEL_VALUE
AND T.LABEL_ID = '8d0fe69b4ff546f082775761d27c70a5'
WHERE EXISTS (SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE B
		                     WHERE  B.BUS_DATE = %d{yyyyMMdd}
							 AND    A.BUS_DATE = B.LST_TRD_D
							 AND    B.TRD_DT = %d{yyyyMMdd}
             )
AND A.LABEL_ID = '8d0fe69b4ff546f082775761d27c70a5'
) T1
FULL JOIN
(
SELECT 
         A.CUST_NO
        ,A.LABEL_ID
        ,A.LABEL_VALUE
		,T.BIZ_DESC
		,A.BIZ_TIME_RANGE_END
FROM DDW_PROD.T_DDW_LM_LABEL_V_C_HIS A
LEFT JOIN DDW_PROD.T_DDW_LM_LABEL_DM T
ON A.LABEL_VALUE = T.LABEL_VALUE
AND T.LABEL_ID = '8d0fe69b4ff546f082775761d27c70a5'
WHERE A.LABEL_ID = '8d0fe69b4ff546f082775761d27c70a5'
AND A.BUS_DATE = %d{yyyyMMdd}
) T2
ON T1.CUST_NO = T2.CUST_NO
AND T1.LABEL_ID = T2.LABEL_ID
WHERE NVL(T1.LABEL_VALUE,'') <> NVL(T2.LABEL_VALUE,'')
;


INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_LM_CUST_STAR_LVL_CHG_STATS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
invalidate metadata DDW_PROD.T_DDW_LM_CUST_STAR_LVL_CHG_STATS;
--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:：每日增量插入用户登录数据                                                                      */
  --/* 创建人:吴超洋                                                                            */
  --/* 创建时间:2017-05-26
  
    ----插入数据--
   INSERT OVERWRITE DDW_PROD.T_DDW_USER_LOGIN
 (          
              QSMC               ,     --券商名称
              YYBMC              ,     --营业部名称
              ZJZH               ,     --资金账户
              GDMC               ,     -- 股东名称
              CZRQ               ,     --操作日期
              CZSJ               ,     --操作时间
              CZZY               ,     --操作描述
              SJLY               ,     --数据来源
              IP                 ,     --IP地址
              MAC                ,     --MAC地址
              DISK               ,     --磁盘序列号
              IMEI               ,     --IMEI
              IMSI               ,     --IMSI
              MOBILE             ,     --手机号
              CLIENT             ,     --客户端
              UUID               ,     --UUID
              SERVER             ,     --服务器
              CZSJC                    --操作时间戳
 ) partition  (bus_date ) 
 SELECT  
              QSMC     ,     --券商名称
              YYBMC     ,     --营业部名称
              ZJZH     ,     --资金账户
              GDMC    ,     -- 股东名称
              t.CZRQ     ,     --操作日期
              CZSJ    ,     --操作时间
              CZZY    ,     --操作描述
              SJLY    ,     --数据来源
              IP    ,     --IP地址
              MAC    ,     --MAC地址
              DISK    ,     --磁盘序列号
              IMEI    ,     --IMEI
              IMSI    ,     --IMSI
              MOBILE    ,     --手机号
              CLIENT    ,     --客户端
              UUID    ,     --UUID
              SERVER    ,     --服务器
              CZSJC     ,    --操作时间戳
              CAST(t.CZRQ AS INT) AS BUS_DATE --操作日期
 FROM AIDER.USER_LOGIN t 
 WHERE t.CZRQ =  '%d{yyyyMMdd}'
 
 --WHERE t.CZRQ  >=(SELECT CAST(MAX(DISTINCT BUS_DATE) AS STRING ) FROM DDW_PROD.T_DDW_USER_LOGIN) 
----结束
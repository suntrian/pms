 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:机构客户信息表                                                                      */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 

  
  
  --删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORG_CUST_INFO_TEMP;
--创建临时表
  TRUNCATE TABLE DDW_PROD.T_DDW_PRT_ORG_CUST_INFO ;
  CREATE TABLE  DDW_PROD.T_DDW_PRT_ORG_CUST_INFO_TEMP AS
  SELECT 
                                    a1.BRH_NO                    as BRH_NO                                       --营业部编号                                               
                                   ,nvl(a2.BRH_SHRTNM,a5.FILIL_DEPT_SHRTNM)   as BRH_NAME                                     --营业部名称                                               
                                   ,a1.OPNAC_MOD                 as OPNAC_MOD                                    --开户方式                                                
                                   ,a1.ORDI_OPNAC_DT             as OPNAC_DT                                     --开户日期                                                                                     
                                   ,t.CUST_NO                    as CUST_NO                                      --客户号                                                 
                                   ,a1.CUST_NAME                 as CUST_NAME                                    --客户姓名                                                
                                   ,a1.CTF_CGY_CD                as CTF_CGY_CD                                   --证件类别代码                                              
                                   ,a1.CTF_NO                    as CTF_NO                                       --证件编号                                                
                                   ,t.CPTL_ATTR_CD               as CPTL_ATTR_CD                                 --资本属性代码                                              
                                   ,t.STOWN_ATTR_CD              as STOWN_ATTR_CD                                --国有属性代码                                              
                                   ,t.LSTD_ATTR_CD               as LSTD_ATTR_CD                                 --上市属性代码                                              
                                   ,t.LGLPSN_CGY_CD              as LGLPSN_CGY_CD                                --法人类别代码                                              
                                   ,t.ETP_CGY_CD                 as ETP_CGY_CD                                   --企业类别代码                                              
                                   ,t.IDSTR_CD                   as IDSTR_CD                                     --行业代码                                                
                                   ,a3.DLRMC                     as AGNT_NAME                                    --代理人姓名                                               
                                   ,t.LGLPSN_BHAF_NAME           as LGLPSN_BHAF_NAME                             --法人代表姓名                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
                                   ,t.ORG_CD_CTF                 as ORG_CD_CTF                                   --组织机构代码证                                          
                                   ,t.NTNLTAX_REGST_CTF          as NTNLTAX_REGST_CTF                            --国税登记证         
                                   ,t.TZX_REGST_CTF              as TZX_REGST_CTF                                --地税登记证         
                                   ,CASE WHEN t.CUST_NO = '105000009415'
								         THEN '实业投资；投资管理、投资咨询；资产管理及咨询；财务咨询．'
										 ELSE REGEXP_REPLACE(REGEXP_REPLACE(t.MG_SCP,chr(13),''),chr(10),'')   
										 END                     as MG_SCP                                       --经营范围                   
                                   ,a4.KZRMC                     as HOLD_SHRHLD_NAME                             --控股股东姓名    
                                   ,t.ORG_CUST_ORG_CGY           as ORG_CUST_ORG_CGY                             --机构客户机构类别
                                   ,t.PR_FND_ADMIN_NO            as PR_FND_ADMIN_NO                              --私募基金管理人编码
								   ,T.BUS_DATE
  FROM          DDW_PROD.T_DDW_F00_CUST_ORG_CUST_INFO                                 t      
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO                                   a1
  ON            t.CUST_NO = a1.CUST_NO
  AND           t.BUS_DATE = a1.BUS_DATE
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH a2
  ON            a1.BRH_NO = a2.BRH_NO
  AND           t.BUS_DATE = a2.BUS_DATE
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT a5
  ON             a1.BRH_NO = a5.FILIL_DEPT_CDG
  AND           t.BUS_DATE = a5.BUS_DATE
  LEFT JOIN ( SELECT  a.KHH
                     ,a.DLRID
	                 ,a.DLRMC
					 ,a.BUS_DATE
             FROM EDW_PROD.T_EDW_T01_TDLR a
             WHERE exists ( SELECT 1 
                            FROM (SELECT KHH,MAX(DLRID) AS ID ,BUS_DATE
							       FROM EDW_PROD.T_EDW_T01_TDLR GROUP BY KHH,BUS_DATE
						          ) b
            WHERE a.DLRID = b.ID AND a.BUS_DATE = b.BUS_DATE
                          )                                              --取出最近的代理人姓名
	        )                                                             a3
 ON              t.CUST_NO = a3.KHH
 AND          t.BUS_DATE = a3.BUS_DATE
 LEFT JOIN    ( SELECT a.KHH
                      ,a.JGKGID
		              ,a.KZRMC
					  ,a.BUS_DATE
                FROM  EDW_PROD.T_EDW_T02_TJGKGGD a
                WHERE exists ( SELECT 1 
                               FROM  ( SELECT KHH,MIN(JGKGID) AS ID,BUS_DATE 
							            FROM EDW_PROD.T_EDW_T02_TJGKGGD 
										GROUP BY KHH,BUS_DATE
									 ) b
                               WHERE a.JGKGID = b.id AND a.BUS_DATE = b.BUS_DATE
                              )
               )                                                           a4
 ON           t.CUST_NO = a4.KHH                                                      --取出最近的控制股东姓名
 AND          t.BUS_DATE = a4.BUS_DATE 
 WHERE        t.BUS_DATE = %d{yyyyMMdd} ;

 ---
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORG_CUST_INFO_TEMP1;
 CREATE TABLE  DDW_PROD.T_DDW_PRT_ORG_CUST_INFO_TEMP1 AS
 SELECT COALESCE(a.CID,b.CID,c.CID) as CID
        ,a.SYRXM
		,b.GGXM
		,c.GDMC
 FROM
 (SELECT cast(CID AS INT) as CID,ID,SYRXM,ROW_NUMBER() OVER(PARTITION BY CID ORDER BY ID ) as NUM  FROM YGTCX.CIF_TJGSYSYR
 WHERE DT = '%d{yyyyMMdd}'
 AND NVL(SYRZJJZRQ,99999999) > %d{yyyyMMdd}

 ) a
 FULL JOIN
 (SELECT cast(a.CID AS INT) as CID,b.ID,b.GGXM, ROW_NUMBER() OVER(PARTITION BY a.CID ORDER BY b.ID ) as NUM
  FROM (SELECT CID,GGXXID FROM YGTCX.CIF_TJGGGXX WHERE DT = '%d{yyyyMMdd}') a
  LEFT JOIN (SELECT ID,GGXM FROM YGTCX.CIF_TGGXX WHERE DT = '%d{yyyyMMdd}' AND NVL(ZJJZRQ,99999999) > %d{yyyyMMdd} ) b
  ON a.GGXXID = b.ID
  WHERE b.ID IS NOT NULL) b
  ON a.CID =b.CID
  AND  b.NUM = 1
  FULL JOIN
  (SELECT cast(a.CID AS INT) AS cid,b.ID,b.GDMC, ROW_NUMBER() OVER(PARTITION BY a.CID ORDER BY b.ID ) as num
  FROM (SELECT CID,gdxxid FROM YGTCX.CIF_TJGGDXX WHERE DT = '%d{yyyyMMdd}') a
  LEFT JOIN (SELECT ID,GDMC FROM YGTCX.CIF_TGDXX WHERE DT = '%d{yyyyMMdd}' AND NVL(ZJJZRQ,99999999) > %d{yyyyMMdd} ) b
  ON a.gdxxid = b.ID
  WHERE b.ID IS NOT NULL) c
  ON NVL(a.CID,b.CID) = c.CID
  AND  c.NUM = 1
 WHERE a.NUM = 1 ;

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_ORG_CUST_INFO
(        
								 BRH_NO                     --营业部编号      
								,BRH_NAME                   --营业部名称      
								,OPNAC_MOD                  --开户方式        
								,OPNAC_DT                   --开户日期        
								,CUST_NO                    --客户号          
								,CUST_NAME                  --客户姓名        
								,CTF_CGY_CD                 --证件类别代码    
								,CTF_NO                     --证件号码        
								,AGNT_NAME                  --代理人姓名      
								,LGLPSN_BHAF_NAME           --法人代表姓名    
								,DEPMGT_BANK                --存管银行        
								,CTRL_ATTR                  --控制属性        
								,M_LAUND_RSK_LVL            --洗钱风险等级    
								,IMAGE_TP                   --影像资料        
								,RSK_BEAR_ABLTY             --风险承受能力
                                ,FRIST_EVAL_DT	            --初次评测日期								
								,CTCT_ADDR                  --联系地址        
								,CTCT_TEL                   --联系电话        
								,PHONE                      --手机            
								,ORG_CD_CTF                 --组织机构代码    
								,NTNLTAX_REGST_CTF          --国税登记证      
								,TZX_REGST_CTF              --地税登记证      
								,MG_SCP                     --经营范围
								,HOLD_SHRHLD_NAME           --控股股东姓名  
                                ,CMSN_SETUP_DT              --佣金设置日期
                                ,CMSN_SETUP_ABST            --佣金设置摘要								   
								,IF_OPN_PHONE_ODR           --是否开通手机委托
								,IF_PR_FND_ADMIN            --是否为私募基金管理人
								,PR_FND_ADMIN_NO            --私募基金管理人编码
								,FCT_CTRL_PSN               --实际控制人
                                ,FCT_YLD_PSN			    --实际收益人
								,TOT_AST                      --净总资产	
								,YLD_PSN_INFO                --受益人信息(反识)
								,EXCTV_INFO                  --高管信息(反识)
								,SHRHLD_INFO                 --股东信息(反识)
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
					 a1.BRH_NO                                       AS  BRH_NO                       --营业部编号      
					,a1.BRH_NAME                                     AS  BRH_NAME                     --营业部名称      
					,b1.OPNAC_MOD_NAME                               AS  OPNAC_MOD                    --开户方式        
					,a1.OPNAC_DT                                     AS  OPNAC_DT                     --开户日期        
					,a1.CUST_NO                                      AS  CUST_NO                      --客户号          
					,a2.KHMC                                         AS  CUST_NAME                    --客户姓名        
					,b2.CTF_CGY_CD_NAME                              AS  CTF_CGY_CD                   --证件类别代码    
					,a1.CTF_NO                                       AS  CTF_NO                       --证件号码        
					,a1.AGNT_NAME                                    AS  AGNT_NAME                    --代理人姓名      
					,a1.LGLPSN_BHAF_NAME                             AS  LGLPSN_BHAF_NAME             --法人代表姓名    
					,t.DEPMGT_BANK                                   AS  DEPMGT_BANK                  --存管银行        
					,t.CTRL_ATTR                                     AS  CTRL_ATTR                    --控制属性        
					,b6.M_LAUND_RSK_LVL_name                               AS  M_LAUND_RSK_LVL              --洗钱风险等级       
					,t.IMAGE_TP                                      AS  IMAGE_TP                     --影像资料        
					,b3.RSK_BEAR_ABLTY_NAME                                AS  RSK_BEAR_ABLTY               --风险承受能力 
                    ,t.FRIST_EVAL_DT	             	             AS  FRIST_EVAL_DT                --初次评测日期					
					,t.CTCT_ADDR                                     AS  CTCT_ADDR                    --联系地址        
					,t.CTCT_TEL                                      AS  CTCT_TEL                     --联系电话        
					,t.PHONE                                         AS  PHONE                        --手机            
					,a1.ORG_CD_CTF                                   AS  ORG_CD_CTF                   --组织机构代码    
					,a1.NTNLTAX_REGST_CTF                            AS  NTNLTAX_REGST_CTF            --国税登记证      
					,a1.TZX_REGST_CTF                                AS  TZX_REGST_CTF                --地税登记证      
					,a1.MG_SCP                                       AS  MG_SCP                       --经营范围 					
					,a1.HOLD_SHRHLD_NAME                             AS  HOLD_SHRHLD_NAME             --控股股东姓名
                    ,t.CMSN_SETUP_DT                                 AS  CMSN_SETUP_DT                 --佣金设置日期
                    ,t.CMSN_SETUP_ABST                               AS  CMSN_SETUP_ABST               --佣金设置摘要							
					,t.IF_OPN_PHONE_ODR                              AS  IF_OPN_PHONE_ODR             --是否开通手机委托
					,CASE WHEN a1.ORG_CUST_ORG_CGY = '25'
					      THEN '是'
						  ELSE '否'  
						  END                                        AS  IF_PR_FND_ADMIN            --是否为私募基金管理人
				    ,a1.PR_FND_ADMIN_NO                              AS  PR_FND_ADMIN_NO            --私募基金管理人编码
                    ,a4.SJKZR                                        AS  FCT_CTRL_PSN                       --实际控制人
                    ,a4.SJSYR                                        AS  FCT_YLD_PSN			              --实际收益人					
                    ,NVL(a5.TOT_AST,0)   as TOT_AST                      --净总资产	
					,a6.syrxm                                     as YLD_PSN_INFO                --受益人信息(反识)
					,a6.ggxm                                      as EXCTV_INFO                  --高管信息(反识)
					,a6.gdmc                                      as SHRHLD_INFO                 --股东信息(反识)
					
  FROM           DDW_PROD.T_DDW_F00_CUST_CUST_INFO        t
  LEFT JOIN      DDW_PROD.T_DDW_PRT_ORG_CUST_INFO_TEMP  a1
  ON             t.CUST_NO = a1.CUST_NO
  AND            t.BUS_DATE = a1.BUS_DATE
  LEFT JOIN     	DDW_PROD.V_OPNAC_MOD			                      b1
  ON            	t.OPNAC_MOD = b1.OPNAC_MOD 
  LEFT JOIN     	DDW_PROD.V_CTF_CGY_CD			                      b2
  ON            	t.CTF_CGY_CD = b2.CTF_CGY_CD   
  LEFT JOIN     	DDW_PROD.V_RSK_BEAR_ABLTY                          	  b3
  ON            	t.RSK_BEAR_ABLTY = b3.RSK_BEAR_ABLTY  
  LEFT JOIN         YGTCX.CIF_TKHXX                                       a2
  ON                t.CUST_NO = a2.KHH
  AND               a2.KHLB = 1
  AND               a2.DT = '%d{yyyyMMdd}'
  LEFT JOIN  DDW_PROD.V_M_LAUND_RSK_LVL            b6
  ON         t.M_LAUND_RSK_LVL = b6.M_LAUND_RSK_LVL
  LEFT JOIN  EDW_PROD.T_EDW_T99_TKHYWSX                        a4
  ON         t.CUST_NO = a4.KHH
  and        a4.bus_date = %d{yyyyMMdd}
  LEFT JOIN  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY       a5
  ON         t.CUST_NO = a5.CUST_NO 
  AND        a5.bus_date = %d{yyyyMMdd} 
  LEFT JOIN  DDW_PROD.T_DDW_PRT_ORG_CUST_INFO_TEMP1  a6
  ON        CAST(t.CID as INT) = a6.CID
  WHERE 		 t.bus_date = %d{yyyyMMdd}
  AND            t.ORDI_CUST_STAT <> '3'
  AND            t.CUST_RSK_LVL IN ('0','1','2','8','19')
  AND            t.CUST_CGY = '1'
  ;
  ------结束----
  
  
  --删除临时表 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORG_CUST_INFO_TEMP; 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORG_CUST_INFO_TEMP1;

  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_ORG_CUST_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_ORG_CUST_INFO;
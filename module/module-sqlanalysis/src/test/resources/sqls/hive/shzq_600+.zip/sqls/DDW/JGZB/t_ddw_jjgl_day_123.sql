 --/* ***************************************** SQL Begin *****************************************  */
  --/* 脚本功能:经纪管理指标营业部汇总表                                                                    */
  --/* 创建人: 李昱均                                                                      */
  --/* 创建时间:2019-11-13                                                                        */ 


DROP TABLE IF EXISTS ddw_prod.t_ddw_jjgl_day_123;
CREATE TABLE ddw_prod.t_ddw_jjgl_day_123
AS
SELECT belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date
FROM ddw_prod.t_ddw_jjgl_day
WHERE 1=2
;

----1."客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CUST_VOL' as zbm,CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;	

----2."交易客户客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'TRD_CUST_VOL' as zbm,TRD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----3."新增有效客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'ADDED_VLD_CUST_VOL' as zbm,ADDED_VLD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----4."新增存量有效客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'ADDED_OLD_VLD_CUST_VOL' as zbm,ADDED_OLD_VLD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----5."信用客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CRD_CUST_VOL' as zbm,CRD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----6."交易信用客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'TRD_CRD_CUST_VOL' as zbm,TRD_CRD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----7."港股通客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'H_K_CUST_VOL' as zbm,H_K_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----8."交易港股通客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'TRD_H_K_CUST_VOL' as zbm,TRD_H_K_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----9."期权客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WRNT_CUST_VOL' as zbm,WRNT_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----10."交易期权客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'TRD_WRNT_CUST_VOL' as zbm,TRD_WRNT_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----11."科创板客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STIB_CUST_VOL' as zbm,STIB_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----12."新三板客户数(受限制+非受限制,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'NEW_T3BOD_CUST_VOL' as zbm,NEW_T3BOD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----13."交易新三板客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'TRD_NWE_T3BOD_CUST_VOL' as zbm,TRD_NWE_T3BOD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----14."三板客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'T3BOD_CUST_VOL' as zbm,T3BOD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----15."质押回购客户数(股票质押,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'PLG_REPO_CUST_VOL' as zbm,PLG_REPO_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----16."股票质押客户数(小微贷,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STK_PLG_CUST_VOL' as zbm,STK_PLG_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----17."交易质押回购客户数(股票质押,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'TRD_PLG_REPO_CUST_VOL' as zbm,TRD_PLG_REPO_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;


----18."交易股票质押客户数(小微贷,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'TRD_STK_PLG_CUST_VOL' as zbm,TRD_STK_PLG_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----19."分级基金客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STR_FND_CUST_VOL' as zbm,STR_FND_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----20."产品客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'PROD_CUST_VOL' as zbm,PROD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----21."内部PB账户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'INR_PB_CUST_VOL' as zbm,INR_PB_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----22."外部PB账户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'EXTN_PB_CUST_VOL' as zbm,EXTN_PB_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----23."现金添利客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CASH_PROD_CUST_VOL' as zbm,CASH_PROD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----24."合格客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'QLFD_CUST_VOL' as zbm,QLFD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----25."经纪关系合格客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'BROK_RLN_QLFD_CUST_VOL' as zbm,BROK_RLN_QLFD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----26."强服务关系合格客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STRONG_SVC_RLN_QLFD_CUST_VOL' as zbm,STRONG_SVC_RLN_QLFD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----27."弱服务关系合格客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WEAK_SVC_RLN_QLFD_CUST_VOL' as zbm,WEAK_SVC_RLN_QLFD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----28."经纪关系客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'BROK_RLN_CUST_VOL' as zbm,BROK_RLN_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----29."强服务关系客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STRONG_SVC_RLN_CUST_VOL' as zbm,STRONG_SVC_RLN_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----30."弱服务关系客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WEAK_SVC_RLN_CUST_VOL' as zbm,WEAK_SVC_RLN_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----31."开户数(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'OPNAC_CUST_VOL' as zbm,OPNAC_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----32."开户信用客户数(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'OPNAC_CRD_CUST_VOL' as zbm,OPNAC_CRD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----33."开户期权客户数(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'OPNAC_WRNT_CUST_VOL' as zbm,OPNAC_WRNT_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----34."开通科创板客户数(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'OPN_STIB_CUST_VOL' as zbm,OPN_STIB_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----35."开通质押回购客户数(股票质押,bus_date)(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'OPN_PLG_REPO_CUST_VOL' as zbm,OPN_PLG_REPO_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----36."开通股票质押客户数(小微贷,bus_date)(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'OPN_STK_PLG_CUST_VOL' as zbm,OPN_STK_PLG_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----37."开通分级基金客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'OPN_STR_FND_CUST_VOL' as zbm,OPN_STR_FND_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----38."开通新三板客户数(受限制当日+非受限制当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'OPN_NEW_T3BOD_CUST_VOL' as zbm,OPN_NEW_T3BOD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----39."开通三板客户数(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'OPN_T3BOD_CUST_VOL' as zbm,OPN_T3BOD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----40."开户内部PB客户数(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'OPNAC_INR_PB_CUST_VOL' as zbm,OPNAC_INR_PB_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----41."销户数(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CNCLACT_CUST_VOL' as zbm,CNCLACT_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----42."销户信用客户数(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CNCLACT_CRD_CUST_VOL' as zbm,CNCLACT_CRD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----43."销户期权客户数(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CNCLACT_WRNT_CUST_VOL' as zbm,CNCLACT_WRNT_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----44."关闭科创板客户数(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CLS_STIB_CUST_VOL' as zbm,CLS_STIB_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----45."关闭港股通客户数(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CLS_H_K_CUST_VOL' as zbm,CLS_H_K_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----46."关闭质押回购客户数(股票质押,bus_date)(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CLS_PLG_REPO_CUST_VOL' as zbm,CLS_PLG_REPO_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----47."关闭股票质押客户数(小微贷,bus_date)(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CLS_STK_PLG_CUST_VOL' as zbm,CLS_STK_PLG_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----48."关闭分级基金客户数"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CLS_STR_FND_CUST_VOL' as zbm,CLS_STR_FND_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----49."关闭新三板客户数(受限制当日+非受限制当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CLS_NEW_T3BOD_CUST_VOL' as zbm,CLS_NEW_T3BOD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----50."关闭三板客户数(当日,bus_date)"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CLS_T3BOD_CUST_VOL' as zbm,CLS_T3BOD_CUST_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----51."客户总资产"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CUST_TOT_AST' as zbm,CUST_TOT_AST as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----52."客户净资产"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CUST_NET_TOT_AST' as zbm,CUST_NET_TOT_AST as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----53."经纪关系净资产"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'BROK_RLN_CUST_NET_TOT_AST' as zbm,BROK_RLN_CUST_NET_TOT_AST as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----54."强服务关系净资产"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STRONG_SVC_CUST_NET_TOT_AST' as zbm,STRONG_SVC_CUST_NET_TOT_AST as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----55."弱服务关系净资产"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WEAK_SVC_CUST_NET_TOT_AST' as zbm,WEAK_SVC_CUST_NET_TOT_AST as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----56."新开户净资产"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'NEW_OPNAC_NET_TOT_AST' as zbm,NEW_OPNAC_NET_TOT_AST as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----57."新增有效户净资产"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'ADDED_VLD_NET_TOT_AST' as zbm,ADDED_VLD_NET_TOT_AST as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----58."存量有效户净资产"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'ADDED_OLD_VLD_NET_TOT_AST' as zbm,ADDED_OLD_VLD_NET_TOT_AST as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----59."资产净流入"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'NET_TFR_IN_AST' as zbm,NET_TFR_IN_AST as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----60."股票交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STK_TRD_VOL' as zbm,STK_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----61."经纪关系股票交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'BROK_RLN_STK_TRD_VOL' as zbm,BROK_RLN_STK_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----62."强服务关系股票交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STRONG_SVC_STK_TRD_VOL' as zbm,STRONG_SVC_STK_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----63."弱服务关系股票交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WEAK_SVC_STK_TRD_VOL' as zbm,WEAK_SVC_STK_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----64."基金交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'FND_TRD_VOL' as zbm,FND_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----65."经纪关系基金交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'BROK_RLN_FND_TRD_VOL' as zbm,BROK_RLN_FND_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----66."强服务关系基金交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STRONG_SVC_FND_TRD_VOL' as zbm,STRONG_SVC_FND_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----67."弱服务关系基金交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WEAK_SVC_FND_TRD_VOL' as zbm,WEAK_SVC_FND_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----68."港股通交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'H_K_TRD_VOL' as zbm,H_K_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----69."经纪关系港股通交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'BROK_RLN_H_K_TRD_VOL' as zbm,BROK_RLN_H_K_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----70."强服务关系港股通交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STRONG_SVC_H_K_TRD_VOL' as zbm,STRONG_SVC_H_K_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----71."弱服务关系港股通交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WEAK_SVC_H_K_TRD_VOL' as zbm,WEAK_SVC_H_K_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----72."新三板交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'NEW_T3BOD_TRD_VOL' as zbm,NEW_T3BOD_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----73."经纪关系新三板交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'BROK_RLN_NEW_T3BOD_TRD_VOL' as zbm,BROK_RLN_NEW_T3BOD_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----74."强服务关系新三板交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STRONG_SVC_NEW_T3BOD_TRD_VOL' as zbm,STRONG_SVC_NEW_T3BOD_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----75."弱服务关系新三板交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WEAK_SVC_NEW_T3BOD_TRD_VOL' as zbm,WEAK_SVC_NEW_T3BOD_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----76."融资融券交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CRD_TRD_VOL' as zbm,CRD_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----77."经纪关系融资融券交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'BROK_RLN_CRD_TRD_VOL' as zbm,BROK_RLN_CRD_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----78."强服务关系融资融券交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STRONG_SVC_RLN_CRD_TRD_VOL' as zbm,STRONG_SVC_RLN_CRD_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----79."弱服务关系融资融券交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WEAK_SVC_RLN_CRD_TRD_VOL' as zbm,WEAK_SVC_RLN_CRD_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----80."当日新增融资利息"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'TDY_ADDED_MRGNC_INT' as zbm,TDY_ADDED_MRGNC_INT as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----81."当日新增融券利息"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'TDY_ADDED_MRGNS_INT' as zbm,TDY_ADDED_MRGNS_INT as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----82."股票质押余额"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STK_PLG_AMT' as zbm,STK_PLG_AMT as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----83."股票质押新增利息"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STK_PLG_ADD_INT' as zbm,STK_PLG_ADD_INT as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----84."股票质押初始交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STK_PLG_ADD_TRD_AMT' as zbm,STK_PLG_ADD_TRD_AMT as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----85."小微贷余额"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'MIN_STK_PLG_AMT' as zbm,MIN_STK_PLG_AMT as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----86."小微贷新增利息"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'MIN_STK_PLG_ADD_INT' as zbm,MIN_STK_PLG_ADD_INT as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd};

----87."小微贷初始交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'MIN_STK_PLG_ADD_TRD_AMT' as zbm,MIN_STK_PLG_ADD_TRD_AMT as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----88."股票净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STK_NET_S1' as zbm,STK_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----89."经纪关系股票净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'BROK_RLN_STK_NET_S1' as zbm,BROK_RLN_STK_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----90."强服务关系股票净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STRONG_SVC_STK_NET_S1' as zbm,STRONG_SVC_STK_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----91."弱服务关系股票净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WEAK_SVC_STK_NET_S1' as zbm,WEAK_SVC_STK_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----92."基金净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'FND_NET_S1' as zbm,FND_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----93."经纪关系基金净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'BROK_RLN_FND_NET_S1' as zbm,BROK_RLN_FND_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----94."强服务关系基金净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STRONG_SVC_FND_NET_S1' as zbm,STRONG_SVC_FND_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----95."弱服务关系基金净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WEAK_SVC_FND_NET_S1' as zbm,WEAK_SVC_FND_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----96."港股通净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'H_K_NET_S1' as zbm,H_K_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----97."经纪关系港股通净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'BROK_RLN_H_K_NET_S1' as zbm,BROK_RLN_H_K_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----98."强服务关系港股通净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STRONG_SVC_H_K_NET_S1' as zbm,STRONG_SVC_H_K_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----99."弱服务关系港股通净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WEAK_SVC_H_K_NET_S1' as zbm,WEAK_SVC_H_K_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----100."新三板净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'NEW_T3BOD_NET_S1' as zbm,NEW_T3BOD_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----101."经纪关系新三板净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'BROK_RLN_NEW_T3BOD_NET_S1' as zbm,BROK_RLN_NEW_T3BOD_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----102."强服务关系新三板净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'STRONG_SVC_NEW_T3BOD_NET_S1' as zbm,STRONG_SVC_NEW_T3BOD_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----103."弱服务关系新三板净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'WEAK_SVC_NEW_T3BOD_NET_S1' as zbm,WEAK_SVC_NEW_T3BOD_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----104."资金余额"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'CPTL_BAL' as zbm,CPTL_BAL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----105."A股票市值"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'A_STK_MKTVAL' as zbm,A_STK_MKTVAL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----106."B股票市值"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'B_STK_MKTVAL' as zbm,B_STK_MKTVAL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----107."港股股票市值"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'H_K_STK_MKTVAL' as zbm,H_K_STK_MKTVAL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----108."交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'TRD_VOL' as zbm,TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----109."净佣金收入"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'NET_S1_INCM' as zbm,NET_S1_INCM as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----110."息费收入"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'INT_INCM' as zbm,INT_INCM as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----111."A股净佣金"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'A_STK_NET_S1' as zbm,A_STK_NET_S1 as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----112."A股交易量"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'A_STK_TRD_VOL' as zbm,A_STK_TRD_VOL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----113."融资余额"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'MRGNC_CPTL_BAL' as zbm,MRGNC_CPTL_BAL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----114."融券余额"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'MRGNS_CPTL_BAL' as zbm,MRGNS_CPTL_BAL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----115."融资融券余额"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg,belto_filil,brh_no,brh_fullnm
,cust_star,'rzrqye' as zbm,MRGNC_CPTL_BAL+MRGNS_CPTL_BAL as zbz,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd}
;

----116."客户数_年限_五年以上"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_seniority_5_100' as zbm
	,sum(case when khnx>=5 then 1 
			 else 0 end) as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			floor((c.bus_date-aa.OPNAC_DT)/10000) as khnx 
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----117."客户数_年限_一到五年"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_seniority_1_5' as zbm
	,sum(case when khnx>=1 and khnx<5 then 1
			else	0 end) as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			floor((c.bus_date-aa.OPNAC_DT)/10000) as khnx 
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----118."客户数_年限_一年以内"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_seniority_0_1' as zbm
	,sum(case when khnx<1 and khnx>=0 then 1
			else 0 end) as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			floor((c.bus_date-aa.OPNAC_DT)/10000) as khnx 
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----119."客户数_性别_男"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_male' as zbm
	,sum(case when GNDR_CD='1' then 1
			else 0 end)   as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			GNDR_CD
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----120."客户数_性别_女"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_female' as zbm
	,sum(case when GNDR_CD='2' then 1
			else 0 end)   as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			GNDR_CD
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----121."客户数_年龄_25岁以下"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_age_0_25' as zbm
	,sum(case when AGE<=25 and AGE>=0 then 1
			else 0 end)   as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			AGE
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----122."客户数_年龄_26到35岁"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_age_26_35' as zbm
	,sum(case when AGE<=35 and AGE>=26 then 1
			else 0 end)    as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			AGE
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----123."客户数_年龄_36到45岁"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_age_36_45' as zbm
	,sum(case when AGE<=45 and AGE>=36 then 1
			else 0 end)     as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			AGE
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----124."客户数_年龄_46到60岁"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_age_46_60' as zbm
	,sum(case when AGE<=60 and AGE>=46 then 1
			else 0 end) 	as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			AGE
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----125."客户数_年龄_61岁以上"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_age_61_100' as zbm
	,sum(case when AGE<=60 and AGE>=46 then 1
			else 0 end) 	as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			AGE
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----126."客户数_学历_高中以下"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_edu_gzyx' as zbm
	,sum(case when EDU='高中以下' then 1
			else 0 end)  	as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			case when EDU_CD in('1','2') then '研究生以上'
				 when EDU_CD in('3') then '本科'
				 when EDU_CD in('4') then '大专'
				 when EDU_CD in('5','6','7') then '高中以下'
				 else '其他' end as EDU
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----127."客户数_学历_大专"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_edu_dz' as zbm
	,sum(case when EDU='大专' then 1	
			else 0 end)  	as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			case when EDU_CD in('1','2') then '研究生以上'
				 when EDU_CD in('3') then '本科'
				 when EDU_CD in('4') then '大专'
				 when EDU_CD in('5','6','7') then '高中以下'
				 else '其他' end as EDU
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----128."客户数_学历_本科"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_edu_bk' as zbm
	,sum(case when EDU='本科' then 1
			else 0 end)   	as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			case when EDU_CD in('1','2') then '研究生以上'
				 when EDU_CD in('3') then '本科'
				 when EDU_CD in('4') then '大专'
				 when EDU_CD in('5','6','7') then '高中以下'
				 else '其他' end as EDU
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date = %d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----128."客户数_学历_研究生以上"
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    ac.belto_filil_cdg as belto_filil_cdg
	,ac.belto_filil as belto_filil
	,ac.brh_no as brh_no
	,ac.brh_fullnm as brh_fullnm
	,ab.cust_star as cust_star
	,'cust_vol_edu_yjsys' as zbm
	,sum(case when EDU='研究生以上' then 1
			else 0 end)  	as zbz
	,%d{yyyyMMdd} as bus_date
from (
		select
			aa.brh_no,
			aa.cust_star,
			c.bus_date,
			case when EDU_CD in('1','2') then '研究生以上'
				 when EDU_CD in('3') then '本科'
				 when EDU_CD in('4') then '大专'
				 when EDU_CD in('5','6','7') then '高中以下'
				 else '其他' end as EDU
		FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu aa
		left join 
		(
		select distinct brh_no,bus_date from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
		)c
		on aa.brh_no=c.brh_no
		where aa.CUST_STAT <> '3'
		AND aa.CUST_RSK_LVL IN ('0','1','2','8','19')
	 )ab
left join ddw_prod.t_ddw_inr_org_brh_KUDU ac
on ab.brh_no = ac.brh_no
where cust_star is not null and cust_star <> 'NULL'
and ab.bus_date=%d{yyyyMMdd}
group by ac.belto_filil,ac.belto_filil_cdg,ac.brh_no,ac.brh_fullnm,ab.cust_star
;

----129.客户数_投资偏好_纯交易客户
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,case when a.cust_star='0' then '一星客户'
	     when a.cust_star='1' then '二星客户'
	     when a.cust_star='2' then '三星客户'
	     when a.cust_star='3' then '四星客户'
	     when a.cust_star='4' then '五星客户'
	     when a.cust_star='5' then '六星客户'
	     else '七星客户' end as cust_star
	,case when b.inv_pref='0' then 'cust_vol_tzph_cjykh'
		 end as zbm
	,count(1) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	select cust_no,
       	  label_value as cust_star
	from ddw_prod.t_ddw_lm_label_v_c_his
	where bus_date=%d{yyyyMMdd}
  	  and label_id ='8d0fe69b4ff546f082775761d27c70a5'
  	)a,
  	(
	select cust_no,
       	  label_value as inv_pref
	from ddw_prod.t_ddw_lm_label_v_c_his
	where bus_date=%d{yyyyMMdd}
	and label_value='0'
  	and label_id ='8b6c8a85b0014e8384a884a8f8ceb7ee'
  	)b,
	(
	select cust_no,
		  brh_no 
	from ddw_prod.t_ddw_f00_cust_cust_info 
    where bus_date=%d{yyyyMMdd}
    )c,
    ddw_prod.t_ddw_inr_org_brh_kudu d
where a.cust_no=b.cust_no
  and a.cust_no=c.cust_no
  and c.brh_no=d.brh_no
  and a.cust_star in('0','1','2','3','4','5','6')
  and b.inv_pref in('0','1','2','3','4')
group by 	d.belto_filil_cdg,
          d.belto_filil,
		d.brh_no,
		d.brh_fullnm,
		a.cust_star,
		b.inv_pref
order by 	d.belto_filil_cdg,
          d.belto_filil,
		d.brh_no,
		d.brh_fullnm,
		a.cust_star,
		b.inv_pref
;

----130.客户数_投资偏好_纯理财客户
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,case when a.cust_star='0' then '一星客户'
	     when a.cust_star='1' then '二星客户'
	     when a.cust_star='2' then '三星客户'
	     when a.cust_star='3' then '四星客户'
	     when a.cust_star='4' then '五星客户'
	     when a.cust_star='5' then '六星客户'
	     else '七星客户' end as cust_star
	,case when b.inv_pref='1' then 'cust_vol_tzph_clckh'
		 end as zbm
	,count(1) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	select cust_no,
       	  label_value as cust_star
	from ddw_prod.t_ddw_lm_label_v_c_his
	where bus_date=%d{yyyyMMdd}
  	  and label_id ='8d0fe69b4ff546f082775761d27c70a5'
  	)a,
  	(
	select cust_no,
       	  label_value as inv_pref
	from ddw_prod.t_ddw_lm_label_v_c_his
	where bus_date=%d{yyyyMMdd}
	and label_value='1'
  	and label_id ='8b6c8a85b0014e8384a884a8f8ceb7ee'
  	)b,
	(
	select cust_no,
		  brh_no 
	from ddw_prod.t_ddw_f00_cust_cust_info 
    where bus_date=%d{yyyyMMdd}
    )c,
    ddw_prod.t_ddw_inr_org_brh_kudu d
where a.cust_no=b.cust_no
  and a.cust_no=c.cust_no
  and c.brh_no=d.brh_no
  and a.cust_star in('0','1','2','3','4','5','6')
  and b.inv_pref in('0','1','2','3','4')
group by 	d.belto_filil_cdg,
          d.belto_filil,
		d.brh_no,
		d.brh_fullnm,
		a.cust_star,
		b.inv_pref
order by 	d.belto_filil_cdg,
          d.belto_filil,
		d.brh_no,
		d.brh_fullnm,
		a.cust_star,
		b.inv_pref
;

----131.客户数_投资偏好_配置型客户
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,case when a.cust_star='0' then '一星客户'
	     when a.cust_star='1' then '二星客户'
	     when a.cust_star='2' then '三星客户'
	     when a.cust_star='3' then '四星客户'
	     when a.cust_star='4' then '五星客户'
	     when a.cust_star='5' then '六星客户'
	     else '七星客户' end as cust_star
	,case when b.inv_pref='2' then 'cust_vol_tzph_pzxkh'
		 end as zbm
	,count(1) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	select cust_no,
       	  label_value as cust_star
	from ddw_prod.t_ddw_lm_label_v_c_his
	where bus_date=%d{yyyyMMdd}
  	  and label_id ='8d0fe69b4ff546f082775761d27c70a5'
  	)a,
  	(
	select cust_no,
       	  label_value as inv_pref
	from ddw_prod.t_ddw_lm_label_v_c_his
	where bus_date=%d{yyyyMMdd}
	and label_value='2'
  	and label_id ='8b6c8a85b0014e8384a884a8f8ceb7ee'
  	)b,
	(
	select cust_no,
		  brh_no 
	from ddw_prod.t_ddw_f00_cust_cust_info 
    where bus_date=%d{yyyyMMdd}
    )c,
    ddw_prod.t_ddw_inr_org_brh_kudu d
where a.cust_no=b.cust_no
  and a.cust_no=c.cust_no
  and c.brh_no=d.brh_no
  and a.cust_star in('0','1','2','3','4','5','6')
  and b.inv_pref in('0','1','2','3','4')
group by 	d.belto_filil_cdg,
          d.belto_filil,
		d.brh_no,
		d.brh_fullnm,
		a.cust_star,
		b.inv_pref
order by 	d.belto_filil_cdg,
          d.belto_filil,
		d.brh_no,
		d.brh_fullnm,
		a.cust_star,
		b.inv_pref
;

----132.客户数_投资偏好_小额资金客户
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,case when a.cust_star='0' then '一星客户'
	     when a.cust_star='1' then '二星客户'
	     when a.cust_star='2' then '三星客户'
	     when a.cust_star='3' then '四星客户'
	     when a.cust_star='4' then '五星客户'
	     when a.cust_star='5' then '六星客户'
	     else '七星客户' end as cust_star
	,case when b.inv_pref='3' then 'cust_vol_tzph_xezjkh'
		 end as zbm
	,count(1) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	select cust_no,
       	  label_value as cust_star
	from ddw_prod.t_ddw_lm_label_v_c_his
	where bus_date=%d{yyyyMMdd}
  	  and label_id ='8d0fe69b4ff546f082775761d27c70a5'
  	)a,
  	(
	select cust_no,
       	  label_value as inv_pref
	from ddw_prod.t_ddw_lm_label_v_c_his
	where bus_date=%d{yyyyMMdd}
	and label_value='3'
  	and label_id ='8b6c8a85b0014e8384a884a8f8ceb7ee'
  	)b,
	(
	select cust_no,
		  brh_no 
	from ddw_prod.t_ddw_f00_cust_cust_info 
    where bus_date=%d{yyyyMMdd}
    )c,
    ddw_prod.t_ddw_inr_org_brh_kudu d
where a.cust_no=b.cust_no
  and a.cust_no=c.cust_no
  and c.brh_no=d.brh_no
  and a.cust_star in('0','1','2','3','4','5','6')
  and b.inv_pref in('0','1','2','3','4')
group by 	d.belto_filil_cdg,
          d.belto_filil,
		d.brh_no,
		d.brh_fullnm,
		a.cust_star,
		b.inv_pref
order by 	d.belto_filil_cdg,
          d.belto_filil,
		d.brh_no,
		d.brh_fullnm,
		a.cust_star,
		b.inv_pref
;

----133.客户数_投资偏好_零资产客户
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select 
    d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,case when a.cust_star='0' then '一星客户'
	     when a.cust_star='1' then '二星客户'
	     when a.cust_star='2' then '三星客户'
	     when a.cust_star='3' then '四星客户'
	     when a.cust_star='4' then '五星客户'
	     when a.cust_star='5' then '六星客户'
	     else '七星客户' end as cust_star
	,'cust_vol_tzph_lzckh' as zbm
	,count(1) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	select cust_no,
       	  label_value as cust_star
	from ddw_prod.t_ddw_lm_label_v_c_his
	where bus_date=%d{yyyyMMdd}
  	  and label_id ='8d0fe69b4ff546f082775761d27c70a5'
  	)a,
  	(
	select cust_no,
       	  label_value as inv_pref
	from ddw_prod.t_ddw_lm_label_v_c_his
	where bus_date=%d{yyyyMMdd}
	and label_value not in ('0','1','2','3')
  	and label_id ='8b6c8a85b0014e8384a884a8f8ceb7ee'
  	)b,
	(
	select cust_no,
		  brh_no 
	from ddw_prod.t_ddw_f00_cust_cust_info 
    where bus_date=%d{yyyyMMdd}
    )c,
    ddw_prod.t_ddw_inr_org_brh_kudu d
where a.cust_no=b.cust_no
  and a.cust_no=c.cust_no
  and c.brh_no=d.brh_no
  and a.cust_star in('0','1','2','3','4','5','6')
  and b.inv_pref in('0','1','2','3','4')
group by 	d.belto_filil_cdg,
          d.belto_filil,
		d.brh_no,
		d.brh_fullnm,
		a.cust_star,
		b.inv_pref
order by 	d.belto_filil_cdg,
          d.belto_filil,
		d.brh_no,
		d.brh_fullnm,
		a.cust_star,
		b.inv_pref
;

----134.客户数_交易权限_股基权限（累计至当日）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select
	d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,a.cust_star
	,'cust_vol_jyqx_gjqx' as zbm
	,sum(nvl(b.gj,0)) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	  select  brh_no,
			  cust_no,
			  cust_star,		
			  case when if_str_fnd=0 then 1 else 0 end as fjjj, 
			  case when if_H_K=0 then 1 else 0 end as ggtzt,
			  case when if_crd_cnclact=0 then 1 else 0 end as rzrq, 
			  case when if_wrnt_cnclact=0 then 1 else 0 end as ggqq, 
			  case when if_stib=0 then 1 else 0 end as kcb, 
			  case when if_new_t3bod=0 then 1 else 0 end as xsb, 
			  case when if_bond_qlfd_ivsm=0 then 1 else 0 end as zqtzz  
	  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
	  where bus_date=%d{yyyyMMdd} 
	    and cust_stat in('0','99')
	    and cust_rsk_lvl in('0','1','2','8','19')
	 )a
left join 
	 (
	  select cust_no,1 gj
	  from DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
	  where bus_date=%d{yyyyMMdd}
	    and (EXG in('SH','SZ','HB','SB','TA','TU') AND OPN_PRVL=1)--股基暂用基本交易权限
	  group by cust_no
	 )b
on a.cust_no=b.cust_no 
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on a.brh_no = d.brh_no
group by d.belto_filil_cdg,d.belto_filil,d.brh_no,d.brh_fullnm,a.cust_star
;

----135.客户数_交易权限_分级基金权限（累计至当日）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select
	d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,a.cust_star
	,'cust_vol_jyqx_fjjjqx' as zbm
	,sum(a.fjjj) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	  select  brh_no,
			  cust_no,
			  cust_star,		
			  case when if_str_fnd=0 then 1 else 0 end as fjjj, 
			  case when if_H_K=0 then 1 else 0 end as ggtzt,
			  case when if_crd_cnclact=0 then 1 else 0 end as rzrq, 
			  case when if_wrnt_cnclact=0 then 1 else 0 end as ggqq, 
			  case when if_stib=0 then 1 else 0 end as kcb, 
			  case when if_new_t3bod=0 then 1 else 0 end as xsb, 
			  case when if_bond_qlfd_ivsm=0 then 1 else 0 end as zqtzz  
	  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
	  where bus_date=%d{yyyyMMdd}
	    and cust_stat in('0','99')
	    and cust_rsk_lvl in('0','1','2','8','19')
	 )a
left join 
	 (
	  select cust_no,1 gj
	  from DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
	  where bus_date=%d{yyyyMMdd}
	    and (EXG in('SH','SZ','HB','SB','TA','TU') AND OPN_PRVL=1)--股基暂用基本交易权限
	  group by cust_no
	 )b
on a.cust_no=b.cust_no 
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on a.brh_no = d.brh_no
group by d.belto_filil_cdg,d.belto_filil,d.brh_no,d.brh_fullnm,a.cust_star
;

----136.客户数_交易权限_港股通权限（累计至当日）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select
	d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,a.cust_star
	,'cust_vol_jyqx_ggtqx' as zbm
	,sum(a.ggtzt) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	  select  brh_no,
			  cust_no,
			  cust_star,		
			  case when if_str_fnd=0 then 1 else 0 end as fjjj, 
			  case when if_H_K=0 then 1 else 0 end as ggtzt,
			  case when if_crd_cnclact=0 then 1 else 0 end as rzrq, 
			  case when if_wrnt_cnclact=0 then 1 else 0 end as ggqq, 
			  case when if_stib=0 then 1 else 0 end as kcb, 
			  case when if_new_t3bod=0 then 1 else 0 end as xsb, 
			  case when if_bond_qlfd_ivsm=0 then 1 else 0 end as zqtzz  
	  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
	  where bus_date=%d{yyyyMMdd}
	    and cust_stat in('0','99')
	    and cust_rsk_lvl in('0','1','2','8','19')
	 )a
left join 
	 (
	  select cust_no,1 gj
	  from DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
	  where bus_date=%d{yyyyMMdd}
	    and (EXG in('SH','SZ','HB','SB','TA','TU') AND OPN_PRVL=1)--股基暂用基本交易权限
	  group by cust_no
	 )b
on a.cust_no=b.cust_no 
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on a.brh_no = d.brh_no
group by d.belto_filil_cdg,d.belto_filil,d.brh_no,d.brh_fullnm,a.cust_star
;

----137.客户数_交易权限_融资融券权限（累计至当日）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select
	d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,a.cust_star
	,'cust_vol_jyqx_rzrqqx' as zbm
	,sum(a.rzrq) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	  select  brh_no,
			  cust_no,
			  cust_star,		
			  case when if_str_fnd=0 then 1 else 0 end as fjjj, 
			  case when if_H_K=0 then 1 else 0 end as ggtzt,
			  case when if_crd_cnclact=0 then 1 else 0 end as rzrq, 
			  case when if_wrnt_cnclact=0 then 1 else 0 end as ggqq, 
			  case when if_stib=0 then 1 else 0 end as kcb, 
			  case when if_new_t3bod=0 then 1 else 0 end as xsb, 
			  case when if_bond_qlfd_ivsm=0 then 1 else 0 end as zqtzz  
	  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
	  where bus_date=%d{yyyyMMdd}
	    and cust_stat in('0','99')
	    and cust_rsk_lvl in('0','1','2','8','19')
	 )a
left join 
	 (
	  select cust_no,1 gj
	  from DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
	  where bus_date=%d{yyyyMMdd}
	    and (EXG in('SH','SZ','HB','SB','TA','TU') AND OPN_PRVL=1)--股基暂用基本交易权限
	  group by cust_no
	 )b
on a.cust_no=b.cust_no 
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on a.brh_no = d.brh_no
group by d.belto_filil_cdg,d.belto_filil,d.brh_no,d.brh_fullnm,a.cust_star
;

----138.客户数_交易权限_个股期权权限（累计至当日）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select
	d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,a.cust_star
	,'cust_vol_jyqx_ggqqqx' as zbm
	,sum(a.ggqq) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	  select  brh_no,
			  cust_no,
			  cust_star,		
			  case when if_str_fnd=0 then 1 else 0 end as fjjj, 
			  case when if_H_K=0 then 1 else 0 end as ggtzt,
			  case when if_crd_cnclact=0 then 1 else 0 end as rzrq, 
			  case when if_wrnt_cnclact=0 then 1 else 0 end as ggqq, 
			  case when if_stib=0 then 1 else 0 end as kcb, 
			  case when if_new_t3bod=0 then 1 else 0 end as xsb, 
			  case when if_bond_qlfd_ivsm=0 then 1 else 0 end as zqtzz  
	  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
	  where bus_date=%d{yyyyMMdd}
	    and cust_stat in('0','99')
	    and cust_rsk_lvl in('0','1','2','8','19')
	 )a
left join 
	 (
	  select cust_no,1 gj
	  from DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
	  where bus_date=%d{yyyyMMdd}
	    and (EXG in('SH','SZ','HB','SB','TA','TU') AND OPN_PRVL=1)--股基暂用基本交易权限
	  group by cust_no
	 )b
on a.cust_no=b.cust_no 
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on a.brh_no = d.brh_no
group by d.belto_filil_cdg,d.belto_filil,d.brh_no,d.brh_fullnm,a.cust_star
;

----139.客户数_交易权限_科创板权限（累计至当日）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select
	d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,a.cust_star
	,'cust_vol_jyqx_kcbqx' as zbm
	,sum(a.kcb) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	  select  brh_no,
			  cust_no,
			  cust_star,		
			  case when if_str_fnd=0 then 1 else 0 end as fjjj, 
			  case when if_H_K=0 then 1 else 0 end as ggtzt,
			  case when if_crd_cnclact=0 then 1 else 0 end as rzrq, 
			  case when if_wrnt_cnclact=0 then 1 else 0 end as ggqq, 
			  case when if_stib=0 then 1 else 0 end as kcb, 
			  case when if_new_t3bod=0 then 1 else 0 end as xsb, 
			  case when if_bond_qlfd_ivsm=0 then 1 else 0 end as zqtzz  
	  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
	  where bus_date=%d{yyyyMMdd}
	    and cust_stat in('0','99')
	    and cust_rsk_lvl in('0','1','2','8','19')
	 )a
left join 
	 (
	  select cust_no,1 gj
	  from DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
	  where bus_date=%d{yyyyMMdd}
	    and (EXG in('SH','SZ','HB','SB','TA','TU') AND OPN_PRVL=1)--股基暂用基本交易权限
	  group by cust_no
	 )b
on a.cust_no=b.cust_no 
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on a.brh_no = d.brh_no
group by d.belto_filil_cdg,d.belto_filil,d.brh_no,d.brh_fullnm,a.cust_star
;

----140.客户数_交易权限_新三板权限（累计至当日）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select
	d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,a.cust_star
	,'cust_vol_jyqx_xsbqx' as zbm
	,sum(a.xsb) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	  select  brh_no,
			  cust_no,
			  cust_star,		
			  case when if_str_fnd=0 then 1 else 0 end as fjjj, 
			  case when if_H_K=0 then 1 else 0 end as ggtzt,
			  case when if_crd_cnclact=0 then 1 else 0 end as rzrq, 
			  case when if_wrnt_cnclact=0 then 1 else 0 end as ggqq, 
			  case when if_stib=0 then 1 else 0 end as kcb, 
			  case when if_new_t3bod=0 then 1 else 0 end as xsb, 
			  case when if_bond_qlfd_ivsm=0 then 1 else 0 end as zqtzz  
	  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
	  where bus_date=%d{yyyyMMdd}
	    and cust_stat in('0','99')
	    and cust_rsk_lvl in('0','1','2','8','19')
	 )a
left join 
	 (
	  select cust_no,1 gj
	  from DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
	  where bus_date=%d{yyyyMMdd}
	    and (EXG in('SH','SZ','HB','SB','TA','TU') AND OPN_PRVL=1)--股基暂用基本交易权限
	  group by cust_no
	 )b
on a.cust_no=b.cust_no 
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on a.brh_no = d.brh_no
group by d.belto_filil_cdg,d.belto_filil,d.brh_no,d.brh_fullnm,a.cust_star
;

----141.客户数_交易权限_债券投资者权限（累计至当日）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select
	d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,a.cust_star
	,'cust_vol_jyqx_zqtzzqx' as zbm
	,sum(a.zqtzz) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	  select  brh_no,
			  cust_no,
			  cust_star,		
			  case when if_str_fnd=0 then 1 else 0 end as fjjj, 
			  case when if_H_K=0 then 1 else 0 end as ggtzt,
			  case when if_crd_cnclact=0 then 1 else 0 end as rzrq, 
			  case when if_wrnt_cnclact=0 then 1 else 0 end as ggqq, 
			  case when if_stib=0 then 1 else 0 end as kcb, 
			  case when if_new_t3bod=0 then 1 else 0 end as xsb, 
			  case when if_bond_qlfd_ivsm=0 then 1 else 0 end as zqtzz  
	  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
	  where bus_date=%d{yyyyMMdd}
	    and cust_stat in('0','99')
	    and cust_rsk_lvl in('0','1','2','8','19')
	 )a	
left join 
	 (
	  select cust_no,1 gj
	  from DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
	  where bus_date=%d{yyyyMMdd}
	    and (EXG in('SH','SZ','HB','SB','TA','TU') AND OPN_PRVL=1)--股基暂用基本交易权限
	  group by cust_no
	 )b
on a.cust_no=b.cust_no 
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on a.brh_no = d.brh_no
group by d.belto_filil_cdg,d.belto_filil,d.brh_no,d.brh_fullnm,a.cust_star
;

----142.客户数_交易权限_债券投资者权限（累计至当日）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select
	d.belto_filil_cdg as belto_filil_cdg
	,d.belto_filil as belto_filil
	,d.brh_no as brh_no
	,d.brh_fullnm as brh_fullnm
	,a.cust_star
	,'cust_vol_jyqx_zqtzzqx' as zbm
	,sum(a.zqtzz) as zbz
	,%d{yyyyMMdd} as bus_date
from (
	  select  brh_no,
			  cust_no,
			  cust_star,		
			  case when if_str_fnd=0 then 1 else 0 end as fjjj, 
			  case when if_H_K=0 then 1 else 0 end as ggtzt,
			  case when if_crd_cnclact=0 then 1 else 0 end as rzrq, 
			  case when if_wrnt_cnclact=0 then 1 else 0 end as ggqq, 
			  case when if_stib=0 then 1 else 0 end as kcb, 
			  case when if_new_t3bod=0 then 1 else 0 end as xsb, 
			  case when if_bond_qlfd_ivsm=0 then 1 else 0 end as zqtzz  
	  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
	  where bus_date=%d{yyyyMMdd}
	    and cust_stat in('0','99')
	    and cust_rsk_lvl in('0','1','2','8','19')
	 )a	
left join 
	 (
	  select cust_no,1 gj
	  from DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
	  where bus_date=%d{yyyyMMdd}
	    and (EXG in('SH','SZ','HB','SB','TA','TU') AND OPN_PRVL=1)--股基暂用基本交易权限
	  group by cust_no
	 )b
on a.cust_no=b.cust_no 
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on a.brh_no = d.brh_no
group by d.belto_filil_cdg,d.belto_filil,d.brh_no,d.brh_fullnm,a.cust_star
;

----143.客户数_客户关系_经纪人
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_vol_khgx_jjr' as zbm
	  ,sum(b.IF_JJR) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11') a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----144.净资产_客户关系_经纪人
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_net_tot_ast_khgx_jjr' as zbm
	  ,round(sum(b.IF_JJR*c.net_tot_ast)/10000,2) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----145.净佣金_客户关系_经纪人
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_net_s1_khgx_jjr' as zbm
	  ,round(sum(b.IF_JJR*d.tot_net_s1)/10000,2) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----146.客户数_客户关系_客户经理
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_vol_khgx_khjl' as zbm
	  ,sum(b.IF_KHJL) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----147.净资产_客户关系_客户经理
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_net_tot_ast_khgx_khjl' as zbm
	  ,round(sum(b.IF_KHJL*c.net_tot_ast)/10000,2) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----148.净佣金_客户关系_客户经理
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_net_s1_khgx_khjl' as zbm
	  ,round(sum(b.IF_KHJL*d.tot_net_s1)/10000,2) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----149.客户数_客户关系_员工
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_vol_khgx_yg' as zbm
	  ,sum(b.IF_YG) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----150.净资产_客户关系_员工
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_net_tot_ast_khgx_yg' as zbm
	  ,round(sum(b.IF_YG*c.net_tot_ast)/10000,2) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----151.净佣金_客户关系_员工
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_net_s1_khgx_yg' as zbm
	  ,round(sum(b.IF_YG*d.tot_net_s1)/10000,2) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----152.客户数_客户关系_强服务关系
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_vol_khgx_qfwgx' as zbm
	  ,sum(b.IF_QFWGX) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----153.净资产_客户关系_强服务关系
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_net_tot_ast_khgx_qfwgx' as zbm
	  ,round(sum(b.IF_QFWGX*c.net_tot_ast)/10000,2) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----154.净佣金_客户关系_强服务关系
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_net_s1_khgx_qfwgx' as zbm
	  ,round(sum(b.IF_QFWGX*d.tot_net_s1)/10000,2) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----155.客户数_客户关系_弱服务关系
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_vol_khgx_rfwgx' as zbm
	  ,sum(b.IF_RFWGX) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----156.净资产_客户关系_弱服务关系
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_net_tot_ast_khgx_rfwgx' as zbm
	  ,round(sum(b.IF_RFWGX*c.net_tot_ast)/10000,2) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----157.净佣金_客户关系_弱服务关系
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_net_s1_khgx_rfwgx' as zbm
	  ,round(sum(b.IF_RFWGX*d.tot_net_s1)/10000,2) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----158.客户数_客户关系_弱服务关系（去重）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_vol_khgx_rfwgxqc' as zbm
	  ,sum(case when b.IF_JJR+b.IF_KHJL+b.IF_YG+b.IF_QFWGX=0 
				then b.IF_RFWGX else 0 end) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----159.净资产_客户关系_弱服务关系（去重）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_net_tot_ast_khgx_rfwgxqc' as zbm
	  ,round(sum(case when b.IF_JJR+b.IF_KHJL+b.IF_YG+b.IF_QFWGX=0
					  then b.IF_RFWGX*c.net_tot_ast else 0 end)/10000,2) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----160.净佣金_客户关系_弱服务关系（去重）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select e.belto_filil_cdg as belto_filil_cdg
	  ,e.belto_filil as belto_filil
	  ,b.brh_no as brh_no
	  ,e.brh_fullnm	as brh_fullnm
	  ,a.cust_star as cust_star
	  ,'cust_net_s1_khgx_rfwgxqc' as zbm
	  ,round(sum(case when b.IF_JJR+b.IF_KHJL+b.IF_YG+b.IF_QFWGX=0
					  then b.IF_RFWGX*d.tot_net_s1 else 0 end)/10000,2) as zbz
      ,%d{yyyyMMdd} as bus_date
from 
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')a
left join 
(select brh_no
	   ,cust_no
	   ,(case when sum(IF_JJR)>0 then 1 else 0 end) IF_JJR
	   ,(case when sum(IF_KHJL)>0 then 1 else 0 end) IF_KHJL
	   ,(case when sum(IF_YG)>0 then 1 else 0 end) IF_YG
	   ,(case when sum(IF_QFWGX)>0 then 1 else 0 end) IF_QFWGX
	   ,(case when sum(IF_RFWGX)>0 then 1 else 0 end) IF_RFWGX
 from
 (select  brh_no
		 ,cust_no
		 ,(case when cust_rln='证券经纪人' then 1 else 0 end)IF_JJR
		 ,(case when cust_rln='客户经理(新制度)' then 1 else 0 end)IF_KHJL
		 ,(case when cust_rln in('理财经理(新制度)','投资顾问(新制度)','市场总监(新制度)') then 1 else 0 end)IF_YG
		 ,(case when cust_rln='强服务关系' then 1 else 0 end)IF_QFWGX
		 ,(case when cust_rln='弱服务关系' then 1 else 0 end)IF_RFWGX
  from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
  union all
  SELECT   BRH_NO
		  ,CUST_NO
		  ,0 IF_JJR
		  ,0 IF_KHJL
		  ,0 IF_YG
		  ,0 IF_QFWGX
		  ,1 IF_RFWGX 
  FROM 
	 (SELECT BRH_NO,CUST_NO,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
	  FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN
	  WHERE  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})> = STATS_DT
		AND  (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})< NVL(EXPR_DT,99999999)
		AND   BUS_DATE = (select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
		AND   SVC_RLN_TP IN ('5')
	 ) b2
  WHERE b2.NUM = 1)b3
 group by brh_no,cust_no)b
 on trim(cast(a.cust_no as string))=trim(cast(b.cust_no as string))
 left join 
 (select cust_no,net_tot_ast
  from ddw_prod.t_ddw_f10_ast_cust_ast_aggr_day
  where bus_date = %d{yyyyMMdd} ) c
 on a.cust_no=c.cust_no
 left join 
 (select cust_no,sum(tot_net_s1)tot_net_s1
  from ddw_prod.t_ddw_f10_cust_trd_incm_day
  where bus_date =  %d{yyyyMMdd}
  group by cust_no)d
 on a.cust_no=d.cust_no
 left join ddw_prod.t_ddw_inr_org_brh_KUDU e
 on b.brh_no=e.brh_no
where b.brh_no is not null	
group by e.belto_filil_cdg
		,e.belto_filil
		,b.brh_no
		,e.brh_fullnm
		,a.cust_star
;

----161.总委托人数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select d.belto_filil_cdg as belto_filil_cdg
      ,d.belto_filil as belto_filil
      ,c.brh_no as brh_no
	  ,d.brh_fullnm	as brh_fullnm
	  ,b.cust_star as cust_star
      ,'tot_wtrs' as zbm	  
	  ,count(a.khh) as zbz
	  ,%d{yyyyMMdd} as bus_date
from 
(select khh
	   ,case when sum(VIPXW)>0 then 1 else 0 end VIPXW
	   ,case when sum(HXXW)>0 then 1 else 0 end HXXW
	   ,case when sum(PTXW)>0 then 1 else 0 end PTXW
	   ,sum(vipxwcjje)vipxwcjje
	   ,sum(hxxwcjje)hxxwcjje
	   ,sum(ptxwcjje)ptxwcjje
 from 
 (select  khh
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)VIPXW
		 ,sum(case when sbjb=4 then 1 else 0 end)HXXW
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)PTXW
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		 		    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
		 		    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)VIPXWCJJE
		 ,sum(case when sbjb=4 
				    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)HXXWCJJE
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		            and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)PTXWCJJE
  from jzjycx.datacenter_twtls a1
  where wtrq = %d{yyyyMMdd}
  group by khh
  union all
  select  khh
		 ,0 VIPXW
		 ,0 HXXW
		 ,count(*) PTXW
		 ,0 VIPXWCJJE
		 ,0 HXXWCJJE
		 ,sum(case when zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60,61,62,63,64,71,72) 
				   then cjje else 0 end)PTXWCJJE
  from rzrqcx.datacenter_twtls a2
  where wtrq = %d{yyyyMMdd} 
  group by khh)a3
 group by khh)a
left join 		
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')b
on a.khh=b.cust_no
left join 
(select brh_no,cust_no 
 from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd}))c
on a.khh=c.cust_no
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on c.brh_no=d.brh_no
where b.cust_star is not null
group by d.belto_filil_cdg
        ,d.belto_filil
        ,c.brh_no
	    ,d.brh_fullnm
	    ,b.cust_star
;

----162.总人民币股基成交金额_万元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select d.belto_filil_cdg as belto_filil_cdg
      ,d.belto_filil as belto_filil
      ,c.brh_no as brh_no
	  ,d.brh_fullnm	as brh_fullnm
	  ,b.cust_star as cust_star
      ,'tot_cjje' as zbm	  
	  ,round(sum(a.VIPXWCJJE+a.HXXWCJJE+a.PTXWCJJE)/10000,2) as zbz
	  ,%d{yyyyMMdd} as bus_date
from 
(select khh
	   ,case when sum(VIPXW)>0 then 1 else 0 end VIPXW
	   ,case when sum(HXXW)>0 then 1 else 0 end HXXW
	   ,case when sum(PTXW)>0 then 1 else 0 end PTXW
	   ,sum(vipxwcjje)vipxwcjje
	   ,sum(hxxwcjje)hxxwcjje
	   ,sum(ptxwcjje)ptxwcjje
 from 
 (select  khh
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)VIPXW
		 ,sum(case when sbjb=4 then 1 else 0 end)HXXW
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)PTXW
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		 		    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
		 		    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)VIPXWCJJE
		 ,sum(case when sbjb=4 
				    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)HXXWCJJE
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		            and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)PTXWCJJE
  from jzjycx.datacenter_twtls a1
  where wtrq = %d{yyyyMMdd}
  group by khh
  union all
  select  khh
		 ,0 VIPXW
		 ,0 HXXW
		 ,count(*) PTXW
		 ,0 VIPXWCJJE
		 ,0 HXXWCJJE
		 ,sum(case when zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60,61,62,63,64,71,72) 
				   then cjje else 0 end)PTXWCJJE
  from rzrqcx.datacenter_twtls a2
  where wtrq = %d{yyyyMMdd} 
  group by khh)a3
 group by khh)a
left join 		
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')b
on a.khh=b.cust_no
left join 
(select brh_no,cust_no 
 from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd}))c
on a.khh=c.cust_no
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on c.brh_no=d.brh_no
where b.cust_star is not null
group by d.belto_filil_cdg
        ,d.belto_filil
        ,c.brh_no
	    ,d.brh_fullnm
	    ,b.cust_star
;

----163.普通席位委托客户数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select d.belto_filil_cdg as belto_filil_cdg
      ,d.belto_filil as belto_filil
      ,c.brh_no as brh_no
	  ,d.brh_fullnm	as brh_fullnm
	  ,b.cust_star as cust_star
      ,'wtrs_ptxw' as zbm	  
	  ,sum(a.PTXW) as zbz
	  ,%d{yyyyMMdd} as bus_date
from 
(select khh
	   ,case when sum(VIPXW)>0 then 1 else 0 end VIPXW
	   ,case when sum(HXXW)>0 then 1 else 0 end HXXW
	   ,case when sum(PTXW)>0 then 1 else 0 end PTXW
	   ,sum(vipxwcjje)vipxwcjje
	   ,sum(hxxwcjje)hxxwcjje
	   ,sum(ptxwcjje)ptxwcjje
 from 
 (select  khh
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)VIPXW
		 ,sum(case when sbjb=4 then 1 else 0 end)HXXW
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)PTXW
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		 		    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
		 		    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)VIPXWCJJE
		 ,sum(case when sbjb=4 
				    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)HXXWCJJE
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		            and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)PTXWCJJE
  from jzjycx.datacenter_twtls a1
  where wtrq = %d{yyyyMMdd}
  group by khh
  union all
  select  khh
		 ,0 VIPXW
		 ,0 HXXW
		 ,count(*) PTXW
		 ,0 VIPXWCJJE
		 ,0 HXXWCJJE
		 ,sum(case when zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60,61,62,63,64,71,72) 
				   then cjje else 0 end)PTXWCJJE
  from rzrqcx.datacenter_twtls a2
  where wtrq = %d{yyyyMMdd} 
  group by khh)a3
 group by khh)a
left join 		
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')b
on a.khh=b.cust_no
left join 
(select brh_no,cust_no 
 from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd}))c
on a.khh=c.cust_no
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on c.brh_no=d.brh_no
where b.cust_star is not null
group by d.belto_filil_cdg
        ,d.belto_filil
        ,c.brh_no
	    ,d.brh_fullnm
	    ,b.cust_star
;

----164.人民币股基交易量_普通席位
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select d.belto_filil_cdg as belto_filil_cdg
      ,d.belto_filil as belto_filil
      ,c.brh_no as brh_no
	  ,d.brh_fullnm	as brh_fullnm
	  ,b.cust_star as cust_star
      ,'cjje_ptxw' as zbm	  
	  ,round(sum(a.PTXWCJJE)/10000,2) as zbz
	  ,%d{yyyyMMdd} as bus_date
from 
(select khh
	   ,case when sum(VIPXW)>0 then 1 else 0 end VIPXW
	   ,case when sum(HXXW)>0 then 1 else 0 end HXXW
	   ,case when sum(PTXW)>0 then 1 else 0 end PTXW
	   ,sum(vipxwcjje)vipxwcjje
	   ,sum(hxxwcjje)hxxwcjje
	   ,sum(ptxwcjje)ptxwcjje
 from 
 (select  khh
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)VIPXW
		 ,sum(case when sbjb=4 then 1 else 0 end)HXXW
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)PTXW
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		 		    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
		 		    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)VIPXWCJJE
		 ,sum(case when sbjb=4 
				    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)HXXWCJJE
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		            and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)PTXWCJJE
  from jzjycx.datacenter_twtls a1
  where wtrq = %d{yyyyMMdd}
  group by khh
  union all
  select  khh
		 ,0 VIPXW
		 ,0 HXXW
		 ,count(*) PTXW
		 ,0 VIPXWCJJE
		 ,0 HXXWCJJE
		 ,sum(case when zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60,61,62,63,64,71,72) 
				   then cjje else 0 end)PTXWCJJE
  from rzrqcx.datacenter_twtls a2
  where wtrq = %d{yyyyMMdd} 
  group by khh)a3
 group by khh)a
left join 		
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')b
on a.khh=b.cust_no
left join 
(select brh_no,cust_no 
 from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd}))c
on a.khh=c.cust_no
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on c.brh_no=d.brh_no
where b.cust_star is not null
group by d.belto_filil_cdg
        ,d.belto_filil
        ,c.brh_no
	    ,d.brh_fullnm
	    ,b.cust_star
;

----162.核心席位委托客户数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select d.belto_filil_cdg as belto_filil_cdg
      ,d.belto_filil as belto_filil
      ,c.brh_no as brh_no
	  ,d.brh_fullnm	as brh_fullnm
	  ,b.cust_star as cust_star
      ,'wtrs_hxxw' as zbm	  
	  ,sum(a.HXXW) as zbz
	  ,%d{yyyyMMdd} as bus_date
from 
(select khh
	   ,case when sum(VIPXW)>0 then 1 else 0 end VIPXW
	   ,case when sum(HXXW)>0 then 1 else 0 end HXXW
	   ,case when sum(PTXW)>0 then 1 else 0 end PTXW
	   ,sum(vipxwcjje)vipxwcjje
	   ,sum(hxxwcjje)hxxwcjje
	   ,sum(ptxwcjje)ptxwcjje
 from 
 (select  khh
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)VIPXW
		 ,sum(case when sbjb=4 then 1 else 0 end)HXXW
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)PTXW
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		 		    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
		 		    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)VIPXWCJJE
		 ,sum(case when sbjb=4 
				    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)HXXWCJJE
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		            and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)PTXWCJJE
  from jzjycx.datacenter_twtls a1
  where wtrq = %d{yyyyMMdd}
  group by khh
  union all
  select  khh
		 ,0 VIPXW
		 ,0 HXXW
		 ,count(*) PTXW
		 ,0 VIPXWCJJE
		 ,0 HXXWCJJE
		 ,sum(case when zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60,61,62,63,64,71,72) 
				   then cjje else 0 end)PTXWCJJE
  from rzrqcx.datacenter_twtls a2
  where wtrq = %d{yyyyMMdd} 
  group by khh)a3
 group by khh)a
left join 		
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')b
on a.khh=b.cust_no
left join 
(select brh_no,cust_no 
 from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd}))c
on a.khh=c.cust_no
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on c.brh_no=d.brh_no
where b.cust_star is not null
group by d.belto_filil_cdg
        ,d.belto_filil
        ,c.brh_no
	    ,d.brh_fullnm
	    ,b.cust_star
;

----166.人民币股基交易量_核心席位
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select d.belto_filil_cdg as belto_filil_cdg
      ,d.belto_filil as belto_filil
      ,c.brh_no as brh_no
	  ,d.brh_fullnm	as brh_fullnm
	  ,b.cust_star as cust_star
      ,'cjje_hxxw' as zbm	  
	  ,round(sum(a.HXXWCJJE)/10000,2) as zbz
	  ,%d{yyyyMMdd} as bus_date
from 
(select khh
	   ,case when sum(VIPXW)>0 then 1 else 0 end VIPXW
	   ,case when sum(HXXW)>0 then 1 else 0 end HXXW
	   ,case when sum(PTXW)>0 then 1 else 0 end PTXW
	   ,sum(vipxwcjje)vipxwcjje
	   ,sum(hxxwcjje)hxxwcjje
	   ,sum(ptxwcjje)ptxwcjje
 from 
 (select  khh
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)VIPXW
		 ,sum(case when sbjb=4 then 1 else 0 end)HXXW
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)PTXW
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		 		    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
		 		    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)VIPXWCJJE
		 ,sum(case when sbjb=4 
				    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)HXXWCJJE
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		            and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)PTXWCJJE
  from jzjycx.datacenter_twtls a1
  where wtrq = %d{yyyyMMdd}
  group by khh
  union all
  select  khh
		 ,0 VIPXW
		 ,0 HXXW
		 ,count(*) PTXW
		 ,0 VIPXWCJJE
		 ,0 HXXWCJJE
		 ,sum(case when zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60,61,62,63,64,71,72) 
				   then cjje else 0 end)PTXWCJJE
  from rzrqcx.datacenter_twtls a2
  where wtrq = %d{yyyyMMdd} 
  group by khh)a3
 group by khh)a
left join 		
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')b
on a.khh=b.cust_no
left join 
(select brh_no,cust_no 
 from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd}))c
on a.khh=c.cust_no
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on c.brh_no=d.brh_no
where b.cust_star is not null
group by d.belto_filil_cdg
        ,d.belto_filil
        ,c.brh_no
	    ,d.brh_fullnm
	    ,b.cust_star
;

----167.VIP席位委托客户数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select d.belto_filil_cdg as belto_filil_cdg
      ,d.belto_filil as belto_filil
      ,c.brh_no as brh_no
	  ,d.brh_fullnm	as brh_fullnm
	  ,b.cust_star as cust_star
      ,'wtrs_vipxw' as zbm	  
	  ,sum(a.VIPXW) as zbz
	  ,%d{yyyyMMdd} as bus_date
from 
(select khh
	   ,case when sum(VIPXW)>0 then 1 else 0 end VIPXW
	   ,case when sum(HXXW)>0 then 1 else 0 end HXXW
	   ,case when sum(PTXW)>0 then 1 else 0 end PTXW
	   ,sum(vipxwcjje)vipxwcjje
	   ,sum(hxxwcjje)hxxwcjje
	   ,sum(ptxwcjje)ptxwcjje
 from 
 (select  khh
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)VIPXW
		 ,sum(case when sbjb=4 then 1 else 0 end)HXXW
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)PTXW
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		 		    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
		 		    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)VIPXWCJJE
		 ,sum(case when sbjb=4 
				    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)HXXWCJJE
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		            and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)PTXWCJJE
  from jzjycx.datacenter_twtls a1
  where wtrq = %d{yyyyMMdd}
  group by khh
  union all
  select  khh
		 ,0 VIPXW
		 ,0 HXXW
		 ,count(*) PTXW
		 ,0 VIPXWCJJE
		 ,0 HXXWCJJE
		 ,sum(case when zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60,61,62,63,64,71,72) 
				   then cjje else 0 end)PTXWCJJE
  from rzrqcx.datacenter_twtls a2
  where wtrq = %d{yyyyMMdd} 
  group by khh)a3
 group by khh)a
left join 		
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')b
on a.khh=b.cust_no
left join 
(select brh_no,cust_no 
 from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd}))c
on a.khh=c.cust_no
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on c.brh_no=d.brh_no
where b.cust_star is not null
group by d.belto_filil_cdg
        ,d.belto_filil
        ,c.brh_no
	    ,d.brh_fullnm
	    ,b.cust_star
;

----168.人民币股基交易量_VIP席位
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select d.belto_filil_cdg as belto_filil_cdg
      ,d.belto_filil as belto_filil
      ,c.brh_no as brh_no
	  ,d.brh_fullnm	as brh_fullnm
	  ,b.cust_star as cust_star
      ,'cjje_vipxw' as zbm	  
	  ,round(sum(a.VIPXWCJJE)/10000,2) as zbz
	  ,%d{yyyyMMdd} as bus_date
from 
(select khh
	   ,case when sum(VIPXW)>0 then 1 else 0 end VIPXW
	   ,case when sum(HXXW)>0 then 1 else 0 end HXXW
	   ,case when sum(PTXW)>0 then 1 else 0 end PTXW
	   ,sum(vipxwcjje)vipxwcjje
	   ,sum(hxxwcjje)hxxwcjje
	   ,sum(ptxwcjje)ptxwcjje
 from 
 (select  khh
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)VIPXW
		 ,sum(case when sbjb=4 then 1 else 0 end)HXXW
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) then 1 else 0 end)PTXW
		 ,sum(case when sbjb in(6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		 		    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
		 		    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)VIPXWCJJE
		 ,sum(case when sbjb=4 
				    and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)HXXWCJJE
		 ,sum(case when sbjg not in(4,6,10,11,12,13,14,15,16,17,18,19,20,21,22) 
		            and zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60) 
				    and bz='RMB' then cjje else 0 end)PTXWCJJE
  from jzjycx.datacenter_twtls a1
  where wtrq = %d{yyyyMMdd}
  group by khh
  union all
  select  khh
		 ,0 VIPXW
		 ,0 HXXW
		 ,count(*) PTXW
		 ,0 VIPXWCJJE
		 ,0 HXXWCJJE
		 ,sum(case when zqlb in('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
				    and wtlb in(1,2,29,30,41,42,43,57,58,59,60,61,62,63,64,71,72) 
				   then cjje else 0 end)PTXWCJJE
  from rzrqcx.datacenter_twtls a2
  where wtrq = %d{yyyyMMdd} 
  group by khh)a3
 group by khh)a
left join 		
(select cust_no,label_value,decode(label_value,'1','二星客户','2','三星客户','3','四星客户','4','五星客户','5','六星客户','6','七星客户','一星客户')cust_star
 from DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
 where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd})
   and label_id='8d0fe69b4ff546f082775761d27c70a5'
   and length(trim(cust_no))=12 
   and substr(trim(cust_no),1,2) between '10' and '11')b
on a.khh=b.cust_no
left join 
(select brh_no,cust_no 
 from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu b1
  where bus_date=(select max(trd_dt) from edw_prod.t_edw_t99_trd_date where nat_dt=%d{yyyyMMdd}))c
on a.khh=c.cust_no
left join ddw_prod.t_ddw_inr_org_brh_kudu d
on c.brh_no=d.brh_no
where b.cust_star is not null
group by d.belto_filil_cdg
        ,d.belto_filil
        ,c.brh_no
	    ,d.brh_fullnm
	    ,b.cust_star
;

----169.股基交易量（万元）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select belto_filil_cdg
      ,belto_filil
	  ,brh_no 
      ,brh_fullnm
	  ,cust_star
      ,'STK_FND_H_K_TRD_VOL' as zbm
      ,sum((fnd_trd_vol+stk_trd_vol+h_k_trd_vol)/10000) as zbz
	  ,%d{yyyyMMdd} as bus_date
from DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU
where bus_date = %d{yyyyMMdd} 
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----170.新增客户引入资产（万元）
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
	  ,A.cust_star as cust_star
      ,'new_cust_net_tot_ast' as zbm
      ,sum(NET_TOT_AST/10000) as zbz
	  ,%d{yyyyMMdd} as bus_date
from
(
select distinct cust_no,brh_no,cust_star
from DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
AND opnac_dt =%d{yyyyMMdd}
) A
left join
(
select brh_no,cust_no,NET_TOT_AST 
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where BUS_DATE=%d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no=B.brh_no
left join ddw_prod.t_ddw_inr_org_brh_kudu C
on A.brh_no=C.brh_no
where A.brh_no not in ('1002','1007','1013','1031','1080')
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----171.信用总资产
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_AST' as zbm
      ,sum(CRD_AST) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_AST
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----172.信用净资产
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_AST' as zbm
      ,sum(CRD_NET_AST) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_AST
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----173.信用资金余额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_CPTL' as zbm
      ,sum(CRD_CPTL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_CPTL                      
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----174.信用在途资金余额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_UNPY_CPTL' as zbm
      ,sum(CRD_UNPY_CPTL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_UNPY_CPTL                 
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----175.信用市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL' as zbm
      ,sum(CRD_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL                    
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----176.信用沪A市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_HA' as zbm
      ,sum(CRD_MKTVAL_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_HA                 
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----177.信用深A市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_SA' as zbm
      ,sum(CRD_MKTVAL_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_SA                 
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----178.信用沪债券市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_BOND_H' as zbm
      ,sum(CRD_MKTVAL_BOND_H) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_BOND_H             
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----179.信用深债券市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_BOND_S' as zbm
      ,sum(CRD_MKTVAL_BOND_S) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_BOND_S             
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----180.信用沪场内基金市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_FND_H' as zbm
      ,sum(CRD_MKTVAL_FND_H) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_FND_H              
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----181.信用深场内基金市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_FND_S' as zbm
      ,sum(CRD_MKTVAL_FND_S) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_FND_S              
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----182.信用其他市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_OTH' as zbm
      ,sum(CRD_MKTVAL_OTH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_OTH                
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----183.信用持仓 
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_HLD_COST' as zbm
      ,sum(CRD_HLD_COST) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_HLD_COST                  
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----184.信用负债
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_GL' as zbm
      ,sum(CRD_GL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_GL                        
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----185.融资负债
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNC_GL' as zbm
      ,sum(MRGNC_GL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNC_GL                      
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----186.融券负债
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNS_GL' as zbm
      ,sum(MRGNS_GL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNS_GL                      
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----187.融资初始负债
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNC_INL_GL' as zbm
      ,sum(MRGNC_INL_GL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNC_INL_GL                  
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----188.融券初始负债
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNS_INL_GL' as zbm
      ,sum(MRGNS_INL_GL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNS_INL_GL                  
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----189.沪A信用负债
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_GL_HA' as zbm
      ,sum(CRD_GL_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_GL_HA                     
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----190.深A信用负债
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_GL_SA' as zbm
      ,sum(CRD_GL_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_GL_SA                     
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----191.融资费用
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNC_FEE' as zbm
      ,sum(MRGNC_FEE) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNC_FEE                     
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----192.融券费用
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNS_FEE' as zbm
      ,sum(MRGNS_FEE) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNS_FEE                     
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----193.当日融资融券金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TDY_MRGNC_MRGNS_AMT' as zbm
      ,sum(TDY_MRGNC_MRGNS_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TDY_MRGNC_MRGNS_AMT           
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----194.当日融资金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TDY_MRGNC_AMT' as zbm
      ,sum(TDY_MRGNC_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TDY_MRGNC_AMT                 
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
; 

----195.当日融券金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TDY_MRGNS_AMT' as zbm
      ,sum(TDY_MRGNS_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TDY_MRGNS_AMT                 
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----196.融资授信额度
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNC_CRD_QUO' as zbm
      ,sum(MRGNC_CRD_QUO) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNC_CRD_QUO                 
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----197.融券授信额度
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNS_CRD_QUO' as zbm
      ,sum(MRGNS_CRD_QUO) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNS_CRD_QUO                 
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----198.融资交易量   
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNC_TRD_VOL' as zbm
      ,sum(MRGNC_TRD_VOL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNC_TRD_VOL                 
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----199.融券交易量  
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNS_TRD_VOL' as zbm
      ,sum(MRGNS_TRD_VOL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNS_TRD_VOL                 
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----200.交易量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL' as zbm
      ,sum(TRD_VOL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL                       
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----201.交易量(普通) 
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_ORDI' as zbm
      ,sum(TRD_VOL_ORDI) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_ORDI                  
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----202.交易量(信用) 
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_CRD' as zbm
      ,sum(TRD_VOL_CRD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_CRD                   
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----203.买入交易量(普通) 
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'BUYIN_TRD_VOL_ORDI' as zbm
      ,sum(BUYIN_TRD_VOL_ORDI) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,BUYIN_TRD_VOL_ORDI            
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----204.买入交易量(信用) 
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'BUYIN_TRD_VOL_CRD' as zbm
      ,sum(BUYIN_TRD_VOL_CRD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,BUYIN_TRD_VOL_CRD             
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----205.卖出交易量(普通) 
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'SELL_TRD_VOL_ORDI' as zbm
      ,sum(SELL_TRD_VOL_ORDI) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,SELL_TRD_VOL_ORDI             
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----206.卖出交易量(信用) 
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'SELL_TRD_VOL_CRD' as zbm
      ,sum(SELL_TRD_VOL_CRD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,SELL_TRD_VOL_CRD              
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----207.毛佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'S1' as zbm
      ,sum(S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,S1                            
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----208.普通交易毛佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_S1' as zbm
      ,sum(ORDI_TRD_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_S1                   
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----209.信用交易毛佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_S1' as zbm
      ,sum(CRD_TRD_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_S1                    
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----210.净佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NET_S1' as zbm
      ,sum(NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NET_S1                        
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----211.普通交易净佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_NET_S1' as zbm
      ,sum(ORDI_TRD_NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_NET_S1               
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----212.信用交易净佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_NET_S1' as zbm
      ,sum(CRD_TRD_NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_NET_S1                
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----213.成交笔数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MTCH_ITMS' as zbm
      ,sum(MTCH_ITMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MTCH_ITMS                     
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----214.融资成交笔数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNC_MTCH_ITMS' as zbm
      ,sum(MRGNC_MTCH_ITMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNC_MTCH_ITMS               
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----215.融券成交笔数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNS_MTCH_ITMS' as zbm
      ,sum(MRGNS_MTCH_ITMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNS_MTCH_ITMS               
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----216.当日归还利息
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TDY_RTN_INT' as zbm
      ,sum(TDY_RTN_INT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TDY_RTN_INT                   
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----217.归还利息
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'RTN_INT' as zbm
      ,sum(RTN_INT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,RTN_INT                       
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----218.还款金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'REP_AMT' as zbm
      ,sum(REP_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,REP_AMT                       
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----219.还券数量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'REP_QTY' as zbm
      ,sum(REP_QTY) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,REP_QTY                       
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----220.预计利息
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'PRDCT_INT' as zbm
      ,sum(PRDCT_INT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,PRDCT_INT                     
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----221.融资预计利息
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNC_PRDCT_INT' as zbm
      ,sum(MRGNC_PRDCT_INT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNC_PRDCT_INT               
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----222.融券预计利息
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNS_PRDCT_INT' as zbm
      ,sum(MRGNS_PRDCT_INT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNS_PRDCT_INT               
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----223.当日新增信用利息
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TDY_ADDED_CRD_INT' as zbm
      ,sum(TDY_ADDED_CRD_INT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TDY_ADDED_CRD_INT             
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----224.当日新增融资利息
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TDY_ADDED_MRGNC_INT' as zbm
      ,sum(TDY_ADDED_MRGNC_INT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TDY_ADDED_MRGNC_INT           
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----225.当日新增融券利息
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TDY_ADDED_MRGNS_INT' as zbm
      ,sum(TDY_ADDED_MRGNS_INT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TDY_ADDED_MRGNS_INT           
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----226.平仓次数 
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CP_TMS' as zbm
      ,sum(CP_TMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CP_TMS                        
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----227.追保次数 
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ADD_BOND_TMS' as zbm
      ,sum(ADD_BOND_TMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ADD_BOND_TMS                  
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----228.信用转入资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TFR_IN_AMT' as zbm
      ,sum(CRD_TFR_IN_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TFR_IN_AMT                
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----229.信用转出资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TURN_OUT_AMT' as zbm
      ,sum(CRD_TURN_OUT_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TURN_OUT_AMT              
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----230.信用转入市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TFR_IN_MKTVAL' as zbm
      ,sum(CRD_TFR_IN_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TFR_IN_MKTVAL             
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----231.信用转出市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TURN_OUT_MKTVAL' as zbm
      ,sum(CRD_TURN_OUT_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TURN_OUT_MKTVAL           
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----232.持仓成本
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'HLD_COST' as zbm
      ,sum(HLD_COST) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,HLD_COST                      
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----233.担保比例
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GNT_RTO' as zbm
      ,sum(GNT_RTO) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GNT_RTO                       
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----234.可用保证金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'AVL_BOND' as zbm
      ,sum(AVL_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,AVL_BOND                      
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----235.可充抵保证金证券市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CASH_DEP_CRD_MKTVAL' as zbm
      ,sum(CASH_DEP_CRD_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CASH_DEP_CRD_MKTVAL           
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----236.逾期次数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'OVDU_TMS' as zbm
      ,sum(OVDU_TMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,OVDU_TMS                      
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----237.信用盈亏
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_PRFT' as zbm
      ,sum(CRD_PRFT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_PRFT                      
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----238.卖券还券交易量   
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'SELL_TCK_PAY_TCK_TRD_VOL' as zbm
      ,sum(SELL_TCK_PAY_TCK_TRD_VOL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,SELL_TCK_PAY_TCK_TRD_VOL      
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----239.买券还券交易量 
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'BUY_TCK_PAY_TCK_TRD_VOL' as zbm
      ,sum(BUY_TCK_PAY_TCK_TRD_VOL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,BUY_TCK_PAY_TCK_TRD_VOL       
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----240.融资强平交易量   
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNC_COE_CP_TRD_VOL' as zbm
      ,sum(MRGNC_COE_CP_TRD_VOL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNC_COE_CP_TRD_VOL          
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----241.融券强平交易量  
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNS_COE_CP_TRD_VOL' as zbm
      ,sum(MRGNS_COE_CP_TRD_VOL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNS_COE_CP_TRD_VOL          
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----242.融资买入净佣金  
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNC_NET_S1' as zbm
      ,sum(MRGNC_NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNC_NET_S1                  
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----243.融券卖出净佣金  
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNS_NET_S1' as zbm
      ,sum(MRGNS_NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNS_NET_S1                  
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----244.卖券还券净佣金  
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'SELL_TCK_PAY_TCK_NET_S1' as zbm
      ,sum(SELL_TCK_PAY_TCK_NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,SELL_TCK_PAY_TCK_NET_S1       
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----245.买券还券净佣金   
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'BUY_TCK_PAY_TCK_NET_S1' as zbm
      ,sum(BUY_TCK_PAY_TCK_NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,BUY_TCK_PAY_TCK_NET_S1        
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----246.融资强平净佣金  
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNC_COE_CP_NET_S1' as zbm
      ,sum(MRGNC_COE_CP_NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNC_COE_CP_NET_S1           
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----247.融券强平净佣金   
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MRGNS_COE_CP_NET_S1' as zbm
      ,sum(MRGNS_COE_CP_NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MRGNS_COE_CP_NET_S1           
from DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----248.市值_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MKTVAL_HA' as zbm
      ,sum(MKTVAL_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MKTVAL_HA
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----249.普通账户市值_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_HA' as zbm
      ,sum(ORDI_MKTVAL_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_HA
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----250.信用账户市值_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_HA' as zbm
      ,sum(CRD_MKTVAL_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_HA
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----251.市值_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MKTVAL_SA' as zbm
      ,sum(MKTVAL_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MKTVAL_SA
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----252.普通账户市值_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_SA' as zbm
      ,sum(ORDI_MKTVAL_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_SA
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----253.信用账户市值_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_SA' as zbm
      ,sum(CRD_MKTVAL_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_SA
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----254.市值_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MKTVAL_SMS' as zbm
      ,sum(MKTVAL_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MKTVAL_SMS
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----255.普通账户市值_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_SMS' as zbm
      ,sum(ORDI_MKTVAL_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_SMS
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----256.信用账户市值_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_SMS' as zbm
      ,sum(CRD_MKTVAL_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_SMS
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----257.市值_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'MKTVAL_GEM' as zbm
      ,sum(MKTVAL_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,MKTVAL_GEM
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----258.普通账户市值_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_GEM' as zbm
      ,sum(ORDI_MKTVAL_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_GEM
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----259.信用账户市值_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_GEM' as zbm
      ,sum(CRD_MKTVAL_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_GEM
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----260.普通账户市值_沪B_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_HB_USD' as zbm
      ,sum(ORDI_MKTVAL_HB_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_HB_USD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----261.普通账户市值_深B_港币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_SB_HKD' as zbm
      ,sum(ORDI_MKTVAL_SB_HKD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_SB_HKD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----262.普通账户市值_沪港通
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_HK' as zbm
      ,sum(ORDI_MKTVAL_HK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_HK
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----263.普通账户市值_深港通
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_SK' as zbm
      ,sum(ORDI_MKTVAL_SK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_SK
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----264.普通账户市值_三板A股
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_TA' as zbm
      ,sum(ORDI_MKTVAL_TA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_TA
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----265.普通账户市值_三板B股_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_TU_USD' as zbm
      ,sum(ORDI_MKTVAL_TU_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_TU_USD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----266.代销基金市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'AGN_FND_MKTVAL' as zbm
      ,sum(AGN_FND_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,AGN_FND_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----267.公司产品市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GS_PROD_MKTVAL' as zbm
      ,sum(GS_PROD_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GS_PROD_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----268.国君产品市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GJ_PROD_MKTVAL' as zbm
      ,sum(GJ_PROD_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GJ_PROD_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----269.银行产品市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'BANK_PROD_MKTVAL' as zbm
      ,sum(BANK_PROD_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,BANK_PROD_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----270.OTC产品市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'OTC_PROD_MKTVAL' as zbm
      ,sum(OTC_PROD_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,OTC_PROD_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----271.期权账户权利仓市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_RGHT_HLD_MKTVAL' as zbm
      ,sum(WRNT_RGHT_HLD_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_RGHT_HLD_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----272.期权账户义务仓市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_DUTY_HLD_MKTVAL' as zbm
      ,sum(WRNT_DUTY_HLD_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_DUTY_HLD_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----273.普通账户证券市值_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_SEC_USD' as zbm
      ,sum(ORDI_MKTVAL_SEC_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_SEC_USD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----274.普通账户证券市值_港币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_SEC_HKD' as zbm
      ,sum(ORDI_MKTVAL_SEC_HKD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_SEC_HKD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----275.普通账户证券市值_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_SEC_RMD' as zbm
      ,sum(ORDI_MKTVAL_SEC_RMD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_SEC_RMD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----276.普通账户产品市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_PROD' as zbm
      ,sum(ORDI_MKTVAL_PROD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_PROD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----277.普通账户资金_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_CPTL_USD' as zbm
      ,sum(ORDI_CPTL_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_CPTL_USD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----278.普通账户资金_港币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_CPTL_HKD' as zbm
      ,sum(ORDI_CPTL_HKD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_CPTL_HKD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----279.普通账户资金_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_CPTL_RMB' as zbm
      ,sum(ORDI_CPTL_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_CPTL_RMB
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----280.普通账户存入金额_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_DEPIN_AMT_USD' as zbm
      ,sum(ORDI_DEPIN_AMT_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_DEPIN_AMT_USD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----281.普通账户存入金额_港币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_DEPIN_AMT_HKD' as zbm
      ,sum(ORDI_DEPIN_AMT_HKD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_DEPIN_AMT_HKD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----282.普通账户存入金额_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_DEPIN_AMT_RMB' as zbm
      ,sum(ORDI_DEPIN_AMT_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_DEPIN_AMT_RMB
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----283.普通账户转入金额(折算人民币)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TFR_IN_AMT' as zbm
      ,sum(ORDI_TFR_IN_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TFR_IN_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----284.普通账户取出金额_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_WTHDR_AMT_USD' as zbm
      ,sum(ORDI_WTHDR_AMT_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_WTHDR_AMT_USD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----285.普通账户取出金额_港币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_WTHDR_AMT_HKD' as zbm
      ,sum(ORDI_WTHDR_AMT_HKD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_WTHDR_AMT_HKD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----286.普通账户取出金额_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_WTHDR_AMT_RMB' as zbm
      ,sum(ORDI_WTHDR_AMT_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_WTHDR_AMT_RMB
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----287.普通账户转出金额(折算人民币)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TFR_OUT_AMT' as zbm
      ,sum(ORDI_TFR_OUT_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TFR_OUT_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----288.信用账户存入金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_DEPIN_AMT'
 as zbm
      ,sum(CRD_DEPIN_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_DEPIN_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----289.信用账户转入金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TFR_IN_AMT' as zbm
      ,sum(CRD_TFR_IN_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TFR_IN_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----290.信用账户取出金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_WTHDR_AMT' as zbm
      ,sum(CRD_WTHDR_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_WTHDR_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----291.信用账户转出金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TFR_OUT_AMT' as zbm
      ,sum(CRD_TFR_OUT_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TFR_OUT_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----292.期权账户存入金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_DEPIN_AMT' as zbm
      ,sum(WRNT_DEPIN_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_DEPIN_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----293.期权账户转入金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TFR_IN_AMT' as zbm
      ,sum(WRNT_TFR_IN_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TFR_IN_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----294.期权账户取出金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_WTHDR_AMT' as zbm
      ,sum(WRNT_WTHDR_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_WTHDR_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
where BUS_DATE = %d{yyyyMMdd}
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----295.期权账户转出金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TFR_OUT_AMT' as zbm
      ,sum(WRNT_TFR_OUT_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TFR_OUT_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----296.转入资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TFR_IN_AMT' as zbm
      ,sum(TFR_IN_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TFR_IN_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----297.转出资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TFR_OUT_AMT' as zbm
      ,sum(TFR_OUT_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TFR_OUT_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----298.普通账户净转入资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_TFR_IN_AMT' as zbm
      ,sum(ORDI_NET_TFR_IN_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_TFR_IN_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----299.信用账户净转入资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_TFR_IN_AMT' as zbm
      ,sum(CRD_NET_TFR_IN_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_TFR_IN_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----300.期权账户净转入资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_NET_TFR_IN_AMT' as zbm
      ,sum(WRNT_NET_TFR_IN_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_NET_TFR_IN_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----301.净转入资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NET_TFR_IN_AMT' as zbm
      ,sum(NET_TFR_IN_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NET_TFR_IN_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----302.普通账户指定转入市值_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_ASGN_TFR_IN_MKTVAL_RMB' as zbm
      ,sum(ORDI_ASGN_TFR_IN_MKTVAL_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_ASGN_TFR_IN_MKTVAL_RMB
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----303.普通账户指定转入市值_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_ASGN_TFR_IN_MKTVAL_USD' as zbm
      ,sum(ORDI_ASGN_TFR_IN_MKTVAL_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_ASGN_TFR_IN_MKTVAL_USD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----304.普通账户转托管转入市值_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB' as zbm
      ,sum(ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----305.普通账户转托管转入市值_港币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD' as zbm
      ,sum(ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----306.信用账户指定转入市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_ASGN_TFR_IN_MKTVAL' as zbm
      ,sum(CRD_ASGN_TFR_IN_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_ASGN_TFR_IN_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----307.信用账户转托管转入市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TFR_CSTD_TFR_IN_MKTVAL' as zbm
      ,sum(CRD_TFR_CSTD_TFR_IN_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TFR_CSTD_TFR_IN_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----308.普通账户撤指定转出市值_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_ASGN_TFR_OUT_MKTVAL_RMB' as zbm
      ,sum(ORDI_ASGN_TFR_OUT_MKTVAL_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_ASGN_TFR_OUT_MKTVAL_RMB
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----309.普通账户撤指定转出市值_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_ASGN_TFR_OUT_MKTVAL_USD' as zbm
      ,sum(ORDI_ASGN_TFR_OUT_MKTVAL_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_ASGN_TFR_OUT_MKTVAL_USD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----310.普通账户转托管转出市值_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB' as zbm
      ,sum(ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----311.普通账户转托管转出市值_港币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD' as zbm
      ,sum(ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----312.信用账户指定转出市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_ASGN_TFR_OUT_MKTVAL' as zbm
      ,sum(CRD_ASGN_TFR_OUT_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_ASGN_TFR_OUT_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----313.信用账户转托管转出市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TFR_CSTD_TFR_OUT_MKTVAL' as zbm
      ,sum(CRD_TFR_CSTD_TFR_OUT_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TFR_CSTD_TFR_OUT_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----314.普通账户转入市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TFR_IN_MKTVAL' as zbm
      ,sum(ORDI_TFR_IN_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TFR_IN_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----315.普通账户转出市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TFR_OUT_MKTVAL' as zbm
      ,sum(ORDI_TFR_OUT_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TFR_OUT_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----316.信用账户转入市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TFR_IN_MKTVAL' as zbm
      ,sum(CRD_TFR_IN_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TFR_IN_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----317.信用账户转出市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TFR_OUT_MKTVAL' as zbm
      ,sum(CRD_TFR_OUT_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TFR_OUT_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----318.转入市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TFR_IN_MKTVAL' as zbm
      ,sum(TFR_IN_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TFR_IN_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----319.转出市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TFR_OUT_MKTVAL' as zbm
      ,sum(TFR_OUT_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TFR_OUT_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----320.普通账户净转入市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_TFR_IN_MKTVAL' as zbm
      ,sum(ORDI_NET_TFR_IN_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_TFR_IN_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----321.信用账户净转入市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_TFR_IN_MKTVAL' as zbm
      ,sum(CRD_NET_TFR_IN_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_TFR_IN_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----322.净转入市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NET_TFR_IN_MKTVAL' as zbm
      ,sum(NET_TFR_IN_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NET_TFR_IN_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----323.普通账户资金(折算人民币)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_CPTL' as zbm
      ,sum(ORDI_CPTL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_CPTL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----324.普通账户在途资金(折算人民币)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_UNPY_CPTL' as zbm
      ,sum(ORDI_UNPY_CPTL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_UNPY_CPTL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----325.信用账户在途资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_UNPY_CPTL' as zbm
      ,sum(CRD_UNPY_CPTL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_UNPY_CPTL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----326.期权账户在途资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_UNPY_CPTL' as zbm
      ,sum(WRNT_UNPY_CPTL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_UNPY_CPTL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----327.信用账户资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_CPTL' as zbm
      ,sum(CRD_CPTL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_CPTL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----328.期权账户资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_CPTL' as zbm
      ,sum(WRNT_CPTL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_CPTL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----329.总的在途资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TOT_UNPY_CPTL' as zbm
      ,sum(TOT_UNPY_CPTL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TOT_UNPY_CPTL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----330.总资金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TOT_CPTL' as zbm
      ,sum(TOT_CPTL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TOT_CPTL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----331.普通账户证券市值(折算人民币)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_SEC_MKTVAL' as zbm
      ,sum(ORDI_SEC_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_SEC_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;
----332.普通账户市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL' as zbm
      ,sum(ORDI_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----333.普通账户非流通市值(折算人民币)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_UN_CIR_MKTVAL' as zbm
      ,sum(ORDI_UN_CIR_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_UN_CIR_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----334.信用账户证券市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_SEC_MKTVAL' as zbm
      ,sum(CRD_SEC_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_SEC_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----335.期权账户市值(权利仓市值-义务仓市值)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_MKTVAL' as zbm
      ,sum(WRNT_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----336.期权张数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_CNTS' as zbm
      ,sum(WRNT_CNTS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_CNTS
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----337.总市值
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TOT_MKTVAL' as zbm
      ,sum(TOT_MKTVAL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TOT_MKTVAL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----338.普通账户负债
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_GL' as zbm
      ,sum(ORDI_GL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_GL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----339.信用账户负债
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_GL' as zbm
      ,sum(CRD_GL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_GL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----340.总负债
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TOTGL' as zbm
      ,sum(TOTGL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TOTGL
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----341.普通资产(不包含OTC)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_AST_UN_OTC' as zbm
      ,sum(ORDI_AST_UN_OTC) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_AST_UN_OTC
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----342.普通资产
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_AST' as zbm
      ,sum(ORDI_AST) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_AST
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----343.普通净资产(不包含OTC)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_AST_UN_OTC' as zbm
      ,sum(ORDI_NET_AST_UN_OTC) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_AST_UN_OTC
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----344.普通净资产
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_AST' as zbm
      ,sum(ORDI_NET_AST) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_AST
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----345.信用资产
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_AST' as zbm
      ,sum(CRD_AST) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_AST
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----346.信用净资产
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_AST' as zbm
      ,sum(CRD_NET_AST) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_AST
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----347.期权资产
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_AST' as zbm
      ,sum(WRNT_AST) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_AST
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----348.总资产
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TOT_AST' as zbm
      ,sum(TOT_AST) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TOT_AST
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----349.场内净资产
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'EXG_NET_TOT_AST' as zbm
      ,sum(EXG_NET_TOT_AST) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,EXG_NET_TOT_AST
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----350.净总资产
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NET_TOT_AST' as zbm
      ,sum(NET_TOT_AST) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NET_TOT_AST
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----351.普通盈亏
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_PRFT' as zbm
      ,sum(ORDI_PRFT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_PRFT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----352.信用盈亏
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_PRFT' as zbm
      ,sum(CRD_PRFT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_PRFT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----353.期权盈亏
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_PRFT' as zbm
      ,sum(WRNT_PRFT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_PRFT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----354.总盈亏
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TOT_PRFT' as zbm
      ,sum(TOT_PRFT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TOT_PRFT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;
----355.普通账户市值_场内基金_沪市
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_EXG_FND_SH' as zbm
      ,sum(ORDI_MKTVAL_EXG_FND_SH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_EXG_FND_SH
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----356.普通账户市值_场内基金_深市
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_EXG_FND_SZ' as zbm
      ,sum(ORDI_MKTVAL_EXG_FND_SZ) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_EXG_FND_SZ
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----357.信用账户市值_场内基金_沪市
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_EXG_FND_SH' as zbm
      ,sum(CRD_MKTVAL_EXG_FND_SH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_EXG_FND_SH
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----358.信用账户市值_场内基金_深市
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_EXG_FND_SZ' as zbm
      ,sum(CRD_MKTVAL_EXG_FND_SZ) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_EXG_FND_SZ
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----359.普通账户市值_债券_沪市
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_BOND_SH' as zbm
      ,sum(ORDI_MKTVAL_BOND_SH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_BOND_SH
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----360.普通账户市值_债券_深市
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_BOND_SZ' as zbm
      ,sum(ORDI_MKTVAL_BOND_SZ) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_BOND_SZ
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----361.信用账户市值_债券_沪市
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_BOND_SH' as zbm
      ,sum(CRD_MKTVAL_BOND_SH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_BOND_SH
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----362.信用账户市值_债券_深市
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_BOND_SZ' as zbm
      ,sum(CRD_MKTVAL_BOND_SZ) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_BOND_SZ
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----363.普通账户沪市非流通市值(折算人民币)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_UN_CIR_MKTVAL_SH' as zbm
      ,sum(ORDI_UN_CIR_MKTVAL_SH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_UN_CIR_MKTVAL_SH
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----364.普通账户深市非流通市值(折算人民币)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_UN_CIR_MKTVAL_SZ' as zbm
      ,sum(ORDI_UN_CIR_MKTVAL_SZ) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_UN_CIR_MKTVAL_SZ
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----365.股票质押余额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'STK_PLG_AMT' as zbm
      ,sum(STK_PLG_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,STK_PLG_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----366.股票质押新增利息
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'STK_PLG_ADD_INT' as zbm
      ,sum(STK_PLG_ADD_INT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,STK_PLG_ADD_INT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----367.股票质押初始交易量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'STK_PLG_ADD_TRD_AMT' as zbm
      ,sum(STK_PLG_ADD_TRD_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,STK_PLG_ADD_TRD_AMT
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----368.普通账户市值_新三板A股
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_NEW_TA' as zbm
      ,sum(ORDI_MKTVAL_NEW_TA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_NEW_TA
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----369.普通账户市值_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_AK_STIB' as zbm
      ,sum(ORDI_MKTVAL_AK_STIB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_AK_STIB
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----370.普通账户市值_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_RK_STIB' as zbm
      ,sum(ORDI_MKTVAL_RK_STIB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_RK_STIB
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----371.信用账户市值_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_AK_STIB' as zbm
      ,sum(CRD_MKTVAL_AK_STIB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_AK_STIB
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----372.信用账户市值_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_RK_STIB' as zbm
      ,sum(CRD_MKTVAL_RK_STIB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_RK_STIB
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----373.普通账户市值_回购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_REPO' as zbm
      ,sum(ORDI_MKTVAL_REPO) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_REPO
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----374.普通账户市值_场内基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_EXG_FND' as zbm
      ,sum(ORDI_MKTVAL_EXG_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_EXG_FND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----375.普通账户市值_封闭式基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_CLS_FND' as zbm
      ,sum(ORDI_MKTVAL_CLS_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_CLS_FND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----376.普通账户市值_ETF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_ETF_FND' as zbm
      ,sum(ORDI_MKTVAL_ETF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_ETF_FND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----377.普通账户市值_开放式
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_OPN_FND' as zbm
      ,sum(ORDI_MKTVAL_OPN_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_OPN_FND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----378.普通账户市值_LOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_LOF_FND' as zbm
      ,sum(ORDI_MKTVAL_LOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_LOF_FND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----379.普通账户市值_FOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_FOF_FND' as zbm
      ,sum(ORDI_MKTVAL_FOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_FOF_FND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----380.信用账户市值_场内基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_EXG_FND' as zbm
      ,sum(CRD_MKTVAL_EXG_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_EXG_FND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----381.信用账户市值_封闭式基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_CLS_FND' as zbm
      ,sum(CRD_MKTVAL_CLS_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_CLS_FND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----382.信用账户市值_ETF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_ETF_FND' as zbm
      ,sum(CRD_MKTVAL_ETF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_ETF_FND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----383.信用账户市值_开放式
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_OPN_FND' as zbm
      ,sum(CRD_MKTVAL_OPN_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_OPN_FND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----384.信用账户市值_LOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_LOF_FND' as zbm
      ,sum(CRD_MKTVAL_LOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_LOF_FND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----385.信用账户市值_FOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_FOF_FND' as zbm
      ,sum(CRD_MKTVAL_FOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_FOF_FND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----386.普通账户市值_债券
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_MKTVAL_BOND' as zbm
      ,sum(ORDI_MKTVAL_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_MKTVAL_BOND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----387.信用账户市值_债券
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_MKTVAL_BOND' as zbm
      ,sum(CRD_MKTVAL_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_MKTVAL_BOND
from DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----388.普通账户佣金收入(人民币)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_RMB' as zbm
      ,sum(ORDI_S1_INCM_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----389.信用账户佣金收入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM' as zbm
      ,sum(CRD_S1_INCM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----390.普通账户佣金收入_其他(包括权证等)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_OTH_RMB' as zbm
      ,sum(ORDI_S1_INCM_OTH_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_OTH_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----391.佣金收入_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'S1_INCM_HA' as zbm
      ,sum(S1_INCM_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,S1_INCM_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----392.普通账户佣金收入_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_HA' as zbm
      ,sum(ORDI_S1_INCM_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----393.信用账户佣金收入_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_HA' as zbm
      ,sum(CRD_S1_INCM_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----394.佣金收入_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'S1_INCM_SA' as zbm
      ,sum(S1_INCM_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,S1_INCM_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----395.普通账户佣金收入_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_SA' as zbm
      ,sum(ORDI_S1_INCM_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----396.信用账户佣金收入_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_SA' as zbm
      ,sum(CRD_S1_INCM_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----397.佣金收入_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'S1_INCM_SMS' as zbm
      ,sum(S1_INCM_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,S1_INCM_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----398.普通账户佣金收入_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_SMS' as zbm
      ,sum(ORDI_S1_INCM_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----399.信用账户佣金收入_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_SMS' as zbm
      ,sum(CRD_S1_INCM_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----400.佣金收入_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'S1_INCM_GEM' as zbm
      ,sum(S1_INCM_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,S1_INCM_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----401.普通账户佣金收入_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_GEM' as zbm
      ,sum(ORDI_S1_INCM_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----402.信用账户佣金收入_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_GEM' as zbm
      ,sum(CRD_S1_INCM_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----403.普通账户佣金收入_沪港通
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_HK' as zbm
      ,sum(ORDI_S1_INCM_HK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_HK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----404.普通账户佣金收入_深港通
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_SK' as zbm
      ,sum(ORDI_S1_INCM_SK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_SK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----405.普通账户佣金收入_债券
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_BOND' as zbm
      ,sum(ORDI_S1_INCM_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_BOND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----406.信用账户佣金收入_债券
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_BOND' as zbm
      ,sum(CRD_S1_INCM_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_BOND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----407.普通账户净佣金收入(人民币)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_RMB' as zbm
      ,sum(ORDI_NET_S1_INCM_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----408.信用账户净佣金收入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM' as zbm
      ,sum(CRD_NET_S1_INCM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----409.普通账户净佣金收入_其他(包括权证等)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_OTH_RMB' as zbm
      ,sum(ORDI_NET_S1_INCM_OTH_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_OTH_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----410.净佣金收入_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NET_S1_INCM_HA' as zbm
      ,sum(NET_S1_INCM_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NET_S1_INCM_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----411.普通账户净佣金收入_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_HA' as zbm
      ,sum(ORDI_NET_S1_INCM_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----412.信用账户净佣金收入_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_HA' as zbm
      ,sum(CRD_NET_S1_INCM_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----413.净佣金收入_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NET_S1_INCM_SA' as zbm
      ,sum(NET_S1_INCM_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NET_S1_INCM_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----414.普通账户净佣金收入_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_SA' as zbm
      ,sum(ORDI_NET_S1_INCM_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----415.信用账户净佣金收入_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_SA' as zbm
      ,sum(CRD_NET_S1_INCM_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----416.净佣金收入_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NET_S1_INCM_SMS' as zbm
      ,sum(NET_S1_INCM_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NET_S1_INCM_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----417.普通账户净佣金收入_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_SMS' as zbm
      ,sum(ORDI_NET_S1_INCM_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----418.信用账户净佣金收入_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_SMS' as zbm
      ,sum(CRD_NET_S1_INCM_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----419.净佣金收入_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NET_S1_INCM_GEM' as zbm
      ,sum(NET_S1_INCM_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NET_S1_INCM_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----420.普通账户净佣金收入_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_GEM' as zbm
      ,sum(ORDI_NET_S1_INCM_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----421.信用账户净佣金收入_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_GEM' as zbm
      ,sum(CRD_NET_S1_INCM_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----422.普通账户净佣金收入_沪港通
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_HK' as zbm
      ,sum(ORDI_NET_S1_INCM_HK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_HK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----423.普通账户净佣金收入_深港通
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_SK' as zbm
      ,sum(ORDI_NET_S1_INCM_SK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_SK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----424.普通账户净佣金收入_债券
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_BOND' as zbm
      ,sum(ORDI_NET_S1_INCM_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_BOND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----425.信用账户净佣金收入_债券
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_BOND' as zbm
      ,sum(CRD_NET_S1_INCM_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_BOND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----426.普通账户交易费用(人民币)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_RMB' as zbm
      ,sum(ORDI_TRD_FEE_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----427.信用账户交易费用
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE' as zbm
      ,sum(CRD_TRD_FEE) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----428.普通账户交易费用_其他(包括权证等)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_OTH_RMB' as zbm
      ,sum(ORDI_TRD_FEE_OTH_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_OTH_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----429.交易费用_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_FEE_HA' as zbm
      ,sum(TRD_FEE_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_FEE_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----430.普通账户交易费用_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_HA' as zbm
      ,sum(ORDI_TRD_FEE_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----431.信用账户交易费用_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_HA' as zbm
      ,sum(CRD_TRD_FEE_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
where bus_date = %d{yyyyMMdd}
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----432.交易费用_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_FEE_SA' as zbm
      ,sum(TRD_FEE_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_FEE_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----433.普通账户交易费用_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_SA' as zbm
      ,sum(ORDI_TRD_FEE_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----434.信用账户交易费用_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_SA' as zbm
      ,sum(CRD_TRD_FEE_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----435.交易费用_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_FEE_SMS' as zbm
      ,sum(TRD_FEE_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_FEE_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----436.普通账户交易费用_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_SMS' as zbm
      ,sum(ORDI_TRD_FEE_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----437.信用账户交易费用_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_SMS' as zbm
      ,sum(CRD_TRD_FEE_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----438.交易费用_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_FEE_GEM' as zbm
      ,sum(TRD_FEE_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_FEE_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----439.普通账户交易费用_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_GEM' as zbm
      ,sum(ORDI_TRD_FEE_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----440.信用账户交易费用_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_GEM' as zbm
      ,sum(CRD_TRD_FEE_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----441.普通账户交易费用_沪港通
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_HK' as zbm
      ,sum(ORDI_TRD_FEE_HK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_HK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----442.普通账户交易费用_深港通
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_SK' as zbm
      ,sum(ORDI_TRD_FEE_SK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_SK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----443.普通账户交易费用_债券
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_BOND' as zbm
      ,sum(ORDI_TRD_FEE_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_BOND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----444.信用账户交易费用_债券
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_BOND' as zbm
      ,sum(CRD_TRD_FEE_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_BOND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----445.产品手续费
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'PROD_CMSN_FEE' as zbm
      ,sum(PROD_CMSN_FEE) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,PROD_CMSN_FEE
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----446.代销基金手续费
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'AGN_FND_CMSN_FEE' as zbm
      ,sum(AGN_FND_CMSN_FEE) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,AGN_FND_CMSN_FEE
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----447.公司产品手续费
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GS_PROD_CMSN_FEE' as zbm
      ,sum(GS_PROD_CMSN_FEE) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GS_PROD_CMSN_FEE
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----448.国君产品手续费
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GJ_PROD_CMSN_FEE' as zbm
      ,sum(GJ_PROD_CMSN_FEE) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GJ_PROD_CMSN_FEE
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----449.OTC产品手续费
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'OTC_PROD_CMSN_FEE' as zbm
      ,sum(OTC_PROD_CMSN_FEE) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,OTC_PROD_CMSN_FEE
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----450.产品认购金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'PROD_SCRP_AMT' as zbm
      ,sum(PROD_SCRP_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,PROD_SCRP_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----451.产品申购金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'PROD_PRCH_AMT' as zbm
      ,sum(PROD_PRCH_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,PROD_PRCH_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----452.产品定投金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'PROD_FIXINV_AMT' as zbm
      ,sum(PROD_FIXINV_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,PROD_FIXINV_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----453.产品赎回金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'PROD_RDMPT_AMT' as zbm
      ,sum(PROD_RDMPT_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,PROD_RDMPT_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----454.代销基金认购金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'AGN_FND_SCRP_AMT' as zbm
      ,sum(AGN_FND_SCRP_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,AGN_FND_SCRP_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----455.代销基金申购金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'AGN_FND_PRCH_AMT' as zbm
      ,sum(AGN_FND_PRCH_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,AGN_FND_PRCH_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----456.代销基金定投金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'AGN_FND_FIXINV_AMT' as zbm
      ,sum(AGN_FND_FIXINV_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,AGN_FND_FIXINV_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----457.代销基金赎回金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'AGN_FND_RDMPT_AMT' as zbm
      ,sum(AGN_FND_RDMPT_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,AGN_FND_RDMPT_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----458.公司产品认购金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GS_PROD_SCRP_AMT' as zbm
      ,sum(GS_PROD_SCRP_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GS_PROD_SCRP_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----459.公司产品申购金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GS_PROD_PRCH_AMT' as zbm
      ,sum(GS_PROD_PRCH_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GS_PROD_PRCH_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----460.公司产品定投金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GS_PROD_FIXINV_AMT' as zbm
      ,sum(GS_PROD_FIXINV_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GS_PROD_FIXINV_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----461.公司产品赎回金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GS_PROD_RDMPT_AMT' as zbm
      ,sum(GS_PROD_RDMPT_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GS_PROD_RDMPT_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----462.国君产品认购金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GJ_PROD_SCRP_AMT' as zbm
      ,sum(GJ_PROD_SCRP_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GJ_PROD_SCRP_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----463.国君产品申购金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GJ_PROD_PRCH_AMT' as zbm
      ,sum(GJ_PROD_PRCH_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GJ_PROD_PRCH_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----464.国君产品定投金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GJ_PROD_FIXINV_AMT' as zbm
      ,sum(GJ_PROD_FIXINV_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GJ_PROD_FIXINV_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----465.国君产品赎回金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'GJ_PROD_RDMPT_AMT' as zbm
      ,sum(GJ_PROD_RDMPT_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,GJ_PROD_RDMPT_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----466.银行产品认购金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'BANK_PROD_SCRP_AMT' as zbm
      ,sum(BANK_PROD_SCRP_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,BANK_PROD_SCRP_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----467.银行产品申购金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'BANK_PROD_PRCH_AMT' as zbm
      ,sum(BANK_PROD_PRCH_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,BANK_PROD_PRCH_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----468.银行产品赎回金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'BANK_PROD_RDMPT_AMT' as zbm
      ,sum(BANK_PROD_RDMPT_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,BANK_PROD_RDMPT_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----469.OTC产品认购金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'OTC_PROD_SCRP_AMT' as zbm
      ,sum(OTC_PROD_SCRP_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,OTC_PROD_SCRP_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----470.OTC产品申购金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'OTC_PROD_PRCH_AMT' as zbm
      ,sum(OTC_PROD_PRCH_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,OTC_PROD_PRCH_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----471.OTC产品赎回金额
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'OTC_PROD_RDMPT_AMT' as zbm
      ,sum(OTC_PROD_RDMPT_AMT) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,OTC_PROD_RDMPT_AMT
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----472.普通账户交易量(人民币)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_RMB' as zbm
      ,sum(ORDI_TRD_VOL_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----473.普通账户交易量(人民币)(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_RMB_80' as zbm
      ,sum(ORDI_TRD_VOL_RMB_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_RMB_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----474.普通账户交易量(人民币)_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_RMB_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_RMB_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_RMB_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----475.普通账户交易量(人民币)_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_RMB_SELL' as zbm
      ,sum(ORDI_TRD_VOL_RMB_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_RMB_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----476.普通账户交易量(人民币)_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_RMB_PRCH' as zbm
      ,sum(ORDI_TRD_VOL_RMB_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_RMB_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----477.信用账户交易量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL' as zbm
      ,sum(CRD_TRD_VOL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----478.信用账户交易量(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_80' as zbm
      ,sum(CRD_TRD_VOL_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----479.信用账户交易量_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----480.信用账户交易量_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_SELL' as zbm
      ,sum(CRD_TRD_VOL_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----481.信用账户交易量_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_PRCH' as zbm
      ,sum(CRD_TRD_VOL_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----482.普通账户交易量_其他(包括权证等)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_OTH_RMB' as zbm
      ,sum(ORDI_TRD_VOL_OTH_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_OTH_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----483.普通账户交易量_其他(包括权证等)_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_OTH_RMB_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_OTH_RMB_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_OTH_RMB_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----484.普通账户交易量_其他(包括权证等)_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_OTH_RMB_SELL' as zbm
      ,sum(ORDI_TRD_VOL_OTH_RMB_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_OTH_RMB_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----485.交易量_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_HA' as zbm
      ,sum(TRD_VOL_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----486.交易量_沪A主板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_HA_80' as zbm
      ,sum(TRD_VOL_HA_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_HA_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----487.交易量_沪A主板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_HA_BUYIN' as zbm
      ,sum(TRD_VOL_HA_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_HA_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----488.交易量_沪A主板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_HA_SELL' as zbm
      ,sum(TRD_VOL_HA_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_HA_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----489.交易量_沪A主板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_HA_PRCH' as zbm
      ,sum(TRD_VOL_HA_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_HA_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----490.普通账户交易量_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HA' as zbm
      ,sum(ORDI_TRD_VOL_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----491.普通账户交易量_沪A主板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HA_80' as zbm
      ,sum(ORDI_TRD_VOL_HA_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HA_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----492.普通账户交易量_沪A主板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HA_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_HA_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HA_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----493.普通账户交易量_沪A主板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HA_SELL' as zbm
      ,sum(ORDI_TRD_VOL_HA_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HA_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----494.普通账户交易量_沪A主板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HA_PRCH' as zbm
      ,sum(ORDI_TRD_VOL_HA_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HA_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----495.信用账户交易量_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_HA' as zbm
      ,sum(CRD_TRD_VOL_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----496.信用账户交易量_沪A主板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_HA_80' as zbm
      ,sum(CRD_TRD_VOL_HA_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_HA_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----497.信用账户交易量_沪A主板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_HA_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_HA_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_HA_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----498.信用账户交易量_沪A主板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_HA_SELL' as zbm
      ,sum(CRD_TRD_VOL_HA_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_HA_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----499.信用账户交易量_沪A主板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_HA_PRCH' as zbm
      ,sum(CRD_TRD_VOL_HA_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_HA_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----500.交易量_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_SA' as zbm
      ,sum(TRD_VOL_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----501.交易量_深A主板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_SA_80' as zbm
      ,sum(TRD_VOL_SA_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_SA_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----502.交易量_深A主板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_SA_BUYIN' as zbm
      ,sum(TRD_VOL_SA_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_SA_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----503.交易量_深A主板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_SA_SELL' as zbm
      ,sum(TRD_VOL_SA_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_SA_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----504.交易量_深A主板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_SA_PRCH' as zbm
      ,sum(TRD_VOL_SA_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_SA_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----505.普通账户交易量_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SA' as zbm
      ,sum(ORDI_TRD_VOL_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----506.普通账户交易量_深A主板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SA_80' as zbm
      ,sum(ORDI_TRD_VOL_SA_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SA_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----507.普通账户交易量_深A主板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SA_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_SA_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SA_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----508.普通账户交易量_深A主板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SA_SELL' as zbm
      ,sum(ORDI_TRD_VOL_SA_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SA_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----509.普通账户交易量_深A主板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SA_PRCH' as zbm
      ,sum(ORDI_TRD_VOL_SA_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SA_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----510.信用账户交易量_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_SA' as zbm
      ,sum(CRD_TRD_VOL_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----511.信用账户交易量_深A主板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_SA_80' as zbm
      ,sum(CRD_TRD_VOL_SA_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_SA_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----512.信用账户交易量_深A主板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_SA_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_SA_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_SA_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----513.信用账户交易量_深A主板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_SA_SELL' as zbm
      ,sum(CRD_TRD_VOL_SA_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_SA_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----514.信用账户交易量_深A主板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_SA_PRCH' as zbm
      ,sum(CRD_TRD_VOL_SA_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_SA_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----515.交易量_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_SMS' as zbm
      ,sum(TRD_VOL_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----516.交易量_中小板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_SMS_80' as zbm
      ,sum(TRD_VOL_SMS_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_SMS_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----517.交易量_中小板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_SMS_BUYIN' as zbm
      ,sum(TRD_VOL_SMS_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_SMS_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----518.交易量_中小板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_SMS_SELL' as zbm
      ,sum(TRD_VOL_SMS_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_SMS_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----519.交易量_中小板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_SMS_PRCH' as zbm
      ,sum(TRD_VOL_SMS_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_SMS_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----520.普通账户交易量_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SMS' as zbm
      ,sum(ORDI_TRD_VOL_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----521.普通账户交易量_中小板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SMS_80' as zbm
      ,sum(ORDI_TRD_VOL_SMS_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SMS_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----522.普通账户交易量_中小板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SMS_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_SMS_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SMS_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----523.普通账户交易量_中小板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SMS_SELL' as zbm
      ,sum(ORDI_TRD_VOL_SMS_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SMS_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----524.普通账户交易量_中小板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SMS_PRCH' as zbm
      ,sum(ORDI_TRD_VOL_SMS_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SMS_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----525.信用账户交易量_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_SMS' as zbm
      ,sum(CRD_TRD_VOL_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----526.信用账户交易量_中小板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_SMS_80' as zbm
      ,sum(CRD_TRD_VOL_SMS_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_SMS_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----527.信用账户交易量_中小板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_SMS_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_SMS_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_SMS_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----528.信用账户交易量_中小板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_SMS_SELL' as zbm
      ,sum(CRD_TRD_VOL_SMS_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_SMS_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----529.信用账户交易量_中小板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_SMS_PRCH' as zbm
      ,sum(CRD_TRD_VOL_SMS_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_SMS_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----530.交易量_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_GEM' as zbm
      ,sum(TRD_VOL_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----531.交易量_创业板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_GEM_80' as zbm
      ,sum(TRD_VOL_GEM_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_GEM_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----532.交易量_创业板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_GEM_BUYIN' as zbm
      ,sum(TRD_VOL_GEM_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_GEM_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----533.交易量_创业板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_GEM_SELL' as zbm
      ,sum(TRD_VOL_GEM_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_GEM_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----534.交易量_创业板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_GEM_PRCH' as zbm
      ,sum(TRD_VOL_GEM_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_GEM_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----535.普通账户交易量_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_GEM' as zbm
      ,sum(ORDI_TRD_VOL_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----536.普通账户交易量_创业板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_GEM_80' as zbm
      ,sum(ORDI_TRD_VOL_GEM_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_GEM_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----537.普通账户交易量_创业板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_GEM_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_GEM_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_GEM_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----538.普通账户交易量_创业板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_GEM_SELL' as zbm
      ,sum(ORDI_TRD_VOL_GEM_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_GEM_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----539.普通账户交易量_创业板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_GEM_PRCH' as zbm
      ,sum(ORDI_TRD_VOL_GEM_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_GEM_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----540.信用账户交易量_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_GEM' as zbm
      ,sum(CRD_TRD_VOL_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----541.信用账户交易量_创业板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_GEM_80' as zbm
      ,sum(CRD_TRD_VOL_GEM_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_GEM_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----542.信用账户交易量_创业板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_GEM_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_GEM_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_GEM_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----543.信用账户交易量_创业板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_GEM_SELL' as zbm
      ,sum(CRD_TRD_VOL_GEM_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_GEM_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----544.信用账户交易量_创业板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_GEM_PRCH' as zbm
      ,sum(CRD_TRD_VOL_GEM_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_GEM_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----545.普通账户交易量_沪B_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HB_USD' as zbm
      ,sum(ORDI_TRD_VOL_HB_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HB_USD
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----546.普通账户交易量_沪B_美元_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HB_USD_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_HB_USD_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HB_USD_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----547.普通账户交易量_沪B_美元_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HB_USD_SELL' as zbm
      ,sum(ORDI_TRD_VOL_HB_USD_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HB_USD_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----548.普通账户交易量_深B_港币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SB_HKD' as zbm
      ,sum(ORDI_TRD_VOL_SB_HKD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SB_HKD
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----549.普通账户交易量_深B_港币_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SB_HKD_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_SB_HKD_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SB_HKD_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----550.普通账户交易量_深B_港币_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SB_HKD_SELL' as zbm
      ,sum(ORDI_TRD_VOL_SB_HKD_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SB_HKD_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----551.普通账户交易量_沪港通
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HK' as zbm
      ,sum(ORDI_TRD_VOL_HK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----552.普通账户交易量_沪港通_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HK_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_HK_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HK_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----553.普通账户交易量_沪港通_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HK_SELL' as zbm
      ,sum(ORDI_TRD_VOL_HK_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HK_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----554.普通账户交易量_深港通
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SK' as zbm
      ,sum(ORDI_TRD_VOL_SK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----555.普通账户交易量_深港通_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SK_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_SK_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SK_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----556.普通账户交易量_深港通_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SK_SELL' as zbm
      ,sum(ORDI_TRD_VOL_SK_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SK_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----557.普通账户交易量_三板A股
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_TA' as zbm
      ,sum(ORDI_TRD_VOL_TA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_TA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----558.普通账户交易量_三板A股_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_TA_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_TA_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_TA_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----559.普通账户交易量_三板A股_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_TA_SELL' as zbm
      ,sum(ORDI_TRD_VOL_TA_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_TA_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----560.普通账户交易量_三板B股_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_TU_USD' as zbm
      ,sum(ORDI_TRD_VOL_TU_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_TU_USD
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----561.普通账户交易量_三板B股_美元_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_TU_USD_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_TU_USD_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_TU_USD_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----562.普通账户交易量_三板B股_美元_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_TU_USD_SELL' as zbm
      ,sum(ORDI_TRD_VOL_TU_USD_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_TU_USD_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----563.普通账户交易量_回购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_REPO' as zbm
      ,sum(ORDI_TRD_VOL_REPO) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_REPO
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----564.普通账户交易量_回购_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_REPO_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_REPO_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_REPO_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----565.普通账户交易量_回购_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_REPO_SELL' as zbm
      ,sum(ORDI_TRD_VOL_REPO_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_REPO_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----566.普通账户交易量_场内基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_EXG_FND' as zbm
      ,sum(ORDI_TRD_VOL_EXG_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_EXG_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----567.普通账户交易量_场内基金_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_EXG_FND_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_EXG_FND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_EXG_FND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----568.普通账户交易量_场内基金_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_EXG_FND_SELL' as zbm
      ,sum(ORDI_TRD_VOL_EXG_FND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_EXG_FND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----569.普通账户交易量_封闭式基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_CLS_FND' as zbm
      ,sum(ORDI_TRD_VOL_CLS_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_CLS_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----570.普通账户交易量_封闭式基金_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_CLS_FND_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_CLS_FND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_CLS_FND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----571.普通账户交易量_封闭式基金_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_CLS_FND_SELL' as zbm
      ,sum(ORDI_TRD_VOL_CLS_FND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_CLS_FND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----572.普通账户交易量_ETF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_ETF_FND' as zbm
      ,sum(ORDI_TRD_VOL_ETF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_ETF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----573.普通账户交易量_ETF_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_ETF_FND_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_ETF_FND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_ETF_FND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----574.普通账户交易量_ETF_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_ETF_FND_SELL' as zbm
      ,sum(ORDI_TRD_VOL_ETF_FND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_ETF_FND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----575.普通账户交易量_开放式
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_OPN_FND' as zbm
      ,sum(ORDI_TRD_VOL_OPN_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_OPN_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----576.普通账户交易量_开放式_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_OPN_FND_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_OPN_FND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_OPN_FND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----577.普通账户交易量_开放式_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_OPN_FND_SELL' as zbm
      ,sum(ORDI_TRD_VOL_OPN_FND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_OPN_FND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----578.普通账户交易量_LOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_LOF_FND' as zbm
      ,sum(ORDI_TRD_VOL_LOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_LOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----579.普通账户交易量_LOF_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_LOF_FND_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_LOF_FND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_LOF_FND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;


----580.普通账户交易量_LOF_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_LOF_FND_SELL' as zbm
      ,sum(ORDI_TRD_VOL_LOF_FND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_LOF_FND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----581.普通账户交易量_FOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_FOF_FND' as zbm
      ,sum(ORDI_TRD_VOL_FOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_FOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----582.普通账户交易量_FOF_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_FOF_FND_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_FOF_FND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_FOF_FND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----583.普通账户交易量_FOF_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_FOF_FND_SELL' as zbm
      ,sum(ORDI_TRD_VOL_FOF_FND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_FOF_FND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----584.信用账户交易量_场内基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_EXG_FND' as zbm
      ,sum(CRD_TRD_VOL_EXG_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_EXG_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----585.信用账户交易量_场内基金_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_EXG_FND_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_EXG_FND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_EXG_FND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----586.信用账户交易量_场内基金_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_EXG_FND_SELL' as zbm
      ,sum(CRD_TRD_VOL_EXG_FND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_EXG_FND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----587.信用账户交易量_封闭式基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_CLS_FND' as zbm
      ,sum(CRD_TRD_VOL_CLS_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_CLS_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----588.信用账户交易量_封闭式基金_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_CLS_FND_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_CLS_FND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_CLS_FND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----589.信用账户交易量_封闭式基金_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_CLS_FND_SELL' as zbm
      ,sum(CRD_TRD_VOL_CLS_FND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_CLS_FND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----590.信用账户交易量_ETF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_ETF_FND' as zbm
      ,sum(CRD_TRD_VOL_ETF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_ETF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----591.信用账户交易量_ETF_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_ETF_FND_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_ETF_FND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_ETF_FND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----592.信用账户交易量_ETF_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_ETF_FND_SELL' as zbm
      ,sum(CRD_TRD_VOL_ETF_FND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_ETF_FND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----593.信用账户交易量_开放式
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_OPN_FND' as zbm
      ,sum(CRD_TRD_VOL_OPN_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_OPN_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----594.信用账户交易量_开放式_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_OPN_FND_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_OPN_FND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_OPN_FND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----595.信用账户交易量_开放式_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_OPN_FND_SELL' as zbm
      ,sum(CRD_TRD_VOL_OPN_FND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_OPN_FND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----596.信用账户交易量_LOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_LOF_FND' as zbm
      ,sum(CRD_TRD_VOL_LOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_LOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----597.信用账户交易量_LOF_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_LOF_FND_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_LOF_FND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_LOF_FND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----598.信用账户交易量_LOF_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_LOF_FND_SELL' as zbm
      ,sum(CRD_TRD_VOL_LOF_FND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_LOF_FND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----599.信用账户交易量_FOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_FOF_FND' as zbm
      ,sum(CRD_TRD_VOL_FOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_FOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----600.信用账户交易量_FOF_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_FOF_FND_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_FOF_FND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_FOF_FND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----601.信用账户交易量_FOF_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_FOF_FND_SELL' as zbm
      ,sum(CRD_TRD_VOL_FOF_FND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_FOF_FND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----602.普通账户交易量_债券
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_BOND' as zbm
      ,sum(ORDI_TRD_VOL_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_BOND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----603.普通账户交易量_债券(不包含债券的申购)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_BOND_80' as zbm
      ,sum(ORDI_TRD_VOL_BOND_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_BOND_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----604.普通账户交易量_债券_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_BOND_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_BOND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_BOND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----605.普通账户交易量_债券_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_BOND_SELL' as zbm
      ,sum(ORDI_TRD_VOL_BOND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_BOND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----606.普通账户交易量_债券_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_BOND_PRCH' as zbm
      ,sum(ORDI_TRD_VOL_BOND_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_BOND_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----607.信用账户交易量_债券
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_BOND' as zbm
      ,sum(CRD_TRD_VOL_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_BOND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----608.信用账户交易量_债券(不包含债券的申购)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_BOND_80' as zbm
      ,sum(CRD_TRD_VOL_BOND_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_BOND_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----609.信用账户交易量_债券_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_BOND_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_BOND_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_BOND_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----610.信用账户交易量_债券_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_BOND_SELL' as zbm
      ,sum(CRD_TRD_VOL_BOND_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_BOND_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----611.信用账户交易量_债券_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_BOND_PRCH' as zbm
      ,sum(CRD_TRD_VOL_BOND_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_BOND_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----612.普通账户交易笔数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS' as zbm
      ,sum(ORDI_TRD_ITMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----613.普通账户交易笔数(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_80' as zbm
      ,sum(ORDI_TRD_ITMS_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----614.信用账户交易笔数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS' as zbm
      ,sum(CRD_TRD_ITMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----615.信用账户交易笔数(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_80' as zbm
      ,sum(CRD_TRD_ITMS_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----616.普通账户交易笔数_其他(包括权证等)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_OTH' as zbm
      ,sum(ORDI_TRD_ITMS_OTH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_OTH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----617.交易笔数_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_ITMS_HA' as zbm
      ,sum(TRD_ITMS_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_ITMS_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----618.交易笔数_沪A主板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_ITMS_HA_80' as zbm
      ,sum(TRD_ITMS_HA_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_ITMS_HA_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----619.普通账户交易笔数_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_HA' as zbm
      ,sum(ORDI_TRD_ITMS_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----620.普通账户交易笔数_沪A主板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_HA_80' as zbm
      ,sum(ORDI_TRD_ITMS_HA_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_HA_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----621.信用账户交易笔数_沪A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_HA' as zbm
      ,sum(CRD_TRD_ITMS_HA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_HA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----622.信用账户交易笔数_沪A主板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_HA_80' as zbm
      ,sum(CRD_TRD_ITMS_HA_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_HA_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----623.交易笔数_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_ITMS_SA' as zbm
      ,sum(TRD_ITMS_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_ITMS_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----624.交易笔数_深A主板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_ITMS_SA_80' as zbm
      ,sum(TRD_ITMS_SA_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_ITMS_SA_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----625.普通账户交易笔数_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_SA' as zbm
      ,sum(ORDI_TRD_ITMS_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----626.普通账户交易笔数_深A主板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_SA_80' as zbm
      ,sum(ORDI_TRD_ITMS_SA_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_SA_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----627.信用账户交易笔数_深A主板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_SA' as zbm
      ,sum(CRD_TRD_ITMS_SA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_SA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----628.交易笔数_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_ITMS_SMS' as zbm
      ,sum(TRD_ITMS_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_ITMS_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----629.交易笔数_中小板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_ITMS_SMS_80' as zbm
      ,sum(TRD_ITMS_SMS_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_ITMS_SMS_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----630.普通账户交易笔数_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_SMS' as zbm
      ,sum(ORDI_TRD_ITMS_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----631.普通账户交易笔数_中小板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_SMS_80' as zbm
      ,sum(ORDI_TRD_ITMS_SMS_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_SMS_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----632.信用账户交易笔数_中小板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_SMS' as zbm
      ,sum(CRD_TRD_ITMS_SMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_SMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----633.信用账户交易笔数_中小板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_SMS_80' as zbm
      ,sum(CRD_TRD_ITMS_SMS_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_SMS_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----634.交易笔数_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_ITMS_GEM' as zbm
      ,sum(TRD_ITMS_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_ITMS_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----635.交易笔数_创业板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_ITMS_GEM_80' as zbm
      ,sum(TRD_ITMS_GEM_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_ITMS_GEM_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----636.普通账户交易笔数_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_GEM' as zbm
      ,sum(ORDI_TRD_ITMS_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----637.普通账户交易笔数_创业板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_GEM_80' as zbm
      ,sum(ORDI_TRD_ITMS_GEM_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_GEM_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----638.信用账户交易笔数_创业板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_GEM' as zbm
      ,sum(CRD_TRD_ITMS_GEM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_GEM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----639.信用账户交易笔数_创业板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_GEM_80' as zbm
      ,sum(CRD_TRD_ITMS_GEM_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_GEM_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----640.普通账户交易笔数_沪B
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_HB' as zbm
      ,sum(ORDI_TRD_ITMS_HB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_HB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----641.普通账户交易笔数_深B
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_SB' as zbm
      ,sum(ORDI_TRD_ITMS_SB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_SB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----642.普通账户交易笔数_沪港通
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_HK' as zbm
      ,sum(ORDI_TRD_ITMS_HK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_HK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----643.普通账户交易笔数_深港通
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_SK' as zbm
      ,sum(ORDI_TRD_ITMS_SK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_SK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----644.普通账户交易笔数_三板A股
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_TA' as zbm
      ,sum(ORDI_TRD_ITMS_TA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_TA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----645.普通账户交易笔数_三板B股
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_TU' as zbm
      ,sum(ORDI_TRD_ITMS_TU) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_TU
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----646.普通账户交易笔数_回购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_REPO' as zbm
      ,sum(ORDI_TRD_ITMS_REPO) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_REPO
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----647.普通账户交易笔数_场内基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_EXG_FND' as zbm
      ,sum(ORDI_TRD_ITMS_EXG_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_EXG_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----648.普通账户交易笔数_封闭式基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_CLS_FND' as zbm
      ,sum(ORDI_TRD_ITMS_CLS_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_CLS_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----649.普通账户交易笔数_ETF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_ETF_FND' as zbm
      ,sum(ORDI_TRD_ITMS_ETF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_ETF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----650.普通账户交易笔数_开放式
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_OPN_FND' as zbm
      ,sum(ORDI_TRD_ITMS_OPN_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_OPN_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----651.普通账户交易笔数_LOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_LOF_FND' as zbm
      ,sum(ORDI_TRD_ITMS_LOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_LOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----652.普通账户交易笔数_FOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_FOF_FND' as zbm
      ,sum(ORDI_TRD_ITMS_FOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_FOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----653.信用账户交易笔数_场内基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_EXG_FND' as zbm
      ,sum(CRD_TRD_ITMS_EXG_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_EXG_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----654.信用账户交易笔数_封闭式基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_CLS_FND' as zbm
      ,sum(CRD_TRD_ITMS_CLS_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_CLS_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----655.信用账户交易笔数_ETF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_ETF_FND' as zbm
      ,sum(CRD_TRD_ITMS_ETF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_ETF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----656.信用账户交易笔数_开放式
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_OPN_FND' as zbm
      ,sum(CRD_TRD_ITMS_OPN_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_OPN_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----657.信用账户交易笔数_LOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_LOF_FND' as zbm
      ,sum(CRD_TRD_ITMS_LOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_LOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----658.信用账户交易笔数_FOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_FOF_FND' as zbm
      ,sum(CRD_TRD_ITMS_FOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_FOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----659.普通账户交易笔数_债券
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_BOND' as zbm
      ,sum(ORDI_TRD_ITMS_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_BOND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----660.普通账户交易笔数_债券(不包含债券申购)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_BOND_80' as zbm
      ,sum(ORDI_TRD_ITMS_BOND_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_BOND_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----661.信用账户交易笔数_债券
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_BOND' as zbm
      ,sum(CRD_TRD_ITMS_BOND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_BOND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----662.信用账户交易笔数_债券(不包含债券申购)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_BOND_80' as zbm
      ,sum(CRD_TRD_ITMS_BOND_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_BOND_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----663.总佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TOT_S1' as zbm
      ,sum(TOT_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TOT_S1
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----664.总净佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TOT_NET_S1' as zbm
      ,sum(TOT_NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TOT_NET_S1
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----665.总收入贡献
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TOT_INCM_OFFER' as zbm
      ,sum(TOT_INCM_OFFER) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TOT_INCM_OFFER
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----666.普通账户佣金收入_沪B_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_HB_RMB' as zbm
      ,sum(ORDI_S1_INCM_HB_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_HB_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----667.普通账户佣金收入_深B_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_SB_RMB' as zbm
      ,sum(ORDI_S1_INCM_SB_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_SB_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----668.普通账户佣金收入_三板B股_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_TU_RMB' as zbm
      ,sum(ORDI_S1_INCM_TU_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_TU_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----669.普通账户净佣金收入_沪B_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_HB_RMB' as zbm
      ,sum(ORDI_NET_S1_INCM_HB_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_HB_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----670.普通账户净佣金收入_深B_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_SB_RMB' as zbm
      ,sum(ORDI_NET_S1_INCM_SB_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_SB_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----671.普通账户净佣金收入_三板B股_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_TU_RMB' as zbm
      ,sum(ORDI_NET_S1_INCM_TU_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_TU_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----672.普通账户交易费用_沪B_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_HB_RMB' as zbm
      ,sum(ORDI_TRD_FEE_HB_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_HB_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----673.普通账户交易费用_深B_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_SB_RMB' as zbm
      ,sum(ORDI_TRD_FEE_SB_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_SB_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----674.普通账户交易费用_三板B股_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_TU_RMB' as zbm
      ,sum(ORDI_TRD_FEE_TU_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_TU_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----675.普通账户交易量_沪B_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HB_RMB' as zbm
      ,sum(ORDI_TRD_VOL_HB_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HB_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----676.普通账户交易量_沪B_人民币_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HB_RMB_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_HB_RMB_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HB_RMB_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----677.普通账户交易量_沪B_人民币_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_HB_RMB_SELL' as zbm
      ,sum(ORDI_TRD_VOL_HB_RMB_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_HB_RMB_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----678.普通账户交易量_深B_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SB_RMB' as zbm
      ,sum(ORDI_TRD_VOL_SB_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SB_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----679.普通账户交易量_深B_人民币_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SB_RMB_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_SB_RMB_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SB_RMB_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----680.普通账户交易量_深B_人民币_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_SB_RMB_SELL' as zbm
      ,sum(ORDI_TRD_VOL_SB_RMB_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_SB_RMB_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----681.普通账户交易量_三板B股_人民币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_TU_RMB' as zbm
      ,sum(ORDI_TRD_VOL_TU_RMB) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_TU_RMB
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----682.普通账户交易量_三板B股_人民币_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_TU_RMB_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_TU_RMB_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_TU_RMB_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where BUS_DATE = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----683.普通账户交易量_三板B股_人民币_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_TU_RMB_SELL' as zbm
      ,sum(ORDI_TRD_VOL_TU_RMB_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_TU_RMB_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----684.普通账户佣金收入_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_STIB_AK' as zbm
      ,sum(ORDI_S1_INCM_STIB_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_STIB_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----685.信用账户佣金收入_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_STIB_AK' as zbm
      ,sum(CRD_S1_INCM_STIB_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_STIB_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----686.佣金收入_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'S1_INCM_STIB_AK' as zbm
      ,sum(S1_INCM_STIB_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,S1_INCM_STIB_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----687.普通账户佣金收入_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_STIB_RK' as zbm
      ,sum(ORDI_S1_INCM_STIB_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_STIB_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----688.信用账户佣金收入_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_STIB_RK' as zbm
      ,sum(CRD_S1_INCM_STIB_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_STIB_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----689.佣金收入_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'S1_INCM_STIB_RK' as zbm
      ,sum(S1_INCM_STIB_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,S1_INCM_STIB_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----690.普通账户净佣金收入_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_STIB_AK' as zbm
      ,sum(ORDI_NET_S1_INCM_STIB_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_STIB_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----691.信用账户净佣金收入_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_STIB_AK' as zbm
      ,sum(CRD_NET_S1_INCM_STIB_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_STIB_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----692.净佣金收入_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NET_S1_INCM_STIB_AK' as zbm
      ,sum(NET_S1_INCM_STIB_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NET_S1_INCM_STIB_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----693.普通账户净佣金收入_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_STIB_RK' as zbm
      ,sum(ORDI_NET_S1_INCM_STIB_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_STIB_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----694.信用账户净佣金收入_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_STIB_RK' as zbm
      ,sum(CRD_NET_S1_INCM_STIB_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_STIB_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----695.净佣金收入_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NET_S1_INCM_STIB_RK' as zbm
      ,sum(NET_S1_INCM_STIB_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NET_S1_INCM_STIB_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----696.普通账户交易费用_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_STIB_AK' as zbm
      ,sum(ORDI_TRD_FEE_STIB_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_STIB_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----697.信用账户交易费用_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_STIB_AK' as zbm
      ,sum(CRD_TRD_FEE_STIB_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_STIB_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----698.交易费用_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_FEE_STIB_AK' as zbm
      ,sum(TRD_FEE_STIB_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_FEE_STIB_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----699.普通账户交易费用_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_STIB_RK' as zbm
      ,sum(ORDI_TRD_FEE_STIB_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_STIB_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----700.信用账户交易费用_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_STIB_RK' as zbm
      ,sum(CRD_TRD_FEE_STIB_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_STIB_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----701.交易费用_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_FEE_STIB_RK' as zbm
      ,sum(TRD_FEE_STIB_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_FEE_STIB_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----702.交易量_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_AK' as zbm
      ,sum(TRD_VOL_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----703.交易量_AK科创板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_AK_80' as zbm
      ,sum(TRD_VOL_AK_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_AK_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----704.交易量_AK科创板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_AK_BUYIN' as zbm
      ,sum(TRD_VOL_AK_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_AK_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----705.交易量_AK科创板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_AK_SELL' as zbm
      ,sum(TRD_VOL_AK_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_AK_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----706.交易量_AK科创板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_AK_PRCH' as zbm
      ,sum(TRD_VOL_AK_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_AK_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----707.普通账户交易量_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_AK' as zbm
      ,sum(ORDI_TRD_VOL_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----708.普通账户交易量_AK科创板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_AK_80' as zbm
      ,sum(ORDI_TRD_VOL_AK_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_AK_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----709.普通账户交易量_AK科创板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_AK_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_AK_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_AK_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----710.普通账户交易量_AK科创板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_AK_SELL' as zbm
      ,sum(ORDI_TRD_VOL_AK_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_AK_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----711.普通账户交易量_AK科创板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_AK_PRCH' as zbm
      ,sum(ORDI_TRD_VOL_AK_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_AK_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----712.信用账户交易量_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_AK' as zbm
      ,sum(CRD_TRD_VOL_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----713.信用账户交易量_AK科创板(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_AK_80' as zbm
      ,sum(CRD_TRD_VOL_AK_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_AK_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----714.信用账户交易量_AK科创板_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_AK_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_AK_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_AK_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----715.信用账户交易量_AK科创板_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_AK_SELL' as zbm
      ,sum(CRD_TRD_VOL_AK_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_AK_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----716.信用账户交易量_AK科创板_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_AK_PRCH' as zbm
      ,sum(CRD_TRD_VOL_AK_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_AK_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----717.交易量_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_RK' as zbm
      ,sum(TRD_VOL_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----718.交易量_RK科创CDR(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_RK_80' as zbm
      ,sum(TRD_VOL_RK_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_RK_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----719.交易量_RK科创CDR_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_RK_BUYIN' as zbm
      ,sum(TRD_VOL_RK_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_RK_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----720.交易量_RK科创CDR_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_RK_SELL' as zbm
      ,sum(TRD_VOL_RK_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_RK_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----721.交易量_RK科创CDR_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_VOL_RK_PRCH' as zbm
      ,sum(TRD_VOL_RK_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_VOL_RK_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----722.普通账户交易量_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_RK' as zbm
      ,sum(ORDI_TRD_VOL_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----723.普通账户交易量_RK科创CDR(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_RK_80' as zbm
      ,sum(ORDI_TRD_VOL_RK_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_RK_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----724.普通账户交易量_RK科创CDR_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_RK_BUYIN' as zbm
      ,sum(ORDI_TRD_VOL_RK_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_RK_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----725.普通账户交易量_RK科创CDR_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_RK_SELL' as zbm
      ,sum(ORDI_TRD_VOL_RK_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_RK_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----726.普通账户交易量_RK科创CDR_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_VOL_RK_PRCH' as zbm
      ,sum(ORDI_TRD_VOL_RK_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_VOL_RK_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;


----727.信用账户交易量_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_RK' as zbm
      ,sum(CRD_TRD_VOL_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----728.信用账户交易量_RK科创CDR(不包含申购交易量)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_RK_80' as zbm
      ,sum(CRD_TRD_VOL_RK_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_RK_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----729.信用账户交易量_RK科创CDR_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_RK_BUYIN' as zbm
      ,sum(CRD_TRD_VOL_RK_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_RK_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----730.信用账户交易量_RK科创CDR_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_RK_SELL' as zbm
      ,sum(CRD_TRD_VOL_RK_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_RK_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----731.信用账户交易量_RK科创CDR_申购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_VOL_RK_PRCH' as zbm
      ,sum(CRD_TRD_VOL_RK_PRCH) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_VOL_RK_PRCH
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----732.交易笔数_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_ITMS_STIB_AK' as zbm
      ,sum(TRD_ITMS_STIB_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_ITMS_STIB_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----733.交易笔数_AK科创板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_ITMS_STIB_AK_80' as zbm
      ,sum(TRD_ITMS_STIB_AK_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_ITMS_STIB_AK_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----734.普通账户交易笔数_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_STIB_AK' as zbm
      ,sum(ORDI_TRD_ITMS_STIB_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_STIB_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----735.普通账户交易笔数_AK科创板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_STIB_AK_80' as zbm
      ,sum(ORDI_TRD_ITMS_STIB_AK_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_STIB_AK_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----736.信用账户交易笔数_AK科创板
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_STIB_AK' as zbm
      ,sum(CRD_TRD_ITMS_STIB_AK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_STIB_AK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----737.信用账户交易笔数_AK科创板(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_STIB_AK_80' as zbm
      ,sum(CRD_TRD_ITMS_STIB_AK_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_STIB_AK_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----738.交易笔数_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_ITMS_STIB_RK' as zbm
      ,sum(TRD_ITMS_STIB_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_ITMS_STIB_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----739.交易笔数_RK科创CDR(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'TRD_ITMS_STIB_RK_80' as zbm
      ,sum(TRD_ITMS_STIB_RK_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,TRD_ITMS_STIB_RK_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----740.普通账户交易笔数_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_STIB_RK' as zbm
      ,sum(ORDI_TRD_ITMS_STIB_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_STIB_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----741.普通账户交易笔数_RK科创CDR(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_ITMS_STIB_RK_80' as zbm
      ,sum(ORDI_TRD_ITMS_STIB_RK_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_ITMS_STIB_RK_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----742.信用账户交易笔数_RK科创CDR
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_STIB_RK' as zbm
      ,sum(CRD_TRD_ITMS_STIB_RK) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_STIB_RK
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----743.信用账户交易笔数_RK科创CDR(不包含申购的笔数)
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_ITMS_STIB_RK_80' as zbm
      ,sum(CRD_TRD_ITMS_STIB_RK_80) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_ITMS_STIB_RK_80
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----744.信用账户信用交易量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_CRD_TRD_VOL' as zbm
      ,sum(CRD_CRD_TRD_VOL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_CRD_TRD_VOL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----745.信用账户信用交易佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_CRD_TRD_S1' as zbm
      ,sum(CRD_CRD_TRD_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_CRD_TRD_S1
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----746.信用账户信用交易净佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_CRD_TRD_NET_S1' as zbm
      ,sum(CRD_CRD_TRD_NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_CRD_TRD_NET_S1
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----747.信用账户信用交易费用
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_CRD_TRD_FEE' as zbm
      ,sum(CRD_CRD_TRD_FEE) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_CRD_TRD_FEE
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----748.信用账户信用交易笔数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_CRD_TRD_ITMS' as zbm
      ,sum(CRD_CRD_TRD_ITMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_CRD_TRD_ITMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----749.新三板交易量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NEW_TA_TRD_VOL' as zbm
      ,sum(NEW_TA_TRD_VOL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NEW_TA_TRD_VOL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----750.新三板交易佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NEW_TA_TRD_S1' as zbm
      ,sum(NEW_TA_TRD_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NEW_TA_TRD_S1
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----751.新三板交易净佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NEW_TA_TRD_NET_S1' as zbm
      ,sum(NEW_TA_TRD_NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NEW_TA_TRD_NET_S1
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----752.新三板交易费用
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NEW_TA_TRD_FEE' as zbm
      ,sum(NEW_TA_TRD_FEE) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NEW_TA_TRD_FEE
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----753.新三板交易笔数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'NEW_TA_TRD_ITMS' as zbm
      ,sum(NEW_TA_TRD_ITMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,NEW_TA_TRD_ITMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----754.分级基金交易量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CLS_FND_TRD_VOL' as zbm
      ,sum(CLS_FND_TRD_VOL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CLS_FND_TRD_VOL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----755.分级基金交易佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CLS_FND_TRD_S1' as zbm
      ,sum(CLS_FND_TRD_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CLS_FND_TRD_S1
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----756.分级基金交易净佣金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CLS_FND_TRD_NET_S1' as zbm
      ,sum(CLS_FND_TRD_NET_S1) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CLS_FND_TRD_NET_S1
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----757.分级基金交易费用
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CLS_FND_TRD_FEE' as zbm
      ,sum(CLS_FND_TRD_FEE) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CLS_FND_TRD_FEE
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----758.分级基金交易笔数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CLS_FND_TRD_ITMS' as zbm
      ,sum(CLS_FND_TRD_ITMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CLS_FND_TRD_ITMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----759.期权账户交易张数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_CNTS' as zbm
      ,sum(WRNT_TRD_CNTS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_CNTS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----760.期权账户交易量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_VOL' as zbm
      ,sum(WRNT_TRD_VOL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_VOL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----761.期权账户佣金收入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_S1_INCM' as zbm
      ,sum(WRNT_S1_INCM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_S1_INCM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----762.期权账户净佣金收入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_NET_S1_INCM' as zbm
      ,sum(WRNT_NET_S1_INCM) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_NET_S1_INCM
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----763.期权账户交易费用
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_FEE' as zbm
      ,sum(WRNT_TRD_FEE) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_FEE
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----764.期权账户交易笔数
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_ITMS' as zbm
      ,sum(WRNT_TRD_ITMS) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_ITMS
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----765.期权账户交易量_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_VOL_BUYIN' as zbm
      ,sum(WRNT_TRD_VOL_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_VOL_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----766.期权账户交易量_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_VOL_SELL' as zbm
      ,sum(WRNT_TRD_VOL_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_VOL_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----767.期权账户交易张数_买入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_CNTS_BUYIN' as zbm
      ,sum(WRNT_TRD_CNTS_BUYIN) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_CNTS_BUYIN
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----768.期权账户交易张数_卖出
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_CNTS_SELL' as zbm
      ,sum(WRNT_TRD_CNTS_SELL) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_CNTS_SELL
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----769.期权账户交易量_买入_开仓
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_VOL_BUYIN_O' as zbm
      ,sum(WRNT_TRD_VOL_BUYIN_O) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_VOL_BUYIN_O
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----770.期权账户交易量_买入_平仓
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_VOL_BUYIN_C' as zbm
      ,sum(WRNT_TRD_VOL_BUYIN_C) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_VOL_BUYIN_C
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----771.期权账户交易量_卖出_开仓
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_VOL_SELL_O' as zbm
      ,sum(WRNT_TRD_VOL_SELL_O) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_VOL_SELL_O
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----772.期权账户交易量_卖出_平仓
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_VOL_SELL_C' as zbm
      ,sum(WRNT_TRD_VOL_SELL_C) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_VOL_SELL_C
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----773.期权账户交易张数_买入_开仓
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_CNTS_BUYIN_O' as zbm
      ,sum(WRNT_TRD_CNTS_BUYIN_O) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_CNTS_BUYIN_O
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----774.期权账户交易张数_买入_平仓
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_CNTS_BUYIN_C' as zbm
      ,sum(WRNT_TRD_CNTS_BUYIN_C) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_CNTS_BUYIN_C
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----775.期权账户交易张数_卖出_开仓
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_CNTS_SELL_O' as zbm
      ,sum(WRNT_TRD_CNTS_SELL_O) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_CNTS_SELL_O
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----776.期权账户交易张数_卖出_平仓
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'WRNT_TRD_CNTS_SELL_C' as zbm
      ,sum(WRNT_TRD_CNTS_SELL_C) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,WRNT_TRD_CNTS_SELL_C
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----777.普通账户交易费用_沪B_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_HB_USD' as zbm
      ,sum(ORDI_TRD_FEE_HB_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_HB_USD
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----778.普通账户交易费用_深B_港币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_SB_HKD' as zbm
      ,sum(ORDI_TRD_FEE_SB_HKD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_SB_HKD
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----779.普通账户交易费用_三板A股
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_TA' as zbm
      ,sum(ORDI_TRD_FEE_TA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_TA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----780.普通账户交易费用_三板B股_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_TU_USD' as zbm
      ,sum(ORDI_TRD_FEE_TU_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_TU_USD
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----781.普通账户交易费用_回购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_REPO' as zbm
      ,sum(ORDI_TRD_FEE_REPO) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_REPO
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----782.普通账户交易费用_场内基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_EXG_FND' as zbm
      ,sum(ORDI_TRD_FEE_EXG_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_EXG_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----783.普通账户交易费用_封闭式基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_CLS_FND' as zbm
      ,sum(ORDI_TRD_FEE_CLS_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_CLS_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----784.普通账户交易费用_ETF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_ETF_FND' as zbm
      ,sum(ORDI_TRD_FEE_ETF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_ETF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----785.普通账户交易费用_开放式
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_OPN_FND' as zbm
      ,sum(ORDI_TRD_FEE_OPN_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_OPN_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----786.普通账户交易费用_LOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_LOF_FND' as zbm
      ,sum(ORDI_TRD_FEE_LOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_LOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----787.普通账户交易费用_FOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_TRD_FEE_FOF_FND' as zbm
      ,sum(ORDI_TRD_FEE_FOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_TRD_FEE_FOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----788.信用账户交易费用_场内基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_EXG_FND' as zbm
      ,sum(CRD_TRD_FEE_EXG_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_EXG_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----789.信用账户交易费用_封闭式基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_CLS_FND' as zbm
      ,sum(CRD_TRD_FEE_CLS_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_CLS_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----790.信用账户交易费用_ETF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_ETF_FND' as zbm
      ,sum(CRD_TRD_FEE_ETF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_ETF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----791.信用账户交易费用_开放式
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_OPN_FND' as zbm
      ,sum(CRD_TRD_FEE_OPN_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_OPN_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----792.信用账户交易费用_LOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_LOF_FND' as zbm
      ,sum(CRD_TRD_FEE_LOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_LOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----793.信用账户交易费用_FOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_TRD_FEE_FOF_FND' as zbm
      ,sum(CRD_TRD_FEE_FOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_TRD_FEE_FOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----794.普通账户净佣金收入_三板A股
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_TA' as zbm
      ,sum(ORDI_NET_S1_INCM_TA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_TA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----795.普通账户净佣金收入_三板B股_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_TU_USD' as zbm
      ,sum(ORDI_NET_S1_INCM_TU_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_TU_USD
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----796.普通账户净佣金收入_回购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_REPO' as zbm
      ,sum(ORDI_NET_S1_INCM_REPO) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_REPO
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----797.普通账户净佣金收入_场内基金收入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_EXG_FND' as zbm
      ,sum(ORDI_NET_S1_INCM_EXG_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_EXG_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----798.普通账户净佣金收入_封闭式基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_CLS_FND' as zbm
      ,sum(ORDI_NET_S1_INCM_CLS_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_CLS_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----799.普通账户净佣金收入_ETF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_ETF_FND' as zbm
      ,sum(ORDI_NET_S1_INCM_ETF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_ETF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----800.普通账户净佣金收入_开放式
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_OPN_FND' as zbm
      ,sum(ORDI_NET_S1_INCM_OPN_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_OPN_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----801.普通账户净佣金收入_LOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_LOF_FND' as zbm
      ,sum(ORDI_NET_S1_INCM_LOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_LOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----802.普通账户净佣金收入_FOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_FOF_FND' as zbm
      ,sum(ORDI_NET_S1_INCM_FOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_FOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----803.信用账户净佣金收入_场内基金收入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_EXG_FND' as zbm
      ,sum(CRD_NET_S1_INCM_EXG_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_EXG_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----804.信用账户净佣金收入_封闭式基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_CLS_FND' as zbm
      ,sum(CRD_NET_S1_INCM_CLS_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_CLS_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----805.信用账户净佣金收入_ETF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_ETF_FND' as zbm
      ,sum(CRD_NET_S1_INCM_ETF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_ETF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----806.信用账户净佣金收入_开放式
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_OPN_FND' as zbm
      ,sum(CRD_NET_S1_INCM_OPN_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_OPN_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----807.信用账户净佣金收入_LOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_LOF_FND' as zbm
      ,sum(CRD_NET_S1_INCM_LOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_LOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----808.信用账户净佣金收入_FOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_NET_S1_INCM_FOF_FND' as zbm
      ,sum(CRD_NET_S1_INCM_FOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_NET_S1_INCM_FOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----809.普通账户净佣金收入_沪B_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_HB_USD' as zbm
      ,sum(ORDI_NET_S1_INCM_HB_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_HB_USD
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----810.普通账户净佣金收入_深B_港币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_NET_S1_INCM_SB_HKD' as zbm
      ,sum(ORDI_NET_S1_INCM_SB_HKD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_NET_S1_INCM_SB_HKD
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----811.普通账户佣金收入_三板A股
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_TA' as zbm
      ,sum(ORDI_S1_INCM_TA) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_TA
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----812.普通账户佣金收入_三板B股_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_TU_USD' as zbm
      ,sum(ORDI_S1_INCM_TU_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_TU_USD
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;
----813.普通账户佣金收入_回购
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_REPO' as zbm
      ,sum(ORDI_S1_INCM_REPO) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_REPO
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----814.普通账户佣金收入_场内基金收入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_EXG_FND' as zbm
      ,sum(ORDI_S1_INCM_EXG_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_EXG_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----815.普通账户佣金收入_封闭式基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_CLS_FND' as zbm
      ,sum(ORDI_S1_INCM_CLS_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_CLS_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----816.普通账户佣金收入_ETF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_ETF_FND' as zbm
      ,sum(ORDI_S1_INCM_ETF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_ETF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----817.普通账户佣金收入_开放式
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_OPN_FND' as zbm
      ,sum(ORDI_S1_INCM_OPN_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_OPN_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----818.普通账户佣金收入_LOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_LOF_FND' as zbm
      ,sum(ORDI_S1_INCM_LOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_LOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----819.普通账户佣金收入_FOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_FOF_FND' as zbm
      ,sum(ORDI_S1_INCM_FOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_FOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----820.信用账户佣金收入_场内基金收入
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_EXG_FND' as zbm
      ,sum(CRD_S1_INCM_EXG_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_EXG_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----821.信用账户佣金收入_封闭式基金
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_CLS_FND' as zbm
      ,sum(CRD_S1_INCM_CLS_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_CLS_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----822.信用账户佣金收入_ETF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_ETF_FND' as zbm
      ,sum(CRD_S1_INCM_ETF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_ETF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----823.信用账户佣金收入_开放式
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_OPN_FND' as zbm
      ,sum(CRD_S1_INCM_OPN_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_OPN_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----824.信用账户佣金收入_LOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_LOF_FND' as zbm
      ,sum(CRD_S1_INCM_LOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_LOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----825.信用账户佣金收入_FOF
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'CRD_S1_INCM_FOF_FND' as zbm
      ,sum(CRD_S1_INCM_FOF_FND) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,CRD_S1_INCM_FOF_FND
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----826.普通账户佣金收入_沪B_美元
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_HB_USD' as zbm
      ,sum(ORDI_S1_INCM_HB_USD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_HB_USD
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----827.普通账户佣金收入_深B_港币
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
select C.belto_filil_cdg as belto_filil_cdg
      ,C.belto_filil as belto_filil
      ,A.brh_no as brh_no
      ,C.brh_fullnm as brh_fullnm
      ,B.cust_star as cust_star
      ,'ORDI_S1_INCM_SB_HKD' as zbm
      ,sum(ORDI_S1_INCM_SB_HKD) as zbz
      ,%d{yyyyMMdd} as bus_date
from
(
select cust_no,brh_no,ORDI_S1_INCM_SB_HKD
from ddw_prod.T_DDW_F10_CUST_TRD_INCM_DAY
where bus_date = %d{yyyyMMdd}
) A
left join
(
select cust_no,brh_no,cust_star from
DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu
where bus_date = %d{yyyyMMdd}
) B
on A.cust_no=B.cust_no
and A.brh_no = B.brh_no
left join 
(select brh_no,belto_filil_cdg,belto_filil,brh_fullnm from ddw_prod.t_ddw_inr_org_brh_kudu
) C
on A.brh_no=C.brh_no
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----828.权益类公募销量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'ETMT_PUB_PROD_SALE' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'010100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'010400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'010500',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)),0) as zbz
             ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----829.债券类公募销量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'BOND_PUB_PROD_SALE' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'010200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----830.货币类公募销量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'CCY_PUB_PROD_SALE' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'010300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----831.基金专产品户销量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'FND_SPELACT_PROD_SALE' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'080100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080500',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080600',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----832.私募基金销量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'PRV_FND_PROD_SALE' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'020100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'020200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'020300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'020400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----833.银行产品销量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'BANK_PROD_SALE' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'050100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----834.国君产品销量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'GTJA_PROD_SALE' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'070100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'070200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'070300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'070400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----835.公司产品销量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'SHZQ_PROD_SALE' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'040100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'040200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'040300',0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----836.现金添利产品销量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'CASH_PROD_SALE' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CD,'A30003',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----837.OTC产品销量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'OTC_PROD_SALE' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'060100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----838.权益类公募保有量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'ETMT_PUB_PROD_HLD_AMT' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'010100',a.HLD_AMT,'010400',a.HLD_AMT,'010500',a.HLD_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----839.债券类公募保有量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'BOND_PUB_PROD_HLD_AMT' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'010200',a.HLD_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----840.货币类公募保有量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'CCY_PUB_PROD_HLD_AMT' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'010300',a.HLD_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----841.基金专产品户保有量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'FND_SPELACT_PROD_HLD_AMT' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'080100',a.HLD_AMT,'080200',a.HLD_AMT,'080300',a.HLD_AMT,'080400',a.HLD_AMT,'080500',a.HLD_AMT,'080600',a.HLD_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----842.私募基金保有量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'PRV_FND_PROD_HLD_AMT' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'020100',a.HLD_AMT,'020200',a.HLD_AMT,'020300',a.HLD_AMT,'020400',a.HLD_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----843.银行产品保有量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'BANK_PROD_HLD_AMT' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'050100',a.HLD_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----844.国君产品保有量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'GTJA_PROD_HLD_AMT' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'070100',a.HLD_AMT,'070200',a.HLD_AMT,'070300',a.HLD_AMT,'070400',a.HLD_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----845.公司产品保有量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'SHZQ_PROD_HLD_AMT' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'040100',a.HLD_AMT,'040200',a.HLD_AMT,'040300',0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----846.现金添利产品保有量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'CASH_PROD_HLD_AMT' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CD,'A30003',a.HLD_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;

----847.OTC产品保有量
insert into ddw_prod.t_ddw_jjgl_day_123
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
,bus_date)
SELECT        t.belto_filil_cdg as belto_filil_cdg
             ,t.belto_filil as belto_filil
             ,b.BRH_NO as brh_no
             ,t.brh_fullnm as brh_fullnm
             ,c.cust_star as cust_star
             ,'OTC_PROD_HLD_AMT' as zbm
			 ,nvl(SUM(DECODE(a.PROD_CL_CD,'060100',a.HLD_AMT,0)),0) as zbz
			 ,%d{yyyyMMdd} as bus_date
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
and        b.BUS_DATE = %d{yyyyMMdd}
left join DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_kudu c
ON          a.cust_no = c.cust_no
and         c.bus_date = %d{yyyyMMdd}
left join (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
           FROM  DDW_PROD.T_DDW_INR_ORG_BRH_kudu
		   ) t
on b.brh_no = t.brh_no
where a.BUS_DATE = %d{yyyyMMdd}
group by belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
;


INSERT OVERWRITE ddw_prod.t_ddw_jjgl_day
(
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
)
partition(bus_date=%d{yyyyMMdd})
select 
 belto_filil_cdg
,belto_filil
,brh_no
,brh_fullnm
,cust_star
,zbm
,zbz
from ddw_prod.t_ddw_jjgl_day_123
;



DROP TABLE IF EXISTS ddw_prod.t_ddw_jjgl_day_123;


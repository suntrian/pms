 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:银证转帐对应关系表                                                                */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                       */
TRUNCATE TABLE EDW_PROD.T_EDW_T02_TYZZZDY; 
------插入数据开始-------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TYZZZDY(
                                    YHDM                                --银行代码                               
                                   ,YHZH                                --银行帐号                               
                                   ,BZDM                                --币种代码                               
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,KHH                                 --客户号                                
                                   ,DYBS                                --对应标示                               
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,DJRQ                                --登记日期                               
                                   ,ZH_YHZHGXZT                        --帐户与银行账号关系状态                       
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.YHDM                                as YHDM                                --银行代码                                
                                   ,t.YHZH                                as YHZH                                --银行帐号                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.DYBS                                as DYBS                                --对应标示                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.ZT                                  as ZH_YHZHGXZT                            --状态                                  
 FROM           JZJYCX.ACCOUNT_TYZZZDY                 t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'YZZZZT'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.ZT AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}'
 AND           NOT EXISTS (SELECT 1 FROM JZJYCX.ACCOUNT_TYZZZDY b
                           WHERE b.dt = '%d{yyyyMMdd}'
                           AND   t.yhzh = b.yhzh
                           and   t.yhdm = b.yhdm
                           and   b.YHZH = '9555500213281834'	
                           AND   b.yhdm = 'SHZH'						   
                          );
--------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TYZZZDY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TYZZZDY;
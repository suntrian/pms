------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:金融产品产品业务代码表                                                                      */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
 TRUNCATE TABLE DDW_PROD.T_DDW_PUB_FNCL_PROD_BIZ_CD ;
INSERT OVERWRITE DDW_PROD.T_DDW_PUB_FNCL_PROD_BIZ_CD
(
                   ISSUE_ORG                        --发行机构  
                  ,FNCL_PROD_BIZ_CD                 --金融产品业务代码 
                  ,FNCL_PROD_BIZ_SHRTNM             --金融产品业务代码简称                                                  
				  ,SYS_BIZ_CD                       --系统业务代码
				  ,EXPLN                            --说明						                                   								
 ) 
 partition(BUS_DATE = %d{yyyyMMdd})
 SELECT         t.FXJG	          as ISSUE_ORG                        --发行机构                            
               ,t.JRCP_YWDM       as FNCL_PROD_BIZ_CD                 --金融产品业务代码  
               ,t.JRCP_YWJC       as FNCL_PROD_BIZ_SHRTNM             --金融产品业务代码简称   	                                        						    
               ,t.XTYWDM	      as SYS_BIZ_CD                       --系统业务代码 
               ,t.SM	          as EXPLN                            --说明                         				
 FROM           EDW_PROD.T_EDW_T99_TJRCP_CPYWDM                                 t       
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_FNCL_PROD_BIZ_CD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_FNCL_PROD_BIZ_CD;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:CIF系统业务请求表                                                                        */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
--------------------------删除临时表------------------
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_RQM_HIS_TEMP_TEMP ;
-----------------------删除临时表-------------------- 

--------创建临时表 二代证验证------
CREATE  TABLE DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_RQM_HIS_TEMP_TEMP AS
  SELECT t1.khh,t1.rq, 1 as bz 
  FROM (
         SELECT t.khh,t.rq as RQ
         FROM (
	             SELECT  khh,rq 
                 FROM   EDW_PROD.T_EDW_T05_TYGTXTCZMX
                 WHERE  YWKM = '20090' OR  zy like '%二代证验证%'
                 UNION ALL
                 SELECT     a1.khh,a2.sqrq as rq
                 FROM       (SELECT yyb,zjbh,khh FROM  EDW_PROD.T_EDW_T01_TKHXX where bus_date = %d{yyyyMMdd})     a1
                 INNER JOIN (SELECT zjbh,yyb,sqrq FROM EDW_PROD.T_EDW_T02_TGMSFCXSQ WHERE CLJG = 1)                a2
                 ON           a1.yyb = a2.yyb
                 AND          a1.zjbh = a2.zjbh
              ) t
       GROUP BY t.khh,t.rq
      )   t1
	  ;


--------插入------
 INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_RQM_HIS
(                                  BIZ_RQM_ID               --业务请求主键     
                                  ,BIZ_CD                   --业务代码 
                                  ,BIZ_CD_NAME              --业务代码名称								  
                                  ,APL_DT                   --申请日期     
                                  ,APL_TM                   --申请时间     
                                  ,CUST_NO                  --客户号       
                                  ,CPTL_ACTNO               --资金账号     
                                  ,BRH_NO                   --客户营业部
                                  ,BRH_NAME                 --营业部名称 								  
                                  ,OCC_BRH_NO               --发生营业部   
                                  ,SPNSR                    --发起人       
                                  ,OPRT_SITE                --操作站点     
                                  ,AUDT_TELR                --临柜审核柜员 
								  ,OPRT_TELR                --操作柜员
                                  ,DEAL_RSLT_EXPLN          --处理结果说明 
                                  ,BIZ_RQM_STAT             --业务处理状态  
                                  ,HAND_LVL_CD              --办理等级代码 
                                  ,CUST_NAME                --客户名称     
                                  ,CTF_CGY_CD               --证件类别代码 
                                  ,CTF_NO                   --证件编号     
                                  ,HAND_CGY                 --转办类别     
                                  ,SECOND_CARD_VRFCTN       --二代证验证 
                                  ,OPRT_MOD                 --操作方式									  								
) 
 partition(bus_date)
 SELECT                        t.YWQQID	                              as BIZ_RQM_ID               --业务请求主键   
                               ,t.YWDM	                              as BIZ_CD                   --业务代码 
                               ,a5.YWMC                               as BIZ_CD_NAME              --业务代码名称	
							   ,t.SQRQ	                              as APL_DT                   --申请日期     
                               ,t.SQSJ	                              as APL_TM                   --申请时间     
                               ,t.KHH	                              as CUST_NO                  --客户号       
                               ,t.ZJZH	                              as CPTL_ACTNO               --资金账号     
                               ,t.YYB                                 as BRH_NO                   --客户营业部
                               ,NVL(a1.BRH_SHRTNM,a8.FILIL_DEPT_SHRTNM)                               as BRH_NAME                 --营业部名称 	
                               ,t.FSYYB	                              as OCC_BRH_NO               --发生营业部   
                               ,CAST(t.FQR as STRING)                 as SPNSR                    --发起人       
                               ,t.CZZD	                              as OPRT_SITE                --操作站点     
                               ,CAST(t.LGSHGY as STRING)	          as AUDT_TELR                --临柜审核柜员 
                               ,a4.NAME                               as OPRT_TELR                --操作柜员
							   ,t.CLJGSM	                          as DEAL_RSLT_EXPLN          --处理结果说明 
                               ,t.YWQQZT	                          as BIZ_RQM_STAT             --业务处理状态 
                               ,t.BLDJDM	                          as HAND_LVL_CD              --办理等级代码 
                               ,t.KHMC	                              as CUST_NAME                --客户名称     
                               ,t.ZJLBDM	                          as CTF_CGY_CD               --证件类别代码 
                               ,t.ZJBH	                              as CTF_NO                   --证件编号     
                               ,t.ZBLB	                              as HAND_CGY                 --转办类别     
							   ,CASE WHEN a3.BZ = 1 
                                     THEN '已验证'	
 									 ELSE '未验证'
									 END                              as SECOND_CARD_VRFCTN                  --二代证验证        
                               ,CASE WHEN t.FQR = 9057 
                                     THEN '掌厅'
                                     WHEN t.FQR= 9292
								     THEN '指E通'
									 WHEN a6.BRH_NO IS NOT NULL 
                                     THEN '临柜'
                                     ELSE a4.NAME
                                     END	                          as OPRT_MOD                           --操作方式										 
                              ,t.BUS_DATE as bus_date
  FROM          EDW_PROD.T_EDW_T05_TYWQQ                 t
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                                                   a1
  ON            t.YYB = a1.BRH_NO   
  AND           a1.BUS_DATE = %d{yyyyMMdd} 
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT                                        a8
  ON            t.YYB = a8.FILIL_DEPT_CDG
  AND           a8.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     EDW_PROD.T_EDW_T01_TKHXX                 a2 
  ON            t.KHH = a2.KHH  
  AND           a2.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_RQM_HIS_TEMP_TEMP          a3
  ON            t.KHH = a3.KHH
  AND           t.SQRQ = a3.RQ
  LEFT JOIN     EDW_PROD.T_EDW_T02_TUSER                  a4
  ON            t.FQR = a4.TUSER_ID
  AND           a4.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     EDW_PROD.T_EDW_T99_TYWDM                  a5
  ON            t.YWDM = a5.YWDM
  AND           a5.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH              a6
  ON            t.YYB = a6.BRH_NO   
  AND           a6.BUS_DATE = %d{yyyyMMdd} 
  --WHERE         t.bus_date = %d{yyyyMMdd}
  	  ;
		
---------------- 插入数据结束 -----------------------

--------------------------删除临时表------------------
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_RQM_HIS_TEMP_TEMP ;
-----------------------删除临时表-------------------- 

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_CIF_SRC_BIZ_RQM_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_RQM_HIS ;
--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:证券持仓明细表                                                                      */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-02-02                                                                        */ 
-----删除今天的数据---
ALTER TABLE DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ;
------三板申购
INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源			
 )PARTITION (BUS_DATE = %d{yyyyMMdd} )
  SELECT      t.KHH                     as CUST_NO                  --客户号        
              ,t.KHXM                   as CUST_NAME                --客户姓名      
              ,t.YYB                    as BRH_NO                   --营业部编号     
              ,t.JYS                    as EXG                      --交易所
              ,t.GDH                    as SHRHLD_NO                --股东号
              ,t.ZQDM                   as SEC_CD                   --证券代码
              ,t.ZQDM1                  as SEC_CD1                  --证券代码1
              ,t.ZQMC                   as SEC_NAME                 --证券名称
              ,t.ZQLB                   as SEC_CGY                  --证券类别
              ,t.BZDM                   as CCY_CD                   --币种代码
              ,NULL                     as OPNWH_DT                --开仓日期
              ,NULL                     as CHG_DT                   --变动日期		
              ,CASE WHEN t.WTLB IN (3,80,83,4444)
			        THEN t.CJSL 
					ELSE 0-t.CJSL
					END                   as SEC_QTY                  --证券数量
              ,0                        as FZN_QTY                  --冻结数量
              ,0                        as UN_CIR_SEC_QTY           --非流通数证券量	
              ,CASE WHEN t.WTLB IN (3,80,83,4444)
			        THEN t.CJJE 
					ELSE 0-t.CJJE
					END                   as SEC_MKTVAL               --证券市值
              ,0                                                       as UN_CIR_SEC_MKTVAL        --非流通证券市值
			  ,0                         as TRD_FEE                       --交易费用
	          ,CASE WHEN t.WTLB IN (3,80,83,4444)
			        THEN t.CJJE 
					ELSE 0-t.CJJE
					END                          as HLD_COST                      --持仓成本
	          ,0                         as GT_PRFT                       --累计盈亏
              ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户')      as SYS_SRC                  --系统来源		
 FROM   (SELECT   KHH
                 ,KHXM
				 ,DECODE(YYB,'1002','1028','1013','1029','1007','1012',YYB)  as YYB
				 ,JYS
				 ,GDH
				 ,ZQDM
				 ,ZQDM1
				 ,ZQMC
				 ,CJSL
				 ,XTBS
				 ,CJJE
				 ,BUS_DATE
				 ,ZQLB
				 ,BZDM
				 ,WTLB
         FROM   EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
		 WHERE  WTLB IN (80,81,83,3,4444,5555)
		 AND    JYS IN ('TA','TU')
		 AND    SUBSTR(ZQDM1,1,3) = '889'
         AND BUS_DATE < = %d{yyyyMMdd}			 
		 )                 t
 LEFT JOIN ( SELECT CONCAt(substr(a.paydate,1,4),substr(a.paydate,6,2),substr(a.paydate,9,2) ) as paydate
                   ,NVL(CONCAt(substr(a.NEWSHARELISTDT,1,4),substr(a.NEWSHARELISTDT,6,2),substr(a.NEWSHARELISTDT,9,2) ),'99999999') as NEWSHARELISTDT
				   ,b.secucode
				   ,a.IssueCODE
             FROM   FUNDEXT.DBO_NQ_IPOISSUE  a
			 LEFT JOIN FUNDEXT.DBO_NQ_SECUMAIN b
			 ON        a.DT = b.DT
			 AND       a.INNERCODE = b.INNERCODE
			 WHERE    a.DT = '%d{yyyyMMdd}'
			 AND   '%d{yyyyMMdd}' BETWEEN CONCAt(substr(a.paydate,1,4),substr(a.paydate,6,2),substr(a.paydate,9,2) )  AND NVL(CONCAt(substr(a.NEWSHARELISTDT,1,4),substr(a.NEWSHARELISTDT,6,2),substr(a.NEWSHARELISTDT,9,2) ),'99999999')
			 AND a.IssueCODE is not null
             )   a1
 ON t.ZQDM1 = a1.IssueCODE
 LEFT JOIN (SELECT TRD_DT,LST_TRD_D FROM EDW_PROD.T_EDW_T99_TRD_DATE WHERE BUS_DATE = %d{yyyyMMdd} AND TRD_DT = NAT_DT) a2
 ON  CAST(a1.NEWSHARELISTDT as INT) = a2.TRD_DT
 WHERE        a1.IssueCODE IS NOT NULL 
 AND         a1.paydate < = '%d{yyyyMMdd}'  
 AND        %d{yyyyMMdd} < NVL(a2.LST_TRD_D,99999999) 
 ;
 

-------A股增发 
INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源			
 )PARTITION (BUS_DATE = %d{yyyyMMdd} )
  SELECT      t.KHH                     as CUST_NO                  --客户号        
              ,t.KHXM                   as CUST_NAME                --客户姓名      
              ,t.YYB                    as BRH_NO                   --营业部编号     
              ,t.JYS                    as EXG                      --交易所
              ,t.GDH                    as SHRHLD_NO                --股东号
              ,t.ZQDM                   as SEC_CD                   --证券代码
              ,t.ZQDM1                  as SEC_CD1                  --证券代码1
              ,t.ZQMC                   as SEC_NAME                 --证券名称
              , CASE WHEN t.JYS = 'SB'
		         AND  SUBSTR(t.ZQDM,1,3) = '200'
				 AND  NVL(a3.ZQLB,t.ZQLB) NOT LIKE 'B%'
				 THEN 'B0'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('135','145','146')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z36'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('500')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('512')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J04'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('519')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J07'
 				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('101')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z04'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z04'
				  WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z01'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('112')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z13'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('119')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('127','128')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z10'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('150')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J06'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('184')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 ELSE NVL(a3.ZQLB,t.ZQLB)
		         END       as SEC_CGY                  --证券类别
              ,t.BZDM                   as CCY_CD                   --币种代码
              ,NULL                     as OPNWH_DT                --开仓日期
              ,NULL                     as CHG_DT                   --变动日期		
              ,CASE WHEN t.WTLB IN (3,80,83)
			        THEN t.CJSL 
					ELSE 0-t.CJSL
					END                   as SEC_QTY                  --证券数量
              ,0                        as FZN_QTY                  --冻结数量
              ,0                        as UN_CIR_SEC_QTY           --非流通数证券量	
              ,CASE WHEN t.WTLB IN (3,80,83)
			        THEN t.CJJE 
					ELSE 0-t.CJJE
					END                   as SEC_MKTVAL               --证券市值
              ,0                                                       as UN_CIR_SEC_MKTVAL        --非流通证券市值
			  ,0                         as TRD_FEE                       --交易费用
	          ,CASE WHEN t.WTLB IN (3,80,83)
			        THEN t.CJJE 
					ELSE 0-t.CJJE
					END                          as HLD_COST                      --持仓成本
	          ,0                         as GT_PRFT                       --累计盈亏
              ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户')      as SYS_SRC                  --系统来源		
 FROM   (SELECT   KHH
                 ,KHXM
				 ,DECODE(YYB,'1002','1028','1013','1029','1007','1012',YYB)  as YYB
				 ,JYS
				 ,GDH
				 ,ZQDM
				 ,ZQDM1
				 ,ZQMC
				 ,CJSL
				 ,XTBS
				 ,CJJE
				 ,BUS_DATE
				 ,ZQLB
				 ,BZDM
				 ,WTLB
         FROM   EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
		 WHERE  WTLB IN (80,81,83,3)
		 AND    ((JYS = 'SZ' AND SUBSTR(ZQDM1,1,2) IN ('07','37'))
		 OR     (JYS = 'SH' AND SUBSTR(ZQDM1,1,3) IN ('790','780','760','742','732','734')))
		 
         AND BUS_DATE < = %d{yyyyMMdd}			 
		 )                 t
 LEFT JOIN (SELECT          b.SECUCODE                           as ZQDM
                           ,DECODE(b.secumarket,83,'SH',90,'SZ') as JYS
                           ,a.APPLYCODEONLINE                    as ZFDM		
		                   ,CASE WHEN LENGTH(TRIM(NVL(NEWSHARELISTDATE,''))) = 0
						         THEN 99999999
								 ELSE  CAST(CONCAt(SUBSTR(NEWSHARELISTDATE,1,4),SUBSTR(NEWSHARELISTDATE,6,2),SUBSTR(NEWSHARELISTDATE,9,2) ) as INT)    
								 END     as ZFSSRQ
							,a.PREFPLAAPPLYCODEH     as LGDZFDM
							,CAST(CONCAt(SUBSTR(ISSUEDATEONLINE,1,4),SUBSTR(ISSUEDATEONLINE,6,2),SUBSTR(ISSUEDATEONLINE,9,2) ) as INT) as FXQSRQ
                  FROM 	     FUNDEXT.DBO_LC_ASHARESEASONEDNEWISSUE	  a
                  LEFT JOIN  FUNDEXT.DBO_SECUMAIN               b
                  ON         a.INNERCODE = b.INNERCODE
                  AND        a.DT = b.DT
                  WHERE      a.DT = '%d{yyyyMMdd}'
                 )                   a1 
 ON              EDW_PROD.CODE_TRANS_RGDMQZ(t.JYS,t.ZQDM1) = a1.ZFDM
 AND             t.JYS = a1.JYS
 LEFT JOIN       EDW_PROD.T_EDW_T04_TZQDM   a3
 ON              t.JYS = a3.JYS
 AND             t.ZQDM = a3.ZQDM
 AND             a3.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN       EDW_PROD.T_EDW_T99_TRD_DATE   a4
 ON              a1.ZFSSRQ = a4.TRD_DT 
 AND             a4.TRD_DT = a4.NAT_DT
 AND             a4.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN       EDW_PROD.T_EDW_T04_TSZQDM   a5
 ON              t.JYS = a5.JYS
 AND             t.ZQDM = a5.ZQDM
 AND             a5.BUS_DATE = %d{yyyyMMdd}
 WHERE            t.BUS_DATE  < = %d{yyyyMMdd}
 AND              NVL(a4.LST_TRD_D,99999999) > %d{yyyyMMdd} 
 AND              t.BUS_DATE > NVL(a5.SSRQ,99999999)
 AND              a1.ZFDM IS NOT NULL
 AND             t.BUS_DATE > = NVL(a1.FXQSRQ,99999999)
 ;
 
 INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源			
 )PARTITION (BUS_DATE = %d{yyyyMMdd} )
  SELECT      t.KHH                     as CUST_NO                  --客户号        
              ,t.KHXM                   as CUST_NAME                --客户姓名      
              ,t.YYB                    as BRH_NO                   --营业部编号     
              ,t.JYS                    as EXG                      --交易所
              ,t.GDH                    as SHRHLD_NO                --股东号
              ,t.ZQDM                   as SEC_CD                   --证券代码
              ,t.ZQDM1                  as SEC_CD1                  --证券代码1
              ,t.ZQMC                   as SEC_NAME                 --证券名称
              , CASE WHEN t.JYS = 'SB'
		         AND  SUBSTR(t.ZQDM,1,3) = '200'
				 AND  NVL(a3.ZQLB,t.ZQLB) NOT LIKE 'B%'
				 THEN 'B0'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('135','145','146')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z36'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('500')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('512')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J04'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('519')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J07'
 				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('101')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z04'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z04'
				  WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z01'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('112')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z13'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('119')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('127','128')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z10'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('150')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J06'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('184')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 ELSE NVL(a3.ZQLB,t.ZQLB)
		         END       as SEC_CGY                  --证券类别
              ,t.BZDM                   as CCY_CD                   --币种代码
              ,NULL                     as OPNWH_DT                --开仓日期
              ,NULL                     as CHG_DT                   --变动日期		
              ,CASE WHEN t.WTLB IN (3,80,83)
			        THEN t.CJSL 
					ELSE 0-t.CJSL
					END                   as SEC_QTY                  --证券数量
              ,0                        as FZN_QTY                  --冻结数量
              ,0                        as UN_CIR_SEC_QTY           --非流通数证券量	
              ,CASE WHEN t.WTLB IN (3,80,83)
			        THEN t.CJJE 
					ELSE 0-t.CJJE
					END                   as SEC_MKTVAL               --证券市值
              ,0                                                       as UN_CIR_SEC_MKTVAL        --非流通证券市值
			  ,0                         as TRD_FEE                       --交易费用
	          ,CASE WHEN t.WTLB IN (3,80,83)
			        THEN t.CJJE 
					ELSE 0-t.CJJE
					END                          as HLD_COST                      --持仓成本
	          ,0                         as GT_PRFT                       --累计盈亏
              ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户')      as SYS_SRC                  --系统来源		
 FROM   (SELECT   KHH
                 ,KHXM
				 ,DECODE(YYB,'1002','1028','1013','1029','1007','1012',YYB)  as YYB
				 ,JYS
				 ,GDH
				 ,ZQDM
				 ,ZQDM1
				 ,ZQMC
				 ,CJSL
				 ,XTBS
				 ,CJJE
				 ,BUS_DATE
				 ,ZQLB
				 ,BZDM
				 ,WTLB
         FROM   EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
		 WHERE  WTLB IN (80,81,83,3)
		 AND    ((JYS = 'SZ' AND SUBSTR(ZQDM1,1,2) IN ('07','37'))
		 OR     (JYS = 'SH' AND SUBSTR(ZQDM1,1,3) IN ('790','780','760','742')))
		 
         AND BUS_DATE < = %d{yyyyMMdd}			 
		 )                 t
 LEFT JOIN (SELECT          b.SECUCODE                           as ZQDM
                           ,DECODE(b.secumarket,83,'SH',90,'SZ') as JYS
                           ,a.APPLYCODEONLINE                    as ZFDM		
		                   ,CASE WHEN LENGTH(TRIM(NVL(NEWSHARELISTDATE,''))) = 0
						         THEN 99999999
								 ELSE  CAST(CONCAt(SUBSTR(NEWSHARELISTDATE,1,4),SUBSTR(NEWSHARELISTDATE,6,2),SUBSTR(NEWSHARELISTDATE,9,2) ) as INT)    
								 END     as ZFSSRQ
							,a.PREFPLAAPPLYCODEH     as LGDZFDM
							,CAST(CONCAt(SUBSTR(PREFPLADATEH,1,4),SUBSTR(PREFPLADATEH,6,2),SUBSTR(PREFPLADATEH,9,2) ) as INT) as FXQSRQ
                  FROM 	     FUNDEXT.DBO_LC_ASHARESEASONEDNEWISSUE	  a
                  LEFT JOIN  FUNDEXT.DBO_SECUMAIN               b
                  ON         a.INNERCODE = b.INNERCODE
                  AND        a.DT = b.DT
                  WHERE      a.DT = '%d{yyyyMMdd}'
				  AND        NVL(a.PREFPLAAPPLYCODEH,'1') <> NVL(a.APPLYCODEONLINE,'2') 
                 )                   a1 
 ON              EDW_PROD.CODE_TRANS_RGDMQZ(t.JYS,t.ZQDM1) = a1.LGDZFDM            
 AND             t.JYS = a1.JYS
 LEFT JOIN       EDW_PROD.T_EDW_T04_TZQDM   a3
 ON              t.JYS = a3.JYS
 AND             t.ZQDM = a3.ZQDM
 AND             a3.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN       EDW_PROD.T_EDW_T99_TRD_DATE   a4
 ON              a1.ZFSSRQ = a4.TRD_DT 
 AND             a4.TRD_DT = a4.NAT_DT
 AND             a4.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN       EDW_PROD.T_EDW_T04_TSZQDM   a5
 ON              t.JYS = a5.JYS
 AND             t.ZQDM = a5.ZQDM
 AND             a5.BUS_DATE = %d{yyyyMMdd}
 WHERE            t.BUS_DATE  < = %d{yyyyMMdd}
 AND              NVL(a4.LST_TRD_D,99999999) > %d{yyyyMMdd} 
 AND              t.BUS_DATE > NVL(a5.SSRQ,99999999)
 AND              a1.LGDZFDM IS NOT NULL
 AND             t.BUS_DATE > = NVL(a1.FXQSRQ,99999999)
 ;

------插入配股市值
 INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源			
 )PARTITION (BUS_DATE = %d{yyyyMMdd} )
  SELECT      t.KHH                     as CUST_NO                  --客户号        
              ,t.KHXM                   as CUST_NAME                --客户姓名      
              ,t.YYB                    as BRH_NO                   --营业部编号     
              ,t.JYS                    as EXG                      --交易所
              ,t.GDH                    as SHRHLD_NO                --股东号
              ,t.ZQDM                   as SEC_CD                   --证券代码
              ,t.ZQDM1                  as SEC_CD1                  --证券代码1
              ,t.ZQMC                   as SEC_NAME                 --证券名称
              , CASE WHEN t.JYS = 'SB'
		         AND  SUBSTR(t.ZQDM,1,3) = '200'
				 AND  NVL(a3.ZQLB,t.ZQLB) NOT LIKE 'B%'
				 THEN 'B0'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('135','145','146')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z36'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('500')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('512')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J04'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('519')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J07'
 				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('101')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z04'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z04'
				  WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z01'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('112')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z13'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('119')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('127','128')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z10'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('150')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J06'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('184')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 ELSE NVL(a3.ZQLB,t.ZQLB)
		         END       as SEC_CGY                  --证券类别
              ,t.BZDM                   as CCY_CD                   --币种代码
              ,NULL                     as OPNWH_DT                --开仓日期
              ,NULL                     as CHG_DT                   --变动日期		
              ,t.CJSL                   as SEC_QTY                  --证券数量
              ,0                        as FZN_QTY                  --冻结数量
              ,0                        as UN_CIR_SEC_QTY           --非流通数证券量	
              ,CASE WHEN  %d{yyyyMMdd} < a4.lst_trd_d
					THEN  t.CJJE
                    ELSE 0
				    END                  as SEC_MKTVAL               --证券市值
              ,0                                                       as UN_CIR_SEC_MKTVAL        --非流通证券市值
			  ,0                         as TRD_FEE                       --交易费用
	          ,0                         as HLD_COST                      --持仓成本
	          ,0                         as GT_PRFT                       --累计盈亏
              ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户')      as SYS_SRC                  --系统来源		
 FROM   (SELECT   KHH
                 ,KHXM
				 ,DECODE(YYB,'1002','1028','1013','1029','1007','1012',YYB)  as YYB
				 ,JYS
				 ,GDH
				 ,ZQDM
				 ,ZQDM1
				 ,ZQMC
				 ,CJSL
				 ,XTBS
				 ,CJJE
				 ,BUS_DATE
				 ,ZQLB
				 ,BZDM
         FROM   EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
		 WHERE  WTLB = 3
		 AND    ((JYS = 'SH' AND SUBSTR(ZQDM1,1,3) IN ('700','760','742')) 
			 OR (JYS = 'SZ' AND SUBSTR(ZQDM1,1,2) IN ('08','38')))	
         AND BUS_DATE < = %d{yyyyMMdd}			 
		 )                 t
 LEFT JOIN (SELECT          b.SECUCODE                           as ZQDM
                           ,DECODE(b.secumarket,83,'SH',90,'SZ') as JYS
                           ,a.PLACODE                            as PGDM
		                   ,CAST(CONCAt(SUBSTR(payStartDate,1,4),SUBSTR(payStartDate,6,2),SUBSTR(payStartDate,9,2) ) as INT) as PGJKQSRQ
		                   ,CAST(CONCAt(SUBSTR(payEnddate,1,4),SUBSTR(payEnddate,6,2),SUBSTR(payEnddate,9,2) ) as INT)       as PGJKJZRQ
		                   ,CAST(CONCAt(SUBSTR(rightregdate,1,4),SUBSTR(rightregdate,6,2),SUBSTR(rightregdate,9,2) ) as INT) as PGCQRQ
		                   ,CASE WHEN LENGTH(TRIM(NVL(plalistDATE,''))) = 0
						         THEN 99999999
								 ELSE  CAST(CONCAt(SUBSTR(plalistDATE,1,4),SUBSTR(plalistDATE,6,2),SUBSTR(plalistDATE,9,2) ) as INT)    
								 END     as PGSSRQ
                  FROM 	     FUNDEXT.DBO_LC_ASHAREPLACEMENT	  a
                  LEFT JOIN  FUNDEXT.DBO_SECUMAIN               b
                  ON         a.INNERCODE = b.INNERCODE
                  AND        a.DT = b.DT
                  WHERE      a.DT = '%d{yyyyMMdd}'
                  AND        CONCAt(SUBSTR(payEndDate,1,4),SUBSTR(payEnddate,6,2),SUBSTR(payEndDate,9,2) ) > = '20140101'
		    )                   a1 
 ON              t.ZQDM1 = a1.PGDM
 AND             t.JYS = a1.JYS
 LEFT JOIN       DDW_PROD.T_DDW_PUB_QOT a2
 ON              t.JYS = a2.EXG
 AND             t.ZQDM = a2.CD
 AND             a2.TRD_MKT = 1
 AND             a2.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN       EDW_PROD.T_EDW_T04_TZQDM   a3
 ON              t.JYS = a3.JYS
 AND             t.ZQDM = a3.ZQDM
 AND             a3.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN       EDW_PROD.T_EDW_T99_TRD_DATE   a4
 ON              a1.PGSSRQ = a4.TRD_DT 
 AND             a4.TRD_DT = a4.NAT_DT
 AND             a4.BUS_DATE = %d{yyyyMMdd}
 WHERE           t.BUS_DATE > = a1.PGJKQSRQ
 AND             t.BUS_DATE < a4.lst_trd_d
 AND             %d{yyyyMMdd} > = t.BUS_DATE
 AND             %d{yyyyMMdd} < a4.lst_trd_d
 ;

--------A股申购,A股增发,可转债申购,基金认购,债券认购
INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源			
 )PARTITION (BUS_DATE = %d{yyyyMMdd} )
  SELECT      t.KHH                     as CUST_NO                  --客户号        
              ,t.KHXM                   as CUST_NAME                --客户姓名      
              ,t.YYB                    as BRH_NO                   --营业部编号     
              ,t.JYS                    as EXG                      --交易所
              ,t.GDH                    as SHRHLD_NO                --股东号
              ,t.ZQDM                   as SEC_CD                   --证券代码
              ,t.ZQDM1                  as SEC_CD1                  --证券代码1
              ,t.ZQMC                   as SEC_NAME                 --证券名称
              , CASE WHEN t.JYS = 'SB'
		         AND  SUBSTR(t.ZQDM,1,3) = '200'
				 AND  NVL(a3.ZQLB,t.ZQLB) NOT LIKE 'B%'
				 THEN 'B0'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('135','145','146')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z36'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('500')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('512')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J04'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('519')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J07'
 				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('101')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z04'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z04'
				  WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z01'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('112')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z13'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('119')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('127','128')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z10'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('150')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J06'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('184')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 ELSE NVL(a3.ZQLB,t.ZQLB)
		         END       as SEC_CGY                  --证券类别
              ,t.BZDM                   as CCY_CD                   --币种代码
              ,NULL                     as OPNWH_DT                --开仓日期
              ,NULL                     as CHG_DT                   --变动日期		
              ,CASE WHEN t.WTLB IN (3,80,83)
			        THEN t.CJSL 
					ELSE 0-t.CJSL
					END                 as SEC_QTY                  --证券数量
              ,0                        as FZN_QTY                  --冻结数量
              ,0                        as UN_CIR_SEC_QTY           --非流通数证券量	
              ,CASE WHEN t.WTLB IN (3,80,83)
			        THEN t.CJJE 
					ELSE 0-t.CJJE
					END                   as SEC_MKTVAL               --证券市值
              ,0                                                       as UN_CIR_SEC_MKTVAL        --非流通证券市值
			  ,0                         as TRD_FEE                       --交易费用
	          ,CASE WHEN t.WTLB IN (3,80,83)
			        THEN t.CJJE 
					ELSE 0-t.CJJE
					END                  as HLD_COST                      --持仓成本
	          ,0                         as GT_PRFT                       --累计盈亏
              ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户')      as SYS_SRC                  --系统来源		
 FROM   (SELECT   KHH
                 ,KHXM
				 ,DECODE(YYB,'1002','1028','1013','1029','1007','1012',YYB)  as YYB
				 ,JYS
				 ,GDH
				 ,ZQDM
				 ,ZQDM1
				 ,ZQMC
				 ,CJSL
				 ,XTBS
				 ,CJJE
				 ,BUS_DATE
				 ,ZQLB
				 ,BZDM
				 ,WTLB
         FROM   EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
		 WHERE  (WTLB IN (80,81,83) 
		 OR     (WTLB = 3 AND SUBSTR(ZQDM1,1,3) IN ('704','764','753','700','760','742','787','795') AND JYS = 'SH')
		 OR      (WTLB = 3 AND SUBSTR(ZQDM1,1,2) IN ('08','38') AND CJBH IN ('配债认购','道氏配债'))
		 )
		 AND BUS_DATE < = %d{yyyyMMdd}		 
		 )                 t
 LEFT JOIN      (    SELECT     NVL(a.JYS,b.JYS) as JYS
                              ,NVL(a.ZQDM,b.ZQDM) as ZQDM
							  ,LEAST(NVL(a.SSRQ,99999999),NVL(b.SSRQ,99999999)) as SSRQ
							  ,GREATEST(NVL(a.TSRQ,00000000),NVL(b.TSRQ,00000000)) as TSRQ
                    FROM      (SELECT JYS,ZQDM,SSRQ,TSRQ 
					           FROM EDW_PROD.T_EDW_T04_TSZQDM
							   WHERE BUS_DATE = %d{yyyyMMdd}
							   AND   CPLB IN (1,2,3,4,5,6,7,9)
							   AND   ZQDM NOT LIKE '%J'
							   ) a
			        FULL JOIN  (SELECT JYS,SUBSTR(ZQDM,1,6) as ZQDM,MIN(SSRQ) as SSRQ,MAX(TSRQ) as TSRQ,BUS_DATE FROM EDW_PROD.T_EDW_T04_TSZQDM
			                     WHERE CPLB = 5
				                 AND   ZQDM LIKE '%J'
								 AND BUS_DATE = %d{yyyyMMdd}
								 GROUP BY JYS,ZQDM,BUS_DATE
				                ) b
				    ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
				    AND          a.JYS = b.JYS
                   )       a1
 ON             t.ZQDM = a1.ZQDM
 AND            t.JYS = a1.JYS
 LEFT JOIN       EDW_PROD.T_EDW_T04_TZQDM   a3
 ON              t.JYS = a3.JYS
 AND             t.ZQDM = a3.ZQDM
 AND             a3.BUS_DATE = %d{yyyyMMdd}
 WHERE          %d{yyyyMMdd} > = t.BUS_DATE
 AND            %d{yyyyMMdd} < NVL(a1.SSRQ,99999999)
 ;
 
-------插入上市之后正常代码的市值
 INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源			
 )PARTITION (BUS_DATE = %d{yyyyMMdd} )
 SELECT        NVL(a4.KHH,t.KHH)            as CUST_NO                  --客户号        
               ,t.KHXM                      as CUST_NAME                --客户姓名      
               ,t.YYB                       as BRH_NO                   --营业部编号     
               ,t.JYS                       as EXG                      --交易所
               ,t.GDH                       as SHRHLD_NO                --股东号
               ,NVL(a1.SecurityCode,DECODE(t.ZQDM,'519028','519029',t.ZQDM))                      as SEC_CD                   --证券代码
               ,t.ZQDM                      as SEC_CD1                  --证券代码1
               ,t.ZQDM                      as SEC_NAME                 --证券名称
               , CASE WHEN t.JYS = 'SB'
		         AND  SUBSTR(t.ZQDM,1,3) = '200'
				 AND  NVL(a6.ZQLB,t.ZQLB) NOT LIKE 'B%'
				 THEN 'B0'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('135','145','146')
				 AND  LENGTH(NVL(NVL(a6.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z36'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('500')
				 AND  LENGTH(NVL(NVL(a6.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('512')
				 AND  LENGTH(NVL(NVL(a6.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J04'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('519')
				 AND  LENGTH(NVL(NVL(a6.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J07'
 				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('101')
				 AND  NVL(a6.ZQLB,t.ZQLB) < > 'Z04'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z04'
				  WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  LENGTH(NVL(NVL(a6.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  NVL(a6.ZQLB,t.ZQLB) < > 'Z01'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('112')
				 AND  LENGTH(NVL(NVL(a6.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z13'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('119')
				 AND  LENGTH(NVL(NVL(a6.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('127','128')
				 AND  LENGTH(NVL(NVL(a6.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z10'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('150')
				 AND  LENGTH(NVL(NVL(a6.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J06'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('184')
				 AND  LENGTH(NVL(NVL(a6.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 ELSE NVL(a6.ZQLB,t.ZQLB)
		         END          as SEC_CGY                  --证券类别
               ,t.BZDM                      as CCY_CD                   --币种代码
               ,t.KCRQ                      as OPNWH_DT                 --开仓日期
               ,t.BDRQ                      as CHG_DT                   --变动日期		
               ,t.ZQSL                      as SEC_QTY                  --证券数量
               ,t.DJSL                      as FZN_QTY                  --冻结数量
               ,t.FLTSL                     as UN_CIR_SEC_QTY           --非流通数证券量	
               ,NVL(ROUND((a5.NEWST_PRC+a5.NEWST_INT*a5.NETPRC_TRD_FLG)*a5.TRD_UNIT*t.zqsl,2),0)                      as SEC_MKTVAL               --证券市值
               ,NVL(ROUND((a5.NEWST_PRC+a5.NEWST_INT*a5.NETPRC_TRD_FLG)*a5.TRD_UNIT*t.FLTSL,2),0)                      as UN_CIR_SEC_MKTVAL        --非流通证券市值
               ,NVL(t.JYFY,0)               as TRD_FEE                  --交易费用
	           ,NVL(t.CCCB,0)               as HLD_COST                 --持仓成本
	           ,NVL(t.LJYK,0)               as GT_PRFT                  --累计盈亏
			  ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户')                      as SYS_SRC                  --系统来源		
 FROM       (SELECT * FROM   EDW_PROD.T_EDW_T02_TZQGL WHERE BUS_DATE = %d{yyyyMMdd})      t
 LEFT JOIN  (SELECT   SecurityCode,ExApplyingCode,DT 
		      FROM    fundext.dbo_MF_FundArchives
			  WHERE   length(trim(NVL(exapplyingcode,'')))>0
			  AND    securitycode <> exapplyingcode
			  AND    SUBSTR(securitycode,7,1) <> 'J'
			  AND    DT =  '%d{yyyyMMdd}'
			)                                                                   a1
 ON       t.ZQDM = a1.ExApplyingCode
 AND      (SUBSTR(t.ZQDM,1,3) = '519' AND t.JYS = 'SH')
 LEFT JOIN (SELECT EXG,SEC_CD_PFX,IF_AST FROM  DDW_PROD.T_DDW_CFG_SEC  GROUP BY   EXG,SEC_CD_PFX,IF_AST)                                            a2
 ON         t.JYS = a2.EXG
 AND        (SUBSTR(t.ZQDM,1,3) = a2.SEC_CD_PFX OR t.ZQDM = a2.SEC_CD_PFX)
 AND        a2.IF_AST = 0
 LEFT JOIN      (    SELECT     NVL(a.JYS,b.JYS) as JYS
                              ,NVL(a.ZQDM,b.ZQDM) as ZQDM
							  ,LEAST(NVL(a.SSRQ,99999999),NVL(b.SSRQ,99999999)) as SSRQ
							  ,GREATEST(NVL(a.TSRQ,00000000),NVL(b.TSRQ,00000000)) as TSRQ
                    FROM      (SELECT JYS,ZQDM,SSRQ,TSRQ 
					           FROM EDW_PROD.T_EDW_T04_TSZQDM
							   WHERE BUS_DATE = %d{yyyyMMdd}
							   AND   CPLB IN (1,2,3,4,5,6,7,9)
							   AND   ZQDM NOT LIKE '%J'
							   ) a
			        FULL JOIN  (SELECT JYS,SUBSTR(ZQDM,1,6) as ZQDM,MIN(SSRQ) as SSRQ,MAX(TSRQ) as TSRQ,BUS_DATE FROM EDW_PROD.T_EDW_T04_TSZQDM
			                     WHERE CPLB = 5
				                 AND   ZQDM LIKE '%J'
								 AND BUS_DATE = %d{yyyyMMdd}
								 GROUP BY JYS,ZQDM,BUS_DATE
				                ) b
				    ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
				    AND          a.JYS = b.JYS
                   )                              a3
  ON            NVL(a1.SecurityCode,DECODE(t.ZQDM,'519028','519029',t.ZQDM)) = a3.ZQDM
  AND           t.JYS = a3.JYS
 LEFT JOIN      EDW_PROD.T_EDW_T99_TWYZZZH      a4
 ON             t.KHH = a4.WYZZKHH
 AND            a4.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_PUB_QOT             a5
 ON            NVL(a1.SecurityCode,DECODE(t.ZQDM,'519028','519029',t.ZQDM)) = a5.CD
 AND           t.JYS = a5.EXG       
 AND           t.BUS_DATE = a5.BUS_DATE
 AND           a5.TRD_MKT  = 1
 LEFT JOIN     EDW_PROD.T_EDW_T04_TZQDM   a6
 ON            t.JYS = a6.JYS
 AND           NVL(a1.SecurityCode,DECODE(t.ZQDM,'519028','519029',t.ZQDM)) = a6.ZQDM
 AND           a6.BUS_DATE = %d{yyyyMMdd}
 WHERE          t.BUS_DATE = %d{yyyyMMdd}
 AND            t.ZQSL > 0
 AND            (%d{yyyyMMdd} BETWEEN a3.SSRQ AND a3.TSRQ OR (t.JYS = 'SB' AND SUBSTR(t.ZQDM,1,3) IN ('238','299')))
 AND            a2.EXG IS NULL
 ;



	
--------插入回购数据---
--------插入回购数据---
 INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
                                 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
								 ,SYS_SRC                  --系统来源			
 )PARTITION (BUS_DATE = %d{yyyyMMdd} )                       	                                        	                  
 SELECT 
                                    t.KHH                        as CUST_NO                   --客户号                  
                                   ,t.KHXM                      as CUST_NAME                 --客户姓名     
                                   ,t.YYB                       as BRH_NO                    --营业部编号      
                                   ,t.JYS                       as EXG                       --交易所
                                   ,t.GDH                       as SHRHLD_NO                 --股东号           
                                   ,t.ZQDM                      as SEC_CD                    --证券代码
                                   ,t.ZQDM						as SEC_CD1                     --证券代码1		   
                                   ,t.ZQMC                      as SEC_NAME                  --证券名称     
                                   ,t.ZQLB                      as SEC_CGY                   --证券类别                               
                                   ,t.JSBZDM                    as CCY_CD                    --币种代码                                                                                
                                   ,NULL                        as OPNWH_DT                  --开仓日期
                                   ,NULL                        as CHG_DT                    --变动日期
								   ,NVL(t.CJSL,0)               as SEC_QTY                   --证券数量
								   ,0                           as FZN_QTY                   --冻结数量
                                   ,0                           as UN_CIR_SEC_QTY            --非流通数证券量	
								   ,NVL(t.CJJE,0)               as SEC_MKTVAL               --证券市值
                                   ,0                           as UN_CIR_SEC_MKTVAL        --非流通证券市值
								   ,0                           as TRD_FEE                  --交易费用
	                               ,NVL(t.CJJE,0)               as HLD_COST                 --持仓成本
	                               ,0                           as GT_PRFT                  --累计盈亏
								  ,'普通账户'                   as SYS_SRC                  --系统来源								   								  									                                           
  FROM          EDW_PROD.T_EDW_T05_TDJSQSZL                                             t   
  WHERE         t.BUS_DATE = %d{yyyyMMdd} 
  AND           t.ZQLB LIKE 'H%' 
  AND           t.WTLB = 5   
  AND           t.JSBZ_2 = 0  
  AND           t.JSRQ_2 > %d{yyyyMMdd}           --债券市值			 
;		
--------
--------债券抵押市值---
 INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源			
 )PARTITION (BUS_DATE = %d{yyyyMMdd} )                       	                                        	                  
SELECT 
                                     t.KHH                      as CUST_NO                   --客户号                  
                                   ,a1.CUST_NAME                     as CUST_NAME                 --客户姓名     
                                   ,a1.BRH_NO                      as BRH_NO                    --营业部编号    
                                   ,t.JYS                       as EXG                       --交易所
                                   ,t.GDH                       as SHRHLD_NO                 --股东号           
                                   ,t.ZQDM                      as SEC_CD                    --证券代码
                                   ,t.ZQDM						as SEC_CD1                     --证券代码1		   
                                   ,a4.ZQMC                     as SEC_NAME                  --证券名称     
                                   ,a4.ZQLB                     as SEC_CGY                   --证券类别                               
                                   ,'RMB'                       as CCY_CD                    --币种代码                                                                                
                                   ,NULL                        as OPNWH_DT                 --开仓日期
                                   ,NULL                        as CHG_DT                   --变动日期  
								   ,NVL(t.DYSL,0)               as SEC_QTY                   --证券数量
                                   ,0                           as FZN_QTY                   --冻结数量 								   
                                   ,0                           as UN_CIR_SEC_QTY            --非流通数证券量	
								   ,NVL(ROUND((a3.NEWST_PRC+a3.NEWST_INT*a3.NETPRC_TRD_FLG)*a3.TRD_UNIT*t.DYSL,2),0)               as SEC_MKTVAL               --证券市值
                                   ,0                           as UN_CIR_SEC_MKTVAL        --非流通证券市值
								   ,0                           as TRD_FEE                  --交易费用
	                               ,NVL(ROUND(100*a3.TRD_UNIT*t.DYSL,2),0) as HLD_COST                 --持仓成本
	                               ,0                           as GT_PRFT                  --累计盈亏
								   ,'普通账户'                  as SYS_SRC                  --系统来源												                                                    
  FROM          EDW_PROD.T_EDW_T02_TZQDYMX                                 t  
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO                       a1 
  ON            t.KHH = a1.CUST_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_PUB_QOT                                      a3
  ON            t.ZQDM = a3.CD
  AND           t.JYS = a3.EXG       
  AND           t.BUS_DATE = a3.BUS_DATE
  AND           a3.TRD_MKT  = 1  
  LEFT JOIN      EDW_PROD.T_EDW_T04_TZQDM                                  a4
  ON             t.JYS = a4.JYS
  AND            t.ZQDM = a4.ZQDM
  AND           a4.BUS_DATE = %d{yyyyMMdd}
  WHERE         t.BUS_DATE = %d{yyyyMMdd}  
  AND           t.DYSL > 0   
 ;	



----------------
-----上市之前的转入或者转出的市值-----

INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
                                 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
								 ,SYS_SRC                  --系统来源			
 )PARTITION (BUS_DATE = %d{yyyyMMdd} )
  SELECT      NVL(a2.KHH,t.KHH)         as CUST_NO                  --客户号        
              ,t.KHXM                   as CUST_NAME                --客户姓名      
              ,DECODE(t.YYB,'1002','1028','1013','1029','1007','1012',t.YYB)                      as BRH_NO                   --营业部编号     
              ,t.JYS                    as EXG                      --交易所
              ,t.GDH                    as SHRHLD_NO                --股东号
              ,t.ZQDM                   as SEC_CD                   --证券代码
              ,t.ZQDM1                  as SEC_CD1                  --证券代码1
              ,t.ZQMC                   as SEC_NAME                 --证券名称
              , CASE WHEN t.JYS = 'SB'
		         AND  SUBSTR(t.ZQDM,1,3) = '200'
				 AND  NVL(a3.ZQLB,t.ZQLB) NOT LIKE 'B%'
				 THEN 'B0'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('135','145','146')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z36'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('500')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('512')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J04'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('519')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J07'
 				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('101')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z04'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z04'
				  WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z01'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('112')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z13'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('119')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('127','128')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z10'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('150')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J06'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('184')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 ELSE NVL(a3.ZQLB,t.ZQLB)
		         END       as SEC_CGY                  --证券类别
              ,t.BZDM                   as CCY_CD                   --币种代码
              ,NULL                     as OPNWH_DT                --开仓日期
              ,NULL                     as CHG_DT                   --变动日期		
              ,CASE WHEN t.WTLB IN (9,15,4444)
			        THEN t.CJSL 
					ELSE 0-t.CJSL
					END                 as SEC_QTY                  --证券数量
              ,0                        as FZN_QTY                  --冻结数量
              ,0                        as UN_CIR_SEC_QTY           --非流通数证券量	
              ,CASE WHEN t.WTLB IN (9,15,4444)
			        THEN t.CJJE 
					ELSE 0-t.CJJE
					END                   as SEC_MKTVAL               --证券市值
              ,0                                                       as UN_CIR_SEC_MKTVAL        --非流通证券市值
             ,0                           as TRD_FEE                  --交易费用
	         ,CASE WHEN t.WTLB IN (9,15,4444)
			        THEN t.CJJE 
					ELSE 0-t.CJJE
					END                   as HLD_COST                 --持仓成本
	         ,0                           as GT_PRFT                  --累计盈亏
			 ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户')      as SYS_SRC                  --
  FROM      EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW  t
  LEFT JOIN (   SELECT     NVL(a.JYS,b.JYS) as JYS
                              ,NVL(a.ZQDM,b.ZQDM) as ZQDM
							  ,LEAST(NVL(a.SSRQ,99999999),NVL(b.SSRQ,99999999)) as SSRQ
							  ,GREATEST(NVL(a.TSRQ,00000000),NVL(b.TSRQ,00000000)) as TSRQ
                    FROM      (SELECT JYS,ZQDM,SSRQ,TSRQ 
					           FROM EDW_PROD.T_EDW_T04_TSZQDM
							   WHERE BUS_DATE = %d{yyyyMMdd}
							   AND   CPLB IN (1,2,3,4,5,6,7,9)
							   AND   ZQDM NOT LIKE '%J'
							   ) a
			        FULL JOIN  (SELECT JYS,SUBSTR(ZQDM,1,6) as ZQDM,MIN(SSRQ) as SSRQ,MAX(TSRQ) as TSRQ,BUS_DATE FROM EDW_PROD.T_EDW_T04_TSZQDM
			                     WHERE CPLB = 5
				                 AND   ZQDM LIKE '%J'
								 AND BUS_DATE = %d{yyyyMMdd}
								 GROUP BY JYS,ZQDM,BUS_DATE
				                ) b
				    ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
				    AND          a.JYS = b.JYS
			)               a1
 ON        t.JYS = a1.JYS
 AND       t.ZQDM = a1.ZQDM
 LEFT JOIN      EDW_PROD.T_EDW_T99_TWYZZZH      a2
 ON             t.KHH = a2.WYZZKHH
 AND            a2.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     EDW_PROD.T_EDW_T04_TZQDM   a3
 ON            t.JYS = a3.JYS
 AND           t.ZQDM = a3.ZQDM
 AND           a3.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  (SELECT EXG,SEC_CD_PFX 
             FROM DDW_PROD.T_DDW_CFG_SEC WHERE IF_AST = 1
            GROUP BY EXG,SEC_CD_PFX
			)                     a4
 ON        t.jys = a4.EXG
 AND       substr(t.zqdm,1,3) = a4.sec_cd_pfx
 WHERE     t.WTLB IN (7,9,10,15,4444,5555)
 AND        %d{yyyyMMdd} > = t.BUS_DATE  
 AND        %d{yyyyMMdd} < nvl(a1.SSRQ,99999999)
 AND        t.BUS_DATE < nvl(a1.SSRQ,99999999)
 AND        a4.EXG IS NOT NULL
 AND        substr(t.zqdm,1,3) <> '299'
 AND        t.ZQDM <> '00000'
 --AND        a1.JYS IS NOT NULL
 ;
	
---插入一条负债划款的负的市值	
 
INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源			
 )PARTITION (BUS_DATE = %d{yyyyMMdd} )
            SELECT    t.KHH                as CUST_NO                --客户号       
			         ,t.KHXM              as CUST_NAME              --客户姓名     
			         ,t.YYB               as BRH_NO                 --营业部编号     
			         ,t.JYS               as EXG                    --交易所
			         ,t.GDH               as SHRHLD_NO              --股东号        
			         ,t.ZQDM              as SEC_CD                 --证券代码
			         ,t.ZQDM              as SEC_CD1                --证券代码1
			         ,t.ZQMC              as SEC_NAME               --证券名称             
			         ,t.ZQLB              as SEC_CGY                --证券类别
			         ,t.BZDM              as CCY_CD                 --币种代码
					 ,NULL                as OPNWH_DT                 --开仓日期
                     ,NULL                as CHG_DT                   --变动日期
			         ,0-t.WTSL            as SEC_QTY                --证券数量
			         ,0                   as FZN_QTY                --冻结数量
					 ,0                   as UN_CIR_SEC_QTY         --非流通数证券量			
			         ,0-NVL(ROUND((a3.NEWST_PRC+a3.NEWST_INT*a3.NETPRC_TRD_FLG)*a3.TRD_UNIT*t.WTSL,2),0)
										  as SEC_NEWST_MKTVAL       --证券最新市值
					 ,0					  as UN_CIR_SEC_MKTVAL        --非流通证券市值
			         ,0                   as TRD_FEE                  --交易费用
	                 ,0                   as HLD_COST                 --持仓成本
	                 ,0                   as GT_PRFT                  --累计盈亏
					 ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户')    as SYS_SRC                  --系统来源	
					
 FROM          EDW_PROD.T_EDW_T05_TWTLS   t
 LEFT JOIN     DDW_PROD.T_DDW_PUB_QOT      a3
 ON            t.ZQDM = a3.CD
 AND           t.JYS = a3.EXG 
 AND           a3.trd_mkt = 1
 AND           t.SBRQ = a3.BUS_DATE
 WHERE         t.WTLB = 70
 AND           t.SBRQ = %d{yyyyMMdd}
 AND           t.CXBZ = 'O' 
 AND           t.SBJG = 2
 AND           NOT EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T05_TJGMXLS b
                          WHERE   t.KHH = b.KHH
                           AND    t.JYS = b.JYS
                           AND    t.SBRQ = b.BUS_DATE
                           AND    t.WTLB = b.WTLB
                           AND    t.WTH = b.WTH
                           )
 
 ;
 
-----插入红股未除权的负的市值SZ 16,债券的22
-------
INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源			
 )PARTITION (BUS_DATE = %d{yyyyMMdd} )
  SELECT      t.KHH                     as CUST_NO                  --客户号        
              ,t.KHXM                   as CUST_NAME                --客户姓名      
              ,t.YYB                    as BRH_NO                   --营业部编号     
              ,t.JYS                    as EXG                      --交易所
              ,t.GDH                    as SHRHLD_NO                --股东号
              ,t.ZQDM                   as SEC_CD                   --证券代码
              ,t.ZQDM1                  as SEC_CD1                  --证券代码1
              ,t.ZQMC                   as SEC_NAME                 --证券名称
              , CASE WHEN t.JYS = 'SB'
		         AND  SUBSTR(t.ZQDM,1,3) = '200'
				 AND  NVL(a3.ZQLB,t.ZQLB) NOT LIKE 'B%'
				 THEN 'B0'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('135','145','146')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z36'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('500')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('512')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J04'
				 WHEN t.JYS = 'SH'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('519')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J07'
 				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('101')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z04'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z04'
				  WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('111')
				 AND  NVL(a3.ZQLB,t.ZQLB) < > 'Z01'
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('112')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z13'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('119')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z01'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('127','128')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'Z10'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('150')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J06'
				 WHEN t.JYS = 'SZ'
		         AND  SUBSTR(t.ZQDM,1,3) IN ('184')
				 AND  LENGTH(NVL(NVL(a3.ZQLB,t.ZQLB),'')) =2
				 AND  LENGTH(TRIM(NVL(t.ZQLB,''))) = 2
				 THEN 'J01'
				 ELSE NVL(a3.ZQLB,t.ZQLB)
		         END       as SEC_CGY                  --证券类别
              ,t.BZDM                   as CCY_CD                   --币种代码
              ,NULL                     as OPNWH_DT                --开仓日期
              ,NULL                     as CHG_DT                   --变动日期		
              ,0                        as SEC_QTY                  --证券数量
              ,0                        as FZN_QTY                  --冻结数量
              ,0                        as UN_CIR_SEC_QTY           --非流通数证券量	
              ,0-t.CJJE                 as SEC_MKTVAL               --证券市值
              ,0                        as UN_CIR_SEC_MKTVAL        --非流通证券市值
			  ,0                        as TRD_FEE                  --交易费用
	          ,0                        as HLD_COST                 --持仓成本
	          ,0                        as GT_PRFT                  --累计盈亏
              ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户')      as SYS_SRC     	
 FROM            EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW  t
 LEFT JOIN       EDW_PROD.T_EDW_T04_TZQDM            a3
 ON              t.JYS = a3.JYS
 AND             t.ZQDM = a3.ZQDM
 AND             a3.BUS_DATE = %d{yyyyMMdd}
 WHERE          t.BUS_DATE = %d{yyyyMMdd}
 AND            (t.WTLB = 22 OR (t.WTLB = 16 AND t.JYS = 'SZ')) ;
 
 
 ----临时增加'06863'持仓 BY 20200113
 INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
 (
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源
								 ,BUS_DATE
)
SELECT                            CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源
								 ,%d{yyyyMMdd} AS BUS_DATE
FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
WHERE BUS_DATE = 20200110
AND SEC_CD = '06863'
AND CUST_NO IN ('107600015243','105500018739','103716801412')
;

----临时增加'113539'持仓 BY 20190821  增加'00729'持仓 BY 20190905  删除增加'00729'持仓 BY 20190918
INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源
								 ,BUS_DATE
)
SELECT                            CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源
								 ,%d{yyyyMMdd} AS BUS_DATE
FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
WHERE BUS_DATE = 20190904
AND
( 
 (CUST_NO = '103815832158' AND SEC_CD = '113539')
 --OR
---(CUST_NO IN ('100180100832','101620701417','103518800060') AND SEC_CD = '00729')
)
;

INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源			
 )PARTITION (BUS_DATE = %d{yyyyMMdd} )
  SELECT      t.KHH                     as CUST_NO                  --客户号        
              ,t.KHXM                   as CUST_NAME                --客户姓名      
              ,t.YYB                    as BRH_NO                   --营业部编号     
              ,t.JYS                    as EXG                      --交易所
              ,t.GDH                    as SHRHLD_NO                --股东号
              ,'00566'                   as SEC_CD                   --证券代码
              ,t.ZQDM1                  as SEC_CD1                  --证券代码1
              ,t.ZQMC                   as SEC_NAME                 --证券名称
              , 'A0'       as SEC_CGY                  --证券类别
              ,t.BZDM                   as CCY_CD                   --币种代码
              ,NULL                     as OPNWH_DT                --开仓日期
              ,NULL                     as CHG_DT                   --变动日期		
              ,t.CJSL                        as SEC_QTY                  --证券数量
              ,0                        as FZN_QTY                  --冻结数量
              ,0                        as UN_CIR_SEC_QTY           --非流通数证券量	
              ,round(t.cjsl*3.91,2)                 as SEC_MKTVAL               --证券市值
              ,0                        as UN_CIR_SEC_MKTVAL        --非流通证券市值
			  ,0                        as TRD_FEE                  --交易费用
	          ,0                        as HLD_COST                 --持仓成本
	          ,0                        as GT_PRFT                  --累计盈亏
              ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户')      as SYS_SRC     	
 FROM            EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW  t
 where t.ZQDM1 =  '44041' and bus_date = 20190620 ;
 

----临时增加'113539'持仓 BY 20190821  增加'00729'持仓 BY 20190905  删除增加'00729'持仓 BY 20190918
INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源
								 ,BUS_DATE
)
SELECT                            CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源
								 ,%d{yyyyMMdd} AS BUS_DATE
FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
WHERE BUS_DATE = 20200408
AND
( 
 (CUST_NO IN ('101220933269','106700250981') AND SEC_CD = '110067')
)
;

----临时增加'113589'持仓 BY 20200716
INSERT INTO DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
(
                                  CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源
								 ,BUS_DATE
)
SELECT                            CUST_NO                  --客户号        
                                 ,CUST_NAME                --客户姓名      
                                 ,BRH_NO                   --营业部编号       
                                 ,EXG                      --交易所
                                 ,SHRHLD_NO                --股东号
                                 ,SEC_CD                   --证券代码
								 ,SEC_CD1                  --证券代码1
                                 ,SEC_NAME                 --证券名称
                                 ,SEC_CGY                  --证券类别
                                 ,CCY_CD                   --币种代码
								 ,OPNWH_DT                 --开仓日期
                                 ,CHG_DT                   --变动日期			
                                 ,SEC_QTY                  --证券数量
								 ,FZN_QTY                  --冻结数量
                                 ,UN_CIR_SEC_QTY           --非流通数证券量								  
                                 ,SEC_MKTVAL               --证券市值
                                 ,UN_CIR_SEC_MKTVAL        --非流通证券市值
								 ,TRD_FEE                  --交易费用
	                             ,HLD_COST                 --持仓成本
	                             ,GT_PRFT                  --累计盈亏
                                 ,SYS_SRC                  --系统来源
								 ,%d{yyyyMMdd} AS BUS_DATE
FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
WHERE BUS_DATE = 20200715
AND
( 
 (CUST_NO IN ('101620744240') AND SEC_CD = '113589')
)
;

---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_AST_SEC_HLD_DTL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS ;
 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:融资融券帐户信息表                                                               */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 

   TRUNCATE TABLE DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO; 
  
----判断是否有临时表
 DROP TABLE IF EXISTS   DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP;
 DROP TABLE IF EXISTS   DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP2;
   DROP TABLE IF EXISTS   DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP21;
   DROP TABLE IF EXISTS   DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP22;
----创建临时表  
   CREATE TABLE DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP AS
        SELECT t.RQ,t.KHH,t.ZY
		 FROM 
        (
		SELECT   RQ,KHH,FSSJ,ZY,'RZRQ' AS LY ,ROW_NUMBER() OVER(PARTITION BY KHH ORDER BY RQ DESC, FSSJ DESC) AS NUM		
		FROM     EDW_PROD.T_EDW_T05_TYWXTCZMX
		WHERE    XTBS = 'RZRQ' AND ywkm = '30599' AND zy like('%佣金%')  and zy like('%对象复核%') 
		)        t
		WHERE t.NUM = 1
	  ;


-------首次信用额度的口径 临时表-------
CREATE TABLE  DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP21
 AS
 SELECT   KHH      as KHH
          ,MIN(RQ) as RQ 
 FROM     EDW_PROD.T_EDW_T02_TXY_HTXXLS 
 WHERE    RZXYED+RQXYED > 0
 GROUP BY KHH ;
 
----------			  
CREATE TABLE DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP22 AS
 SELECT   a.khh as KHH
          ,a.rzxyed as rzxyed
		  ,a.rqxyed as rqxyed
 FROM EDW_PROD.T_EDW_T02_TXY_HTXXLS a 
 WHERE EXISTS(SELECT 1 
			  from DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP21 b 
			  WHERE a.khh=b.khh and a.rq=b.rq);
	  
	CREATE TABLE DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP2   AS
	SELECT 
                                    t.YYB                                   as BRH_NO                                                --营业部编号                                      
                                   ,nvl(a1.BRH_SHRTNM,a7.FILIL_DEPT_SHRTNM) as BRH_NAME                                              --营业部名称                                      
                                   ,CASE WHEN a3.SCJYRQ IS NOT NULL
                                         THEN a3.SCJYRQ
                                         ELSE CAST(a3.BGSSCJYRQ AS DECIMAL(38,0))
                                         END                              as ERLST_TRD_DT                                          --最早交易日期                                     
                                   ,t.KHRQ                                  as ACCNT_OPNAC_DT                                        --账户开户日期                                                                        
                                   ,t.KHH                                   as CUST_NO                                               --客户号                                        
                                   ,t.KHXM                                  as CUST_NAME                                             --客户姓名                                                                             
                                   ,a4.YHDM                                 as DEPMGT_BANK                                           --存管银行                                       
                                   ,a5.KZSX                                 as CTRL_ATTR                                             --控制属性                                                                            
                                   ,a6.RZXYED                               as FRIST_MRGNC_QUO                                      --首次融资额度                                                    
                                   ,a6.RQXYED                               as FRIST_MRGNS_QUO     								     --首次融券额度
								   ,a2.RZED                                 as MRGNC_QUO                                             --融资额度
								   ,a2.RQED                                 as MRGNS_QUO                                             --融券额度
                                   ,'信用账户'	                            as ACCNT_CGY                                             --账户类别		
                                   ,T.BUS_DATE                              AS BUS_DATE        								   
  FROM          EDW_PROD.T_EDW_T02_TZJZH                                                t
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                                a1
  ON            t.yyb      = a1.BRH_NO
  AND           t.BUS_DATE = a1.BUS_DATE
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT                                       a7
  ON            t.yyb      = a7.FILIL_DEPT_CDG
  AND           t.BUS_DATE = a7.BUS_DATE  
  LEFT JOIN     EDW_PROD.T_EDW_T02_TXY_HTXXLS                                           a2
  ON            t.KHH = a2.KHH
  AND           t.BUS_DATE = a2.BUS_DATE
   LEFT JOIN        (SELECT   KHH,MIN(SCJYRQ) AS SCJYRQ ,BUS_DATE,MIN(BGSSCJYRQ)  AS BGSSCJYRQ 
                    FROM     EDW_PROD.T_EDW_T02_TGDH
					GROUP BY KHH,BUS_DATE
					)                               a3
  ON                t.KHH = a3.KHH
  AND               t.BUS_DATE = a3.BUS_DATE
  LEFT JOIN     (SELECT KHH,YHDM,BUS_DATE FROM EDW_PROD.T_EDW_T02_TCGZHDY WHERE XTBS = 'RZRQ' )   a4
  ON            t.KHH = a4.KHH
  AND           t.BUS_DATE = a4.BUS_DATE
  LEFT JOIN     EDW_PROD.T_EDW_T99_TKHYWSX                                               a5
  ON            t.KHH = a5.KHH
  AND           t.BUS_DATE = a5.BUS_DATE
  LEFT JOIN     DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP22                                      a6
  ON            t.KHH = a6.KHH
  WHERE         t.bus_date=%d{yyyyMMdd}
  AND           t.XTBS = 'RZRQ';
  
   DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP3 ;
 CREATE TABLE  DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP3 
 as SELECT * FROM 
 (SELECT khh,round(S1*1.000000/CJJE,4) as YJL,SEQNO,ROW_NUMBER() OVER(PARTITION BY KHH ORDER BY SEQNO DESC) as num       
 FROM EDW_PROD.T_EDW_T05_TJGMXLS
 WHERE JYS IN ('SH','SZ') and s1> 0 and cjje > 0
 AND   SUBSTR(ZQLB,1,1) IN ('A','C')
 AND   WTLB IN (1,2,61,62,63,64,71)
 AND   XTBS = 'RZRQ'
 )  t
 WHERE t.NUM = 1 ;
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO
(
				BRH_NO                 --营业部编号   
               ,BRH_NAME               --营业部名称   
               ,FSTTM_TRD_DT           --首次交易日期  
               ,CRD_ACCNT_OPNAC_DT     --信用账户开户日期
               ,CUST_NO                --客户号     
               ,CUST_NAME              --客户姓名    
               ,CTF_CGY_CD             --证件类别    
               ,CTF_NO                 --证件号码    
               ,DEPMGT_BANK            --存管银行    
               ,CTRL_ATTR              --控制属性    
               ,M_LAUND_RSK_LVL        --洗钱风险等级  
               ,IMAGE_TP               --影像资料    
               ,RSK_BEAR_ABLTY         --风险承受能力  
               ,CTF_EXPR_DT            --证件截至日期  
               ,CTCT_ADDR              --联系地址    
               ,CTCT_TEL               --联系电话    
               ,PHONE                  --手机      
               ,EDU_CD                 --学历代码    
               ,OCP_CD                 --职业代码    
               ,CMSN_SETUP_DT          --佣金设置日期  
               ,CMSN_SETUP_ABST        --佣金设置摘要  
               ,FRIST_MRGNC_QUO        --首次融资额度  
               ,FRIST_MRGNS_QUO        --首次融券额度  
               ,MRGNC_QUO              --融资额度    
               ,MRGNS_QUO              --融券额度 
               ,OPN_MRGNC_MRGNS_AGE    --开通融资融券年龄
               ,FLOT_PRFT_TOT               --浮动盈亏	
               ,RCT_TM_S1_RATE      --最近一次佣金率			   
             			   
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
						 t.BRH_NO                        	AS BRH_NO                 --营业部编号         
						,t.BRH_NAME                      	AS BRH_NAME               --营业部名称         
						,t.ERLST_TRD_DT      	            AS FSTTM_TRD_DT           --首次交易日期        
						,t.ACCNT_OPNAC_DT	                AS CRD_ACCNT_OPNAC_DT     --信用账户开户日期      
						,t.CUST_NO                       	AS CUST_NO                --客户号           
						,t.CUST_NAME                    	AS CUST_NAME              --客户姓名                
						,b1.CTF_CGY_CD_NAME                  	AS CTF_CGY_CD             --证件类别          
						,a1.CTF_NO                      	AS CTF_NO                 --证件号码          
						,t.DEPMGT_BANK                  	AS DEPMGT_BANK            --存管银行          
						,t.CTRL_ATTR                    	AS CTRL_ATTR              --控制属性          
						,b6.M_LAUND_RSK_LVL_NAME             	AS M_LAUND_RSK_LVL        --洗钱风险等级        
						,a1.IMAGE_TP                    	AS IMAGE_TP               --影像资料          
						,b2.RSK_BEAR_ABLTY_NAME              	AS RSK_BEAR_ABLTY         --风险承受能力        
						,a1.CTF_EXPR_DT                 	AS CTF_EXPR_DT            --证件截至日期        
						,a1.CTCT_ADDR                   	AS CTCT_ADDR              --联系地址          
						,a1.CTCT_TEL                    	AS CTCT_TEL               --联系电话          
						,a1.PHONE                       	AS PHONE                  --手机            
						,b3.EDU_CD_NAME                      	AS EDU_CD                 --学历代码          
						,b4.OCP_CD_NAME                      	AS OCP_CD                 --职业代码          
						,a2.RQ                          	AS CMSN_SETUP_DT          --佣金设置日期        
						,a2.ZY             	                AS CMSN_SETUP_ABST        --佣金设置摘要        
						,t.FRIST_MRGNC_QUO              	AS FRIST_MRGNC_QUO        --首次融资额度        
						,t.FRIST_MRGNS_QUO              	AS FRIST_MRGNS_QUO        --首次融券额度          
						,t.MRGNC_QUO                        AS MRGNC_QUO              --融资额度
                        ,t.MRGNS_QUO	                    AS MRGNS_QUO              --融券额度
                        ,CAST(CASE WHEN NVL(a1.BRTH_YM,99999999) <>99999999 
							  THEN ROUND(EDW_PROD.G_DATE_COMPARE_DATE(CAST(t.ACCNT_OPNAC_DT AS STRING),'yyyyMMdd',CAST(a1.BRTH_YM AS STRING),'yyyyMMdd')/365,0)
							  ELSE NULL 
							  END AS DECIMAL(38,0))		   AS OPN_MRGNC_MRGNS_AGE    --开通融资融券年龄
                        ,NVL(a10.TOL_YLD,0)				as FLOT_PRFT_TOT               --浮动盈亏
                        ,a5.YJL                                as RCT_TM_S1_RATE      --最近一次佣金率							
  FROM  		DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP2                	t    
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO                    a1
  ON            t.CUST_NO = a1.CUST_NO 
  AND           t.bus_date = a1.bus_date  
  LEFT JOIN     DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP  a2
  ON            t.CUST_NO = a2.KHH
 -- LEFT JOIN     EDW_PROD.T_EDW_T01_TGRKHXX      a3
 -- ON            t.CUST_NO = a3.KHH
 -- AND           t.BUS_DATE = a3.BUS_DATE
LEFT JOIN 		DDW_PROD.V_CTF_CGY_CD					b1
ON				a1.CTF_CGY_CD = b1.CTF_CGY_CD
LEFT JOIN 		DDW_PROD.V_RSK_BEAR_ABLTY				b2
ON				a1.RSK_BEAR_ABLTY = b2.RSK_BEAR_ABLTY
LEFT JOIN 		DDW_PROD.V_EDU_CD						b3
ON				a1.EDU_CD = b3.EDU_CD
LEFT JOIN 		DDW_PROD.V_OCP_CD						b4
ON				a1.OCP_CD = b4.OCP_CD  
LEFT JOIN  DDW_PROD.V_M_LAUND_RSK_LVL            b6
ON         a1.M_LAUND_RSK_LVL = b6.M_LAUND_RSK_LVL
  LEFT JOIN (SELECT CUST_NO,SUM(tol_yld) as TOL_YLD FROM DDW_PROD.T_DDW_CUST_STATMT_DAY
              WHERE  BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS DECIMAL(38,0)) AND %d{yyyyMMdd} 
              GROUP BY CUST_NO
             )            a10
ON           t.CUST_NO = a10.CUST_NO   
LEFT JOIN DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP3 a5
ON    t.CUST_NO = a5.KHH 
  WHERE			t.bus_date = %d{yyyyMMdd}
  AND           t.ACCNT_CGY = '信用账户'
  AND           CAST(t.ACCNT_OPNAC_DT as STRING)   > =  CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-3,0,0),1,4),'0101') 
  ;
 
-----------------------------加载结束--------------------

----删除临时表
 DROP TABLE IF EXISTS   DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP;
 DROP TABLE IF EXISTS   DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP2;
 DROP TABLE IF EXISTS   DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP3;
 DROP TABLE IF EXISTS   DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP21;
 DROP TABLE IF EXISTS   DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO_TEMP22;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_ACCNT_INFO;
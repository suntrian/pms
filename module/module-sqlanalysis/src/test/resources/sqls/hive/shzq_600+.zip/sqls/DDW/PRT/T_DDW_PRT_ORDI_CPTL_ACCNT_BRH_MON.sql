 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:资金账户报表_普通账户_营业部月表                                                                   */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-11-14                                                                        */ 

------创建临时表1 合格客户  
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP as
 SELECT   a.CUST_NO
         ,a.CNTR_CPTL_ACCNT		
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE   a.CPTL_ACCNT_STAT < > '3'
 AND     a.BUS_DATE = %d{yyyyMMdd}
 AND     a.SYS_SRC = '普通账户' 
 AND     EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
                 WHERE b.CUST_RSK_LVL IN ('0','1','2','8','19') 
				 AND b.BRH_NO NOT IN('4444','8003','8002','0017','099300000001','099000000001')
				 AND b.CUST_NO NOT IN ('100610335855')
				 AND b.BUS_DATE = %d{yyyyMMdd}
				 AND a.CUST_NO = b.CUST_NO
                )
 GROUP BY a.CUST_NO
         ,a.CNTR_CPTL_ACCNT
		 ;

-----
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP1 as
 SELECT  
		  SUM(a.ACCNT_BAL) as ACCNT_BAL
		 ,a.CCY_CD
		 ,a.BRH_NO
		 ,SUM(CASE WHEN SUBSTR(a.CUST_NO,1,4) < > '4444'
                   THEN 1
                   ELSE 0
                   END
			 ) 	 as FNL_ACCNT_ACTA       --期末账户数
         ,SUM(CASE WHEN SUBSTR(CAST(a.OPNAC_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)	
                   THEN 1
                   ELSE 0
                   END
			 )              as OPNAC_ACTA          --开户数	
         ,SUM(CASE WHEN SUBSTR(CAST(a.CNCLACT_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)	
		           AND a.CPTL_ACCNT_STAT = '3'  
                   THEN 1
                   ELSE 0
                   END
			 )              as CNCLACT_ACTA          --销户数			 
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE   a.CPTL_ACCNT_STAT < > '3'
 AND     a.BUS_DATE = %d{yyyyMMdd}
 AND     a.SYS_SRC = '普通账户' 
 AND     EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
                 WHERE b.CUST_RSK_LVL IN ('0','1','2','8','19') 
				 AND b.BRH_NO NOT IN('4444','8003','8002','0017','099300000001','099000000001')
				 AND b.CUST_NO NOT IN ('100610335855')
				 AND b.BUS_DATE = %d{yyyyMMdd}
				 AND a.CUST_NO = b.CUST_NO
                )
 GROUP BY a.CCY_CD
		 ,a.BRH_NO
		 ;		 
		 
		 
		 
		 
----
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP2 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP2 as
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)   as YEAR_MON
         ,CCY_CD
		 ,BRH_NO
         ,SUM(a.ACCNT_BAL)   as ACCNT_BAL
		 ,SUM(CASE WHEN SUBSTR(a.CUST_NO,1,4) < > '4444'
                   THEN 1
                   ELSE 0
                   END
			 ) 	 as STRT_ACCNT_ACTA      --期初账户数
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP b
                 WHERE a.CNTR_CPTL_ACCNT = b.CNTR_CPTL_ACCNT
				 AND a.CUST_NO = b.CUST_NO
                )
 AND   a.SYS_SRC = '普通账户'
 AND  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                             FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                 WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                 AND BUS_DATE = %d{yyyyMMdd}
				            )  c
                     WHERE  a.BUS_DATE = c.MON_START
			 )	
 GROUP BY YEAR_MON 
         ,CCY_CD
		 ,BRH_NO;		 


 
 -----
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP3 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP3 as 
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON
          ,CCY_CD
		 ,BRH_NO
         ,SUM(CASE WHEN SUBSTR(a.BIZ_SBJ,1,3) = '101'
                   THEN a.INCM_AMT-a.PAY_AMT
				   ELSE 0
				   END 
              )                              as DEPIN_CPTL  --存入资金
		  ,SUM(CASE WHEN SUBSTR(a.BIZ_SBJ,1,3) = '102'
                   THEN a.INCM_AMT-a.PAY_AMT
				   ELSE 0
				   END 
              )                              as WTHDR_CPTL  --存入资金
		
			  
 FROM   DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS  a
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP b
                 WHERE a.CNTR_CPTL_ACCNT = b.CNTR_CPTL_ACCNT
				 AND a.CUST_NO = b.CUST_NO
                )
AND    a.SYS_SRC = '普通账户'
AND   SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
GROUP BY  YEAR_MON
         ,CCY_CD
		 ,BRH_NO
;		

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP4 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP4 as
 SELECT   a.CUST_NO
         ,a.CNTR_CPTL_ACCNT		
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE   a.CPTL_ACCNT_STAT < > '3'
 AND     a.BUS_DATE = %d{yyyyMMdd}
 AND     a.SYS_SRC = '普通账户' 
 AND     EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
                 WHERE b.CUST_RSK_LVL IN ('0','1','2','8','19') 
				 AND b.BRH_NO NOT IN('4444','8003','8002','0017','099300000001','099000000001')
				 AND b.CUST_NO NOT IN ('100610335855')
				 AND b.BUS_DATE = %d{yyyyMMdd}
				 AND SUBSTR(CASt(b.ORDI_OPNAC_DT as STRING),1,6) =  SUBSTR('%d{yyyyMMdd}',1,6)
				 AND a.CUST_NO = b.CUST_NO
                )
 GROUP BY a.CUST_NO
         ,a.CNTR_CPTL_ACCNT
		 ;

-----
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP5 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP5 as
 SELECT  
		  SUM(a.ACCNT_BAL) as ACCNT_BAL
		 ,a.CCY_CD
		 ,a.BRH_NO
		 ,SUM(CASE WHEN SUBSTR(a.CUST_NO,1,4) < > '4444'
                   THEN 1
                   ELSE 0
                   END
			 ) 	 as FNL_ACCNT_ACTA       --期末账户数
         ,SUM(CASE WHEN SUBSTR(CAST(a.OPNAC_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)	
                   THEN 1
                   ELSE 0
                   END
			 )              as OPNAC_ACTA          --开户数	
         ,SUM(CASE WHEN SUBSTR(CAST(a.CNCLACT_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)	
		           AND a.CPTL_ACCNT_STAT = '3'  
                   THEN 1
                   ELSE 0
                   END
			 )              as CNCLACT_ACTA          --销户数			 
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE   a.CPTL_ACCNT_STAT < > '3'
 AND     a.BUS_DATE = %d{yyyyMMdd}
 AND     a.SYS_SRC = '普通账户' 
 AND     EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
                 WHERE b.CUST_RSK_LVL IN ('0','1','2','8','19') 
				 AND b.BRH_NO NOT IN('4444','8003','8002','0017','099300000001','099000000001')
				 AND b.CUST_NO NOT IN ('100610335855')
				 AND b.BUS_DATE = %d{yyyyMMdd}
				 AND a.CUST_NO = b.CUST_NO
				 AND SUBSTR(CASt(b.ORDI_OPNAC_DT as STRING),1,6) =  SUBSTR('%d{yyyyMMdd}',1,6)
                )
 GROUP BY a.CCY_CD
		 ,a.BRH_NO
		 ;		 
		 
		 
		 
		 
----
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP6 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP6 as
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)   as YEAR_MON
         ,CCY_CD
		 ,BRH_NO
         ,SUM(a.ACCNT_BAL)   as ACCNT_BAL
		 ,SUM(CASE WHEN SUBSTR(a.CUST_NO,1,4) < > '4444'
                   THEN 1
                   ELSE 0
                   END
			 ) 	 as STRT_ACCNT_ACTA      --期初账户数
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP4 b
                 WHERE a.CNTR_CPTL_ACCNT = b.CNTR_CPTL_ACCNT
				 AND a.CUST_NO = b.CUST_NO
                )
 AND   a.SYS_SRC = '普通账户'
 AND  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                             FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                 WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                 AND BUS_DATE = %d{yyyyMMdd}
				            )  c
                     WHERE  a.BUS_DATE = c.MON_START
			 )	
 GROUP BY YEAR_MON 
         ,CCY_CD
		 ,BRH_NO;		 


 
 -----
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP7 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP7 as 
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON
          ,CCY_CD
		 ,BRH_NO
         ,SUM(CASE WHEN SUBSTR(a.BIZ_SBJ,1,3) = '101'
                   THEN a.INCM_AMT-a.PAY_AMT
				   ELSE 0
				   END 
              )                              as DEPIN_CPTL  --存入资金
		  ,SUM(CASE WHEN SUBSTR(a.BIZ_SBJ,1,3) = '102'
                   THEN a.INCM_AMT-a.PAY_AMT
				   ELSE 0
				   END 
              )                              as WTHDR_CPTL  --存入资金
		
			  
 FROM   DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS  a
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP4 b
                 WHERE a.CNTR_CPTL_ACCNT = b.CNTR_CPTL_ACCNT
				 AND a.CUST_NO = b.CUST_NO
                )
AND    a.SYS_SRC = '普通账户'
AND   SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
GROUP BY  YEAR_MON
         ,CCY_CD
		 ,BRH_NO
;




 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP8 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP8 as
 SELECT   a.CUST_NO
         ,a.CNTR_CPTL_ACCNT		
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE   a.CPTL_ACCNT_STAT < > '3'
 AND     a.BUS_DATE = %d{yyyyMMdd}
 AND     a.SYS_SRC = '普通账户' 
 AND     EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
                 WHERE b.CUST_RSK_LVL IN ('0','1','2','8','19') 
				 AND b.BRH_NO NOT IN('4444','8003','8002','0017','099300000001','099000000001')
				 AND b.CUST_NO NOT IN ('100610335855')
				 AND b.BUS_DATE = %d{yyyyMMdd}
				 AND SUBSTR(CASt(b.ORDI_OPNAC_DT as STRING),1,4) =  SUBSTR('%d{yyyyMMdd}',1,4)
				 AND a.CUST_NO = b.CUST_NO
                )
 GROUP BY a.CUST_NO
         ,a.CNTR_CPTL_ACCNT
		 ;

-----
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP9 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP9 as
 SELECT  
		  SUM(a.ACCNT_BAL) as ACCNT_BAL
		 ,a.CCY_CD
		 ,a.BRH_NO
		 ,SUM(CASE WHEN SUBSTR(a.CUST_NO,1,4) < > '4444'
                   THEN 1
                   ELSE 0
                   END
			 ) 	 as FNL_ACCNT_ACTA       --期末账户数
         ,SUM(CASE WHEN SUBSTR(CAST(a.OPNAC_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)	
                   THEN 1
                   ELSE 0
                   END
			 )              as OPNAC_ACTA          --开户数	
         ,SUM(CASE WHEN SUBSTR(CAST(a.CNCLACT_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)	
		           AND a.CPTL_ACCNT_STAT = '3'  
                   THEN 1
                   ELSE 0
                   END
			 )              as CNCLACT_ACTA          --销户数			 
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE   a.CPTL_ACCNT_STAT < > '3'
 AND     a.BUS_DATE = %d{yyyyMMdd}
 AND     a.SYS_SRC = '普通账户' 
 AND     EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
                 WHERE b.CUST_RSK_LVL IN ('0','1','2','8','19') 
				 AND b.BRH_NO NOT IN('4444','8003','8002','0017','099300000001','099000000001')
				 AND b.CUST_NO NOT IN ('100610335855')
				 AND b.BUS_DATE = %d{yyyyMMdd}
				 AND a.CUST_NO = b.CUST_NO
				 AND SUBSTR(CASt(b.ORDI_OPNAC_DT as STRING),1,4) =  SUBSTR('%d{yyyyMMdd}',1,4)
                )
 GROUP BY a.CCY_CD
		 ,a.BRH_NO
		 ;		 
		 
		 
		 
		 
----
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP10 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP10 as
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)   as YEAR_MON
         ,CCY_CD
		 ,BRH_NO
         ,SUM(a.ACCNT_BAL)   as ACCNT_BAL
		 ,SUM(CASE WHEN SUBSTR(a.CUST_NO,1,4) < > '4444'
                   THEN 1
                   ELSE 0
                   END
			 ) 	 as STRT_ACCNT_ACTA      --期初账户数
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP8 b
                 WHERE a.CNTR_CPTL_ACCNT = b.CNTR_CPTL_ACCNT
				 AND a.CUST_NO = b.CUST_NO
                )
 AND   a.SYS_SRC = '普通账户'
 AND  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                             FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                 WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                 AND BUS_DATE = %d{yyyyMMdd}
				            )  c
                     WHERE  a.BUS_DATE = c.MON_START
			 )	
 GROUP BY YEAR_MON 
         ,CCY_CD
		 ,BRH_NO;		 


 
 -----
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP11 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP11 as 
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON
          ,CCY_CD
		 ,BRH_NO
         ,SUM(CASE WHEN SUBSTR(a.BIZ_SBJ,1,3) = '101'
                   THEN a.INCM_AMT-a.PAY_AMT
				   ELSE 0
				   END 
              )                              as DEPIN_CPTL  --存入资金
		  ,SUM(CASE WHEN SUBSTR(a.BIZ_SBJ,1,3) = '102'
                   THEN a.INCM_AMT-a.PAY_AMT
				   ELSE 0
				   END 
              )                              as WTHDR_CPTL  --存入资金
		
			  
 FROM   DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS  a
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP8 b
                 WHERE a.CNTR_CPTL_ACCNT = b.CNTR_CPTL_ACCNT
				 AND a.CUST_NO = b.CUST_NO
                )
AND    a.SYS_SRC = '普通账户'
AND   SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
GROUP BY  YEAR_MON
         ,CCY_CD
		 ,BRH_NO
;







INSERT OVERWRITE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON
(                                   FILIL_NAME               --分公司
								   ,BRH_NO                   --营业部编码
								   ,BRH_NAME                 --营业部名称
                                   ,CCY                      --币种 
                                   ,STRT_ACCNT_ACTA          --期初账户数
								   ,OPNAC_ACTA               --开户数
								   ,CNCLACT_ACTA             --销户数
								   ,FNL_ACCNT_ACTA           --期末账户数
								   ,STRT_CPTL_BAL            --期初资金余额
								   ,FNL_CPTL_BAL             --期末资金余额
								   ,DEPIN_CPTL               --资金存
								   ,WTHDR_CPTL               --资金取
                                   ,DATA_SRC                --数据来源 		   
) 
 PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
  SELECT                            a3.BELTO_FILIL    as FILIL_NAME                      --分公司
								   ,t.BRH_NO                          --营业部编码
								   ,a3.BRH_SHRTNM                       --营业部名称
                                   ,t.CCY_CD                          --币种 
                                   ,NVL(a1.STRT_ACCNT_ACTA,0)         --期初账户数
								   ,t.OPNAC_ACTA                      --开户数
								   ,t.CNCLACT_ACTA                    --销户数
								   ,t.FNL_ACCNT_ACTA                  --期末账户数
								   ,NVL(a1.ACCNT_BAL,0)  as STRT_CPTL_BAL           --期初资金余额
								   ,t.ACCNT_BAL          as FNL_CPTL_BAL            --期末资金余额
								   ,NVL(a2.DEPIN_CPTL,0)                --资金存
								   ,NVL(a2.WTHDR_CPTL,0)                --资金取
                                   ,'所有合格客户'      as DATA_SRC                            --数据来源 		
 FROM  DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP1  t
 LEFT JOIN DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP2 a1
 ON        t.CCY_CD = a1.CCY_CD
 AND       t.BRH_NO = a1.BRH_NO
 LEFT JOIN DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP3 a2
 ON        t.CCY_CD = a2.CCY_CD
 AND       t.BRH_NO = a2.BRH_NO
 INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH   a3
 ON         t.BRH_NO = a3.BRH_NO
 AND        a3.BUS_DATE = %d{yyyyMMdd} 
 UNION ALL
 SELECT                            a3.BELTO_FILIL    as FILIL_NAME                      --分公司
								   ,t.BRH_NO                          --营业部编码
								   ,a3.BRH_SHRTNM                       --营业部名称
                                   ,t.CCY_CD                          --币种 
                                   ,NVL(a1.STRT_ACCNT_ACTA,0)         --期初账户数
								   ,t.OPNAC_ACTA                      --开户数
								   ,t.CNCLACT_ACTA                    --销户数
								   ,t.FNL_ACCNT_ACTA                  --期末账户数
								   ,NVL(a1.ACCNT_BAL,0)  as STRT_CPTL_BAL           --期初资金余额
								   ,t.ACCNT_BAL          as FNL_CPTL_BAL            --期末资金余额
								   ,NVL(a2.DEPIN_CPTL,0)                --资金存
								   ,NVL(a2.WTHDR_CPTL,0)                --资金取
                                   ,'当月新开客户'      as DATA_SRC                            --数据来源 		
 FROM  DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP5  t
 LEFT JOIN DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP6 a1
 ON        t.CCY_CD = a1.CCY_CD
 AND       t.BRH_NO = a1.BRH_NO
 LEFT JOIN DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP7 a2
 ON        t.CCY_CD = a2.CCY_CD
 AND       t.BRH_NO = a2.BRH_NO
 INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH   a3
 ON         t.BRH_NO = a3.BRH_NO
 AND        a3.BUS_DATE = %d{yyyyMMdd} 
  UNION ALL
 SELECT                            a3.BELTO_FILIL    as FILIL_NAME                      --分公司
								   ,t.BRH_NO                          --营业部编码
								   ,a3.BRH_SHRTNM                       --营业部名称
                                   ,t.CCY_CD                          --币种 
                                   ,NVL(a1.STRT_ACCNT_ACTA,0)         --期初账户数
								   ,t.OPNAC_ACTA                      --开户数
								   ,t.CNCLACT_ACTA                    --销户数
								   ,t.FNL_ACCNT_ACTA                  --期末账户数
								   ,NVL(a1.ACCNT_BAL,0)  as STRT_CPTL_BAL           --期初资金余额
								   ,t.ACCNT_BAL          as FNL_CPTL_BAL            --期末资金余额
								   ,NVL(a2.DEPIN_CPTL,0)                --资金存
								   ,NVL(a2.WTHDR_CPTL,0)                --资金取
                                   ,'当年新开客户'      as DATA_SRC                            --数据来源 		
 FROM  DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP9  t
 LEFT JOIN DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP10 a1
 ON        t.CCY_CD = a1.CCY_CD
 AND       t.BRH_NO = a1.BRH_NO
 LEFT JOIN DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP11 a2
 ON        t.CCY_CD = a2.CCY_CD
 AND       t.BRH_NO = a2.BRH_NO
 INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH   a3
 ON         t.BRH_NO = a3.BRH_NO
 AND        a3.BUS_DATE = %d{yyyyMMdd} 
 ;

--
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP1 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP2 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP3 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP4 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP5 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP6 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP7 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP8 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP9 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP10 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON_TEMP11 ;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BRH_MON ;
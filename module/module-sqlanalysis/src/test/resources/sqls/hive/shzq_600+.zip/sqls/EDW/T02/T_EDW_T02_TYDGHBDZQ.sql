 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:约定购回标的证券表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TYDGHBDZQ; 
-----插入数据开始-----------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TYDGHBDZQ
(
                                    JYS                                 --交易所                                
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQFL                                --证券分类                               
                                   ,RQSX                                --融券上限                               
                                   ,RQ                                  --日期  
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.ZQFL                                as ZQFL                                --证券分类                                
                                   ,t.RQSX                                as RQSX                                --融券上限                                
                                   ,t.RQ                                  as RQ                                  --日期   
                                   ,'JZJY'                                as XTBS								   
 FROM     JZJYCX.SECURITIES_TYDGHBDZQ    t
 WHERE    t.DT = '%d{yyyyMMdd}';
----插入数据结束------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TYDGHBDZQ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TYDGHBDZQ;
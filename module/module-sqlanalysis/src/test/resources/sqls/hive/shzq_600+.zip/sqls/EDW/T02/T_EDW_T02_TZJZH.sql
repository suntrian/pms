 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:资金帐户信息表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
	

----------------------------删除今天的数据开始----------
ALTER TABLE EDW_PROD.T_EDW_T02_TZJZH DROP IF EXISTS PARTITION   (BUS_DATE = %d{yyyyMMdd});
------------------------------------删除今天的数据结束-----

-----插入数据开始-------------
----插入集中交易数据
INSERT  INTO EDW_PROD.T_EDW_T02_TZJZH
(
                                     KHH                                 --客户号                                
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,KHXM                                --客户姓名                               
                                   ,ZHMC                                --帐户名称                               
                                   ,BZDM                                --币种代码                               
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,ZJZHLB                              --资金帐户类别                             
                                   ,ZHYWFW                              --资金帐户业务范围                           
                                   ,SRYE                                --上日余额                               
                                   ,ZHYE                                --帐户余额                               
                                   ,DJJE                                --冻结金额                               
                                   ,LXJS                                --利息基数                               
                                   ,DZLX                                --待转利息                               
                                   ,YJLX                                --预计利息                               
                                   ,TZJS                                --透支基数                               
                                   ,ZJZHZT                              --资金帐户状态                             
                                   ,ZZHBZ                               --主帐户标志                              
                                   ,ZHSX_ZJ                             --资金帐户属性                             
                                   ,KHRQ                                --开户日期                               
                                   ,XHRQ                                --销户日期                               
                                   ,BDRQ                                --变动日期                               
                                   ,LXS                                 --利息税                                
                                   ,DRCKJE                              --当日存款金额                             
                                   ,ZPYE                                --支票余额                               
                                   ,XJYE                                --现金余额                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,ZCFZ                                --资产分组                               
                                   ,WJSZJ                               --未交收资金                              
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.ZHMC                                as ZHMC                                --帐户名称                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                    as BZDM                                --币种                                  
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJZHLB                              --帐户类别                                
                                   ,t.YWFW                                as ZHYWFW                              --业务范围                                
                                   ,t.SRYE                                as SRYE                                --上日余额                                
                                   ,t.ZHYE                                as ZHYE                                --帐户余额                                
                                   ,t.DJJE                                as DJJE                                --冻结金额                                
                                   ,t.LXJS                                as LXJS                                --利息基数                                
                                   ,t.DZLX                                as DZLX                                --待转利息                                
                                   ,t.YJLX                                as YJLX                                --预计利息                                
                                   ,t.TZJS                                as TZJS                                --透支基数                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJZHZT                              --帐户状态                                
                                   ,t.ZZHBZ                               as ZZHBZ                               --主帐户标志                               
                                   ,t.ZHSX                                as ZHSX_ZJ                             --帐户属性                                
                                   ,t.KHRQ                                as KHRQ                                --开户日期                                
                                   ,t.XHRQ                                as XHRQ                                --销户日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.ZRSZ                                as LXS                                 --利息税                                 
                                   ,t.DRCKJE                              as DRCKJE                              --当日存款金额                              
                                   ,t.ZPYE                                as ZPYE                                --支票余额                                
                                   ,t.XJYE                                as XJYE                                --现金余额                                
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.ZCFZ                                as ZCFZ                                --资产分组                                
                                   ,t.WJSZJ                               as WJSZJ                               --未交收资金                               
                                   ,%d{yyyyMMdd}                             as KSRQ                                --                                    
                                   ,%d{yyyyMMdd}                             as JSRQ                                --                                    
                                   ,'JZJY'                               as XTBS                                --                                    
 FROM           JZJYCX.DATACENTER_TZJZH                t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'ZJZHLB'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'ZJZHZT'
 AND            t3.YXT = 'JZJY'
 AND            t3.YDM = CAST(t.ZHZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t4
 ON             t4.YXT = 'JZJY'
 AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
 
 -------插入个股期权数据
 INSERT  INTO EDW_PROD.T_EDW_T02_TZJZH
(
                                     KHH                                 --客户号                                
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,KHXM                                --客户姓名                               
                                   ,ZHMC                                --帐户名称                               
                                   ,BZDM                                --币种代码                               
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,ZJZHLB                              --资金帐户类别                             
                                   ,ZHYWFW                              --资金帐户业务范围                           
                                   ,SRYE                                --上日余额                               
                                   ,ZHYE                                --帐户余额                               
                                   ,DJJE                                --冻结金额                               
                                   ,LXJS                                --利息基数                               
                                   ,DZLX                                --待转利息                               
                                   ,YJLX                                --预计利息                               
                                   ,TZJS                                --透支基数                               
                                   ,ZJZHZT                              --资金帐户状态                             
                                   ,ZZHBZ                               --主帐户标志                              
                                   ,ZHSX_ZJ                             --资金帐户属性                             
                                   ,KHRQ                                --开户日期                               
                                   ,XHRQ                                --销户日期                               
                                   ,BDRQ                                --变动日期                               
                                   ,LXS                                 --利息税                                
                                   ,DRCKJE                              --当日存款金额                             
                                   ,ZPYE                                --支票余额                               
                                   ,XJYE                                --现金余额                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,ZCFZ                                --资产分组                               
                                   ,WJSZJ                               --未交收资金                              
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.ZHMC                                as ZHMC                                --帐户名称                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                    as BZDM                                --币种                                  
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJZHLB                              --帐户类别                                
                                   ,t.YWFW                                as ZHYWFW                              --业务范围                                
                                   ,t.SRYE                                as SRYE                                --上日余额                                
                                   ,t.ZHYE                                as ZHYE                                --帐户余额                                
                                   ,t.DJJE                                as DJJE                                --冻结金额                                
                                   ,t.LXJS                                as LXJS                                --利息基数                                
                                   ,t.DZLX                                as DZLX                                --待转利息                                
                                   ,t.YJLX                                as YJLX                                --预计利息                                
                                   ,t.TZJS                                as TZJS                                --透支基数                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJZHZT                              --帐户状态                                
                                   ,t.ZZHBZ                               as ZZHBZ                               --主帐户标志                               
                                   ,t.ZHSX                                as ZHSX_ZJ                             --帐户属性                                
                                   ,t.KHRQ                                as KHRQ                                --开户日期                                
                                   ,t.XHRQ                                as XHRQ                                --销户日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.ZRSZ                                as LXS                                 --利息税                                 
                                   ,t.DRCKJE                              as DRCKJE                              --当日存款金额                              
                                   ,t.ZPYE                                as ZPYE                                --支票余额                                
                                   ,t.XJYE                                as XJYE                                --现金余额                                
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.ZCFZ                                as ZCFZ                                --资产分组                                
                                   ,t.WJSZJ                               as WJSZJ                               --未交收资金                               
                                   ,%d{yyyyMMdd}                           as KSRQ                                --发生的业务日期                             
                                   ,%d{yyyyMMdd}                           as JSRQ                                --发生的业务日期                             
                                   ,'GGQQ'                                as XTBS                                --GGQQ'                               
 FROM           GGQQCX.DATACENTER_TZJZH t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'GGQQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'ZJZHLB'
 AND            t2.YXT = 'GGQQ'
 AND            t2.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'ZJZHZT'
 AND            t3.YXT = 'GGQQ'
 AND            t3.YDM = CAST(t.ZHZT AS VARCHAR(20)) 
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t4
 ON             t4.YXT = 'GGQQ'
 AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';

 ------插入融资融券的数据
 INSERT  INTO EDW_PROD.T_EDW_T02_TZJZH
(
                                    KHH                                 --客户号                                
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,KHXM                                --客户姓名                               
                                   ,ZHMC                                --帐户名称                               
                                   ,BZDM                                --币种代码                               
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,ZJZHLB                              --资金帐户类别                             
                                   ,ZHYWFW                              --资金帐户业务范围                           
                                   ,SRYE                                --上日余额                               
                                   ,ZHYE                                --帐户余额                               
                                   ,DJJE                                --冻结金额                               
                                   ,LXJS                                --利息基数                               
                                   ,DZLX                                --待转利息                               
                                   ,YJLX                                --预计利息                               
                                   ,TZJS                                --透支基数                               
                                   ,ZJZHZT                              --资金帐户状态                             
                                   ,ZZHBZ                               --主帐户标志                              
                                   ,ZHSX_ZJ                             --资金帐户属性                             
                                   ,KHRQ                                --开户日期                               
                                   ,XHRQ                                --销户日期                               
                                   ,BDRQ                                --变动日期                               
                                   ,LXS                                 --利息税                                
                                   ,DRCKJE                              --当日存款金额                             
                                   ,ZPYE                                --支票余额                               
                                   ,XJYE                                --现金余额                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,ZCFZ                                --资产分组                               
                                   ,WJSZJ                               --未交收资金                              
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})	
SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.ZHMC                                as ZHMC                                --帐户名称                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                    as BZDM                                --币种                                  
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJZHLB                              --帐户类别                                
                                   ,t.YWFW                                as ZHYWFW                              --业务范围                                
                                   ,t.SRYE                                as SRYE                                --上日余额                                
                                   ,t.ZHYE                                as ZHYE                                --帐户余额                                
                                   ,t.DJJE                                as DJJE                                --冻结金额                                
                                   ,t.LXJS                                as LXJS                                --利息基数                                
                                   ,t.DZLX                                as DZLX                                --待转利息                                
                                   ,t.YJLX                                as YJLX                                --预计利息                                
                                   ,t.TZJS                                as TZJS                                --透支基数                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJZHZT                              --帐户状态                                
                                   ,t.ZZHBZ                               as ZZHBZ                               --主帐户标志                               
                                   ,t.ZHSX                                as ZHSX_ZJ                             --帐户属性                                
                                   ,t.KHRQ                                as KHRQ                                --开户日期                                
                                   ,t.XHRQ                                as XHRQ                                --销户日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.ZRSZ                                as LXS                                 --利息税                                 
                                   ,t.DRCKJE                              as DRCKJE                              --当日存款金额                              
                                   ,t.ZPYE                                as ZPYE                                --支票余额                                
                                   ,t.XJYE                                as XJYE                                --现金余额                                
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.ZCFZ                                as ZCFZ                                --资产分组                                
                                   ,t.WJSZJ                               as WJSZJ                               --未交收资金                               
                                   ,%d{yyyyMMdd}                          as KSRQ                                --                                    
                                   ,%d{yyyyMMdd}                          as JSRQ                                --                                    
                                   ,'RZRQ'                                as XTBS                                --                                    
 FROM           RZRQCX.DATACENTER_TZJZH                t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'ZJZHLB'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'ZJZHZT'
 AND            t3.YXT = 'RZRQ'
 AND            t3.YDM = CAST(t.ZHZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t4
 ON             t4.YXT = 'RZRQ'
 AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';	
-------插入数据结束	
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZJZH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata EDW_PROD.T_EDW_T02_TZJZH;
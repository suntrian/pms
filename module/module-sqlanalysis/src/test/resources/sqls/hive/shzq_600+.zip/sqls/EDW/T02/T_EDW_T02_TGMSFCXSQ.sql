 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:公民身份验证申请表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
----插入数据开始----
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TGMSFCXSQ(
                                    TGMSFCXSQ_ID                        --公民身份验证申请主键                         
                                   ,SQRQ                                --申请日期                               
                                   ,SQSJ                                --申请时间                               
                                   ,ZJBH                                --证件编号                               
                                   ,SQXM                                --申请姓名                               
                                   ,CZR                                 --操作人                                
                                   ,YYB                                 --营业部                                
                                   ,CXLX                                --查询类型                               
                                   ,CSRQ                                --出生日期                               
                                   ,XM                                  --姓名                                 
                                   ,GJDM                                --国籍代码                               
                                   ,XBDM                                --性别代码                               
                                   ,ZJBHHCJG                            --证件编号核查结果                           
                                   ,XMHCJG                              --姓名核查结果                             
                                   ,CLJG                                --处理结果                               
                                   ,JGSM                                --结果说明                               
                                   ,CLSJ                                --处理时间                               
                                   ,JKLX                                --接口类型                               
                                   ,SBRQ                                --申报日期                               
                                   ,SBSJ                                --申报时间                               
                                   ,HBRQ                                --回报日期                               
                                   ,HBSJ                                --回报时间                               
                                   ,SFFC_CLZT                           --身份复查处理状态                           
                                   ,FILEPATH                            --文件路径                               
                                   ,JGDM1                                --结果代码 
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
select 
                                    t.ID                                  as TGMSFCXSQ_ID                        --ID                                  
                                   ,t.SQRQ                                as SQRQ                                --申请日期                                
                                   ,t.SQSJ                                as SQSJ                                --申请时间                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,t.SQXM                                as SQXM                                --申请姓名                                
                                   ,t.CZR                                 as CZR                                 --操作人                                 
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                 as YYB                                 --营业部                                 
                                   ,t.CXLX                                as CXLX                                --查询类型                                
                                   ,t.CSRQ                                as CSRQ                                --出生日期                                
                                   ,t.XM                                  as XM                                  --姓名                                  
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.NATION AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as GJDM                                --国籍                                  
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.XB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as XBDM                                --性别                                  
                                   ,t.ZJBHHCJG                            as ZJBHHCJG                            --证件编号核查结果                            
                                   ,t.XMHCJG                              as XMHCJG                              --姓名核查结果                              
                                   ,t.CLJG                                as CLJG                                --处理结果                                
                                   ,t.JGSM                                as JGSM                                --结果说明                                
                                   ,t.CLSJ                                as CLSJ                                --处理时间                                
                                   ,t.JKLX                                as JKLX                                --接口类型                                
                                   ,t.SBRQ                                as SBRQ                                --申报日期                                
                                   ,t.SBSJ                                as SBSJ                                --申报时间                                
                                   ,t.HBRQ                                as HBRQ                                --回报日期                                
                                   ,t.HBSJ                                as HBSJ                                --回报时间                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.CLZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SFFC_CLZT                           --处理状态                                
                                   ,t.FILEPATH                            as FILEPATH                            --文件路径                                
                                   ,t.JGDM                                as JGDM1                                --结果代码     
                                   ,'YGT'		                          as XTBS						   
 FROM           YGTCX.CIF_TGMSFCXSQ                 t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'GJDM'
 AND            t1.YXT = 'YGT'
 AND            t1.YDM = CAST(t.NATION AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'XBDM'
 AND            t2.YXT = 'YGT_GT'
 AND            t2.YDM = CAST(t.XB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'SFFC_CLZT'
 AND            t3.YXT = 'YGT'
 AND            t3.YDM = CAST(t.CLZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t4
 ON             t4.YXT = 'CIF'
 AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE 			t.DT = '%d{yyyyMMdd}'
 
union all
select 
                                    t.ID                                  as TGMSFCXSQ_ID                        --ID                                  
                                   ,t.SQRQ                                as SQRQ                                --申请日期                                
                                   ,t.SQSJ                                as SQSJ                                --申请时间                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,t.SQXM                                as SQXM                                --申请姓名                                
                                   ,t.CZR                                 as CZR                                 --操作人                                 
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                 as YYB                                 --营业部                                 
                                   ,t.CXLX                                as CXLX                                --查询类型                                
                                   ,t.CSRQ                                as CSRQ                                --出生日期                                
                                   ,t.XM                                  as XM                                  --姓名                                  
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.NATION AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as GJDM                                --国籍                                  
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.XB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as XBDM                                --性别                                  
                                   ,t.ZJBHHCJG                            as ZJBHHCJG                            --证件编号核查结果                            
                                   ,t.XMHCJG                              as XMHCJG                              --姓名核查结果                              
                                   ,t.CLJG                                as CLJG                                --处理结果                                
                                   ,t.JGSM                                as JGSM                                --结果说明                                
                                   ,t.CLSJ                                as CLSJ                                --处理时间                                
                                   ,t.JKLX                                as JKLX                                --接口类型                                
                                   ,t.SBRQ                                as SBRQ                                --申报日期                                
                                   ,t.SBSJ                                as SBSJ                                --申报时间                                
                                   ,t.HBRQ                                as HBRQ                                --回报日期                                
                                   ,t.HBSJ                                as HBSJ                                --回报时间                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.CLZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SFFC_CLZT                           --处理状态                                
                                   ,t.FILEPATH                            as FILEPATH                            --文件路径                                
                                   ,t.JGDM                                as JGDM1                                --结果代码     
                                   ,'YGT'		                          as XTBS						   
 FROM           YGTCX.CIFHIS_TGMSFCXSQ                 t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'GJDM'
 AND            t1.YXT = 'YGT'
 AND            t1.YDM = CAST(t.NATION AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'XBDM'
 AND            t2.YXT = 'YGT_GT'
 AND            t2.YDM = CAST(t.XB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'SFFC_CLZT'
 AND            t3.YXT = 'YGT'
 AND            t3.YDM = CAST(t.CLZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t4
 ON             t4.YXT = 'CIF'
 AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE 			t.DT = '%d{yyyyMMdd}' and t.id not in (select id from YGTCX.CIF_TGMSFCXSQ where DT = '%d{yyyyMMdd}') ;
--------插入数据结束------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TGMSFCXSQ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TGMSFCXSQ;
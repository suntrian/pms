 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:休眠股东账户表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TGDZH_XM ; 
-------------插入数据开始-----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TGDZH_XM(
                                    GDH                                 --股东号                                
                                   ,JYS                                 --交易所                                
                                   ,KHH                                 --客户号                                
                                   ,YYB                                 --营业部                                
                                   ,BZDM                                --币种代码                               
                                   ,GDMC                                --股东名称                               
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,GDZT                                --股东状态                               
                                   ,KHRQ                                --开户日期                               
                                   ,FSRQ                                --发生日期                               
                                   ,JHRQ                                --激活日期                               
                                   ,YWXT                                --业务系统                               
                                   ,YWZH                                --业务账号    
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
select 
                                    t.GDH                                 as GDH                                 --股东号                                 
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as JYS                                 --交易所                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,CAST(COALESCE(t5.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )           as YYB                                 --营业部                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as BZDM                                --币种                                  
                                   ,t.GDMC                                as GDMC                                --股东名称                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.GDZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as GDZT                                --股东状态                                
                                   ,t.KHRQ                                as KHRQ                                --开户日期                                
                                   ,t.FSRQ                                as FSRQ                                --发生日期                                
                                   ,t.JHRQ                                as JHRQ                                --激活日期                                
                                   ,t.YWXT                                as YWXT                                --业务系统                                
                                   ,t.YWZH                                as YWZH                                --业务账号         
                                   ,'YGT_GT'								   
 FROM           YGTCX.CIF_TGDZH_XM                                  t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING              t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'YGT_GT'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING              t2 
 ON             t2.DMLX = 'JYS'
 AND            t2.YXT = 'YGT_GT'
 AND            t2.YDM = CAST(t.JYS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING               t3 
 ON             t3.DMLX = 'ZJLBDM'
 AND            t3.YXT = 'YGT_GT'
 AND            t3.YDM = CAST(t.ZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING               t4 
 ON             t4.DMLX = 'GDZT'
 AND            t4.YXT = 'YGT_GT'
 AND            t4.YDM = CAST(t.GDZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING                           t5
 ON             t5.YXT = 'CIF'
 AND            t5.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---------插入数据结束-----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TGDZH_XM',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TGDZH_XM;
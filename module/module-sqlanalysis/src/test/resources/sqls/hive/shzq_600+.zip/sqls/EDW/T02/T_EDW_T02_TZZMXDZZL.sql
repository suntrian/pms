 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:转帐明细对帐单表                                                                */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                       */

 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZZMXDZZL;
----------插入数据开始----------------
---------插入集中交易数据
INSERT  INTO EDW_PROD.T_EDW_T02_TZZMXDZZL(
                                    BZDM                                --币种代码                               
                                   ,YYB                                 --营业部                                
                                   ,LB                                  --类别                                 
                                   ,YZYWFQF                             --银证业务发起方                            
                                   ,SQH                                 --申请号                                
                                   ,WDH                                 --申请网点号                              
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,XTYWDM                              --系统业务代码                             
                                   ,JYJE                                --交易金额                               
                                   ,GYDM                                --柜员代码                               
                                   ,RQ                                  --日期                                 
                                   ,SJ                                  --时间                                 
                                   ,GDJG                                --勾对结果                               
                                   ,WBZH                                --外部帐户                               
                                   ,WBJGDM                              --外部机构代码                             
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CASE WHEN LENGTH(TRIM(NVL(t.BZ,'')))>0 
									     THEN CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )
                                         ELSE null										 
										 END as BZDM                                --币种                                  
                                   ,CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.LY                                  as LB                                  --类别                                  
                                   ,t.FQF                                 as YZYWFQF                             --发起方                                 
                                   ,CAST(t.SQH AS STRING) 			      as SQH                                 --申请号                    
                                   ,t.WDH                                 as WDH                                 --申请网点号                               
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.XTYWDM                              as XTYWDM                              --系统业务代码                              
                                   ,t.JYJE                                as JYJE                                --交易金额                                
                                   ,t.GYDM                                as GYDM                                --柜员代码                                
                                   ,t.RQ                                  as RQ                                  --日期                                  
                                   ,t.SJ                                  as SJ                                  --时间                                  
                                   ,t.GDJG                                as GDJG                                --勾对结果                                
                                   ,t.WBZH                                as WBZH                                --外部帐号                                
                                   ,t.WBJGDM                              as WBJGDM                              --外部机构代码                              
                                   ,'JZJY'                                as XTBS                                --                                    
 FROM           JZJYCX.ACCOUNT_TZZMXDZZL               t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t2
 ON             t2.YXT = 'JZJY'
 AND            t2.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';		

--------------插入个股期权数据
INSERT  INTO EDW_PROD.T_EDW_T02_TZZMXDZZL(
                                    BZDM                                --币种代码                               
                                   ,YYB                                 --营业部                                
                                   ,LB                                  --类别                                 
                                   ,YZYWFQF                             --银证业务发起方                            
                                   ,SQH                                 --申请号                                
                                   ,WDH                                 --申请网点号                              
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,XTYWDM                              --系统业务代码                             
                                   ,JYJE                                --交易金额                               
                                   ,GYDM                                --柜员代码                               
                                   ,RQ                                  --日期                                 
                                   ,SJ                                  --时间                                 
                                   ,GDJG                                --勾对结果                               
                                   ,WBZH                                --外部帐户                               
                                   ,WBJGDM                              --外部机构代码                             
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CASE WHEN LENGTH(TRIM(t.BZ))>0 
									     THEN CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )
                                         ELSE NULL										 
										 END as BZDM                                --币种                                  
                                   ,CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.LY                                  as LB                                  --类别                                  
                                   ,t.FQF                                 as YZYWFQF                             --发起方                                 
                                   ,CAST(t.SQH AS STRING)				  as SQH                                 --申请号                                 
                                   ,t.WDH                                 as WDH                                 --申请网点号                               
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.XTYWDM                              as XTYWDM                              --系统业务代码                              
                                   ,t.JYJE                                as JYJE                                --交易金额                                
                                   ,t.GYDM                                as GYDM                                --柜员代码                                
                                   ,t.RQ                                  as RQ                                  --日期                                  
                                   ,t.SJ                                  as SJ                                  --时间                                  
                                   ,t.GDJG                                as GDJG                                --勾对结果                                
                                   ,t.WBZH                                as WBZH                                --外部帐号                                
                                   ,t.WBJGDM                              as WBJGDM                              --外部机构代码                              
                                   ,'GGQQ'                                as XTBS                                --                                    
 FROM           GGQQCX.ACCOUNT_TZZMXDZZL               t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'GGQQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t2
 ON             t2.YXT = 'GGQQ'
 AND            t2.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';	

-------插入融资融券的数据
INSERT  INTO EDW_PROD.T_EDW_T02_TZZMXDZZL(
                                    BZDM                                --币种代码                               
                                   ,YYB                                 --营业部                                
                                   ,LB                                  --类别                                 
                                   ,YZYWFQF                             --银证业务发起方                            
                                   ,SQH                                 --申请号                                
                                   ,WDH                                 --申请网点号                              
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,XTYWDM                              --系统业务代码                             
                                   ,JYJE                                --交易金额                               
                                   ,GYDM                                --柜员代码                               
                                   ,RQ                                  --日期                                 
                                   ,SJ                                  --时间                                 
                                   ,GDJG                                --勾对结果                               
                                   ,WBZH                                --外部帐户                               
                                   ,WBJGDM                              --外部机构代码                             
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CASE WHEN LENGTH(TRIM(t.BZ))>0 
									     THEN CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )
                                         ELSE NULL										 
										 END as BZDM                                --币种                                
                                   ,CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.LY                                  as LB                                  --类别                                  
                                   ,t.FQF                                 as YZYWFQF                             --发起方                                 
                                   ,CAST(t.SQH AS STRING)		      as SQH                                 --申请号                                 
                                   ,t.WDH                                 as WDH                                 --申请网点号                               
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.XTYWDM                              as XTYWDM                              --系统业务代码                              
                                   ,t.JYJE                                as JYJE                                --交易金额                                
                                   ,t.GYDM                                as GYDM                                --柜员代码                                
                                   ,t.RQ                                  as RQ                                  --日期                                  
                                   ,t.SJ                                  as SJ                                  --时间                                  
                                   ,t.GDJG                                as GDJG                                --勾对结果                                
                                   ,t.WBZH                                as WBZH                                --外部帐号                                
                                   ,t.WBJGDM                              as WBJGDM                              --外部机构代码                              
                                   ,'RZRQ'                                as XTBS                                --                                    
 FROM           RZRQCX.ACCOUNT_TZZMXDZZL               t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t2
 ON             t2.YXT = 'RZRQ'
 AND            t2.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';	
--------插入数据结束-----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZZMXDZZL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TZZMXDZZL; 
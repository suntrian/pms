------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:融资融券客户统计年表                                                                */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

------期初
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP 
 as SELECT CUST_NO
          ,a.STRT_CRD_AST            as YRBGN_CRD_AST                     --年初信用总资产
		  ,a.STRT_CRD_NET_AST        as YRBGN_CRD_NET_AST                 --年初信用净资产
		  ,a.STRT_CRD_CPTL           as YRBGN_CRD_CPTL                    --年初信用资金余额
		  ,a.STRT_CRD_MKTVAL         as YRBGN_CRD_MKTVAL                  --年初信用市值
		  ,a.STRT_CRD_MKTVAL_HA      as YRBGN_CRD_MKTVAL_HA               --年初信用沪A市值
		  ,a.STRT_CRD_MKTVAL_SA      as YRBGN_CRD_MKTVAL_SA               --年初信用深A市值
		  ,a.STRT_CRD_MKTVAL_BOND_H  as YRBGN_CRD_MKTVAL_BOND_H           --年初信用沪债券市值
		  ,a.STRT_CRD_MKTVAL_BOND_S  as YRBGN_CRD_MKTVAL_BOND_S           --年初信用深债券市值
		  ,a.STRT_CRD_MKTVAL_FND_H   as YRBGN_CRD_MKTVAL_FND_H            --年初信用沪场内基金市值
		  ,a.STRT_CRD_MKTVAL_FND_S   as YRBGN_CRD_MKTVAL_FND_S            --年初信用深场内基金市值
		  ,a.STRT_CRD_MKTVAL_OTH     as YRBGN_CRD_MKTVAL_OTH              --年初信用其他市值
		  ,a.STRT_CRD_HLD_COST       as YRBGN_CRD_HLD_COST                --年初信用持仓成本
		  ,a.STRT_CRD_GL             as YRBGN_CRD_GL                      --年初信用负债
		  ,a.STRT_MRGNC_GL           as YRBGN_MRGNC_GL                    --年初融资负债
		  ,a.STRT_MRGNS_GL           as YRBGN_MRGNS_GL                    --年初融券负债
		  ,a.STRT_CRD_GL_HA          as YRBGN_CRD_GL_HA                   --年初沪A信用负债
		  ,a.STRT_CRD_GL_SA          as YRBGN_CRD_GL_SA                   --年初深A信用负债
		  ,a.STRT_MRGNC_CRD_QUO      as YRBGN_MRGNC_CRD_QUO               --年初融资授信额度
		  ,a.STRT_MRGNS_CRD_QUO      as YRBGN_MRGNS_CRD_QUO               --年初融券授信额度		
		  ,a.STRT_HLD_COST           as YRBGN_HLD_COST                    --年初持仓成本		
		  ,a.STRT_GNT_RTO            as YRBGN_GNT_RTO                     --年初担保比例		
		  ,a.STRT_AVL_BOND           as YRBGN_AVL_BOND                    --年初可用保证金
		  ,a.STRT_CASH_DEP_CRD_MKTVAL   as YRBGN_CASH_DEP_CRD_MKTVAL         --年初可充抵保证金证券市值
 FROM        DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON  a
  WHERE  EXISTS(SELECT 1 FROM (SELECT MIN(YEAR_MTH) as YEAR_MON 
                                    FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                       WHERE   SUBSTR(CAST(TRD_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
			                       AND BUS_DATE = %d{yyyyMMdd}
				                   )  b
                     WHERE  a.YEAR_MON = b.YEAR_MON
				      )
       ;	   
       

 -----期末
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP1
 as SELECT CUST_NO
          ,a.CRD_AST                 as YREND_CRD_AST                     --期末信用总资产
		  ,a.CRD_NET_AST             as YREND_CRD_NET_AST                 --期末信用净资产
		  ,a.CRD_CPTL                as YREND_CRD_CPTL                    --期末信用资金余额
		  ,a.CRD_MKTVAL              as YREND_CRD_MKTVAL                  --期末信用市值
		  ,a.CRD_MKTVAL_HA           as YREND_CRD_MKTVAL_HA               --期末信用沪A市值
		  ,a.CRD_MKTVAL_SA           as YREND_CRD_MKTVAL_SA               --期末信用深A市值
		  ,a.CRD_MKTVAL_BOND_H       as YREND_CRD_MKTVAL_BOND_H           --期末信用沪债券市值
		  ,a.CRD_MKTVAL_BOND_S       as YREND_CRD_MKTVAL_BOND_S           --期末信用深债券市值
		  ,a.CRD_MKTVAL_FND_H        as YREND_CRD_MKTVAL_FND_H            --期末信用沪场内基金市值
		  ,a.CRD_MKTVAL_FND_S        as YREND_CRD_MKTVAL_FND_S            --期末信用深场内基金市值
		  ,a.CRD_MKTVAL_OTH          as YREND_CRD_MKTVAL_OTH              --期末信用其他市值
		  ,a.CRD_HLD_COST            as YREND_CRD_HLD_COST                --期末信用持仓成本
		  ,a.CRD_GL                  as YREND_CRD_GL                      --期末信用负债
		  ,a.MRGNC_GL                as YREND_MRGNC_GL                    --期末融资负债
		  ,a.MRGNS_GL                as YREND_MRGNS_GL                    --期末融券负债
		  ,a.CRD_GL_HA               as YREND_CRD_GL_HA                   --期末沪A信用负债
		  ,a.CRD_GL_SA               as YREND_CRD_GL_SA                   --期末深A信用负债
		  ,a.MRGNC_CRD_QUO           as YREND_MRGNC_CRD_QUO               --期末融资授信额度
		  ,a.MRGNS_CRD_QUO           as YREND_MRGNS_CRD_QUO               --期末融券授信额度		
		  ,a.HLD_COST                as YREND_HLD_COST                    --期末持仓成本		
		  ,a.GNT_RTO                 as YREND_GNT_RTO                     --期末担保比例		
		  ,a.AVL_BOND                as YREND_AVL_BOND                    --期末可用保证金
		  ,a.REP_AMT                 as YREND_REP_AMT                     --期末还款金额
		  ,a.REP_QTY                 as YREND_REP_QTY                     --期末还券数量
		  ,a.CASH_DEP_CRD_MKTVAL     as YREND_CASH_DEP_CRD_MKTVAL         --期末可充抵保证金证券市值
 FROM        DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY   a
 WHERE       a.BUS_DATE = %d{yyyyMMdd}  ;
 ----月
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP2 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP2
 as SELECT CUST_NO
          ,SUM(MRGNC_FEE)                as MRGNC_FEE                    --融资费用
		  ,SUM(MRGNS_FEE)                as MRGNS_FEE                    --融券费用		
		  ,SUM(MRGNC_TRD_VOL)            as MRGNC_TRD_VOL                --融资交易量   
		  ,SUM(MRGNS_TRD_VOL)            as MRGNS_TRD_VOL                --融券交易量   
		  ,SUM(TRD_VOL)                  as TRD_VOL                      --交易量
		  ,SUM(TRD_VOL_ORDI)             as TRD_VOL_ORDI                 --交易量(普通) 
		  ,SUM(TRD_VOL_CRD)              as TRD_VOL_CRD                  --交易量(信用) 
		  ,SUM(BUYIN_TRD_VOL_ORDI)       as BUYIN_TRD_VOL_ORDI           --买入交易量(普通) 
		  ,SUM(BUYIN_TRD_VOL_CRD)        as BUYIN_TRD_VOL_CRD            --买入交易量(信用)
		  ,SUM(SELL_TRD_VOL_ORDI)        as SELL_TRD_VOL_ORDI            --卖出交易量(普通)
		  ,SUM(SELL_TRD_VOL_CRD)         as SELL_TRD_VOL_CRD             --卖出交易量(信用)
		  ,SUM(S1)                       as S1                           --毛佣金
		  ,SUM(ORDI_TRD_S1)              as ORDI_TRD_S1                  --普通交易毛佣金
		  ,SUM(CRD_TRD_S1)               as CRD_TRD_S1                   --信用交易毛佣金
		  ,SUM(NET_S1)                   as NET_S1                       --净佣金
		  ,SUM(ORDI_TRD_NET_S1)          as ORDI_TRD_NET_S1              --普通交易净佣金
		  ,SUM(CRD_TRD_NET_S1)           as CRD_TRD_NET_S1               --信用交易净佣金
		  ,SUM(MTCH_ITMS)                as MTCH_ITMS                    --成交笔数
		  ,SUM(MRGNC_MTCH_ITMS)          as MRGNC_MTCH_ITMS              --融资成交笔数
		  ,SUM(MRGNS_MTCH_ITMS)          as MRGNS_MTCH_ITMS              --融券成交笔数		
		  ,SUM(TDM_RTN_INT)              as TYEAR_RTN_INT                --本年归还利息
          ,SUM(PRDCT_INT)                as PRDCT_INT                    --预计利息
          ,SUM(MRGNC_PRDCT_INT)          as MRGNC_PRDCT_INT              --融资预计利息
          ,SUM(MRGNS_PRDCT_INT)          as MRGNS_PRDCT_INT              --融券预计利息
          ,SUM(TDM_ADDED_CRD_INT)        as TYEAR_ADDED_CRD_INT          --本年新增信用利息
          ,SUM(TDM_ADDED_MRGNC_INT)      as TYEAR_ADDED_MRGNC_INT        --本年新增融资利息
		  ,SUM(TDM_ADDED_MRGNS_INT)      as TYEAR_ADDED_MRGNS_INT        --本年新增融券利息
		  ,SUM(CP_TMS)                   as CP_TMS                       --平仓次数 WTLB IN (71,72)
		  ,SUM(ADD_BOND_TMS)             as ADD_BOND_TMS                 --追保次数 
		  ,SUM(CRD_TFR_IN_AMT)           as CRD_TFR_IN_AMT               --信用转入资金
		  ,SUM(CRD_TURN_OUT_AMT)         as CRD_TURN_OUT_AMT             --信用转出资金
		  ,SUM(CRD_TFR_IN_MKTVAL)        as CRD_TFR_IN_MKTVAL            --信用转入市值
		  ,SUM(CRD_TURN_OUT_MKTVAL)      as CRD_TURN_OUT_MKTVAL          --信用转出市值
          ,SUM(OVDU_TMS)                 as OVDU_TMS                     --逾期次数			  
		  ,SUM(CRD_PRFT)                 as CRD_PRFT                     --信用盈亏
 FROM        DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_MON   
 WHERE       SUBSTR(CAST(YEAR_MON as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
 GROUP BY    CUST_NO
  ;
 -----累计
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP3 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP3
 as      SELECT    KHH as CUST_NO
                 ,COUNT(1) as GT_ADD_BOND_TMS
           FROM RZRQCX.MARGIN_TXY_ZLXX
		   WHERE DT = '%d{yyyyMMdd}'
		   AND JSRQ < = %d{yyyyMMdd}
		   AND JSRQ IS NOT NULL
		   GROUP BY CUST_NO ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP4 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP4
 as      SELECT    KHH as CUST_NO
                 ,COUNT(1) as GT_CP_TMS
           FROM RZRQCX.DATACENTER_TJGMXLS
		   WHERE RZRQ < = %d{yyyyMMdd}
		   AND WTLB IN (71,72)
		   GROUP BY CUST_NO ;
		   
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP5 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP5
 as     SELECT a.KHH as CUST_NO
        ,COUNT(1) as NUM
 FROM RZRQCX.DATACENTER_TJGMXLS  a
 WHERE     a.WTLB IN (71,72)
 AND  EXISTS(SELECT 1 FROM RZRQCX.DATACENTER_TXY_FZXXLS b
             WHERE a.KHH = b.KHH 
			 AND   a.CJRQ = b.RQ 
			 AND   b.FZZT = 3
			 AND   NVL(b.BDRQ,0) > NVL(b.DQRQ,0)			
			 )
 GROUP BY CUST_NO ;
		   
 ------插入数据
  INSERT OVERWRITE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR
(        CUST_NO                                --客户号                 
        ,BRH_NO                                 --营业部编号                         
        ,CUST_CGY			                    --客户类别
        ,CRD_LVL                                --信用等级		
		,YRBGN_CRD_AST                          --年初信用总资产
		,YRBGN_CRD_NET_AST                      --年初信用净资产
		,YRBGN_CRD_CPTL                         --年初信用资金余额
		,YRBGN_CRD_MKTVAL                       --年初信用市值
		,YRBGN_CRD_MKTVAL_HA                    --年初信用沪A市值
		,YRBGN_CRD_MKTVAL_SA                    --年初信用深A市值
		,YRBGN_CRD_MKTVAL_BOND_H                --年初信用沪债券市值
		,YRBGN_CRD_MKTVAL_BOND_S                --年初信用深债券市值
		,YRBGN_CRD_MKTVAL_FND_H                 --年初信用沪场内基金市值
		,YRBGN_CRD_MKTVAL_FND_S                 --年初信用深场内基金市值
		,YRBGN_CRD_MKTVAL_OTH                   --年初信用其他市值
		,YRBGN_CRD_HLD_COST                     --年初信用持仓成本
		,YRBGN_CRD_GL                           --年初信用负债
		,YRBGN_MRGNC_GL                         --年初融资负债
		,YRBGN_MRGNS_GL                         --年初融券负债
		,YRBGN_CRD_GL_HA                        --年初沪A信用负债
		,YRBGN_CRD_GL_SA                        --年初深A信用负债
		,YRBGN_MRGNC_CRD_QUO                    --年初融资授信额度
		,YRBGN_MRGNS_CRD_QUO                    --年初融券授信额度		
		,YRBGN_HLD_COST                         --年初持仓成本		
		,YRBGN_GNT_RTO                          --年初担保比例		
		,YRBGN_AVL_BOND                         --年初可用保证金	
        ,YRBGN_CASH_DEP_CRD_MKTVAL              --年初可充抵保证金证券市值		
		,YREND_CRD_AST                          --年末信用总资产		
		,YREND_CRD_NET_AST                      --年末信用净资产		
		,YREND_CRD_CPTL                         --年末信用资金余额		
		,YREND_CRD_MKTVAL                       --年末信用市值      
		,YREND_CRD_MKTVAL_HA                    --年末信用沪A市值
		,YREND_CRD_MKTVAL_SA                    --年末信用深A市值
		,YREND_CRD_MKTVAL_BOND_H                --年末信用沪债券市值
		,YREND_CRD_MKTVAL_BOND_S                --年末信用深债券市值		
		,YREND_CRD_MKTVAL_FND_H                 --年末信用沪场内基金市值
		,YREND_CRD_MKTVAL_FND_S                 --年末信用深场内基金市值	
		,YREND_CRD_MKTVAL_OTH                   --年末信用其他市值
		,YREND_CRD_HLD_COST                     --年末信用持仓成本  
		,YREND_CRD_GL                           --年末信用负债
		,YREND_MRGNC_GL                         --年末融资负债		
		,YREND_MRGNS_GL                         --年末融券负债	
		,YREND_CRD_GL_HA                        --年末沪A信用负债
		,YREND_CRD_GL_SA                        --年末深A信用负债		
		,YREND_MRGNC_CRD_QUO                    --年末融资授信额度
		,YREND_MRGNS_CRD_QUO                    --年末融券授信额度
		,YREND_HLD_COST                         --年末持仓成本
		,YREND_GNT_RTO                          --年末担保比例
		,YREND_AVL_BOND                         --年末可用保证金		
		,YREND_REP_AMT                          --年末还款金额
		,YREND_REP_QTY                          --年末还券数量	
        ,YREND_CASH_DEP_CRD_MKTVAL              --期末可充抵保证金证券市值		
		,MRGNC_FEE                              --融资费用
		,MRGNS_FEE                              --融券费用		
		,MRGNC_TRD_VOL                          --融资交易量   
		,MRGNS_TRD_VOL                          --融券交易量   
		,TRD_VOL                                --交易量
		,TRD_VOL_ORDI                           --交易量(普通) 
		,TRD_VOL_CRD                            --交易量(信用) 
		,BUYIN_TRD_VOL_ORDI                     --买入交易量(普通) 
		,BUYIN_TRD_VOL_CRD                      --买入交易量(信用)
		,SELL_TRD_VOL_ORDI                      --卖出交易量(普通)
		,SELL_TRD_VOL_CRD                       --卖出交易量(信用)
		,S1                                     --毛佣金
		,ORDI_TRD_S1                            --普通交易毛佣金
		,CRD_TRD_S1                             --信用交易毛佣金
		,NET_S1                                 --净佣金
		,ORDI_TRD_NET_S1                        --普通交易净佣金
		,CRD_TRD_NET_S1                         --信用交易净佣金
		,MTCH_ITMS                              --成交笔数
		,MRGNC_MTCH_ITMS                        --融资成交笔数
		,MRGNS_MTCH_ITMS                        --融券成交笔数		
		,TYEAR_RTN_INT                          --本年归还利息	
		,PRDCT_INT                              --预计利息
		,MRGNC_PRDCT_INT                        --融资预计利息
		,MRGNS_PRDCT_INT                        --融券预计利息
		,TYEAR_ADDED_CRD_INT                    --本年新增信用利息
		,TYEAR_ADDED_MRGNC_INT                  --本年新增融资利息
		,TYEAR_ADDED_MRGNS_INT                  --本年新增融券利息
		,CP_TMS                                 --平仓次数 WTLB IN (71,72)
		,ADD_BOND_TMS                           --追保次数 
		,CRD_TFR_IN_AMT                         --信用转入资金
		,CRD_TURN_OUT_AMT                       --信用转出资金
		,CRD_TFR_IN_MKTVAL                      --信用转入市值
		,CRD_TURN_OUT_MKTVAL                    --信用转出市值
        ,OVDU_TMS                               --逾期次数			
		,CRD_PRFT                               --信用盈亏
		,GT_CP_TMS                              --累计平仓次数 
		,GT_ADD_BOND_TMS                        --累计追保次数
		,GT_OVDU_TMS                            --累计逾期次数
		,ETL_DT                            
 ) partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT))
 
 SELECT  t.CUST_NO                              --客户号                 
        ,t.BRH_NO                               --营业部编号                         
        ,t.CUST_CGY			                  --客户类别
        ,a1.XYDJ as CRD_LVL                              --信用等级		
		,NVL(a2.YRBGN_CRD_AST,0)                         --期初信用总资产
		,NVL(a2.YRBGN_CRD_NET_AST,0)                     --期初信用净资产
		,NVL(a2.YRBGN_CRD_CPTL,0)                        --期初信用资金余额
		,NVL(a2.YRBGN_CRD_MKTVAL,0)                      --期初信用市值
		,NVL(a2.YRBGN_CRD_MKTVAL_HA,0)                   --期初信用沪A市值
		,NVL(a2.YRBGN_CRD_MKTVAL_SA,0)                   --期初信用深A市值
		,NVL(a2.YRBGN_CRD_MKTVAL_BOND_H,0)               --期初信用沪债券市值
		,NVL(a2.YRBGN_CRD_MKTVAL_BOND_S,0)               --期初信用深债券市值
		,NVL(a2.YRBGN_CRD_MKTVAL_FND_H,0)                --期初信用沪场内基金市值
		,NVL(a2.YRBGN_CRD_MKTVAL_FND_S,0)                --期初信用深场内基金市值
		,NVL(a2.YRBGN_CRD_MKTVAL_OTH,0)                  --期初信用其他市值
		,NVL(a2.YRBGN_CRD_HLD_COST,0)                    --期初信用持仓成本
		,NVL(a2.YRBGN_CRD_GL,0)                          --期初信用负债
		,NVL(a2.YRBGN_MRGNC_GL,0)                        --期初融资负债
		,NVL(a2.YRBGN_MRGNS_GL,0)                        --期初融券负债
		,NVL(a2.YRBGN_CRD_GL_HA,0)                       --期初沪A信用负债
		,NVL(a2.YRBGN_CRD_GL_SA,0)                       --期初深A信用负债
		,NVL(a2.YRBGN_MRGNC_CRD_QUO,0)                   --期初融资授信额度
		,NVL(a2.YRBGN_MRGNS_CRD_QUO,0)                   --期初融券授信额度		
		,NVL(a2.YRBGN_HLD_COST,0)                        --期初持仓成本		
		,NVL(a2.YRBGN_GNT_RTO,0)                         --期初担保比例		
		,NVL(a2.YRBGN_AVL_BOND,0)                        --期初可用保证金
        ,NVL(a2.YRBGN_CASH_DEP_CRD_MKTVAL,0)             --年初可充抵保证金证券市值		
		,NVL(a3.YREND_CRD_AST,0)                          --期末信用总资产		
		,NVL(a3.YREND_CRD_NET_AST,0)                      --期末信用净资产		
		,NVL(a3.YREND_CRD_CPTL,0)                         --期末信用资金余额		
		,NVL(a3.YREND_CRD_MKTVAL,0)                       --期末信用市值      
		,NVL(a3.YREND_CRD_MKTVAL_HA,0)                    --期末信用沪A市值
		,NVL(a3.YREND_CRD_MKTVAL_SA,0)                    --期末信用深A市值
		,NVL(a3.YREND_CRD_MKTVAL_BOND_H,0)                --期末信用沪债券市值
		,NVL(a3.YREND_CRD_MKTVAL_BOND_S,0)                --期末信用深债券市值		
		,NVL(a3.YREND_CRD_MKTVAL_FND_H,0)                 --期末信用沪场内基金市值
		,NVL(a3.YREND_CRD_MKTVAL_FND_S,0)                 --期末信用深场内基金市值	
		,NVL(a3.YREND_CRD_MKTVAL_OTH,0)                   --期末信用其他市值
		,NVL(a3.YREND_CRD_HLD_COST,0)                     --期末信用持仓成本  
		,NVL(a3.YREND_CRD_GL,0)                           --期末信用负债
		,NVL(a3.YREND_MRGNC_GL,0)                         --期末融资负债		
		,NVL(a3.YREND_MRGNS_GL,0)                         --期末融券负债	
		,NVL(a3.YREND_CRD_GL_HA,0)                        --期末沪A信用负债
		,NVL(a3.YREND_CRD_GL_SA,0)                        --期末深A信用负债		
		,NVL(a3.YREND_MRGNC_CRD_QUO,0)                    --期末融资授信额度
		,NVL(a3.YREND_MRGNS_CRD_QUO,0)                    --期末融券授信额度
		,NVL(a3.YREND_HLD_COST,0)                         --期末持仓成本
		,NVL(a3.YREND_GNT_RTO,0)                          --期末担保比例
		,NVL(a3.YREND_AVL_BOND,0)                         --期末可用保证金		
		,NVL(a3.YREND_REP_AMT,0)                          --期末还款金额
		,NVL(a3.YREND_REP_QTY,0)                          --期末还券数量
        ,NVL(a3.YREND_CASH_DEP_CRD_MKTVAL,0)	           	
		,NVL(a4.MRGNC_FEE,0)                            --融资费用
		,NVL(a4.MRGNS_FEE,0)                            --融券费用		
		,NVL(a4.MRGNC_TRD_VOL,0)                        --融资交易量   
		,NVL(a4.MRGNS_TRD_VOL,0)                        --融券交易量   
		,NVL(a4.TRD_VOL,0)                              --交易量
		,NVL(a4.TRD_VOL_ORDI,0)                         --交易量(普通) 
		,NVL(a4.TRD_VOL_CRD,0)                          --交易量(信用) 
		,NVL(a4.BUYIN_TRD_VOL_ORDI,0)                   --买入交易量(普通) 
		,NVL(a4.BUYIN_TRD_VOL_CRD,0)                    --买入交易量(信用)
		,NVL(a4.SELL_TRD_VOL_ORDI,0)                    --卖出交易量(普通)
		,NVL(a4.SELL_TRD_VOL_CRD,0)                     --卖出交易量(信用)
		,NVL(a4.S1,0)                                   --毛佣金
		,NVL(a4.ORDI_TRD_S1,0)                          --普通交易毛佣金
		,NVL(a4.CRD_TRD_S1,0)                           --信用交易毛佣金
		,NVL(a4.NET_S1,0)                               --净佣金
		,NVL(a4.ORDI_TRD_NET_S1,0)                      --普通交易净佣金
		,NVL(a4.CRD_TRD_NET_S1,0)                       --信用交易净佣金
		,NVL(a4.MTCH_ITMS,0)                            --成交笔数
		,NVL(a4.MRGNC_MTCH_ITMS,0)                      --融资成交笔数
		,NVL(a4.MRGNS_MTCH_ITMS,0)                      --融券成交笔数		
		,NVL(a4.TYEAR_RTN_INT,0)                          --当月归还利息	
		,NVL(a4.PRDCT_INT,0)                            --预计利息
		,NVL(a4.MRGNC_PRDCT_INT,0)                      --融资预计利息
		,NVL(a4.MRGNS_PRDCT_INT,0)                      --融券预计利息
		,NVL(a4.TYEAR_ADDED_CRD_INT,0)                    --当月新增信用利息
		,NVL(a4.TYEAR_ADDED_MRGNC_INT,0)                  --当月新增融资利息
		,NVL(a4.TYEAR_ADDED_MRGNS_INT,0)                  --当月新增融券利息
		,NVL(a4.CP_TMS,0)                               --平仓次数 WTLB IN (71,72)
		,NVL(a4.ADD_BOND_TMS,0)                         --追保次数 
		,NVL(a4.CRD_TFR_IN_AMT,0)                       --信用转入资金
		,NVL(a4.CRD_TURN_OUT_AMT,0)                     --信用转出资金
		,NVL(a4.CRD_TFR_IN_MKTVAL,0)                    --信用转入市值
		,NVL(a4.CRD_TURN_OUT_MKTVAL,0)                  --信用转出市值
        ,NVL(a4.OVDU_TMS,0)		                        --逾期次数
		,NVL(a4.CRD_PRFT,0)                             --信用盈亏
		,NVL(a6.GT_CP_TMS,0)                            --累计平仓次数 
		,NVL(a5.GT_ADD_BOND_TMS,0)                      --累计追保次数
		,NVL(a7.NUM,0)   as GT_OVDU_TMS                          --累计逾期次数
		,%d{yyyyMMdd}   as ETL_DT
 FROM (SELECT CUST_NO,BRH_NO,CUST_CGY 
       FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO 
	   WHERE BUS_DATE = %d{yyyyMMdd}
	   )                                        t		
LEFT JOIN RZRQCX.MARGIN_TXY_KHXX a1
ON        t.CUST_NO = a1.KHH
AND       a1.DT = '%d{yyyyMMdd}'
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP a2
ON       t.CUST_NO = a2.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP1 a3
ON       t.CUST_NO = a3.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP2 a4
ON       t.CUST_NO = a4.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP3 a5
ON       t.CUST_NO = a5.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP4 a6
ON       t.CUST_NO = a6.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP5 a7
ON       t.CUST_NO = a7.CUST_NO
WHERE COALESCE(a2.CUST_NO,a3.CUST_NO,a4.CUST_NO) IS NOT NULL ;

----删除
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP1 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP2 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP3 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP4 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR_TEMP5 ;
 
-----------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_YEAR;
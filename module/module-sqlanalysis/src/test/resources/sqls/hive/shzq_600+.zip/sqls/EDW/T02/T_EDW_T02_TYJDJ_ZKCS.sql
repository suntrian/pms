 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:佣金定价策略参数表                                                                */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                       */

   TRUNCATE TABLE EDW_PROD.T_EDW_T02_TYJDJ_ZKCS; 
----------插入数据开始----------------
---------插入集中交易数据
INSERT INTO EDW_PROD.T_EDW_T02_TYJDJ_ZKCS(
                                     YJDJFS                              --佣金策略类别                             
                                   ,JYLFDBH                             --交易量分段编号                            
                                   ,ZCFDBH                              --资产分段编号                             
                                   ,JYSFW                               --交易所范围                              
                                   ,FLLBFW                              --费率类别范围                             
                                   ,WTFSFW                              --委托方式范围                             
                                   ,JYLBFW                              --交易类别范围                             
                                   ,FID                                 --佣金策略编号                             
                                   ,YJZKBL                              --佣金折扣比率                             
                                   ,YJXX                                --佣金下限                               
                                   ,YJSX                                --佣金上限                               
                                   ,GHFZKBL                             --过户费折扣比例                            
                                   ,FJFZKBL                             --附加费折扣比例                            
                                   ,SHBZ                                --审核标志
                                   ,SHLX								   
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.YJDJFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as YJDJFS                              --佣金定价方式                              
                                   ,t.JYLFDBH                             as JYLFDBH                             --交易量分段编号                             
                                   ,t.JYLFDBH                             as ZCFDBH                              --交易量分段编号                             
                                   ,t.JYSFW                               as JYSFW                               --交易所范围                               
                                   ,t.FLLBFW                              as FLLBFW                              --费率类别范围                              
                                   ,t.WTFSFW                              as WTFSFW                              --委托方式范围                              
                                   ,t.JYLBFW                              as JYLBFW                              --交易类别范围                              
                                   ,t.FID                                 as FID                                 --ID号                                 
                                   ,t.YJZKBL                              as YJZKBL                              --佣金折扣比率                              
                                   ,t.YJXX                                as YJXX                                --佣金下限                                
                                   ,t.YJSX                                as YJSX                                --佣金上限                                
                                   ,t.GHFZKBL                             as GHFZKBL                             --过户费折扣比例                             
                                   ,t.FJFZKBL                             as FJFZKBL                             --附加费折扣比例                             
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.SHBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SHBZ                                --审核标志                                
                                   ,t.SHLX                                as SHLX
								   ,'JZJY'                                as XTBS                                --                                    
 FROM           JZJYCX.SECURITIES_TYJDJ_ZKCS           t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'YJDJFS'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.YJDJFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'SHBZ'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.SHBZ AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';	

--------插入融资融券数据
INSERT INTO EDW_PROD.T_EDW_T02_TYJDJ_ZKCS(
                                     YJDJFS                              --佣金策略类别                             
                                   ,JYLFDBH                             --交易量分段编号                            
                                   ,ZCFDBH                              --资产分段编号                             
                                   ,JYSFW                               --交易所范围                              
                                   ,FLLBFW                              --费率类别范围                             
                                   ,WTFSFW                              --委托方式范围                             
                                   ,JYLBFW                              --交易类别范围                             
                                   ,FID                                 --佣金策略编号                             
                                   ,YJZKBL                              --佣金折扣比率                             
                                   ,YJXX                                --佣金下限                               
                                   ,YJSX                                --佣金上限                               
                                   ,GHFZKBL                             --过户费折扣比例                            
                                   ,FJFZKBL                             --附加费折扣比例                            
                                   ,SHBZ                                --审核标志                               
                                   ,SHLX
								   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.YJDJFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as YJDJFS                              --佣金定价方式                              
                                   ,t.JYLFDBH                             as JYLFDBH                             --交易量分段编号                             
                                   ,t.JYLFDBH                             as ZCFDBH                              --交易量分段编号                             
                                   ,t.JYSFW                               as JYSFW                               --交易所范围                               
                                   ,t.FLLBFW                              as FLLBFW                              --费率类别范围                              
                                   ,t.WTFSFW                              as WTFSFW                              --委托方式范围                              
                                   ,t.JYLBFW                              as JYLBFW                              --交易类别范围                              
                                   ,t.FID                                 as FID                                 --ID号                                 
                                   ,t.YJZKBL                              as YJZKBL                              --佣金折扣比率                              
                                   ,t.YJXX                                as YJXX                                --佣金下限                                
                                   ,t.YJSX                                as YJSX                                --佣金上限                                
                                   ,t.GHFZKBL                             as GHFZKBL                             --过户费折扣比例                             
                                   ,t.FJFZKBL                             as FJFZKBL                             --附加费折扣比例                             
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.SHBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SHBZ                                --审核标志                                
                                   ,t.SHLX                                as SHLX
								   ,'RZRQ'                                as XTBS                                --                                    
 FROM           RZRQCX.SECURITIES_TYJDJ_ZKCS           t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'YJDJFS'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.YJDJFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'SHBZ'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.SHBZ AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---插入数据结束---------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TYJDJ_ZKCS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TYJDJ_ZKCS;
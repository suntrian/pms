 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:融资融券额度表                                                                     */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TXY_EDKZ; 
------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TXY_EDKZ
(
                                    YYB                                 --营业部                                
                                   ,BZDM                                --币种代码                               
                                   ,RZED                                --融资额度                               
                                   ,RZXYED                              --融资授信额度                             
                                   ,RZJE                                --当前融资                               
                                   ,RQED                                --融券额度                               
                                   ,RQXYED                              --融券授信额度                             
                                   ,RQJE                                --当前融券                               
                                   ,RQ                                  --日期                                 
                                   ,GYH                                 --修改柜员                               
                                   ,ZT                                  --状态                                 
                                   ,QRRZYE                              --前日融资余额                             
                                   ,DRRZED                              --当日融资额度     
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.BZ                                  as BZDM                                --币种                                  
                                   ,t.RZED                                as RZED                                --融资额度                                
                                   ,t.RZXYED                              as RZXYED                              --融资授信额度                              
                                   ,t.RZJE                                as RZJE                                --当前融资                                
                                   ,t.RQED                                as RQED                                --融券额度                                
                                   ,t.RQXYED                              as RQXYED                              --融券授信额度                              
                                   ,t.RQJE                                as RQJE                                --当前融券                                
                                   ,t.RQ                                  as RQ                                  --日期                                  
                                   ,t.GYH                                 as GYH                                 --修改柜员                                
                                   ,t.ZT                                  as ZT                                  --状态                                  
                                   ,t.QRRZYE                              as QRRZYE                              --前日融资余额                              
                                   ,t.DRRZED                              as DRRZED                              --当日融资额度  
                                   ,'RZRQ'                                as XTBS								   
 FROM     RZRQCX.MARGIN_TXY_EDKZ   t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'RZRQ'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE    t.DT = '%d{yyyyMMdd}';
------插入数据结束--------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TXY_EDKZ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TXY_EDKZ;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:历史存管交易申请表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
------------------------删除今天的数据-------------
 ALTER TABLE EDW_PROD.T_EDW_T05_TCGJYSQLS DROP IF EXISTS PARTITION   (BUS_DATE = %d{yyyyMMdd});
------------------------删除今天的数据结束------------------------

---------------- 插入集中交易数据开始 -----------------------
INSERT  INTO EDW_PROD.T_EDW_T05_TCGJYSQLS(
                                     SEQNO                               --事件序号                               
                                   ,LSH                                 --流水号                                
                                   ,SQH                                 --申请号                                
                                   ,YZYWFQF                             --银证业务发起方                            
                                   ,KHH                                 --客户号                                
                                   ,YHDM                                --银行代码                               
                                   ,CGZH                                --存管帐户                               
                                   ,YHZH                                --银行帐号                               
                                   ,BZDM                                --币种代码                               
                                   ,XTYWDM                              --系统业务代码                             
                                   ,FSJE                                --发生金额                               
                                   ,FSYYB                               --发生营业部                              
                                   ,SQGY                                --申请柜员                               
                                   ,SQRQ                                --申请日期                               
                                   ,SQSJ                                --申请时间                               
                                   ,SQFS                                --申请方式                               
                                   ,CZZD                                --操作站点                               
                                   ,CLRQ                                --处理日期                               
                                   ,CLSJ                                --处理时间                               
                                   ,CLJG                                --处理结果                               
                                   ,BCZJYE                              --本次资金余额                             
                                   ,BDYWLSH                             --本地业务流水号                            
                                   ,CGCLJG                              --存管处理结果                             
                                   ,CGCLRQ                              --存管处理日期                             
                                   ,CGCLSJ                              --存管处理时间                             
                                   ,CGWBCLJG                            --存管外部处理结果                           
                                   ,WDH                                 --申请网点号                              
                                   ,WBJGGYDM                            --外部结构柜员代码                           
                                   ,WBLSH                               --外部流水号                              
                                   ,CXWBLSH                             --冲销外部流水号                            
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,CXSQH                               --冲销申请号                              
                                   ,CZCS                                --存折参数                               
                                   ,ZY                                  --摘要                                 
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,YWSQH                               --业务申请号                              
                                   ,SQCZRH                              --授权操作人号                             
                                   ,WBCLJG                              --外部处理结果                             
                                   ,CZZD1                               --操作终端                               
                                   ,IP_PHONE                            --IP地址/ 电话号码                         
                                   ,MAC                                 --MAC地址                              
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
select 
                                    t.SEQNO                               as SEQNO                               --序号                                  
                                   ,t.LSH                                 as LSH                                 --流水号                                 
                                   ,t.SQH                                 as SQH                                 --申请号                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.FQF AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YZYWFQF                             --发起方                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.YHDM                                as YHDM                                --银行代码                                
                                   ,t.CGZH                                as CGZH                                --存管帐户                                
                                   ,t.YHZH                                as YHZH                                --银行帐号                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.XTYWDM                              as XTYWDM                              --系统业务代码                              
                                   ,t.FSJE                                as FSJE                                --发生金额                                
                                   ,t.FSYYB                               as FSYYB                               --发生营业部                               
                                   ,t.SQGY                                as SQGY                                --申请柜员                                
                                   ,t.SQRQ                                as SQRQ                                --申请日期                                
                                   ,t.SQSJ                                as SQSJ                                --申请时间                                
                                   ,CAST( EDW_PROD.G_WTFS_J_WTFS(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD) AS DECIMAL(38,0) )       as SQFS                                --申请方式                                
                                   ,t.CZZD                                as CZZD                                --操作站点                                
                                   ,t.CLRQ                                as CLRQ                                --处理日期                                
                                   ,t.CLSJ                                as CLSJ                                --处理时间                                
                                   ,t.CLJG                                as CLJG                                --处理结果                                
                                   ,t.BCZJYE                              as BCZJYE                              --本次资金余额                              
                                   ,t.BDYWLSH                             as BDYWLSH                             --本地业务流水号                             
                                   ,t.CGCLJG                              as CGCLJG                              --存管处理结果                              
                                   ,t.CGCLRQ                              as CGCLRQ                              --存管处理日期                              
                                   ,t.CGCLSJ                              as CGCLSJ                              --存管处理时间                              
                                   ,t.CGWBCLJG                            as CGWBCLJG                            --存管外部处理结果                            
                                   ,t.WDH                                 as WDH                                 --申请网点号                               
                                   ,t.WBJGGYDM                            as WBJGGYDM                            --外部结构柜员代码                            
                                   ,t.WBLSH                               as WBLSH                               --外部流水号                               
                                   ,t.CXWBLSH                             as CXWBLSH                             --冲销外部流水号                             
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.CXSQH                               as CXSQH                               --冲销申请号                               
                                   ,t.CZCS                                as CZCS                                --存折参数                                
                                   ,t.ZY                                  as ZY                                  --摘要                                  
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.YWSQH                               as YWSQH                               --业务申请号                               
                                   ,t.SQCZRH                              as SQCZRH                              --授权操作人号                              
                                   ,t.WBCLJG                              as WBCLJG                              --外部处理结果                              
                                   ,EDW_PROD.G_WTFS_J_TERM(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)                                  as CZZD1                               --                                    
                                   ,NVL(NVL(CONCAT(EDW_PROD.G_WTFS_J_IP(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD),',',EDW_PROD.G_WTFS_J_PHONE(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)),EDW_PROD.G_WTFS_J_IP(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)),EDW_PROD.G_WTFS_J_PHONE(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD))                               as IP_PHONE                            --                                    
                                   ,NVL(NVL(CONCAT(EDW_PROD.G_WTFS_J_MAC(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD),',',EDW_PROD.G_WTFS_J_IMEI(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)),EDW_PROD.G_WTFS_J_MAC(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)),EDW_PROD.G_WTFS_J_IMEI(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD))                               as MAC                                 --                                    
                                   ,'JZJY'                                as XTBS                                --JZJY'                               
 FROM           JZJYCX.DATACENTER_TCGJYSQLS     t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1
 ON             t1.DMLX = 'YZYWFQF'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.FQF AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2
 ON             t2.DMLX = 'BZDM'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t4
 ON             t4.YXT = 'JZJY'
 AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}' ;
 ---------------------------------插入集中交易数据结束-----------------
 --------------------------------插入个股期权数据开始---------------------
	INSERT  INTO EDW_PROD.T_EDW_T05_TCGJYSQLS(
                                     SEQNO                               --事件序号                               
                                   ,LSH                                 --流水号                                
                                   ,SQH                                 --申请号                                
                                   ,YZYWFQF                             --银证业务发起方                            
                                   ,KHH                                 --客户号                                
                                   ,YHDM                                --银行代码                               
                                   ,CGZH                                --存管帐户                               
                                   ,YHZH                                --银行帐号                               
                                   ,BZDM                                --币种代码                               
                                   ,XTYWDM                              --系统业务代码                             
                                   ,FSJE                                --发生金额                               
                                   ,FSYYB                               --发生营业部                              
                                   ,SQGY                                --申请柜员                               
                                   ,SQRQ                                --申请日期                               
                                   ,SQSJ                                --申请时间                               
                                   ,SQFS                                --申请方式                               
                                   ,CZZD                                --操作站点                               
                                   ,CLRQ                                --处理日期                               
                                   ,CLSJ                                --处理时间                               
                                   ,CLJG                                --处理结果                               
                                   ,BCZJYE                              --本次资金余额                             
                                   ,BDYWLSH                             --本地业务流水号                            
                                   ,CGCLJG                              --存管处理结果                             
                                   ,CGCLRQ                              --存管处理日期                             
                                   ,CGCLSJ                              --存管处理时间                             
                                   ,CGWBCLJG                            --存管外部处理结果                           
                                   ,WDH                                 --申请网点号                              
                                   ,WBJGGYDM                            --外部结构柜员代码                           
                                   ,WBLSH                               --外部流水号                              
                                   ,CXWBLSH                             --冲销外部流水号                            
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,CXSQH                               --冲销申请号                              
                                   ,CZCS                                --存折参数                               
                                   ,ZY                                  --摘要                                 
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,YWSQH                               --业务申请号                              
                                   ,SQCZRH                              --授权操作人号                             
                                   ,WBCLJG                              --外部处理结果                             
                                   ,CZZD1                               --操作终端                               
                                   ,IP_PHONE                            --IP地址/ 电话号码                         
                                   ,MAC                                 --MAC地址                              
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.SEQNO                               as SEQNO                               --序号                                  
                                   ,t.LSH                                 as LSH                                 --流水号                                 
                                   ,t.SQH                                 as SQH                                 --申请号                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.FQF AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YZYWFQF                             --发起方                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.YHDM                                as YHDM                                --银行代码                                
                                   ,t.CGZH                                as CGZH                                --存管帐户                                
                                   ,t.YHZH                                as YHZH                                --银行帐号                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.XTYWDM                              as XTYWDM                              --系统业务代码                              
                                   ,t.FSJE                                as FSJE                                --发生金额                                
                                   ,t.FSYYB                               as FSYYB                               --发生营业部                               
                                   ,t.SQGY                                as SQGY                                --申请柜员                                
                                   ,t.SQRQ                                as SQRQ                                --申请日期                                
                                   ,t.SQSJ                                as SQSJ                                --申请时间                                
                                   ,CAST( EDW_PROD.G_WTFS_J_WTFS(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD) AS DECIMAL(38,0) )                                  as SQFS                                --申请方式                                
                                   ,t.CZZD                                as CZZD                                --操作站点                                
                                   ,t.CLRQ                                as CLRQ                                --处理日期                                
                                   ,t.CLSJ                                as CLSJ                                --处理时间                                
                                   ,t.CLJG                                as CLJG                                --处理结果                                
                                   ,t.BCZJYE                              as BCZJYE                              --本次资金余额                              
                                   ,t.BDYWLSH                             as BDYWLSH                             --本地业务流水号                             
                                   ,t.CGCLJG                              as CGCLJG                              --存管处理结果                              
                                   ,t.CGCLRQ                              as CGCLRQ                              --存管处理日期                              
                                   ,t.CGCLSJ                              as CGCLSJ                              --存管处理时间                              
                                   ,t.CGWBCLJG                            as CGWBCLJG                            --存管外部处理结果                            
                                   ,t.WDH                                 as WDH                                 --申请网点号                               
                                   ,t.WBJGGYDM                            as WBJGGYDM                            --外部结构柜员代码                            
                                   ,t.WBLSH                               as WBLSH                               --外部流水号                               
                                   ,t.CXWBLSH                             as CXWBLSH                             --冲销外部流水号                             
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.CXSQH                               as CXSQH                               --冲销申请号                               
                                   ,t.CZCS                                as CZCS                                --存折参数                                
                                   ,t.ZY                                  as ZY                                  --摘要                                  
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.YWSQH                               as YWSQH                               --业务申请号                               
                                   ,t.SQCZRH                              as SQCZRH                              --授权操作人号                              
                                   ,t.WBCLJG                              as WBCLJG                              --外部处理结果                              
                                   ,EDW_PROD.G_WTFS_J_TERM(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)                                  as CZZD1                               --                                    
                                   ,NVL(NVL(CONCAT(EDW_PROD.G_WTFS_J_IP(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD),',',EDW_PROD.G_WTFS_J_PHONE(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)),EDW_PROD.G_WTFS_J_IP(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)),EDW_PROD.G_WTFS_J_PHONE(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD))                                   as IP_PHONE                            --                                    
                                   ,NVL(NVL(CONCAT(EDW_PROD.G_WTFS_J_MAC(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD),',',EDW_PROD.G_WTFS_J_IMEI(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)),EDW_PROD.G_WTFS_J_MAC(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)),EDW_PROD.G_WTFS_J_IMEI(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD))                                   as MAC                                 --                                    
                                   ,'GGQQ'                                as XTBS                                --GGQQ'                               
 FROM           GGQQCX.DATACENTER_TCGJYSQLS            t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1
 ON             t1.DMLX = 'YZYWFQF'
 AND            t1.YXT = 'GGQQ'
 AND            t1.YDM = CAST(t.FQF AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2
 ON             t2.DMLX = 'BZDM'
 AND            t2.YXT = 'GGQQ'
 AND            t2.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t4
 ON             t4.YXT = 'GGQQ'
 AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}' ;
-------------------------------插入个股期权数据结束---------------------
 
 -----------------------------插入融资融券数据开始-----------------------
 INSERT  INTO  EDW_PROD.T_EDW_T05_TCGJYSQLS(
                                     SEQNO                               --事件序号                               
                                   ,LSH                                 --流水号                                
                                   ,SQH                                 --申请号                                
                                   ,YZYWFQF                             --银证业务发起方                            
                                   ,KHH                                 --客户号                                
                                   ,YHDM                                --银行代码                               
                                   ,CGZH                                --存管帐户                               
                                   ,YHZH                                --银行帐号                               
                                   ,BZDM                                --币种代码                               
                                   ,XTYWDM                              --系统业务代码                             
                                   ,FSJE                                --发生金额                               
                                   ,FSYYB                               --发生营业部                              
                                   ,SQGY                                --申请柜员                               
                                   ,SQRQ                                --申请日期                               
                                   ,SQSJ                                --申请时间                               
                                   ,SQFS                                --申请方式                               
                                   ,CZZD                                --操作站点                               
                                   ,CLRQ                                --处理日期                               
                                   ,CLSJ                                --处理时间                               
                                   ,CLJG                                --处理结果                               
                                   ,BCZJYE                              --本次资金余额                             
                                   ,BDYWLSH                             --本地业务流水号                            
                                   ,CGCLJG                              --存管处理结果                             
                                   ,CGCLRQ                              --存管处理日期                             
                                   ,CGCLSJ                              --存管处理时间                             
                                   ,CGWBCLJG                            --存管外部处理结果                           
                                   ,WDH                                 --申请网点号                              
                                   ,WBJGGYDM                            --外部结构柜员代码                           
                                   ,WBLSH                               --外部流水号                              
                                   ,CXWBLSH                             --冲销外部流水号                            
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,CXSQH                               --冲销申请号                              
                                   ,CZCS                                --存折参数                               
                                   ,ZY                                  --摘要                                 
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,YWSQH                               --业务申请号                              
                                   ,SQCZRH                              --授权操作人号                             
                                   ,WBCLJG                              --外部处理结果                             
                                   ,CZZD1                               --操作终端                               
                                   ,IP_PHONE                            --IP地址/ 电话号码                         
                                   ,MAC                                 --MAC地址                              
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.SEQNO                               as SEQNO                               --序号                                  
                                   ,t.LSH                                 as LSH                                 --流水号                                 
                                   ,t.SQH                                 as SQH                                 --申请号                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.FQF AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YZYWFQF                             --发起方                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.YHDM                                as YHDM                                --银行代码                                
                                   ,t.CGZH                                as CGZH                                --存管帐户                                
                                   ,t.YHZH                                as YHZH                                --银行帐号                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as BZDM                                --币种                                  
                                   ,t.XTYWDM                              as XTYWDM                              --系统业务代码                              
                                   ,t.FSJE                                as FSJE                                --发生金额                                
                                   ,t.FSYYB                               as FSYYB                               --发生营业部                               
                                   ,t.SQGY                                as SQGY                                --申请柜员                                
                                   ,t.SQRQ                                as SQRQ                                --申请日期                                
                                   ,t.SQSJ                                as SQSJ                                --申请时间                                
                                   ,CAST( EDW_PROD.G_WTFS_J_WTFS(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD) AS DECIMAL(38,0) )                                  as SQFS                                --申请方式                                
                                   ,t.CZZD                                as CZZD                                --操作站点                                
                                   ,t.CLRQ                                as CLRQ                                --处理日期                                
                                   ,t.CLSJ                                as CLSJ                                --处理时间                                
                                   ,t.CLJG                                as CLJG                                --处理结果                                
                                   ,t.BCZJYE                              as BCZJYE                              --本次资金余额                              
                                   ,t.BDYWLSH                             as BDYWLSH                             --本地业务流水号                             
                                   ,t.CGCLJG                              as CGCLJG                              --存管处理结果                              
                                   ,t.CGCLRQ                              as CGCLRQ                              --存管处理日期                              
                                   ,t.CGCLSJ                              as CGCLSJ                              --存管处理时间                              
                                   ,t.CGWBCLJG                            as CGWBCLJG                            --存管外部处理结果                            
                                   ,t.WDH                                 as WDH                                 --申请网点号                               
                                   ,t.WBJGGYDM                            as WBJGGYDM                            --外部结构柜员代码                            
                                   ,t.WBLSH                               as WBLSH                               --外部流水号                               
                                   ,t.CXWBLSH                             as CXWBLSH                             --冲销外部流水号                             
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.CXSQH                               as CXSQH                               --冲销申请号                               
                                   ,t.CZCS                                as CZCS                                --存折参数                                
                                   ,t.ZY                                  as ZY                                  --摘要                                  
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.YWSQH                               as YWSQH                               --业务申请号                               
                                   ,t.SQCZRH                              as SQCZRH                              --授权操作人号                              
                                   ,t.WBCLJG                              as WBCLJG                              --外部处理结果                              
                                   ,EDW_PROD.G_WTFS_J_TERM(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)                                  as CZZD1                               --                                    
                                   ,NVL(NVL(CONCAT(EDW_PROD.G_WTFS_J_IP(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD),',',EDW_PROD.G_WTFS_J_PHONE(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)),EDW_PROD.G_WTFS_J_IP(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)),EDW_PROD.G_WTFS_J_PHONE(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD))                                   as IP_PHONE                            --                                    
                                   ,NVL(NVL(CONCAT(EDW_PROD.G_WTFS_J_MAC(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD),',',EDW_PROD.G_WTFS_J_IMEI(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)),EDW_PROD.G_WTFS_J_MAC(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD)),EDW_PROD.G_WTFS_J_IMEI(CAST(t.SQFS AS INT),0,t.FSYYB,t.SQGY,t.CZZD))                                   as MAC                                 --                                    
                                   ,'RZRQ'                                as XTBS                                --RZRQ'                               
 FROM           RZRQCX.DATACENTER_TCGJYSQLS     t  
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1
 ON             t1.DMLX = 'YZYWFQF'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.FQF AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2
 ON             t2.DMLX = 'BZDM'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t4
 ON             t4.YXT = 'RZRQ'
 AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}' ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TCGJYSQLS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_TCGJYSQLS;
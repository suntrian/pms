 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:基金委托表                                                                 */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 
/*      T_DDW_F05_PROD_ODR_DEL  修改为  T_DDW_F00_TRD_PROD_ODR_DEL_HIS                      */
	/* 修改人:梅杰                                                                               */
	/* 修改时间:2018-05-23                                                                        */ 

	

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_FND_ODR
(
			    BRH_NO                   --营业部编号 
               ,BRH_NAME                 --营业部名称 
               ,RPT_DT                   --申报日期  
               ,RPT_TM                   --申报时间  
               ,ODR_MOD                  --委托方式  
               ,CUST_NO                  --客户号   
               ,CUST_NAME                --客户姓名  
               ,RSK_BEAR_ABLTY           --风险承受能力
               ,BIZ_CGY                  --业务类别  
               ,PROD_CD                  --产品代码  
               ,PROD_NAME                --产品简称  
               ,PROD_RSK_LVL             --产品风险等级
               ,ODR_SHR                  --委托份额  
               ,ODR_AMT                  --委托金额  
               ,ABST                     --摘要    
               ,SECOND_CARD_VRFCTN       --二代证验证 
               ,SCRP_AGE                 --认购年龄
			   ,IF_OUT_RSK				 --是否超风险
			   ,FND_CO_NAME              --基金公司名称
			   ,APPRO_MTCHG              --适当性匹配
               ,WARNG_CNTT               --警示内容
			   ,HAND_brh_no              --办理营业部
) 
 PARTITION(bus_date)
 SELECT 
			 t.BRH_NO                       AS BRH_NO                   --营业部编号          
			,t.BRH_NAME                     AS BRH_NAME                 --营业部名称          
			,t.RPT_DT                       AS RPT_DT                   --申报日期           
			,t.RPT_TM                       AS RPT_TM                   --申报时间           
			,CASE WHEN t.ODR_MOD = 8
                  AND  a1.BRH_NO IS NULL
				  THEN '网上业务'
			      ELSE b1.ODR_MOD_NAME
				  END                       AS ODR_MOD                  --委托方式           
			,t.CUST_NO                      AS CUST_NO                  --客户号                    
			,t.CUST_NAME                    AS CUST_NAME                --客户姓名           
            ,b2.RSK_BEAR_ABLTY_NAME         AS RSK_BEAR_ABLTY           --风险承受能力         
            ,CASE WHEN t.ODR_CGY = 8
 			      THEN b3.YWMC
				  WHEN t.ODR_CGY = 9
				  THEN b5.JRCP_YWJC
				  end                       AS BIZ_CGY                  --业务类别           
            ,t.PROD_CD                      AS PROD_CD                  --产品代码           
            ,t.PROD_NAME                    AS PROD_NAME                --产品简称           
            ,b4.PROD_RSK_LVL_NAME           AS PROD_RSK_LVL             --产品风险等级         
            ,cast(t.ODR_SHR as DECIMAL(16,2))                      AS ODR_SHR                  --委托份额           
            ,cast(t.ODR_AMT as DECIMAL(16,2))                      AS ODR_AMT                  --委托金额           
            ,t.ABST                         AS ABST                     --摘要             
            ,t.SECOND_CARD_VRFCTN           AS SECOND_CARD_VRFCTN       --二代证验证          
            ,t.SCRP_AGE                     AS SCRP_AGE                 --认购年龄
			,case when 	t.PROD_BIZ_CD IN ('020','022','039')
				  and   b2.RSK_BEAR_ABLTY_TRANS < b4.PROD_RSK_LVL
				  then  '是' 
				  end  						AS IF_OUT_RSK				 --是否超风险
			,a3.TAJGJC	                    as FND_CO_NAME              --基金公司名称
            ,DECODE(a5.sdxppjg,0,'适当',CONCAT(DECODE(FLOOR(a5.sdxppjg/32),1,'即将退市个股风险警示',''),','
                   ,DECODE(FLOOR(MOD(a5.sdxppjg,32)/16),1,'券商特殊个股风险警示',''),','
	               ,DECODE(FLOOR(MOD(MOD(a5.sdxppjg,32),16)/8),1,'预期收益不匹配',''),','
	               ,DECODE(FLOOR(MOD(MOD(MOD(a5.sdxppjg,32),16),8)/4),1,'投资期限不匹配',''),','
	               ,DECODE(FLOOR(MOD(MOD(MOD(MOD(a5.sdxppjg,32),16),8),4)/2),1,'投资品种不匹配',''),','
	               ,DECODE(FLOOR(MOD(MOD(MOD(MOD(MOD(a5.sdxppjg,32),16),8),4),2)/1),1,'风险承受能力不匹配',''),','
                    ))                         as APPRO_MTCHG                --适当性匹配
			,a5.jsnr                           as WARNG_CNTT                 --警示内容
			,t.occ_brh_no                      as HAND_brh_no              --办理营业部
            ,t.BUS_DATE                        as BUS_DATE
  FROM  		    DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS        t
  LEFT JOIN         DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON                t.OCC_BRH_NO = a1.BRH_NO
  AND               a1.BUS_DATE = %d{yyyyMMdd} 
  LEFT JOIN 		DDW_PROD.V_ODR_MOD						b1
  ON				t.ODR_MOD = CAST(b1.ODR_MOD AS DECIMAL(38,0))
  LEFT JOIN 		(SELECT RSK_BEAR_ABLTY_NAME
							,RSK_BEAR_ABLTY
							,CASE WHEN RSK_BEAR_ABLTY IN ('11','12','1')
								  THEN '1'
								  WHEN RSK_BEAR_ABLTY IN ('13','6')
								  THEN '2'
								  WHEN RSK_BEAR_ABLTY IN ('14','2')
								  THEN '3'
								  WHEN RSK_BEAR_ABLTY IN ('15','3')
								  THEN '4'
								  WHEN RSK_BEAR_ABLTY IN ('16','4')
								  THEN '5'
							END 	AS   RSK_BEAR_ABLTY_TRANS
						    
					FROM DDW_PROD.V_RSK_BEAR_ABLTY	)		b2
  ON				t.RSK_BEAR_ABLTY = b2.RSK_BEAR_ABLTY
  LEFT JOIN 		EDW_PROD.T_EDW_T99_TOF_YWDM		        b3
  ON				t.PROD_BIZ_CD = b3.ywdm
  AND               t.ODR_CGY = 8
  AND               b3.bus_date = %d{yyyyMMdd}
  LEFT JOIN         EDW_PROD.T_EDW_T99_TJRCP_CPYWDM         b5
  ON				t.PROD_BIZ_CD = b5.JRCP_ywdm
  AND               t.ODR_CGY = 9
  AND               b5.bus_date = %d{yyyyMMdd}
  LEFT JOIN 		DDW_PROD.V_PROD_RSK_LVL 				b4
  ON				t.PROD_RSK_LVL = b4.PROD_RSK_LVL  
  LEFT JOIN         EDW_PROD.T_EDW_T03_TOF_TAXX              a3
  ON                t.TA_CD = a3.TADM
  AND               a3.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN         JZJYCX.DATACENTER_TKHBSDJYRZLS            a5
  ON                t.ODR_NO = a5.WTH
  AND               t.ODR_DT = a5.FSRQ
  AND               a5.JYS NOT IN ('SH','SZ','HB','SB','TA','TU','HK','SK')
  WHERE			    CAST(t.bus_date as STRING) BETWEEN EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,-20)  AND '%d{yyyyMMdd}'   
  AND               t.PROD_CD <> 'A30003' 
  AND               (t.ABST IS  NULL
  OR               t.ABST NOT LIKE '%现金宝业务批量自动触发参与%' ) 
  ;
-----------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_FND_ODR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_FND_ODR ;
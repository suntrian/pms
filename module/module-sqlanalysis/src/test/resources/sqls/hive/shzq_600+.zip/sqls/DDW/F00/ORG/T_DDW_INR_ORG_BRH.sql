------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:内部机构营业部表                                                                    */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
TRUNCATE TABLE DDW_PROD.T_DDW_INR_ORG_BRH ;
INSERT OVERWRITE DDW_PROD.T_DDW_INR_ORG_BRH
(                    BRH_NO              --营业部编号                       	
                    ,BRH_FULLNM          --营业部全称 
                    ,BRH_SHRTNM          --营业部简称 
                    ,BELTO_FILIL         --所属分公司 
					,BELTO_FILIL_CDG	 --所属分公司编码
                    ,BELTO_PROV          --所属省     
                    ,BELTO_CITY          --所属市     
                    ,CDG_PFX             --编码前缀   								                                   								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT   DISTINCT   t.MBJGDM           as BRH_NO              --营业部编号                          
                    ,t.MBJGQC           as BRH_FULLNM          --营业部全称 
                    ,t.MBJGJC           as BRH_SHRTNM          --营业部简称                                       						   
                    ,t.SSFGS            as BELTO_FILIL         --所属分公司
					,t.SSFGSBM			as BELTO_FILIL_CDG	   --所属分公司编码
                    ,t.SF               as BELTO_PROV          --所属省     
                    ,t.CS               as BELTO_CITY          --所属市     
                    ,t.BMQZ             as CDG_PFX             --编码前缀   	
 FROM           EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING                t       
 WHERE          t.JGLB = '3'
;		
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_INR_ORG_BRH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
       invalidate metadata DDW_PROD.T_DDW_INR_ORG_BRH ;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户信用合同信息表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 

---------插入数据开始-------------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TXY_HTXXLS
(
                                    RQ                                  --日期                                 
                                   ,HTBH                                --合同编号                               
                                   ,KHH                                 --客户号                                
                                   ,BZDM                                --币种代码                               
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,RZED                                --合同融资额度                             
                                   ,RQED                                --合同融券额度                             
                                   ,RZXYED                              --授信融资额度                             
                                   ,RQXYED                              --授信融券额度                             
                                   ,LLSRFS                              --利率输入方式                             
                                   ,XY_LLLX                             --信用利率类型                             
                                   ,RZLL                                --融资利率                               
                                   ,RQLL                                --融券利率                               
                                   ,RZJE                                --融资金额                               
                                   ,RQJE                                --融券金额                               
                                   ,DJRQ                                --登记日期                               
                                   ,BDRQ                                --变动日期                               
                                   ,RZXYLX                              --融资占用利息                             
                                   ,RQXYLX                              --融券占用利息                             
                                   ,RZYJLX                              --融资使用预计利息                           
                                   ,RQYJLX                              --融券使用预计利息                           
                                   ,KYBZJ                               --可用保证金                              
                                   ,ZZC                                 --总资产                                
                                   ,ZFZ                                 --总负债                                
                                   ,ZHYE                                --账户余额                               
                                   ,DBBL                                --维持担保比例                             
                                   ,DBSZ                                --担保市值                               
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期                               
                                   ,XJCE                                --追保资金                               
                                   ,KTZC                                --可提资产                               
                                   ,PCKZ                                --平仓到位                               
                                   ,SHDBSZ                              --上海担保证券市值                           
                                   ,SZDBSZ                              --深圳担保证券市值                           
                                   ,WGHQYJE                             --未过户权益金额                            
                                   ,WGHZQSZ                             --未过户证券市值                            
                                   ,ZSSZ                                --担保证券折算市值                           
                                   ,KQZJ                                --可取资金                               
                                   ,RQSYKYZJ                            --融券剩余可用资金                           
                                   ,JZC                                 --净资产                                
                                   ,RZZYBZJ                             --融资占用保证金                            
                                   ,RZLX                                --融资利息                               
                                   ,RZFZ                                --融资负债                               
                                   ,RZDQSZ                              --融资当前市值                             
                                   ,RZFY                                --融资浮盈                               
                                   ,RZFYZS                              --融资浮盈折算                             
                                   ,RZFK                                --融资浮亏                               
                                   ,RQZYBZJ                             --融券占用保证金                            
                                   ,RQLX                                --融券费用                               
                                   ,RQFZ                                --融券负债                               
                                   ,RQDQSZ                              --融券当前市值                             
                                   ,RQFY                                --融券浮盈                               
                                   ,RQFYZS                              --融券浮盈折算                             
                                   ,RQFK                                --融券浮亏                               
                                   ,HTSBH                               --合同书编号                              
                                   ,SHWBDBSZ                            --上海外部担保市值                           
                                   ,SHWBFDBSZ                           --上海外部非担保市值                          
                                   ,SZWBDBSZ                            --深圳外部担保市值                           
                                   ,SZWBFDBSZ                           --深圳外部非担保市值                          
                                   ,PGJE                                --配股金额                               
                                   ,XGSGSZ                              --新股申购市值                             
                                   ,ZZZCJZD                             --最大持仓站总资产集中度                        
                                   ,ZJZCJZD                             --最大持仓站净资产集中度 
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.RQ                                  as RQ                                  --日期                                  
                                   ,t.HTBH                                as HTBH                                --合同编号                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as BZDM                                --币种                                  
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.RZED                                as RZED                                --合同融资额度                              
                                   ,t.RQED                                as RQED                                --合同融券额度                              
                                   ,t.RZXYED                              as RZXYED                              --授信融资额度                              
                                   ,t.RQXYED                              as RQXYED                              --授信融券额度                              
                                   ,t.LLSRFS                              as LLSRFS                              --利率输入方式                              
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.LLLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as XY_LLLX                             --利率类型                                
                                   ,t.RZLL                                as RZLL                                --融资利率                                
                                   ,t.RQLL                                as RQLL                                --融券利率                                
                                   ,t.RZJE                                as RZJE                                --融资金额                                
                                   ,t.RQJE                                as RQJE                                --融券金额                                
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.RZXYLX                              as RZXYLX                              --融资占用利息                              
                                   ,t.RQXYLX                              as RQXYLX                              --融券占用利息                              
                                   ,t.RZYJLX                              as RZYJLX                              --融资使用预计利息                            
                                   ,t.RQYJLX                              as RQYJLX                              --融券使用预计利息                            
                                   ,t.KYBZJ                               as KYBZJ                               --可用保证金                               
                                   ,t.ZZC                                 as ZZC                                 --总资产                                 
                                   ,t.FZJE                                as ZFZ                                 --总负债                                 
                                   ,t.ZHYE                                as ZHYE                                --账户余额                                
                                   ,t.DBBL                                as DBBL                                --维持担保比例                              
                                   ,t.DBSZ                                as DBSZ                                --担保市值                                
                                   ,t.KSRQ                                as KSRQ                                --开始日期                                
                                   ,t.JSRQ                                as JSRQ                                --结束日期                                
                                   ,t.XJCE                                as XJCE                                --追保资金                                
                                   ,t.KTZC                                as KTZC                                --可提资产                                
                                   ,t.PCKZ                                as PCKZ                                --平仓到位                                
                                   ,t.SHDBSZ                              as SHDBSZ                              --上海担保证券市值                            
                                   ,t.SZDBSZ                              as SZDBSZ                              --深圳担保证券市值                            
                                   ,t.WGHQYJE                             as WGHQYJE                             --未过户权益金额                             
                                   ,t.WGHZQSZ                             as WGHZQSZ                             --未过户证券市值                             
                                   ,t.ZSSZ                                as ZSSZ                                --担保证券折算市值                            
                                   ,t.KQZJ                                as KQZJ                                --可取资金                                
                                   ,t.RQSYKYZJ                            as RQSYKYZJ                            --融券剩余可用资金                            
                                   ,t.JZC                                 as JZC                                 --净资产                                 
                                   ,t.RZZYBZJ                             as RZZYBZJ                             --融资占用保证金                             
                                   ,t.RZLX                                as RZLX                                --融资利息                                
                                   ,t.RZFZ                                as RZFZ                                --融资负债                                
                                   ,t.RZDQSZ                              as RZDQSZ                              --融资当前市值                              
                                   ,t.RZFY                                as RZFY                                --融资浮盈                                
                                   ,t.RZFYZS                              as RZFYZS                              --融资浮盈折算                              
                                   ,t.RZFK                                as RZFK                                --融资浮亏                                
                                   ,t.RQZYBZJ                             as RQZYBZJ                             --融券占用保证金                             
                                   ,t.RQLX                                as RQLX                                --融券费用                                
                                   ,t.RQFZ                                as RQFZ                                --融券负债                                
                                   ,t.RQDQSZ                              as RQDQSZ                              --融券当前市值                              
                                   ,t.RQFY                                as RQFY                                --融券浮盈                                
                                   ,t.RQFYZS                              as RQFYZS                              --融券浮盈折算                              
                                   ,t.RQFK                                as RQFK                                --融券浮亏                                
                                   ,t.HTSBH                               as HTSBH                               --合同书编号                               
                                   ,t.SHWBDBSZ                            as SHWBDBSZ                            --上海外部担保市值                            
                                   ,t.SHWBFDBSZ                           as SHWBFDBSZ                           --上海外部非担保市值                           
                                   ,t.SZWBDBSZ                            as SZWBDBSZ                            --深圳外部担保市值                            
                                   ,t.SZWBFDBSZ                           as SZWBFDBSZ                           --深圳外部非担保市值                           
                                   ,t.PGJE                                as PGJE                                --配股金额                                
                                   ,t.XGSGSZ                              as XGSGSZ                              --新股申购市值                              
                                   ,t.ZZZCJZD                             as ZZZCJZD                             --                                    
                                   ,t.ZJZCJZD                             as ZJZCJZD                             --     
                                   ,'RZRQ'		                          as XTBS						   
 FROM           RZRQCX.DATACENTER_TXY_HTXXLS t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'XY_LLLX'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.LLLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t3
 ON             t3.YXT = 'RZRQ'
 AND            t3.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---------插入数据结束--------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TXY_HTXXLS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TXY_HTXXLS;
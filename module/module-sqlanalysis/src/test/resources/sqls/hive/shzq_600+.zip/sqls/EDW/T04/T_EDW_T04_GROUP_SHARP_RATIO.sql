------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:组合夏普比率表                                                                    */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

 
 --清除数据
-- TRUNCATE TABLE EDW_PROD.T_EDW_T04_GROUP_SHARP_RATIO;
 
 ------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T04_GROUP_SHARP_RATIO
(
                GROUP_ID    --组合id
			   ,SHARP_RATIO --夏普比率
			   ,UPDATE_TIME 
 ) partition(BUS_DATE = %d{yyyyMMdd})
SELECT     
                GROUP_ID    --组合id
			   ,SHARP_RATIO --夏普比率
			   ,UPDATE_TIME 
FROM JJLC.GROUP_SHARP_RATIO
WHERE DT = '%d{yyyyMMdd}'
;
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_GROUP_SHARP_RATIO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
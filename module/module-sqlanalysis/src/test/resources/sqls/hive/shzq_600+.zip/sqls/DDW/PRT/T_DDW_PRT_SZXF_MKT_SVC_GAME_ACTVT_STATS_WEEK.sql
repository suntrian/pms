------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能: 上证先锋—2019年“争先创优”营销服务竞赛活动统计周表                                                                 */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP;
CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP as
SELECT t.CUST_NO
FROM 
(SELECT KHH as CUST_NO  FROM newcrm.DSC_STAT_T_STAT_KHZC_R
WHERE DT BETWEEN '20160101' AND '20161231'
AND  ZZC > 0 
UNION 
SELECT CUST_NO
FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
WHERE BUS_DATE BETWEEN 20170101 AND 20181231
AND   TOT_AST > 0
)   t
GROUP BY t.CUST_NO ;
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP1;
CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP1 as
 SELECT  a.TYEAR_WHICH_WEEK
        ,a.TRD_DT_WEEK_MIN
        ,a.TRD_DT_WEEK_MAX
		,CASE WHEN b.NUM IS NULL
	         THEN a.TRD_DT_WEEK_MIN
			 ELSE b.TRD_DT_WEEK_MIN
			 END     as LAST_TRD_DT_WEEK_MIN
	   ,CASE WHEN b.NUM IS NULL
	         THEN a.TRD_DT_WEEK_MIN
			 ELSE b.TRD_DT_WEEK_MAX
			 END     as LAST_TRD_DT_WEEK_MAX
 FROM 		
 (SELECT  a.TRD_DT_WEEK_MIN
        ,a.TRD_DT_WEEK_MAX
		,ROW_NUMBER() OVER(ORDER BY TYEAR_WHICH_WEEK ) as NUM
		,a.TYEAR_WHICH_WEEK
 FROM 
 (SELECT MIN(TRD_DT)    as TRD_DT_WEEK_MIN 
        ,MAX(TRD_DT)   as TRD_DT_WEEK_MAX 
		,TYEAR_WHICH_WEEK
 FROM  EDW_PROD.T_EDW_T99_TRD_DATE
 WHERE NAT_DT BETWEEN 20190101 AND 20191231
 AND   BUS_DATE = %d{yyyyMMdd}
  AND   TRD_DT = NAT_DT
 GROUP BY TYEAR_WHICH_WEEK
 )  a
 ) a
 LEFT JOIN
 (SELECT  a.TRD_DT_WEEK_MIN
        ,a.TRD_DT_WEEK_MAX
		,ROW_NUMBER() OVER(ORDER BY TYEAR_WHICH_WEEK )+1 as NUM
 FROM 
 (SELECT MIN(TRD_DT)    as TRD_DT_WEEK_MIN 
        ,MAX(TRD_DT)   as TRD_DT_WEEK_MAX 
		,TYEAR_WHICH_WEEK
 FROM  EDW_PROD.T_EDW_T99_TRD_DATE
 WHERE NAT_DT BETWEEN 20190101 AND 20191231
 AND   BUS_DATE = %d{yyyyMMdd}
  AND   TRD_DT = NAT_DT
 GROUP BY TYEAR_WHICH_WEEK
 )  a
 ) b 
 on a.NUM = b.NUM ;

  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP2;
 CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP2 as
 SELECT       t.BRH_NO              
             ,t.CUST_NO
			 ,CASE WHEN t.CUST_RSK_LVL IN ('0','1','2','8','19')
			       THEN '合格客户'
				   ELSE '-'
				   END  as IF_QLFD
			 ,NVL(MIN_BUS_DATE,99999999) as MIN_BUS_DATE
			 ,NVL(MIN_BUS_DATE_50,99999999) as MIN_BUS_DATE_50
             ,NVL(a2.FNL_AST,0) as FNL_AST
             ,NVL(a3.NET_TOT_AST,0)  as STRT_AST
             ,NVL(a4.NET_TOT_AST,0)  as LAST_Y_FNL_AST	
             ,CASE WHEN a5.CUST_NO IS NULL
			       AND NVL(t.ORDI_OPNAC_DT,99999999) BETWEEN 20160101 AND 20181231
                   THEN '存量客户'
                   ELSE '-'
                   END  as IF_CLKH
             ,NVL(t.ORDI_OPNAC_DT,99999999)	 as ORDI_OPNAC_DT	
             ,a6.tyear_which_week
             ,a6.trd_dt_week_min	
             ,a6.trd_dt_week_MAX			 
 FROM        (SELECT *,1 as ID FROM   DDW_PROD.T_DDW_F00_CUST_CUST_INFO WHERE BUS_DATE = %d{yyyyMMdd})   t
 INNER JOIN    DDW_PROD.T_DDW_INR_ORG_BRH           a1
 ON            t.BRH_NO = a1.BRH_NO
 AND           a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN    (SELECT CUST_NO
                     ,MIN(CASE WHEN NET_TOT_AST > = 1000
					           THEN BUS_DATE 
						       ELSE 99999999
						       END
						 ) as MIN_BUS_DATE
					 ,MIN(CASE WHEN NET_TOT_AST > = 500000
					           THEN BUS_DATE 
						       ELSE 99999999
						       END
						 ) as MIN_BUS_DATE_50
                     ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},NET_TOT_AST,0)) FNL_AST
               FROM   DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
               WHERE  SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)			  
			   GROUP BY CUST_NO 
			  )                                 a2
 ON         t.CUST_NO = a2.CUST_NO
 LEFT JOIN ( SELECT CUST_NO,NET_TOT_AST,a.BUS_DATE
             FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY a
             WHERE a.BUS_DATE IN (SELECT 	LAST_TRD_DT_WEEK_MAX 
			                      FROM DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP1
			                      WHERE %d{yyyyMMdd} BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX
			                     )
				
	       )     a3
 ON          t.CUST_NO = a3.CUST_NO
  LEFT JOIN ( SELECT CUST_NO,NET_TOT_AST,a.BUS_DATE
             FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY a
             WHERE  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                                    FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                       WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,4) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4)
			                       AND BUS_DATE = %d{yyyyMMdd}
				                   )  b
                     WHERE  a.BUS_DATE = b.MON_START
				      )
	    AND  SUBSTR(CAST(a.BUS_DATE as STRING),1,4) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4)
	  )     a4
 ON          t.CUST_NO = a4.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP a5
 ON           t.CUST_NO = a5.CUST_NO
 LEFT JOIN (SELECT 	* ,1 as ID
			FROM DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP1
			WHERE %d{yyyyMMdd} BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX 
			)  a6
 ON  t.ID = a6.ID
 WHERE            t.CUST_NO < > '100610335855'
 ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP3;
 CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP3 as
 SELECT 
         BRH_NO
		,SUM(CASE WHEN ORDI_OPNAC_DT BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX
		          AND  IF_QLFD = '合格客户'
			      THEN 1
				  ELSE 0
			      END 
             )    as OPNAC_QLFD_CUST_VOL
        ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND  IF_QLFD = '合格客户'
			      THEN 1
				  ELSE 0
			      END 
             )    as TISSU_GT_OPNAC_QLFD_CUST_VOL	
       ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND MIN_BUS_DATE BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX			 
			      THEN 1
				  ELSE 0
			      END 
             )    as TADDED_VLD_CUST_VOL
        ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND SUBSTR(CAST(MIN_BUS_DATE as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
			      THEN 1
				  ELSE 0
			      END 
             )    as TISSU_GT_TADDED_VLD_CUST_VOL
      ,SUM(CASE WHEN IF_CLKH = '存量客户'
		          AND MIN_BUS_DATE BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX				 
			      THEN 1
				  ELSE 0
			      END 
             )    as STOCK_ACTVT_CUST_VOL
        ,SUM(CASE WHEN IF_CLKH = '存量客户'
		          AND SUBSTR(CAST(MIN_BUS_DATE as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
			      THEN 1
				  ELSE 0
			      END 
             )    as TISSU_GT_STOCK_ACTVT_CUST_VOL	

      ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND MIN_BUS_DATE BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX					 
			      THEN FNL_AST
				  ELSE 0
			      END 
             )    as ADDED_AST_S1
        ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND SUBSTR(CAST(MIN_BUS_DATE as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
			      THEN FNL_AST
				  ELSE 0
			      END 
             )    as ADDED_AST_S2

       ,SUM(CASE WHEN   IF_QLFD = '合格客户'
			      THEN FNL_AST-STRT_AST
				  ELSE 0
			      END 
             )    as ADDED_AST_S5
        ,SUM(CASE WHEN  IF_QLFD = '合格客户'
			      THEN FNL_AST-LAST_Y_FNL_AST
				  ELSE 0
			      END 
             )    as ADDED_AST_S6
		,SUM(CASE WHEN  LAST_Y_FNL_AST >= 500000
			      THEN 1
				  ELSE 0
			      END 
             )    as HIGHT_CUST_S1
		,SUM(CASE WHEN  FNL_AST >= 500000
			      THEN 1
				  ELSE 0
			      END 
             )    as HIGHT_CUST_S2 
		 ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND MIN_BUS_DATE_50 BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX				 
			      THEN 1
				  ELSE 0
			      END 
             )    as HIGHT_CUST_S4
        ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND SUBSTR(CAST(MIN_BUS_DATE_50 as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
			      THEN 1
				  ELSE 0
			      END 
             )    as HIGHT_CUST_S5
 FROM   DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP2  t
 GROUP BY  t.BRH_NO ;
 
 
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP4;
 CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP4 as
 SELECT       t.BRH_NO
              ,SUM(CASE WHEN t.OPN_PRVL = 20
			            AND t.OPN_DT BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX
					    THEN 1
					    ELSE 0
					    END
				   )          as STIB_S1
			  ,SUM(CASE WHEN t.OPN_PRVL = 20
			            AND  SUBSTR(CAST(t.OPN_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
					    THEN 1
					    ELSE 0
					    END
				   )          as STIB_S2
			  ,SUM(CASE WHEN t.OPN_PRVL = 1
			            AND t.OPN_DT BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX
					    THEN 1
					    ELSE 0
					    END
				   )          as OPN_H_K_PRVL_CUST_VOL
			  ,SUM(CASE WHEN t.OPN_PRVL = 1
			            AND  SUBSTR(CAST(t.OPN_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
					    THEN 1
					    ELSE 0
					    END
				   )          as TISSU_GT_OPN_H_K_PRVL_CUST_VOL
 FROM        (SELECT  BRH_NO
                     ,CUST_NO
                     ,OPN_PRVL 					 
                     ,MIN(b.TRD_DT) as OPN_DT
                     ,1 as ID					 
              FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL a
			  LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE  b
              ON        a.OPN_DT = b.NAT_DT
              AND       b.BUS_DATE = %d{yyyyMMdd}			  
			  WHERE  (OPN_PRVL = 20 
			  OR (EXG IN ('HK','SK')
			  AND   OPN_PRVL = 1))
               AND   a.BUS_DATE = %d{yyyyMMdd}
              GROUP BY 	BRH_NO,CUST_NO,OPN_PRVL		  
              )t
 INNER JOIN    DDW_PROD.T_DDW_INR_ORG_BRH           a1
 ON            t.BRH_NO = a1.BRH_NO
 AND           a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN (SELECT 	* ,1 as ID
			FROM DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP1
			WHERE %d{yyyyMMdd} BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX 
			)  a2
 ON  t.ID = a2.ID
 WHERE t.OPN_DT < = %d{yyyyMMdd}
 GROUP BY t.BRH_NO ;
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP5;
  CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP5 as
  SELECT      t.BRH_NO
              ,SUM(CASE WHEN t.SYS_SRC IN ('信用账户')
			            AND t.OPNAC_DT BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX
					    THEN 1
					    ELSE 0
					    END
				   )          as OPNAC_CRD_CUST_VOL
			  ,SUM(CASE WHEN t.SYS_SRC IN ('信用账户')
			            AND  SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
					    THEN 1
					    ELSE 0
					    END
				   )          as TISSU_GT_OPNAC_CRD_CUST_VOL
			  ,SUM(CASE WHEN t.SYS_SRC IN ('期权账户')
			            AND t.OPNAC_DT BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX
					    THEN 1
					    ELSE 0
					    END
				   )          as OPNAC_WRNT_CUST_VOL
			  ,SUM(CASE WHEN t.SYS_SRC IN ('期权账户')
			            AND  SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
					    THEN 1
					    ELSE 0
					    END
				   )          as TISSU_GT_OPNAC_WRNT_CUST_VOL
  FROM         (SELECT CUST_NO
                      ,BRH_NO
					  ,MIN(NVL(OPNAC_DT,99999999))   as OPNAC_DT
                      ,MAX(NVL(CNCLACT_DT,99999999)) as CNCLACT_DT
					  ,MIN(DECODE(CPTL_ACCNT_STAT,'0','0','3','3','0'))  as CPTL_ACCNT_STAT
                      ,1 as ID
                      ,SYS_SRC					  
               FROM DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
			   WHERE SYS_SRC IN ('信用账户','期权账户')
			   AND   BUS_DATE = %d{yyyyMMdd}
			   GROUP BY CUST_NO,BRH_NO,SYS_SRC
               )			   t
 INNER JOIN    DDW_PROD.T_DDW_INR_ORG_BRH           a1
 ON            t.BRH_NO = a1.BRH_NO
 AND           a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN (SELECT 	* ,1 as ID
			FROM DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP1
			WHERE %d{yyyyMMdd} BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX 
			)  a2
 ON  t.ID = a2.ID
 WHERE         t.CUST_NO < > '100610335855'
 GROUP BY t.BRH_NO ;
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP6;
 CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP6 as
 SELECT a.TRD_DT,b.TRD_DT as TRD_DT_20,c.TRD_DT as TRD_DT_21
 FROM 
 (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC )  as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND      TRD_DT < = %d{yyyyMMdd}
  AND       BUS_DATE = %d{yyyyMMdd}
 )  a
 LEFT JOIN 
  (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT  DESC )-19  as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND       TRD_DT < = %d{yyyyMMdd}
  AND       BUS_DATE = %d{yyyyMMdd}
 )   b
 ON  a.NUM = b.NUM
 LEFT JOIN 
  (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT  DESC )-20  as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND      TRD_DT < = %d{yyyyMMdd}
  AND       BUS_DATE = %d{yyyyMMdd}
 )   c
 ON  a.NUM = c.NUM ;
 
     DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP7;
 CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP7 as
 SELECT       t.BRH_NO
              ,t.CUST_NO
			  ,t.opn_dt
			  ,a2.trd_dt_20
			  ,a2.trd_dt_21
			  ,a4.bus_date_min
			  ,a4.bus_date_max
			 -- ,a3.NET_TOT_AST
 FROM        (SELECT  BRH_NO
                     ,CUST_NO 
                     ,MIN(b.TRD_DT) as OPN_DT					 
              FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL a
			  LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE  b
              ON        a.OPN_DT = b.NAT_DT
              AND       b.BUS_DATE = %d{yyyyMMdd}			  
			  WHERE  OPN_PRVL = 20
               AND   a.BUS_DATE = %d{yyyyMMdd}
              GROUP BY 	BRH_NO,CUST_NO		  
              )t
 INNER JOIN    DDW_PROD.T_DDW_INR_ORG_BRH           a1
 ON            t.BRH_NO = a1.BRH_NO
 AND           a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP6 a2
 ON           t.OPN_DT = a2.trd_dt
 --LEFT JOIN   DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY a3
 --ON          t.CUST_NO = a3.cust_no
 --and         a2.trd_dt_21 = a3.BUS_DATE
 LEFT JOIN (SELECT  CUST_NO
                   ,MIN(BUS_DATE) as BUS_DATE_MIN
                   ,MAX(BUS_DATE) AS BUS_DATE_MAX
             FROM DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS
			 WHERE SUBSTR(BIZ_SBJ,1,3) = '101'
			 AND INCM_AMT > 0
			 AND  BUS_DATE >= 20190101
			 GROUP BY CUST_NO
			 )    a4
ON      t.CUST_NO = a4.CUST_NO
WHERE  a4.BUS_DATE_MIN is not null
AND    t.OPN_DT < = %d{yyyyMMdd}
and    ((a4.BUS_DATE_MIN between a2.trd_dt_20 and t.opn_dt) 
OR     (a4.BUS_DATE_MAX between a2.trd_dt_20 and t.opn_dt)) ;

   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP8;
 CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP8 as
 SELECT a1.brh_no
       ,SUM(CASE WHEN a1.opn_dt  BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX
	             THEN 1
			     ELSE 0
			     END) as STIB_S5
	   ,SUM(CASE WHEN SUBSTR(cast(a1.opn_dt AS string),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
	             THEN 1
			     ELSE 0
			     END) as STIB_S6
 FROM (SELECT *,1 as ID FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY) t
 INNER JOIN DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP7 a1
 ON        t.CUST_NO = a1.cust_no
 and       t.bus_date = a1.trd_dt_21
LEFT JOIN (SELECT 	* ,1 as ID
			FROM DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP1
			WHERE %d{yyyyMMdd} BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX 
			)  a2
 ON  t.ID = a2.ID
 WHERE    t.net_tot_ast <  500000
 group by a1.BRH_NO ;
 
 

  

 

 
 
 
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK
(
  BELTO_FILIL_CDG                            --分公司编码
, BELTO_FILIL                                --分公司名称
, BRH_NO                                     --营业部编码
, BRH_FULLNM                                 --营业部名称
,OPNAC_QLFD_CUST_VOL                         --新增合格客户数
,TISSU_GT_OPNAC_QLFD_CUST_VOL				 --本年累计新增合格客户数
,TADDED_VLD_CUST_VOL                         --新增有效客户数
,TISSU_GT_TADDED_VLD_CUST_VOL				 --本年累计新增有效客户数
,STOCK_ACTVT_CUST_VOL                        --存量客户激活
,TISSU_GT_STOCK_ACTVT_CUST_VOL               --本年累计存量客户激活
,ADDED_AST_S1                                --新增客户引进资产当期数
,ADDED_AST_S2                                --新增客户引进资产本年累计
,ADDED_AST_S3                                --存量客户新引进资产当期数
,ADDED_AST_S4                                --存量客户新引进资产本年累计数
,ADDED_AST_S5                                --当期合计新增资产
,ADDED_AST_S6                                --本年累计合计新增资产
,HIGHT_CUST_S1                               --新引进高端客户数上年期末数
,HIGHT_CUST_S2                               --新引进高端客户数当期期末数
,HIGHT_CUST_S3                               --新引进高端客户数增长率
,HIGHT_CUST_S4                               --新引进高端客户数当期新增数
,HIGHT_CUST_S5                               --新引进高端客户数本年新增累计数
,STIB_S1                                     --科创板当期
,STIB_S2                                     --科创板本年累计
,STIB_S3                                     --科创板存量客户当期
,STIB_S4                                     --科创板存量客户本年累计
,STIB_S5                                     --科创板增量客户当期
,STIB_S6                                     --科创板增量客户本年累计
,OPN_H_K_PRVL_CUST_VOL                       --港股通当期
,TISSU_GT_OPN_H_K_PRVL_CUST_VOL              --港股通本年累计
,OPNAC_CRD_CUST_VOL                          --两融当期
,TISSU_GT_OPNAC_CRD_CUST_VOL                 --两融本年累计
,OPNAC_WRNT_CUST_VOL                         --股票期权当期
,TISSU_GT_OPNAC_WRNT_CUST_VOL                --股票期权本年累计
,OPNAC_IB_CUST_VOL                           --IB业务当期
,TISSU_GT_OPNAC_IB_CUST_VOL                  --IB业务本年累计
,PROD_S1                                     --公募基金当期
,PROD_S2                                     --公募基金本年累计
,PROD_S3                                     --公司资管产品当期
,PROD_S4                                     --公司资管产品本年累计  
,trd_dt_week_min     
,trd_dt_week_max         
 ) PARTITION(WEEK)
SELECT    t.BELTO_FILIL_CDG                             --分公司编码
        , t.BELTO_FILIL                                --分公司名称
        , t.BRH_NO                                     --营业部编码
        , t.BRH_FULLNM                                 --营业部名称
        ,NVL(a1.OPNAC_QLFD_CUST_VOL,0)                         --新增合格客户数
        ,NVL(a1.TISSU_GT_OPNAC_QLFD_CUST_VOL,0)				 --本年累计新增合格客户数
        ,NVL(a1.TADDED_VLD_CUST_VOL,0)                         --新增有效客户数
        ,NVL(a1.TISSU_GT_TADDED_VLD_CUST_VOL,0)				 --本年累计新增有效客户数
        ,NVL(a1.STOCK_ACTVT_CUST_VOL,0)                        --存量客户激活
        ,NVL(a1.TISSU_GT_STOCK_ACTVT_CUST_VOL,0)               --本年累计存量客户激活
        ,NVL(a1.ADDED_AST_S1,0)                                --新增客户引进资产当期数
        ,NVL(a1.ADDED_AST_S2,0)                                --新增客户引进资产本年累计
        ,NVL(a1.ADDED_AST_S5,0)- NVL(a1.ADDED_AST_S1,0)                               --存量客户新引进资产当期数
        ,NVL(a1.ADDED_AST_S6,0)- NVL(a1.ADDED_AST_S2,0)                              --存量客户新引进资产本年累计数
        ,NVL(a1.ADDED_AST_S5,0)                                --当期合计新增资产
        ,NVL(a1.ADDED_AST_S6,0)                                --本年累计合计新增资产
        ,NVL(a1.HIGHT_CUST_S1,0)                               --新引进高端客户数上年期末数
        ,NVL(a1.HIGHT_CUST_S2,0)                               --新引进高端客户数当期期末数
        ,CAST(round(NVL(a1.HIGHT_CUST_S2,0)*1.0000/NVL(a1.HIGHT_CUST_S1,0),4) as DECIMAL(38,4))                              --新引进高端客户数增长率
        ,NVL(a1.HIGHT_CUST_S4,0)                               --新引进高端客户数当期新增数
        ,NVL(a1.HIGHT_CUST_S5,0)                               --新引进高端客户数本年新增累计数
        ,NVL(a2.STIB_S1,0)                                     --科创板当期
        ,NVL(a2.STIB_S2,0)                                     --科创板本年累计
        ,NVL(a2.STIB_S1,0)- NVL(a4.STIB_S5,0)                                    --科创板存量客户当期
        ,NVL(a2.STIB_S2,0)-  NVL(a4.STIB_S6,0)                                   --科创板存量客户本年累计
        ,NVL(a4.STIB_S5,0)                                     --科创板增量客户当期
		,NVL(a4.STIB_S6,0)                                     --科创板增量客户本年累计
        ,NVL(a2.OPN_H_K_PRVL_CUST_VOL,0)                       --港股通当期
        ,NVL(a2.TISSU_GT_OPN_H_K_PRVL_CUST_VOL,0)              --港股通本年累计
        ,NVL(a3.OPNAC_CRD_CUST_VOL,0)                          --两融当期
        ,NVL(a3.TISSU_GT_OPNAC_CRD_CUST_VOL,0)                 --两融本年累计
        ,NVL(a3.OPNAC_WRNT_CUST_VOL,0)                         --股票期权当期
        ,NVL(a3.TISSU_GT_OPNAC_WRNT_CUST_VOL,0)                --股票期权本年累计
        ,0                           --IB业务当期
        ,0                  --IB业务本年累计
        ,0                                     --公募基金当期
        ,0                                     --公募基金本年累计
        ,0                                     --公司资管产品当期
        ,0                                     --公司资管产品本年累计
		,trd_dt_week_min     
		,trd_dt_week_max
		,CONCAT('2019','.',CAST(tyear_which_week as STRING))
 FROM (SELECT *,1 as ID 
       FROM  DDW_PROD.T_DDW_INR_ORG_BRH  
       WHERE BUS_DATE = %d{yyyyMMdd}
	   )t
LEFT JOIN DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP3 a1
ON        t.BRH_NO = a1.BRH_NO
LEFT JOIN DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP4 a2
ON        t.BRH_NO = a2.BRH_NO
LEFT JOIN DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP5 a3
ON        t.BRH_NO = a3.BRH_NO
LEFT JOIN DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP8 a4
ON        t.BRH_NO = a4.BRH_NO
LEFT JOIN (SELECT 	* ,1 as ID
			FROM DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP1
			WHERE %d{yyyyMMdd} BETWEEN TRD_DT_WEEK_MIN AND TRD_DT_WEEK_MAX 
			)  a5
 ON  t.ID = a5.ID
 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP1;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP2;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP3;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP4;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP5;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP6;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP7;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK_TEMP8;

 ---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_WEEK ; 
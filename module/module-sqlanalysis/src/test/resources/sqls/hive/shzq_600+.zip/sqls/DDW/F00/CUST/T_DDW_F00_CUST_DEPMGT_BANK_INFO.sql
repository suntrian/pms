 --/* ***************************************** SQL Begin *****************************************  */
  --/* 脚本功能:客户存管银行信息表                                                                  */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2016-11-02                                                                        */ 
  

--------插入------
 INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_DEPMGT_BANK_INFO
(              BANK_CD                         --银行代码                  
              ,BANK_ACTNO                      --银行帐号        
              ,CCY_CD                          --币种代码        
              ,CUST_NO                         --客户号          
              ,CUST_NAME                       --客户姓名        
              ,DEPMGT_BANK_CGY                 --存管银行类别    
              ,DEPMGT_ACCNT                    --存管帐户        
              ,CPTL_ACTNO                      --柜台资金帐号    
              ,REGST_DT                        --登记日期        
              ,ACCNT_BANK_ACTNO_RLN_STAT       --账户银行账号状态
              ,BRH_NO                          --营业部
              ,BRH_NAME                        --营业部名称			  
              ,SYS_SRC                         --系统来源 								  								
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT                         t.YHDM	                                                             as BANK_CD                         --银行代码           
                               ,t.YHZH	                                                             as BANK_ACTNO                      --银行帐号        
                               ,t.BZDM	                                                             as CCY_CD                          --币种代码        
							   ,t.KHH	                                                             as CUST_NO                         --客户号          
                               ,t.KHXM	                                                             as CUST_NAME                       --客户姓名        
                               ,t.CGYHLB	                                                         as DEPMGT_BANK_CGY                 --存管银行类别    
                               ,t.CGZH	                                                             as DEPMGT_ACCNT                    --存管帐户        
                               ,t.GTZJZH	                                                         as CPTL_ACTNO                      --柜台资金帐号    
                               ,t.DJRQ	                                                             as REGST_DT                        --登记日期        
                               ,t.ZH_YHZHGXZT                                                        as ACCNT_BANK_ACTNO_RLN_STAT       --账户银行账号状态
                               ,t.YYB	                                                             as BRH_NO                          --营业部                   								 
                               ,NVL(a2.BRH_SHRTNM,a3.FILIL_DEPT_SHRTNM)                                                          as BRH_NAME                        --营业部名称			
                               ,DECODE(t.XTBS,'JZJY','普通账户','GGQQ','期权账户','RZRQ','信用账户') as SYS_SRC                         --系统来源 			
 FROM          EDW_PROD.T_EDW_T02_TCGZHDY    t
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH    a2
 ON             t.YYB = a2.BRH_NO   
 AND           a2.BUS_DATE = %d{yyyyMMdd} 
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a3
 ON            t.YYB = a3.FILIL_DEPT_CDG
 AND           a3.BUS_DATE = %d{yyyyMMdd}
 WHERE         t.bus_date = %d{yyyyMMdd}
 UNION ALL
  SELECT                        t.YHDM	                  as BANK_CD                         --银行代码           
                               ,t.YHZH	                  as BANK_ACTNO                      --银行帐号        
                               ,t.BZDM	                  as CCY_CD                          --币种代码        
							   ,t.KHH	                  as CUST_NO                         --客户号          
                               ,a1.KHXM	                  as CUST_NAME                       --客户姓名        
                               ,NULL	                  as DEPMGT_BANK_CGY                 --存管银行类别    
                               ,NULL	                  as DEPMGT_ACCNT                    --存管帐户        
                               ,t.GTZJZH	              as CPTL_ACTNO                      --柜台资金帐号    
                               ,t.DJRQ	                  as REGST_DT                        --登记日期        
                               ,t.ZH_YHZHGXZT             as ACCNT_BANK_ACTNO_RLN_STAT       --账户银行账号状态
                               ,a1.YYB	                  as BRH_NO                          --营业部                   								 
                               ,NVL(a2.BRH_SHRTNM,a3.FILIL_DEPT_SHRTNM)               as BRH_NAME                        --营业部名称			
                               ,'普通账户'                as SYS_SRC                         --系统来源 			
 FROM          EDW_PROD.T_EDW_T02_TYZZZDY    t
 LEFT JOIN     EDW_PROD.T_EDW_T01_TKHXX      a1
 ON            t.KHH = a1.KHH
 AND           t.BUS_DATE = a1.BUS_DATE
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH    a2
 ON            a1.YYB = a2.BRH_NO   
 AND           a2.BUS_DATE = %d{yyyyMMdd} 
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a3
 ON            a1.YYB = a3.FILIL_DEPT_CDG
 AND           a3.BUS_DATE = %d{yyyyMMdd}
 WHERE         t.bus_date = %d{yyyyMMdd}
  	  ;
		
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_DEPMGT_BANK_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_DEPMGT_BANK_INFO ;
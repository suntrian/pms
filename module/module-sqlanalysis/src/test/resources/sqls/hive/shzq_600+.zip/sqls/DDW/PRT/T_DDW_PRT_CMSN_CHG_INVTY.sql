 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:佣金变动清单表                                                                      */
  /* 创建人:程骏                                                                               */
  /* 创建时间:2017-09-15                                                                        */ 
   /*  T_DDW_F05_BIZ_SYS_TRD_OPE_DETAIL  修改为  T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS */
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CMSN_CHG_INVTY_TEMP1;
--创建临时表
 CREATE TABLE DDW_PROD.T_DDW_PRT_CMSN_CHG_INVTY_TEMP1
 as
 select T.KHH,ROUND((s1*1.00000/cjje),5) as rct_tm_s1_rate
 from (select khh,s1,cjje,bus_date,row_number() over(partition by khh order by bus_date desc) AS NUM
 from edw_prod.t_edw_t05_tjgmxls
 where wtlb in (1,2,61,62,63,64)
 AND JYS IN ('SH','SZ')
 AND SUBSTR(ZQLB,1,1) IN ('A','C')
AND S1>5
AND  XTBS = 'JZJY'
AND  BUS_DATE < = %d{yyyyMMdd}
 ) T ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CMSN_CHG_INVTY_TEMP2;
--创建临时表
 CREATE TABLE DDW_PROD.T_DDW_PRT_CMSN_CHG_INVTY_TEMP2
 as
 select T.KHH,ROUND((s1*1.00000/cjje),5) as rct_tm_s1_rate
 from (select khh,s1,cjje,bus_date,row_number() over(partition by khh order by bus_date desc) AS NUM
 from edw_prod.t_edw_t05_tjgmxls
 where wtlb in (1,2,61,62,63,64)
 AND JYS IN ('SH','SZ')
 AND SUBSTR(ZQLB,1,1) IN ('A','C')
AND S1>5
AND  XTBS = 'RZRQ'
AND  BUS_DATE < = %d{yyyyMMdd}
 ) T ;
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CMSN_CHG_INVTY
(        
								 BRH_NO				--营业部编号    
								 ,BRH_NAME			--营业部名称    
								 ,CUST_NO			--客户号    
								 ,CUST_NAME			--客户姓名
								 ,CMSN_SETUP_DT		--佣金设置日期    
								 ,ABST				--摘要
								 ,SYS_CGY			--系统类别
								 ,STAT				--状态
                                ,rct_tm_s1_rate								 
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
					 t.BRH_NO				--营业部编号
					 ,t.BRH_NAME			--营业部名称
					 ,t.CUST_NO				--客户号          
					 ,t.CUST_NAME			--客户姓名        
					 ,t.DT					--佣金设置日期           
					 ,t.ABST         	    --摘要
					 ,case when 			--系统类别
						t.SYS_SRC = 'JZJY' 
						THEN 'ABOSS' 
						ELSE 'RZRQ'	end				
					 ,case when 			--状态
						a1.rownum_tm = 1
						THEN '正常' 
						ELSE '历史'	end	
                    ,NVL(a2.rct_tm_s1_rate,a3.rct_tm_s1_rate)						
  FROM           DDW_PROD.T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS        t
  LEFT JOIN ( SELECT  t.CUST_NO
		             ,t.TM,t.bus_date
	 	             ,t.dt
					 ,t.ABST
		    ,row_number() over(partition by t.cust_no,t.bus_date order by t.TM DESC) as rownum_tm 
	        FROM (SELECT  DISTINCT CUST_NO,tm,bus_date,dt,abst  
		          FROM     DDW_PROD.T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS  
		          WHERE    BIZ_SBJ =  '30599' AND (ABST like('%佣金%')  or ABST like('%对象复核%'))
				  AND      BUS_DATE = %d{yyyyMMdd}
				  )	t
           ) a1 
  ON    t.CUST_NO = a1.CUST_NO 
  AND   t.tm = a1.tm 
  AND   t.bus_date = a1.bus_date 
  left join DDW_PROD.T_DDW_PRT_CMSN_CHG_INVTY_TEMP1 a2
  ON         t.CUST_NO = a2.KHH
  AND        t.SYS_SRC = 'JZJY'
  left join DDW_PROD.T_DDW_PRT_CMSN_CHG_INVTY_TEMP2 a3
  ON         t.CUST_NO = a3.KHH
  AND        t.SYS_SRC = 'RZRQ'
  WHERE 		 t.bus_date = %d{yyyyMMdd}
  AND t.BIZ_SBJ =  '30599' 
  AND (t.ABST like('%佣金%')  or t.ABST like('%对象复核%'))   
  ;
  ------结束----
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CMSN_CHG_INVTY_TEMP1;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CMSN_CHG_INVTY_TEMP2;
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_CMSN_CHG_INVTY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_CMSN_CHG_INVTY ;
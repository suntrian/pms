 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:营业部存管银行余额表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2019-11-11                                                                        */ 
  -----今天银行余额
  
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY_TEMP ;
CREATE TABLE  DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY_TEMP as
SELECT a.YYB as BRH_NO ,b.YHDM as BANK_CD,SUM(a.ZHYE) as BAL_DAY
FROM EDW_PROD.T_EDW_T02_TZJZH a
LEFT JOIN (SELECT  YHDM
                   ,GTZJZH 
           FROM  EDW_PROD.T_EDW_T02_TCGZHDY 
           WHERE BZDM = 'RMB'
           AND    XTBS = 'JZJY'
           AND BUS_DATE = %d{yyyyMMdd}
           GROUP BY YHDM,GTZJZH
           )                  b
ON      a.GTZJZH = b.GTZJZH
WHERE   a.XTBS = 'JZJY'
AND     a.BUS_DATE = %d{yyyyMMdd}
AND     a.BZDM = 'RMB'
AND     b.GTZJZH IS NOT NULL
GROUP BY  BRH_NO,BANK_CD ;
----昨日账户余额
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY_TEMP1 ;
CREATE TABLE  DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY_TEMP1 as
SELECT a.YYB as BRH_NO ,b.YHDM as BANK_CD,SUM(a.ZHYE) as BAL_LASTDAY
FROM EDW_PROD.T_EDW_T02_TZJZH a
INNER JOIN EDW_PROD.T_EDW_T99_TRD_DATE c
ON         a.BUS_DATE = c.LST_TRD_D
AND        c.TRD_DT = %d{yyyyMMdd}
AND        c.BUS_DATE = %d{yyyyMMdd}
AND        c.TRD_DT = c.NAT_DT
LEFT JOIN (SELECT  YHDM
                   ,GTZJZH 
           FROM  EDW_PROD.T_EDW_T02_TCGZHDY 
           WHERE BZDM = 'RMB'
           AND    XTBS = 'JZJY'
           AND BUS_DATE = %d{yyyyMMdd}
           GROUP BY YHDM,GTZJZH
           )                  b
ON      a.GTZJZH = b.GTZJZH
WHERE   a.XTBS = 'JZJY'
AND     a.BZDM = 'RMB'
AND     b.GTZJZH IS NOT NULL
GROUP BY  BRH_NO,BANK_CD ;
-----今天银行存取
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY_TEMP2 ;
CREATE TABLE  DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY_TEMP2 as
SELECT    b.YYB as BRH_NO
         ,a.YHDM as BANK_CD
		 ,SUM(DECODE(a.XTYWDM,1,a.FSJE,0)) as DEPIN_BAL
		 ,SUM(DECODE(a.XTYWDM,2,a.FSJE,0)) as RECV_BAL
FROM      EDW_PROD.T_EDW_T05_TCGJYSQLS a
LEFT JOIN EDW_PROD.T_EDW_T01_TKHXX     b
ON        a.KHH = b.KHH
AND       b.BUS_DATE = %d{yyyyMMdd}
WHERE a.XTBS = 'JZJY'
AND   a.SQRQ = %d{yyyyMMdd}
AND   a.CLJG = 111
AND   a.BZDM = 'RMB'
GROUP BY  BRH_NO,BANK_CD ;
 ------插入数据
 INSERT OVERWRITE DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY
(
               BELTO_FILIL_CDG               --分公司编码
             , BELTO_FILIL                   --分公司名称
             , BRH_NO                        --营业部编码
             , BRH_FULLNM                    --营业部名称
			 , BANK_CD                       --银行代码
			 , BANK_NAME                     --银行名称
			 , BAL_LASTDAY                   --上日余额
             , BAL_DAY                       --当日余额
			 , DEPIN_BAL                     --当日存入余额
			 , RECV_BAL                      --当日取出余额         
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT    t.BELTO_FILIL_CDG                --分公司编码
          ,t.BELTO_FILIL                    --分公司名称
          ,t.BRH_NO                         --营业部编码
          ,t.BRH_FULLNM                     --营业部名称
		  ,a1.WBJGDM                        --银行代码
		  ,a1.WBJGMC                        --银行名称
		  ,NVL(a3.BAL_LASTDAY,0)            --上日余额
          ,NVL(a2.BAL_DAY,0)                --当日余额
		  ,NVL(a4.DEPIN_BAL,0)              --当日存入余额
		  ,NVL(a4.RECV_BAL,0)               --当日取出余额 
 FROM 	(SELECT 1 as ID,* 
         FROM DDW_PROD.T_DDW_INR_ORG_BRH
		 WHERE BUS_DATE = %d{yyyyMMdd}
		 )   t		
 LEFT JOIN (SELECT 1 as ID
                   ,WBJGDM
				   ,WBJGMC
            FROM EDW_PROD.T_EDW_T03_TWBJGDM
			WHERE XTBS = 'JZJY'
			AND   BUS_DATE = %d{yyyyMMdd}
			GROUP BY  ID
			         ,WBJGDM
				     ,WBJGMC
             )     a1	
ON    t.ID = a1.ID	
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY_TEMP a2
ON 		  t.BRH_NO = a2.BRH_NO
AND       a1.WBJGDM = a2.BANK_CD
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY_TEMP1 a3
ON 		  t.BRH_NO = a3.BRH_NO
AND       a1.WBJGDM = a3.BANK_CD
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY_TEMP2 a4
ON 		  t.BRH_NO = a4.BRH_NO
AND       a1.WBJGDM = a4.BANK_CD ;
-------------删除临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY_TEMP ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY_TEMP1 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY_TEMP2 ;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
INVALIDATE METADATA DDW_PROD.T_DDW_F20_BRH_NO_DEPMGT_BANK_BAL_DAY;
------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户非交易资产汇总日表                                                                  */
------/* 创建人:黄勇华   2020-01-13                                                                 */ 
  
 


------插入数据
  INSERT OVERWRITE DDW_PROD.T_DDW_F10_AST_CUST_UN_TRD_AST_AGGR_DAY
(        CUST_NO                                        --客户号                 
       , BRH_NO                                         --营业部编号                         
       , CUST_CGY                                       --客户类别
       , UN_CIR_MKTVAL                                  --非流通市值
       , UN_TRD_TOT_AST                                 --非交易总资产
       , UN_TRD_NET_TOT_AST                             --非交易净资产
       , FZN_TOT_AST                                    --冻结总资产
       , FZN_NET_TOT_AST	                            --冻结净资产   
 ) partition(BUS_DATE = %d{yyyyMMdd})
 SELECT     a4.CUST_NO                                        --客户号                 
          , a4.BRH_NO                                         --营业部编号                         
          , a4.CUST_CGY                                       --客户类别
          , NVL(t.ORDI_UN_CIR_MKTVAL,0)                            --非流通市值
          , NVL(a1.TOT_AST,0)                                 --非交易总资产
          , NVL(a1.NET_TOT_AST,0)                             --非交易净资产
          , NVL(a2.FZN_MKTVAL,0)                              --冻结总资产
          , NVL(a2.FZN_MKTVAL,0)- NVL(a3.ORDI_GL,0)	          --冻结净资产 
FROM  (SELECT CUST_NO,ORDI_UN_CIR_MKTVAL
         FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
		 WHERE ORDI_UN_CIR_MKTVAL > 0
		 AND   BUS_DATE = %d{yyyyMMdd}
	  )  t
FULL JOIN (SELECT CUST_NO,NET_TOT_AST,TOT_AST
           FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
		   WHERE  BUS_DATE = %d{yyyyMMdd}
		   AND CUST_NO  IN (SELECT KHH FROM EDW_PROD.T_EDW_T01_TKHXX WHERE BUS_DATE = %d{yyyyMMdd} AND (KHQC LIKE '上海国际集团%' OR KHQC LIKE '上海国际信托%' OR KHQC LIKE '%上国投%' OR KHH = '100311120576'))
		   AND CUST_NO NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL WHERE BUS_DATE = %d{yyyyMMdd} AND CUST_CGY = '2' )
		 ) a1
ON  t.CUST_NO = a1.CUST_NO
FULL JOIN ( SELECT a.CUST_NO
                  ,SUM(NVL(ROUND((b.NEWST_PRC+b.NEWST_INT*b.NETPRC_TRD_FLG)*b.TRD_UNIT*a.FZN_QTY,2),0)) as FZN_MKTVAL
            FROM (SELECT CUST_NO
                        ,FZN_QTY
			            ,EXG
			            ,SEC_CD 
                  FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
                  WHERE BUS_DATE = %d{yyyyMMdd}
                  AND   FZN_QTY > 0
                  ) a
            LEFT JOIN (SELECT    CD
                                ,EXG
                                ,TRD_UNIT
                                ,NETPRC_TRD_FLG
                                ,NEWST_INT
                                ,NEWST_PRC					
		               FROM DDW_PROD.T_DDW_PUB_QOT 
		               WHERE BUS_DATE = %d{yyyyMMdd} 
		               AND TRD_MKT  = 1
		             )            b
            ON a.EXG = b.EXG
            AND a.SEC_CD = b.CD
            GROUP BY a.CUST_NO
          ) a2
ON  NVL(t.CUST_NO,a1.CUST_NO) = a2.CUST_NO	
FULL JOIN ( SELECT CUST_NO
                  ,ORDI_GL
            FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
			WHERE BUS_DATE = %d{yyyyMMdd}
			AND   ORDI_GL > 0 
          ) a3
ON  COALESCE(t.CUST_NO,a1.CUST_NO,a2.CUST_NO) = a3.CUST_NO
INNER JOIN DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL a4
ON  COALESCE(t.CUST_NO,a1.CUST_NO,a2.CUST_NO,a3.CUST_NO) = a4.CUST_NO
AND a4.BUS_DATE = %d{yyyyMMdd}
;
-----------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_AST_CUST_UN_TRD_AST_AGGR_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F10_AST_CUST_UN_TRD_AST_AGGR_DAY;
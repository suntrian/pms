 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:风险警示与退市整理开通信息表                                                                       */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 
/*  T_DDW_F05_CIF_CUST_OPE_DETAIL	修改为	T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS  */

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_RSK_WARNG_DLSTG_UP_OPN_INFO
(
				BRH_NO           				--营业部编号
               ,BRH_NAME         				--营业部名称
               ,CUST_NO          				--客户号  
               ,CUST_NAME        				--客户姓名 
               ,OPN_DT           				--开通日期 
               ,CGY              				--类别   
               ,ABST             				--摘要 
               ,RSK_BEAR_ABLTY       --风险承受能力	
               ,FSTTM_TRD_DT         --首次交易日期 			   
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
						 t.BRH_NO     		AS  BRH_NO           --营业部编号      
						,t.BRH_NAME   		AS  BRH_NAME         --营业部名称      
						,t.CUST_NO    		AS  CUST_NO          --客户号        
						,t.CUST_NAME  		AS  CUST_NAME        --客户姓名       
						,t.DT         		AS  OPN_DT           --开通日期       
						,CASE WHEN t.ABST LIKE '%风险警示%' AND t.ABST NOT LIKE '%退市整理%'
						      THEN '风险警示'
						      WHEN t.ABST LIKE '%退市整理%' AND t.ABST NOT LIKE '%风险警示%'
						      THEN '退市整理'
						      ELSE '风险警示_退市整理' 
						      END  		    AS  CGY              --类别         
						,t.ABST  	       	AS  ABST             --摘要         
			            ,b3.RSK_BEAR_ABLTY_NAME    AS  RSK_BEAR_ABLTY       --风险承受能力
                        ,a2.FSTTM_TRD_DT 	   as  FSTTM_TRD_DT         --首次交易日期			
  FROM  		DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS              	t  
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO                           	a1
  ON            t.CUST_NO = a1.CUST_NO
  AND           a1.BUS_DATE =   %d{yyyyMMdd}
  LEFT JOIN     	DDW_PROD.V_RSK_BEAR_ABLTY                          	  b3
  ON            	a1.RSK_BEAR_ABLTY = b3.RSK_BEAR_ABLTY
  LEFT JOIN    (select cust_no,min(FSTTM_TRD_DT) as FSTTM_TRD_DT from DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO group by cust_no)                            a2
  ON            t.CUST_NO = a2.CUST_NO
  WHERE			t.bus_date = %d{yyyyMMdd}
  AND           t.OPRT_MOD = '临柜'
  AND           t.BIZ_SBJ IN ('20201','20240','20241','21279')
  AND          (t.ABST like '%退市整理%' or t.ABST like '%风险警示%' or t.ABST like '%退市警示%')
  ;
 
-----------------------------加载结束--------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_RSK_WARNG_DLSTG_UP_OPN_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_RSK_WARNG_DLSTG_UP_OPN_INFO; 
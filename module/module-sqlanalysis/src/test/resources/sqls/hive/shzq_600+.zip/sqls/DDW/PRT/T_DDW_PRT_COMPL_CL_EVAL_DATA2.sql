 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:合规分类评价数据(其他)表2                                                                       */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2019-02-18                                                                        */ 

  --新开客户数(经纪业务,融资融券,个股期权,非现场开户数)
   DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP as
  SELECT     t.BRH_NO,t.BRH_SHRTNM as BRH_NAME,t.BELTO_FILIL_CDG
             ,SUM(CASE WHEN SUBSTR(CAST(a1.ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
			           AND  a1.CUST_RSK_LVL IN ('0','1','2','8','19')
                       THEN 1
				       ELSE 0
				       END)  as BROK_CUST_ADDED_ACTA --新增经纪客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(a2.OPNAC_DT,0) as STRING),1,4) = SUBSTR('20181228',1,4)			       
                       THEN 1
				       ELSE 0
				       END)       as CRD_CUST_ADDED_ACTA --新增信用客户数	
             ,SUM(CASE WHEN a1.WRNT_OPNAC_DT IS NOT NULL
			           AND  a1.WRNT_CUST_STAT < > '3'
                       THEN 1
				       ELSE 0
				       END)  as WRNT_CUST_FNL_ACTA --期末期权客户数
			 ,SUM(CASE WHEN SUBSTR(CAST(NVL(a1.WRNT_OPNAC_DT,0) as STRING),1,4) = SUBSTR('20181228',1,4)			       
                       THEN 1
				       ELSE 0
				       END) 	 as WRNT_CUST_ADDED_ACTA --新增期权客户数
              ,SUM(CASE WHEN SUBSTR(CAST(a1.ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
			           AND  a1.OPNAC_MOD IN ('2','4')
                       THEN 1
				       ELSE 0
				       END)  as WTNS_ADDED_OPN_ACTA --新增经见证开户数
              ,SUM(CASE WHEN SUBSTR(CAST(a1.ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
			           AND  a1.OPNAC_MOD IN ('3')
                       THEN 1
				       ELSE 0
				       END)  as ONLN_ADDED_OPN_ACTA --新增网上开户数					   
  FROM       DDW_PROD.T_DDW_INR_ORG_BRH  t
  LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO  a1
  ON        t.BRH_NO = a1.BRH_NO
  AND       a1.BUS_DATE = 20181228
  LEFT JOIN (SELECT  CUST_NO
                    ,MIN(OPNAC_DT) as OPNAC_DT  
             FROM  DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
			 WHERE  BUS_DATE = 20181228
			 AND    SYS_SRC  = '信用账户'
			 GROUP BY CUST_NO
			 )      a2
  ON       a1.CUST_NO = a2.CUST_NO 
  GROUP BY t.BRH_NO,t.BRH_SHRTNM ,t.BELTO_FILIL_CDG;
 
 ---普通账户主资金账户数
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP1;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP1 as
 SELECT     a1.BRH_NO
            ,SUM(DECODE(NVL(t.MAIN_ACCNT_FLG,0),1,1,0)) as ORDI_ACCNT_MAIN_CPTL_FNL_ACTA  --普通账户主资金期末账户数 
            ,SUM(CASE WHEN NVL(t.MAIN_ACCNT_FLG,0) = 1
                      AND  SUBSTR(CAST(NVL(t.OPNAC_DT,0) as STRING),1,4) = SUBSTR('20181228',1,4)
                      THEN 1
                      ELSE 0
                      END
				)	as ORDI_ACCNT_MAIN_CPTL_ADDED_ACTA  --普通账户主资金新增账户数 			  
 FROM       DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS  t
 INNER JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO    a1
 ON         t.CUST_NO = a1.CUST_NO
 AND        a1.BUS_DATE = 20181228
 AND        a1.CUST_RSK_LVL IN ('0','1','2','8','19')
 AND        a1.ORDI_CUST_STAT < > '3'
 WHERE  t.BUS_DATE = 20181228
 AND    t.CCY_CD = 'RMB'
 AND    t.SYS_SRC  = '普通账户'
 AND    t.CPTL_ACCNT_STAT < > '3' 
 AND    t.BRH_NO < > '4444'
 GROUP BY  a1.BRH_NO ;
--港股通
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP2;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP2 as
 SELECT  t.BRH_NO 
         ,SUM(CASE WHEN t.EXG = 'HK'
		           AND  t.SHRHLD_STAT < > '3'
			       THEN 1
			       ELSE 0
			       END)   as FNL_SHRHLD_NUM_HK  --期末沪港通股东数
		 ,SUM(CASE WHEN t.EXG = 'HK'
		           AND  SUBSTR(CAST(NVL(t.SHRHLD_OPNAC_DT,0) as STRING),1,4) = SUBSTR('20181228',1,4)
			       THEN 1
			       ELSE 0
			       END)   as ADDED_SHRHLD_NUM_HK --新增沪港通股东数
		 ,SUM(CASE WHEN t.EXG = 'SK'
		           AND  t.SHRHLD_STAT < > '3'
			       THEN 1
			       ELSE 0
			       END)   as FNL_SHRHLD_NUM_SK --期末深港通股东数
		 ,SUM(CASE WHEN t.EXG = 'SK'
		           AND  SUBSTR(CAST(NVL(t.SHRHLD_OPNAC_DT,0) as STRING),1,4) = SUBSTR('20181228',1,4)
			       THEN 1
			       ELSE 0
			       END)   as ADDED_SHRHLD_NUM_SK --新增深港通股东数
        
FROM    DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO t
WHERE   t.BUS_DATE = 20181228
GROUP BY t.BRH_NO ;
----业务权限开通
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP3;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP3 as
 SELECT t.BRH_NO
        ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.OPN_DT,0) as STRING),1,4) = SUBSTR('20181228',1,4)
		          AND  t.OPN_PRVL = 102
                  THEN 1
                  ELSE 0
                  END
             )     as PROMS_RPHS_ADDED_ACTA            --约定购回新增客户数		
       ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.OPN_DT,0) as STRING),1,4) = SUBSTR('20181228',1,4)
		          AND  t.OPN_PRVL IN (106)
                  THEN 1
                  ELSE 0
                  END
             )     as STK_PLG_ADDED_ACTA               --股票质新增押客户数	
        ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.OPN_DT,0) as STRING),1,4) = SUBSTR('20181228',1,4)
		          AND  t.OPN_PRVL IN (110)
                  THEN 1
                  ELSE 0
                  END
             )     as MAIN_STK_PLG_ADDED_ACTA               --小微贷股票质新增押客户数	
         ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.OPN_DT,0) as STRING),1,4) = SUBSTR('20181228',1,4)
		          AND  t.OPN_PRVL IN (6)
                  THEN 1
                  ELSE 0
                  END
             )     as NEW_T3BOD_ADDED_ACTA               --新三板新增押客户数					 
 FROM
 (SELECT  CUST_NO
         ,EXG
		 ,OPN_PRVL
		 ,SHRHLD_NO
		 ,BRH_NO
		 ,MIN(OPN_DT) as OPN_DT  
		 ,MAX(CHG_DT) as CHG_DT
 FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL 
 WHERE BUS_DATE = 20181228
 GROUP BY CUST_NO,EXG,OPN_PRVL,SHRHLD_NO,BRH_NO
 )  t
 GROUP BY t.BRH_NO ;

--新开产品账户
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP4;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP4 as
 SELECT t.YYB as BRH_NO
        ,COUNT(1) as ADDED_PROD_ACTA   --新增产品账户数
 FROM 
(SELECT YYB,1
FROM   EDW_PROD.T_EDW_T02_TOF_JJZH
WHERE  BUS_DATE = 20190219
AND    SUBSTR(CAST(NVL(KHRQ,0) as STRING),1,4) = SUBSTR('20181228',1,4) 
UNION ALL
SELECT YYB,1
FROM   EDW_PROD.T_EDW_T02_TJRCP_CPZH 
WHERE  BUS_DATE = 20190219
AND    SUBSTR(CAST(NVL(KHRQ,0) as STRING),1,4) = SUBSTR('20181228',1,4) ) t
GROUP BY BRH_NO ;


-- 手机相同 
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP5;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP5 as
SELECT BRH_NO,NVL(COUNT(DISTINCT PHONE),0) as COMMON_PHONE_PHONE_NUM --相同手机数
,NVL(COUNT(1),0) as COMMON_PHONE_CUST_ACTA --相同手机客户数
FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
WHERE BUS_DATE = 20181228
AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
AND    PHONE IS NOT NULL 
AND  PHONE IN 
(SELECT PHONE
 FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
 WHERE BUS_DATE = 20181228
 AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
 AND    PHONE IS NOT NULL 
 GROUP BY PHONE
 HAVING COUNT(1) > 1
)   
 GROUP BY BRH_NO ;
-- 电话数相同 
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP6;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP6 as
SELECT BRH_NO,NVL(COUNT(DISTINCT CTCT_TEL),0) as COMMON_CTCT_TEL_NUM --相同电话数
,NVL(COUNT(1),0) as COMMON_CTCT_TEL_CUST_ACTA --相同电话客户数
FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
WHERE BUS_DATE = 20181228
AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
AND    CTCT_TEL IS NOT NULL
 AND     LENGTH(TRIM(CTCT_TEL)) > 0
AND  CTCT_TEL IN 
(SELECT CTCT_TEL
 FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
 WHERE BUS_DATE = 20181228
 AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
 AND    CTCT_TEL IS NOT NULL
 AND     LENGTH(TRIM(CTCT_TEL)) > 0
 GROUP BY CTCT_TEL
 HAVING COUNT(1) > 1
)   
 GROUP BY BRH_NO ;
---地址相同
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP7;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP7 as
SELECT BRH_NO,NVL(COUNT(DISTINCT CTCT_ADDR),0) as COMMON_CTCT_ADDR_NUM --相同地址数
   ,NVL(COUNT(1),0) as COMMON_CTCT_ADDR_CUST_ACTA --相同地址客户数
FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
WHERE BUS_DATE = 20181228
AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
AND    CTCT_ADDR IS NOT NULL
AND  CTCT_ADDR IN 
(SELECT CTCT_ADDR
 FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
 WHERE BUS_DATE = 20181228
 AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
 AND    CTCT_ADDR IS NOT NULL
 GROUP BY CTCT_ADDR
 HAVING COUNT(1) > 1
)   
 GROUP BY BRH_NO ; 
 
 ----
 -- 三项相同
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP8;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP8 as
SELECT t.BRH_NO,COUNT(DISTINCT t.CUST_NO) as COMMON_SUM_CUST_ACTA --合计相同客户数
FROM 
(SELECT BRH_NO,CUST_NO
FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
WHERE BUS_DATE = 20181228
AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
AND    PHONE IS NOT NULL 
AND  PHONE IN 
(SELECT PHONE
 FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
 WHERE BUS_DATE = 20181228
 AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
 AND    PHONE IS NOT NULL 
 GROUP BY PHONE
 HAVING COUNT(1) > 1
)   
 UNION 
SELECT BRH_NO,CUST_NO
FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
WHERE BUS_DATE = 20181228
AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
AND    CTCT_TEL IS NOT NULL
 AND     LENGTH(TRIM(CTCT_TEL)) > 0
AND  CTCT_TEL IN 
(SELECT CTCT_TEL
 FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
 WHERE BUS_DATE = 20181228
 AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
 AND    CTCT_TEL IS NOT NULL
 AND     LENGTH(TRIM(CTCT_TEL)) > 0
 GROUP BY CTCT_TEL
 HAVING COUNT(1) > 1
)   
 UNION 
SELECT BRH_NO,CUST_NO
FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
WHERE BUS_DATE = 20181228
AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
AND    CTCT_ADDR IS NOT NULL
AND  CTCT_ADDR IN 
(SELECT CTCT_ADDR
 FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
 WHERE BUS_DATE = 20181228
 AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
 AND    CTCT_ADDR IS NOT NULL
 GROUP BY CTCT_ADDR
 HAVING COUNT(1) > 1
)   
)   t
GROUP BY t.BRH_NO ;
------多银行客户 
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP9;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP9 as
 SELECT t.BRH_NO
       ,COUNT( DISTINCT t.CUST_NO)  as MLT_BANK_FNL_CUST_ACTA --多银行期末客户数
	   ,COUNT(ID)                   as MLT_BANK_FNL_BANK_ACTA --多银行期末银行账户数
	 --  ,COUNT( DISTINCT t.CUST_NO1)
	   ,SUM(ID1)                    as MLT_BANK_ADDED_BANK_ACTA --多银行新增银行账户数
FROM 
 (SELECT t.BRH_NO
        ,t.CUST_NO
        ,1 as ID
		,CASE WHEN SUBSTR(CAST(a2.ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
              THEN t.CUST_NO
              ELSE NULL
              END as CUST_NO1
			   	
       ,CASE WHEN SUBSTR(CAST(a2.ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
                  THEN 1
                  ELSE 0
                  END	 as ID1		   
 FROM   DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS   t
 LEFT JOIN (SELECT  CUST_NO 
             FROM   DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
             WHERE  BUS_DATE = 20181228
			 AND    MAIN_ACCNT_FLG = 0
             AND    CCY_CD = 'RMB' 
			 AND   OPNAC_DT < CAST(CONCAT(SUBSTR('20181228',1,4),'0101') as INT)
            )    a1	
 ON     t.CUST_NO = a1.CUST_NO	
 LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO    a2
 ON         t.CUST_NO = a2.CUST_NO
 AND        a2.BUS_DATE = 20181228  
 WHERE  t.BUS_DATE = 20181228
 AND    t.MAIN_ACCNT_FLG = 0
 AND    t.CCY_CD = 'RMB'
 AND   SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4) 
 AND   a1.CUST_NO IS NULL
 
 )    t
GROUP BY t.BRH_NO
ORDER BY t.BRH_NO ;
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP10;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP10 as 
 
  SELECT t.BRH_NO
       
	   ,COUNT( DISTINCT t.CUST_NO1)  as MLT_BANK_ADDED_CUST_ACTA --多银行新增客户数
FROM 
 (SELECT t.BRH_NO
        ,t.CUST_NO
        ,1 as ID
		,CASE WHEN SUBSTR(CAST(a2.ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
              THEN t.CUST_NO
              ELSE NULL
              END as CUST_NO1
			   	
       ,CASE WHEN SUBSTR(CAST(a2.ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4)
                  THEN 1
                  ELSE 0
                  END	 as ID1		   
 FROM   DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS   t
 LEFT JOIN (SELECT  CUST_NO 
             FROM   DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
             WHERE  BUS_DATE = 20181228
			 AND    MAIN_ACCNT_FLG = 0
             AND    CCY_CD = 'RMB' 
			 AND   OPNAC_DT < CAST(CONCAT(SUBSTR('20181228',1,4),'0101') as INT)
            )    a1	
 ON     t.CUST_NO = a1.CUST_NO	
 LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO    a2
 ON         t.CUST_NO = a2.CUST_NO
 AND        a2.BUS_DATE = 20181228  
 WHERE  t.BUS_DATE = 20181228
 AND    t.MAIN_ACCNT_FLG = 0
 AND    t.CCY_CD = 'RMB'
 AND   SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) = SUBSTR('20181228',1,4) 
 AND   a1.CUST_NO IS NULL
 
 )    t
GROUP BY t.BRH_NO
ORDER BY t.BRH_NO ;
 
 
 
 
   
 
 
  
  INSERT OVERWRITE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2
 (
     BRH_NO                               --营业部
	,BRH_NAME                             --营业部名称
	,BELTO_FILIL_CDG                      --地区
    ,BROK_CUST_ADDED_ACTA                 --新增经纪客户数	
    ,CRD_CUST_ADDED_ACTA                  --新增信用客户数	
    ,WRNT_CUST_FNL_ACTA                   --期末期权客户数
	,WRNT_CUST_ADDED_ACTA                 --新增期权客户数
    ,WTNS_ADDED_OPN_ACTA                  --新增经见证开户数
    ,ONLN_ADDED_OPN_ACTA                  --新增网上开户数					   
    ,ORDI_ACCNT_MAIN_CPTL_FNL_ACTA        --普通账户主资金期末账户数 
    ,ORDI_ACCNT_MAIN_CPTL_ADDED_ACTA      --普通账户主资金新增账户数 			  
    ,FNL_SHRHLD_NUM_HK                    --期末沪港通股东数
	,ADDED_SHRHLD_NUM_HK                  --新增沪港通股东数
	,FNL_SHRHLD_NUM_SK                    --期末深港通股东数
	,ADDED_SHRHLD_NUM_SK                  --新增深港通股东数
    ,PROMS_RPHS_ADDED_ACTA                --约定购回新增客户数		
    ,STK_PLG_ADDED_ACTA                   --股票质新增押客户数	
    ,MAIN_STK_PLG_ADDED_ACTA              --小微贷股票质新增押客户数	
    ,NEW_T3BOD_ADDED_ACTA                 --新三板新增押客户数					 
    ,ADDED_PROD_ACTA                      --新增产品账户数
    ,COMMON_PHONE_PHONE_NUM               --相同手机数
    ,COMMON_PHONE_CUST_ACTA               --相同手机客户数
    ,COMMON_CTCT_TEL_NUM                  --相同电话数
    ,COMMON_CTCT_TEL_CUST_ACTA            --相同电话客户数
    ,COMMON_CTCT_ADDR_NUM                 --相同地址数
    ,COMMON_CTCT_ADDR_CUST_ACTA           --相同地址客户数
    ,COMMON_SUM_CUST_ACTA                 --合计相同客户数
    ,MLT_BANK_FNL_CUST_ACTA               --多银行期末客户数
    ,MLT_BANK_FNL_BANK_ACTA               --多银行期末银行账户数
    ,MLT_BANK_ADDED_BANK_ACTA             --多银行新增银行账户数
    ,MLT_BANK_ADDED_CUST_ACTA             --多银行新增客户数
                                
 )  PARTITION(YEAR = CAST(SUBSTR('20181228',1,4) as INT))
 
 SELECT     t.BRH_NO                               --营业部
	       ,t.BRH_NAME                             --营业部名称
	       ,t.BELTO_FILIL_CDG                      --地区
           ,t.BROK_CUST_ADDED_ACTA                 --新增经纪客户数	
           ,t.CRD_CUST_ADDED_ACTA                  --新增信用客户数	
           ,t.WRNT_CUST_FNL_ACTA                   --期末期权客户数
	       ,t.WRNT_CUST_ADDED_ACTA                 --新增期权客户数
           ,t.WTNS_ADDED_OPN_ACTA                  --新增经见证开户数
           ,t.ONLN_ADDED_OPN_ACTA                  --新增网上开户数					   
           ,NVL(a1.ORDI_ACCNT_MAIN_CPTL_FNL_ACTA,0)        --普通账户主资金期末账户数 
           ,NVL(a1.ORDI_ACCNT_MAIN_CPTL_ADDED_ACTA,0)      --普通账户主资金新增账户数 			  
           ,NVL(a2.FNL_SHRHLD_NUM_HK,0)                    --期末沪港通股东数
	       ,NVL(a2.ADDED_SHRHLD_NUM_HK,0)                  --新增沪港通股东数
	       ,NVL(a2.FNL_SHRHLD_NUM_SK,0)                    --期末深港通股东数
	       ,NVL(a2.ADDED_SHRHLD_NUM_SK,0)                  --新增深港通股东数
           ,NVL(a3.PROMS_RPHS_ADDED_ACTA,0)                --约定购回新增客户数		
           ,NVL(a3.STK_PLG_ADDED_ACTA,0)                   --股票质新增押客户数	
           ,NVL(a3.MAIN_STK_PLG_ADDED_ACTA,0)              --小微贷股票质新增押客户数	
           ,NVL(a3.NEW_T3BOD_ADDED_ACTA,0)                 --新三板新增押客户数					 
           ,NVL(a4.ADDED_PROD_ACTA,0)                      --新增产品账户数
           ,NVL(a5.COMMON_PHONE_PHONE_NUM,0)               --相同手机数
           ,NVL(a5.COMMON_PHONE_CUST_ACTA,0)               --相同手机客户数
           ,NVL(a6.COMMON_CTCT_TEL_NUM,0)                  --相同电话数
           ,NVL(a6.COMMON_CTCT_TEL_CUST_ACTA,0)            --相同电话客户数
           ,NVL(a7.COMMON_CTCT_ADDR_NUM,0)                 --相同地址数
           ,NVL(a7.COMMON_CTCT_ADDR_CUST_ACTA,0)           --相同地址客户数
           ,NVL(a8.COMMON_SUM_CUST_ACTA,0)                 --合计相同客户数
           ,NVL(a9.MLT_BANK_FNL_CUST_ACTA,0)               --多银行期末客户数
           ,NVL(a9.MLT_BANK_FNL_BANK_ACTA,0)               --多银行期末银行账户数
           ,NVL(a9.MLT_BANK_ADDED_BANK_ACTA,0)             --多银行新增银行账户数
           ,NVL(a10.MLT_BANK_ADDED_CUST_ACTA,0)             --多银行新增客户数
 FROM         DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP   t
 LEFT JOIN    DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP1  a1                                                  
 ON           t.BRH_NO = a1.BRH_NO 
 LEFT JOIN    DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP2   a2                                                  
 ON           t.BRH_NO = a2.BRH_NO 
 LEFT JOIN    DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP3   a3                                                  
 ON           t.BRH_NO = a3.BRH_NO 
 LEFT JOIN    DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP4   a4                                                
 ON           t.BRH_NO = a4.BRH_NO 
 LEFT JOIN    DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP5   a5                                                
 ON           t.BRH_NO = a5.BRH_NO 
 LEFT JOIN    DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP6   a6                                                
 ON           t.BRH_NO = a6.BRH_NO 
 LEFT JOIN    DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP7   a7                                                
 ON           t.BRH_NO = a7.BRH_NO 
 LEFT JOIN    DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP8   a8                                                
 ON           t.BRH_NO = a8.BRH_NO 
 LEFT JOIN    DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP9   a9                                                
 ON           t.BRH_NO = a9.BRH_NO 
 LEFT JOIN    DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP10   a10                                                
 ON           t.BRH_NO = a10.BRH_NO 
 ;
 ---删除临时表
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP  ;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP1  ;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP2  ;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP3  ;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP4  ;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP5  ;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP6  ;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP7  ;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP8  ;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP9  ;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2_TEMP10 ;
   
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_COMPL_CL_EVAL_DATA2',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA2 ;
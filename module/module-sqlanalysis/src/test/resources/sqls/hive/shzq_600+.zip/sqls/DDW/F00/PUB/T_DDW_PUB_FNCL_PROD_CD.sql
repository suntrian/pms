------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:金融产品产品代码表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
 TRUNCATE TABLE DDW_PROD.T_DDW_PUB_FNCL_PROD_CD ;
INSERT OVERWRITE DDW_PROD.T_DDW_PUB_FNCL_PROD_CD
(
                                   ISSUE_ORG                 --发行机构  
                                  ,FNCL_PROD_CD              --金融产品代码 
                                  ,FNCL_PROD_SHRTNM          --金融产品简称                                 
                                  ,FNCL_PROD_FULLNM          --金融产品全称 							                                   								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT         t.FXJG       as ISSUE_ORG                 --发行机构                            
               ,t.CPDM       as FNCL_PROD_CD              --金融产品代码 
               ,t.CPJC       as FNCL_PROD_SHRTNM          --金融产品简称 	                                        						    
               ,t.CPQC       as FNCL_PROD_FULLNM          --金融产品全称  
 FROM           EDW_PROD.T_EDW_T04_TJRCP_CPDM                                 t       
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_FNCL_PROD_CD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_FNCL_PROD_CD ;
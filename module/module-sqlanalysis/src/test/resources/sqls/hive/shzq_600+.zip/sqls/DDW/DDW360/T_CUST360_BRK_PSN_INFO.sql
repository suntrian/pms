 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360纪经人信息表                                                                      */
  --/* 创建人:程骏                                                                               */
  --/* 创建时间:2017-10-19                                                                        */ 
  /* T_DDW_F01_CUST_BRK_RLN 替换为 T_DDW_F00_CUST_CUST_BRK_RLN */
  


---------------- 插入集中交易数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_BRK_PSN_INFO
 (
	 CUST_NO             	--客户号
	,STATS_DT            	--统计日期
	,CNCL_DT            	--注销日期
	,EXPR_DT            	--截至日期
	,BRK_NAME           	--经纪人姓名
	,BRK_BELTO_BRH      	--经纪人所属营业部
	,OPNAC_DT           	--开户日期
	,CNCLACT_DT         	--销户日期
	,RSG_DT             	--离职日期
	,IF_VLD_BRK_CUST		--纪经人是否有效
	,SVC_RLN				--服务关系
	,BRK_RLN				--经纪关系           
 )PARTITION( BUS_DATE = 20180510)
 SELECT     t.CUST_NO                                  as CUST_NO             	--客户号
	       ,CAST(t.STATS_DT AS DECIMAL(8,0))           as STATS_DT            	--统计日期
	       ,t.CNCL_DT                                  as CNCL_DT            	--注销日期
	       ,t.EXPR_DT                                  as EXPR_DT            	--截至日期
	       ,t.BRK_NAME                                 as BRK_NAME           	--经纪人姓名
	       ,a1.JGMC                                    as BRK_BELTO_BRH      	--经纪人所属营业部
	       ,t.OPNAC_DT                                 as OPNAC_DT           	--开户日期
	       ,t.CNCLACT_DT                               as CNCLACT_DT         	--销户日期
	       ,t.RSG_DT                                   as RSG_DT             	--离职日期
	       ,CASE WHEN T.VLD_BRK_CUST_FLG = 1           
		         THEN '有效经纪人'                    
				 ELSE '无效经纪人'                              
				 END                                   as IF_VLD_BRK_CUST		--纪经人是否有效
	       ,NULL                                       as SVC_RLN				--服务关系
	       ,NULL                                       as BRK_RLN				--经纪关系
 FROM           DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN      t
 LEFT JOIN      EDW_PROD.T_EDW_T03_TJGGL             a1
 ON             t.BRK_BELTO_BRH = a1.JGDM
 AND            t.BUS_DATE = a1.BUS_DATE
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_BRK_PSN_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_BRK_PSN_INFO; 
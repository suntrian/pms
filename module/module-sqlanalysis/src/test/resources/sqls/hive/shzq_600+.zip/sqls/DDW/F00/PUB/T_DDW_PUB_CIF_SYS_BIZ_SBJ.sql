------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:CIF系统业务科目表                                                                   */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
 TRUNCATE TABLE DDW_PROD.T_DDW_PUB_CIF_SYS_BIZ_SBJ ;
INSERT OVERWRITE DDW_PROD.T_DDW_PUB_CIF_SYS_BIZ_SBJ
(
                                   BIZ_SBJ              --业务科目      
                                  ,BIZ_SBJ_NAME         --业务科目名称						                                   								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT         t.YWKM	        as BIZ_SBJ              --业务科目                              
               ,t.YWKMMC        as BIZ_SBJ_NAME         --业务科目名称  
 FROM           EDW_PROD.T_EDW_T99_TYGTYWKM                                 t       
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_CIF_SYS_BIZ_SBJ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_CIF_SYS_BIZ_SBJ ;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:约定购回交易额度表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TYDGHJYED;   
---插入数据开始--------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TYDGHJYED
(
                                    KHH                                 --客户号                                
                                   ,YYB                                 --营业部                                
                                   ,KHXM                                --客户姓名                               
                                   ,SQED                                --授权额度                               
                                   ,SYED                                --使用额度                               
                                   ,DJRQ                                --登记日期                               
                                   ,XGRQ                                --修改日期  
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --客户姓名                                
                                   ,t.KHXM                                as KHXM                                --营业部                                 
                                   ,t.SQED                                as SQED                                --授权额度                                
                                   ,t.SYED                                as SYED                                --使用额度                                
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.XGRQ                                as XGRQ                                --修改日期   
                                   ,'JZJY'								   
 FROM         JZJYCX.SECURITIES_TYDGHJYED t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'JZJY'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE        t.DT = '%d{yyyyMMdd}';
--------插入数据结束--------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TYDGHJYED',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TYDGHJYED;
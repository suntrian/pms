 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:金融产品账户信息表                                                                      */
  --/* 创建人:刘桂汝                                                                               */
  --/* 创建时间:2017-10-20                                                                        */ 




---------------- 插入集中交易数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_DDW_F00_CUST_FNCL_PROD_ACCNT_INFO
     ( 
           CUST_NO		      					     --客户号
          ,ISSUE_ORG							     --发行机构
          ,FNCL_PROD_ACTNO				             --产品帐号
          ,CCY_CD								     --币种代码
          ,OPNAC_DT							         -- 开户日期
          ,FNCL_PROD_CUST_RSK_LVL	                 --金融产品客户风险评级
          ,RSK_EVAL_DT						         --风险评测日期
          ,FNCL_PROD_ACCNT_ATTR		                 --金融产品帐户属性
          ,FNCL_PROD_ACCNT_STAT		                 --金融产品帐户状态
          ,CUST_NAME							     --产品账户姓名
          ,CTF_CGY_CD							     --证件类别代码
          ,CTF_NO								     --证件编号	
          ,GNDR_CD								     --性别代码
          ,PHONE									 --手机
          ,PSTCD									 --邮政编码
          ,ADDR									     --地址
          ,TEL										 --电话
          ,BRH_NO								     --营业部编号
          ,BRH_NAME							         --营业部名称
      )PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT 
	              t.KHH                   as CUST_NO		      					     --客户号
	             ,t.FXJG                  as ISSUE_ORG							         --发行机构
	             ,t.JSZH                  as FNCL_PROD_ACTNO				             --产品帐号
	             ,t.BZDM                  as CCY_CD								         --币种代码
	             ,t.KHRQ                  as OPNAC_DT							         -- 开户日期
	             ,t.JRCP_FXDJ             as FNCL_PROD_CUST_RSK_LVL	                     --金融产品客户风险评级
	             ,t.FXPCRQ                as RSK_EVAL_DT						         --风险评测日期
	             ,t.JRCP_ZHSX             as FNCL_PROD_ACCNT_ATTR		                 --金融产品帐户属性
	             ,t.JRCP_ZHZT             as FNCL_PROD_ACCNT_STAT		                 --金融产品帐户状态
	             ,t.KHXM                  as CUST_NAME							         --产品账户姓名
	             ,t.ZJLBDM                as CTF_CGY_CD							         --证件类别代码
	             ,t.ZJBH                  as CTF_NO								         --证件编号	
	             ,t.XBDM                  as GNDR_CD								     --性别代码
	             ,t.MOBILE                as PHONE									     --手机
	             ,t.YZBM                  as PSTCD									     --邮政编码
	             ,t.DZ                    as ADDR									     --地址
	             ,t.DH                    as TEL										 --电话
	             ,t.YYB                   as BRH_NO								         --营业部编号
	             ,NVL(a2.BRH_SHRTNM,a3.FILIL_DEPT_SHRTNM)                 as BRH_NAME							         --营业部名称
 FROM          EDW_PROD.T_EDW_T02_TJRCP_CPZH    t
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH    a2
 ON             t.YYB = a2.BRH_NO   
 AND           a2.BUS_DATE = %d{yyyyMMdd} 
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a3
 ON            t.YYB = a3.FILIL_DEPT_CDG
 AND           a3.BUS_DATE = %d{yyyyMMdd}
 WHERE      t.bus_date = %d{yyyyMMdd}
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_FNCL_PROD_ACCNT_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_FNCL_PROD_ACCNT_INFO ;
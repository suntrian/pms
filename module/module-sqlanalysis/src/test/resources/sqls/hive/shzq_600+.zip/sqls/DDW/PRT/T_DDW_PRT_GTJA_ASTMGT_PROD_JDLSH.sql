 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:国君资管产品君得利三号                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 

--DDW_PROD.T_DDW_PRT_GTJA_ASTMGT_PROD_JDJXL
--------插入数据开始-----------
------插入营业部
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_GTJA_ASTMGT_PROD_JDLSH
(
								 BELTO_FILIL                   --地区
								,BRH_NO 					   --营业部编号
								,BRH_NAME                      --营业部名称
								,PRCH_952653_7                 --申购_952653_7
								,RTAN_AMT_GT_952653_7          --累计保有量_952653_7
								,ASS_INCM_952653_7             --考核收入_952653_7
								,PRCH_952624_14                 --申购_952624_14
								,RTAN_AMT_GT_952624_14          --累计保有量_952624_14
								,ASS_INCM_952624_14             --考核收入_952624_14								
								,PRCH_952625_14                 --申购_952625_14
								,RTAN_AMT_GT_952625_14          --累计保有量_952625_14
								,ASS_INCM_952625_14             --考核收入_952625_14
								,PRCH_14                        --申购_14
								,RTAN_AMT_GT_14                 --累计保有量_14
								,ASS_INCM_14                    --考核收入_14
                                ,PRCH_952654_28                --申购_952654_28
								,RTAN_AMT_GT_952654_28         --累计保有量_952654_28
								,ASS_INCM_952654_28            --考核收入_952654_28
								,PRCH_952655_28                --申购_952655_28
								,RTAN_AMT_GT_952655_28         --累计保有量_952655_28
								,ASS_INCM_952655_28            --考核收入_952655_28
								,PRCH_952656_28                --申购_952656_28
								,RTAN_AMT_GT_952656_28         --累计保有量_952656_28
								,ASS_INCM_952656_28            --考核收入_952656_28
								,PRCH_952657_28                --申购_952657_28
								,RTAN_AMT_GT_952657_28         --累计保有量_952657_28
								,ASS_INCM_952657_28            --考核收入_952657_28
								,PRCH_28                       --申购汇总_28
								,RTAN_AMT_GT_28                --累计保有量汇总_28
								,ASS_INCM_28                   --考核收入汇总_28
								,PRCH_952602_91                --申购_952602_91
								,RTAN_AMT_GT_952602_91        --累计保有量_952602_91
								,ASS_INCM_952602_91           --考核收入_952602_91
								,PRCH_952603_91               --申购_952603_91
								,RTAN_AMT_GT_952603_91        --累计保有量_952603_91
								,ASS_INCM_952603_91           --考核收入_952603_91
								,PRCH_952604_91               --申购_952604_91
								,RTAN_AMT_GT_952604_91        --累计保有量_952604_91
								,ASS_INCM_952604_91           --考核收入_952604_91
								,PRCH_952605_91                --申购_952605_91
								,RTAN_AMT_GT_952605_91        --累计保有量_952605_91
								,ASS_INCM_952605_91           --考核收入_952605_91
								,PRCH_952606_91               --申购_952606_91
								,RTAN_AMT_GT_952606_91        --累计保有量_952606_91
								,ASS_INCM_952606_91           --考核收入_952606_91
								,PRCH_952607_91               --申购_952607_91
								,RTAN_AMT_GT_952607_91        --累计保有量_952607_91
								,ASS_INCM_952607_91           --考核收入_952607_91
								,PRCH_952612_91                --申购_952612_91
								,RTAN_AMT_GT_952612_91        --累计保有量_952612_91
								,ASS_INCM_952612_91           --考核收入_952612_91
								,PRCH_952613_91               --申购_952613_91
								,RTAN_AMT_GT_952613_91        --累计保有量_952613_91
								,ASS_INCM_952613_91           --考核收入_952613_91
								,PRCH_952614_91               --申购_952614_91
								,RTAN_AMT_GT_952614_91        --累计保有量_952614_91
								,ASS_INCM_952614_91           --考核收入_952614_91
								,PRCH_952615_91                --申购_952615_91
								,RTAN_AMT_GT_952615_91        --累计保有量_952615_91
								,ASS_INCM_952615_91           --考核收入_952615_91
								,PRCH_952633_91               --申购_952633_91
								,RTAN_AMT_GT_952633_91        --累计保有量_952633_91
								,ASS_INCM_952633_91           --考核收入_952633_91
								,PRCH_952634_91               --申购_952634_91
								,RTAN_AMT_GT_952634_91        --累计保有量_952634_91
								,ASS_INCM_952634_91           --考核收入_952634_91
								,PRCH_952636_91               --申购_952636_91
								,RTAN_AMT_GT_952636_91        --累计保有量_952636_91
								,ASS_INCM_952636_91           --考核收入_952636_91
								,PRCH_91                       --申购汇总_91
								,RTAN_AMT_GT_91                --累计保有量汇总_91
								,ASS_INCM_91                   --考核收入汇总_91									
								,PRCH_952637_182               --申购_952637_182
								,RTAN_AMT_GT_952637_182        --累计保有量_952637_182
								,ASS_INCM_952637_182           --考核收入_952637_182
								,PRCH_952638_182               --申购_952638_182
								,RTAN_AMT_GT_952638_182        --累计保有量_952638_182
								,ASS_INCM_952638_182           --考核收入_952638_182
								,PRCH_952639_182               --申购_952639_182
								,RTAN_AMT_GT_952639_182        --累计保有量_952639_182
								,ASS_INCM_952639_182           --考核收入_952639_182
								,PRCH_952640_182                --申购_952640_182
								,RTAN_AMT_GT_952640_182        --累计保有量_952640_182
								,ASS_INCM_952640_182           --考核收入_952640_182
								,PRCH_952641_182               --申购_952641_182
								,RTAN_AMT_GT_952641_182        --累计保有量_952641_182
								,ASS_INCM_952641_182           --考核收入_952641_182
								,PRCH_952643_182               --申购_952643_182
								,RTAN_AMT_GT_952643_182        --累计保有量_952643_182
								,ASS_INCM_952643_182           --考核收入_952643_182
								,PRCH_182                      --申购汇总_182
								,RTAN_AMT_GT_182               --累计保有量汇总_182
								,ASS_INCM_182                  --考核收入汇总_182				
								,PRCH                          --申购汇总
								,RTAN_AMT_GT                   --累计保有量汇总
								,ASS_INCM                      --收益考核汇总
								)		
 PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT 
								 t.BELTO_FILIL      as BELTO_FILIL    --地区
								,t.BRH_NO 			as BRH_NO		  --营业部编号
								,t.BRH_SHRTNM       as BRH_NAME       --营业部名称
								,ROUND(SUM(DECODE(a1.PROD_CD,'952653',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952653_7                --申购_952653_7
								,ROUND(SUM(DECODE(a1.PROD_CD,'952653',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952653_7         --累计保有量_952653_7
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952653',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952653_7            --考核收入_952653_7
		                        ,ROUND(SUM(DECODE(a1.PROD_CD,'952624',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952624_14                --申购_952624_14
								,ROUND(SUM(DECODE(a1.PROD_CD,'952624',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952624_14         --累计保有量_952624_14
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952624',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952624_14            --考核收入_952624_14
								,ROUND(SUM(DECODE(a1.PROD_CD,'952625',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952625_14                --申购_952625_14
								,ROUND(SUM(DECODE(a1.PROD_CD,'952625',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952625_14         --累计保有量_952625_14
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952625',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952625_14            --考核收入_952625_14
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952624','952625')
								                THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									            ELSE 0
									            END
									   ),6)                                                                                         as PRCH_14                        --申购汇总_14
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952624','952625')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                                            as RTAN_AMT_GT_14                 --累计保有量汇总_14
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952624','952625')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                                            as ASS_INCM_14                    --考核收入汇总_14
								,ROUND(SUM(DECODE(a1.PROD_CD,'952654',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952654_28               --申购_952654_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952654',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952654_28        --累计保有量_952654_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952654',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952654_28           --考核收入_952654_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952655',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952655_28               --申购_952655_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952655',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952655_28        --累计保有量_952655_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952655',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952655_28           --考核收入_952655_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952656',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952656_28               --申购_952656_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952656',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952656_28        --累计保有量_952656_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952656',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952656_28           --考核收入_952656_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952657',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952657_28               --申购_952657_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952657',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952657_28        --累计保有量_952657_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952657',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952657_28           --考核收入_952657_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952654','952655','952656','952657')
								                THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									            ELSE 0
									            END
									   ),6)                                                                                               as PRCH_28               --申购汇总_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952654','952655','952656','952657')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_28        --累计保有量汇总_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952654','952655','952656','952657')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_28                  --考核收入汇总_28
								
								
								,ROUND(SUM(DECODE(a1.PROD_CD,'952602',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952602_91                --申购_952602_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952602',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952602_91        --累计保有量_952602_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952602',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952602_91           --考核收入_952602_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952603',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952603_91               --申购_952603_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952603',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952603_91        --累计保有量_952603_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952603',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952603_91           --考核收入_952603_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952604',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952604_91               --申购_952604_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952604',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952604_91        --累计保有量_952604_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952604',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952604_91           --考核收入_952604_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952605',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952605_91                --申购_952605_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952605',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952605_91        --累计保有量_952605_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952605',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952605_91           --考核收入_952605_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952606',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952606_91               --申购_952606_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952606',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952606_91        --累计保有量_952606_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952606',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952606_91           --考核收入_952606_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952607',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952607_91               --申购_952607_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952607',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952607_91        --累计保有量_952607_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952607',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952607_91           --考核收入_952607_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952612',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952612_91                --申购_952612_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952612',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952612_91        --累计保有量_952612_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952612',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952612_91           --考核收入_952612_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952613',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952613_91               --申购_952613_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952613',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952613_91        --累计保有量_952613_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952613',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952613_91           --考核收入_952613_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952614',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952614_91               --申购_952614_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952614',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952614_91        --累计保有量_952614_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952614',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952614_91           --考核收入_952614_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952615',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952615_91                --申购_952615_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952615',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952615_91        --累计保有量_952615_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952615',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952615_91           --考核收入_952615_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952633',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952633_91               --申购_952633_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952633',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952633_91        --累计保有量_952633_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952633',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952633_91           --考核收入_952633_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952634',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952634_91               --申购_952634_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952634',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952634_91        --累计保有量_952634_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952634',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952634_91           --考核收入_952634_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952636',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952636_91               --申购_952636_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952636',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952636_91        --累计保有量_952636_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952636',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952636_91           --考核收入_952636_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_91               --申购汇总_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									) ,6)                                                                       as RTAN_AMT_GT_91        --累计保有量汇总_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_91               --考核收入汇总_91	
                                ,ROUND(SUM(DECODE(a1.PROD_CD,'952637',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952637_182               --申购_952637_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952637',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952637_182        --累计保有量_952637_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952637',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952637_182           --考核收入_952637_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952638',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952638_182               --申购_952638_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952638',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952638_182        --累计保有量_952638_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952638',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952638_182           --考核收入_952638_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952639',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952639_182               --申购_952639_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952639',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952639_182        --累计保有量_952639_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952639',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952639_182           --考核收入_952639_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952640',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952640_182                --申购_952640_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952640',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952640_182        --累计保有量_952640_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952640',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952640_182           --考核收入_952640_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952641',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952641_182               --申购_952641_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952641',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952641_182        --累计保有量_952641_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952641',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952641_182           --考核收入_952641_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952643',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952643_182               --申购_952643_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952643',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952643_182        --累计保有量_952643_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952643',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952643_182           --考核收入_952643_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952637','952638','952639','952640','952641','952643')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_182               --申购汇总_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952637','952638','952639','952640','952641','952643')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_182        --累计保有量汇总_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952637','952638','952639','952640','952641','952643')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_182               --考核收入汇总_182                                
                                ,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH              --申购汇总
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									) ,6)                                                                       as RTAN_AMT_GT       --累计保有量汇总
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                         as ASS_INCM         --考核收入汇总
  FROM  		DDW_PROD.T_DDW_INR_ORG_BRH 	           t
  LEFT JOIN     DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON   a1
  ON            t.BRH_NO = a1.BRH_NO
  AND           a1.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
  AND           CAST(a1.YEAR_MON as STRING) = SUBSTR('%d{yyyyMMdd}',1,6)
  WHERE         t.BUS_DATE = %d{yyyyMMdd}
  GROUP BY BELTO_FILIL,BRH_NO,BRH_NAME 

  
  
  ---插入分公司
  UNION  ALL
   SELECT 
								 t.BELTO_FILIL       as BELTO_FILIL    --地区
								,t.BELTO_FILIL 		 as BRH_NO		  --营业部编号
								,t.BELTO_FILIL       as BRH_NAME       --营业部名称
								,ROUND(SUM(DECODE(a1.PROD_CD,'952653',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952653_7                --申购_952653_7
								,ROUND(SUM(DECODE(a1.PROD_CD,'952653',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952653_7         --累计保有量_952653_7
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952653',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952653_7            --考核收入_952653_7
		                        ,ROUND(SUM(DECODE(a1.PROD_CD,'952624',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952624_14                --申购_952624_14
								,ROUND(SUM(DECODE(a1.PROD_CD,'952624',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952624_14         --累计保有量_952624_14
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952624',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952624_14            --考核收入_952624_14
								,ROUND(SUM(DECODE(a1.PROD_CD,'952625',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952625_14                --申购_952625_14
								,ROUND(SUM(DECODE(a1.PROD_CD,'952625',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952625_14         --累计保有量_952625_14
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952625',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952625_14            --考核收入_952625_14
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952624','952625')
								                THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									            ELSE 0
									            END
									   ),6)                                                                                         as PRCH_14                        --申购汇总_14
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952624','952625')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                                            as RTAN_AMT_GT_14                 --累计保有量汇总_14
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952624','952625')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                                            as ASS_INCM_14                    --考核收入汇总_14
								,ROUND(SUM(DECODE(a1.PROD_CD,'952654',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952654_28               --申购_952654_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952654',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952654_28        --累计保有量_952654_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952654',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952654_28           --考核收入_952654_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952655',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952655_28               --申购_952655_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952655',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952655_28        --累计保有量_952655_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952655',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952655_28           --考核收入_952655_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952656',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952656_28               --申购_952656_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952656',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952656_28        --累计保有量_952656_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952656',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952656_28           --考核收入_952656_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952657',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952657_28               --申购_952657_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952657',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952657_28        --累计保有量_952657_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952657',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952657_28           --考核收入_952657_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952654','952655','952656','952657')
								                THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									            ELSE 0
									            END
									   ),6)                                                                                               as PRCH_28               --申购汇总_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952654','952655','952656','952657')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_28        --累计保有量汇总_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952654','952655','952656','952657')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_28                  --考核收入汇总_28
								
								
								,ROUND(SUM(DECODE(a1.PROD_CD,'952602',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952602_91                --申购_952602_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952602',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952602_91        --累计保有量_952602_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952602',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952602_91           --考核收入_952602_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952603',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952603_91               --申购_952603_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952603',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952603_91        --累计保有量_952603_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952603',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952603_91           --考核收入_952603_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952604',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952604_91               --申购_952604_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952604',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952604_91        --累计保有量_952604_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952604',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952604_91           --考核收入_952604_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952605',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952605_91                --申购_952605_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952605',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952605_91        --累计保有量_952605_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952605',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952605_91           --考核收入_952605_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952606',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952606_91               --申购_952606_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952606',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952606_91        --累计保有量_952606_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952606',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952606_91           --考核收入_952606_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952607',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952607_91               --申购_952607_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952607',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952607_91        --累计保有量_952607_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952607',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952607_91           --考核收入_952607_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952612',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952612_91                --申购_952612_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952612',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952612_91        --累计保有量_952612_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952612',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952612_91           --考核收入_952612_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952613',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952613_91               --申购_952613_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952613',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952613_91        --累计保有量_952613_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952613',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952613_91           --考核收入_952613_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952614',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952614_91               --申购_952614_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952614',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952614_91        --累计保有量_952614_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952614',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952614_91           --考核收入_952614_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952615',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952615_91                --申购_952615_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952615',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952615_91        --累计保有量_952615_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952615',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952615_91           --考核收入_952615_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952633',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952633_91               --申购_952633_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952633',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952633_91        --累计保有量_952633_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952633',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952633_91           --考核收入_952633_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952634',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952634_91               --申购_952634_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952634',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952634_91        --累计保有量_952634_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952634',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952634_91           --考核收入_952634_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952636',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952636_91               --申购_952636_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952636',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952636_91        --累计保有量_952636_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952636',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952636_91           --考核收入_952636_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_91               --申购汇总_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									) ,6)                                                                       as RTAN_AMT_GT_91        --累计保有量汇总_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_91               --考核收入汇总_91	
                                ,ROUND(SUM(DECODE(a1.PROD_CD,'952637',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952637_182               --申购_952637_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952637',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952637_182        --累计保有量_952637_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952637',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952637_182           --考核收入_952637_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952638',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952638_182               --申购_952638_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952638',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952638_182        --累计保有量_952638_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952638',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952638_182           --考核收入_952638_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952639',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952639_182               --申购_952639_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952639',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952639_182        --累计保有量_952639_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952639',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952639_182           --考核收入_952639_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952640',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952640_182                --申购_952640_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952640',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952640_182        --累计保有量_952640_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952640',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952640_182           --考核收入_952640_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952641',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952641_182               --申购_952641_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952641',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952641_182        --累计保有量_952641_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952641',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952641_182           --考核收入_952641_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952643',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952643_182               --申购_952643_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952643',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952643_182        --累计保有量_952643_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952643',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952643_182           --考核收入_952643_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952637','952638','952639','952640','952641','952643')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_182               --申购汇总_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952637','952638','952639','952640','952641','952643')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_182        --累计保有量汇总_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952637','952638','952639','952640','952641','952643')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_182               --考核收入汇总_182                                
                                ,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH              --申购汇总
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									) ,6)                                                                       as RTAN_AMT_GT       --累计保有量汇总
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                         as ASS_INCM         --考核收入汇总
  FROM  		DDW_PROD.T_DDW_INR_ORG_BRH 	           t
  LEFT JOIN     DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON   a1
  ON            t.BRH_NO = a1.BRH_NO
  AND           a1.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
  AND           CAST(a1.YEAR_MON as STRING) = SUBSTR('%d{yyyyMMdd}',1,6)
  WHERE         t.BUS_DATE = %d{yyyyMMdd}
  GROUP BY BELTO_FILIL,BRH_NO,BRH_NAME 
  ---插入分公司
  UNION  ALL
   SELECT 
								 '上海证券总计'      as BELTO_FILIL    --地区
								,'上海证券总计' 	 as BRH_NO		  --营业部编号
								,'上海证券总计'      as BRH_NAME       --营业部名称
								,ROUND(SUM(DECODE(a1.PROD_CD,'952653',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952653_7                --申购_952653_7
								,ROUND(SUM(DECODE(a1.PROD_CD,'952653',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952653_7         --累计保有量_952653_7
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952653',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952653_7            --考核收入_952653_7
		                        ,ROUND(SUM(DECODE(a1.PROD_CD,'952624',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952624_14                --申购_952624_14
								,ROUND(SUM(DECODE(a1.PROD_CD,'952624',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952624_14         --累计保有量_952624_14
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952624',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952624_14            --考核收入_952624_14
								,ROUND(SUM(DECODE(a1.PROD_CD,'952625',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952625_14                --申购_952625_14
								,ROUND(SUM(DECODE(a1.PROD_CD,'952625',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952625_14         --累计保有量_952625_14
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952625',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952625_14            --考核收入_952625_14
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952624','952625')
								                THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									            ELSE 0
									            END
									   ),6)                                                                                         as PRCH_14                        --申购汇总_14
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952624','952625')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                                            as RTAN_AMT_GT_14                 --累计保有量汇总_14
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952624','952625')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                                            as ASS_INCM_14                    --考核收入汇总_14
								,ROUND(SUM(DECODE(a1.PROD_CD,'952654',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952654_28               --申购_952654_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952654',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952654_28        --累计保有量_952654_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952654',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952654_28           --考核收入_952654_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952655',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952655_28               --申购_952655_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952655',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952655_28        --累计保有量_952655_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952655',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952655_28           --考核收入_952655_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952656',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952656_28               --申购_952656_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952656',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952656_28        --累计保有量_952656_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952656',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952656_28           --考核收入_952656_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952657',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952657_28               --申购_952657_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952657',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952657_28        --累计保有量_952657_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952657',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)                 as ASS_INCM_952657_28           --考核收入_952657_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952654','952655','952656','952657')
								                THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									            ELSE 0
									            END
									   ),6)                                                                                               as PRCH_28               --申购汇总_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952654','952655','952656','952657')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_28        --累计保有量汇总_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952654','952655','952656','952657')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_28                  --考核收入汇总_28
								
								
								,ROUND(SUM(DECODE(a1.PROD_CD,'952602',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952602_91                --申购_952602_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952602',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952602_91        --累计保有量_952602_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952602',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952602_91           --考核收入_952602_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952603',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952603_91               --申购_952603_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952603',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952603_91        --累计保有量_952603_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952603',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952603_91           --考核收入_952603_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952604',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952604_91               --申购_952604_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952604',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952604_91        --累计保有量_952604_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952604',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952604_91           --考核收入_952604_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952605',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952605_91                --申购_952605_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952605',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952605_91        --累计保有量_952605_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952605',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952605_91           --考核收入_952605_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952606',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952606_91               --申购_952606_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952606',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952606_91        --累计保有量_952606_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952606',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952606_91           --考核收入_952606_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952607',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952607_91               --申购_952607_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952607',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952607_91        --累计保有量_952607_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952607',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952607_91           --考核收入_952607_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952612',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952612_91                --申购_952612_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952612',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952612_91        --累计保有量_952612_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952612',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952612_91           --考核收入_952612_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952613',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952613_91               --申购_952613_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952613',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952613_91        --累计保有量_952613_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952613',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952613_91           --考核收入_952613_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952614',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952614_91               --申购_952614_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952614',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952614_91        --累计保有量_952614_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952614',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952614_91           --考核收入_952614_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952615',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952615_91                --申购_952615_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952615',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952615_91        --累计保有量_952615_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952615',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952615_91           --考核收入_952615_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952633',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952633_91               --申购_952633_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952633',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952633_91        --累计保有量_952633_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952633',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952633_91           --考核收入_952633_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952634',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952634_91               --申购_952634_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952634',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952634_91        --累计保有量_952634_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952634',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952634_91           --考核收入_952634_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952636',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952636_91               --申购_952636_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952636',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952636_91        --累计保有量_952636_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952636',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952636_91           --考核收入_952636_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_91               --申购汇总_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									) ,6)                                                                       as RTAN_AMT_GT_91        --累计保有量汇总_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_91               --考核收入汇总_91	
                                ,ROUND(SUM(DECODE(a1.PROD_CD,'952637',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952637_182               --申购_952637_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952637',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952637_182        --累计保有量_952637_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952637',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952637_182           --考核收入_952637_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952638',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952638_182               --申购_952638_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952638',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952638_182        --累计保有量_952638_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952638',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952638_182           --考核收入_952638_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952639',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952639_182               --申购_952639_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952639',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952639_182        --累计保有量_952639_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952639',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952639_182           --考核收入_952639_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952640',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952640_182                --申购_952640_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952640',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952640_182        --累计保有量_952640_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952640',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952640_182           --考核收入_952640_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952641',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952641_182               --申购_952641_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952641',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952641_182        --累计保有量_952641_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952641',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952641_182           --考核收入_952641_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952643',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952643_182               --申购_952643_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952643',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952643_182        --累计保有量_952643_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952643',a1.RTAN_AMT_AMT_GT,0)*0.0036/365,6)),6)   as ASS_INCM_952643_182           --考核收入_952643_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952637','952638','952639','952640','952641','952643')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_182               --申购汇总_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952637','952638','952639','952640','952641','952643')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_182        --累计保有量汇总_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952637','952638','952639','952640','952641','952643')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_182               --考核收入汇总_182                                
                                ,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH              --申购汇总
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									) ,6)                                                                       as RTAN_AMT_GT       --累计保有量汇总
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
								          THEN a1.RTAN_AMT_AMT_GT*0.0036/365
									      ELSE 0
									      END
									),6)                                                                         as ASS_INCM         --考核收入汇总
  FROM  		DDW_PROD.T_DDW_INR_ORG_BRH 	           t
  LEFT JOIN     DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON   a1
  ON            t.BRH_NO = a1.BRH_NO
  AND           a1.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
  AND           CAST(a1.YEAR_MON as STRING) = SUBSTR('%d{yyyyMMdd}',1,6)
  WHERE         t.BUS_DATE = %d{yyyyMMdd}
  GROUP BY BELTO_FILIL,BRH_NO,BRH_NAME 
 ;
 

 

 
-----------------------------加载结束--------------------
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_GTJA_ASTMGT_PROD_JDLSH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_GTJA_ASTMGT_PROD_JDLSH ;
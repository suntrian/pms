--/* ***************************************** SQL Begin *****************************************   */
  --/* 脚本功能:领导驾驶舱指标表                                                                  */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2016-11-02                                                                        */ 


 INSERT OVERWRITE DDW_PROD.DDW_APP_DASHBORD_IND_VALUE
 (      CODE	           --指标代码
       ,DIM_DATE	       --指标时间维护_日
       ,DIM_MON	           --指标时间维护_月
       ,DIM_YEAR	       --指标时间维护_年
       ,DIM_ORG	           --指标机构维度
       ,VALUE_STR	       --指标值_字符
       ,VALUE	     	   --指标值_数字
       ,ETL_DATE	       --数据更新时间
       --,TYPE	        --当前数据(CUR)，预处理数据(PRE_DATA)   
 ) 
 SELECT      CODE         as CODE	                --指标代码
            ,NULL         as DIM_DATE	            --指标时间维护_日
            ,DIM_MON      as DIM_MON	  	        --指标时间维护_月
            ,NULL         as DIM_YEAR	            --指标时间维护_年
            ,DIM_ORG      as DIM_ORG	            --指标机构维度
            ,VALUE_STR    as VALUE_STR	            --指标值_字符
            ,VALUE        as VALUE	      	        --指标值_数字
            ,%d{yyyyMMdd}     as ETL_DATE	            --数据更新时间
       --,TYPE	      STRING	        --当前数据(CUR)，预处理数据(PRE_DATA) 
 FROM     DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON 
 WHERE    NVL(DIM_MON,999999) > = 201701 
 UNION ALL
 SELECT      CONCAT(CODE,'_RANK')         as CODE	                --指标代码
            ,NULL                       as DIM_DATE	            --指标时间维护_日
            ,DIM_MON                    as DIM_MON	  	        --指标时间维护_月
            ,NULL                       as DIM_YEAR	            --指标时间维护_年
            ,DIM_ORG                    as DIM_ORG	            --指标机构维度
            ,NULL                       as VALUE_STR	            --指标值_字符
            ,ROW_NUMBER() OVER(PARTITION BY DIM_MON ORDER BY VALUE DESC )        as VALUE	      	        --指标值_数字
            ,%d{yyyyMMdd}     as ETL_DATE	            --数据更新时间
            --,TYPE	      STRING	        --当前数据(CUR)，预处理数据(PRE_DATA) 
 FROM     DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON 
 WHERE    NVL(DIM_MON,999999) > = 201701 
 AND      CODE IN ('BROK_BIZ_NET_INCM','SEC_IVSM_HEADS_NET_INCM','FIX_YLD_HEADS_NET_INCM','OTC_MKT_HEADS_NET_INCM','WEA_MGMT_CENTR_HEADS_NET_INCM','AST_MGMT_HEADS_NET_INCM'
 ,'CRD_BIZ_HEADS_NET_INCM','CO_HEADS_NET_INCM')
 UNION ALL
  SELECT      CONCAT(t.CODE,'_PCT')          as CODE	                --指标代码
            ,NULL                             as DIM_DATE	            --指标时间维护_日
            ,t.DIM_MON                        as DIM_MON	  	        --指标时间维护_月
            ,NULL                             as DIM_YEAR	            --指标时间维护_年
            ,t.DIM_ORG                        as DIM_ORG	            --指标机构维度
            ,NULL                             as VALUE_STR	            --指标值_字符
            ,ROUND(t.VALUE*1.0000/a1.VALUE,6) as VALUE	      	        --指标值_数字
            ,%d{yyyyMMdd}     as ETL_DATE	            --数据更新时间
            --,TYPE	      STRING	        --当前数据(CUR)，预处理数据(PRE_DATA) 
 FROM     DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON t
 LEFT JOIN (SELECT DIM_MON,VALUE 
            FROM   DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
            WHERE CODE = 'WHL_CO_GT_NET_INCM_MON'
            ) a1
 ON        t.DIM_MON = a1.DIM_MON 
 WHERE    NVL(t.DIM_MON,999999) > = 201701 
 AND      t.CODE IN ('BROK_BIZ_NET_INCM','SEC_IVSM_HEADS_NET_INCM','FIX_YLD_HEADS_NET_INCM','OTC_MKT_HEADS_NET_INCM','WEA_MGMT_CENTR_HEADS_NET_INCM','AST_MGMT_HEADS_NET_INCM'
 ,'CRD_BIZ_HEADS_NET_INCM','CO_HEADS_NET_INCM')
 UNION ALL
 SELECT      CONCAT(t.CODE,'_PCT')          as CODE	                --指标代码
            ,NULL                             as DIM_DATE	            --指标时间维护_日
            ,t.DIM_MON                        as DIM_MON	  	        --指标时间维护_月
            ,NULL                             as DIM_YEAR	            --指标时间维护_年
            ,t.DIM_ORG                        as DIM_ORG	            --指标机构维度
            ,NULL                             as VALUE_STR	            --指标值_字符
            ,ROUND(t.VALUE*1.0000/a1.VALUE,6) as VALUE	      	        --指标值_数字
            ,%d{yyyyMMdd}     as ETL_DATE	            --数据更新时间
            --,TYPE	      STRING	        --当前数据(CUR)，预处理数据(PRE_DATA) 
 FROM     DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON t
 LEFT JOIN (SELECT DIM_MON,VALUE 
            FROM   DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
            WHERE CODE = 'BROK_BIZ_NET_INCM'
            ) a1
 ON        t.DIM_MON = a1.DIM_MON 
 WHERE    NVL(t.DIM_MON,999999) > = 201701 
 AND      t.CODE IN ('BROK_BIZ_NET_INCM_CMSN_NET_INCM','BROK_BIZ_NET_INCM_3IP_DEPMGT_PAYOUT','BROK_BIZ_NET_INCM__INT_NET_INCM','BROK_BIZ_NET_INCM_OTHER_INCM'
   ,'BROK_BIZ_NET_INCM_AGGR_PL'
  )
  UNION ALL
  SELECT      CONCAT(t.CODE,'_PCT')          as CODE	                --指标代码
            ,NULL                             as DIM_DATE	            --指标时间维护_日
            ,t.DIM_MON                        as DIM_MON	  	        --指标时间维护_月
            ,NULL                             as DIM_YEAR	            --指标时间维护_年
            ,t.DIM_ORG                        as DIM_ORG	            --指标机构维度
            ,NULL                             as VALUE_STR	            --指标值_字符
            ,ROUND(t.VALUE*1.0000/a1.VALUE,6) as VALUE	      	        --指标值_数字
            ,%d{yyyyMMdd}     as ETL_DATE	            --数据更新时间
            --,TYPE	      STRING	        --当前数据(CUR)，预处理数据(PRE_DATA) 
 FROM     DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON t
 LEFT JOIN (SELECT DIM_MON,VALUE 
            FROM   DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
            WHERE CODE = 'SEC_IVSM_HEADS_NET_INCM'
            ) a1
 ON        t.DIM_MON = a1.DIM_MON 
 WHERE    NVL(t.DIM_MON,999999) > = 201701 
 AND      t.CODE IN ('SEC_IVSM_HEADS_NET_INCM__INT_NET_INCM','SEC_IVSM_HEADS_NET_INCM_FAIRS_VAL_CHG_PL','SEC_IVSM_HEADS_NET_INCM_IVSM_YLD'
          ,'SEC_IVSM_HEADS_NET_INCM_CMSN_NET_INCM'
             )
  UNION ALL
  SELECT      CONCAT(t.CODE,'_PCT')          as CODE	                --指标代码
            ,NULL                             as DIM_DATE	            --指标时间维护_日
            ,t.DIM_MON                        as DIM_MON	  	        --指标时间维护_月
            ,NULL                             as DIM_YEAR	            --指标时间维护_年
            ,t.DIM_ORG                        as DIM_ORG	            --指标机构维度
            ,NULL                             as VALUE_STR	            --指标值_字符
            ,ROUND(t.VALUE*1.0000/a1.VALUE,6) as VALUE	      	        --指标值_数字
            ,%d{yyyyMMdd}     as ETL_DATE	            --数据更新时间
            --,TYPE	      STRING	        --当前数据(CUR)，预处理数据(PRE_DATA) 
 FROM     DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON t
 LEFT JOIN (SELECT DIM_MON,VALUE 
            FROM   DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
            WHERE CODE = 'FIX_YLD_HEADS_NET_INCM'
            ) a1
 ON        t.DIM_MON = a1.DIM_MON 
 WHERE    NVL(t.DIM_MON,999999) > = 201701 
 AND      t.CODE IN ('FIX_YLD_HEADS_NET_INCM_UDWRT_NET_INCM','FIX_YLD_HEADS_NET_INCM_FAIRS_VAL_CHG_PL','FIX_YLD_HEADS_NET_INCM_IVSM_YLD','FIX_YLD_HEADS_NET_INCM_OTHER_INCM'
 )
  UNION ALL
  SELECT      CONCAT(t.CODE,'_PCT')          as CODE	                --指标代码
            ,NULL                             as DIM_DATE	            --指标时间维护_日
            ,t.DIM_MON                        as DIM_MON	  	        --指标时间维护_月
            ,NULL                             as DIM_YEAR	            --指标时间维护_年
            ,t.DIM_ORG                        as DIM_ORG	            --指标机构维度
            ,NULL                             as VALUE_STR	            --指标值_字符
            ,ROUND(t.VALUE*1.0000/a1.VALUE,6) as VALUE	      	        --指标值_数字
            ,%d{yyyyMMdd}     as ETL_DATE	            --数据更新时间
            --,TYPE	      STRING	        --当前数据(CUR)，预处理数据(PRE_DATA) 
 FROM     DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON t
 LEFT JOIN (SELECT DIM_MON,VALUE 
            FROM   DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
            WHERE CODE = 'OTC_MKT_HEADS_NET_INCM'
            ) a1
 ON        t.DIM_MON = a1.DIM_MON 
 WHERE    NVL(t.DIM_MON,999999) > = 201701 
 AND      t.CODE IN ('OTC_MKT_HEADS_NET_INCM_IVSM_YLD','OTC_MKT_HEADS_NET_INCM_FNC_CON_NET_INCM','OTC_MKT_HEADS_NET_INCM__INT_NET_INCM','OTC_MKT_HEADS_NET_INCM_OTHER_INCM'
      )
  UNION ALL
  SELECT      CONCAT(t.CODE,'_PCT')          as CODE	                --指标代码
            ,NULL                             as DIM_DATE	            --指标时间维护_日
            ,t.DIM_MON                        as DIM_MON	  	        --指标时间维护_月
            ,NULL                             as DIM_YEAR	            --指标时间维护_年
            ,t.DIM_ORG                        as DIM_ORG	            --指标机构维度
            ,NULL                             as VALUE_STR	            --指标值_字符
            ,ROUND(t.VALUE*1.0000/a1.VALUE,6) as VALUE	      	        --指标值_数字
            ,%d{yyyyMMdd}     as ETL_DATE	            --数据更新时间
            --,TYPE	      STRING	        --当前数据(CUR)，预处理数据(PRE_DATA) 
 FROM     DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON t
 LEFT JOIN (SELECT DIM_MON,VALUE 
            FROM   DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
            WHERE CODE = 'WEA_MGMT_CENTR_HEADS_NET_INCM'
            ) a1
 ON        t.DIM_MON = a1.DIM_MON 
 WHERE    NVL(t.DIM_MON,999999) > = 201701 
 AND      t.CODE IN ('WEA_MGMT_CENTR_HEADS_NET_INCM_FND_CO_NET_INCM'
 ,'WEA_MGMT_CENTR_HEADS_NET_INCM_QFII_NET_INCM'
 )
  UNION ALL
  SELECT      CONCAT(t.CODE,'_PCT')          as CODE	                --指标代码
            ,NULL                             as DIM_DATE	            --指标时间维护_日
            ,t.DIM_MON                        as DIM_MON	  	        --指标时间维护_月
            ,NULL                             as DIM_YEAR	            --指标时间维护_年
            ,t.DIM_ORG                        as DIM_ORG	            --指标机构维度
            ,NULL                             as VALUE_STR	            --指标值_字符
            ,ROUND(t.VALUE*1.0000/a1.VALUE,6) as VALUE	      	        --指标值_数字
            ,%d{yyyyMMdd}     as ETL_DATE	            --数据更新时间
            --,TYPE	      STRING	        --当前数据(CUR)，预处理数据(PRE_DATA) 
 FROM     DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON t
 LEFT JOIN (SELECT DIM_MON,VALUE 
            FROM   DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
            WHERE CODE = 'AST_MGMT_HEADS_NET_INCM'
            ) a1
 ON        t.DIM_MON = a1.DIM_MON 
 WHERE    NVL(t.DIM_MON,999999) > = 201701 
 AND      t.CODE IN ('AST_MGMT_HEADS_NET_INCM_ENTRUST_MGMT_NET_INCM'
                   ,'AST_MGMT_HEADS_NET_INCM_IVSM_YLD'
           )
  UNION ALL
  SELECT      CONCAT(t.CODE,'_PCT')          as CODE	                --指标代码
            ,NULL                             as DIM_DATE	            --指标时间维护_日
            ,t.DIM_MON                        as DIM_MON	  	        --指标时间维护_月
            ,NULL                             as DIM_YEAR	            --指标时间维护_年
            ,t.DIM_ORG                        as DIM_ORG	            --指标机构维度
            ,NULL                             as VALUE_STR	            --指标值_字符
            ,ROUND(t.VALUE*1.0000/a1.VALUE,6) as VALUE	      	        --指标值_数字
            ,%d{yyyyMMdd}     as ETL_DATE	            --数据更新时间
            --,TYPE	      STRING	        --当前数据(CUR)，预处理数据(PRE_DATA) 
 FROM     DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON t
 LEFT JOIN (SELECT DIM_MON,VALUE 
            FROM   DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
            WHERE CODE = 'CRD_BIZ_HEADS_NET_INCM'
            ) a1
 ON        t.DIM_MON = a1.DIM_MON 
 WHERE    NVL(t.DIM_MON,999999) > = 201701 
 AND      t.CODE IN ('CRD_BIZ_HEADS_NET_INCM__INT_NET_INCM'
                     ,'CRD_BIZ_HEADS_NET_INCM_FAIRS_VAL_CHG_PL'
                     ,'CRD_BIZ_HEADS_NET_INCM_IVSM_YLD'
                    )
   UNION ALL
  SELECT      CONCAT(t.CODE,'_PCT')          as CODE	                --指标代码
            ,NULL                             as DIM_DATE	            --指标时间维护_日
            ,t.DIM_MON                        as DIM_MON	  	        --指标时间维护_月
            ,NULL                             as DIM_YEAR	            --指标时间维护_年
            ,t.DIM_ORG                        as DIM_ORG	            --指标机构维度
            ,NULL                             as VALUE_STR	            --指标值_字符
            ,ROUND(t.VALUE*1.0000/a1.VALUE,6) as VALUE	      	        --指标值_数字
            ,%d{yyyyMMdd}     as ETL_DATE	            --数据更新时间
            --,TYPE	      STRING	        --当前数据(CUR)，预处理数据(PRE_DATA) 
 FROM     DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON t
 LEFT JOIN (SELECT DIM_MON,VALUE 
            FROM   DDW_PROD.DDW_APP_DASHBORD_IND_VALUE_MON
            WHERE CODE = 'CO_HEADS_NET_INCM'
            ) a1
 ON        t.DIM_MON = a1.DIM_MON 
 WHERE    NVL(t.DIM_MON,999999) > = 201701 
 AND      t.CODE IN ('CO_HEADS_NET_INCM_INT_NET_INCM','CO_HEADS_NET_INCM_OTHER_INCM','CO_HEADS_NET_INCM__CMSN_FEE_PAYOUT'
 ,'CO_HEADS_NET_INCM_CMSN_FEE_NET_INCM','CO_HEADS_NET_INCM_AGGR_PL','CO_HEADS_NET_INCM_IVSM_YLD'
 ) 
 ;
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','DDW_APP_DASHBORD_IND_VALUE',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
  invalidate metadata DDW_PROD.DDW_APP_DASHBORD_IND_VALUE ;
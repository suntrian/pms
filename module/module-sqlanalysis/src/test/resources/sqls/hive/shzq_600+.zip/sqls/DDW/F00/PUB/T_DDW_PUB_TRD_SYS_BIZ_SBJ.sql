------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:交易系统业务科目表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
TRUNCATE TABLE DDW_PROD.T_DDW_PUB_TRD_SYS_BIZ_SBJ ;
INSERT OVERWRITE DDW_PROD.T_DDW_PUB_TRD_SYS_BIZ_SBJ
(
                                   BIZ_SBJ             --业务科目      
                                  ,BIZ_SBJ_NAME        --业务科目名称  
                                  ,BIZ_SBJ_CGY         --业务科目类别                            
                                  ,REMRK_INFO          --备注信息      
								  ,INNER_SBJ           --内部名称      
                                  ,SUPRS_SBJ           --上级科目 
								  ,SYS_SRC             --系统来源							                                   								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT         t.YWKM	                                                                           as BIZ_SBJ             --业务科目                               
               ,t.YWKMMC	                                                                       as BIZ_SBJ_NAME        --业务科目名称  
               ,t.YWKMLB	                                                                       as BIZ_SBJ_CGY         --业务科目类别   	                                        						    
               ,t.BZXX	                                                                           as REMRK_INFO          --备注信息      
               ,t.NBMC	                                                                           as INNER_SBJ           --内部名称      
               ,t.SJKM	                                                                           as SUPRS_SBJ           --上级科目 
               ,DECODE(t.XTBS,'JZJY','普通账户','GGQQ','期权账户','RZRQ','信用账户')               as SYS_SRC             --系统来源		
 FROM           EDW_PROD.T_EDW_T99_TXTYWKM        t       
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_TRD_SYS_BIZ_SBJ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_TRD_SYS_BIZ_SBJ;
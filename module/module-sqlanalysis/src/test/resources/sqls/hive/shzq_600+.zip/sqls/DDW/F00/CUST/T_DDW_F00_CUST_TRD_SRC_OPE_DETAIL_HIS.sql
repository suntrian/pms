 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:交易系统操作明细历史表                                                                       */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
--------------------------删除临时表------------------
 DROP TABLE IF EXISTS DDW_PROD.TEMP_T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS ;
-----------------------删除临时表-------------------- 

--------创建临时表 二代证验证------

CREATE TABLE  DDW_PROD.TEMP_T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS  AS 
  SELECT t1.khh,t1.rq, 1 as bz 
  FROM (
         SELECT t.khh,t.rq as RQ
         FROM (
	             SELECT  khh,rq 
                 FROM   EDW_PROD.T_EDW_T05_TYGTXTCZMX
                 WHERE  YWKM = '20090' OR  zy like '%二代证验证%'
                 UNION ALL
                 SELECT     a1.khh,a2.sqrq as rq
                 FROM       (SELECT yyb,zjbh,khh FROM  EDW_PROD.T_EDW_T01_TKHXX where bus_date = %d{yyyyMMdd})     a1
                 INNER JOIN (SELECT zjbh,yyb,sqrq FROM EDW_PROD.T_EDW_T02_TGMSFCXSQ WHERE CLJG = 1)                a2
                 ON           a1.yyb = a2.yyb
                 AND          a1.zjbh = a2.zjbh
              ) t
       GROUP BY t.khh,t.rq
      )   t1
	  ; 


--------插入------
 INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS
(
                                     EVNT_SEQNBR                                   --事件序号   
                                    ,BRH_NO                                        --营业部编码  
                                    ,BRH_NAME                                      --营业部名称  
                                    ,DT                                            --日期     
                                    ,TM                                            --时间     
                                    ,CUST_NO                                       --客户号    
                                    ,CUST_NAME                                     --客户姓名   
                                    ,OCC_BRH_NO                                    --发生营业部编号
                                    ,BIZ_SBJ                                       --业务科目   
                                    ,SBJ_NAME                                      --科目名称   
                                    ,ABST                                          --摘要                                          
                                    ,OPRT_TELR                                     --操作柜员   
                                    ,RECHK_TELR                                    --复核柜员   
                                    ,SECOND_CARD_VRFCTN                            --二代证验证  
                                    ,SYS_SRC                                       --系统来源   
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                                    t.SEQNO                 as EVNT_SEQNBR                                   --事件序号                                                       
                                   ,t.YYB                   as BRH_NO                                        --营业部编码                                                      
                                   ,NVL(a1.BRH_SHRTNM,a6.FILIL_DEPT_SHRTNM)                 as BRH_NAME                                      --营业部名称                                                      
                                   ,t.RQ                    as DT                                            --日期                                                                                              
                                   ,t.FSSJ                  as TM                                            --时间                                                         
                                   ,t.KHH                   as CUST_NO                                       --客户号                                                        
                                   ,t.KHXM                  as CUST_NAME                                     --客户姓名          
                                   ,t.FSYYB                 as OCC_BRH_NO                                    --发生营业部编号                                                   
                                   ,t.YWKM                  as BIZ_SBJ                                       --业务科目                                                       
                                   ,a2.YWKMMC               as SBJ_NAME                                      --科目名称                                                       
                                   ,t.ZY                    as ABST                                          --摘要            
                                   ,NVL(a4.XM,t.LOGINID)    as OPRT_TELR                                     --操作柜员                                             
                                   ,CASE WHEN t.FHGY IS NULL
                                         THEN NULL
                                         ELSE a5.XM
                                         END                 as RECHK_TELR                                    --复核柜员          
                                   ,CASE WHEN a3.BZ = 1 
                                         THEN '已验证'	
 										 ELSE '未验证'
										 END                 as SECOND_CARD_VRFCTN                            --二代证验证         
                                    ,t.XTBS                  as SYS_SRC                                       --系统来源                                                                                                                                                
  FROM          EDW_PROD.T_EDW_T05_TYWXTCZMX                                               t
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH    a1
  ON             t.YYB = a1.BRH_NO   
  AND           a1.BUS_DATE = %d{yyyyMMdd} 
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a6
  ON            t.YYB = a6.FILIL_DEPT_CDG
  AND           a6.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     EDW_PROD.T_EDW_T99_TXTYWKM                                                 a2 
  ON            t.YWKM  = a2.YWKM 
  AND           t.XTBS = a2.XTBS 
  AND           a2.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     DDW_PROD.TEMP_T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS                                                       a3
  ON            t.KHH = a3.KHH
  AND           t.RQ = a3.RQ
  LEFT JOIN     EDW_PROD.T_EDW_T01_TGYXX                                                   a4
  ON            t.LOGINID = a4.LOGINID
  AND           t.XTBS = a4.XTBS
  AND           a4.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     EDW_PROD.T_EDW_T01_TGYXX                                                   a5
  ON            t.FHGY = a5.LOGINID
  AND           t.XTBS = a5.XTBS
  AND           a5.BUS_DATE = %d{yyyyMMdd}
  WHERE         t.bus_date = %d{yyyyMMdd}
  ;
  
---------------- 插入数据结束 -----------------------
--------------------------删除临时表------------------
 DROP TABLE IF EXISTS DDW_PROD.TEMP_T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS ;
-----------------------删除临时表-------------------- 

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS ;
------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:自营持仓表                                                                          */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2017-12-29                                                                        */ 

 DROP TABLE IF EXISTS  RISK_INDEX.HISSELFSTOCK_TEMP ;
 CREATE TABLE RISK_INDEX.HISSELFSTOCK_TEMP  as
 SELECT      a1.secucode  as ZQDM
			 ,ROUND(t.interestthisyear*(EDW_PROD.G_DATE_COMPARE_DATE('%d{yyyyMMdd}','yyyyMMdd',CONCAt(substr(t.valuedateper,1,4),substr(t.valuedateper,6,2),substr(t.valuedateper,9,2) ),'yyyyMMdd')+1)*1.00000/(EDW_PROD.G_DATE_COMPARE_DATE(CONCAt(substr(t.valuedatenextper,1,4),substr(t.valuedatenextper,6,2),substr(t.valuedatenextper,9,2) ),'yyyyMMdd',CONCAt(substr(t.valuedateper,1,4),substr(t.valuedateper,6,2),substr(t.valuedateper,9,2) ),'yyyyMMdd')+1),4) as ZXLX
			 ,%d{yyyyMMdd} as RQ
			 
 FROM        FUNDEXT.DBO_BOND_INTERESTRATE  t
 LEFT JOIN   FUNDEXT.DBO_BOND_CODE           a1
 ON          t.INNERCODE = a1.INNERCODE
 AND         t.DT = a1.DT
 WHERE       t.DT = '%d{yyyyMMdd}'
 AND         '%d{yyyyMMdd}' BETWEEN CONCAt(substr(t.valuedateper,1,4),substr(t.valuedateper,6,2),substr(t.valuedateper,9,2) ) AND CONCAt(substr(t.valuedatenextper,1,4),substr(t.valuedatenextper,6,2),substr(t.valuedatenextper,9,2) )
 UNION ALL 
  SELECT      a1.secucode  as ZQDM
			 ,ROUND((t.parvalue-t.issueprice)*(EDW_PROD.G_DATE_COMPARE_DATE('%d{yyyyMMdd}','yyyyMMdd',CONCAt(substr(t.valuedate,1,4),substr(t.valuedate,6,2),substr(t.valuedate,9,2) ),'yyyyMMdd'))*1.000000000000/(EDW_PROD.G_DATE_COMPARE_DATE(CONCAt(substr(t.enddate,1,4),substr(t.enddate,6,2),substr(t.enddate,9,2) ),'yyyyMMdd',CONCAt(substr(t.valuedate,1,4),substr(t.valuedate,6,2),substr(t.valuedate,9,2) ),'yyyyMMdd')),4) as ZXLX
			 ,%d{yyyyMMdd} as RQ
 FROM        FUNDEXT.DBO_BOND_BASICINFO  t
 LEFT JOIN   FUNDEXT.DBO_BOND_CODE           a1
 ON          t.MainCode = a1.MainCode
 AND         t.DT = a1.DT
 WHERE       t.DT = '%d{yyyyMMdd}'
 AND         '%d{yyyyMMdd}' BETWEEN CONCAt(substr(t.valuedate,1,4),substr(t.valuedate,6,2),substr(t.valuedate,9,2) ) AND CONCAt(substr(t.enddate,1,4),substr(t.enddate,6,2),substr(t.enddate,9,2) )
 AND         NOT EXISTS (SELECT 1 FROM FUNDEXT.DBO_BOND_INTERESTRATE a2
                         WHERE    '%d{yyyyMMdd}' BETWEEN CONCAt(substr(a2.valuedateper,1,4),substr(a2.valuedateper,6,2),substr(a2.valuedateper,9,2) ) AND CONCAt(substr(a2.valuedatenextper,1,4),substr(a2.valuedatenextper,6,2),substr(a2.valuedatenextper,9,2) )
                         AND     a2.DT = '%d{yyyyMMdd}'
						 AND     t.INNERCODE = a2.INNERCODE 
                         )
 ;
 
 
 



--------------插入数据-------------------
INSERT OVERWRITE RISK_INDEX.HISSELFSTOCK
(
                    T_DATE                                     --日期
				   ,I_CODE                                     --资产代码
				   ,I_NAME                                     --证券名称
				   ,A_TYPE                                     --资产类型:股票、债券、基金、期货、期权等
				   ,CURRENCY                                   --原币币种:比如港币
				   ,H_COUNT                                    --数量
				   ,H_COST                                     --原币成本
				   ,H_EVAL                                     --原币市值
				   ,H_AI                                       --原币利息
				   ,PORT_CURRENCY                              --本币币种
				   ,H_PORT_COST                                --本币成本:一般是人民币
				   ,H_PORT_EVAL                                --本币市值
				   ,FX_RATE                                    --汇率
				   ,H_PORT_AI                                  --本币利息
				   ,POSITION                                   --多空头标识 多头：L；空头：S
					
)
PARTITION  (DT = '%d{yyyyMMdd}')
SELECT 
                     CAST(EDW_PROD.G_DATE_CONVERT_INT(CAST(t.OC_DATE AS INT),'yyyyMMdd','yyyy-MM-dd') AS VARCHAR(16) )         AS T_DATE  
                    ,CAST(CASE WHEN t.exchange_type = '1'
					      THEN CONCAT(t.NC_STOCK_CODE,'.SH')
						  WHEN t.exchange_type = '2'
					      THEN CONCAT(t.NC_STOCK_CODE,'.SZ')
						  WHEN t.exchange_type = '5'
					      THEN CONCAT(t.NC_STOCK_CODE,'.IB')
						  WHEN t.exchange_type = 'Y'
					      THEN CONCAT(t.NC_STOCK_CODE,'.OC')
						  WHEN t.exchange_type = 'G'
					      THEN CONCAT(t.NC_STOCK_CODE,'.HK')
						  WHEN t.exchange_type = '16'
					      THEN CONCAT(t.NC_STOCK_CODE,'.CW')
                          ELSE t.NC_STOCK_CODE
                          END  AS VARCHAR(32))   	                    AS I_CODE 
                    ,t.STOCK_NAME                                       AS I_NAME 
                    ,t.NC_STOCK_TYPE                                    AS A_TYPE  --exchange_type为1和2时，nc_stock_type 1:股票 2：债券, exchange_type为Y时,nc_stock_type 1:新三板股票
                    ,t.CURRENCY                                         AS CURRENCY
                    ,CAST(t.CURRENT_AMOUNT AS BIGINT)                   AS H_COUNT
                    ,CAST(t.STOCK_INVEST_ORIGINAL AS DECIMAL(20,2))     AS H_COST  
                    ,CAST(t.MARKET_VALUE AS DECIMAL(20,2))              AS H_EVAL 
                    ,CAST(t.CURRENT_AMOUNT*NVL(a1.ZXLX,0) as DECIMAL(16,2) )  AS H_AI  -- 证券类型为债券时，计算债券应收利息(全价-净价)，数据需要来自资讯
                    ,t.CURRENCY                                         AS PORT_CURRENCY 
                    ,CAST(t.STOCK_INVEST AS DECIMAL(20,2))              AS H_PORT_COST 
                    ,CAST(t.MARKET_VALUE AS DECIMAL(20,2))              AS H_PORT_EVAL 
                    ,1                                                  AS FX_RATE 
                    ,0                                                  AS H_PORT_AI  -- 证券类型为债券时，计算债券应收利息，数据需要来自资讯
                    ,CAST('L' AS VARCHAR(32))                           AS POSITION  
FROM        		QMFK.HSFSK_NC_QUERYSELFSTOCK  t
LEFT JOIN           RISK_INDEX.HISSELFSTOCK_TEMP  a1
ON                  TRIM(t.NC_STOCK_CODE) = TRIM(a1.ZQDM)
AND                 t.NC_STOCK_TYPE = '2'
WHERE       		t.OC_DATE       = %d{yyyyMMdd}
AND         		t.DT            = '%d{yyyyMMdd}';
---------------- 插入数据结束 -----------------------
------删除临时表

 DROP TABLE IF EXISTS  RISK_INDEX.HISSELFSTOCK_TEMP ;
 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360普通账户负债明细表                                                          */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-10-27                                                                       */ 
  /* T_DDW_F02_ORDI_ACCNT_GL_DTL	替换为	T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS */
  


---------------- 插入数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_ORDI_ACCNT_GL_DTL
 (
	 CUST_NO                --客户号       
	,CUST_NAME              --客户姓名     
	,EXG                    --交易所
	,SEC_CD                 --证券代码
	,SEC_NAME               --证券名称
	,SEC_CGY                --证券类别
	,CCY                    --币种
	,SEC_QTY                --证券数量
	,GL_PRINP               --负债本金
	,PRDCT_RTN_PRINP        --预计归还金额
	,INTSETL_AMT            --结息金额
 )PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT      t.CUST_NO                as CUST_NO                --客户号               
            ,t.CUST_NAME              as CUST_NAME              --客户姓名        
            ,a1.EXG_NAME              as EXG                    --交易所   
            ,t.SEC_CD                 as SEC_CD                 --证券代码
            ,t.SEC_NAME               as SEC_NAME               --证券名称
            ,a3.ZQLBMC                as SEC_CGY                --证券类别
            ,a4.CCY_CD_NAME           as CCY                    --币种
            ,t.QTY_GL                 as SEC_QTY                --证券数量
            ,t.MTCH_AMT               as GL_PRINP               --负债本金
            ,t.PRDCT_RTN_PRINP        as PRDCT_RTN_PRINP        --预计归还金额
            ,t.INTSETL_AMT            as INTSETL_AMT            --结息金额
 FROM         DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS       t
 LEFT JOIN    DDW_PROD.V_EXG                       a1
 ON           t.EXG = a1.EXG
 LEFT JOIN    EDW_PROD.T_EDW_T99_TZQLB             a3
 ON           t.SEC_CGY = a3.ZQLB 
 AND          a3.XTBS = 'JZJY' 
 AND          t.bus_date = a3.BUS_DATE
 LEFT JOIN    DDW_PROD.V_CCY_CD                    a4
 ON           t.CCY_CD = a4.CCY_CD
 WHERE        t.BUS_DATE = %d{yyyyMMdd}
 
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_ORDI_ACCNT_GL_DTL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_ORDI_ACCNT_GL_DTL;
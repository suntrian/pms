 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:员工新增存量客户资产表                                                                        */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-05-14                                                                       */ 
----存量客户资产
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_STFF_ADDED_STOCK_CUST_AST_TEMP  ;
 CREATE TABLE DDW_PROD.T_DDW_STFF_ADDED_STOCK_CUST_AST_TEMP
 as 
 SELECT      NVL(t.CUST_NO,a1.CUST_NO)           as CUST_NO
            ,NVL(t.TOT_AST,0)-NVL(a1.TOT_AST,0)  as TOT_AST_ADD
            ,NVL(t.TOT_AST,0)                    as TOT_AST_END
 FROM     (SELECT CUST_NO
                 ,NET_TOT_AST AS TOT_AST 
           FROM  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
		   WHERE BUS_DATE = %d{yyyyMMdd}
          )        t
 FULL JOIN  (SELECT CUST_NO
                   ,NET_TOT_AST AS TOT_AST 
             FROM  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY a
		     WHERE EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as TRD_DT
			                             FROM EDW_PROD.T_EDW_T99_TRD_DATE		  
			                             WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                             AND BUS_DATE = %d{yyyyMMdd}
										 )  b
					     WHERE a.BUS_DATE = b.TRD_DT
			 
			             )
            )        a1
 ON       t.CUST_NO = a1.CUST_NO
 ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_STFF_ADDED_STOCK_CUST_AST_TEMP1  ;
 CREATE TABLE DDW_PROD.T_DDW_STFF_ADDED_STOCK_CUST_AST_TEMP1
 as 
 SELECT      t.CUST_NO           as CUST_NO
            --,NVL(t.TOT_AST,0)-NVL(a1.TOT_AST,0)  as TOT_AST_ADD
            ,NVL(t.TOT_AST,0)    as TOT_AST_END
 FROM     DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY  t
 WHERE   t.BUS_DATE = %d{yyyyMMdd}
 ;
 
 
 
 
 ---------------------新增客户资产
-- DROP TABLE IF EXISTS DDW_PROD.T_DDW_STFF_ADDED_STOCK_CUST_AST_TEMP1  ;
-- CREATE TABLE DDW_PROD.T_DDW_STFF_ADDED_STOCK_CUST_AST_TEMP1
-- as 
-- SELECT      COALESCE(t.CUST_NO,a1.CUST_NO,a2.CUST_NO)           as CUST_NO
--            --,NVL(t.TOT_AST,0)-NVL(a1.TOT_AST,0)  as TOT_AST_ADD
--            ,NVL(t.TOT_AST,0)+NVL(a1.TOT_AST,0)+NVL(a2.TOT_AST,0)    as TOT_AST_END
-- FROM     (SELECT KHH as CUST_NO
--                 ,YMzzc as TOT_AST 
--           FROM  newcrm.DSC_STAT_T_STAT_KHZC_Y
--		   WHERE DT = SUBSTR('%d{yyyyMMdd}',1,6)
--          )        t
-- FULL JOIN     (SELECT KHH as CUST_NO
--                 ,zzc as TOT_AST 
--           FROM  newcrm.DSC_STAT_T_STAT_RZRQ_Y
--		   WHERE DT = SUBSTR('%d{yyyyMMdd}',1,6)
--          )        A1
-- ON       t.CUST_NO = a1.CUST_NO
-- FULL JOIN     (SELECT KHH as CUST_NO
--                 ,QMzzc as TOT_AST 
--           FROM  newcrm.DSC_STAT_T_STAT_GGQQ_Y
--		   WHERE DT = SUBSTR('%d{yyyyMMdd}',1,6)
--          )        A2
-- ON       NVL(t.CUST_NO,a1.CUST_NO) = a2.CUST_NO
-- ;
-- 

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_STFF_ADDED_STOCK_CUST_AST
(
		   BRH_NO                      --营业部编号
          ,BRH_NAME                    --营业部名称
          ,BELTO_FILIL                 --所属分公司
		  ,BELTO_FILIL_CDG	 	   	   --所属分公司编码
          ,PSN_NO                      --人员编码
          ,PSN_NAME                    --人员姓名
		  ,PSN_CGY                     --人员类别
          ,BRK_RLN_STOCK_CUST_AST	   --经纪关系存量客户资产
		  ,SVC_RLN_STOCK_CUST_AST	   --服务关系存量客户资产
)		
 PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT 
		   NVL(a1.JJRYYB,a2.YYB)                as BRH_NO               --营业部编号
          ,a3.brh_shrtnm                        as BRH_NAME             --营业部名称
          ,a3.BELTO_FILIL                       as BELTO_FILIL          --所属分公司
		  ,a3.BELTO_FILIL_CDG					as BELTO_FILIL_CDG	 	--所属分公司编码
          ,t.PSN_NO                             as PSN_NO               --人员编码
          ,NVL(a1.JJRXM,a2.RYXM)                as PSN_NAME             --人员姓名
          ,a4.PSN_CGY_NAME                      as PSN_CGY                     --人员类别
          ,SUM(CASE WHEN t.SVC_RLN_TP = '经纪关系'
		        AND  a5.ORDI_OPNAC_DT < CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-4,0),1,6),'01') as INT)
				THEN NVL(a7.TOT_AST_ADD,0)
				WHEN t.SVC_RLN_TP = '经纪关系'
				AND  SUBSTR(CAST(a5.ORDI_OPNAC_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-4,0),1,6)
				AND  NVL(a6.YXQRRQ,99999999) >   CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'31') as INT)
				THEN NVL(a8.TOT_AST_END,0)
				WHEN t.SVC_RLN_TP = '经纪关系'
				AND  SUBSTR(CAST(a5.ORDI_OPNAC_DT as STRING),1,6) BETWEEN SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-4,0),1,6) AND SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				AND  SUBSTR(CAST(NVL(a6.YXQRRQ,99999999) as STRING),1,6) BETWEEN SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-4,0),1,6) AND SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				THEN NVL(a7.TOT_AST_ADD,0)
				WHEN t.SVC_RLN_TP = '经纪关系'
				AND  SUBSTR(CAST(a5.ORDI_OPNAC_DT as STRING),1,6) BETWEEN SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-4,0),1,6) AND SUBSTR('%d{yyyyMMdd}',1,6)
				AND  SUBSTR(CAST(NVL(a6.YXQRRQ,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
				THEN NVL(a8.TOT_AST_END,0)
                ELSE 0
                END) 				            as BRK_RLN_STOCK_CUST_AST	   --经纪关系存量客户资产
		  ,SUM(CASE WHEN t.SVC_RLN_TP = '服务关系'
		        AND  a5.ORDI_OPNAC_DT < CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-4,0),1,6),'01') as INT)
				THEN NVL(a7.TOT_AST_ADD,0)
				WHEN t.SVC_RLN_TP = '服务关系'
				AND  SUBSTR(CAST(a5.ORDI_OPNAC_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-4,0),1,6)
				AND  NVL(a6.YXQRRQ,99999999) >   CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'31') as INT)
				THEN NVL(a7.TOT_AST_END,0)
				WHEN t.SVC_RLN_TP = '服务关系'
				AND  SUBSTR(CAST(a5.ORDI_OPNAC_DT as STRING),1,6) BETWEEN SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-4,0),1,6) AND SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				AND  SUBSTR(CAST(NVL(a6.YXQRRQ,99999999) as STRING),1,6) BETWEEN SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-4,0),1,6) AND SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
				THEN NVL(a7.TOT_AST_ADD,0)
				WHEN t.SVC_RLN_TP = '服务关系'
				AND  SUBSTR(CAST(a5.ORDI_OPNAC_DT as STRING),1,6) BETWEEN SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-4,0),1,6) AND SUBSTR('%d{yyyyMMdd}',1,6)
				AND  SUBSTR(CAST(NVL(a6.YXQRRQ,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
				THEN NVL(a7.TOT_AST_END,0)
                ELSE 0
                END)                               as SVC_RLN_STOCK_CUST_AST	   --服务关系存量客户资产
 FROM   (SELECT CUST_NO,BRK_NO as PSN_NO,'经纪关系' as SVC_RLN_TP,BRK_CGY as PSN_CGY
         FROM   DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN 
         WHERE  %d{yyyyMMdd} > = STATS_DT 
         AND      %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
	     AND     BUS_DATE = %d{yyyyMMdd}
         UNION ALL
         SELECT CUST_NO,PSN_NO as PSN_NO,'服务关系' as SVC_RLN_TP,PSN_CGY
         FROM DDW_PROD.T_DDW_F00_CUST_CUST_RLN
         WHERE    %d{yyyyMMdd} > = STATS_DT 
         AND      %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
         AND      BUS_DATE = %d{yyyyMMdd}
         AND       SVC_RLN_TP = '4'
		 )             t
 LEFT JOIN  EDW_PROD.T_EDW_T01_TJJR a1
 ON  		t.PSN_NO = a1.JJRBH
 AND  		a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  EDW_PROD.T_EDW_T01_TRYXX a2
 ON  		t.PSN_NO = a2.RYBH
 AND  		a2.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  DDW_PROD.T_DDW_INR_ORG_BRH              a3
 ON         NVL(a1.JJRYYB,a2.YYB)	 = a3.BRH_NO
 AND        a3.BUS_DATE =  %d{yyyyMMdd}
 LEFT JOIN  DDW_PROD.V_PSN_CGY                     a4
 ON         t.PSN_CGY = a4.PSN_CGY
 LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_INFO      a5
 ON         t.CUST_NO = a5.CUST_NO
 AND        a5.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  NEWCRM.CRMII_TKHXX                     a6
 ON        t.CUST_NO = a6.KHH
 LEFT JOIN  DDW_PROD.T_DDW_STFF_ADDED_STOCK_CUST_AST_TEMP  a7
 ON         t.CUST_NO = a7.CUST_NO
  LEFT JOIN  DDW_PROD.T_DDW_STFF_ADDED_STOCK_CUST_AST_TEMP1  a8
 ON         t.CUST_NO = a8.CUST_NO
 GROUP BY     BRH_NO        
             ,BRH_NAME      
             ,BELTO_FILIL
			 ,BELTO_FILIL_CDG
             ,PSN_NO        
             ,PSN_NAME      
             ,PSN_CGY      
 ;			 
  
 
-------
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_STFF_ADDED_STOCK_CUST_AST_TEMP  ;	
DROP TABLE IF EXISTS DDW_PROD.T_DDW_STFF_ADDED_STOCK_CUST_AST_TEMP1  ;	   

-----------------------------加载结束--------------------
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_STFF_ADDED_STOCK_CUST_AST',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ; 
invalidate metadata DDW_PROD.T_DDW_STFF_ADDED_STOCK_CUST_AST ; 
--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:资金明细业务科目表                                                                      */
  --/* 创建人:段智泓                                                                            */
  --/* 创建时间:2018-03-26
  

 
    ----插入数据--
   INSERT OVERWRITE DDW_PROD.T_DDW_CPTL_DTL_BIZ_SBJ_MOT 
 (          
              CUST_NO        --客户号  
			 ,ASBT           --摘要        
			 ,BIZ_SBJ        --业务科目   
 ) partition  (bus_date ) 
   SELECT  
              KHH        AS  CUST_NO
			 ,ZY         AS  ASBT
			 ,YWKM       AS  BIZ_SBJ
			 ,BUS_DATE   AS  BUS_DATE
  FROM        EDW_PROD.T_EDW_T05_TZJMXLS 
  WHERE       (YWKM LIKE '103%' OR  YWKM LIKE '104%' )
  AND         BUS_DATE = %d{yyyyMMdd}
 

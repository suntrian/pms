 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:营业部产品保有量月表                                                                     */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2019-04-11                                                                        */ 
  
----
 ---
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP as
 SELECT  a.SEC_CD
          ,SUM(a.SEC_QTY)         as SEC_QTY
		  ,SUM(a.SEC_MKTVAL)      as SEC_MKTVAL
		  ,a.BRH_NO
		  ,SUBSTR('%d{yyyyMMdd}',1,6) as YEAR_MON
   FROM  DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS  a
   LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE b
   ON    a.BUS_DATE = b.TRD_DT
   AND   b.BUS_DATE = %d{yyyyMMdd}
   INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH   c
   ON         a.BRH_NO = c.BRH_NO
   AND        c.BUS_DATE = %d{yyyyMMdd}
   WHERE SUBSTR(CAST(b.NAT_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
   AND   SUBSTR(a.SEC_CGY,1,1) = 'J'
   AND   a.CUST_NO < > '100610335855' 
   GROUP BY a.SEC_CD,a.BRH_NO,YEAR_MON ;
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP1 as
 SELECT  a.PROD_CD
          ,SUM(a.PROD_SHR_QTY)         as SEC_QTY
		  ,SUM(a.PROD_NEWST_MKTVAL)      as SEC_MKTVAL
		  ,a.BRH_NO
		  ,SUBSTR('%d{yyyyMMdd}',1,6) as YEAR_MON
   FROM  DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS  a
   LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE b
   ON    a.BUS_DATE = b.TRD_DT
   AND   b.BUS_DATE = %d{yyyyMMdd}
   INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH   c
   ON         a.BRH_NO = c.BRH_NO
   AND        c.BUS_DATE = %d{yyyyMMdd}
   WHERE SUBSTR(CAST(b.NAT_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
  -- AND   SUBSTR(a.SEC_CGY,1,1) = 'J'
   AND   a.CUST_NO < > '100610335855' 
   GROUP BY a.PROD_CD,a.BRH_NO,YEAR_MON ;
   
     DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP2 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP2 as
 SELECT COALESCE(a.ZQDM,b.CPDM,c.JJDM,d.CPDM)  as CPDM
        ,COALESCE(a.ZQMC,b.CPJP,c.JJMC,d.CPJC)  as CPMC
   FROM (SELECT ZQDM,ZQMC 
         FROM  EDW_PROD.T_EDW_T04_TZQDM 
         WHERE BUS_DATE = %d{yyyyMMdd}
         AND SUBSTR(ZQLB,1,1) = 'J'
        )		 a
   FULL JOIN EDW_PROD.T_EDW_T04_TFP_CPDM b
   ON    a.ZQDM = b.CPDM
   AND   b.BUS_DATE = %d{yyyyMMdd}
   FULL JOIN EDW_PROD.T_EDW_T04_TOF_JJXX c
   ON    NVL(a.ZQDM,b.CPDM) = c.JJDM
   AND   c.BUS_DATE = %d{yyyyMMdd}
   FULL JOIN EDW_PROD.T_EDW_T99_TJRCP_CPDM d
   ON    COALESCE(a.ZQDM,b.CPDM,c.JJDM) = d.CPDM
   AND   d.BUS_DATE = %d{yyyyMMdd}
   
 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP3 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP3 as
  SELECT  BELTO_FILIL_CDG            --分公司代码
          ,BELTO_FILIL                --分公司名称
		  ,BRH_NO 					--营业部编号
		  ,BRH_FULLNM                   --营业部名称
		  ,a1.SEC_CD
  FROM (SELECT 1 as ID,* FROM DDW_PROD.T_DDW_INR_ORG_BRH WHERE BUS_DATE = %d{yyyyMMdd}) t
  RIGHT JOIN  (SELECT DISTINCT SEC_CD,1 as ID
  FROM DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP
  UNION 
  SELECT DISTINCT PROD_CD  as SEC_CD,1 as ID
  FROM DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP1
  ) a1
  ON t.ID = a1.ID ;
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON
(                                BELTO_FILIL_CDG            --分公司代码
                                ,BELTO_FILIL                --分公司名称
								,BRH_NO 					--营业部编号
								,BRH_NAME                   --营业部名称
								,PROD_CD                    --产品代码
								,PROD_CD_NAME               --产品名称
							    ,PROD_QTY_AVG               --月日均产品数量
								,PROD_QTY_AMT               --月日均产品金额
)		
 PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT                     t.BELTO_FILIL_CDG
                           ,t.BELTO_FILIL
						   ,t.BRH_NO 					--营业部编号
						   ,t.BRH_FULLNM                   --营业部名称
					       ,t.SEC_CD  as PROD_CD                    --产品代码
						   ,a4.CPMC                  as PROD_CD_NAME               --产品名称
						   ,ROUND((NVL(a1.SEC_QTY,0)+NVL(a2.SEC_QTY,0))*1.0000/NVL(a3.NUM,9999),2) as PROD_QTY_AVG               --月日均产品数量
						   ,ROUND((NVL(a1.SEC_MKTVAL,0)+NVL(a2.SEC_MKTVAL,0))*1.0000/NVL(a3.NUM,9999),2) as PROD_QTY_AMT               --月日均产品金额
  FROM  		DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP3  t
  LEFT JOIN     DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP 	a1
  ON            t.BRH_NO = a1.BRH_NO
  AND           t.SEC_CD = a1.SEC_CD
  LEFT JOIN     DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP1 	a2
  ON            t.BRH_NO = a2.BRH_NO
  AND           t.SEC_CD = a2.PROD_CD
  
  LEFT JOIN (SELECT SUBSTR(CAST(NAT_DT as STRING),1,6) as YEAR_MON,COUNT(1) as NUM 
              FROM EDW_PROD.T_EDW_T99_TRD_DATE
			  WHERE BUS_DATE = %d{yyyyMMdd}
			  AND SUBSTR(CAST(NAT_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			  GROUP BY YEAR_MON
         )   a3
 ON      NVL(a1.YEAR_MON,a2.YEAR_MON) = a3.YEAR_MON
 LEFT JOIN DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP2  a4
 ON    t.SEC_CD = a4.CPDM
;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP1 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP2 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON_TEMP3 ;
-----------------------------加载结束--------------------
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_BRH_NO_PROD_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_BRH_NO_PROD_MON ; 
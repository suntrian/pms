-- /* ***************************************** SQL Begin ***************************************** */
--  /* 脚本功能:机构客户信息表                                                                      */
 -- /* 创建人:黄勇华                                                                              */
 -- /* 创建时间:2016-11-02                                                                        */ 
 TRUNCATE TABLE EDW_PROD.T_EDW_T01_TJGKHXX ; 
-----插入数据开始----
 INSERT OVERWRITE EDW_PROD.T_EDW_T01_TJGKHXX
 (
                                    KHH                                 --客户号                                
                                   ,YWMC                                --英文名称                               
                                   ,YGT_JGLB                            --一柜通机构类别                            
                                   ,ZBSXDM                              --资本属性代码                             
                                   ,GYSX                                --国有属性                               
                                   ,SSSXDM                              --上市属性代码                             
                                   ,FRLBDM                              --法人类别代码                             
                                   ,QYLBDM                              --企业类别代码                             
                                   ,HYLB                                --行业类别                               
                                   ,JGWZDZ                              --网站地址                               
                                   ,JGZCDZ                              --注册地址                               
                                   ,JGZCRQ                              --注册日期                               
                                   ,JGJYFW                              --经营范围                               
                                   ,JGZCZB                              --注册资本                               
                                   ,BZDM                                --注册币种                               
                                   ,JGZGB                               --总股本                                
                                   ,JGLTGB                              --流通股本                               
                                   ,SSGPDM_c                            --上市股票代码                             
                                   ,SSDD                                --上市地点                               
                                   ,YYZZNJRQ                            --营业执照年检日期                           
                                   ,ZZJGDM                              --组织机构代码证                            
                                   ,ZZJGDMQSRQ                          --组织机构代码证起始日期                        
                                   ,ZZJGDMJZRQ                          --组织机构代码证截止日期                        
                                   ,ZZJGDMFZJG                          --组织机构代码证发证机关                        
                                   ,ZZJGDMNJRQ                          --组织机构代码证年检日期                        
                                   ,ZZJGDMZJDZ                          --组织机构代码证证件地址                        
                                   ,GSSWDJZ                             --国税税务登记证                            
                                   ,GSSWDJZQSRQ                         --国税税务登记证起始日期                        
                                   ,GSSWDJZJZRQ                         --国税税务登记证截止日期                        
                                   ,GSSWDJZFZJG                         --国税税务登记证发证机关                        
                                   ,GSSWDJZNJRQ                         --国税税务登记证年检日期                        
                                   ,DSSWDJZ                             --地税税务登记证                            
                                   ,DSSWDJZQSRQ                         --地税税务登记证起始日期                        
                                   ,DSSWDJZJZRQ                         --地税税务登记证截止日期                        
                                   ,DSSWDJZFZJG                         --地税税务登记证发证机关                        
                                   ,DSSWDJZNJRQ                         --地税税务登记证年检日期                        
                                   ,FRDBXM                              --法定代表人姓名                            
                                   ,FRDBZJLBDM                          --法定代表人证件类别                          
                                   ,FRDBZJBH                            --法定代表人证件编号                          
                                   ,FRDBZJQSRQ                          --法定代表人证件起始日期                        
                                   ,FRDBZJJZRQ                          --法定代表人证件截止日期                        
                                   ,JBRXM                               --经办人姓名                              
                                   ,JBRZJLBDM                           --经办人证件类别                            
                                   ,JBRZJBH                             --经办人证件编号                            
                                   ,JBRZJQSRQ                           --经办人证件起始日期                          
                                   ,JBRZJJZRQ                           --经办人证件截止日期                          
                                   ,JBRDH                               --经办人电话                              
                                   ,JBRSJ                               --经办人手机                              
                                   ,JBRXBDM                             --经办人性别代码 
								   ,SMJJGLRBM                           --私募管理人编码
								   ,CPBZ                                --产品标志
                                   ,XTBS                            								   
 ) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.YWMC                                as YWMC                                --英文名称                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JGLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YGT_JGLB                            --机构类别                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZBSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZBSXDM                              --资本属性                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.GYSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as GYSX                                --国有属性                                
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.SSSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as SSSXDM                              --上市属性                                
                                   ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.FRLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as FRLBDM                              --法人类别                                
                                   ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.QYLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as QYLBDM                              --企业类别                                
                                   ,CAST(COALESCE(t7.MBDM,NULLIF(CONCAT('ERR',CAST(t.HYDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as HYLB                                --行业代码                                
                                   ,t.JGWZDZ                              as JGWZDZ                              --网站地址                                
                                   ,t.JGZCDZ                              as JGZCDZ                              --注册地址                                
                                   ,t.JGZCRQ                              as JGZCRQ                              --注册日期                                
                                   ,t.JGJYFW                              as JGJYFW                              --经营范围                                
                                   ,t.JGZCZB                              as JGZCZB                              --注册资本                                
                                   ,t.JGZCBZ                              as BZDM                                --注册币种                                
                                   ,t.JGZGB                               as JGZGB                               --总股本                                 
                                   ,t.JGLTGB                              as JGLTGB                              --流通股本                                
                                   ,t.SSGPDM                              as SSGPDM_c                            --上市股票代码                              
                                   ,t.SSDD                                as SSDD                                --上市地点                                
                                   ,t.YYZZNJRQ                            as YYZZNJRQ                            --营业执照年检日期                            
                                   ,t.ZZJGDM                              as ZZJGDM                              --组织机构代码证                             
                                   ,t.ZZJGDMQSRQ                          as ZZJGDMQSRQ                          --组织机构代码证起始日期                         
                                   ,t.ZZJGDMJZRQ                          as ZZJGDMJZRQ                          --组织机构代码证截止日期                         
                                   ,t.ZZJGDMFZJG                          as ZZJGDMFZJG                          --组织机构代码证发证机关                         
                                   ,t.ZZJGDMNJRQ                          as ZZJGDMNJRQ                          --组织机构代码证年检日期                         
                                   ,t.ZZJGDMZJDZ                          as ZZJGDMZJDZ                          --组织机构代码证证件地址                         
                                   ,t.GSSWDJZ                             as GSSWDJZ                             --国税税务登记证                             
                                   ,t.GSSWDJZQSRQ                         as GSSWDJZQSRQ                         --国税税务登记证起始日期                         
                                   ,t.GSSWDJZJZRQ                         as GSSWDJZJZRQ                         --国税税务登记证截止日期                         
                                   ,t.GSSWDJZFZJG                         as GSSWDJZFZJG                         --国税税务登记证发证机关                         
                                   ,t.GSSWDJZNJRQ                         as GSSWDJZNJRQ                         --国税税务登记证年检日期                         
                                   ,t.DSSWDJZ                             as DSSWDJZ                             --地税税务登记证                             
                                   ,t.DSSWDJZQSRQ                         as DSSWDJZQSRQ                         --地税税务登记证起始日期                         
                                   ,t.DSSWDJZJZRQ                         as DSSWDJZJZRQ                         --地税税务登记证截止日期                         
                                   ,t.DSSWDJZFZJG                         as DSSWDJZFZJG                         --地税税务登记证发证机关                         
                                   ,t.DSSWDJZNJRQ                         as DSSWDJZNJRQ                         --地税税务登记证年检日期                         
                                   ,t.FRDBXM                              as FRDBXM                              --法定代表人姓名                             
                                   ,CAST(COALESCE(t8.MBDM,NULLIF(CONCAT('ERR',CAST(t.FRDBZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                            as FRDBZJLBDM                          --法定代表人证件类别                           
                                   ,t.FRDBZJBH                            as FRDBZJBH                            --法定代表人证件编号                           
                                   ,t.FRDBZJQSRQ                          as FRDBZJQSRQ                          --法定代表人证件起始日期                         
                                   ,t.FRDBZJJZRQ                          as FRDBZJJZRQ                          --法定代表人证件截止日期                         
                                   ,t.JBRXM                               as JBRXM                               --经办人姓名                               
                                   ,CAST(COALESCE(t9.MBDM,NULLIF(CONCAT('ERR',CAST(t.JBRZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as JBRZJLBDM                           --经办人证件类别                             
                                   ,t.JBRZJBH                             as JBRZJBH                             --经办人证件编号                             
                                   ,t.JBRZJQSRQ                           as JBRZJQSRQ                           --经办人证件起始日期                           
                                   ,t.JBRZJJZRQ                           as JBRZJJZRQ                           --经办人证件截止日期                           
                                   ,t.JBRDH                               as JBRDH                               --经办人电话                               
                                   ,t.JBRSJ                               as JBRSJ                               --经办人手机                               
                                   ,CAST(COALESCE(t10.MBDM,NULLIF(CONCAT('ERR',CAST(t.JBRXB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as JBRXBDM                             --经办人性别 
                                   ,t.SMJJGLRBM                           as SMJJGLRBM                           --私募管理人编码
								   ,CASE WHEN a1.CUST_NO IS NOT NULL
								         THEN 1
										 ELSE t.CPBZ
										 END                              as CPBZ 
								   ,'YGT_GT'								   
 FROM           YGTCX.CIF_TJGKHXX                                 t
 LEFT JOIN      C5CX.FINEDB_IMPORT_PROD_CUST  a1--DDW_PROD.T_DDW_CFG_PB_CUST                                               a1
 ON             t.KHH = a1.CUST_NO
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING            t1 
 ON             t1.DMLX = 'YGT_JGLB'                              
 AND            t1.YXT = 'YGT_GT'                                 
 AND            t1.YDM = CAST(t.JGLB AS VARCHAR(20))              
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING            t2 
 ON             t2.DMLX = 'ZBSXDM'                                
 AND            t2.YXT = 'YGT_GT'                                 
 AND            t2.YDM = CAST(t.ZBSX AS VARCHAR(20))              
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING            t3 
 ON             t3.DMLX = 'GYSX'                                  
 AND            t3.YXT = 'YGT_GT'                                 
 AND            t3.YDM = CAST(t.GYSX AS VARCHAR(20))              
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING            t4 
 ON             t4.DMLX = 'SSSXDM'                                
 AND            t4.YXT = 'YGT_GT'                                 
 AND            t4.YDM = CAST(t.SSSX AS VARCHAR(20))              
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING            t5 
 ON             t5.DMLX = 'FRLBDM'                                
 AND            t5.YXT = 'YGT_GT'                                 
 AND            t5.YDM = CAST(t.FRLB AS VARCHAR(20))              
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING            t6 
 ON             t6.DMLX = 'QYLBDM'                                
 AND            t6.YXT = 'YGT_GT'                                 
 AND            t6.YDM = CAST(t.QYLB AS VARCHAR(20))              
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING            t7 
 ON             t7.DMLX = 'HYLB'                                  
 AND            t7.YXT = 'YGT_GT'                                 
 AND            t7.YDM = CAST(t.HYDM AS VARCHAR(20))              
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING            t8 
 ON             t8.DMLX = 'ZJLBDM'
 AND            t8.YXT = 'YGT_GT'
 AND            t8.YDM = CAST(t.FRDBZJLB AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING            t9 
 ON             t9.DMLX = 'ZJLBDM'                                
 AND            t9.YXT = 'YGT_GT'                                 
 AND            t9.YDM = CAST(t.JBRZJLB AS VARCHAR(20))           
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING            t10 
 ON             t10.DMLX = 'XBDM'
 AND            t10.YXT = 'YGT_GT'
 AND            t10.YDM = CAST(t.JBRXB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}' ;
---插入数据结束 ----
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TJGKHXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

invalidate metadata EDW_PROD.T_EDW_T01_TJGKHXX;

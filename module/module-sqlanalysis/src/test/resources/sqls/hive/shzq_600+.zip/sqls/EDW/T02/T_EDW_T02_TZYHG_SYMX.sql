 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:质押回购顺延明细表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZYHG_SYMX ;
----插入数据开始-------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZYHG_SYMX
(
                                    ZYHGBH                             --质押回购编号                             
                                   ,XYBH                                --协议编码                               
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期                               
                                   ,YYJGHRQ                             --预计购回日期                             
                                   ,YGHJG                               --购回价格                               
                                   ,YGHJE                               --购回金额                               
                                   ,YDYSZ                               --抵押市值 
                                   ,SYFS                                --顺延方式								   
                                   ,XTBS                           								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.BH                                  as YDGH_BH                             --编码                                  
                                   ,t.XYBH                                as XYBH                                --协议编码                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.KSRQ                                as KSRQ                                --开始日期                                
                                   ,t.JSRQ                                as JSRQ                                --结束日期                                
                                   ,t.YYJGHRQ                             as YYJGHRQ                             --预计购回日期                              
                                   ,t.YGHJG                               as YGHJG                               --购回价格                                
                                   ,t.YGHJE                               as YGHJE                               --购回金额                                
                                   ,t.YDYSZ                               as YDYSZ                               --抵押市值     
                                   ,t.SYFS                                as SYFS  						         --顺延方式		   
								   ,'JZJY'                                as XTBS
 FROM    		JZJYCX.SECURITIES_TZYHG_SYMX t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'JZJY'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束-----------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZYHG_SYMX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

invalidate metadata EDW_PROD.T_EDW_T02_TZYHG_SYMX;
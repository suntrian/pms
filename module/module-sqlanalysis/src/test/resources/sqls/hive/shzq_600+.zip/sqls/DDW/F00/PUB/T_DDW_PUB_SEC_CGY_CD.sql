------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:证券类别代码表                                                                 */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
TRUNCATE TABLE DDW_PROD.T_DDW_PUB_SEC_CGY_CD ;
INSERT OVERWRITE DDW_PROD.T_DDW_PUB_SEC_CGY_CD
(
                                     EXG                     --交易所        
                                    ,SEC_CGY                 --证券类别   
                                    ,SEC_CGY_NAME            --证券类别名称  							                                   								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT         t.JYS	         as EXG                     --交易所                             
               ,t.ZQLB           as SEC_CGY                 --证券类别   
               ,t.ZQLBMC         as SEC_CGY_NAME            --证券类别名称                                        						    
 FROM           EDW_PROD.T_EDW_T99_TZQLB                                 t       
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
 UNION ALL
 SELECT         DECODE(t.SECUMARKET,83,'SH',90,'SZ')	         as EXG                     --交易所                             
               ,CASE WHEN t.BONDNATURE BETWEEN 0 AND 9
      			     THEN CONCAT('Z0',CAST(t.BONDNATURE as STRING))
                     ELSE CONCAT('Z',CAST(t.BONDNATURE as STRING))	
                     END					                     as SEC_CGY                 --证券类别   
               ,a1.MS                                            as SEC_CGY_NAME            --证券类别名称 
 FROM          FUNDEXT.DBO_BOND_CODE       t
 LEFT JOIN     FUNDEXT.DBO_CT_SYSTEMCONST  a1
 ON            t.DT = a1.DT
 AND           a1.LB = 1243
 AND           t.BONDNATURE = a1.DM 
 --AND           t.SECUMARKET IN (83,90)
 WHERE         t.DT = '%d{yyyyMMdd}'
 AND           t.SECUMARKET IN (83,90)
 GROUP BY EXG,SEC_CGY,SEC_CGY_NAME
 UNION ALL
 SELECT         CASE WHEN SUBSTR(t.SecurityCode,1,3) IN ('500','501','502','505','506','519','510','511','512','513','518','515')
                     THEN 'SH'
					 WHEN (SUBSTR(t.SecurityCode,1,3) IN ('150','151','159','184') OR SUBSTR(t.SecurityCode,1,2) = '16')
					 THEN 'SZ'
					 END                                        as EXG                     --交易所                             
               ,CONCAT('J0',CAST(t.TYPE as STRING))			as SEC_CGY                 --证券类别   
               ,a1.MS                                           as SEC_CGY_NAME            --证券类别名称 
 FROM          FUNDEXT.dbo_MF_FundArchives          t
 LEFT JOIN     FUNDEXT.DBO_CT_SYSTEMCONST           a1
 ON            t.DT = a1.DT
 AND           a1.LB = 1210
 AND           t.TYPE = a1.DM
 WHERE         t.DT = '%d{yyyyMMdd}' 
 AND  SUBSTR(t.SecurityCode,1,3) IN ('500','501','502','505','506','519','510','511','512','513','518','150','151','159','184','160','161','162','163','164','165','166','167','168','169','515')
 GROUP BY EXG,SEC_CGY,SEC_CGY_NAME
 ;		
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_SEC_CGY_CD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_SEC_CGY_CD ;

-- /* ***************************************** SQL Begin ***************************************** */
 -- /* 脚本功能:人员信息表                                                                  */
  --/* 创建人:段智泓                                                                              */
  --/* 创建时间:2018-05-11  


TRUNCATE TABLE EDW_PROD.T_EDW_T01_TRYXX;

---插入数据开始------------
INSERT OVERWRITE EDW_PROD.T_EDW_T01_TRYXX
(
                                        ID                     --主键
                                       ,RYXM                   --人员姓名
                                       ,RYBH                   --人员编号
                                       ,ZBXZ                   --在编性质
                                       ,RYZHZT                 --账户状态
                                       ,RYLB                   --人员类别
                                       ,QYHT                   --签约合同类型
                                       ,RYHGBZ                 --合规标志
                                       ,KHRQ                   --开户日期
                                       ,RZRQ                   --入职日期
                                       ,LZRQ                   --离职日期
                                       ,TBTS                   --特别提示
                                       ,YYB                  --营业部
                                       ,DYYH                   --对应用户
                                       ,DLQX                   --代理权限
                                       ,HDFW                   --活动范围
                                       ,KSKM                   --考试科目
                                       ,ZYZG                   --职业资格
                                       ,ZJLBDM                 --证件类别
									   ,ZJBH                   --证件编号
									   ,SJ                     --手机
									   ,DH                     --电话号码
                                       ,EMAIL                  --邮箱
                                       ,MSN                    --MSN
                                       ,QQ                     --QQ
                                       ,LXDZ                   --联系地址
                                       ,JTDZ                   --家庭地址
                                       ,YZBM                   --邮政编码
                                       ,BYYX                   --毕业院校
                                       ,BYSJ                   --毕业时间
                                       ,XLDM                   --学历
                                       ,XWDM                   --学位
                                       ,XZ                     --学制
                                       ,XXZY                   --专业信息
                                       ,XBDM                   --性别
                                       ,CSRQ                   --出生日期
                                       ,TC                     --特长
                                       ,MZDM                   --名族
                                       ,JG                     --籍贯
                                       ,HYZKDM                 --婚姻状况
                                       ,ZZMM                   --政治面貌
                                       ,GJDM                   --国籍
                                       ,PROVINCE               --省份
                                       ,CITY                   --城市
                                       ,SEC                    --所属辖区
                                       ,PYDM                   --拼音代码
                                       ,GRJL                   --个人经历
                                       ,GRJJ                   --个人简历
									   ,XTBS
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT                    
                                        t.ID                as ID                     --主键
                                       ,t.RYXM              as RYXM                   --人员姓名
                                       ,NVL(a1.JJRBH,t.RYBH) as RYBH                   --人员编号
                                       ,t.ZBXZ              as ZBXZ                   --在编性质
                                       ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20))              as RYZHZT                   --账户状态
                                       ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.RYLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))              as RYLB                     --人员类别
                                       ,t.QYHT              as HTLX                     --签约合同类型
                                       ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.HGBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20))              as RYHGBZ                   --合规标志
                                       ,t.KHRQ              as KHRQ                   --开户日期
                                       ,t.RZRQ              as RZRQ                   --入职日期
                                       ,t.LZRQ              as LZRQ                   --离职日期
                                       ,t.TBTS              as TBTS                   --特别提示
                                       ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.ORGID AS VARCHAR(20))),'ERR')) AS VARCHAR(20))             as ORGID                  --营业部
                                       ,t.DYYH              as DYYH                   --对应用户
                                       ,t.DLQX              as DLQX                   --代理权限
                                       ,t.HDFW              as HDFW                   --活动范围
                                       ,t.KSKM              as KSKM                   --考试科目
                                       ,t.ZYZG               as ZYZG                     --职业资格
                                       ,CAST(COALESCE(t8.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))              as ZJLBDM                   --证件类别
									   ,t.ZJBH              as ZJBH                   --证件编号
									   ,a2.SJ                as SJ                     --手机
									   ,a2.DH                as DH                     --电话号码
                                       ,a2.EMAIL             as EMAIL                  --邮箱
                                       ,a2.MSN               as MSN                    --MSN
                                       ,a2.QQ                as QQ                     --QQ
                                       ,a2.LXDZ              as LXDZ                   --联系地址
                                       ,a2.JTDZ              as JTDZ                   --家庭地址
                                       ,a2.YZBM              as YZBM                   --邮政编码
                                       ,a2.BYYX              as BYYX                   --毕业院校
                                       ,a2.BYSJ              as BYSJ                   --毕业时间
                                       ,CAST(COALESCE(t9.MBDM,NULLIF(CONCAT('ERR',CAST(a2.XL AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                 as XLDM                     --学历
                                       ,CAST(COALESCE(t10.MBDM,NULLIF(CONCAT('ERR',CAST(a2.XW AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                as XWDM                     --学位
                                       ,a2.XZ                as XZ                     --学制
                                       ,a2.XXZY              as XXZY                   --专业信息
                                       ,CAST(COALESCE(t11.MBDM,NULLIF(CONCAT('ERR',CAST(a2.XB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                as XBDM                     --性别
                                       ,a2.CSRQ              as CSRQ                   --出生日期
                                       ,a2.TC                as TC                     --特长
                                       ,CAST(COALESCE(t12.MBDM,NULLIF(CONCAT('ERR',CAST(a2.MZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                as MZDM                     --名族
                                       ,a2.JG                as JG                     --籍贯
                                       ,CAST(COALESCE(t13.MBDM,NULLIF(CONCAT('ERR',CAST(a2.HYZK AS VARCHAR(20))),'ERR')) AS VARCHAR(20))              as HYZKDM                   --婚姻状况
                                       ,CAST(COALESCE(t14.MBDM,NULLIF(CONCAT('ERR',CAST(a2.ZZMM AS VARCHAR(20))),'ERR')) AS VARCHAR(20))              as ZZMM                   --政治面貌
                                       ,CAST(COALESCE(t15.MBDM,NULLIF(CONCAT('ERR',CAST(a2.GJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                as GJDM                     --国籍
                                       ,a2.PROVINCE          as PROVINCE               --省份
                                       ,a2.CITY              as CITY                   --城市
                                       ,a2.SEC               as SEC                    --所属辖区
                                       ,t.PYDM              as PYDM                   --拼音代码
                                       ,a2.GRJL              as GRJL                   --个人经历
                                       ,a2.GRJJ              as GRJJ                   --个人简历
									   ,'CRM'          as XTBS
 FROM           C5CX.CIS_TRYXX t
 LEFT JOIN      C5CX.CIS_TRYXX_BJXX a2
 ON             t.ID = a2.RYXX
 AND            a2.DT = '%d{yyyyMMdd}'
 LEFT JOIN      NEWCRM.CRMII_TJJR  a1
 ON             a1.DT = '%d{yyyyMMdd}'
 AND            a1.KHRQ < = %d{yyyyMMdd}
 AND            NVL(a1.XHRQ,99999999) > %d{yyyyMMdd}
 AND            a1.RYXXID IS NOT NULL
 AND            t.ID = a1.RYXXID
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'CRM'
 AND            t1.JGDM = CAST(t.ORGID AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t2
 ON             t2.YXT = 'CRM'
 AND            t2.YDM = CAST(t.ZHZT AS VARCHAR(20))
 AND            t2.dmlx = 'RYZHZT'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t3
 ON             t3.YXT = 'CRM'
 AND            t3.YDM = CAST(NVL(a1.JJRLB,t.RYLB) AS VARCHAR(20))
 AND            t3.dmlx = 'RYLB'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t5
 ON             t5.YXT = 'CRM'
 AND            t5.YDM = CAST(t.HGBZ AS VARCHAR(20))
 AND            t5.dmlx = 'RYHGBZ'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t6
 ON             t6.YXT = 'CRM'
 AND            t6.YDM = CAST(t.KSKM AS VARCHAR(20))
 AND            t6.dmlx = 'CYKSKM'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t7
 ON             t7.YXT = 'CRM'
 AND            t7.YDM = CAST(t.ZYZG AS VARCHAR(20))
 AND            t7.dmlx = 'CYZG'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t8
 ON             t8.YXT = 'CRM'
 AND            t8.YDM = CAST(t.ZJLB AS VARCHAR(20))
 AND            t8.dmlx = 'ZJLBDM'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t9
 ON             t9.YXT = 'CRM'
 AND            t9.YDM = CAST(a2.XL AS VARCHAR(20))
 AND            t9.dmlx = 'XLDM'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t10
 ON             t10.YXT = 'CRM'
 AND            t10.YDM = CAST(a2.XW AS VARCHAR(20))
 AND            t10.dmlx = 'XWDM'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t11
 ON             t11.YXT = 'CRM'
 AND            t11.YDM = CAST(a2.XB AS VARCHAR(20))
 AND            t11.dmlx = 'XBDM'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t12
 ON             t12.YXT = 'CRM'
 AND            t12.YDM = CAST(a2.MZ AS VARCHAR(20))
 AND            t12.dmlx = 'MZDM'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t13
 ON             t13.YXT = 'CRM'
 AND            t13.YDM = CAST(a2.HYZK AS VARCHAR(20))
 AND            t13.dmlx = 'HYZKDM'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t14
 ON             t14.YXT = 'CRM'
 AND            t14.YDM = CAST(a2.ZZMM AS VARCHAR(20))
 AND            t14.dmlx = 'ZZMM'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t15
 ON             t15.YXT = 'CRM'
 AND            t15.YDM = CAST(a2.GJ AS VARCHAR(20))
 AND            t15.dmlx = 'GJDM'
 WHERE          t.DT = '%d{yyyyMMdd}';
----插入数据结束------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TRYXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T01_TRYXX;
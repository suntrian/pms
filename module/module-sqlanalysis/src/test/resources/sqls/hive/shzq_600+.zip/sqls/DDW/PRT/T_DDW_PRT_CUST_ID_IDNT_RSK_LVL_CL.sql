 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:客户身份识别及风险等级分类表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2019-02-14                                                                       */ 

  INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CUST_ID_IDNT_RSK_LVL_CL
(
								 BRH_NO 					--营业部编号
								,BRH_FULLNM                 --营业部名称
								,BELTO_FILIL_CDG            --地区
								,BELTO_FILIL                --地区名称
								,PRJ                        --项目
								,IDV_CUST                   --自然人客户
								,ORG_CUST                   --机构客户
								,ETL_DT                     --加载日期     
)		
 PARTITION(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT))
  
  SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL               
		 ,'年末客户数' as PRJ
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		 ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  WHERE t.ORDI_CUST_STAT < > '3' 
  AND  t.BUS_DATE = %d{yyyyMMdd}
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL
  UNION ALL
   SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'当年新增客户数' as PRJ
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
 UNION ALL
     SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'当年新增客户数' as PRJ
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    SUBSTR(CAST(t.ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
  UNION ALL
   SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'当年销户数' as PRJ
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    SUBSTR(CAST(t.ORDI_CNCLACT_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
  UNION ALL
    SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'初次识别客户数' as PRJ
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    SUBSTR(CAST(t.ORDI_OPNAC_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
  UNION ALL
  SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'中止服务客户数' as PRJ		 
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN YGTCX.CIF_TKHFXXMKZ     a2
  ON        t.CUST_NO = a2.KHH
  AND       a2.CZRQ < = %d{yyyyMMdd}
  AND       a2.FXXM = 1
  AND       a2.DT = '%d{yyyyMMdd}'
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    t.ORDI_CUST_STAT = '0' 
  AND    t.CUST_RSK_LVL IN ('0','1','2','8','19')
  AND    t.CTF_EXPR_DT IS NOT NULL
  AND    t.CTF_EXPR_DT < = %d{yyyyMMdd}
  AND   CONCAT(';',CTRL_ATTR,';',NVL(a2.KZSX,';'),';') LIKE '%;2;%'
  AND   CONCAT(';',CTRL_ATTR,';',NVL(a2.KZSX,';'),';') LIKE '%;4;%'
  AND   CONCAT(';',CTRL_ATTR,';',NVL(a2.KZSX,';'),';') LIKE '%;5;%'
  AND   CONCAT(';',CTRL_ATTR,';',NVL(a2.KZSX,';'),';') LIKE '%;6;%'
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
  UNION ALL
  
   SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'限制功能客户数' as PRJ		 
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN YGTCX.CIF_TKHFXXMKZ     a2
  ON        t.CUST_NO = a2.KHH
  AND       a2.CZRQ < = %d{yyyyMMdd}
  AND       a2.FXXM = 1
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    t.ORDI_CUST_STAT = '0' 
  AND    t.CUST_RSK_LVL IN ('0','1','2','8','19')
  AND    LENGTH(TRIM(T.CTRL_ATTR)) > 0
  AND    (t.CTF_EXPR_DT IS  NULL
  OR     t.CTF_EXPR_DT > %d{yyyyMMdd}
  OR  CONCAT(';',CTRL_ATTR,';',NVL(a2.KZSX,';'),';') NOT LIKE '%;2;%'
  OR   CONCAT(';',CTRL_ATTR,';',NVL(a2.KZSX,';'),';') NOT LIKE '%;4;%'
  OR   CONCAT(';',CTRL_ATTR,';',NVL(a2.KZSX,';'),';') NOT LIKE '%;5;%'
  OR   CONCAT(';',CTRL_ATTR,';',NVL(a2.KZSX,';'),';') NOT LIKE '%;6;%'
  )
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
  
  UNION ALL
  SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'高风险人数' as PRJ		 
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
 
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    t.ORDI_CUST_STAT < > '3' 
  AND    t.CUST_RSK_LVL IN ('0','1','2','8','19')
  AND    t.M_LAUND_RSK_LVL = '4'
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
  UNION ALL
   SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'高风险变动次数' as PRJ		 
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  INNER JOIN (SELECT CUST_NO FROM  DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS 
             WHERE (ABST like('%->高风险%') OR ABST like('%:高风险%'))
			 AND SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
             )a2
  ON         t.CUST_NO = a2.CUST_NO
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    t.CUST_RSK_LVL IN ('0','1','2','8','19')
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
  UNION ALL 
    SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'较高风险人数' as PRJ		 
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
 
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    t.ORDI_CUST_STAT < > '3'  
  AND    t.CUST_RSK_LVL IN ('0','1','2','8','19')
  AND    t.M_LAUND_RSK_LVL = '3'
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
  UNION ALL
  
     SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'较高风险变动' as PRJ		 
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  INNER JOIN (SELECT CUST_NO FROM  DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS 
             WHERE (ABST like('%较高风险%') )
			 AND SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
             )a2
  ON         t.CUST_NO = a2.CUST_NO
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    t.CUST_RSK_LVL IN ('0','1','2','8','19')
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
  UNION ALL
  
     SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'中风险人数' as PRJ		 
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
 
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    t.ORDI_CUST_STAT < > '3'  
  AND    t.CUST_RSK_LVL IN ('0','1','2','8','19')
  AND    t.M_LAUND_RSK_LVL = '2'
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
  UNION ALL
     SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'中风险变动' as PRJ		 
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  INNER JOIN (SELECT CUST_NO FROM  DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS 
             WHERE (ABST like('%中风险%') )
			 AND SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
             )a2
  ON         t.CUST_NO = a2.CUST_NO
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    t.CUST_RSK_LVL IN ('0','1','2','8','19')
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
  UNION ALL
  
  
  
       SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'低风险人数' as PRJ		 
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
 
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    t.ORDI_CUST_STAT < > '3' 
  AND    t.CUST_RSK_LVL IN ('0','1','2','8','19')
  AND    t.M_LAUND_RSK_LVL = '1'
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  
  UNION ALL
     SELECT a1.BRH_NO
	     ,a1.BRH_FULLNM
	     ,a1.BELTO_FILIL_CDG
		 ,a1.BELTO_FILIL 
		 ,'低风险变动' as PRJ		 
         ,SUM(DECODE(CUST_CGY,'0',1,0))   as IDV_CUST  --自然人客户
		 ,SUM(DECODE(CUST_CGY,'1',1,0))   as ORG_CUST  --机构客户
		  ,%d{yyyyMMdd}        as ETL_DT
  FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1
  ON         t.BRH_NO = a1.BRH_NO
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  INNER JOIN (SELECT CUST_NO FROM  DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS 
             WHERE (ABST like('%低风险%') )
			 AND SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
             )a2
  ON         t.CUST_NO = a2.CUST_NO
  WHERE   t.BUS_DATE = %d{yyyyMMdd}
  AND    t.CUST_RSK_LVL IN ('0','1','2','8','19')
  GROUP BY PRJ,BRH_NO,BRH_FULLNM,BELTO_FILIL_CDG,BELTO_FILIL  ;
  
  
  INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_CUST_ID_IDNT_RSK_LVL_CL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_CUST_ID_IDNT_RSK_LVL_CL ;
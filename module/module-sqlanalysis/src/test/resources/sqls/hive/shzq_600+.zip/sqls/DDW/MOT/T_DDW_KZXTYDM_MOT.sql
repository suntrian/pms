--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:监控系统源代码更新与更改或者新增                                                                             */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2017-1-11                                                                           */  

 INSERT OVERWRITE DDW_PROD.T_DDW_KZXTYDM_MOT
 (
                                    DMQK                                      --代码情况
                                   ,DMLX                                      --代码类型
                                   ,BM                                        --编码
                                   ,FLMC                                      --代码类型名称
								   ,XTBS                                      --系统标识								   
 ) PARTITION( bus_date = %d{yyyyMMdd})
 SELECT  CASE WHEN t1.FLDM IS NULL
              THEN '代码新增'
              WHEN t.FLDM IS NULL 
              THEN '代码减少'
			  WHEN t.BMSM<> t1.BMSM 
			  THEN '代码更新'
			  END                as DMQK
		,NVL(t.FLDM,t1.FLDM)     as DMLX
		,NVL(t.BM,t1.BM)         as BM
		,NVL(t.FLMC,t1.FLMC)     as FLMC
		,'JZJY'                  as XTBS
 FROM         (SELECT * FROM JZJYCX.ABOSS_TXTDM WHERE DT = '%d{yyyyMMdd}')    t
 FULL JOIN    (SELECT * FROM JZJYCX.ABOSS_TXTDM 
                        WHERE CAST(DT AS INT) = (SELECT MAX(LST_TRD_D) 
						             FROM  EDW_PROD.T_EDW_T99_TRD_DATE  
									 WHERE NAT_DT =  %d{yyyyMMdd}
									 ) 
               )									 t1
 ON     t.FLDM = t1.FLDM
 AND    t.FLMC = t1.FLMC
 AND    t.BM = t1.BM
 WHERE (t1.FLDM IS NULL OR t.FLDM IS NULL OR  t.BMSM<> t1.BMSM)
 UNION ALL
  SELECT  CASE WHEN t1.FLDM IS NULL
              THEN '代码新增'
              WHEN t.FLDM IS NULL 
              THEN '代码减少'
			  WHEN t.BMSM<> t1.BMSM 
			  THEN '代码更新'
			  END                as DMQK
		,NVL(t.FLDM,t1.FLDM)     as DMLX
		,NVL(t.BM,t1.BM)         as BM
		,NVL(t.FLMC,t1.FLMC)     as FLMC
		,'RZRQ'                  as XTBS
 FROM         (SELECT * FROM RZRQCX.ABOSS_TXTDM WHERE DT = '%d{yyyyMMdd}')    t
 FULL JOIN    (SELECT * FROM RZRQCX.ABOSS_TXTDM 
                        WHERE CAST(DT AS INT) = (SELECT MAX(LST_TRD_D) 
						             FROM  EDW_PROD.T_EDW_T99_TRD_DATE  
									 WHERE NAT_DT =  %d{yyyyMMdd}
									 )  
              )									 t1
 ON     t.FLDM = t1.FLDM
 AND    t.FLMC = t1.FLMC
 AND    t.BM = t1.BM
 WHERE (t1.FLDM IS NULL OR t.FLDM IS NULL OR  t.BMSM<> t1.BMSM)
 UNION ALL
  SELECT  CASE WHEN t1.FLDM IS NULL
              THEN '代码新增'
              WHEN t.FLDM IS NULL 
              THEN '代码减少'
			  WHEN t.BMSM<> t1.BMSM 
			  THEN '代码更新'
			  END                as DMQK
		,NVL(t.FLDM,t1.FLDM)     as DMLX
		,NVL(CAST(t.BM AS STRING),CAST(t1.BM AS STRING)) as BM
		,NVL(t.FLMC,t1.FLMC)     as FLMC
		,'GGQQ'                  as XTBS
 FROM         (SELECT * FROM GGQQCX.ABOSS_TXTDM WHERE DT = '%d{yyyyMMdd}')    t
 FULL JOIN    (SELECT * FROM GGQQCX.ABOSS_TXTDM 
                        WHERE CAST(DT AS INT) = (SELECT MAX(LST_TRD_D) 
						             FROM  EDW_PROD.T_EDW_T99_TRD_DATE  
									 WHERE NAT_DT =  %d{yyyyMMdd}
									 )
               )									 t1
 ON     t.FLDM = t1.FLDM
 AND    t.FLMC = t1.FLMC
 AND    t.BM = t1.BM
 WHERE (t1.FLDM IS NULL OR t.FLDM IS NULL OR  t.BMSM<> t1.BMSM)
  UNION ALL
  SELECT  CASE WHEN t1.FLDM IS NULL
              THEN '代码新增'
              WHEN t.FLDM IS NULL 
              THEN '代码减少'
			  WHEN t.NOTE<> t1.NOTE 
			  THEN '代码更新'
			  END                as DMQK
		,NVL(t.FLDM,t1.FLDM)     as DMLX
		,NVL(CAST(t.IBM AS STRING),CAST(t1.IBM AS STRING))       as BM
		,NVL(t.FLMC,t1.FLMC)     as FLMC
		,'YGT'                   as XTBS
 FROM         (SELECT * FROM YGTCX.CIF_TXTDM WHERE DT = '%d{yyyyMMdd}')    t
 FULL JOIN    (SELECT * FROM YGTCX.CIF_TXTDM 
                        WHERE CAST(DT AS INT) = (SELECT MAX(LST_TRD_D) 
						             FROM  EDW_PROD.T_EDW_T99_TRD_DATE  
									 WHERE NAT_DT =  %d{yyyyMMdd}
									 )   
              )                                     t1
 ON     t.FLDM = t1.FLDM
 AND    t.FLMC = t1.FLMC
 AND    t.IBM = t1.IBM
 WHERE (t1.FLDM IS NULL OR t.FLDM IS NULL OR  t.NOTE<> t1.NOTE)
 ;
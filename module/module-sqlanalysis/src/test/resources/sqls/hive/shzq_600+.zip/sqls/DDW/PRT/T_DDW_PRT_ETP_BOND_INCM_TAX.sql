 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:企债所得税报表                                                                */
  --/* 创建人:OYJ                                                                              */
  --/* 创建时间:2018-10-26                                                                       */

-------------------------------删除今天的数据------------------------------
ALTER TABLE DDW_PROD.T_DDW_PRT_ETP_BOND_INCM_TAX DROP IF EXISTS PARTITION   (BUS_DATE = %d{yyyyMMdd});


INSERT OVERWRITE DDW_PROD.T_DDW_PRT_ETP_BOND_INCM_TAX
(
 CUST_NO     --客户号
,CUST_NM     --客户姓名
,BRH_NO      --营业部编号
,BRH_NM      --营业部名称
,CTF_CGY     --证件类别
,CTF_CGY_NM  --证件类别名称
,CTF_NO      --证件编号
,PHONE       --手机
,CTCT_TEL    --联系电话
,EXG         --交易所
,DVID_AMT    --派息金额
,DEDU_TAX    --扣税金额
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT 
        T.KHH
	   ,T.KHXM
	   ,T.YYB
	   ,T.MBJGQC
	   ,T.CTF_CGY_CD
	   ,T.CTF_CGY_CD_NAME
	   ,T.CTF_NO
	   ,T.PHONE
	   ,T.CTCT_TEL
	   ,T.ZJLY
	   ,CASE WHEN T.DVID_AMT = 0 THEN T.DEDU_TAX * 5
	         WHEN T.DVID_AMT > T.DEDU_TAX * 5 THEN T.DEDU_TAX * 5
	    ELSE T.DVID_AMT END AS DVID_AMT
	   ,T.DEDU_TAX
FROM(
SELECT 
        T1.KHH
	   ,T1.KHXM
	   ,T1.YYB
	   ,T3.MBJGQC
	   ,T2.CTF_CGY_CD
	   ,T4.CTF_CGY_CD_NAME
	   ,T2.CTF_NO
	   ,T2.PHONE
	   ,T2.CTCT_TEL
	   ,T1.ZJLY
	   ,CAST(SUM(T1.SRJE) AS DECIMAL(12,2)) AS DVID_AMT
	   ,CAST(SUM(T1.FCJE) AS DECIMAL(12,2)) AS DEDU_TAX
FROM EDW_PROD.T_EDW_T05_TZJMXLS T1
LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO T2
ON T1.KHH = T2.CUST_NO
AND T2.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING T3
ON T3.JGDM = CAST(T1.YYB AS VARCHAR(20))
AND T3.YXT = 'JZJY'
LEFT JOIN DDW_PROD.V_CTF_CGY_CD T4
ON T2.CTF_CGY_CD = T4.CTF_CGY_CD
WHERE T1.RQ  = %d{yyyyMMdd}
AND T1.XTBS IN ('JZJY','RZRQ')
AND T1.YWKM IN ('13202','10705','13154')
AND T3.MBJGQC like '%上海%'
AND exists(select 1 from EDW_PROD.T_EDW_T05_TZJMXLS T5 WHERE T1.RQ = T5.RQ AND T5.YWKM = '10705' AND T1.XGPZ = T5.XGPZ AND T1.KHH = T5.KHH)
GROUP BY  
        T1.KHH
	   ,T1.KHXM
	   ,T1.YYB
	   ,T3.MBJGQC
	   ,T2.CTF_CGY_CD
	   ,T4.CTF_CGY_CD_NAME
	   ,T2.CTF_NO
	   ,T2.PHONE
	   ,T2.CTCT_TEL
	   ,T1.ZJLY
	   ,T1.RQ
) T
;

-----------------------加载结束---------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_ETP_BOND_INCM_TAX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_ETP_BOND_INCM_TAX;
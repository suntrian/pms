--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:机构管理表                                                                           */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T03_TJGGL;
--插入数据--
 INSERT OVERWRITE EDW_PROD.T_EDW_T03_TJGGL
 (
                                     JGDM                                --机构代码                               
                                    ,JGMC                                --机构名称                               
                                    ,JGJC                                --机构简称                               
                                    ,JGLB                                --机构类别                               
                                    ,JGSX                                --机构属性                               
                                    ,PROVINCE                            --省份                                 
                                    ,CITY                                --城市                                 
                                    ,SJJGDM                              --上级机构代码                             
                                    ,SJJGLB                              --上级机构类别                             
                                    ,CGJGDM                              --存管机构代码        
                                    ,XTBS								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.JGDM                                as JGDM                                --机构代码                                
                                    ,t.JGMC                                as JGMC                                --机构名称                                
                                    ,t.JGJC                                as JGJC                                --机构简称                                
                                    ,t.JGLB                                as JGLB                                --机构类别                                
                                    ,t.JGSX                                as JGSX                                --机构属性                                
                                    ,t.PROVINCE                            as PROVINCE                            --省份                                  
                                    ,t.CITY                                as CITY                                --城市                                  
                                    ,t.SJJGDM                              as SJJGDM                              --上级机构代码                              
                                    ,t.SJJGLB                              as SJJGLB                              --上级机构类别                              
                                    ,t.CGJGDM                              as CGJGDM                              --存管机构代码 
                                    ,'JZJY'								   
 FROM         JZJYCX.ABOSS_TJGGL             t 
 WHERE        t.DT = '%d{yyyyMMdd}';
--插入数据结束--
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T03_TJGGL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T03_TJGGL; 
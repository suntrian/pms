  /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:交易量_交易通道_客户级别月表                                                                   */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-11-14                                                                        */ 

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_PATH_CUST_LVL_MON_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_PATH_CUST_LVL_MON_TEMP 
 as SELECT  t.KHH               as CUST_NO
           ,a3.BELTO_FILIL      as BELTO_FILIL
           ,a2.BRH_NO           as BRH_NO
           ,a3.BRH_SHRTNM		as BRH_NAME
           ,CASE WHEN a1.KHTZ IN (2405,2406,2407,2408,2409,2410)	
                 AND  a2.CUST_CGY = '0'	
                 THEN 'gr1'
				 WHEN a2.CUST_CGY = '1'
				 THEN 'jg'
				 ELSE 'gr2'
				 END     as CUST_LVL
                 				 
		   ,CASE WHEN t.GDSBJBDM = '4'
		         THEN 1
				 WHEN t.GDSBJBDM IN ('6','10','11','12','13')
		         THEN 2
				 ELSE 3
				 END   as CUST_TRD_PATH   --客户交易通道
				 
				 
		   ,SUM(CJJE)  as STK_FUND_TRD_VOL --股基交易量
		   ,CAST(SUBSTR('20181127',1,6) as INT) as YEAR_MON 
 FROM EDW_PROD.T_EDW_T05_TWTLS t
 LEFT JOIN (SELECT * FROM EDW_PROD.T_EDW_T99_TKHTZ WHERE BUS_DATE = %d{yyyyMMdd} AND %d{yyyyMMdd} BETWEEN GXRQ AND JZRQ)  a1
 ON        t.KHH = a1.KHH
 LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_INFO  a2
 ON         t.KHH = a2.CUST_NO 
 AND        a2.BUS_DATE = %d{yyyyMMdd}
 INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH      a3
 ON         a2.BRH_NO = a3.BRH_NO 
 AND        a2.BUS_DATE = %d{yyyyMMdd}
 WHERE SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 AND  DDLX < > '3' 
 AND SUBSTR(ZQLB,1,1) <> 'F'
 AND JYS IN ('SH','SZ')
 AND SUBSTR(ZQLB,1,1) IN ('A','C','E','J','L','T')
 AND WTLB   IN (1,2,29,30,41,42,43,57,58,59,60,61,62,63,64,71,72) 
 GROUP BY CUST_NO
          ,BELTO_FILIL
          ,BRH_NO
          ,BRH_SHRTNM
          ,CUST_LVL
          ,CUST_TRD_PATH 
          ,YEAR_MON ;
				
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_PATH_CUST_LVL_MON_TEMP1 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_PATH_CUST_LVL_MON_TEMP1 
  as SELECT BELTO_FILIL,BRH_NO,BRH_NAME,CUST_LVL,COUNT(1) as NUM
         FROM 
         (SELECT   BELTO_FILIL,BRH_NO,BRH_NAME,CUST_LVL,CUST_NO 
          FROM     DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_PATH_CUST_LVL_MON_TEMP
          GROUP BY  BELTO_FILIL,BRH_NO,BRH_NAME,CUST_LVL,CUST_NO
		  ) t
		  GROUP BY BELTO_FILIL,BRH_NO,BRH_NAME,CUST_LVL	 ;
  
------期初创建临时表1  
 INSERT OVERWRITE DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_PATH_CUST_LVL_MON
 (
         
          BELTO_FILIL                      --地区	
         ,BRH_NO                           --营业部	
         ,BRH_NAME                         --营业部名称	
         ,CUST_LVL                         --客户级别	
         ,TRD_PSNNUM                       --交易人数	
         ,ORDI_PATH_TRD_PSNNUM             --普通通道交易人数	
         ,CORE_PATH_TRD_PSNNUM             --核心通道交易人数	
         ,VIP_PATH_TRD_PSNNUM              --VIP通道交易人数	
         ,STK_FUND_TRD_VOL                 --股基交易量	
         ,ORDI_PATH_STK_FUND_TRD_VOL       --股基交易量普通通道	
         ,CORE_PATH_STK_FUND_TRD_VOL       --股基交易量核心通道	
         ,VIP_PATH_STK_FUND_TRD_VOL        --股基交易量VIP通道	
         ,STK_FUND_TRD_VOL_AVG             --人均交易量	
         ,ORDI_PATH_STK_FUND_TRD_VOL_AVG   --普通通道人均	
         ,CORE_PATH_STK_FUND_TRD_VOL_AVG   --核心通道人均	
         ,VIP_PATH_STK_FUND_TRD_VOL_AVG    --VIP通道人均		  
) 
PARTITION( YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
SELECT    t.BELTO_FILIL                      --地区	
         ,t.BRH_NO                           --营业部	
         ,t.BRH_NAME                         --营业部名称	
         ,t.CUST_LVL                         --客户级别	
         ,t.NUM                    as TRD_PSNNUM         --交易人数	
         ,a1.ORDI_PATH_TRD_PSNNUM               --普通通道交易人数	
         ,a1.CORE_PATH_TRD_PSNNUM               --核心通道交易人数	
         ,a1.VIP_PATH_TRD_PSNNUM                --VIP通道交易人数	
         ,a1.STK_FUND_TRD_VOL                   --股基交易量	
         ,a1.ORDI_PATH_STK_FUND_TRD_VOL         --股基交易量普通通道	
         ,a1.CORE_PATH_STK_FUND_TRD_VOL         --股基交易量核心通道	
         ,a1.VIP_PATH_STK_FUND_TRD_VOL          --股基交易量VIP通道	
         ,NVL(ROUND(a1.STK_FUND_TRD_VOL*1.000/t.NUM,2),0)  as STK_FUND_TRD_VOL_AVG               --人均交易量	
         ,NVL(ROUND(a1.ORDI_PATH_STK_FUND_TRD_VOL*1.000/a1.ORDI_PATH_TRD_PSNNUM,2),0) as   ORDI_PATH_STK_FUND_TRD_VOL_AVG     --普通通道人均交易量		
         ,NVL(ROUND(a1.CORE_PATH_STK_FUND_TRD_VOL*1.000/a1.CORE_PATH_TRD_PSNNUM,2),0) as CORE_PATH_STK_FUND_TRD_VOL_AVG     --核心通道人均交易量		
         ,NVL(ROUND(a1.VIP_PATH_STK_FUND_TRD_VOL*1.000/a1.VIP_PATH_TRD_PSNNUM,2),0) as VIP_PATH_STK_FUND_TRD_VOL_AVG      --VIP通道人均交易量	
 
FROM      DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_PATH_CUST_LVL_MON_TEMP1  t
LEFT JOIN (SELECT BELTO_FILIL,BRH_NO,BRH_NAME,CUST_LVL
                  ,SUM(CASE WHEN CUST_TRD_PATH = 1
				            THEN 1
							ELSE 0
							END ) as CORE_PATH_TRD_PSNNUM         --核心通道交易人数
				  ,SUM(CASE WHEN CUST_TRD_PATH = 2
				            THEN 1
							ELSE 0
							END ) as VIP_PATH_TRD_PSNNUM              --VIP通道交易人数
				  ,SUM(CASE WHEN CUST_TRD_PATH = 3
				            THEN 1
							ELSE 0
							END ) as ORDI_PATH_TRD_PSNNUM               --普通通道交易人数	
				  ,SUM(STK_FUND_TRD_VOL)    as STK_FUND_TRD_VOL                 --股基交易量
				  ,SUM(CASE WHEN CUST_TRD_PATH = 1
				            THEN STK_FUND_TRD_VOL
							ELSE 0
							END ) as CORE_PATH_STK_FUND_TRD_VOL         --股基交易量核心通道
				  ,SUM(CASE WHEN CUST_TRD_PATH = 2
				            THEN STK_FUND_TRD_VOL
							ELSE 0
							END ) as VIP_PATH_STK_FUND_TRD_VOL          --股基交易量VIP通道
				  ,SUM(CASE WHEN CUST_TRD_PATH = 3
				            THEN STK_FUND_TRD_VOL
							ELSE 0
							END ) as ORDI_PATH_STK_FUND_TRD_VOL         --股基交易量普通通道
           FROM   DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_PATH_CUST_LVL_MON_TEMP
		   GROUP BY BELTO_FILIL,BRH_NO,BRH_NAME,CUST_LVL
		   )    a1
ON t.BELTO_FILIL = a1.BELTO_FILIL
AND t.BRH_NO = a1.BRH_NO
AND t.CUST_LVL = a1.CUST_LVL ;
 ---
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_PATH_CUST_LVL_MON_TEMP1 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_PATH_CUST_LVL_MON_TEMP ;
 ---插入运行监控
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_TRD_VOL_TRD_PATH_CUST_LVL_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
     invalidate metadata DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_PATH_CUST_LVL_MON; 
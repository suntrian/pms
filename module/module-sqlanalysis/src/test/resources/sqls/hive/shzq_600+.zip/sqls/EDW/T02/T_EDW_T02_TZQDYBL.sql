 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:债券抵押比例表                                                                     */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZQDYBL; 
---------插入数据开始-----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZQDYBL(
                                    JYS                                 --交易所                                
                                   ,ZQDM                                --债券代码                               
                                   ,DYZQDM                              --抵押代码                               
                                   ,DYBL                                --抵押比例                               
                                   ,XGRQ                                --修改日期                               
                                   ,YXKSRQ                              --有效开始日期                             
                                   ,YXJSRQ                              --有效结束日期                             
                                   ,DYZKBL                              --抵押折扣比例  
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.ZQDM                                as ZQDM                                --债券代码                                
                                   ,t.DYZQDM                              as DYZQDM                              --抵押代码                                
                                   ,t.DYBL                                as DYBL                                --抵押比例                                
                                   ,t.XGRQ                                as XGRQ                                --修改日期                                
                                   ,t.YXKSRQ                              as YXKSRQ                              --有效开始日期                              
                                   ,t.YXJSRQ                              as YXJSRQ                              --有效结束日期                              
                                   ,t.DYZKBL                              as DYZKBL                              --抵押折扣比例   
                                   ,'JZJY'				                  as XTBS				   
 FROM           JZJYCX.SECURITIES_TZQDYBL t
 WHERE          t.DT = '%d{yyyyMMdd}';
-------------插入数据结束-----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZQDYBL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TZQDYBL;
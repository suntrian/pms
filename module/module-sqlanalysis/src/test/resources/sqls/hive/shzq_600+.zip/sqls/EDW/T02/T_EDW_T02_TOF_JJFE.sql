 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:基金份额表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
------插入数据开始---------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TOF_JJFE
(
                                    KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,JJZH                                --基金帐号                               
                                   ,TADM                                --TA代码                               
                                   ,JJDM                                --基金代码                               
                                   ,JJJC                                --基金简称                               
                                   ,OF_SFFS                             --基金收费方式                             
                                   ,JJSL                                --份额数量                               
                                   ,MCWTSL                              --赎回委托数量                             
                                   ,DJSL                                --冻结数量                               
                                   ,ZXSZ                                --最新市值                               
                                   ,KCRQ                                --开仓日期                               
                                   ,BDRQ                                --最近变动日期                             
                                   ,CCCB                                --持仓成本                               
                                   ,LJYK                                --累计盈亏                               
                                   ,OF_FHFS                             --基金分红方式                             
                                   ,YYB                                 --客户营业部                              
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,BZDM                                --币种代码                               
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期      
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.JJZH                                as JJZH                                --基金帐号                                
                                   ,t.TADM                                as TADM                                --TA代码                                
                                   ,t.JJDM                                as JJDM                                --基金代码                                
                                   ,t.JJJC                                as JJJC                                --基金简称                                
                                   ,t.SFFS                                as OF_SFFS                             --收费方式                                
                                   ,t.JJSL                                as JJSL                                --份额数量                                
                                   ,t.MCWTSL                              as MCWTSL                              --                                    
                                   ,t.DJSL                                as DJSL                                --                                    
                                   ,t.ZXSZ                                as ZXSZ                                --                                    
                                   ,t.KCRQ                                as KCRQ                                --                                    
                                   ,t.BDRQ                                as BDRQ                                --                                    
                                   ,t.CCCB                                as CCCB                                --                                    
                                   ,t.LJYK                                as LJYK                                --                                    
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.FHFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as OF_FHFS                             --                                    
                                   ,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --客户营业部                               
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.ZHGLJG                                  as ZHGLJG                              --                                    
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as BZDM                                --币种                                  
                                   ,%d{yyyyMMdd}                           as KSRQ                                --开始日期                                
                                   ,%d{yyyyMMdd}                           as JSRQ                                --结束日期  
                                   ,'JZJY'		                          as XTBS						   
 FROM           JZJYCX.DATACENTER_TOF_JJFE             t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'OF_FHFS'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.FHFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t3
 ON             t3.YXT = 'JZJY'
 AND            t3.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
-----------插入数据结束-----------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TOF_JJFE',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TOF_JJFE;
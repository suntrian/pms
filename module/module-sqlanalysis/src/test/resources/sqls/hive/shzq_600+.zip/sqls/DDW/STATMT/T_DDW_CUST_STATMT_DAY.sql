 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户对账单日表                                                         */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-05-03                                                                       */ 

 -----
 -----指标是:(总资产,普通账户资产,信用账户资产,期权账户资产)
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP;
  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP  as
  SELECT     CUST_NO
            ,NET_TOT_AST     as TOL_AST
			,ORDI_NET_AST    as ORDT_ACCNT_AST
			,CRD_NET_AST     as CRD_ACCNT_AST
			,WRNT_AST        as WRNT_ACCNT_AST
			,0-TOTGL         as TOL_GL
            ,TOT_UNPY_CPTL   as TOT_UNPY_CPTL
			,TOT_CPTL        as TOT_CPTL
			,TFR_IN_MKTVAL   as TFR_IN_MKTVAL
			,TFR_OUT_MKTVAL  as TFR_OUT_MKTVAL
			,NET_TFR_IN_AMT+NET_TFR_IN_MKTVAL as NET_FLW_IN_AMT 
			,TFR_IN_AMT                          --转入资金
            ,TFR_OUT_AMT                         --转出资金
			,TOT_PRFT
  FROM   DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY   a
  WHERE  a.BUS_DATE = %d{yyyyMMdd} ; 

-----昨天的资产
--  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP1;
--  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP1 as
--  SELECT     CUST_NO
--            ,TOT_AST as TOL_AST
--			,ORDI_ACCNT_AST as ORDT_ACCNT_AST
--			,CRD_ACCNT_AST
--			,WRNT_ACCNT_AST
--			,TOT_GL as TOL_GL
--            ,TOT_UNPY_CPTL
--			,TOT_CPTL
--  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY a
--  WHERE   EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
--	             WHERE  c.BUS_DATE = %d{yyyyMMdd}
--				 AND    c.TRD_DT = %d{yyyyMMdd}
--				 AND    a.BUS_DATE = c.LST_TRD_D
--	             )
--  ;
  -------转入市值,转出市值
--  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP2;
--  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP2    as 
--  SELECT      t.CUST_NO
--              ,SUM(TFR_IN_MKTVAL)    as TFR_IN_MKTVAL
--			  ,SUM(TFR_OUT_MKTVAL)  as TFR_OUT_MKTVAL  
--  FROM   (SELECT    CUST_NO
--                   ,SUM(NVL(SEC_TFR_IN_MKTVAL,0))    as TFR_IN_MKTVAL
--                   ,SUM(NVL(SEC_TFR_OUT_MKTVAL,0))   as TFR_OUT_MKTVAL
--          FROM      DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY
--          WHERE     BUS_DATE = %d{yyyyMMdd}  
--          GROUP BY  CUST_NO  
--          UNION ALL 
--          SELECT     CUST_NO
--                    ,SUM(NVL(PROD_TFR_IN_MKTVAL,0))			     as TFR_IN_MKTVAL 
--		            ,SUM(NVL(PROD_TFR_OUT_MKTVAL,0))				  as TFR_OUT_MKTVAL 		 			 
--          FROM     DDW_PROD.T_DDW_F10_TRD_CUST_PROD_TRD_AGGR_DAY 
--          WHERE    BUS_DATE = %d{yyyyMMdd}
--          GROUP BY  CUST_NO
--         )                   t
--  GROUP BY t.CUST_NO
--  ;
--  
--  
-----指标:(资金流进，流出) 客户的收益 = 今天资产-昨天的资产+流出资金-流入+转出—转入  收益率 收益/max(今天的资产，昨天的资产)
 --OR SUBSTR(t.SEC_CGY,1,3) = t.SEC_CGY_PFX
 DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP3;
 CREATE TABLE   DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP3 
 as
 SELECT             a.CUST_NO                  
					,SUM(ROUND(CASE WHEN b.BZDM IS NOT NULL AND  a.BIZ_SBJ IN ('10705','10701','10501','10503','10505') AND a.INCM_AMT > 0
					          THEN a.INCM_AMT*b.ZHHL
							  WHEN a.BIZ_SBJ IN ('10705','10701','10501','10503','10505') AND a.INCM_AMT > 0
					          THEN a.INCM_AMT
							  WHEN b.BZDM IS NOT NULL AND  a.BIZ_SBJ IN ('10705','10701','10501','10503','10505') AND a.PAY_AMT > 0
					          THEN 0-a.PAY_AMT*b.ZHHL
							  WHEN a.BIZ_SBJ IN ('10705','10701','10501','10503','10505') AND a.PAY_AMT > 0
					          THEN 0-a.PAY_AMT
							  ELSE 0
							  END,2))    as INT_YLD                    --利息收益					
 FROM       DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS   a
 LEFT JOIN  EDW_PROD.T_EDW_T99_HLZH      b
 ON         a.CCY_CD = b.BZDM
 AND        a.BUS_DATE = b.BUS_DATE
 WHERE      a.BUS_DATE = %d{yyyyMMdd} 
 AND        SUBSTR(a.BIZ_SBJ,1,3) IN ('101','102','105','107','103','104','130')
 GROUP BY   a.CUST_NO;
 
 
--------指标:(持有场外基金(只),持有金融产品(只))
 DROP TABLE  IF EXISTS  DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP4;
 CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP4 as
 SELECT  a.CUST_NO
        ,SUM(CASE WHEN a.PROD_CGY = 9
                  THEN 1
				  ELSE 0
				  END
		     )                 as HLD_FNCL_PROD
      	,SUM(CASE WHEN a.PROD_CGY = 8
                  THEN 1
				  ELSE 0
				  END
		     )		     as HLD_OTC_FND
 FROM   (SELECT    CUST_NO,PROD_CD,PROD_CGY  
          FROM     DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS
		  WHERE    BUS_DATE = %d{yyyyMMdd}
          GROUP BY CUST_NO,PROD_CD,PROD_CGY 
        )    a
 GROUP BY a.CUST_NO;
 --------指标:(金融产品认购笔数,金融产品赎回笔数,场外基金认购笔数,场外基金赎回笔数)
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP5;
  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP5
  as 
  SELECT a.CUST_NO
        ,SUM(OTC_FND_SCRP_ITMS+OTC_FND_PRCH_ITMS+CO_PROD_SCRP_ITMS+CO_PROD_PRCH_ITMS+GJ_CO_PROD_SCRP_ITMS+GJ_CO_PROD_PRCH_ITMS)    as FND_SCRP_ITMS
		,SUM(OTC_FND_RDMPT_ITMS+CO_PROD_RDMPT_ITMS+GJ_CO_PROD_RDMPT_ITMS)   as FND_RDMPT_ITMS  --场外基金赎回笔数
        ,SUM(FNCL_PROD_SCRP_ITMS)   as FNCL_PROD_SCRP_ITMS --金融产品认购笔数
        ,SUM(FNCL_PROD_RDMPT_ITMS)  as FNCL_PROD_RDMPT_ITMS --金融产品赎回笔数
  FROM 	  DDW_PROD.T_DDW_F10_TRD_CUST_PROD_TRD_AGGR_DAY   a 
  WHERE    a.BUS_DATE = %d{yyyyMMdd}
  GROUP BY a.CUST_NO;
  ------指标:(中签新股)-----
   DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP6;
  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP6
  as 
  SELECT    a.CUST_NO as CUST_NO
           ,SUM(CASE WHEN a.EXG = 'SH'
		             AND  a.ODR_CGY = 82
					 AND  SUBSTR(a.SEC_CGY,1,1) < > 'Z' 
		             THEN 1
				     ELSE 0
				     END
			    )               as LOT_SH_STK
		   ,SUM(CASE WHEN a.EXG = 'SZ'
		             AND  a.ODR_CGY = 82
					 AND  SUBSTR(a.SEC_CGY,1,1) < > 'Z' 
		             THEN 1
				     ELSE 0
				     END
			    )               as LOT_SZ_STK
 FROM      DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS   a
 WHERE    a.BUS_DATE = %d{yyyyMMdd} 
 GROUP BY  a.CUST_NO
	   ;
-------指标:(持有股票的只数)
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP7;
 CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP7   as
 SELECT a.CUST_NO
       ,SUM(CASE WHEN a.EXG IN ('SH','HK','HB')
	         THEN 1
			 ELSE 0
			 END
		)    as HLD_SH_STK
	   ,SUM(CASE WHEN a.EXG IN ('SZ','SK','SB')
	         THEN 1
			 ELSE 0
			 END
		   )    as HLD_SZ_STK
 FROM(SELECT    a.CUST_NO,a.EXG,a.SEC_CD 
      FROM       DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS  a
	  LEFT JOIN  (SELECT  EXG
	                      ,SEC_CD_PFX
						  ,SEC_CL_CD 
				 FROM  DDW_PROD.T_DDW_CFG_SEC_TRD_CL
				 GROUP BY EXG,SEC_CD_PFX,SEC_CL_CD
			      )                                b
      ON        a.EXG = b.EXG
      AND       SUBSTR(a.SEC_CD,1,3) = b.SEC_CD_PFX
      WHERE    a.BUS_DATE = %d{yyyyMMdd} 
	   AND     a.EXG IN ('SH','SZ','HK','SK','HB','SB')
       AND     b.SEC_CD_PFX IS NOT NULL
	   AND     b.SEC_CL_CD IN ('001','002','003','004','005','063','015','016','054','055','056','057','058','059','060','061','062','012','013')  ----
     GROUP BY   CUST_NO,EXG,SEC_CD
     )  a
 GROUP BY a.CUST_NO;
 ------指标:(股票交易次数)-----
 DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP8;
 CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP8   as 
   SELECT   CUST_NO         as CUST_NO
        ,SUM(TRD_ITMS_ASTK+TRD_ITMS_BSTK+TRD_ITMS_HK_STK+TRD_ITMS_EXG_FND-TRD_ITMS_ASTK_PRCH)  as STK_TRD_TMS
        ,SUM(TRD_VOL_ASTK+TRD_VOL_BSTK+TRD_VOL_HK_STK+TRD_VOL_EXG_FND-TRD_VOL_ASTK_PRCH)   as STK_TRD_VOL
        ,SUM(TRD_ITMS_ASTK_BUYIN+TRD_ITMS_BSTK_BUYIN+TRD_ITMS_HK_STK_BUYIN+TRD_ITMS_EXG_FND_BUYIN) as STK_BUYIN_TMS
	    ,SUM(TRD_ITMS_ASTK_SELL+TRD_ITMS_BSTK_SELL+TRD_ITMS_HK_STK_SELL+TRD_ITMS_EXG_FND_SELL) as STK_SELL_TMS
 FROM       DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY 
--DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY  a
 WHERE     BUS_DATE = %d{yyyyMMdd} 
 GROUP BY  CUST_NO;
 

 
--------指标(股票收益,场外基金收益,理财产品收益,期权收益,其他收益)---
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP12;
   CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP12
   as 
   SELECT NVL(a.CUST_NO,b.CUST_NO) as CUST_NO ,NVL(a.GT_INT,0)-NVL(b.GT_INT,0) as ADJ_YLD
   FROM (SELECT CUST_NO,SUM(NVL(GT_INT,0)) as GT_INT FROM DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
         WHERE BUS_DATE = %d{yyyyMMdd}
		 GROUP BY CUST_NO
         ) a
	FULL JOIN (SELECT CUST_NO,SUM(NVL(GT_INT,0)) as GT_INT FROM DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS a
                WHERE   EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
	                           WHERE   c.BUS_DATE = %d{yyyyMMdd}
						       AND     c.TRD_DT = %d{yyyyMMdd}
						       AND    a.BUS_DATE = c.LST_TRD_D
	                           )
		       GROUP BY CUST_NO
              ) b
	ON      a.CUST_NO = b.CUST_NO
	;




--插入数据--
INSERT OVERWRITE DDW_PROD.T_DDW_CUST_STATMT_DAY
(
                         CUST_NO                    --客户号           
                        ,TOL_AST                    --总资产
						,TOL_GL                     --总负债
						,AMT_BAL                    --资金余额
						,UPNY_AMT                   --在途资金
                        ,ORDT_ACCNT_AST             --普通账户资产
                        ,CRD_ACCNT_AST              --信用账户资产
                        ,WRNT_ACCNT_AST             --期权账户资产
                        ,TOL_YLD                    --总收益
						,INT_YLD                    --利息收益
						,NET_INCM                   --收益率
                        ,STK_YLD                    --股票收益                       
                        ,MNY_PROD_YLD               --理财产品收益
                        ,WRNT_YLD                   --期权收益
						,OTH_YLD                    --其他收益
						,TFR_IN_MKTVAL              --转入市值
						,TURN_OUT_MKTVAL            --转出市值
						,NET_FLW_IN_AMT             --净流入资金
                        ,TFR_IN_AMT                 --转入资金
                        ,TURN_OUT_AMT               --转出资金
						,HLD_OTC_FND                --持有场外基金(只)
						,FND_SCRP_ITMS              --场外基金认购笔数
						,FND_RDMPT_ITMS             --场外基金赎回笔数
						,HLD_FNCL_PROD              --持有金融产品(只)
						,FNCL_PROD_SCRP_ITMS        --金融产品认购笔数
						,FNCL_PROD_RDMPT_ITMS       --金融产品赎回笔数
						,HLD_SH_STK                 --持有上海股票(只)			
						,HLD_SZ_STK                 --持有深圳股票(只)			
						,LOT_SH_STK                 --中签上海股票(只)			
						,LOT_SZ_STK                 --中签深圳股票(只)			
						,STK_TRD_TMS                --股票交易次数(1,2,57-64)
						,STK_BUYIN_TMS              --股票买入笔数
						,STK_SELL_TMS               --股票卖出笔数
                        ,STK_TRD_VOL                --股票交易量
                        ,ADJ_YLD	                --调整收益						
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT           t.CUST_NO                        as CUST_NO                    --客户号                        
                 ,NVL(a1.TOL_AST,0)                as TOL_AST                    --总资产
				 ,NVL(a1.TOL_GL,0)                 as TOL_GL                     --总负债
				 ,NVL(a1.TOT_CPTL,0)               as AMT_BAL                    --资金余额
				 ,NVL(a1.TOT_UNPY_CPTL,0)          as UPNY_AMT                   --在途资金
                 ,NVL(a1.ORDT_ACCNT_AST,0)         as ORDT_ACCNT_AST             --普通账户资产
                 ,NVL(a1.CRD_ACCNT_AST,0)          as CRD_ACCNT_AST              --信用账户资产
                 ,NVL(a1.WRNT_ACCNT_AST,0)         as WRNT_ACCNT_AST             --期权账户资产
                 ,NVL(a1.TOT_PRFT,0)               as TOL_YLD                    --总收益
				 ,ROUND(NVL(a4.INT_YLD,0),2)       as INT_YLD                    --利息收益
                 ,NVL(CAST((NVL(a1.TOT_PRFT,0)+NVL(a12.ADJ_YLD,0))*1.000000/(NVL(a1.TOL_AST,0)+NVL(a1.TFR_OUT_AMT,0)+NVL(a1.TFR_OUT_MKTVAL,0)-NVL(a12.ADJ_YLD,0)-NVL(a1.TOT_PRFT,0)) as DECIMAL(38,6)),0)   as NET_INCM --收益率
				 ,NVL(a10.STK_YLD,0)               as STK_YLD                    --股票收益                
                 ,NVL(a10.MNY_PROD_YLD,0)+NVL(a10.OTC_FND_YLD,0)          as MNY_PROD_YLD               --理财产品收益
                 ,NVL(a10.WRNT_YLD,0)              as WRNT_YLD                   --期权收益
                 ,NVL(a1.TOT_PRFT,0)-NVL(a10.STK_YLD,0)-NVL(a10.OTC_FND_YLD,0)-NVL(a10.MNY_PROD_YLD,0)-NVL(a10.WRNT_YLD,0)-NVL(a4.INT_YLD,0)                                as OTH_YLD                    --其他收益
                 ,NVL(a1.TFR_IN_MKTVAL,0)          as TFR_IN_MKTVAL              --转入市值
                 ,NVL(a1.TFR_OUT_MKTVAL,0)         as TURN_OUT_MKTVAL            --转出市值
                 ,NVL(a1.NET_FLW_IN_AMT,0)         as NET_FLW_IN_AMT             --净流入资金
                 ,NVL(a1.TFR_IN_AMT,0)             as TFR_IN_AMT                 --转入资金
                 ,NVL(a1.TFR_OUT_AMT,0)           as TURN_OUT_AMT                --转出资金
                 ,NVL(a5.HLD_OTC_FND,0)            as HLD_OTC_FND                --持有场外基金(只)
                 ,NVL(a6.FND_SCRP_ITMS,0)          as FND_SCRP_ITMS              --场外基金认购笔数
                 ,NVL(a6.FND_RDMPT_ITMS,0)         as FND_RDMPT_ITMS             --场外基金赎回笔数
                 ,NVL(a5.HLD_FNCL_PROD,0)          as HLD_FNCL_PROD              --持有金融产品(只)
                 ,NVL(a6.FNCL_PROD_SCRP_ITMS,0)    as FNCL_PROD_SCRP_ITMS        --金融产品认购笔数
                 ,NVL(a6.FNCL_PROD_RDMPT_ITMS,0)   as FNCL_PROD_RDMPT_ITMS       --金融产品赎回笔数   
				 ,NVL(a8.HLD_SH_STK,0)             as HLD_SH_STK                 --持有上海股票(只)	
                 ,NVL(a8.HLD_SZ_STK,0)             as HLD_SZ_STK                 --持有深圳股票(只)	
                 ,NVL(a7.LOT_SH_STK,0)             as LOT_SH_STK                 --中签上海股票(只)	
                 ,NVL(a7.LOT_SZ_STK,0)             as LOT_SZ_STK                 --中签深圳股票(只)	
				 ,NVL(a9.STK_TRD_TMS,0)            as STK_TRD_TMS                --股票交易次数	
				 ,CAST(NVL(a9.STK_BUYIN_TMS,0) as DECIMAL(38,0))          as STK_BUYIN_TMS              --股票买入笔数
				 ,CAST(NVL(a9.STK_SELL_TMS,0) as DECIMAL(38,0))          as STK_SELL_TMS               --股票卖出笔数
				 ,NVL(a9.STK_TRD_VOL,0)            as STK_TRD_VOL                --股票交易量
				 ,NVL(a12.ADJ_YLD,0)               as ADJ_YLD	                --调整收益
 FROM        DDW_PROD.T_DDW_F00_CUST_CUST_INFO     t
 LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP   a1
 ON          t.CUST_NO =  a1.CUST_NO
 --LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP1  a2
 --ON          t.CUST_NO =  a2.CUST_NO
-- LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP2  a3
-- ON          t.CUST_NO =  a3.CUST_NO
 LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP3   a4
 ON          t.CUST_NO =  a4.CUST_NO
 LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP4   a5
 ON          t.CUST_NO =  a5.CUST_NO
 LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP5   a6
 ON          t.CUST_NO =  a6.CUST_NO
 LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP6   a7
 ON          t.CUST_NO =  a7.CUST_NO
 LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP7   a8
 ON          t.CUST_NO =  a8.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP8       a9
 ON         t.CUST_NO = a9.CUST_NO
 LEFT JOIN  (SELECT CUST_NO
                   ,SUM(ROUND(CASE WHEN PROD_CGY IN (1,2,5,7) 
				         THEN TOT_PRET_RMB                      
						 ELSE 0
						 END ,2))        as STK_YLD
				   ,SUM(DECODE(PROD_CGY,8,TOT_PRET,0)) as OTC_FND_YLD
				   ,SUM(DECODE(PROD_CGY,9,TOT_PRET,11,TOT_PRET,0)) as MNY_PROD_YLD
				   ,SUM(DECODE(PROD_CGY,10,TOT_PRET,0)) as WRNT_YLD
              FROM DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY a
              LEFT JOIN    EDW_PROD.T_EDW_T99_HLZH      b
			  ON           a.CCY_CD = b.BZDM
			  AND          a.BUS_DATE = b.BUS_DATE
             WHERE a.BUS_DATE  = %d{yyyyMMdd}
			 GROUP BY CUST_NO
                )                a10
 ON         t.CUST_NO = a10.CUST_NO
 LEFT JOIN  DDW_PROD.T_DDW_INR_ORG_BRH   a11
 ON          t.BRH_NO = a11.BRH_NO
 AND        a11.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP12      a12
 ON        t.CUST_NO = a12.CUST_NO
 WHERE       t.BUS_DATE = %d{yyyyMMdd} 
 AND         (t.ORDI_CUST_STAT < > '3' OR ORDI_CNCLACT_DT > %d{yyyyMMdd}) 
 AND         a11.BRH_NO IS NOT NULL
 AND         t.CUST_NO < > '100610335855' ;
 
-----
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP1;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP2;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP3;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP4;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP5;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP6;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP7;  
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP8; 
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP12; 
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_DAY_TEMP;

-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_STATMT_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_CUST_STATMT_DAY;  
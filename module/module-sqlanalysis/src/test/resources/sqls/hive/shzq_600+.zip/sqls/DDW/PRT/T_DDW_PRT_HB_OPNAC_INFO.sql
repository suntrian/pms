 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:沪B开户信息表                                                                       */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 

 TRUNCATE TABLE DDW_PROD.T_DDW_PRT_HB_OPNAC_INFO ; 
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_HB_OPNAC_INFO_TEMP ;
 CREATE TABLE  DDW_PROD.T_DDW_PRT_HB_OPNAC_INFO_TEMP
 as    SELECT     a.khh
                 ,GROUP_CONCAT(b.YHDM,',')as YHDM
				 ,a.BZDM
				 ,GROUP_CONCAT(CAST(b.DJRQ as STRING),',') as DJRQ
				 ,GROUP_CONCAT(CAST(a.KHRQ as STRING),',') as KHRQ
       FROM       ( SELECT  GTZJZH
	                        ,KHH
							,KHRQ
							,BZDM
                    FROM    EDW_PROD.T_EDW_T02_TZJZH 
                    WHERE   XTBS = 'JZJY'
				    AND     BUS_DATE = %d{yyyyMMdd}
					AND     BZDM = 'USD'                   			
                   )            a
       INNER JOIN  ( SELECT  GTZJZH
	                        ,YHDM
							,DJRQ as DJRQ
                     FROM    EDW_PROD.T_EDW_T02_TYZZZDY
                     WHERE   BUS_DATE = %d{yyyyMMdd}
					 AND     BZDM = 'USD'                    				 
					 )           b
       ON   a.GTZJZH = b.GTZJZH
	  GROUP BY a.KHH,a.BZDM 
 ;
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_HB_OPNAC_INFO_TEMP1 ;
 CREATE TABLE  DDW_PROD.T_DDW_PRT_HB_OPNAC_INFO_TEMP1 as 
 SELECT * FROM 
 (SELECT khh,round(S1*1.000000/CJJE,4) as YJL,SEQNO,ROW_NUMBER() OVER(PARTITION BY KHH,JYS,GDH ORDER BY SEQNO DESC) as num,JYS,GDH
 FROM EDW_PROD.T_EDW_T05_TJGMXLS
 WHERE JYS ='HB' and s1> 1 and cjje > 0
 AND   WTLB IN (1,2)
 )  t
 WHERE t.NUM = 1 ;
 
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_HB_OPNAC_INFO
(
									 BRH_NO                 --营业部编号   
									,BRH_NAME         		--营业部名称   
									,SHRHLD_REGST_DT  		--股东登记日期  
									,CUST_NO          		--客户号     
									,CUST_NAME        		--客户姓名    
									,CTF_CGY_CD       		--证件类别代码  
									,CTF_NO           		--证件号码    
									,HB_SHRHLD_NO     		--沪B股账号   
									,CTRL_ATTR        		--控制属性    
									,M_LAUND_RSK_LVL  		--洗钱风险等级  
									,IMAGE_TP         		--影像资料    
									,RSK_BEAR_ABLTY   		--风险承受力   
									,CTF_EXPR_DT            --证件截至日期  
									,CTCT_ADDR            --联系地址    
									,CTCT_TEL             --联系电话    
									,PHONE                --手机      
									,EDU_CD               --学历代码    
									,OCP_CD               --职业代码    
									,CMSN_SETUP_DT        --佣金设置日期  
									,CMSN_SETUP_ABST      --佣金设置摘要  
									,IF_OPN_PHONE_ODR     --是否开通手机委托
									,DEPMGT_BANK          --存管银行
									,ODR_MOD              --委托方式
									,CPT_ACCNT_OPNAC_DT   --资金账户开户日期
                                    ,CCY                  --货币
									,REGST_DT             --登记日期
									,HAND_BRH_NO          --办理营业部
									,OPN_MOD              --开通方式
									,RCT_TM_S1_RATE      --最近一次佣金率
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
						 t.BRH_NO               		AS  BRH_NO               	--营业部编号      
						,t.BRH_NAME             		AS  BRH_NAME         		--营业部名称       
						,t.SHRHLD_OPNAC_DT      		AS  SHRHLD_REGST_DT  		--股东登记日期      
						,t.CUST_NO              		AS  CUST_NO          		--客户号         
						,t.CUST_NAME            		AS  CUST_NAME        		--客户姓名        
						,b2.CTF_CGY_CD_NAME           		AS  CTF_CGY_CD       		--证件类别代码      
						,t.CTF_NO               		AS  CTF_NO           		--证件号码        
						,t.SHRHLD_NO         			AS  HB_SHRHLD_NO     		--沪B股账号       
						,a1.CTRL_ATTR            		AS  CTRL_ATTR        		--控制属性        
						,b6.M_LAUND_RSK_LVL_NAME      		AS  M_LAUND_RSK_LVL  		--洗钱风险等级      
						,a1.IMAGE_TP             		AS  IMAGE_TP         		--影像资料        
						,b3.RSK_BEAR_ABLTY_NAME          	AS  RSK_BEAR_ABLTY   		--风险承受力       
						,cast(a1.CTF_EXPR_DT   as DECIMAL(8,0))            	AS  CTF_EXPR_DT         	--证件截至日期     
						,a1.CTCT_ADDR               	AS  CTCT_ADDR           	--联系地址       
						,a1.CTCT_TEL                	AS  CTCT_TEL            	--联系电话       
						,a1.PHONE                   	AS  PHONE               	--手机         
						,b4.EDU_CD_NAME                  	AS  EDU_CD              	--学历代码       
						,b5.OCP_CD_NAME                  	AS  OCP_CD              	--职业代码       
						,a1.CMSN_SETUP_DT           	AS  CMSN_SETUP_DT       	--佣金设置日期     
						,a1.CMSN_SETUP_ABST         	AS  CMSN_SETUP_ABST     	--佣金设置摘要     
						,a1.IF_OPN_PHONE_ODR        	AS  IF_OPN_PHONE_ODR    	--是否开通手机委托 
                        ,a2.YHDM                        AS  DEPMGT_BANK          --存管银行
                        ,CONCAT(DECODE(FLOOR(a1.ORDI_ODR_MOD_SCP/128),1,'银行',''),','
                               ,DECODE(FLOOR(MOD(a1.ORDI_ODR_MOD_SCP,128)/64),1,'手机',''),','
	                           ,DECODE(FLOOR(MOD(MOD(a1.ORDI_ODR_MOD_SCP,128),64)/32),1,'互联网',''),','
	                           ,DECODE(FLOOR(MOD(MOD(MOD(a1.ORDI_ODR_MOD_SCP,128),64),32)/16),1,'远程',''),','
	                           ,DECODE(FLOOR(MOD(MOD(MOD(MOD(a1.ORDI_ODR_MOD_SCP,128),64),32),16)/8),1,'柜台',''),','
	                           ,DECODE(FLOOR(MOD(MOD(MOD(MOD(MOD(a1.ORDI_ODR_MOD_SCP,128),64),32),16),8)/4),1,'热键',''),','
	                           ,DECODE(FLOOR(MOD(MOD(MOD(MOD(MOD(MOD(a1.ORDI_ODR_MOD_SCP,128),64),32),16),8),4)/2),1,'磁卡',''),','
	                           ,DECODE(FLOOR(MOD(MOD(MOD(MOD(MOD(MOD(MOD(a1.ORDI_ODR_MOD_SCP,128),64),32),16),8),4),2)/1),1,'电话',''),',')  as ODR_MOD   --委托方式							   
                               ,cast(a2.KHRQ as decimal(38,0))                 as CPT_ACCNT_OPNAC_DT
                               ,a2.BZDM                 as CCY              --货币
							   ,cast(a2.DJRQ as decimal(38,0))                 as REGST_DT         --登记日期
                        ,a4.OCC_BRH_NO                             as HAND_BRH_NO                 --办理营业部
                        ,CASE WHEN a4.SPNS_CNL = 1
                              THEN '临柜'
                              WHEN a4.SPNS_CNL IN (2,11)
                              THEN '网上'
                              ELSE '其他'
                              END                              as OPN_MOD             --开通方式
                        ,a5.YJL                                as RCT_TM_S1_RATE      --最近一次佣金率							  
  FROM  		DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO     		t
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO 	    	a1
  ON            t.CUST_NO = a1.CUST_NO 
  AND           t.bus_date = a1.bus_date 
  LEFT JOIN     	DDW_PROD.V_CTF_CGY_CD			                      b2
  ON            	t.CTF_CGY_CD = b2.CTF_CGY_CD   
  LEFT JOIN     	DDW_PROD.V_RSK_BEAR_ABLTY                          	  b3
  ON            	a1.RSK_BEAR_ABLTY = b3.RSK_BEAR_ABLTY
  LEFT JOIN     	DDW_PROD.V_EDU_CD			                          b4
  ON            	a1.EDU_CD = b4.EDU_CD 
  LEFT JOIN     	DDW_PROD.V_OCP_CD			                          b5
  ON            	a1.OCP_CD = b5.OCP_CD  
 LEFT JOIN      DDW_PROD.V_M_LAUND_RSK_LVL            b6
  ON            a1.M_LAUND_RSK_LVL = b6.M_LAUND_RSK_LVL 
  LEFT JOIN     DDW_PROD.T_DDW_PRT_HB_OPNAC_INFO_TEMP                        a2
  ON            t.CUST_NO = a2.KHH
  and           a2.BZDM = 'USD'
  LEFT JOIN     (				 
				 SELECT   CUST_NO
                         ,OCC_BRH_NO
						 ,SPNS_CNL
						 ,DT
				 FROM  DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS
				 WHERE ABST LIKE '%沪B%' 
				 AND BIZ_SBJ = '20201'  
                 GROUP BY CUST_NO
                         ,OCC_BRH_NO
						 ,SPNS_CNL
						 ,DT		 
               ) a4
  ON           t.CUST_NO = a4.CUST_NO
  AND          t.SHRHLD_OPNAC_DT = a4.DT
  LEFT JOIN DDW_PROD.T_DDW_PRT_HB_OPNAC_INFO_TEMP1  a5
  ON            t.CUST_NO = a5.KHH
  AND            t.EXG = a5.JYS
  AND            t.SHRHLD_NO = a5.GDH
  WHERE			t.bus_date = %d{yyyyMMdd}
  AND           CAST(t.SHRHLD_OPNAC_DT AS STRING)> =  CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-3,0,0),1,4),'0101') 
  AND           t.EXG = 'HB'
  ;
 
-----------------------------加载结束--------------------
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_HB_OPNAC_INFO_TEMP ;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_HB_OPNAC_INFO_TEMP1 ;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_HB_OPNAC_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_HB_OPNAC_INFO ;
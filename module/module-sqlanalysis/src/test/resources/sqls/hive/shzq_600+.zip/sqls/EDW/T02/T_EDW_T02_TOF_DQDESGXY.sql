 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户定期定额申购协议表                                                              */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
    TRUNCATE TABLE EDW_PROD.T_EDW_T02_TOF_DQDESGXY;  
--------插入数据开始------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TOF_DQDESGXY
(
                                    XYBH                                --协议编号                               
                                   ,KHH                                 --客户号                                
                                   ,TADM                                --TA代码                               
                                   ,KHXM                                --客户姓名                               
                                   ,JJZH                                --基金帐号                               
                                   ,JJDM                                --基金代码                               
                                   ,OF_SFFS                             --基金收费方式                             
                                   ,SGJE                                --定期申购金额                             
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期                               
                                   ,MYKKRQ                              --每月扣款日期                             
                                   ,SCKKRQ                              --上次扣款日期                             
                                   ,PZDM                                --品种代码                               
                                   ,ORDERS                              --订单顺序号                              
                                   ,QQCS                                --欠缺次数                               
                                   ,LXWYCS                              --连续违约次数                             
                                   ,LJWYCS                              --累计违约次数                             
                                   ,OF_DQDEXYZT                         --基金定期定额协议状态                         
                                   ,WTFS                                --委托方式                               
                                   ,ZY                                  --摘要  
                                   ,EN_CFX
								   ,MZKKBZ
								   ,ZHDM  
								   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.XYBH                                as XYBH                                --协议编号                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as TADM                                --客户姓名                                
                                   ,t.TADM                                as KHXM                                --TA代码                                
                                   ,t.JJZH                                as JJZH                                --基金帐号                                
                                   ,t.JJDM                                as JJDM                                --基金代码                                
                                   ,t.SFFS                                as OF_SFFS                             --收费方式                                
                                   ,t.SGJE                                as SGJE                                --定期申购金额                              
                                   ,t.KSRQ                                as KSRQ                                --开始日期                                
                                   ,t.JSRQ                                as JSRQ                                --结束日期                                
                                   ,t.MYKKRQ                              as MYKKRQ                              --每月扣款日期                              
                                   ,t.SCKKRQ                              as SCKKRQ                              --上次扣款日期                              
                                   ,t.PZDM                                as PZDM                                --品种代码                                
                                   ,t.ORDERS                              as ORDERS                              --订单顺序号                               
                                   ,t.QQCS                                as QQCS                                --欠缺次数                                
                                   ,t.LXWYCS                              as LXWYCS                              --连续违约次数                              
                                   ,t.LJWYCS                              as LJWYCS                              --累计违约次数                              
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                     as OF_DQDEXYZT                         --状态                                  
                                   ,t.WTFS                                as WTFS                                --委托方式                                
                                   ,t.ZY                                  as ZY                                  --摘要     
                                   ,t.EN_CFX                              as EN_CFX
								   ,t.MZKKBZ                              as MZKKBZ
								   ,t.ZHDM                                as ZHDM  
								   ,'JZJY'						          as XTBS		   
 FROM           JZJYCX.OFS_TOF_DQDESGXY                 t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING  t1 
 ON             t1.DMLX = 'OF_DQDEXYZT'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.ZT AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
-------插入数据结束--------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TOF_DQDESGXY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TOF_DQDESGXY;
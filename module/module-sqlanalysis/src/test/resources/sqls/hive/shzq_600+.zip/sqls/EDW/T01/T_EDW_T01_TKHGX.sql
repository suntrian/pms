-- /* ***************************************** SQL Begin ***************************************** */
 -- /* 脚本功能:客户关系表                                                                  */
  --/* 创建人:段智泓                                                                              */
  --/* 创建时间:2018-05-11  
truncate table EDW_PROD.T_EDW_T01_TKHGX;
  --------插入数据开始-------------
INSERT OVERWRITE EDW_PROD.T_EDW_T01_TKHGX
(                                        ID                --主键
										,RYXX              --人员信息
										,TD                --团队
										,JSZH              --结算账户
										,YYB               --营业部
										,KHH               --客户号
										,KHH_XC            --客户号(薪酬)
										,FWGXLX            --关系类型
										,KHGX_YWLX         --业务类型
										,SYQZ              --收益权重
										,ZCQZ              --资产权重
										,CBQZ              --成本权重
										,SXRQ              --生效日期
										,ZXRQ              --注销日期
										,JZRQ              --截止日期
										,TJRQ              --添加日期
										,KHGX              --考核关系
										,QDWD              --渠道网点
										,RYZHZT                --状态
										,SZR               --设置人
										,YXLB              --有效类别
										,YXQRRQ            --有效确认日期
										,KHPZ              --考核品种
										,YXQRRQ2           --有效确认日期2
										,YXLB2             --有效类别2
										,YXHBZ             --是否主招揽
										,SXRQ1             --生效日期1
                                        ,XTBS  										
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT DISTINCT
                                         t.ID                  as ID              --主键
										,t.RYXX                as RYXX            --人员信息
										,t.TD                  as TD              --团队
										,t.JSZH                as JSZH            --结算账户
                                        ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))	     as YYB                      --经纪人营业部							   
										,CAST(t.KHH as STRING)                as KHH             --客户号
										,t.KHH_XC              as KHH_XC          --客户号(薪酬)
										,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.GXLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                as FWGXLX            --关系类型
										,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.YWLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                as KHGX_YWLX            --业务类型
										,t.SYQZ                as SYQZ            --收益权重
										,t.ZCQZ                as ZCQZ            --资产权重
										,t.CBQZ                as CBQZ            --成本权重
										,t.SXRQ                as SXRQ            --生效日期
										,t.ZXRQ                as ZXRQ            --注销日期
										,t.JZRQ                as JZRQ            --截止日期
										,t.TJRQ                as TJRQ            --添加日期
										,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHGX AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                as KHGX            --考核关系
										,t.QDWD                as QDWD            --渠道网点
										,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                  as RYZHZT              --状态
										,t.SZR                 as SZR             --设置人
										,t.YXLB                as YXLB            --有效类别
										,t.YXQRRQ              as YXQRRQ          --有效确认日期
										,t.KHPZ                as KHPZ            --考核品种
										,t.YXQRRQ2             as YXQRRQ2         --有效确认日期2
										,t.YXLB2               as YXLB2           --有效类别2
										,t.YXHBZ               as YXHBZ           --是否主招揽
										,t.SXRQ1               as SXRQ1           --生效日期1
                                        ,'CRM'       as XTBS										
 FROM           C5CX.CIS_TKHGX t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'CRM'
 AND            t1.JGDM = trim(CAST(t.YYB AS VARCHAR(20)))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t2
 ON             t2.YXT = 'CRM'
 AND            t2.YDM = CAST(t.GXLX AS VARCHAR(20))
 AND            t2.dmlx = 'FWGXLX'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t3
 ON             t3.YXT = 'CRM'
 AND            t3.YDM = CAST(t.YWLX AS VARCHAR(20))
 AND            t3.dmlx = 'KHGX_YWLX'
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t4
 ON             t4.YXT = 'CRM'
 AND            t4.YDM = CAST(t.ZT AS VARCHAR(20))
 AND            t4.dmlx = 'RYZHZT'
  LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t5
 ON             t5.YXT = 'CRM'
 AND            t5.YDM = CAST(t.KHGX AS VARCHAR(20))
 AND            t5.dmlx = 'KHGX'
 WHERE   t.DT = '%d{yyyyMMdd}';
--------插入数据结束---------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TKHGX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T01_TKHGX;

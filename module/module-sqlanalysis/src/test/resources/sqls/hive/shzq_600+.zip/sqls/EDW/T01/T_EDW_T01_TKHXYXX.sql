-- /* ***************************************** SQL Begin ***************************************** */
 -- /* 脚本功能:客户信用信息表                                                                         */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T01_TKHXYXX;  
----- 插入数据开始------
 INSERT OVERWRITE EDW_PROD.T_EDW_T01_TKHXYXX
 (
                                      KHH                                                      --客户号
                                     ,KHXM                                                     --客户姓名
                                     ,YWXT                                                     --业务系统
                                     ,YWZH                                                     --业务账号
                                     ,GLYWXT                                                   --关联业务系统
                                     ,GLYWZH                                                   --关联业务账号
                                     ,XYDJDM                                                   --信用等级代码
                                     ,PJZF                                                     --评级总分
                                     ,YYB                                                      --营业部
                                     ,KHQZ                                                     --客户群组
                                     ,DJRQ                                                     --登记日期
                                     ,XGRQ                                                     --修改日期
                                     ,XGGY                                                     --修改柜员
                                     ,KHZTDM                                                   --客户状态代码
                                     ,ZBCS                                                     --追保次数
                                     ,PCCS                                                     --平仓次数   
                                     ,XTBS                       
 ) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                       t.KHH                          as KHH                                                      --客户号        
                                      ,t1.KHXM                        as KHXM                                                     --客户姓名       
                                      ,t.YWXT                         as YWXT                                                     --业务系统       
                                      ,t.YWZH                         as YWZH                                                     --业务账号       
                                      ,t.GLYWXT                       as GLYWXT                                                   --关联业务系统     
                                      ,t.GLYWZH                       as GLYWZH                                                   --关联业务账号     
                                      ,t.XYDJ                         as XYDJDM                                                   --信用等级代码     
                                      ,t.PJZF                         as PJZF                                                     --评级总分       
                                      ,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t1.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                         as YYB                                                      --营业部        
                                      ,t1.KHQZ                        as KHQZ                                                     --客户群组       
                                      ,t1.PJZF                        as DJRQ                                                     --登记日期       
                                      ,t1.DJRQ                        as XGRQ                                                     --修改日期       
                                      ,t1.GYH                         as XGGY                                                     --修改柜员       
                                      ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t1.KHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                         as KHZTDM                                                   --客户状态代码     
                                      ,t1.ZBCS                        as ZBCS                                                     --追保次数       
                                      ,t1.PCCS                        as PCCS                                                     --平仓次数     
                                      ,'YGT_GT,RZRQ'  
                                
 FROM           YGTCX.CIF_TKHXYXX                              t
 LEFT JOIN      RZRQCX.MARGIN_TXY_KHXX                         t1
 ON             t.KHH = t1.KHH AND  t.DT = t1.DT
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t2 
 ON             t2.DMLX = 'KHZTDM'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t1.KHZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t3
 ON             t3.YXT='RZRQ'
 AND            t3.JGDM=CAST(t1.YYB AS VARCHAR(20))
 WHERE          t.YWXT = 1001 
 AND            t.DT = '%d{yyyyMMdd}'
;
---插入数据结束 ----

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TKHXYXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T01_TKHXYXX;

 







































































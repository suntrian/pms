--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:ETF网下认购表                                                                        */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T05_TETF_WXRG ;
------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T05_TETF_WXRG
(
                                    LSH                                 --ETF网下认购流水号                         
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --客户营业部                              
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,JYS                                 --交易所                                
                                   ,SQRQ                                --申请日期                               
                                   ,SQSJ                                --申请时间                               
                                   ,GDH                                 --股东号                                
                                   ,BPGDH                               --报盘股东号                              
                                   ,WTLB                                --委托类别                               
                                   ,RGDM                                --认购代码                               
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,RGJG                                --认购价格                               
                                   ,RGJE                                --认购金额                               
                                   ,RGSL                                --认购数量                               
                                   ,BZDM                                --币种代码                               
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,LSH_ZQDJXM                          --股份冻结流水号                            
                                   ,ZJDJLSH                             --资金冻结流水号                            
                                   ,JSZH                                --结算帐号                               
                                   ,FYBL                                --费用比例                               
                                   ,SXF                                 --手续费                                
                                   ,WTFS                                --委托方式                               
                                   ,CZZD                                --委托站点                               
                                   ,WTGY                                --委托柜员                               
                                   ,SQBH                                --申请编号                               
                                   ,SQXW                                --申请席位                               
                                   ,ZHZDXW                              --指定席位                               
                                   ,FSYYB                               --发生营业部                              
                                   ,SBJG                                --申报结果                               
                                   ,JGSM                                --结果说明                               
                                   ,SBRQ                                --申报日期                               
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,SQCZRH                              --操作人员                               
                                   ,CZZD1                               --操作终端                               
                                   ,IP_PHONE                            --IP地址/ 电话号码                         
                                   ,MAC                                 --MAC地址                              
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.LSH                                 as LSH                                 --流水号                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --客户营业部                               
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.WTRQ                                as SQRQ                                --申请日期                                
                                   ,t.WTSJ                                as SQSJ                                --申请时间                                
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.BPGDH                               as BPGDH                               --报盘股东号                               
                                   ,t.WTLB                                as WTLB                                --委托类别                                
                                   ,t.RGDM                                as RGDM                                --认购代码                                
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.RGJG                                as RGJG                                --认购价格                                
                                   ,t.RGJE                                as RGJE                                --认购金额                                
                                   ,t.RGSL                                as RGSL                                --认购数量                                
                                   ,t.BZ                                  as BZDM                                --币种                                  
                                   ,t.JSLX                                as ZJJSLX                              --结算类型                                
                                   ,t.JSJG                                as JSJG                                --结算机构                                
                                   ,t.LSH_ZQDJXM                          as LSH_ZQDJXM                          --股份冻结流水号                             
                                   ,t.LSH_ZJDJXM                          as ZJDJLSH                             --资金冻结流水号                             
                                   ,t.JSZH                                as JSZH                                --结算帐号                                
                                   ,t.FYBL                                as FYBL                                --费用比例                                
                                   ,t.SXF                                 as SXF                                 --手续费                                 
                                   ,t.WTFS                                as WTFS                                --委托方式                                
                                   ,t.CZZD                                as CZZD                                --委托站点                                
                                   ,t.WTGY                                as WTGY                                --委托柜员                                
                                   ,t.SQBH                                as SQBH                                --申请编号                                
                                   ,t.SQXW                                as SQXW                                --申请席位                                
                                   ,t.ZDXW                                as ZHZDXW                              --指定席位                                
                                   ,t.FSYYB                               as FSYYB                               --发生营业部                               
                                   ,t.SBJG                                as SBJG                                --申报结果                                
                                   ,t.JGSM                                as JGSM                                --结果说明                                
                                   ,t.SBRQ                                as SBRQ                                --申报日期                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.SQCZRH                              as SQCZRH                              --操作人员                                
                                   ,NULL                                  as CZZD1                               --                                    
                                   ,NULL                                  as IP_PHONE                            --                                    
                                   ,NULL                                  as MAC                                 --                                    
 FROM   JZJYCX.SECURITIES_TETF_WXRG     t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t1
 ON             t1.YXT = 'JZJY'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE  t.DT = '%d{yyyyMMdd}';
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TETF_WXRG',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_TETF_WXRG;
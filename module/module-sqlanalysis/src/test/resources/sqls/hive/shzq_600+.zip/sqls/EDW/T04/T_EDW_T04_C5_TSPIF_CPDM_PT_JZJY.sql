 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:OTC平台属性                                                                 */
  --/* 创建人:段智泓                                                                              */
  --/* 创建时间:2018-12-20                                                                       */ 
  
-----------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T04_C5_TSPIF_CPDM_PT_JZJY(
                    ID           --ID
                   ,CPID         --金融产品
                   ,CPRGF        --产品认购费
                   ,CPSGF        --产品申购费
                   ,CPSHF        --产品赎回费
                   ,CPTGF        --产品托管费
                   ,CPGLF        --产品管理费
                   ,CESYFC       --超额收益分成
                   ,XSFWF        --销售服务费
                   ,GRSCRGZDJE   --个人首次认购最低金额
                   ,JGSCRGZDJE   --机构首次认购最低金额
                   ,GRZJRGZDJE   --个人追加认购最低金额
                   ,JGZJRGZDJE   --机构追加认购最低金额
                   ,GMQDMS       --购买起点描述
                   ,SGKSR        --申购开始日
                   ,SGJSR        --申购结束日
                   ,GRSCSGZDJE   --个人首次申购最低金额
                   ,JGSCSGZDJE   --机构首次申购最低金额
                   ,GRZJSGZDJE   --个人追加申购最低金额
                   ,JGZJSGZDJE   --机构追加申购最低金额
                   ,SGRSSX       --申购人数上限
                   ,SGJSRQ       --申购交收日期
                   ,SHJSRQ       --赎回交收日期
                   ,CXKFQSR      --存续开放起始日
                   ,CXKFJSR      --存续开放结束日
                   ,RGJSR        --认购交收日期
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                    t.ID         --ID
                   ,t.CPID       --金融产品
                   ,t.CPRGF      --产品认购费
                   ,t.CPSGF      --产品申购费
                   ,t.CPSHF      --产品赎回费
                   ,t.CPTGF      --产品托管费
                   ,t.CPGLF      --产品管理费
                   ,t.CESYFC     --超额收益分成
                   ,t.XSFWF      --销售服务费
                   ,t.GRSCRGZDJE --个人首次认购最低金额
                   ,t.JGSCRGZDJE --机构首次认购最低金额
                   ,t.GRZJRGZDJE --个人追加认购最低金额
                   ,t.JGZJRGZDJE --机构追加认购最低金额
                   ,t.GMQDMS     --购买起点描述
                   ,t.SGKSR      --申购开始日
                   ,t.SGJSR      --申购结束日
                   ,t.GRSCSGZDJE --个人首次申购最低金额
                   ,t.JGSCSGZDJE --机构首次申购最低金额
                   ,t.GRZJSGZDJE --个人追加申购最低金额
                   ,t.JGZJSGZDJE --机构追加申购最低金额
                   ,t.SGRSSX     --申购人数上限
                   ,t.SGJSRQ     --申购交收日期
                   ,t.SHJSRQ     --赎回交收日期
                   ,t.CXKFQSR    --存续开放起始日
                   ,t.CXKFJSR    --存续开放结束日
                   ,t.RGJSR 	 --认购交收日期		   
 FROM       C5CX.SPIF_TSPIF_CPDM_PT_JZJY    t
 WHERE      t.DT = '%d{yyyyMMdd}';
----插入数据结束--------------



 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:服务产品属性表                                                                      */
  --/* 创建人:CHANGJINGJING                                                                         */
  --/* 创建时间:2019-01-10                                                                          */ 
  
-----------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T04_C5_VPIF_FWCP(
                       ID                   --ID
                       ,CPBH                 --产品编号
                       ,CPML                 --产品目录
                       ,CPMLMC               --产品目录名称
                       ,CPMC                 --产品名称
                       ,CPFL                 --产品分类
                       ,CPFLMC               --产品分类名称
                       ,CPZT                 --产品状态
                       ,CPZTMC               --产品状态名称
                       ,CPMS                 --产品描述
                       ,KXCPSL               --可选产品数量
                       ,SJRQ                 --上架日期
                       ,ZDSLXZ               --最大数量限制
                       ,SFAFWCP              --是否A6服务产品
                       ,SFAFWCPZ             --是否A6服务产品
                       ,YXQ                  --有效期
                       ,CPLY                 --产品来源
                       ,CPLYMC               --产品来源名称
                       ,KFRY                 --开发人员
                       ,TGJS                 --投顾介绍
                       ,TZLN                 --投资理念
                       ,MZTK                 --免责条款
                       ,EJFL                 --二级分类
                       ,EJFLMC               --二级分类名称
                       ,CPFXDJ               --产品风险等级
                       ,CPFXDJMC             --产品风险等级名称
                       ,SFFXJS               --是否风险警示
                       ,SFFXJSZ              --是否风险警示
                       ,SHYYBFW              --适合营业部范围
                       ,SHYYBMC              --适合营业部范围名称
                       ,SHKHFW               --适合客户范围
                       ,SHKHFWMC             --适合客户范围名称
                       ,SFLB                 --收费类别
                       ,SFLBMC               --收费类别名称
                       ,SFRX                 --是否热销
                       ,RX                   --是否热销
                       ,SFCX                 --是否促销
                       ,CX                   --是否促销
                       ,SFXCP                --是否新产品
                       ,XCP                  --是否新产品
                       ,SFQY                 --是否需签约产品
                       ,SFXYQYCP             --是否需签约产品
                       ,TJZS                 --推荐指数
                       ,TJZSZ                --推荐指数
                       ,GLR                  --管理人
                       ,GLRMC                --管理人名称	
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                        t.ID                   --ID
                       ,t.CPBH                 --产品编号
                       ,t.CPML                 --产品目录
                       ,t.CPMLMC               --产品目录名称
                       ,t.CPMC                 --产品名称
                       ,t.CPFL                 --产品分类
                       ,t.CPFLMC               --产品分类名称
                       ,t.CPZT                 --产品状态
                       ,t.CPZTMC               --产品状态名称
                       ,t.CPMS                 --产品描述
                       ,t.KXCPSL               --可选产品数量
                       ,t.SJRQ                 --上架日期
                       ,t.ZDSLXZ               --最大数量限制
                       ,t.SFAFWCP              --是否A6服务产品
                       ,t.SFAFWCPZ             --是否A6服务产品
                       ,t.YXQ                  --有效期
                       ,t.CPLY                 --产品来源
                       ,t.CPLYMC               --产品来源名称
                       ,t.KFRY                 --开发人员
                       ,t.TGJS                 --投顾介绍
                       ,t.TZLN                 --投资理念
                       ,t.MZTK                 --免责条款
                       ,t.EJFL                 --二级分类
                       ,t.EJFLMC               --二级分类名称
                       ,t.CPFXDJ               --产品风险等级
                       ,t.CPFXDJMC             --产品风险等级名称
                       ,t.SFFXJS               --是否风险警示
                       ,t.SFFXJSZ              --是否风险警示
                       ,t.SHYYBFW              --适合营业部范围
                       ,t.SHYYBMC              --适合营业部范围名称
                       ,t.SHKHFW               --适合客户范围
                       ,t.SHKHFWMC             --适合客户范围名称
                       ,t.SFLB                 --收费类别
                       ,t.SFLBMC               --收费类别名称
                       ,t.SFRX                 --是否热销
                       ,t.RX                   --是否热销
                       ,t.SFCX                 --是否促销
                       ,t.CX                   --是否促销
                       ,t.SFXCP                --是否新产品
                       ,t.XCP                  --是否新产品
                       ,t.SFQY                 --是否需签约产品
                       ,t.SFXYQYCP             --是否需签约产品
                       ,t.TJZS                 --推荐指数
                       ,t.TJZSZ                --推荐指数
                       ,t.GLR                  --管理人
                       ,t.GLRMC                --管理人名称						   
 FROM       C5CX.SPIF_VPIF_FWCP t
 WHERE      t.DT = '%d{yyyyMMdd}';
----插入数据结束--------------

--INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
--PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_C5_VPIF_FWCP',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

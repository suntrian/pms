 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:转融通交易时间表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
     TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZRT_JYSJ;
------插入数据开始--------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZRT_JYSJ
(
                                    ZRT_YWLX                            --转融通业务类型                            
                                   ,JYS                                 --交易所                                
                                   ,SWKSSJ                              --上午开始时间                             
                                   ,SWJSSJ                              --上午结束时间                             
                                   ,XWKSSJ                              --下午开始时间                             
                                   ,XWBSSJ                              --下午闭市时间                             
                                   ,ZRT_JYZT                            --转融通交易状态                            
                                   ,KFJYLB                              --允许业务类别                             
                                   ,XGRQ                                --修改日期   
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.YWLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )        --将YWLX改为YWLB                        as ZRT_YWLX                            --业务类别                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.SWKSSJ                              as SWKSSJ                              --上午开始时间                              
                                   ,t.SWJSSJ                              as SWJSSJ                              --上午结束时间                              
                                   ,t.XWKSSJ                              as XWKSSJ                              --下午开始时间                              
                                   ,t.XWBSSJ                              as XWBSSJ                              --下午闭市时间                              
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZRT_JYZT                            --交易状态                                
                                   ,t.KFJYLB                              as KFJYLB                              --允许业务类别                              
                                   ,t.BDRQ                                as XGRQ                                --修改日期 
								   ,'RZRQ'                                as XTBS
                                   								   
 FROM           RZRQCX.ZRT_TZRT_JYSJ                          t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t1 
 ON             t1.DMLX = 'ZRT_YWLX'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.YWLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t2 
 ON             t2.DMLX = 'ZRT_JYZT'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.JYZT AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
----------插入数据结束---------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZRT_JYSJ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

invalidate metadata EDW_PROD.T_EDW_T02_TZRT_JYSJ;

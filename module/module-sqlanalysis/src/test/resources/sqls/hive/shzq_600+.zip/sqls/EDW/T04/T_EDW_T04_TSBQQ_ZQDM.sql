--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:三板确权确权证券代码表                                                               */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T04_TSBQQ_ZQDM;
------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T04_TSBQQ_ZQDM
(
                                    ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,BZDM                                --币种代码                               
                                   ,QSLB                                --券商类别                               
                                   ,ZBQS                                --主办券商代码                             
                                   ,GFXZFW                              --确权股份性质范围       
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as BZDM                                --币种                                  
                                   ,t.QSLB                                as QSLB                                --券商类别                                
                                   ,t.ZBQS                                as ZBQS                                --主办券商代码                              
                                   ,t.GFXZFW                              as GFXZFW                              --确权股份性质范围 
                                   ,'JZJY'				                  as XTBS				   
 FROM 			JZJYCX.SECURITIES_TSBQQ_ZQDM 				t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 		t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 WHERE 			t.DT = '%d{yyyyMMdd}';

---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TSBQQ_ZQDM',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;


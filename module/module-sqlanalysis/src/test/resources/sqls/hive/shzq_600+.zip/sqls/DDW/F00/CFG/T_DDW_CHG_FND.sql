----导入基金的配置
load data inpath '/user/gbk/data/T_DDW_CHG_FND.csv' overwrite  into table DDW_PROD.T_DDW_CHG_FND;


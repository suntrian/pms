 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:客户风险级别变更信息表                                                               */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 
 /*  T_DDW_F05_BIZ_SYS_TRD_OPE_DETAIL  修改为  T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS */

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CUST_RSK_LVL_CHANGE_INFO
(
				BRH_NO         --营业部编号
               ,BRH_NAME       --营业部名称
               ,CUST_NO        --客户号  
               ,CUST_NAME      --客户姓名 
               ,CHANGE_DT      --变更日期 
               ,ABST           --摘要         
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
						 t.BRH_NO   	AS BRH_NO         --营业部编号   
						,t.BRH_NAME 	AS BRH_NAME       --营业部名称   
						,t.CUST_NO  	AS CUST_NO        --客户号     
						,t.CUST_NAME	AS CUST_NAME      --客户姓名    
						,t.DT       	AS CHANGE_DT      --变更日期    
						,t.ABST       AS ABST           --摘要              
			
  FROM  		    DDW_PROD.T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS              	t          
  WHERE			    t.bus_date = %d{yyyyMMdd}
  AND           t.BIZ_SBJ = '20053'
  AND           t.ABST NOT LIKE '%激活后处理%'
  AND           t.ABST NOT LIKE '%开户%'
  AND           t.SYS_SRC = 'JZJY'
  ;
 
-----------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_CUST_RSK_LVL_CHANGE_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_CUST_RSK_LVL_CHANGE_INFO; 
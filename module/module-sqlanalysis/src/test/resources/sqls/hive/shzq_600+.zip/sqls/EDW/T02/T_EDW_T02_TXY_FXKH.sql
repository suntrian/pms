-- /* ***************************************** SQL Begin ***************************************** */
 -- /* 脚本功能:融资融券风险客户表                                                                  */
  --/* 创建人:黄勇华                                                                              */
 --/* 创建时间:2016-11-02                                                                        */ 
    TRUNCATE TABLE EDW_PROD.T_EDW_T02_TXY_FXKH;   
------插入数据开始-----------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TXY_FXKH(
                                    KHH                                 --生成日期                               
                                   ,SCRQ                                --营业部                                
                                   ,YYB                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,TSLB                                --提示类别                               
                                   ,ZT                                  --状态                                 
                                   ,BDRQ                                --变动日期                               
                                   ,BZ                                  --备注                                 
                                   ,XGJYR                               --下一个交易日                             
                                   ,DBBL                                --担保比例                               
                                   ,ZZC                                 --总资产                                
                                   ,ZFZ                                 --总负债                                
                                   ,KYBZJ                               --可用保证金                              
                                   ,BFBZ                                --备份标志                               
                                   ,BFRQ                                --备份日期  
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                
                                   ,t.SCRQ                                as SCRQ                                --生成日期                                 
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --营业部                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.TSLB                                as TSLB                                --提示类别                                
                                   ,t.ZT                                  as ZT                                  --状态                                  
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.BZ                                  as BZ                                  --备注                                  
                                   ,t.XGJYR                               as XGJYR                               --下一个交易日                              
                                   ,t.DBBL                                as DBBL                                --担保比例                                
                                   ,t.ZZC                                 as ZZC                                 --总资产                                 
                                   ,t.ZFZ                                 as ZFZ                                 --总负债                                 
                                   ,t.KYBZJ                               as KYBZJ                               --可用保证金                               
                                   ,t.BFBZ                                as BFBZ                                --备份标志                                
                                   ,t.BFRQ                                as BFRQ                                --备份日期  
                                   ,'RZRQ'                                as XTBS								   
 FROM           RZRQCX.MARGIN_TXY_FXKH            t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'RZRQ'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE t.DT = '%d{yyyyMMdd}';
-----插入数据结束----------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TXY_FXKH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TXY_FXKH;

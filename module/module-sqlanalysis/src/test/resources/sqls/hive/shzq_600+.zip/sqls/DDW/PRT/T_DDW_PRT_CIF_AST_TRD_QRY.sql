 /* ***************************************** SQL Begin ***************************************** */
  /* 脚本功能:柜台资产和交易查询报表                                                              */
  /* 创建人:黄勇华                                                                                */
  /* 创建时间:2018-05-17                                                                          */ 
  /* 修改时间:2018-07-10                                                                          */  
-----创建临时表前10,前20个交易日


----------------------------------------------------
 TRUNCATE TABLE DDW_PROD.T_DDW_PRT_CIF_AST_TRD_QRY1 ;
 -------------------------------------------------------
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_AST_TRD_QRY_TEMP;
 CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_AST_TRD_QRY_TEMP
 as SELECT a.TRD_DT,b.TRD_DT as TRD_DT_20,c.TRD_DT as TRD_DT_10
  --,d.TRD_DT_HALF_YEAR,d.HALF_YEAR_DAYS, e.TRD_DT_YEAR,e.YEAR_DAYS
   FROM (SELECT  TRD_DT
                ,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC ) as NUM				
         FROM (SELECT   TRD_DT 
               FROM     EDW_PROD.T_EDW_T99_TRD_DATE 
               WHERE    BUS_DATE = %d{yyyyMMdd} 
               AND      TRD_DT >= 20140101
			   AND      TRD_DT = %d{yyyyMMdd}
               GROUP BY TRD_DT
               )    a
        )    a
  LEFT JOIN (SELECT  TRD_DT
                    ,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC) -19 as NUM				
              FROM (SELECT   TRD_DT		  
                    FROM     EDW_PROD.T_EDW_T99_TRD_DATE 
                    WHERE    BUS_DATE = %d{yyyyMMdd}
                    AND      TRD_DT >= 20140101
					AND      TRD_DT <= %d{yyyyMMdd}
                    GROUP BY TRD_DT
                    )    b
		    )                      b
   ON       a.NUM = b.NUM
   LEFT JOIN (SELECT  TRD_DT
                    ,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC) -9 as NUM				
              FROM (SELECT   TRD_DT                            	  
                    FROM     EDW_PROD.T_EDW_T99_TRD_DATE 
                    WHERE    BUS_DATE = %d{yyyyMMdd}
                    AND      TRD_DT >= 20140101
					AND      TRD_DT <= %d{yyyyMMdd}
                    GROUP BY TRD_DT
                    )    c
		    )                      c
   ON       a.NUM = c.NUM
--   LEFT JOIN  (     SELECT    MAX(TRD_DT) as TRD_DT
--                             ,MIN(TRD_DT) as TRD_DT_HALF_YEAR
--							 ,COUNT(1)    as HALF_YEAR_DAYS
--					FROM 
--                   (SELECT   TRD_DT                            	  
--                    FROM     EDW_PROD.T_EDW_T99_TRD_DATE 
--                    WHERE    BUS_DATE = %d{yyyyMMdd}
--					AND      TRD_DT BETWEEN  CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) as INT)  AND %d{yyyyMMdd}
--                    GROUP BY TRD_DT
--					) d
--			  ) d
--	ON     a.TRD_DT = d.TRD_DT
--    LEFT JOIN  (     SELECT   MAX(TRD_DT) as TRD_DT
--                             ,MIN(TRD_DT) as TRD_DT_YEAR
--							 ,COUNT(1)    as YEAR_DAYS
--					FROM 
--                   (SELECT   TRD_DT                            	  
--                    FROM     EDW_PROD.T_EDW_T99_TRD_DATE 
--                    WHERE    BUS_DATE = %d{yyyyMMdd}
--					AND      TRD_DT BETWEEN  CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) as INT)  AND %d{yyyyMMdd}
--                    GROUP BY TRD_DT
--					) e
--			  ) e
--	ON     a.TRD_DT = e.TRD_DT
   ;  
 ----插入数据   
 INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CIF_AST_TRD_QRY1
  (
            CUST_NO                                     --客户号
		  --,CUST_NAME
        -- ,CSI_MKTVAL_AVG_10                           --10日日均沪深市值          
        -- ,CSI_MKTVAL_AVG_20                           --20日日均沪深市值
           ,CUST_NAME                                   --客户姓名		
           ,NET_AST_AVG_10                              --10日日均净资产            
           ,NET_AST_AVG_20                              --20日日均净资产            
         --,WTHOUT_CRD_NET_AST_AVG_10                   --10日日均净资产(不含信用)  
        -- ,WTHOUT_CRD_NET_AST_AVG_20                   --20日日均净资产(不含信用)  
        -- ,CSI_MKTVAL_AVG_HALF_YEAR                    --半年日均沪深市值          
       --  ,NET_AST_AVG_HALF_YEAR                       --半年日均净资产            
        -- ,WTHOUT_CRD_NET_AST_AVG_HALF_YEAR            --半年日均净资产(不含信用)  
       --  ,CSI_MKTVAL_AVG_YEAR                         --近一年日均沪深市值        
       --  ,NET_AST_AVG_YEAR                            --近一年日均净资产          
      --   ,WTHOUT_CRD_NET_AST_AVG_YEAR                 --近一年日均净资产(不含信用)
      --   ,CSI_MKTVAL                                  --沪深市值                  
           ,NET_AST                                     --净资产                    
        -- ,WTHOUT_CRD_NET_AST                          --净资产(不含信用)
           ,AST                                         --资产	
 ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})
SELECT     t.CUST_NO
        --   ,SUM(CASE WHEN a2.MIN_BUS_DATE < = a1.trd_dt_10
		--             AND  t.BUS_DATE > = a1.trd_dt_10
		--			 AND  t.BUS_DATE < = %d{yyyyMMdd}
		--             THEN ROUND(t.CSI_MKTVAL*1.0000/10,2)
		--			 WHEN a2.MIN_BUS_DATE >  a1.trd_dt_10
		--			 THEN NULL
		--			 ELSE 0
		--		     END
		--		)                                        as CSI_MKTVAL_AVG_10
		--  ,SUM(CASE WHEN a2.MIN_BUS_DATE < = a1.trd_dt_20
		--            AND  t.BUS_DATE > = a1.trd_dt_20
		--			AND  t.BUS_DATE < = %d{yyyyMMdd}
		--            THEN ROUND(t.CSI_MKTVAL*1.0000/20,2)
		--		    WHEN a2.MIN_BUS_DATE >  a1.trd_dt_20
		--			THEN NULL
		--			ELSE 0
		--		    END
		--	  )                                          as CSI_MKTVAL_AVG_20
		 ,a3.CUST_NAME                        AS CUST_NAME
		 ,SUM(CASE WHEN a2.MIN_BUS_DATE < = a1.trd_dt_10
		           AND  t.BUS_DATE > = a1.trd_dt_10
				   AND  t.BUS_DATE < = %d{yyyyMMdd}
		           THEN ROUND(t.NET_AST*1.0000/10,2)
				   WHEN a2.MIN_BUS_DATE >  a1.trd_dt_10
				   THEN NULL
				   ELSE 0
				   END
				)                                        as NET_AST_AVG_10
		  ,SUM(CASE WHEN a2.MIN_BUS_DATE < = a1.trd_dt_20
		            AND  t.BUS_DATE > = a1.trd_dt_20
					AND  t.BUS_DATE < = %d{yyyyMMdd}
		            THEN ROUND(t.NET_AST*1.0000/20,2)
					WHEN a2.MIN_BUS_DATE >  a1.trd_dt_20
					THEN NULL
					ELSE 0
				    END
			  )                                          as NET_AST_AVG_20
	    --   ,SUM(CASE WHEN a2.MIN_BUS_DATE < = a1.trd_dt_10
		--             AND  t.BUS_DATE > = a1.trd_dt_10
		--			AND  t.BUS_DATE < = %d{yyyyMMdd}
		--            THEN ROUND(t.WTHOUT_CRD_NET_AST*1.0000/10,2)
		--			WHEN a2.MIN_BUS_DATE >  a1.trd_dt_10
		--			THEN NULL
		--			ELSE 0
		--		    END
		--		)                                        as WTHOUT_CRD_NET_AST_AVG_10
		--  ,SUM(CASE WHEN a2.MIN_BUS_DATE < = a1.trd_dt_20
		--            AND  t.BUS_DATE > = a1.trd_dt_20
		--			AND  t.BUS_DATE < = %d{yyyyMMdd}
		--            THEN ROUND(t.WTHOUT_CRD_NET_AST*1.0000/20,2)
		--			WHEN a2.MIN_BUS_DATE >  a1.trd_dt_20
		--			THEN NULL
		--			ELSE 0
		--		    END
		--	  )                                          as WTHOUT_CRD_NET_AST_AVG_20
		-- ,SUM(CASE WHEN a2.MIN_BUS_DATE < = a1.TRD_DT_HALF_YEAR
		--            AND  t.BUS_DATE > = a1.TRD_DT_HALF_YEAR
		--			AND  t.BUS_DATE < = %d{yyyyMMdd}
		--           THEN ROUND(t.CSI_MKTVAL*1.0000/a1.HALF_YEAR_DAYS,2)
		--		   WHEN a2.MIN_BUS_DATE >  a1.TRD_DT_HALF_YEAR
		--			THEN NULL
		--			ELSE 0
		--		   END
		--		)                                       as CSI_MKTVAL_AVG_HALF_YEAR                    --半年平均沪深市值          
        -- ,SUM(CASE WHEN a2.MIN_BUS_DATE < = a1.TRD_DT_HALF_YEAR
		--           AND  t.BUS_DATE > = a1.TRD_DT_HALF_YEAR
		--			AND  t.BUS_DATE < = %d{yyyyMMdd}
		--           THEN ROUND(t.NET_AST*1.0000/a1.HALF_YEAR_DAYS,2)
		--		   WHEN a2.MIN_BUS_DATE >  a1.TRD_DT_HALF_YEAR
		--			THEN NULL
		--			ELSE 0
		--		   END
		--		)                                       as NET_AST_AVG_HALF_YEAR                       --半年平均净资产            
        -- ,SUM(CASE WHEN a2.MIN_BUS_DATE < = a1.TRD_DT_HALF_YEAR
		--            AND  t.BUS_DATE > = a1.TRD_DT_HALF_YEAR
		--			AND  t.BUS_DATE < = %d{yyyyMMdd}
		--           THEN ROUND(t.WTHOUT_CRD_NET_AST*1.0000/a1.HALF_YEAR_DAYS,2)
		--		   WHEN a2.MIN_BUS_DATE >  a1.TRD_DT_HALF_YEAR
		--			THEN NULL
		--			ELSE 0
		--		   END
		--		)                                      as WTHOUT_CRD_NET_AST_AVG_HALF_YEAR            --半年平均净资产(不含信用)  
        -- ,SUM(CASE WHEN a2.MIN_BUS_DATE < = a1.TRD_DT_YEAR
		--            AND  t.BUS_DATE > = a1.TRD_DT_YEAR
		--			AND  t.BUS_DATE < = %d{yyyyMMdd}
		--           THEN ROUND(t.CSI_MKTVAL*1.0000/a1.YEAR_DAYS,2)
		--		   WHEN a2.MIN_BUS_DATE >  a1.TRD_DT_YEAR
		--			THEN NULL
		--			ELSE 0
		--		   END
		--		)                                      as CSI_MKTVAL_AVG_YEAR                         --近一年平均沪深市值        
        -- ,SUM(CASE WHEN a2.MIN_BUS_DATE < = a1.TRD_DT_YEAR
		--            AND  t.BUS_DATE > = a1.TRD_DT_YEAR
		--			AND  t.BUS_DATE < = %d{yyyyMMdd}
		--             THEN ROUND(t.NET_AST*1.0000/a1.YEAR_DAYS,2)
		--			 WHEN a2.MIN_BUS_DATE >  a1.TRD_DT_YEAR
		--			THEN NULL
		--			ELSE 0
		--		     END
		--		)                                     as NET_AST_AVG_YEAR                            --近一年平均净资产          
        -- ,SUM(CASE WHEN a2.MIN_BUS_DATE < = a1.TRD_DT_YEAR
		--            AND  t.BUS_DATE > = a1.TRD_DT_YEAR
		--			AND  t.BUS_DATE < = %d{yyyyMMdd}
		--           THEN ROUND(t.WTHOUT_CRD_NET_AST*1.0000/a1.YEAR_DAYS,2)
		--		   WHEN a2.MIN_BUS_DATE >  a1.TRD_DT_YEAR
		--			THEN NULL
		--			ELSE 0
		--		   END
		--		)                                      as WTHOUT_CRD_NET_AST_AVG_YEAR                 --近一年平均净资产(不含信用)
        -- ,SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd}
		--           THEN t.CSI_MKTVAL
		--	       ELSE 0
		--	       END
		--	 )                                          as CSI_MKTVAL                                  --沪深市值                  
         ,SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd}
		           THEN t.NET_AST
			       ELSE 0
			       END
			 )                                          as NET_AST                                     --净资产                    
        -- ,SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd}
		--           THEN t.WTHOUT_CRD_NET_AST
		--	       ELSE 0
		--	       END
		--	 )                                          as WTHOUT_CRD_NET_AST                          --净资产(不含信用)
      ,SUM(CASE WHEN t.BUS_DATE = %d{yyyyMMdd}
		           THEN t.AST
			       ELSE 0
			       END
			 )                                          as NET_AST                                     --净资产 		
FROM     (SELECT  1                                                 as num
                --  ,SUM(SH_ASTK_MKTVAL+SZ_ASTK_MKTVAL+SZ_GEM_MKTVAL) as CSI_MKTVAL
				  ,SUM(NET_TOT_AST)                                     as NET_AST
				--  ,SUM(ORDI_ACCNT_AST+CRD_ACCNT_AST)                as WTHOUT_CRD_NET_AST
				  ,SUM(TOT_AST)                               as AST
				  ,BUS_DATE
				  ,CUST_NO
          FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
		  WHERE      BUS_DATE BETWEEN  CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) as INT)  AND %d{yyyyMMdd}
		  GROUP BY NUM,BUS_DATE,CUST_NO
		  )              t
LEFT JOIN  (SELECT  1 as NUM
                     ,*                           	  
            FROM     DDW_PROD.T_DDW_PRT_CIF_AST_TRD_QRY_TEMP
		   )                                         a1
ON        t.NUM = a1.NUM
LEFT JOIN (SELECT   MIN(BUS_DATE) as MIN_BUS_DATE
                  ,MAX(BUS_DATE) as MAX_BUS_DATE
				  ,CUST_NO
           FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
		   WHERE      BUS_DATE BETWEEN  CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,-70) as INT)  AND %d{yyyyMMdd}
		   GROUP BY CUST_NO
		  )                                             a2
ON      t.CUST_NO = a2.CUST_NO
LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_INFO             a3
ON      t.CUST_NO = a3.CUST_NO
AND     a3.BUS_DATE = %d{yyyyMMdd}    
WHERE a2.MAX_BUS_DATE = %d{yyyyMMdd}
GROUP BY  t.CUST_NO,CUST_NAME;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_AST_TRD_QRY_TEMP;

--------------------加载结束----------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_CIF_AST_TRD_QRY1',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_CIF_AST_TRD_QRY1 ;
--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:分级基金代码历史                                                                           */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */ 


---创建临时表1
DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TFXJJDM_LS_TEMP;
CREATE TABLE  EDW_PROD.T_EDW_T04_TFXJJDM_LS_TEMP 
as 
SELECT  SUBSTR(a1.SecurityCode,1,6) as ZQDM
       ,SUBSTR(a2.SecurityCode,1,6) as JJDM
	   ,CAST(CONCAt(substr(t.startdate,1,4),substr(t.startdate,6,2),substr(t.startdate,9,2) ) as INT) as KSRQ
	   ,CAST(CONCAt(substr(t.enddate,1,4),substr(t.enddate,6,2),substr(t.enddate,9,2) ) as INT)  as  JSRQ
FROM         FUNDEXT.DBO_MF_CODERELATIONSHIPNEW   t
LEFT JOIN    FUNDEXT.DBO_MF_FundArchives           a1
ON           t.INNERCODE = a1.INNERCODE
AND          a1.DT = '%d{yyyyMMdd}'
LEFT JOIN    FUNDEXT.DBO_MF_FundArchives           a2
ON           t.relatedinnercode = a2.INNERCODE
AND          a2.DT = '%d{yyyyMMdd}'
WHERE        t.DT = '%d{yyyyMMdd}'
AND          t.CODEDEFINE = 21 
AND          t.sndcodedefine = 2101
 ;
---创建临时表2
DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TFXJJDM_LS_TEMP1;
CREATE TABLE  EDW_PROD.T_EDW_T04_TFXJJDM_LS_TEMP1 
as SELECT      t.ZQDM
              ,t.JJDM
			  ,t.KSRQ
			  ,NVL(t.JSRQ,99999999) as JSRQ
			  ,ROW_NUMBER() OVER(PARTITION BY t.ZQDM,t.KSRQ,t.JSRQ ORDER BY t.JJDM)  as NUM
   FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS_TEMP  t
   WHERE NOT EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS_TEMP a
                    WHERE  a.ZQDM < > a.JJDM
                    AND    t.ZQDM = a.JJDM					
                    AND    t.KSRQ = a.KSRQ
					AND    NVL(t.JSRQ,99999999) = NVL(a.JSRQ,99999999)
                     )
 ;
 ---插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TFXJJDM_LS
 (
             JYS                       --交易所
            ,ZQDM                      --证券代码
            ,JJDM                      --基金代码
            ,KSRQ                      --开始日期
            ,JSRQ                      --结束日期
            ,JJFL                      --AB基金	
 ) 
 PARTITION( bus_date = %d{yyyyMMdd}) 
 SELECT      CASE WHEN SUBSTR(t.ZQDM,1,3) IN ('500','501','502','503','505','506','510','511','512','513','518','519','515')
                  THEN 'SH'
				  WHEN  SUBSTR(t.ZQDM,1,3) IN ('150','151','159','184') OR SUBSTR(t.ZQDM,1,2) = '16'
				  THEN 'SZ'
				  ELSE 'CW'
				  END   as JYS                       --交易所
            ,t.ZQDM     as ZQDM                      --证券代码
            ,t.JJDM     as JJDM                      --基金代码
            ,t.KSRQ     as KSRQ                      --开始日期
            ,t.JSRQ     as JSRQ                      --结束日期
            ,t.NUM      as JJFL                      --AB基金	
 FROM  EDW_PROD.T_EDW_T04_TFXJJDM_LS_TEMP1   t 
 ;
 
 
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TFXJJDM_LS_TEMP;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TFXJJDM_LS_TEMP1;
 
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TFXJJDM_LS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360普通信用账户交易明细月表                                                        */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-10-27                                                                       */ 
  


---------------- 插入数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_ORDI_CRD_ACCNT_TRD_DTL_MON
 (
	 STATS_MON          --统计年月  
	,CUST_NO            --客户号
	,SHRHLD_NO          --股东账户
	,EXG                --交易所
	,SEC_CD             --证券代码
	,SEC_NAME           --证券名称
	,TRD_CL             --交易品种
	,CCY                --币种
	,BIZ_FLAG           --业务标志
	,MTCH_QTY           --成交数量
	,MTCH_AMT           --成交金额
	,S1                 --毛佣金
	,NET_CMSN           --净佣金
    ,ACCNT_CGY          --账户类别
 )PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT      CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)              as STATS_MON          --统计年月 
            ,t.CUST_NO                as CUST_NO            --客户号
            ,t.SHRHLD_NO              as SHRHLD_NO          --股东账户
			,a2.EXG_NAME              as EXG                --交易所
            ,t.SEC_CD                 as SEC_CD             --证券代码
            ,t.SEC_NAME               as SEC_NAME           --证券名称
            ,a1.SEC_CL_NAME           as TRD_CL             --交易品种
            ,a4.CCY_CD_NAME           as CCY                --币种           
			,CASE WHEN t.ODR_CGY = 1111
			      THEN '基金申购'
				  WHEN t.ODR_CGY = 2222
				  THEN '基金赎回'
				  ELSE a3.JYLBMC
				  END                 as BIZ_FLAG           --业务标志
            ,SUM(NVL(t.MTCH_QTY,0))   as MTCH_QTY           --成交数量
            ,SUM(NVL(t.MTCH_AMT,0))   as MTCH_AMT           --成交金额
            ,SUM(NVL(t.S1,0))         as S1                 --毛佣金
            ,SUM(NVL(t.S1,0)-NVL(t.S11,0)-NVL(t.S12,0))    as NET_CMSN           --净佣金
            ,t.SYS_SRC              as ACCNT_CGY          --账户类别
 FROM         DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS         t
 LEFT JOIN    (SELECT EXG,SEC_CD_PFX,SEC_CGY_PFX,SEC_CL_NAME 
               FROM DDW_PROD.T_DDW_CFG_SEC_TRD_CL 
               GROUP BY EXG,SEC_CD_PFX,SEC_CGY_PFX,SEC_CL_NAME
			   )               a1
 ON           (SUBSTR(t.SEC_CGY,1,1) = a1.SEC_CD_PFX
 OR           SUBSTR(t.SEC_CGY,1,3) = a1.SEC_CD_PFX)
 AND          t.EXG = a1.EXG
 AND          SUBSTR(t.SEC_CD,1,3) = a1.SEC_CD_PFX
 LEFT JOIN    DDW_PROD.V_EXG                         a2
 ON           t.EXG = a2.EXG
 LEFT JOIN    EDW_PROD.T_EDW_T99_TJYLB               a3
 ON           t.ODR_CGY = a3.JYLB  
 AND          ((a3.XTBS = 'JZJY' AND t.SYS_SRC = '普通账户') OR (a3.XTBS = 'RZRQ' AND t.SYS_SRC = '信用账户'))
 AND           a3.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN    DDW_PROD.V_CCY_CD                     a4
 ON           t.CCY_CD = a4.CCY_CD 
 WHERE        t.ODR_CGY IN (1,42,57,59,61,63,16,1111,78,2,12,13,17,43,58,60,62,64,71,2222)
 AND          SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 GROUP BY   STATS_MON,CUST_NO,SHRHLD_NO,EXG,SEC_CD,SEC_NAME,TRD_CL,CCY,BIZ_FLAG,ACCNT_CGY
 
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_ORDI_CRD_ACCNT_TRD_DTL_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_ORDI_CRD_ACCNT_TRD_DTL_MON;
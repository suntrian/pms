 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:证券委托明细历史表                                                                  */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  

-------------删除临时表-------------------
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_TRD_SEC_ODR_DEL_HIS_TEMP ;
  CREATE  TABLE DDW_PROD.T_DDW_F00_TRD_SEC_ODR_DEL_HIS_TEMP 
  as SELECT      t1.KHH
                ,t1.RQ
				, 1  as BZ 
     FROM ( SELECT    t.KHH
	                 ,t.RQ
            FROM  ( SELECT    KHH
			                  ,RQ
                    FROM    EDW_PROD.T_EDW_T05_TYGTXTCZMX
                    WHERE   YWKM = '20090' 
					OR      ZY LIKE '%二代证验证%'
                    UNION ALL
                    SELECT     a.KHH
					          ,b.SQRQ as RQ
                    FROM       (SELECT YYB
					                  ,ZJBH
									  ,KHH
								FROM  EDW_PROD.T_EDW_T01_TKHXX 
								WHERE BUS_DATE = %d{yyyyMMdd}
								)     a
                   INNER JOIN (SELECT  ZJBH
				                       ,YYB
									   ,SQRQ
							   FROM  EDW_PROD.T_EDW_T02_TGMSFCXSQ 
							   WHERE CLJG = 1
							   )                b
                  ON           a.yyb = b.yyb
                  AND          a.zjbh = b.zjbh
                 ) t
           GROUP BY t.khh,t.rq
          )       t1
	  ; 
---结束--


--------------插入ABOSS,RZRQ数据-------------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_TRD_SEC_ODR_DEL_HIS
(
                                   EVNT_SEQNBR                       --事件序号         
                                   ,JOUR_NO                            --流水号           
                                   ,ODR_NO                             --委托号           
                                   ,RPT_ODR_NO                         --申报委托号         
                                   ,ORIG_RPT_ODR_NO                    --原申报委托号        
                                   ,CUST_NO                            --客户号           
                                   ,CUST_NAME                          --客户姓名          
                                   ,BRH_NO                             --营业部编号         
                                   ,BRH_NAME                           --营业部名称         
                                   ,EXG                                --交易所           
                                   ,SHRHLD_NO                          --股东号           
                                   ,ODR_CGY                            --委托类别          
                                   ,SEC_CD                             --证券代码 
								   ,SEC_CD1                            --证券代码 
                                   ,SEC_NAME                           --证券名称          
                                   ,SEC_CGY                            --证券类别 
                                   ,CCY_CD                                --币种代码									   
                                   ,ODR_QTY                            --委托数量          
                                   ,ODR_PRC                             --委托价格          
                                   ,ODR_DT                             --委托日期          
                                   ,ODR_TM                             --委托时间          
                                   ,RPT_DT                             --申报日期          
                                   ,RPT_RSLT                           --申报结果          
                                   ,RSLT_EXPLN                         --结果说明          
                                   ,RPT_TM                             --申报时间          
                                   ,MTCH_QTY                           --成交数量          
                                   ,MTCH_AMT                           --成交金额          
                                   ,MTCH_PRC                           --成交价格          
                                   ,MTCH_MT                            --成交时间                 
                                   ,OCC_BRH_NO                         --发生营业部         
                                   ,ODR_TELR                           --委托柜员          
                                   ,ODR_MOD                            --委托方式          
                                   ,OPRT_CLNT                          --操作终端          
                                   ,RECHK_TELR                         --复核柜员          
                                   ,SECOND_CARD_VRFCTN                 --二代证验证         
                                   ,IP_IPHONE_ADDR                     --IP地址/ 电话号码    
                                   ,MAC_ADDR                           --MAC地址         
                                   ,ACCNT_CGY                          --账户类别       
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT                             t.SEQNO                                 as EVNT_SEQNBR                       --事件序号 
                                   ,t.LSH                                   as JOUR_NO                           --流水号                                                            
                                   ,t.WTH                                   as ODR_NO                            --委托号                                                            
                                   ,t.SBWTH                                 as RPT_ODR_NO                        --申报委托号                                                                                               
                                   ,NULL                                    as ORIG_RPT_ODR_NO                   --原申报委托号                                                         
                                   ,t.KHH                                   as CUST_NO                           --客户号                                                            
                                   ,t.KHXM                                  as CUST_NAME                         --客户姓名                                                           
                                   ,t.YYB                                   as BRH_NO                            --营业部编号                                                          
                                   ,a1.BRH_SHRTNM                           as BRH_NAME                          --营业部名称                                                          
                                   ,t.JYS                                   as EXG                               --交易所                                                            
                                   ,t.GDH                                   as SHRHLD_NO                         --股东号                                                            
                                   ,t.WTLB                                  as ODR_CGY                           --委托类别
                                   ,CASE WHEN a5.ExApplyingCode IS NOT NULL
								         THEN a5.SecurityCode
										 ELSE EDW_PROD.CODE_TRANS_ZQDM(JYS,ZQDM)
								   		 END	                            AS SEC_CD                            --证券代码								   
                                   ,t.ZQDM                                  as SEC_CD1                           --证券代码                                                           
                                   ,t.ZQMC                                  as SEC_NAME                          --证券名称                                                           
                                   ,t.ZQLB                                  as SEC_CGY                           --证券类别  
                                   ,t.BZDM                                  as CCY_CD                                --币种代码									   
                                   ,t.WTSL                                  as ODR_QTY                           --委托数量                                                           
                                   ,t.WTJG                                  as ODR_PRC                           --委托价格                                                                                                                                    
                                   ,t.WTRQ                                  as ODR_DT                            --委托日期                                                           
                                   ,t.WTSJ                                  as ODR_TM                            --委托时间                                                                                     
                                   ,t.SBRQ                                  as RPT_DT                            --申报日期                                                                                            
                                   ,t.SBJG                                  as RPT_RSLT                          --申报结果                                                           
                                   ,t.JGSM                                  as RSLT_EXPLN                        --结果说明                                                          
                                   ,t.SBSJ                                  as RPT_TM                            --申报时间            
                                   ,t.CJSL                                  as MTCH_QTY                          --成交数量            
                                   ,t.CJJE                                  as MTCH_AMT                          --成交金额            
                                   ,t.CJJG                                  as MTCH_PRC                          --成交价格            
                                   ,t.CJSJ                                  as MTCH_MT                           --成交时间                     
                                   ,t.FSYYB                                 as OCC_BRH_NO                        --发生营业部           
                                   ,a3.XM                                   as ODR_TELR                          --委托柜员            
                                   ,t.WTFS                                  as ODR_MOD                           --委托方式            
                                   ,t.CZZD1                                 as OPRT_CLNT                         --操作终端            
                                   ,CASE WHEN t.FHGY IS NULL
                                         THEN NULL
                                         ELSE a4.XM
                                         END                                as RECHK_TELR                        --复核柜员            
                                   ,CASE WHEN a2.BZ = 1 
                                         THEN '已验证'	
 										 ELSE '未验证'
										 END                                as SECOND_CARD_VRFCTN                --二代证验证           
                                   ,t.IP_PHONE                              as IP_IPHONE_ADDR                    --IP地址/ 电话号码      
                                   ,t.MAC                                   as MAC_ADDR                          --MAC地址           
                                   ,CASE WHEN  t.XTBS = 'JZJY'
                                         THEN  '普通账户'      
                                         WHEN  t.XTBS = 'RZRQ'
                                         THEN '信用账户'
                                         END                                as ODR_SRC                              --委托来源                                                                                                                                             
  FROM          EDW_PROD.T_EDW_T05_TWTLS                  t
  LEFT JOIN     (SELECT   SecurityCode,ExApplyingCode,DT 
		          FROM    fundext.dbo_MF_FundArchives
				 WHERE    length(trim(NVL(exapplyingcode,'')))>0
				 AND      securitycode <> exapplyingcode
			     AND      substr(securitycode,7,1) <> 'J' 
				 AND      DT = '%d{yyyyMMdd}'
				 )                                                                 a5
  ON             t.ZQDM = a5.ExApplyingCode
  AND            t.JYS = 'SH'
  AND            t.ZQDM LIKE '519%'
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH               a1
  ON            t.YYB = a1.BRH_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd} 
  LEFT JOIN     DDW_PROD.T_DDW_F00_TRD_SEC_ODR_DEL_HIS_TEMP     a2
  ON            t.KHH = a2.KHH
  AND           t.WTRQ = a2.RQ
  LEFT JOIN     EDW_PROD.T_EDW_T01_TGYXX                   a3
  ON            t.WTGY = a3.loginid
  AND           t.XTBS = a3.XTBS
  AND           t.bus_date = a3.bus_date
  LEFT JOIN     EDW_PROD.T_EDW_T01_TGYXX                   a4
  ON            t.FHGY = a4.loginid
  AND           t.XTBS = a4.XTBS
  AND           t.bus_date = a4.bus_date 
  WHERE         t.bus_date = %d{yyyyMMdd}  
  
 ;
 
 
--------------------------删除临时表------------------
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_TRD_SEC_ODR_DEL_HIS_TEMP;
 
----------------------插入数据结束------------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_TRD_SEC_ODR_DEL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_F00_TRD_SEC_ODR_DEL_HIS ;
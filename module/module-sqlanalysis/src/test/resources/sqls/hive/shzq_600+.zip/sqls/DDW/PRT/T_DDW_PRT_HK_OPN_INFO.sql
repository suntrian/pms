 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:港股通开户信息表                                                                     */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 

  
  
--删除临时表
 TRUNCATE TABLE DDW_PROD.T_DDW_PRT_HK_OPN_INFO;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_HK_OPN_INFO_TEMP1;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_HK_OPN_INFO_TEMP3;
--创建临时表1
CREATE TABLE DDW_PROD.T_DDW_PRT_HK_OPN_INFO_TEMP1
AS 
SELECT  SUM(ORDI_TRD_VOL_SK) AS SGT_MTCH_AMT
       ,SUM(ORDI_TRD_VOL_HK) AS HGT_MTCH_AMT
       ,SUM(ORDI_S1_INCM_SK) AS SGT_CMSN
	   ,SUM(ORDI_S1_INCM_HK) AS HGT_CMSN
	   ,CUST_NO 

FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
WHERE (BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}) 
GROUP BY CUST_NO
;


 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_HK_OPN_INFO_TEMP3 ;
 CREATE TABLE  DDW_PROD.T_DDW_PRT_HK_OPN_INFO_TEMP3
 as SELECT * FROM 
 (SELECT khh,round(S1*1.000000/CJJE,4) as YJL,SEQNO,ROW_NUMBER() OVER(PARTITION BY KHH,JYS ORDER BY SEQNO DESC) as num
        ,JYS
 FROM EDW_PROD.T_EDW_T05_TJGMXLS
 WHERE JYS IN ('HK','SK') and s1> 0 and cjje > 0
 AND   WTLB IN (1,2)
 )  t
 WHERE t.NUM = 1 ;
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_HK_OPN_INFO
(        
								 BRH_NO                   --营业部编号  
								,BRH_NAME                 --营业部名称 
                                ,CGY                      --类别
                                ,HK_OPN_MOD               --港股通开通方式								
								,APL_DT                   --申请日期    
								,CUST_NO                  --客户号      
								,CUST_NAME                --客户姓名    
								,CTF_CGY_CD               --证件类别代码
								,CTF_NO                   --证件号码    
								,DEPMGT_BANK              --存管银行    
								,CTRL_ATTR                --控制属性    
								,IMAGE_TP                 --影像资料    
								,M_LAUND_RSK_LVL          --洗钱风险等级
								,RSK_BEAR_ABLTY           --风险承受能力
								,CTF_EXPR_DT              --证件截至日期
								,CTCT_ADDR                --联系地址    
								,CTCT_TEL                 --联系电话    
								,PHONE                    --手机        
								,EDU_CD                   --学历代码    				
								,OCP_CD                   --职业代码    
								,SECOND_CARD_VRFCTN       --二代证验证  
								,CMSN_SETUP_DT            --佣金设置日期
								,CMSN_SETUP_ABST          --佣金设置摘要
								,HK_MTCH_AMT              --港股成交量  
								,HK_CMSN                  --港股佣金
                                ,PRVL_OPEN_AGE			
                                ,RCT_TM_S1_RATE      --最近一次佣金率								
) 
 PARTITION(bus_date )
 SELECT 
					 t.BRH_NO                              AS  BRH_NO                   --营业部编号         
					,t.BRH_NAME                            AS  BRH_NAME                 --营业部名称 
                    ,CASE WHEN t.ABST LIKE '%深港%'	
                          THEN '深港通' 
						  ELSE '沪港通' 
						  END			                   AS  CGY                      --类别
                    ,t.OPRT_MOD                            AS  HK_OPN_MOD               --港股通开通方式						  
					,t.DT                                  AS  APL_DT                   --申请日期           
					,t.CUST_NO                             AS  CUST_NO                  --客户号             
					,t.CUST_NAME                           AS  CUST_NAME                --客户姓名           
					,b1.CTF_CGY_CD_NAME                    AS  CTF_CGY_CD               --证件类别代码       
					,a1.CTF_NO                             AS  CTF_NO                   --证件号码           
					,a1.DEPMGT_BANK                        AS  DEPMGT_BANK              --存管银行           
					,a1.CTRL_ATTR                          AS  CTRL_ATTR                --控制属性           
					,a1.IMAGE_TP                            AS  IMAGE_TP                 --影像资料           
					,b6.M_LAUND_RSK_LVL_NAME               AS  M_LAUND_RSK_LVL          --洗钱风险等级       
					,b2.RSK_BEAR_ABLTY_NAME                AS  RSK_BEAR_ABLTY           --风险承受能力       
					,a1.CTF_EXPR_DT                        AS  CTF_EXPR_DT              --证件截至日期       
					,a1.CTCT_ADDR                          AS  CTCT_ADDR                --联系地址           
					,a1.CTCT_TEL                           AS  CTCT_TEL                 --联系电话           
					,a1.PHONE                              AS  PHONE                    --手机               
					,b3.EDU_CD_NAME          	           AS  EDU_CD                   --学历代码    				
					,b4.OCP_CD_NAME                        AS  OCP_CD                   --职业代码           
					,t.SECOND_CARD_VRFCTN                  AS  SECOND_CARD_VRFCTN       --二代证验证         
					,t.CMSN_SETUP_DT                       AS  CMSN_SETUP_DT            --佣金设置日期       
					,t.CMSN_SETUP_ABST                     AS  CMSN_SETUP_ABST          --佣金设置摘要       
					,NVL(CASE WHEN t.ABST LIKE '%深港%'	
                          THEN a2.SGT_MTCH_AMT 
						  ELSE a2.HGT_MTCH_AMT 
						  END,0)	                           AS  HK_MTCH_AMT              --港股成交量         
					,NVL(CASE WHEN t.ABST LIKE '%深港%'	
                          THEN a2.SGT_CMSN 
						  ELSE a2.HGT_CMSN 
						  END,0)	                           AS  HK_CMSN                  --港股佣金           
			        ,cast(t.PRVL_OPEN_AGE as int)                           as  PRVL_OPEN_AGE            --权限开通年龄
					,a5.YJL                                as RCT_TM_S1_RATE      --最近一次佣金率	
					
					,t.BUS_DATE                                as  BUS_DATE                
                    
  FROM  	(SELECT *,CASE WHEN ABST LIKE '%深港%'	
                          THEN 'SK' 
						  ELSE 'HK' 
						  END as JYS FROM	 DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS  )  	t
  LEFT JOIN      DDW_PROD.T_DDW_F00_CUST_CUST_INFO        		a1
  ON             t.CUST_NO = a1.CUST_NO
  AND            a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN		 DDW_PROD.T_DDW_PRT_HK_OPN_INFO_TEMP1		a2
  ON			 t.CUST_NO = a2.CUST_NO
  LEFT JOIN 	 DDW_PROD.V_CTF_CGY_CD						b1
  ON			 a1.CTF_CGY_CD = b1.CTF_CGY_CD	
  LEFT JOIN 	 DDW_PROD.V_RSK_BEAR_ABLTY					b2
  ON			 a1.RSK_BEAR_ABLTY = b2.RSK_BEAR_ABLTY	
  LEFT JOIN 	 DDW_PROD.V_EDU_CD							b3
  ON			 a1.EDU_CD = b3.EDU_CD	
  LEFT JOIN 	 DDW_PROD.V_OCP_CD							b4
  ON			 a1.OCP_CD = b4.OCP_CD
  LEFT JOIN  DDW_PROD.V_M_LAUND_RSK_LVL            b6
  ON         a1.M_LAUND_RSK_LVL = b6.M_LAUND_RSK_LVL
  LEFT JOIN DDW_PROD.T_DDW_PRT_HK_OPN_INFO_TEMP3   a5
  ON       t.CUST_NO = a5.KHH
  AND      t.JYS = a5.JYS
  WHERE 		 ((t.BIZ_SBJ = '20201' and t.ABST LIKE '%港%') OR (LENGTH(TRIM(t.BIZ_SBJ))=0 and t.ABST LIKE '%登记股东账户:交易所[港股]%'))  
  AND            t.BUS_DATE > 20140101
  ;
  --删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_HK_OPN_INFO_TEMP1;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_HK_OPN_INFO_TEMP2;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_HK_OPN_INFO_TEMP3;
  ------结束-----
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_HK_OPN_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_HK_OPN_INFO; 
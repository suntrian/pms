 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:融资资金头寸表                                                                     */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
    TRUNCATE TABLE EDW_PROD.T_EDW_T02_TXY_RZZJTC;  
----插入数据开始-------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TXY_RZZJTC(
                                    ZRT_TCLX                            --头寸类型                               
                                   ,BZDM                                --币种代码                               
                                   ,ZHYE                                --账户余额                               
                                   ,MRDJJE                              --当日冻结金额                             
                                   ,RCJE                                --已融出金额                              
                                   ,YYJE                                --预约金额                               
                                   ,DJJE                                --临时冻结金额                             
                                   ,XGRQ                                --修改日期                               
                                   ,DRRZED                              --当日融资净增额                            
                                   ,QRRZYE                              --前日融资余额                             
                                   ,TCSM                                --头寸说明                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.TCLX                                as ZRT_TCLX                            --头寸类型                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.ZHYE                                as ZHYE                                --账户余额                                
                                   ,t.MRDJJE                              as MRDJJE                              --当日冻结金额                              
                                   ,t.RCJE                                as RCJE                                --已融出金额                               
                                   ,t.YYJE                                as YYJE                                --预约金额                                
                                   ,t.DJJE                                as DJJE                                --临时冻结金额                              
                                   ,t.XGRQ                                as XGRQ                                --修改日期                                
                                   ,t.DRRZED                              as DRRZED                              --当日融资净增额                             
                                   ,t.QRRZYE                              as QRRZYE                              --前日融资余额                              
                                   ,t.TCSM                                as TCSM                                --头寸说明                                
 FROM           RZRQCX.MARGIN_TXY_RZZJTC                 t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING   t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---------插入数据结束--------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TXY_RZZJTC',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TXY_RZZJTC;
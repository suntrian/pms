 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:未上第三方存管银行合格客户信息表                                                    */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2019-02-20                                                                        */ 

  TRUNCATE TABLE DDW_PROD.T_DDW_PRT_UN_T3IP_DEPMGT_BANK_QLFD_CUST_INFO ;
  INSERT OVERWRITE DDW_PROD.T_DDW_PRT_UN_T3IP_DEPMGT_BANK_QLFD_CUST_INFO
 (
           BRH_NO            --营业部
          ,BRH_FULLNM        --营业部名称
		  ,CUST_NO            --客户号
		  ,CNTR_CPTL_ACCNT    --资金账户
		  ,CUST_NAME         --客户姓名
		  ,ORDI_CUST_STAT    --客户状态 
		  ,CUST_RSK_LVL      --风险级别
		  ,CTF_CGY_CD        --证件类别
          ,CTF_NO            --证件编号
          ,ORDI_OPNAC_DT     --开户日期	
          ,PHONE             --手机
          ,CTCT_TEL          --电话
          ,ACCNT_BAL 	        --账户余额	
                                
 )  PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT     a2.BRH_NO            --营业部
          ,a2.BRH_FULLNM        --营业部名称
		  ,t.CUST_NO            --客户号
		  ,t.CNTR_CPTL_ACCNT    --资金账户
		  ,a1.CUST_NAME         --客户姓名
		  ,a1.ORDI_CUST_STAT    --客户状态 
		  ,a1.CUST_RSK_LVL      --风险级别
		  ,a1.CTF_CGY_CD        --证件类别
          ,a1.CTF_NO            --证件编号
          ,a1.ORDI_OPNAC_DT     --开户日期	
          ,a1.PHONE             --手机
          ,a1.CTCT_TEL          --电话
          ,t.ACCNT_BAL 	        --账户余额	  
FROM      DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    t
INNER JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO      a1
ON        t.CUST_NO = a1.CUST_NO
AND       a1.CUST_RSK_LVL IN ('0','1','2','8','19')
AND       a1.ORDI_CUST_STAT = '0'
AND       a1.BUS_DATE = %d{yyyyMMdd}
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH       a2
ON         t.BRH_NO = a2.BRH_NO
AND        a2.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN (SELECT GTZJZH 
           FROM   EDW_PROD.T_EDW_T02_TCGZHDY  
		   WHERE XTBS = 'JZJY' 
		   AND   ZH_YHZHGXZT IN (0,4,5) 
		   AND   BUS_DATE = %d{yyyyMMdd}
		   AND   BZDM = 'RMB'
           GROUP BY GTZJZH
		   )                                 a3
ON         t.CNTR_CPTL_ACCNT = a3.GTZJZH
LEFT JOIN (SELECT a.CUST_NO 
            FROM   DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO  a
            WHERE  a.BUS_DATE = %d{yyyyMMdd}
            AND   a.CCY_CD ='RMB' 
            AND  (SUBSTR(a.SHRHLD_NO,1,3) IN('A99','B99','F97') OR SUBSTR(a.SHRHLD_NO,1,4) IN('0799','0199'))
            AND NOT EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO b
                            WHERE  b.BUS_DATE = %d{yyyyMMdd}
                            AND    b.CCY_CD ='RMB'
				            AND   SUBSTR(b.SHRHLD_NO,1,3) NOT IN('A99','B99','F97') 
				            AND   SUBSTR(b.SHRHLD_NO,1,4) IN('0799','0199')
				            AND   a.CUST_NO = b.CUST_NO
                   )                               
             GROUP BY CUST_NO
		  )a4
ON t.CUST_NO = a4.CUST_NO
WHERE t.BUS_DATE = %d{yyyyMMdd}	
AND   t.SYS_SRC = '普通账户'
AND   t.CCY_CD = 'RMB'
AND   t.CPTL_ACCNT_STAT <> '3'
AND  a3.GTZJZH IS NULL
AND   a4.CUST_NO IS NULL
;
     			  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_UN_T3IP_DEPMGT_BANK_QLFD_CUST_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
   invalidate metadata DDW_PROD.T_DDW_PRT_UN_T3IP_DEPMGT_BANK_QLFD_CUST_INFO ;

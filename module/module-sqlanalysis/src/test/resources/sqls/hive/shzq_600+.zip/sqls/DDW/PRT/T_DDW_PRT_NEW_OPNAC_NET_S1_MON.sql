  /* ***************************************** SQL Begin ***************************************** */
 /* 脚本功能:新开户净佣金月表                                                         */
 /* 创建人:黄勇华                                                                                 */
 /* 创建时间:2018-10-11                                                                           */
 /* 修改时间:2018-10-11                                                                          */
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_NEW_OPNAC_NET_S1_MON_TEMP_%d{yyyyMMdd};
CREATE TABLE DDW_PROD.T_DDW_PRT_NEW_OPNAC_NET_S1_MON_TEMP_%d{yyyyMMdd} AS
SELECT CUST_NO
       ,SUM(CAST(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '普通账户'
			                 THEN (S1+S3-S11-S12-S13) * 0.94*b.ZHHL
							 WHEN b.BZDM IS  NULL
			                 AND  a.SYS_SRC = '普通账户'
			                 THEN (S1+S3-S11-S12-S13) * 0.94
					         ELSE 0
					         END as DECIMAL(38,2)
					))  AS ORDI_NET_S1
		,SUM(CAST(CASE WHEN b.BZDM IS NOT NULL
			                 AND  a.SYS_SRC = '信用账户'
			                 THEN (S1+S3-S11-S12-S13) * 0.94*b.ZHHL
							 WHEN b.BZDM IS  NULL
			                 AND  a.SYS_SRC = '信用账户'
			                 THEN (S1+S3-S11-S12-S13) * 0.94
					         ELSE 0
					         END as DECIMAL(38,2)
					))  AS CRD_NET_S1
FROM        DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS                 a
 LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH                             b
 ON             a.CCY_CD = b.BZDM
 AND            b.BUS_DATE =  a.BUS_DATE 
 WHERE SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
GROUP BY a.CUST_NO ;

INSERT OVERWRITE DDW_PROD.T_DDW_PRT_NEW_OPNAC_NET_S1_MON
(
		   BRH_NO               --营业部编号
          ,BRH_NAME             --营业部名称
          ,BELTO_FILIL          --所属分公司
		  ,BELTO_FILIL_CDG	 	--所属分公司编码
          ,PSN_CGY              --人员类别
          ,ORDI_NET_S1          --普通账户净佣金
		  ,CRD_NET_S1            --信用账户净佣金
)		
 PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT 
		    t.BRH_NO                            as BRH_NO               --营业部编号
          ,a3.brh_shrtnm                        as BRH_NAME             --营业部名称
          ,a3.BELTO_FILIL                       as BELTO_FILIL          --所属分公司
		  ,a3.BELTO_FILIL_CDG					as BELTO_FILIL_CDG	 	--所属分公司编码
          ,NVL(a4.PSN_CGY,'0000')               as PSN_CGY              --人员类别
		  ,SUM(NVL(a5.ORDI_NET_S1,0))           as ORDI_NET_S1          --普通账户净佣金
		  ,SUM(NVL(a5.CRD_NET_S1,0))            as CRD_NET_S1            --信用账户净佣金
 
 FROM       DDW_PROD.T_DDW_F00_CUST_CUST_INFO     t
 LEFT JOIN  DDW_PROD.T_DDW_INR_ORG_BRH              a3
 ON         t.BRH_NO	 = a3.BRH_NO
 AND        a3.BUS_DATE =  %d{yyyyMMdd}
 LEFT JOIN  (SELECT CUST_NO,BRK_NO as PSN_NO,BRK_CGY as PSN_CGY
             FROM DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN 
             WHERE %d{yyyyMMdd} > = STATS_DT 
              AND %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
	          AND BUS_DATE = %d{yyyyMMdd}
		    ) a4
  ON         t.CUST_NO = a4.CUST_NO
 LEFT JOIN  EDW_PROD.T_EDW_T01_TJJR a1
 ON  		a4.PSN_NO = a1.JJRBH
 AND  		a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  EDW_PROD.T_EDW_T01_TRYXX a2
 ON  		a4.PSN_NO = a2.RYBH
 AND  		a2.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN DDW_PROD.T_DDW_PRT_NEW_OPNAC_NET_S1_MON_TEMP_%d{yyyyMMdd} a5
 ON        t.CUST_NO = a5.CUST_NO
 WHERE SUBSTR(CAST(t.ORDI_OPNAC_DT as STRING),1,4) =  SUBSTR('%d{yyyyMMdd}',1,4)
 AND   t.BUS_DATE = %d{yyyyMMdd}
 AND   a3.BRH_NO IS NOT NULL 
 GROUP BY BRH_NO         
          ,BRH_NAME       
          ,BELTO_FILIL    
          ,BELTO_FILIL_CDG
          ,PSN_CGY    ; 
		  
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_NEW_OPNAC_NET_S1_MON_TEMP_%d{yyyyMMdd};
 
-----------------------加载结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_NEW_OPNAC_NET_S1_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_NEW_OPNAC_NET_S1_MON ;
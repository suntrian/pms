 /* ***************************************** SQL Begin ***************************************** */
  /* 脚本功能:配售权益比较表                                                                      */
  /* 创建人:黄勇华                                                                                */
  /* 创建时间:2018-05-17                                                                          */ 
  /* 修改时间:2018-07-10                                                                          */
  /* 修改内容:增加营业部、客户姓名等字段                                                          */ 

DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP;
CREATE TABLE DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP
as SELECT t.TRD_DT,a1.TRD_DT as TRD_DT_20,t.LST_TRD_D,a1.LST_TRD_D as LST_TRD_D_20 
   FROM (SELECT  TRD_DT
                ,LST_TRD_D
                ,ROW_NUMBER() OVER(ORDER BY TRD_DT ) as NUM
				--,ROW_NUMBER() OVER(ORDER BY TRD_DT ) as NUM
         FROM (SELECT   TRD_DT,LST_TRD_D 
               FROM     EDW_PROD.T_EDW_T99_TRD_DATE 
               WHERE    BUS_DATE = %d{yyyyMMdd} 
               AND      TRD_DT >= 20140101
               GROUP BY TRD_DT,LST_TRD_D
               ORDER BY TRD_DT,LST_TRD_D
               )    t
        )    t
  LEFT JOIN (SELECT  TRD_DT
                    ,LST_TRD_D
                    ,ROW_NUMBER() OVER(ORDER BY TRD_DT ) -19 as NUM
					--,ROW_NUMBER() OVER(ORDER BY LST_TRD_D ) -19 as NUM1
              FROM (SELECT   TRD_DT
                             ,LST_TRD_D			  
                    FROM     EDW_PROD.T_EDW_T99_TRD_DATE 
                    WHERE    BUS_DATE = %d{yyyyMMdd}
                    AND      TRD_DT >= 20140101
                    GROUP BY TRD_DT,LST_TRD_D
                    ORDER BY TRD_DT,LST_TRD_D
                    )    t
		    )                      a1
   ON       t.NUM = a1.NUM
   ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP1;
CREATE TABLE DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP1 
 AS
SELECT YYB,BRH_NAME,KHH,CUST_NAME,JYS,SUM(ZQSL*10) AS PSSZ,DZRQ
FROM (SELECT T.YYB,T1.BRH_FULLNM AS BRH_NAME,T.KHH,T2.CUST_NAME,T.JYS,T.ZQSL,T.DZRQ 
        FROM EDW_PROD.T_EDW_T02_TPSQY T
  INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T1
          ON T.YYB = T1.BRH_NO
         AND T1.BUS_DATE = %d{yyyyMMdd}
  INNER JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO T2
          ON T.KHH = T2.CUST_NO
         AND T2.BUS_DATE = %d{yyyyMMdd}
   LEFT JOIN EDW_PROD.T_EDW_T01_TKHXX A1
          ON T.KHH = A1.KHH
         AND A1.BUS_DATE = %d{yyyyMMdd}
         AND A1.KHFXJB IN ('0','1','2','8','19')
       WHERE T.BUS_DATE = %d{yyyyMMdd}
         AND T.ZQDM = '000000'
         AND A1.KHH IS NOT NULL
    GROUP BY T.YYB,T1.BRH_FULLNM,T.KHH,T2.CUST_NAME,T.JYS,T.ZQSL,T.DZRQ
) T
GROUP BY YYB,BRH_NAME,KHH,CUST_NAME,JYS,DZRQ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP2;
 CREATE TABLE DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP2
  as SELECT  t.KHH  as CUST_NO
         ,SUM(NVL(ROUND((a5.NEWST_PRC+a5.NEWST_INT*a5.NETPRC_TRD_FLG)*a5.TRD_UNIT*t.zqsl,2),0)/20) as CO_MKTVAL
		 ,t.JYS  as EXG
  FROM        EDW_PROD.T_EDW_T02_TZQGL t 
  LEFT JOIN   DDW_PROD.T_DDW_PUB_QOT   a5
  ON          t.JYS = a5.EXG
  AND         t.ZQDM = a5.CD
  AND         t.BUS_DATE = a5.BUS_DATE  
  LEFT JOIN  EDW_PROD.T_EDW_T04_TSZQDM              a1
  ON         t.JYS = a1.JYS
  AND        t.ZQDM = a1.ZQDM
  AND        a1.CPLB = 1
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  WHERE  t.JYS = 'SH' AND SUBSTR(t.ZQDM,1,3) IN ('601','602','603','600')
  AND    EXISTS(SELECT 1 FROM (SELECT KHH,JYS,DZRQ,a1.TRD_DT
                               FROM      DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP1 t
                               LEFT JOIN DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP a1
                               ON        t.DZRQ = a1.TRD_DT_20
                               WHERE    t.JYS = 'SH'
							  ) a
               WHERE    t.KHH = a.KHH
			   AND      t.BUS_DATE BETWEEN a.TRD_DT AND a.DZRQ
              )
	AND   t.BUS_DATE BETWEEN a1.SSRQ AND a1.TSRQ
	GROUP BY t.KHH,t.JYS
	UNION ALL
	 SELECT  t.KHH  as CUST_NO
         ,SUM(NVL(ROUND((a5.NEWST_PRC+a5.NEWST_INT*a5.NETPRC_TRD_FLG)*a5.TRD_UNIT*t.zqsl,2),0)/20) as CO_MKTVAL
		 ,t.JYS  as EXG
  FROM        EDW_PROD.T_EDW_T02_TZQGL t 
  LEFT JOIN   DDW_PROD.T_DDW_PUB_QOT   a5
  ON          t.JYS = a5.EXG
  AND         t.ZQDM = a5.CD
  AND         t.BUS_DATE = a5.BUS_DATE 
  LEFT JOIN  EDW_PROD.T_EDW_T04_TSZQDM              a1
  ON         t.JYS = a1.JYS
  AND        t.ZQDM = a1.ZQDM
  AND        a1.CPLB = 1
  AND        a1.BUS_DATE = %d{yyyyMMdd}
  WHERE  t.JYS = 'SZ' AND SUBSTR(t.ZQDM,1,3) IN ('300','002','003','000','001')
  AND    EXISTS(SELECT 1 FROM (SELECT KHH,JYS,DZRQ,a1.TRD_DT
  --,a1.lst_trd_d,a1.lst_trd_d_20
                               FROM      DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP1 t
                               LEFT JOIN DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP a1
                               ON        t.DZRQ = a1.TRD_DT_20
                               WHERE    t.JYS = 'SZ'
							  ) a
               WHERE    t.KHH = a.KHH
			    AND      t.BUS_DATE BETWEEN a.trd_dt AND a.DZRQ
			  -- AND      t.BUS_DATE BETWEEN a.lst_trd_d AND a.lst_trd_d_20
              )
    AND   t.BUS_DATE BETWEEN a1.SSRQ AND a1.TSRQ
	GROUP BY t.KHH,t.JYS
	;
-----------------------------------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP
(
           EXG               --交易所
		  ,BRH_NO            --营业部编号
		  ,BRH_NAME          --营业部名称
          ,CUST_NO           --客户号
		  ,CUST_NAME         --客户名称
          ,PLCG_ETMT_MKTVAL  --配售权益市值
          ,CO_MKTVAL         --公司20日均市值
          ,ETMT_FCTR_CMP     --权益因子比较		                                    						   
) 
PARTITION( BUS_DATE = %d{yyyyMMdd})  
SELECT     T.JYS                 AS EXG               --交易所
          ,T.YYB                 AS BRH_NO            --营业部编号
		  ,T.BRH_NAME                                 --营业部名称
          ,T.KHH                 AS CUST_NO           --客户号
		  ,T.CUST_NAME                                --客户名称
          ,T.PSSZ                AS PLCG_ETMT_MKTVAL  --配售权益市值
          ,CAST(NVL(a1.CO_MKTVAL,0) AS DECIMAL(38,2))   AS CO_MKTVAL         --公司20日均市值
          ,CASE WHEN t.JYS = 'SH'
		        THEN t.PSSZ/10000-TRUNC(nvl(a1.CO_MKTVAL,0)/10000)
				WHEN t.JYS = 'SZ'
				THEN t.PSSZ/5000-TRUNC(nvl(a1.CO_MKTVAL,0)/5000)
				END              AS ETMT_FCTR_CMP     --权益因子比较	
FROM      DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP1 T
LEFT JOIN DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP2 A1
ON        T.KHH = A1.CUST_NO
AND       T.JYS = A1.EXG
;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP1;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_TEMP2;
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_PLCG_ETMT_CMP',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP ;
------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:营业部星级客户指标月表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2018-04-20                                                                        */

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP as 
 SELECT   a.BRH_NO
         ,a.CUST_STAR
		 ,a.CUST_VOL                     as STRT_CUST_VOL                       --期初客户数
		 ,a.QLFD_CUST_VOL                as STRT_QLFD_CUST_VOL                  --期初合格客户数
		 ,a.BROK_RLN_QLFD_CUST_VOL       as STRT_BROK_RLN_QLFD_CUST_VOL         --期初经纪关系合格客户数
         ,a.STRONG_SVC_RLN_QLFD_CUST_VOL as STRT_STRONG_SVC_RLN_QLFD_CUST_VOL   --期初强服务关系合格客户数
         ,a.WEAK_SVC_RLN_QLFD_CUST_VOL   as STRT_WEAK_SVC_RLN_QLFD_CUST_VOL     --期初弱服务关系合格客户数
		 ,a.BROK_RLN_CUST_VOL            as STRT_BROK_RLN_CUST_VOL              --期初经纪关系客户数
		 ,a.STRONG_SVC_RLN_CUST_VOL      as STRT_STRONG_SVC_RLN_CUST_VOL        --期初强服务关系客户数
		 ,a.WEAK_SVC_RLN_CUST_VOL        as STRT_WEAK_SVC_RLN_CUST_VOL          --期初弱服务关系客户数
		 ,a.CRD_CUST_VOL                 as STRT_CRD_CUST_VOL                   --期初信用客户数
		 ,a.H_K_CUST_VOL                 as STRT_H_K_CUST_VOL                   --期初港股通客户数
         ,a.WRNT_CUST_VOL                as STRT_WRNT_CUST_VOL                  --期初期权客户数
		 ,a.STIB_CUST_VOL                as STRT_STIB_CUST_VOL                  --期初科创板客户数
		 ,a.NEW_T3BOD_CUST_VOL           as STRT_NEW_T3BOD_CUST_VOL             --期初新三板客户数(受限制+非受限制) 
		 ,a.T3BOD_CUST_VOL               as STRT_T3BOD_CUST_VOL                 --期初三板客户数 
		 ,a.PLG_REPO_CUST_VOL            as STRT_PLG_REPO_CUST_VOL              --期初质押回购客户数(股票质押)
         ,a.STK_PLG_CUST_VOL             as STRT_STK_PLG_CUST_VOL               --期初股票质押客户数(小微贷)
         ,a.STR_FND_CUST_VOL             as STRT_STR_FND_CUST_VOL               --期初分级基金客户数
         ,a.PROD_CUST_VOL                as STRT_PROD_CUST_VOL                  --期初产品客户数
         ,a.INR_PB_CUST_VOL              as STRT_INR_PB_CUST_VOL                --期初内部PB账户数
         ,a.EXTN_PB_CUST_VOL             as STRT_EXTN_PB_CUST_VOL               --期初外部PB账户数
         ,a.CASH_PROD_CUST_VOL           as STRT_CASH_PROD_CUST_VOL             --期初现金添利客户数
		 ,a.CUST_TOT_AST                 as STRT_CUST_TOT_AST                   --期初客户总资产
         ,a.CUST_NET_TOT_AST             as STRT_CUST_NET_TOT_AST               --期初客户净资产
         ,a.BROK_RLN_CUST_NET_TOT_AST    as STRT_BROK_RLN_CUST_NET_TOT_AST      --期初经纪关系净资产
         ,a.STRONG_SVC_CUST_NET_TOT_AST  as STRT_STRONG_SVC_CUST_NET_TOT_AST    --期初强服务关系净资产
         ,a.WEAK_SVC_CUST_NET_TOT_AST    as STRT_WEAK_SVC_CUST_NET_TOT_AST      --期初弱服务关系净资产
		 ,a.CPTL_BAL                     as STRT_CPTL_BAL                       --期初资金余额
         ,a.A_STK_MKTVAL                 as STRT_A_STK_MKTVAL                   --期初A股票市值
         ,a.B_STK_MKTVAL                 as STRT_B_STK_MKTVAL                   --期初B股票市值
         ,a.H_K_STK_MKTVAL               as STRT_H_K_STK_MKTVAL                 --期初港股股票市值
		 ,a.MRGNC_CPTL_BAL               as STRT_MRGNC_CPTL_BAL                 --期初融资余额
         ,a.MRGNS_CPTL_BAL               as STRT_MRGNS_CPTL_BAL                 --期初融券余额
		 ,a.STK_PLG_AMT                  as STRT_STK_PLG_AMT                    --期初股票质押余额
		 ,a.MIN_STK_PLG_AMT              as STRT_MIN_STK_PLG_AMT                --期初小微贷余额
		  ,a.UN_TRD_NET_AST               as STRT_UN_TRD_NET_AST                 --期初非交易净资产
 FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY     a
 WHERE  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                                     FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                        WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                        AND BUS_DATE = %d{yyyyMMdd}
				              )  b
               WHERE  a.BUS_DATE = b.MON_START
			  )
AND  SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) ;
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP1 as 
 SELECT   a.BRH_NO
         ,a.CUST_STAR
		 ,a.CUST_VOL                     as FNL_CUST_VOL                       --期末客户数
		 ,a.QLFD_CUST_VOL                as FNL_QLFD_CUST_VOL                  --期末合格客户数
		 ,a.BROK_RLN_QLFD_CUST_VOL       as FNL_BROK_RLN_QLFD_CUST_VOL         --期末经纪关系合格客户数
         ,a.STRONG_SVC_RLN_QLFD_CUST_VOL as FNL_STRONG_SVC_RLN_QLFD_CUST_VOL   --期末强服务关系合格客户数
         ,a.WEAK_SVC_RLN_QLFD_CUST_VOL   as FNL_WEAK_SVC_RLN_QLFD_CUST_VOL     --期末弱服务关系合格客户数
		 ,a.BROK_RLN_CUST_VOL            as FNL_BROK_RLN_CUST_VOL              --期末经纪关系客户数
		 ,a.STRONG_SVC_RLN_CUST_VOL      as FNL_STRONG_SVC_RLN_CUST_VOL        --期末强服务关系客户数
		 ,a.WEAK_SVC_RLN_CUST_VOL        as FNL_WEAK_SVC_RLN_CUST_VOL          --期末弱服务关系客户数
		 ,a.CRD_CUST_VOL                 as FNL_CRD_CUST_VOL                   --期末信用客户数
		 ,a.H_K_CUST_VOL                 as FNL_H_K_CUST_VOL                   --期末港股通客户数
         ,a.WRNT_CUST_VOL                as FNL_WRNT_CUST_VOL                  --期末期权客户数
		 ,a.STIB_CUST_VOL                as FNL_STIB_CUST_VOL                  --期末科创板客户数
		 ,a.NEW_T3BOD_CUST_VOL           as FNL_NEW_T3BOD_CUST_VOL             --期末新三板客户数(受限制+非受限制) 
		 ,a.T3BOD_CUST_VOL               as FNL_T3BOD_CUST_VOL                 --期末三板客户数 
		 ,a.PLG_REPO_CUST_VOL            as FNL_PLG_REPO_CUST_VOL              --期末质押回购客户数(股票质押)
         ,a.STK_PLG_CUST_VOL             as FNL_STK_PLG_CUST_VOL               --期末股票质押客户数(小微贷)
         ,a.STR_FND_CUST_VOL             as FNL_STR_FND_CUST_VOL               --期末分级基金客户数
         ,a.PROD_CUST_VOL                as FNL_PROD_CUST_VOL                  --期末产品客户数
         ,a.INR_PB_CUST_VOL              as FNL_INR_PB_CUST_VOL                --期末内部PB账户数
         ,a.EXTN_PB_CUST_VOL             as FNL_EXTN_PB_CUST_VOL               --期末外部PB账户数
         ,a.CASH_PROD_CUST_VOL           as FNL_CASH_PROD_CUST_VOL             --期末现金添利客户数
		 ,a.CUST_TOT_AST                 as FNL_CUST_TOT_AST                   --期末客户总资产
         ,a.CUST_NET_TOT_AST             as FNL_CUST_NET_TOT_AST               --期末客户净资产
         ,a.BROK_RLN_CUST_NET_TOT_AST    as FNL_BROK_RLN_CUST_NET_TOT_AST      --期末经纪关系净资产
         ,a.STRONG_SVC_CUST_NET_TOT_AST  as FNL_STRONG_SVC_CUST_NET_TOT_AST    --期末强服务关系净资产
         ,a.WEAK_SVC_CUST_NET_TOT_AST    as FNL_WEAK_SVC_CUST_NET_TOT_AST      --期末弱服务关系净资产
		 ,a.CPTL_BAL                     as FNL_CPTL_BAL                       --期末资金余额
         ,a.A_STK_MKTVAL                 as FNL_A_STK_MKTVAL                   --期末A股票市值
         ,a.B_STK_MKTVAL                 as FNL_B_STK_MKTVAL                   --期末B股票市值
         ,a.H_K_STK_MKTVAL               as FNL_H_K_STK_MKTVAL                 --期末港股股票市值
		 ,a.MRGNC_CPTL_BAL               as FNL_MRGNC_CPTL_BAL                 --期末融资余额
         ,a.MRGNS_CPTL_BAL               as FNL_MRGNS_CPTL_BAL                 --期末融券余额
		 ,a.STK_PLG_AMT                  as FNL_STK_PLG_AMT                    --期末股票质押余额
		 ,a.MIN_STK_PLG_AMT              as FNL_MIN_STK_PLG_AMT                --期末小微贷余额
		 ,a.UN_TRD_NET_AST               as FNL_UN_TRD_NET_AST                 --期末非交易净资产
 FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY     a
 WHERE  a.BUS_DATE =  %d{yyyyMMdd} ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP2 ;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP2 as 
 SELECT CUST_NO
 FROM   DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
 WHERE  SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 AND    ODR_CGY IN (1,2,4,5,12,13,17,29,30,34,35,36,42,43,57,58,59,60,61,62,63,64,71,78,79,80,83,114,124,1111,2222)
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 UNION 
 SELECT CUST_NO
 FROM   DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
 WHERE   SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 AND    WRNT_BS_DRCT IN ('1','2')
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 UNION 
 
 SELECT CUST_NO
 FROM   DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS
 WHERE  SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 AND    PROD_BIZ_CD IN ('130','122','142','150','139','124')
 AND    CUST_NO NOT IN ('105810000001','100610335855') ;
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP3;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP3 as 
 SELECT         t.BRH_NO
               ,t.CUST_STAR              
               ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TRD_CUST_VOL
			  ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TRD_CRD_CUST_VOL
              ,SUM(CASE WHEN a9.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TRD_STIB_CUST_VOL 
              ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TRD_H_K_CUST_VOL	
            
              ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TRD_WRNT_CUST_VOL					
			  
              
               ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TRD_NWE_T3BOD_CUST_VOL	                	
	           ,SUM(CASE WHEN SUBSTR(CAST(t.OPNAC_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN 1
						 ELSE 0
				         END 
				   )    as OPNAC_CUST_VOL   
				   
               ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.CRD_OPNAC_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN 1
						 ELSE 0
				         END 
				   )    as  OPNAC_CRD_CUST_VOL          
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.WRNT_OPNAC_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN 1
						 ELSE 0
				         END 
				   )   as OPNAC_WRNT_CUST_VOL         
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.STIB_OPNAC_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN 1
						 ELSE 0
				         END 
				   )  as OPN_STIB_CUST_VOL 
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.H_K_OPNAC_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN 1
						 ELSE 0
				         END 
				   )  as OPN_H_K_CUST_VOL 				   
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.PLG_REPO_OPNAC_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN 1
						 ELSE 0
				         END 
				   )  as OPN_PLG_REPO_CUST_VOL       
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.STK_PLG_OPNAC_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN 1
						 ELSE 0
				         END 
				   ) as OPN_STK_PLG_CUST_VOL        
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.STR_FND_OPNAC_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN 1
						 ELSE 0
				         END 
				   ) as OPN_STR_FND_CUST_VOL        
               ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.NEW_T3BOD_OPNAC_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN 1
						 WHEN SUBSTR(CAST(NVL(t.LMT_NEW_T3BOD_OPNAC_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN 1
						 ELSE 0
				         END 
				   ) as OPN_NEW_T3BOD_CUST_VOL      
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.T3BOD_OPNAC_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN 1
						 ELSE 0
				         END 
				   ) as OPN_T3BOD_CUST_VOL  

               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.CNCLACT_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             AND  t.CUST_STAT = '3'
						 THEN 1
						 ELSE 0
				         END 
				   ) as CNCLACT_CUST_VOL               --销户数(当月)
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.CRD_CNCLACT_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             AND  t.IF_CRD_CNCLACT = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CNCLACT_CRD_CUST_VOL           --销户信用客户数(当月)
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.WRNT_CNCLACT_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             AND  t.IF_WRNT_CNCLACT = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CNCLACT_WRNT_CUST_VOL          --销户期权客户数(当月)
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.STIB_CNCLACT_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             AND  t.IF_STIB = 3
						 THEN 1
						 ELSE 0
				         END 
				   )  as CLS_STIB_CUST_VOL              --关闭科创板客户数(当月)
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.H_K_CNCLACT_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             AND  t.IF_H_K = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CLS_H_K_CUST_VOL               --关闭港股通客户数(当月)
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.PLG_REPO_CNCLACT_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             AND  t.IF_PLG_REPO = 3
						 THEN 1
						 ELSE 0
				         END 
				   )  as CLS_PLG_REPO_CUST_VOL          --关闭质押回购客户数(股票质押)(当月)
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.STK_PLG_CNCLACT_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             AND  t.IF_STK_PLG = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CLS_STK_PLG_CUST_VOL           --关闭股票质押客户数(小微贷)(当月)
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.STR_FND_CNCLACT_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             AND  t.IF_STR_FND  = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CLS_STR_FND_CUST_VOL           --关闭分级基金客户数
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.NEW_T3BOD_CNCLACT_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             AND  t.IF_NEW_T3BOD  = 3
						 THEN 1
						 WHEN  SUBSTR(CAST(NVL(t.LMT_NEW_T3BOD_CNCLACT_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             AND  t.IF_LMT_NEW_T3BOD  = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CLS_NEW_T3BOD_CUST_VOL         --关闭新三板客户数(受限制当月+非受限制当月)
               ,SUM(CASE WHEN  SUBSTR(CAST(NVL(t.T3BOD_CNCLACT_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             AND  t.IF_T3BOD  = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CLS_T3BOD_CUST_VOL             --关闭三板客户数(当月)				   
				,SUM(CASE WHEN SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
			             AND   SUBSTR(CAST(NVL(t.VLD_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN 1
					     ELSE 0
					     END
				    )                            as ADDED_VLD_CUST_VOL
				,SUM(CASE WHEN SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) < SUBSTR('%d{yyyyMMdd}',1,4)
			              AND SUBSTR(CAST(NVL(t.OPNAC_DT,0) as STRING),1,4) >= '2016'
						  AND  SUBSTR(CAST(NVL(t.VLD_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			              THEN 1
					      ELSE 0
					      END
				    )                            as ADDED_OLD_VLD_CUST_VOL	
                 ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.OPNAC_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			             THEN a7.NET_TOT_AST
					     ELSE 0
					     END
				   )                        as NEW_OPNAC_NET_TOT_AST
		
				 ,SUM(CASE WHEN   SUBSTR(CAST(NVL(t.VLD_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
                         AND   SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
			             THEN a7.NET_TOT_AST
					     ELSE 0
					     END
				   )                        as ADDED_VLD_NET_TOT_AST
				  ,SUM(CASE WHEN   SUBSTR(CAST(NVL(t.VLD_DT,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
                            AND   SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) < SUBSTR('%d{yyyyMMdd}',1,4)
			                AND SUBSTR(CAST(NVL(t.OPNAC_DT,0) as STRING),1,4) >= '2016'
							THEN a7.NET_TOT_AST
					        ELSE 0
					        END
				     )                        as ADDED_OLD_VLD_NET_TOT_AST	

                ,SUM(  CASE WHEN   NVL(a8.ORDI_ACCNT_CORE_WAG_CUST_VOL,0) = 1                           
			                THEN 1
					        ELSE 0
					        END
				     )                        as ORDI_ACCNT_CORE_WAG_CUST_VOL
                ,SUM(  CASE WHEN   NVL(a8.ORDI_ACCNT_VIP_WAG_CUST_VOL,0) = 1                           
			                THEN 1
					        ELSE 0
					        END
				     )                        as ORDI_ACCNT_VIP_WAG_CUST_VOL
				,SUM(  CASE WHEN   NVL(a8.ORDI_ACCNT_ORDI_WAG_CUST_VOL,0) = 1                           
			                THEN 1
					        ELSE 0
					        END
				     )                        as ORDI_ACCNT_ORDI_WAG_CUST_VOL
                ,SUM(  CASE WHEN   NVL(a8.CRD_ACCNT_ORDI_WAG_CUST_VOL,0) = 1                           
			                THEN 1
					        ELSE 0
					        END
				     )                        as CRD_ACCNT_ORDI_WAG_CUST_VOL	
                ,SUM(NVL(a8.ORDI_ACCNT_CORE_WAG_TRD_VOL,0))   as ORDI_ACCNT_CORE_WAG_TRD_VOL
                ,SUM(NVL(a8.ORDI_ACCNT_VIP_WAG_TRD_VOL,0))    as ORDI_ACCNT_VIP_WAG_TRD_VOL 
                ,SUM(NVL(a8.ORDI_ACCNT_ORDI_WAG_TRD_VOL,0))   as ORDI_ACCNT_ORDI_WAG_TRD_VOL
                ,SUM(NVL(a8.CRD_ACCNT_ORDI_WAG_TRD_VOL,0))    as CRD_ACCNT_ORDI_WAG_TRD_VOL 
				
				  ,SUM(  CASE WHEN   t.CUST_STAT < > '3' 
                              AND    SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) < SUBSTR('%d{yyyyMMdd}',1,4)
                              AND    NVL(t.IB_CUST_FLG,'0') = '1'							  
			                THEN 1
					        ELSE 0
					        END
				     )                        as FNL_OLD_INR_PB_CUST_VOL             --期末存量内部PB账户数
				
				,SUM(  CASE WHEN   t.CUST_STAT < > '3' 
                              AND    SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
                              AND    NVL(t.IB_CUST_FLG,'0') = '1'							  
			                THEN 1
					        ELSE 0
					        END
				     )                        as FNL_ADDED_INR_PB_CUST_VOL           --期末增量内部PB账户数
				 ,SUM(  CASE WHEN    SUBSTR(CAST(t.OPNAC_DT as STRING),1,4)  = SUBSTR('%d{yyyyMMdd}',1,4) 
                              AND    NVL(t.IB_CUST_FLG,'0') = '1'							  
			                THEN 1
					        ELSE 0
					        END
				     )  as TISSU_GT_OPNAC_INR_PB_CUST_VOL      --当年新开内部PB账户数
		  ,SUM(CASE WHEN      t.CUST_STAT < > '3' 
                            AND    SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) < SUBSTR('%d{yyyyMMdd}',1,4)
                            AND SUBSTR(CAST(NVL(t.OPNAC_DT,0) as STRING),1,4) >= '2016'
							AND    NVL(t.IB_CUST_FLG,'0') = '1'
			                THEN a7.NET_TOT_AST
					        ELSE 0
					        END
				     )                        as FNL_OLD_INR_PB_FNL_AST              --期末存量内部PB期末资产
		  ,SUM(CASE WHEN   t.CUST_STAT < > '3' 
                          AND    SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
                          AND    NVL(t.IB_CUST_FLG,'0') = '1'
			              THEN a7.NET_TOT_AST
					      ELSE 0
					      END
				     )                        as FNL_ADDED_INR_PB_FNL_AST            --期末增量内部PB期末资产
		  
	   
					 
 FROM          DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL   t
 INNER JOIN    DDW_PROD.T_DDW_INR_ORG_BRH               a1
 ON            t.BRH_NO = a1.BRH_NO
 AND           a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP2 a2
 ON            t.CUST_NO = a2.CUST_NO
 LEFT JOIN   (SELECT CUST_NO 
              FROM  DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
              WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			  AND   ODR_CGY IN (1,2,61,62,63,64,71,72,80,83)
			  AND   SYS_SRC = '信用账户'
			  GROUP BY CUST_NO
			  )                                   a3
  ON            t.CUST_NO = a3.CUST_NO
 LEFT JOIN   (SELECT CUST_NO 
              FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
              WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			  AND   ODR_CGY IN (1,2,80,83)
			  AND   EXG IN ('HK','SK')
			  AND   SYS_SRC = '普通账户'
			  GROUP BY CUST_NO
             )                                   a4
  ON            t.CUST_NO = a4.CUST_NO
 LEFT JOIN   (SELECT CUST_NO
              FROM   DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
              WHERE  SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
              AND    WRNT_BS_DRCT IN ('1','2')
			  GROUP BY CUST_NO
             )                                   a5
  ON            t.CUST_NO = a5.CUST_NO
  LEFT JOIN   (SELECT CUST_NO 
               FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
               WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			   AND   ODR_CGY IN (1,2,57,58,59,60,78,79)
			   AND   EXG IN ('TA')
			   AND   SUBSTR(SEC_CD,1,2) IN ('43','83','87')
			   AND   SYS_SRC = '普通账户'
			   GROUP BY CUST_NO
              )                                   a6
 ON            t.CUST_NO = a6.CUST_NO
  LEFT JOIN     DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY   a7
 ON            t.CUST_NO = a7.CUST_NO
 AND           a7.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN   (SELECT  CUST_NO
                     ,MAX(CASE WHEN RPT_RSLT = 4
                               AND  ACCNT_CGY = '普通账户'
                               THEN 1
                               ELSE 0
                               END
                         )   as 	ORDI_ACCNT_CORE_WAG_CUST_VOL
                    ,MAX(CASE WHEN RPT_RSLT IN (6,10,11,12,13)
                              AND  ACCNT_CGY = '普通账户'
                              THEN 1
                              ELSE 0
                              END
                         )   as 	ORDI_ACCNT_VIP_WAG_CUST_VOL		
                    ,MAX(CASE WHEN RPT_RSLT NOT IN (4,6,10,11,12,13)
                              AND  ACCNT_CGY = '普通账户'
                              THEN 1
                              ELSE 0
                              END
                         )   as 	ORDI_ACCNT_ORDI_WAG_CUST_VOL
                    ,MAX(CASE WHEN  ACCNT_CGY = '信用账户'
                              THEN 1
                              ELSE 0
                              END
                         )   as 	CRD_ACCNT_ORDI_WAG_CUST_VOL	

                   ,SUM(CASE WHEN RPT_RSLT = 4
                             AND  ACCNT_CGY = '普通账户'
				             AND  ODR_CGY IN (1,2,29,30,41,42,43,57,58,59,60)
			                 AND  SEC_CGY  IN ('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
                             THEN  MTCH_AMT
                             ELSE 0
                             END
                        )   as 	ORDI_ACCNT_CORE_WAG_TRD_VOL	
                 ,SUM(CASE WHEN RPT_RSLT IN (6,10,11,12,13)
                           AND  ACCNT_CGY = '普通账户'
				           AND  ODR_CGY IN (1,2,29,30,41,42,43,57,58,59,60)
			               AND  SEC_CGY  IN ('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
                           THEN  MTCH_AMT
                           ELSE 0
                           END
                     )   as 	ORDI_ACCNT_VIP_WAG_TRD_VOL
                ,SUM(CASE WHEN RPT_RSLT NOT IN (4,6,10,11,12,13)
                          AND  ACCNT_CGY = '普通账户'
				          AND  ODR_CGY IN (1,2,29,30,41,42,43,57,58,59,60)
			              AND  SEC_CGY  IN ('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
                          THEN  MTCH_AMT
                          ELSE 0
                          END
                   )   as 	ORDI_ACCNT_ORDI_WAG_TRD_VOL		
               ,SUM(CASE WHEN ACCNT_CGY = '信用账户'
				         AND  ODR_CGY IN (1,2,29,30,41,42,43,57,58,59,60,61,62,63,64)
			             AND  SEC_CGY  IN ('A0','C0','E0','EH','EZ','J0','J1','L0','T0')
                         THEN  MTCH_AMT
                         ELSE 0
                         END
                    )   as 	CRD_ACCNT_ORDI_WAG_TRD_VOL	   
           FROM DDW_PROD.T_DDW_F00_TRD_SEC_ODR_DEL_HIS
           WHERE  SUBSTR(CAST(ODR_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           GROUP BY CUST_NO
		   )                    a8
 ON  t.CUST_NO = a8.CUST_NO
  LEFT JOIN   (SELECT CUST_NO 
               FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
               WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			   AND   ODR_CGY IN (1,2,61,62,63,64,71,72,80,57,58,59,60,78,79,29,30,1111,2222)
			   AND   EXG IN ('SH')
			   AND   SUBSTR(SEC_CD,1,3) IN ('688')
			   AND   SYS_SRC = '普通账户'
			   GROUP BY CUST_NO
              )                                   a9
 ON            t.CUST_NO = a9.CUST_NO
 WHERE         t.BUS_DATE = %d{yyyyMMdd}
 GROUP BY       t.BRH_NO
               ,t.CUST_STAR
 ;
 
 
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP4 ;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP4 as 
 SELECT t.CUST_NO,SUM(MTCH_AMT) as TRD_VOL
 FROM 
 (SELECT CUST_NO,SUM(ROUND(CASE WHEN b.BUS_DATE IS NOT NULL
                               THEN a.MTCH_AMT*b.ZHHL
						       ELSE a.MTCH_AMT
						       END,2)
			        ) as MTCH_AMT
 FROM   DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS a
 LEFT JOIN     EDW_PROD.T_EDW_T99_HLZH         b
 ON            a.BUS_DATE = b.BUS_DATE
 AND           b.BZDM = a.CCY_CD
 WHERE  SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 AND    a.ODR_CGY IN (1,2,4,5,12,13,17,29,30,34,35,36,42,43,57,58,59,60,61,62,63,64,71,78,79,80,83,114,124,1111,2222)
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 GROUP BY a.CUST_NO
 UNION ALL
 SELECT CUST_NO,SUM(MTCH_AMT) as MTCH_AMT
 FROM   DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS a
 WHERE  SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 AND    WRNT_BS_DRCT IN ('1','2')
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 GROUP BY CUST_NO
 UNION ALL
 SELECT CUST_NO,SUM(CNFM_AMT) as MTCH_AMT
 FROM   DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS a
 WHERE  SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 AND    PROD_BIZ_CD IN ('130','122','142','150','139','124')
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 GROUP BY CUST_NO
 )  t
 GROUP BY t.CUST_NO
 ;
 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP5;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP5 as 
 SELECT         t.BRH_NO
               ,t.CUST_STAR
              
			     ,SUM(NVL(a2.NET_TFR_IN_AMT,0)+NVL(a2.NET_TFR_IN_MKTVAL,0)) as NET_TFR_IN_AST
				 ,SUM(NVL(a3.ORDI_TRD_VOL_HB_USD_RMB,0)+NVL(a3.ORDI_TRD_VOL_SB_HKD_RMB,0)+NVL(a3.TRD_VOL_GEM,0)+NVL(a3.TRD_VOL_SMS,0)+NVL(a3.TRD_VOL_SA,0)+NVL(a3.TRD_VOL_HA,0)) as STK_TRD_VOL
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a3.ORDI_TRD_VOL_HB_USD_RMB,0)+NVL(a3.ORDI_TRD_VOL_SB_HKD_RMB,0)+NVL(a3.TRD_VOL_GEM,0)+NVL(a3.TRD_VOL_SMS,0)+NVL(a3.TRD_VOL_SA,0)+NVL(a3.TRD_VOL_HA,0)
					       ELSE 0
					       END
					)       as BROK_RLN_STK_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a3.ORDI_TRD_VOL_HB_USD_RMB,0)+NVL(a3.ORDI_TRD_VOL_SB_HKD_RMB,0)+NVL(a3.TRD_VOL_GEM,0)+NVL(a3.TRD_VOL_SMS,0)+NVL(a3.TRD_VOL_SA,0)+NVL(a3.TRD_VOL_HA,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_STK_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a3.ORDI_TRD_VOL_HB_USD_RMB,0)+NVL(a3.ORDI_TRD_VOL_SB_HKD_RMB,0)+NVL(a3.TRD_VOL_GEM,0)+NVL(a3.TRD_VOL_SMS,0)+NVL(a3.TRD_VOL_SA,0)+NVL(a3.TRD_VOL_HA,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_STK_TRD_VOL
					
				 ,SUM(NVL(a3.ORDI_TRD_VOL_EXG_FND,0)+NVL(a3.CRD_TRD_VOL_EXG_FND,0)) as FND_TRD_VOL
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a3.ORDI_TRD_VOL_EXG_FND,0)+NVL(a3.CRD_TRD_VOL_EXG_FND,0)
					       ELSE 0
					       END
					)       as BROK_RLN_FND_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a3.ORDI_TRD_VOL_EXG_FND,0)+NVL(a3.CRD_TRD_VOL_EXG_FND,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_FND_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a3.ORDI_TRD_VOL_EXG_FND,0)+NVL(a3.CRD_TRD_VOL_EXG_FND,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_FND_TRD_VOL
			  
			     ,SUM(NVL(a3.ORDI_TRD_VOL_HK,0)+NVL(a3.ORDI_TRD_VOL_SK,0)) as H_K_TRD_VOL
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a3.ORDI_TRD_VOL_HK,0)+NVL(a3.ORDI_TRD_VOL_SK,0)
					       ELSE 0
					       END
					)       as BROK_RLN_H_K_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a3.ORDI_TRD_VOL_HK,0)+NVL(a3.ORDI_TRD_VOL_SK,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_H_K_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a3.ORDI_TRD_VOL_HK,0)+NVL(a3.ORDI_TRD_VOL_SK,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_H_K_TRD_VOL
					
				 ,SUM(NVL(a4.NEW_T3BOD_TRD_VOL,0)) as NEW_T3BOD_TRD_VOL
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a4.NEW_T3BOD_TRD_VOL,0)
					       ELSE 0
					       END
					)       as BROK_RLN_NEW_T3BOD_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a4.NEW_T3BOD_TRD_VOL,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_NEW_T3BOD_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a4.NEW_T3BOD_TRD_VOL,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_NEW_T3BOD_TRD_VOL
				 ,SUM(NVL(a5.TRD_VOL_CRD,0)) as CRD_TRD_VOL
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a5.TRD_VOL_CRD,0)
					       ELSE 0
					       END
					)       as BROK_RLN_CRD_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a5.TRD_VOL_CRD,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_RLN_CRD_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a5.TRD_VOL_CRD,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_RLN_CRD_TRD_VOL
                      
                ,SUM(NVL(a5.TDY_ADDED_MRGNC_INT,0))  as TYM_ADDED_MRGNC_INT            --当月新增融资利息
                ,SUM(NVL(a5.TDY_ADDED_MRGNS_INT,0))  as TYM_ADDED_MRGNS_INT          --当月新增融券利息

		       
                ,SUM(NVL(a2.STK_PLG_ADD_INT,0))          as STK_PLG_ADD_INT              --股票质押新增利息
                ,SUM(NVL(a2.STK_PLG_ADD_TRD_AMT,0))      as STK_PLG_ADD_TRD_AMT          --股票质押初始交易量
                ,SUM(NVL(a2.MIN_STK_PLG_ADD_INT,0))      as MIN_STK_PLG_ADD_INT          --小微贷新增利息
                ,SUM(NVL(a2.MIN_STK_PLG_ADD_TRD_AMT,0))  as MIN_STK_PLG_ADD_TRD_AMT      --小微贷初始交易量	
				,SUM(CASE WHEN NVL(a2.STK_PLG_ADD_TRD_AMT,0) > 0
				      THEN 1
					  ELSE 0
					  END) as  TRD_PLG_REPO_CUST_VOL          --交易质押回购客户数(股票质押)
                ,SUM(CASE WHEN NVL(a2.MIN_STK_PLG_ADD_TRD_AMT,0) > 0
				      THEN 1
					  ELSE 0
					  END) as TRD_STK_PLG_CUST_VOL           --交易股票质押客户数(小微贷)
				 ,SUM(CASE WHEN NVL(a2.STK_PLG_AMT,0) > 0
				      THEN 1
					  ELSE 0
					  END) as  PLG_REPO_FNL_AMT_CUST_VOL         --期末有股票质押余额客户数(股票质押)
                ,SUM(CASE WHEN NVL(a2.MIN_STK_PLG_AMT,0) > 0
				      THEN 1
					  ELSE 0
					  END) as STK_PLG_FNL_AMT_CUST_VOL          --期末有小微贷余额客户数(小微贷)
				 ,SUM(NVL(a3.ORDI_NET_S1_INCM_HB_RMB,0)+NVL(a3.ORDI_NET_S1_INCM_SB_RMB,0)+NVL(a3.NET_S1_INCM_HA,0)+NVL(a3.NET_S1_INCM_SA,0)+NVL(a3.NET_S1_INCM_SMS,0)+NVL(a3.NET_S1_INCM_GEM,0)) as STK_NET_S1 
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a3.ORDI_NET_S1_INCM_HB_RMB,0)+NVL(a3.ORDI_NET_S1_INCM_SB_RMB,0)+NVL(a3.NET_S1_INCM_HA,0)+NVL(a3.NET_S1_INCM_SA,0)+NVL(a3.NET_S1_INCM_SMS,0)+NVL(a3.NET_S1_INCM_GEM,0)
					       ELSE 0
					       END
					)       as BROK_RLN_STK_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a3.ORDI_NET_S1_INCM_HB_RMB,0)+NVL(a3.ORDI_NET_S1_INCM_SB_RMB,0)+NVL(a3.NET_S1_INCM_HA,0)+NVL(a3.NET_S1_INCM_SA,0)+NVL(a3.NET_S1_INCM_SMS,0)+NVL(a3.NET_S1_INCM_GEM,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_STK_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a3.ORDI_NET_S1_INCM_HB_RMB,0)+NVL(a3.ORDI_NET_S1_INCM_SB_RMB,0)+NVL(a3.NET_S1_INCM_HA,0)+NVL(a3.NET_S1_INCM_SA,0)+NVL(a3.NET_S1_INCM_SMS,0)+NVL(a3.NET_S1_INCM_GEM,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_STK_NET_S1
					
				 ,SUM(NVL(a3.ORDI_NET_S1_INCM_EXG_FND,0)+NVL(a3.CRD_NET_S1_INCM_EXG_FND,0)) as FND_NET_S1 
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a3.ORDI_NET_S1_INCM_EXG_FND,0)+NVL(a3.CRD_NET_S1_INCM_EXG_FND,0)
					       ELSE 0
					       END
					)       as BROK_RLN_FND_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a3.ORDI_NET_S1_INCM_EXG_FND,0)+NVL(a3.CRD_NET_S1_INCM_EXG_FND,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_FND_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a3.ORDI_NET_S1_INCM_EXG_FND,0)+NVL(a3.CRD_NET_S1_INCM_EXG_FND,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_FND_NET_S1
					
				 ,SUM(NVL(a3.ORDI_NET_S1_INCM_HK,0)+NVL(a3.ORDI_NET_S1_INCM_SK,0)) as H_K_NET_S1 
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a3.ORDI_NET_S1_INCM_HK,0)+NVL(a3.ORDI_NET_S1_INCM_SK,0)
					       ELSE 0
					       END
					)       as BROK_RLN_H_K_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a3.ORDI_NET_S1_INCM_HK,0)+NVL(a3.ORDI_NET_S1_INCM_SK,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_H_K_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a3.ORDI_NET_S1_INCM_HK,0)+NVL(a3.ORDI_NET_S1_INCM_SK,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_H_K_NET_S1
					
				 ,SUM(NVL(a4.NEW_T3BOD_NET_S1,0)) as NEW_T3BOD_NET_S1
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a4.NEW_T3BOD_NET_S1,0)
					       ELSE 0
					       END
					)       as BROK_RLN_NEW_T3BOD_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a4.NEW_T3BOD_NET_S1,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_NEW_T3BOD_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a4.NEW_T3BOD_NET_S1,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_NEW_T3BOD_NET_S1           
                 ,SUM(NVL(a8.TRD_VOL,0))  as TRD_VOL                     
                 ,SUM(NVL(a3.ORDI_NET_S1_INCM_RMB,0)+NVL(a3.CRD_NET_S1_INCM,0)) as NET_S1_INCM                 
                 ,SUM(NVL(a3.CRD_MRGNC_MRGNS_PRDCT_INT,0)+NVL(a3.ORDI_PLG_REPO_PRDCT_INT,0)) as INT_INCM                    
                 ,SUM(NVL(a3.NET_S1_INCM_HA,0)+NVL(a3.NET_S1_INCM_SA,0)+NVL(a3.NET_S1_INCM_SMS,0)+NVL(a3.NET_S1_INCM_GEM,0)+NVL(a3.NET_S1_INCM_STIB_AK,0)+NVL(a3.NET_S1_INCM_STIB_AK,0)) as A_STK_NET_S1                
                 ,SUM(NVL(a3.TRD_VOL_HA,0)+NVL(a3.TRD_VOL_SA,0)+NVL(a3.TRD_VOL_SMS,0)+NVL(a3.TRD_VOL_GEM,0)+NVL(a3.TRD_VOL_RK,0)+NVL(a3.TRD_VOL_AK,0)) as A_STK_TRD_VOL                              
 FROM          DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL   t
 INNER JOIN    DDW_PROD.T_DDW_INR_ORG_BRH               a1
 ON            t.BRH_NO = a1.BRH_NO
 AND           a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     (SELECT CUST_NO
                     , SUM(NET_TFR_IN_AMT)           as NET_TFR_IN_AMT
					 , SUM(NET_TFR_IN_MKTVAL)        as NET_TFR_IN_MKTVAL
					 , SUM(STK_PLG_ADD_INT)          as STK_PLG_ADD_INT
					 , SUM(STK_PLG_ADD_TRD_AMT)      as STK_PLG_ADD_TRD_AMT
					 , SUM(MIN_STK_PLG_ADD_INT)      as MIN_STK_PLG_ADD_INT
					 , SUM(MIN_STK_PLG_ADD_TRD_AMT)  as MIN_STK_PLG_ADD_TRD_AMT
					 , sum(DECODE(BUS_DATE,20160606,STK_PLG_AMT,0)) as  STK_PLG_AMT
					 , sum(DECODE(BUS_DATE,20160606,MIN_STK_PLG_AMT,0)) as  MIN_STK_PLG_AMT
				FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
				WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
				GROUP BY CUST_NO
				
				)       a2
 ON            t.CUST_NO = a2.CUST_NO
 LEFT JOIN     (SELECT  CUST_NO
                      , SUM(ROUND(NVL(a.ORDI_TRD_VOL_HB_USD,0)*b.ZHHL,2))           as ORDI_TRD_VOL_HB_USD_RMB
		              , SUM(ROUND(NVL(a.ORDI_TRD_VOL_SB_HKD,0)*c.ZHHL,2))           as ORDI_TRD_VOL_SB_HKD_RMB
		              , SUM(TRD_VOL_GEM) as TRD_VOL_GEM
		              , SUM(TRD_VOL_SMS) as TRD_VOL_SMS
		              , SUM(TRD_VOL_HA) as TRD_VOL_HA
                      , SUM(TRD_VOL_SA) as TRD_VOL_SA	
                      , SUM(TRD_VOL_RK) as TRD_VOL_RK
                      , SUM(TRD_VOL_AK) as TRD_VOL_AK					  
		              , SUM(ORDI_TRD_VOL_EXG_FND)      as ORDI_TRD_VOL_EXG_FND
		              , SUM(CRD_TRD_VOL_EXG_FND)       as CRD_TRD_VOL_EXG_FND
		              , SUM(ORDI_TRD_VOL_HK)           as ORDI_TRD_VOL_HK
		              , SUM(ORDI_TRD_VOL_SK)           as ORDI_TRD_VOL_SK
		              , SUM(ORDI_NET_S1_INCM_HB_RMB)   as ORDI_NET_S1_INCM_HB_RMB
		              , SUM(ORDI_NET_S1_INCM_SB_RMB)   as ORDI_NET_S1_INCM_SB_RMB
		              , SUM(NET_S1_INCM_HA)            as NET_S1_INCM_HA
		              , SUM(NET_S1_INCM_SA)            as NET_S1_INCM_SA
		              , SUM(NET_S1_INCM_SMS)           as NET_S1_INCM_SMS
		              , SUM(NET_S1_INCM_GEM)           as NET_S1_INCM_GEM
		              , SUM(ORDI_NET_S1_INCM_EXG_FND)  as ORDI_NET_S1_INCM_EXG_FND
		              , SUM(CRD_NET_S1_INCM_EXG_FND)   as CRD_NET_S1_INCM_EXG_FND
		              , SUM(ORDI_NET_S1_INCM_HK)       as ORDI_NET_S1_INCM_HK
		              , SUM(ORDI_NET_S1_INCM_SK)       as ORDI_NET_S1_INCM_SK
		              , SUM(ORDI_NET_S1_INCM_RMB)          as ORDI_NET_S1_INCM_RMB
		              , SUM(CRD_NET_S1_INCM)               as CRD_NET_S1_INCM               
                      , SUM(CRD_MRGNC_MRGNS_PRDCT_INT) as CRD_MRGNC_MRGNS_PRDCT_INT
		              , SUM(ORDI_PLG_REPO_PRDCT_INT)   as ORDI_PLG_REPO_PRDCT_INT 
                      , SUM(NET_S1_INCM_STIB_AK)	 as NET_S1_INCM_STIB_AK	
                      , SUM(NET_S1_INCM_STIB_RK)	 as NET_S1_INCM_STIB_RK					  

         FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY    a
         LEFT JOIN     EDW_PROD.T_EDW_T99_HLZH                   b
         ON            a.BUS_DATE = b.BUS_DATE
         AND           b.BZDM = 'USD'
         LEFT JOIN     EDW_PROD.T_EDW_T99_HLZH                   c
         ON            a.BUS_DATE = c.BUS_DATE
         AND           c.BZDM = 'HKD'  
         WHERE SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
         GROUP BY CUST_NO
				
				)   a3
 ON            t.CUST_NO = a3.CUST_NO
LEFT JOIN    (SELECT CUST_NO,SUM(MTCH_AMT) as NEW_T3BOD_TRD_VOL,SUM(S1-S11-S12) as NEW_T3BOD_NET_S1
                FROM  DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
                WHERE  SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
				AND   ODR_CGY IN (1,2,57,58,59,60,78,79)
				AND   EXG IN ('TA')
				AND   SUBSTR(SEC_CD,1,2) IN ('43','83','87')
				AND   SYS_SRC = '普通账户'
				GROUP BY CUST_NO
			   ) a4
 ON            t.CUST_NO = a4.CUST_NO
 
LEFT JOIN    (SELECT  CUST_NO
                   , SUM(TDY_ADDED_MRGNC_INT)           as TDY_ADDED_MRGNC_INT
		           , SUM(TDY_ADDED_MRGNS_INT)           as TDY_ADDED_MRGNS_INT
		           , SUM(TRD_VOL_CRD) as TRD_VOL_CRD
             FROM DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY    a
             WHERE SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
             GROUP BY CUST_NO
             ) a5
 ON            t.CUST_NO = a5.CUST_NO
 LEFT JOIN     DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP4 a8
 ON             t.CUST_NO = a8.CUST_NO
 WHERE         t.BUS_DATE = %d{yyyyMMdd}
 GROUP BY       t.BRH_NO
               ,t.CUST_STAR
 ; 
 
 
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP6 ;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP6 as 
 SELECT CUST_NO
 FROM   DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
 WHERE  SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
 AND    ODR_CGY IN (1,2,4,5,12,13,17,29,30,34,35,36,42,43,57,58,59,60,61,62,63,64,71,78,79,80,83,114,124,1111,2222)
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 AND    BUS_DATE < = %d{yyyyMMdd}
 UNION 
 SELECT CUST_NO
 FROM   DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
 WHERE   SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
 AND    WRNT_BS_DRCT IN ('1','2')
 AND    CUST_NO NOT IN ('105810000001','100610335855')
  AND    BUS_DATE < = %d{yyyyMMdd}
 UNION 
 
 SELECT CUST_NO
 FROM   DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS
 WHERE  SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
 AND    PROD_BIZ_CD IN ('130','122','142','150','139','124')
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 AND    BUS_DATE < = %d{yyyyMMdd} ;
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP8 ;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP8 as 
 SELECT t.CUST_NO,SUM(MTCH_AMT) as TRD_VOL,SUM(NET_S1) as NET_S1
 FROM 
 (SELECT CUST_NO,SUM(ROUND(CASE WHEN b.BUS_DATE IS NOT NULL
                               THEN a.MTCH_AMT*b.ZHHL
						       ELSE a.MTCH_AMT
						       END,2)
			        ) as MTCH_AMT
			    ,SUM(ROUND(CASE WHEN a.EXG IN ('HK','SK')
				                THEN a.S1
				               WHEN b.BUS_DATE IS NOT NULL AND a.EXG NOT IN ('HK','SK')
                               THEN (a.S1-S11-S12)*b.ZHHL
						       ELSE (a.S1-S11-S12)
						       END,2)
			        ) as NET_S1
 FROM   DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS a
 LEFT JOIN     EDW_PROD.T_EDW_T99_HLZH         b
 ON            a.BUS_DATE = b.BUS_DATE
 AND           b.BZDM = a.CCY_CD
 WHERE  a.BUS_DATE <= %d{yyyyMMdd}
 AND    a.ODR_CGY IN (1,2,4,5,12,13,17,29,30,34,35,36,42,43,57,58,59,60,61,62,63,64,71,78,79,80,83,114,124,1111,2222)
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 AND SUBSTR(CAST(a.BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
 GROUP BY a.CUST_NO
 UNION ALL
 SELECT CUST_NO,SUM(MTCH_AMT) as MTCH_AMT,SUM(S1-S11-S12) as NET_S1
 FROM   DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
 WHERE  BUS_DATE <= %d{yyyyMMdd}
 AND    WRNT_BS_DRCT IN ('1','2')
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 AND   SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
 GROUP BY CUST_NO
 UNION ALL
 SELECT CUST_NO,SUM(CNFM_AMT) as MTCH_AMT,SUM(0) as NET_S1
 FROM   DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS
 WHERE  BUS_DATE <= %d{yyyyMMdd}
 AND    PROD_BIZ_CD IN ('130','122','142','150','139','124')
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 AND   SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
 GROUP BY CUST_NO
 )  t
 GROUP BY t.CUST_NO
 ;
 
 
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP7;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP7 as 
 SELECT         t.BRH_NO
               ,t.CUST_STAR              
               ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TISSU_GT_TRD_CUST_VOL
			  ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TISSU_GT_TRD_CRD_CUST_VOL
               ,SUM(CASE WHEN a10.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TISSU_GT_TRD_STIB_CUST_VOL
              ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TISSU_GT_TRD_H_K_CUST_VOL
            
              ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TISSU_GT_TRD_WRNT_CUST_VOL			
			  
              
               ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TISSU_GT_TRD_NWE_T3BOD_CUST_VOL                	
	            
				
                 ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.OPNAC_DT,0) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
			               AND  NVL(t.OPNAC_DT,0) < = %d{yyyyMMdd}
						  THEN a7.NET_TOT_AST
					     ELSE 0
					     END
				   )                        as TISSU_GT_NEW_OPNAC_NET_TOT_AST
		
				 ,SUM(CASE WHEN   SUBSTR(CAST(NVL(t.VLD_DT,0) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
                         AND   SUBSTR(CAST(NVL(t.OPNAC_DT,0) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
						 AND  NVL(t.VLD_DT,0) < = %d{yyyyMMdd}
			             THEN a7.NET_TOT_AST
					     ELSE 0
					     END
				   )                        as TISSU_GT_ADDED_VLD_NET_TOT_AST
				  ,SUM(CASE WHEN   SUBSTR(CAST(NVL(t.VLD_DT,0) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
                            AND   SUBSTR(CAST(NVL(t.OPNAC_DT,0) as STRING),1,4) < SUBSTR('%d{yyyyMMdd}',1,4)
							AND   SUBSTR(CAST(NVL(t.OPNAC_DT,0) as STRING),1,4) >= '2016'
							AND  NVL(t.VLD_DT,0) < = %d{yyyyMMdd}
			                THEN a7.NET_TOT_AST							
					        ELSE 0
					        END
				     )                        as TISSU_GT_ADDED_OLD_VLD_NET_TOT_AST	
                  ,SUM(CASE     WHEN   t.CUST_STAT < > '3' 
                            AND    SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) < SUBSTR('%d{yyyyMMdd}',1,4)
                            AND SUBSTR(CAST(NVL(t.OPNAC_DT,0) as STRING),1,4) >= '2016'							
                            AND    NVL(t.IB_CUST_FLG,'0') = '1'
			                THEN a8.TRD_VOL
					        ELSE 0
					        END
				     )                        as TISSU_GT_OLD_INR_PB_TRD_VOL         --当年存量内部PB交易量
		  ,SUM(CASE   WHEN   t.CUST_STAT < > '3' 
                          AND    SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
                          AND    NVL(t.IB_CUST_FLG,'0') = '1'
			              THEN a8.TRD_VOL
					      ELSE 0
					      END
				     )                        as TISSU_GT_ADDED_INR_PB_TRD_VOL       --当年增量内部PB交易量
		    ,SUM(CASE   WHEN   t.CUST_STAT < > '3' 
                            AND    SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) < SUBSTR('%d{yyyyMMdd}',1,4)
                            AND SUBSTR(CAST(NVL(t.OPNAC_DT,0) as STRING),1,4) >= '2016'
							AND    NVL(t.IB_CUST_FLG,'0') = '1'
			                THEN a8.NET_S1
					        ELSE 0
					        END
				     )                        as TISSU_GT_OLD_INR_PB_NET_S1          --当年存量内部PB净佣金
		  ,SUM(CASE   WHEN   t.CUST_STAT < > '3' 
                          AND    SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) > SUBSTR('%d{yyyyMMdd}',1,4)
                          AND    NVL(t.IB_CUST_FLG,'0') = '1'
			              THEN a8.NET_S1
					      ELSE 0
					      END
				     )                        as TISSU_GT_ADDED_INR_PB_NET_S1        --当年增量内部PB净佣金		
           ,SUM(CASE     WHEN   t.CUST_STAT < > '3' 
                            AND    SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) < SUBSTR('%d{yyyyMMdd}',1,4)
                            AND SUBSTR(CAST(NVL(t.OPNAC_DT,0) as STRING),1,4) >= '2016'
							AND    NVL(t.IB_CUST_FLG,'0') = '1'
			                THEN a9.INCM_AMT
					        ELSE 0
					        END
				     )                        as TISSU_GT_OLD_INR_PB_INT_INCM        --当年存量内部PB息差收入
		  ,SUM(CASE  WHEN   t.CUST_STAT < > '3' 
                          AND    SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) > SUBSTR('%d{yyyyMMdd}',1,4)
                          AND    NVL(t.IB_CUST_FLG,'0') = '1'
			              THEN a9.INCM_AMT
					      ELSE 0
					      END
				     )                        as TISSU_GT_ADDED_INR_PB_INT_INCM      --当年增量内部PB息差收入				 
 FROM          DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL   t
 INNER JOIN    DDW_PROD.T_DDW_INR_ORG_BRH               a1
 ON            t.BRH_NO = a1.BRH_NO
 AND           a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP6 a2
 ON            t.CUST_NO = a2.CUST_NO
 LEFT JOIN   (SELECT CUST_NO 
              FROM  DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
              WHERE SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
			  AND   ODR_CGY IN (1,2,61,62,63,64,71,72,80,83)
			  AND   SYS_SRC = '信用账户'
			  AND   BUS_DATE < = %d{yyyyMMdd}
			  GROUP BY CUST_NO
			  )                                   a3
  ON            t.CUST_NO = a3.CUST_NO
 LEFT JOIN   (SELECT CUST_NO 
              FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
              WHERE SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
			  AND   ODR_CGY IN (1,2,80,83)
			  AND   EXG IN ('HK','SK')
			  AND   SYS_SRC = '普通账户'
			  AND   BUS_DATE < = %d{yyyyMMdd} 
			  GROUP BY CUST_NO
             )                                   a4
  ON            t.CUST_NO = a4.CUST_NO
 LEFT JOIN   (SELECT CUST_NO
              FROM   DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
              WHERE  SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
              AND    WRNT_BS_DRCT IN ('1','2')
			  AND    BUS_DATE < = %d{yyyyMMdd}
			  GROUP BY CUST_NO
             )                                   a5
  ON            t.CUST_NO = a5.CUST_NO
  LEFT JOIN   (SELECT CUST_NO 
               FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
               WHERE SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
			   AND   ODR_CGY IN (1,2,57,58,59,60,78,79)
			   AND   EXG IN ('TA')
			   AND   SUBSTR(SEC_CD,1,2) IN ('43','83','87')
			   AND   SYS_SRC = '普通账户'
			   AND   BUS_DATE < = %d{yyyyMMdd}
			   GROUP BY CUST_NO
              )                                   a6
 ON            t.CUST_NO = a6.CUST_NO
  LEFT JOIN     DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY   a7
 ON            t.CUST_NO = a7.CUST_NO
 AND           a7.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP8 a8
 ON          t.CUST_NO = a8.CUST_NO
 LEFT JOIN ( SELECT CUST_NO ,SUM(ROUND(CASE WHEN b.BUS_DATE IS NOT NULL
                               THEN (a.INCM_AMT*b.ZHHL)*(1.62-0.35)/0.35
						       ELSE (a.INCM_AMT)*(1.62-0.35)/0.35
						       END,2)
			                 ) as INCM_AMT
		  FROM   DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS a
          LEFT JOIN     EDW_PROD.T_EDW_T99_HLZH         b
          ON            a.BUS_DATE = b.BUS_DATE
          AND           b.BZDM = a.CCY_CD
		  WHERE SUBSTR(CAST(a.BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		  AND   a.BUS_DATE < = %d{yyyyMMdd}
		  AND   a.BIZ_SBJ IN ('10501','10503')
		  GROUP BY a.CUST_NO 
		  )   a9
 ON   t.CUST_NO = a9.CUST_NO
 LEFT JOIN   (SELECT CUST_NO 
                FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
                WHERE SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
			    AND   ODR_CGY IN (1,2,61,62,63,64,71,72,80,57,58,59,60,78,79,29,30,1111,2222)
			    AND   EXG IN ('SH')
			    AND   SUBSTR(SEC_CD,1,3) IN ('688')
			    AND   SYS_SRC = '普通账户'
				AND   BUS_DATE < = %d{yyyyMMdd}
			    GROUP BY CUST_NO
              )                                   a10
 ON            t.CUST_NO = a10.CUST_NO
 WHERE         t.BUS_DATE = %d{yyyyMMdd}
 GROUP BY       t.BRH_NO
               ,t.CUST_STAR
 ;
 
 



INSERT OVERWRITE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON
(
           BELTO_FILIL_CDG                                 --分公司编码
          ,BELTO_FILIL                                     --分公司名称
          ,BRH_NO                                          --营业部编码
          ,BRH_FULLNM                                      --营业部名称
          ,CUST_STAR                                       --客户星级         
		  ,STRT_CUST_VOL                     --期初客户数
		  ,STRT_QLFD_CUST_VOL                --期初合格客户数
		  ,STRT_BROK_RLN_QLFD_CUST_VOL       --期初经纪关系合格客户数
          ,STRT_STRONG_SVC_RLN_QLFD_CUST_VOL --期初强服务关系合格客户数
          ,STRT_WEAK_SVC_RLN_QLFD_CUST_VOL   --期初弱服务关系合格客户数
		  ,STRT_BROK_RLN_CUST_VOL            --期初经纪关系客户数
		  ,STRT_STRONG_SVC_RLN_CUST_VOL      --期初强服务关系客户数
		  ,STRT_WEAK_SVC_RLN_CUST_VOL        --期初弱服务关系客户数
		  ,STRT_CRD_CUST_VOL                 --期初信用客户数
		  ,STRT_H_K_CUST_VOL                 --期初港股通客户数
          ,STRT_WRNT_CUST_VOL                --期初期权客户数
		  ,STRT_STIB_CUST_VOL                --期初科创板客户数
		  ,STRT_NEW_T3BOD_CUST_VOL           --期初新三板客户数(受限制+非受限制) 
		  ,STRT_T3BOD_CUST_VOL               --期初三板客户数 
		  ,STRT_PLG_REPO_CUST_VOL            --期初质押回购客户数(股票质押)
          ,STRT_STK_PLG_CUST_VOL             --期初股票质押客户数(小微贷)
          ,STRT_STR_FND_CUST_VOL             --期初分级基金客户数
          ,STRT_PROD_CUST_VOL                --期初产品客户数
          ,STRT_INR_PB_CUST_VOL              --期初内部PB账户数
          ,STRT_EXTN_PB_CUST_VOL             --期初外部PB账户数
          ,STRT_CASH_PROD_CUST_VOL           --期初现金添利客户数
          ,FNL_CUST_VOL                      --期末客户数
		  ,FNL_QLFD_CUST_VOL                 --期末合格客户数
		  ,FNL_BROK_RLN_QLFD_CUST_VOL        --期末经纪关系合格客户数
          ,FNL_STRONG_SVC_RLN_QLFD_CUST_VOL  --期末强服务关系合格客户数
          ,FNL_WEAK_SVC_RLN_QLFD_CUST_VOL    --期末弱服务关系合格客户数
		  ,FNL_BROK_RLN_CUST_VOL             --期末经纪关系客户数
		  ,FNL_STRONG_SVC_RLN_CUST_VOL       --期末强服务关系客户数
		  ,FNL_WEAK_SVC_RLN_CUST_VOL         --期末弱服务关系客户数
		  ,FNL_CRD_CUST_VOL                  --期末信用客户数
		  ,FNL_H_K_CUST_VOL                  --期末港股通客户数
          ,FNL_WRNT_CUST_VOL                 --期末期权客户数
		  ,FNL_STIB_CUST_VOL                 --期末科创板客户数
		  ,FNL_NEW_T3BOD_CUST_VOL            --期末新三板客户数(受限制+非受限制) 
		  ,FNL_T3BOD_CUST_VOL                --期末三板客户数 
		  ,FNL_PLG_REPO_CUST_VOL             --期末质押回购客户数(股票质押)
          ,FNL_STK_PLG_CUST_VOL              --期末股票质押客户数(小微贷)
          ,FNL_STR_FND_CUST_VOL              --期末分级基金客户数
          ,FNL_PROD_CUST_VOL                 --期末产品客户数
          ,FNL_INR_PB_CUST_VOL               --期末内部PB账户数
          ,FNL_EXTN_PB_CUST_VOL              --期末外部PB账户数
          ,FNL_CASH_PROD_CUST_VOL            --期末现金添利客户数 			
		  ,TRD_CUST_VOL                      --交易客户客户数
          ,ADDED_VLD_CUST_VOL                --新增有效客户数
          ,ADDED_OLD_VLD_CUST_VOL            --新增存量有效客户数
          ,TRD_CRD_CUST_VOL                  --交易信用客户数
          ,TRD_H_K_CUST_VOL                  --交易港股通客户数
          ,TRD_WRNT_CUST_VOL                 --交易期权客户数          
          ,TRD_NWE_T3BOD_CUST_VOL            --交易新三板客户数
		  ,TRD_STIB_CUST_VOL                 --交易科创板客户数
		  ,TRD_PLG_REPO_CUST_VOL             --交易质押回购客户数(股票质押)
          ,TRD_STK_PLG_CUST_VOL              --交易股票质押客户数(小微贷)
		  ,TISSU_GT_TRD_CUST_VOL             --本期累计交易客户客户数
          ,TISSU_GT_TRD_CRD_CUST_VOL         --本期累计交易信用客户数
          ,TISSU_GT_TRD_H_K_CUST_VOL         --本期累计交易港股通客户数
          ,TISSU_GT_TRD_WRNT_CUST_VOL        --本期累计交易期权客户数
          ,TISSU_GT_TRD_NWE_T3BOD_CUST_VOL   --本期累计交易新三板客户数
		  ,TISSU_GT_TRD_STIB_CUST_VOL        --本期累计交易科创板客户数
          ,TISSU_GT_NEW_OPNAC_NET_TOT_AST    --本期累计新开户净资产
          ,TISSU_GT_ADDED_VLD_NET_TOT_AST    --本期累计新增有效户净资产
          ,TISSU_GT_ADDED_OLD_VLD_NET_TOT_AST--本期累计存量有效户净资产
		  ,PLG_REPO_FNL_AMT_CUST_VOL         --期末有股票质押余额客户数(股票质押)
          ,STK_PLG_FNL_AMT_CUST_VOL          --期末有小微贷余额客户数(小微贷)
          ,OPNAC_CUST_VOL                    --开户数(当月)
          ,OPNAC_CRD_CUST_VOL                --开户信用客户数(当月)
          ,OPNAC_WRNT_CUST_VOL               --开户期权客户数(当月)
          ,OPN_STIB_CUST_VOL                 --开通科创板客户数(当月) 
          ,OPN_H_K_CUST_VOL                  --开通港股通客户数(当月)		  
          ,OPN_PLG_REPO_CUST_VOL             --开通质押回购客户数(股票质押)(当月)
          ,OPN_STK_PLG_CUST_VOL              --开通股票质押客户数(小微贷)(当月)
          ,OPN_STR_FND_CUST_VOL              --开通分级基金客户数
          ,OPN_NEW_T3BOD_CUST_VOL            --开通新三板客户数(受限制当日+非受限制当日)
          ,OPN_T3BOD_CUST_VOL                --开通三板客户数(当月)
          ,CNCLACT_CUST_VOL                  --销户数(当月)
          ,CNCLACT_CRD_CUST_VOL              --销户信用客户数(当月)
          ,CNCLACT_WRNT_CUST_VOL             --销户期权客户数(当月)
          ,CLS_STIB_CUST_VOL                 --关闭科创板客户数(当月)
          ,CLS_H_K_CUST_VOL                  --关闭港股通客户数(当月)
          ,CLS_PLG_REPO_CUST_VOL             --关闭质押回购客户数(股票质押)(当月)
          ,CLS_STK_PLG_CUST_VOL              --关闭股票质押客户数(小微贷)(当月)
          ,CLS_STR_FND_CUST_VOL              --关闭分级基金客户数
          ,CLS_NEW_T3BOD_CUST_VOL            --关闭新三板客户数(受限制当日+非受限制当日)
          ,CLS_T3BOD_CUST_VOL                --关闭三板客户数(当月)	  
		  ,STRT_CUST_TOT_AST                 --期初客户总资产
          ,STRT_CUST_NET_TOT_AST             --期初客户净资产
          ,STRT_BROK_RLN_CUST_NET_TOT_AST    --期初经纪关系净资产
          ,STRT_STRONG_SVC_CUST_NET_TOT_AST  --期初强服务关系净资产
          ,STRT_WEAK_SVC_CUST_NET_TOT_AST    --期初弱服务关系净资产
		  ,FNL_CUST_TOT_AST                  --期末客户总资产
          ,FNL_CUST_NET_TOT_AST              --期末客户净资产
          ,FNL_BROK_RLN_CUST_NET_TOT_AST     --期末经纪关系净资产
          ,FNL_STRONG_SVC_CUST_NET_TOT_AST   --期末强服务关系净资产
          ,FNL_WEAK_SVC_CUST_NET_TOT_AST     --期末弱服务关系净资产
          ,NEW_OPNAC_NET_TOT_AST             --新开户期末净资产
          ,ADDED_VLD_NET_TOT_AST             --新增有效户期末净资产
          ,ADDED_OLD_VLD_NET_TOT_AST         --存量有效户期末净资产
          ,NET_TFR_IN_AST                    --资产净流入
          ,STK_TRD_VOL                       --股票交易量
          ,BROK_RLN_STK_TRD_VOL              --经纪关系股票交易量
          ,STRONG_SVC_STK_TRD_VOL            --强服务关系股票交易量
          ,WEAK_SVC_STK_TRD_VOL              --弱服务关系股票交易量
          ,FND_TRD_VOL                       --基金交易量
          ,BROK_RLN_FND_TRD_VOL              --经纪关系基金交易量
          ,STRONG_SVC_FND_TRD_VOL            --强服务关系基金交易量
          ,WEAK_SVC_FND_TRD_VOL              --弱服务关系基金交易量
          ,H_K_TRD_VOL                       --港股通交易量
          ,BROK_RLN_H_K_TRD_VOL              --经纪关系港股通交易量
          ,STRONG_SVC_H_K_TRD_VOL            --强服务关系港股通交易量
          ,WEAK_SVC_H_K_TRD_VOL              --弱服务关系港股通交易量
          ,NEW_T3BOD_TRD_VOL                 --新三板交易量
          ,BROK_RLN_NEW_T3BOD_TRD_VOL        --经纪关系新三板交易量
          ,STRONG_SVC_NEW_T3BOD_TRD_VOL      --强服务关系新三板交易量
          ,WEAK_SVC_NEW_T3BOD_TRD_VOL        --弱服务关系新三板交易量
          ,CRD_TRD_VOL                       --融资融券交易量
		  ,BROK_RLN_CRD_TRD_VOL              --经纪关系融资融券交易量
          ,STRONG_SVC_RLN_CRD_TRD_VOL        --强服务关系融资融券交易量
          ,WEAK_SVC_RLN_CRD_TRD_VOL          --弱服务关系融资融券交易量
          ,TYM_ADDED_MRGNC_INT               --当日新增融资利息
          ,TYM_ADDED_MRGNS_INT               --当日新增融券利息
          ,STRT_STK_PLG_AMT                  --期初股票质押余额
		  ,FNL_STK_PLG_AMT                   --期末股票质押余额         
		  ,STK_PLG_ADD_INT                   --股票质押新增利息
          ,STK_PLG_ADD_TRD_AMT               --股票质押初始交易量
          ,STRT_MIN_STK_PLG_AMT              --期初小微贷余额
		  ,FNL_MIN_STK_PLG_AMT               --期末小微贷余额
          ,MIN_STK_PLG_ADD_INT               --小微贷新增利息
          ,MIN_STK_PLG_ADD_TRD_AMT           --小微贷初始交易量
          ,STK_NET_S1                        --股票净佣金
          ,BROK_RLN_STK_NET_S1               --经纪关系股票净佣金
          ,STRONG_SVC_STK_NET_S1             --强服务关系股票净佣金
          ,WEAK_SVC_STK_NET_S1               --弱服务关系股票净佣金
          ,FND_NET_S1                        --基金净佣金
          ,BROK_RLN_FND_NET_S1               --经纪关系基金净佣金
          ,STRONG_SVC_FND_NET_S1             --强服务关系基金净佣金
          ,WEAK_SVC_FND_NET_S1               --弱服务关系基金净佣金
          ,H_K_NET_S1                        --港股通净佣金
          ,BROK_RLN_H_K_NET_S1               --经纪关系港股通净佣金
          ,STRONG_SVC_H_K_NET_S1             --强服务关系港股通净佣金
          ,WEAK_SVC_H_K_NET_S1               --弱服务关系港股通净佣金
          ,NEW_T3BOD_NET_S1                  --新三板净佣金
          ,BROK_RLN_NEW_T3BOD_NET_S1         --经纪关系新三板净佣金
          ,STRONG_SVC_NEW_T3BOD_NET_S1       --强服务关系新三板净佣金
          ,WEAK_SVC_NEW_T3BOD_NET_S1         --弱服务关系新三板净佣金
          ,STRT_CPTL_BAL                     --期初资金余额
          ,STRT_A_STK_MKTVAL                 --期初A股票市值
          ,STRT_B_STK_MKTVAL                 --期初B股票市值
          ,STRT_H_K_STK_MKTVAL               --期初港股股票市值
		  ,FNL_CPTL_BAL                      --期末资金余额
          ,FNL_A_STK_MKTVAL                   --期末A股票市值
          ,FNL_B_STK_MKTVAL                   --期末B股票市值
          ,FNL_H_K_STK_MKTVAL                 --期末港股股票市值
          ,TRD_VOL                            --交易量
          ,NET_S1_INCM                        --净佣金收入
          ,INT_INCM                           --息费收入
          ,A_STK_NET_S1                       --A股净佣金
          ,A_STK_TRD_VOL                      --A股交易量
          ,STRT_MRGNC_CPTL_BAL                --期初融资余额
          ,STRT_MRGNS_CPTL_BAL                --期初融券余额
		  ,FNL_MRGNC_CPTL_BAL                 --期末融资余额
          ,FNL_MRGNS_CPTL_BAL                 --期末融券余额
		  ,ORDI_ACCNT_CORE_WAG_CUST_VOL       --普通账户申报_核心通道客户客户数
          ,ORDI_ACCNT_VIP_WAG_CUST_VOL        --普通账户申报_VIP通道客户客户数
          ,ORDI_ACCNT_ORDI_WAG_CUST_VOL       --普通账户申报_普通通道客户客户数
          ,CRD_ACCNT_ORDI_WAG_CUST_VOL        --信用账户申报_普通通道客户客户数
          ,ORDI_ACCNT_CORE_WAG_TRD_VOL        --普通账户申报_核心通道交易量
          ,ORDI_ACCNT_VIP_WAG_TRD_VOL         --普通账户申报_VIP通道交易量
          ,ORDI_ACCNT_ORDI_WAG_TRD_VOL        --普通账户申报_普通通道交易量
          ,CRD_ACCNT_ORDI_WAG_TRD_VOL         --信用账户申报_普通通道交易量
		  ,FNL_OLD_INR_PB_CUST_VOL             --期末存量内部PB账户数
          ,FNL_ADDED_INR_PB_CUST_VOL           --期末增量内部PB账户数
          ,TISSU_GT_OPNAC_INR_PB_CUST_VOL      --当年新开内部PB账户数
		  ,TISSU_GT_OPNAC_EXTN_PB_CUST_VOL     --当年新开外部PB账户数
		  ,FNL_OLD_INR_PB_FNL_AST              --期末存量内部PB期末资产
		  ,FNL_ADDED_INR_PB_FNL_AST            --期末增量内部PB期末资产
		  ,EXTN_PB_FNL_AST                     --外部PB期末资产
		  ,TISSU_GT_OLD_INR_PB_TRD_VOL         --当年存量内部PB交易量
		  ,TISSU_GT_ADDED_INR_PB_TRD_VOL       --当年增量内部PB交易量
		  ,TISSU_GT_EXTN_PB_TRD_VOL            --当年外部PB交易量
		  ,TISSU_GT_OLD_INR_PB_NET_S1          --当年存量内部PB净佣金
		  ,TISSU_GT_ADDED_INR_PB_NET_S1        --当年增量内部PB净佣金
		  ,TISSU_GT_EXTN_PB_NET_S1             --当年外部PB净佣金
		  ,TISSU_GT_OLD_INR_PB_INT_INCM        --当年存量内部PB息差收入
		  ,TISSU_GT_ADDED_INR_PB_INT_INCM      --当年增量内部PB息差收入
		  ,TISSU_GT_EXTN_PB_INT_INCM           --当年外部PB息差收入
		  ,STRT_UN_TRD_NET_AST                 --期初非交易净资产
		  ,FNL_UN_TRD_NET_AST                 --期末非交易净资产
		  ,ETL_DT                                    
 ) PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT    t.BELTO_FILIL_CDG               --分公司编码
          ,t.BELTO_FILIL                    --分公司名称
          ,t.BRH_NO                         --营业部编码
          ,t.BRH_FULLNM                     --营业部名称
          ,a1.CUST_STAR                      --客户星级
          ,NVL(a2.STRT_CUST_VOL,0)                     --期初客户数
		  ,NVL(a2.STRT_QLFD_CUST_VOL,0)                --期初合格客户数
		  ,NVL(a2.STRT_BROK_RLN_QLFD_CUST_VOL,0)       --期初经纪关系合格客户数
          ,NVL(a2.STRT_STRONG_SVC_RLN_QLFD_CUST_VOL,0) --期初强服务关系合格客户数
          ,NVL(a2.STRT_WEAK_SVC_RLN_QLFD_CUST_VOL,0)   --期初弱服务关系合格客户数
		  ,NVL(a2.STRT_BROK_RLN_CUST_VOL,0)            --期初经纪关系客户数
		  ,NVL(a2.STRT_STRONG_SVC_RLN_CUST_VOL,0)      --期初强服务关系客户数
		  ,NVL(a2.STRT_WEAK_SVC_RLN_CUST_VOL,0)        --期初弱服务关系客户数
		  ,NVL(a2.STRT_CRD_CUST_VOL,0)                 --期初信用客户数
		  ,NVL(a2.STRT_H_K_CUST_VOL,0)                 --期初港股通客户数
          ,NVL(a2.STRT_WRNT_CUST_VOL,0)                --期初期权客户数
		  ,NVL(a2.STRT_STIB_CUST_VOL,0)                --期初科创板客户数
		  ,NVL(a2.STRT_NEW_T3BOD_CUST_VOL,0)           --期初新三板客户数(受限制+非受限制) 
		  ,NVL(a2.STRT_T3BOD_CUST_VOL,0)               --期初三板客户数 
		  ,NVL(a2.STRT_PLG_REPO_CUST_VOL,0)            --期初质押回购客户数(股票质押)
          ,NVL(a2.STRT_STK_PLG_CUST_VOL,0)             --期初股票质押客户数(小微贷)
          ,NVL(a2.STRT_STR_FND_CUST_VOL,0)             --期初分级基金客户数
          ,NVL(a2.STRT_PROD_CUST_VOL,0)                --期初产品客户数
          ,NVL(a2.STRT_INR_PB_CUST_VOL,0)              --期初内部PB账户数
          ,NVL(a2.STRT_EXTN_PB_CUST_VOL,0)             --期初外部PB账户数
          ,NVL(a2.STRT_CASH_PROD_CUST_VOL,0)           --期初现金添利客户数
          ,NVL(a3.FNL_CUST_VOL,0)                       --期末客户数
		  ,NVL(a3.FNL_QLFD_CUST_VOL,0)                  --期末合格客户数
		  ,NVL(a3.FNL_BROK_RLN_QLFD_CUST_VOL,0)         --期末经纪关系合格客户数
          ,NVL(a3.FNL_STRONG_SVC_RLN_QLFD_CUST_VOL,0)   --期末强服务关系合格客户数
          ,NVL(a3.FNL_WEAK_SVC_RLN_QLFD_CUST_VOL,0)     --期末弱服务关系合格客户数
		  ,NVL(a3.FNL_BROK_RLN_CUST_VOL,0)              --期末经纪关系客户数
		  ,NVL(a3.FNL_STRONG_SVC_RLN_CUST_VOL,0)        --期末强服务关系客户数
		  ,NVL(a3.FNL_WEAK_SVC_RLN_CUST_VOL,0)          --期末弱服务关系客户数
		  ,NVL(a3.FNL_CRD_CUST_VOL,0)                   --期末信用客户数
		  ,NVL(a3.FNL_H_K_CUST_VOL,0)                   --期末港股通客户数
          ,NVL(a3.FNL_WRNT_CUST_VOL,0)                  --期末期权客户数
		  ,NVL(a3.FNL_STIB_CUST_VOL,0)                  --期末科创板客户数
		  ,NVL(a3.FNL_NEW_T3BOD_CUST_VOL,0)             --期末新三板客户数(受限制+非受限制) 
		  ,NVL(a3.FNL_T3BOD_CUST_VOL,0)                 --期末三板客户数 
		  ,NVL(a3.FNL_PLG_REPO_CUST_VOL,0)              --期末质押回购客户数(股票质押)
          ,NVL(a3.FNL_STK_PLG_CUST_VOL,0)               --期末股票质押客户数(小微贷)
          ,NVL(a3.FNL_STR_FND_CUST_VOL,0)               --期末分级基金客户数
          ,NVL(a3.FNL_PROD_CUST_VOL,0)                  --期末产品客户数
          ,NVL(a3.FNL_INR_PB_CUST_VOL,0)                --期末内部PB账户数
          ,NVL(a3.FNL_EXTN_PB_CUST_VOL,0)               --期末外部PB账户数
          ,NVL(a3.FNL_CASH_PROD_CUST_VOL,0)             --期末现金添利客户数 			
		  ,NVL(a4.TRD_CUST_VOL,0)                      --交易客户客户数
          ,NVL(a4.ADDED_VLD_CUST_VOL,0)                --新增有效客户数
          ,NVL(a4.ADDED_OLD_VLD_CUST_VOL,0)            --新增存量有效客户数
          ,NVL(a4.TRD_CRD_CUST_VOL,0)                  --交易信用客户数
          ,NVL(a4.TRD_H_K_CUST_VOL,0)                  --交易港股通客户数
          ,NVL(a4.TRD_WRNT_CUST_VOL,0)                 --交易期权客户数          
          ,NVL(a4.TRD_NWE_T3BOD_CUST_VOL,0)           --交易新三板客户数
		  ,NVL(a4.TRD_STIB_CUST_VOL,0)                --交易科创板客户数
		  ,NVL(a5.TRD_PLG_REPO_CUST_VOL,0)             --交易质押回购客户数(股票质押)
          ,NVL(a5.TRD_STK_PLG_CUST_VOL,0)              --交易股票质押客户数(小微贷)
		  ,NVL(a6.TISSU_GT_TRD_CUST_VOL,0)             --本期累计交易客户客户数
          ,NVL(a6.TISSU_GT_TRD_CRD_CUST_VOL,0)         --本期累计交易信用客户数
          ,NVL(a6.TISSU_GT_TRD_H_K_CUST_VOL,0)         --本期累计交易港股通客户数
          ,NVL(a6.TISSU_GT_TRD_WRNT_CUST_VOL,0)        --本期累计交易期权客户数
          ,NVL(a6.TISSU_GT_TRD_NWE_T3BOD_CUST_VOL,0)   --本期累计交易新三板客户数
		  ,NVL(a6.TISSU_GT_TRD_STIB_CUST_VOL,0)        --本期累计交易科创板客户数
          ,NVL(a6.TISSU_GT_NEW_OPNAC_NET_TOT_AST,0)    --本期累计新开户净资产
          ,NVL(a6.TISSU_GT_ADDED_VLD_NET_TOT_AST,0)    --本期累计新增有效户净资产
          ,NVL(a6.TISSU_GT_ADDED_OLD_VLD_NET_TOT_AST,0) --本期累计存量有效户净资产
		  ,NVL(a5.PLG_REPO_FNL_AMT_CUST_VOL,0)         --期末有股票质押余额客户数(股票质押)
          ,NVL(a5.STK_PLG_FNL_AMT_CUST_VOL,0)          --期末有小微贷余额客户数(小微贷)
          ,NVL(a4.OPNAC_CUST_VOL,0)                    --开户数(当月)
          ,NVL(a4.OPNAC_CRD_CUST_VOL,0)                --开户信用客户数(当月)
          ,NVL(a4.OPNAC_WRNT_CUST_VOL,0)               --开户期权客户数(当月)
          ,NVL(a4.OPN_STIB_CUST_VOL,0)                 --开通科创板客户数(当月)
          ,NVL(a4.OPN_H_K_CUST_VOL,0)                  --开通港股通客户数(当日)			  
          ,NVL(a4.OPN_PLG_REPO_CUST_VOL,0)             --开通质押回购客户数(股票质押)(当月)
          ,NVL(a4.OPN_STK_PLG_CUST_VOL,0)              --开通股票质押客户数(小微贷)(当月)
          ,NVL(a4.OPN_STR_FND_CUST_VOL,0)              --开通分级基金客户数
          ,NVL(a4.OPN_NEW_T3BOD_CUST_VOL,0)            --开通新三板客户数(受限制当日+非受限制当日)
          ,NVL(a4.OPN_T3BOD_CUST_VOL,0)                --开通三板客户数(当月)
          ,NVL(a4.CNCLACT_CUST_VOL,0)                  --销户数(当月)
          ,NVL(a4.CNCLACT_CRD_CUST_VOL,0)              --销户信用客户数(当月)
          ,NVL(a4.CNCLACT_WRNT_CUST_VOL,0)             --销户期权客户数(当月)
          ,NVL(a4.CLS_STIB_CUST_VOL,0)                 --关闭科创板客户数(当月)
          ,NVL(a4.CLS_H_K_CUST_VOL,0)                  --关闭港股通客户数(当月)
          ,NVL(a4.CLS_PLG_REPO_CUST_VOL,0)             --关闭质押回购客户数(股票质押)(当月)
          ,NVL(a4.CLS_STK_PLG_CUST_VOL,0)              --关闭股票质押客户数(小微贷)(当月)
          ,NVL(a4.CLS_STR_FND_CUST_VOL,0)              --关闭分级基金客户数
          ,NVL(a4.CLS_NEW_T3BOD_CUST_VOL,0)            --关闭新三板客户数(受限制当日+非受限制当日)
          ,NVL(a4.CLS_T3BOD_CUST_VOL,0)                --关闭三板客户数(当月)	  
		  ,NVL(a2.STRT_CUST_TOT_AST,0)                 --期初客户总资产
          ,NVL(a2.STRT_CUST_NET_TOT_AST,0)             --期初客户净资产
          ,NVL(a2.STRT_BROK_RLN_CUST_NET_TOT_AST,0)    --期初经纪关系净资产
          ,NVL(a2.STRT_STRONG_SVC_CUST_NET_TOT_AST,0)  --期初强服务关系净资产
          ,NVL(a2.STRT_WEAK_SVC_CUST_NET_TOT_AST,0)    --期初弱服务关系净资产
		  ,NVL(a3.FNL_CUST_TOT_AST,0)                  --期末客户总资产
          ,NVL(a3.FNL_CUST_NET_TOT_AST,0)              --期末客户净资产
          ,NVL(a3.FNL_BROK_RLN_CUST_NET_TOT_AST,0)     --期末经纪关系净资产
          ,NVL(a3.FNL_STRONG_SVC_CUST_NET_TOT_AST,0)   --期末强服务关系净资产
          ,NVL(a3.FNL_WEAK_SVC_CUST_NET_TOT_AST,0)     --期末弱服务关系净资产
          ,NVL(a4.NEW_OPNAC_NET_TOT_AST,0)             --新开户期末净资产
          ,NVL(a4.ADDED_VLD_NET_TOT_AST,0)             --新增有效户期末净资产
          ,NVL(a4.ADDED_OLD_VLD_NET_TOT_AST,0)         --存量有效户期末净资产
          ,NVL(a5.NET_TFR_IN_AST,0)                    --资产净流入
          ,NVL(a5.STK_TRD_VOL,0)                       --股票交易量
          ,NVL(a5.BROK_RLN_STK_TRD_VOL,0)              --经纪关系股票交易量
          ,NVL(a5.STRONG_SVC_STK_TRD_VOL,0)            --强服务关系股票交易量
          ,NVL(a5.WEAK_SVC_STK_TRD_VOL,0)              --弱服务关系股票交易量
          ,NVL(a5.FND_TRD_VOL,0)                       --基金交易量
          ,NVL(a5.BROK_RLN_FND_TRD_VOL,0)              --经纪关系基金交易量
          ,NVL(a5.STRONG_SVC_FND_TRD_VOL,0)            --强服务关系基金交易量
          ,NVL(a5.WEAK_SVC_FND_TRD_VOL,0)              --弱服务关系基金交易量
          ,NVL(a5.H_K_TRD_VOL,0)                       --港股通交易量
          ,NVL(a5.BROK_RLN_H_K_TRD_VOL,0)              --经纪关系港股通交易量
          ,NVL(a5.STRONG_SVC_H_K_TRD_VOL,0)            --强服务关系港股通交易量
          ,NVL(a5.WEAK_SVC_H_K_TRD_VOL,0)              --弱服务关系港股通交易量
          ,NVL(a5.NEW_T3BOD_TRD_VOL,0)                 --新三板交易量
          ,NVL(a5.BROK_RLN_NEW_T3BOD_TRD_VOL,0)        --经纪关系新三板交易量
          ,NVL(a5.STRONG_SVC_NEW_T3BOD_TRD_VOL,0)      --强服务关系新三板交易量
          ,NVL(a5.WEAK_SVC_NEW_T3BOD_TRD_VOL,0)        --弱服务关系新三板交易量
          ,NVL(a5.CRD_TRD_VOL,0)                       --融资融券交易量
		  ,NVL(a5.BROK_RLN_CRD_TRD_VOL,0)              --经纪关系融资融券交易量
          ,NVL(a5.STRONG_SVC_RLN_CRD_TRD_VOL,0)        --强服务关系融资融券交易量
          ,NVL(a5.WEAK_SVC_RLN_CRD_TRD_VOL,0)          --弱服务关系融资融券交易量
          ,NVL(a5.TYM_ADDED_MRGNC_INT,0)                --当日新增融资利息
          ,NVL(a5.TYM_ADDED_MRGNS_INT,0)                --当日新增融券利息
          ,NVL(a2.STRT_STK_PLG_AMT,0)                  --期初股票质押余额
		  ,NVL(a3.FNL_STK_PLG_AMT,0)                    --期末股票质押余额         
		  ,NVL(a5.STK_PLG_ADD_INT,0)                   --股票质押新增利息
          ,NVL(a5.STK_PLG_ADD_TRD_AMT,0)               --股票质押初始交易量
          ,NVL(a2.STRT_MIN_STK_PLG_AMT,0)              --期初小微贷余额
		  ,NVL(a3.FNL_MIN_STK_PLG_AMT,0)                --期末小微贷余额
          ,NVL(a5.MIN_STK_PLG_ADD_INT,0)               --小微贷新增利息
          ,NVL(a5.MIN_STK_PLG_ADD_TRD_AMT,0)           --小微贷初始交易量
          ,NVL(a5.STK_NET_S1,0)                        --股票净佣金
          ,NVL(a5.BROK_RLN_STK_NET_S1,0)               --经纪关系股票净佣金
          ,NVL(a5.STRONG_SVC_STK_NET_S1,0)             --强服务关系股票净佣金
          ,NVL(a5.WEAK_SVC_STK_NET_S1,0)               --弱服务关系股票净佣金
          ,NVL(a5.FND_NET_S1,0)                        --基金净佣金
          ,NVL(a5.BROK_RLN_FND_NET_S1,0)               --经纪关系基金净佣金
          ,NVL(a5.STRONG_SVC_FND_NET_S1,0)             --强服务关系基金净佣金
          ,NVL(a5.WEAK_SVC_FND_NET_S1,0)               --弱服务关系基金净佣金
          ,NVL(a5.H_K_NET_S1,0)                        --港股通净佣金
          ,NVL(a5.BROK_RLN_H_K_NET_S1,0)               --经纪关系港股通净佣金
          ,NVL(a5.STRONG_SVC_H_K_NET_S1,0)             --强服务关系港股通净佣金
          ,NVL(a5.WEAK_SVC_H_K_NET_S1,0)               --弱服务关系港股通净佣金
          ,NVL(a5.NEW_T3BOD_NET_S1,0)                  --新三板净佣金
          ,NVL(a5.BROK_RLN_NEW_T3BOD_NET_S1,0)         --经纪关系新三板净佣金
          ,NVL(a5.STRONG_SVC_NEW_T3BOD_NET_S1,0)       --强服务关系新三板净佣金
          ,NVL(a5.WEAK_SVC_NEW_T3BOD_NET_S1,0)         --弱服务关系新三板净佣金
          ,NVL(a2.STRT_CPTL_BAL,0)                     --期初资金余额
          ,NVL(a2.STRT_A_STK_MKTVAL,0)                 --期初A股票市值
          ,NVL(a2.STRT_B_STK_MKTVAL,0)                 --期初B股票市值
          ,NVL(a2.STRT_H_K_STK_MKTVAL,0)               --期初港股股票市值
		  ,NVL(a3.FNL_CPTL_BAL,0)                       --期末资金余额
          ,NVL(a3.FNL_A_STK_MKTVAL,0)                   --期末A股票市值
          ,NVL(a3.FNL_B_STK_MKTVAL,0)                   --期末B股票市值
          ,NVL(a3.FNL_H_K_STK_MKTVAL,0)                 --期末港股股票市值
          ,NVL(a5.TRD_VOL,0)                            --交易量
          ,NVL(a5.NET_S1_INCM,0)                        --净佣金收入
          ,NVL(a5.INT_INCM,0)                           --息费收入
          ,NVL(a5.A_STK_NET_S1,0)                       --A股净佣金
          ,NVL(a5.A_STK_TRD_VOL,0)                      --A股交易量
          ,NVL(a2.STRT_MRGNC_CPTL_BAL,0)                --期初融资余额
          ,NVL(a2.STRT_MRGNS_CPTL_BAL,0)                --期初融券余额
		  ,NVL(a3.FNL_MRGNC_CPTL_BAL,0)                 --期末融资余额
          ,NVL(a3.FNL_MRGNS_CPTL_BAL,0)                 --期末融券余额
		  ,NVL(a4.ORDI_ACCNT_CORE_WAG_CUST_VOL,0)       --普通账户申报_核心通道客户客户数
          ,NVL(a4.ORDI_ACCNT_VIP_WAG_CUST_VOL,0)        --普通账户申报_VIP通道客户客户数
          ,NVL(a4.ORDI_ACCNT_ORDI_WAG_CUST_VOL,0)       --普通账户申报_普通通道客户客户数
          ,NVL(a4.CRD_ACCNT_ORDI_WAG_CUST_VOL,0)        --信用账户申报_普通通道客户客户数
          ,NVL(a4.ORDI_ACCNT_CORE_WAG_TRD_VOL,0)        --普通账户申报_核心通道交易量
          ,NVL(a4.ORDI_ACCNT_VIP_WAG_TRD_VOL,0)         --普通账户申报_VIP通道交易量
          ,NVL(a4.ORDI_ACCNT_ORDI_WAG_TRD_VOL,0)        --普通账户申报_普通通道交易量
          ,NVL(a4.CRD_ACCNT_ORDI_WAG_TRD_VOL,0)         --信用账户申报_普通通道交易量
		  ,NVL(a4.FNL_OLD_INR_PB_CUST_VOL,0)             --期末存量内部PB账户数
          ,NVL(a4.FNL_ADDED_INR_PB_CUST_VOL ,0)          --期末增量内部PB账户数
          ,NVL(a4.TISSU_GT_OPNAC_INR_PB_CUST_VOL,0)      --当年新开内部PB账户数
		  ,0 as TISSU_GT_OPNAC_EXTN_PB_CUST_VOL     --当年新开外部PB账户数
		  ,NVL(a4.FNL_OLD_INR_PB_FNL_AST,0)              --期末存量内部PB期末资产
		  ,NVL(a4.FNL_ADDED_INR_PB_FNL_AST,0)            --期末增量内部PB期末资产
		  ,0 as EXTN_PB_FNL_AST                     --外部PB期末资产
		  ,NVL(a6.TISSU_GT_OLD_INR_PB_TRD_VOL,0)         --当年存量内部PB交易量
		  ,NVL(a6.TISSU_GT_ADDED_INR_PB_TRD_VOL,0)        --当年增量内部PB交易量
		  ,0 as TISSU_GT_EXTN_PB_TRD_VOL           --当年外部PB交易量
		  ,NVL(a6.TISSU_GT_OLD_INR_PB_NET_S1,0)           --当年存量内部PB净佣金
		  ,NVL(a6.TISSU_GT_ADDED_INR_PB_NET_S1,0)         --当年增量内部PB净佣金
		  ,0 as TISSU_GT_EXTN_PB_NET_S1             --当年外部PB净佣金
		  ,NVL(a6.TISSU_GT_OLD_INR_PB_INT_INCM,0)         --当年存量内部PB息差收入
		  ,NVL(a6.TISSU_GT_ADDED_INR_PB_INT_INCM,0)       --当年增量内部PB息差收入
		  ,0 as TISSU_GT_EXTN_PB_INT_INCM           --当年外部PB息差收入
		  ,NVL(a2.STRT_UN_TRD_NET_AST,0)                  --期初非交易净资产
		  ,NVL(a3.FNL_UN_TRD_NET_AST,0)                  --期末非交易净资产
		  ,%d{yyyyMMdd} as ETL_DT                                   
 FROM 	(SELECT 1 as ID,* 
         FROM DDW_PROD.T_DDW_INR_ORG_BRH
		 WHERE BUS_DATE = %d{yyyyMMdd}
		 )t
 LEFT JOIN  (SELECT 1 as ID, BIZ_DESC as CUST_STAR 
        FROM DDW_PROD.T_DDW_LM_LABEL_DM 
         WHERE LABEL_ID = '8d0fe69b4ff546f082775761d27c70a5'
		 )    a1
 ON  t.ID = a1.ID
LEFT JOIN DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP a2
ON  t.BRH_NO = a2.BRH_NO
AND a1.CUST_STAR = a2.CUST_STAR
LEFT JOIN DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP1 a3
ON  t.BRH_NO = a3.BRH_NO
AND a1.CUST_STAR = a3.CUST_STAR
LEFT JOIN DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP3 a4
ON  t.BRH_NO = a4.BRH_NO
AND a1.CUST_STAR = a4.CUST_STAR
LEFT JOIN DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP5 a5
ON  t.BRH_NO = a5.BRH_NO
AND a1.CUST_STAR = a5.CUST_STAR
LEFT JOIN DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP7 a6
ON  t.BRH_NO = a6.BRH_NO
AND a1.CUST_STAR = a6.CUST_STAR
 ;
 --

------删除临时表
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP1 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP2 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP3 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP4 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP5 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP6 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP7 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON_TEMP8 ;

  

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_STAR_BRH_CUST_IDX_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON;
		   



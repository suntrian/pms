------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:联系人信息表                                                                       */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 


--------------插入数据-------------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_CTCT_PSN_INFO
(
                                     CTCT_PSN_ID                  --联系人主键    
                                    ,CUST_NO                      --客户号      
                                    ,CTCT_PSN_NAME                --联系人名称  
                                    ,CTF_CGY_CD                   --证件类别代码	
                                    ,CTF_NO                       --证件编号    	
                                    ,CTF_STRT_DT                  --证件起始日期	
                                    ,CTF_EXPR_DT                  --证件截止日期	
                                    ,CTCT_ADDR                    --联系地址    	
                                    ,PST_NO                       --邮政编码    	
                                    ,CTCT_TEL                     --联系电话    	
                                    ,PHONE                        --手机        	
                                    ,EMAIL                        --EMAIL       
                                    ,RLN_EXPLN                    --关系说明    
                                    ,REGST_DT                     --登记日期    
                                    ,CHG_DT                       --变动日期
                                    ,CTCT_FLG	                  --联系人标志								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT        t.LXRID                    as CTCT_PSN_ID                  --联系人主键                                  
               ,t.KHH                     as CUST_NO                      --客户号      
               ,t.LXRMC                   as CTCT_PSN_NAME                --联系人名称  
               ,t.ZJLBDM                  as CTF_CGY_CD                   --证件类别代码							  
               ,t.ZJBH                    as CTF_NO                       --证件编号    							  
               ,t.ZJQSRQ                  as CTF_STRT_DT                  --证件起始日期							  
               ,t.ZJJZRQ                  as CTF_EXPR_DT                  --证件截止日期							  
               ,t.LXDZ                    as CTCT_ADDR                    --联系地址    							  
               ,t.YZBM                    as PST_NO                       --邮政编码    							  
               ,t.LXDH                    as CTCT_TEL                     --联系电话    							  
               ,t.MOBILE                  as PHONE                        --手机        							  
               ,t.EMAIL                   as EMAIL                        --EMAIL       
               ,t.GXSM                    as RLN_EXPLN                    --关系说明    
               ,t.DJRQ                    as REGST_DT                     --登记日期    
               ,t.BDRQ                    as CHG_DT                       --变动日期
               ,DECODE(t.NUM,1,'主','辅') as CTCT_FLG	                  --联系人标志			   
 FROM       ( SELECT   t.*
                       ,ROW_NUMBER() OVER(ORDER BY LXRID DESC ) as NUM    
              FROM     EDW_PROD.T_EDW_T01_TLXR t
              WHERE    t.BUS_DATE = %d{yyyyMMdd} 
			 )                              t       
;
		
---------------- 插入数据结束 -----------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_CTCT_PSN_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_CTCT_PSN_INFO ;




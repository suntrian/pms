------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户股票交易统计表                                                                   */
------/* 创建人:常静静                                                                                 */
------/* 创建时间:2018-11-26                                                                           */

--删除今天的数据--
 ALTER TABLE DDW_PROD.T_DDW_LM_CUST_PREFR_STATS DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd});

insert OVERWRITE DDW_PROD.T_DDW_LM_CUST_STK_TRD_STATS
(
 CUST_NO			--1. 客户号
,ACCT_CGY        	--2. 账户类别
,SEC_CD             --3. 证券代码
,BS_DRCT            --4. 交易方向
,TRD_AMT            --5. 交易金额
,TRD_QTY            --6. 交易数量
)
 partition(BUS_DATE = %d{yyyyMMdd})
  SELECT
         T1.CUST_NO
        ,case when T1.SYS_SRC = '普通账户' then '1' when T1.SYS_SRC = '信用账户' then '2' end as ACCT_CGY
        ,T1.SEC_CD
		,cast(T2.BS_DRCT as int)
        ,sum(T1.MTCH_AMT * NVL(T3.ZHHL,1)) AS MTCH_AMT_RMB
		,sum(T1.MTCH_QTY) as TRD_QTY
  FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS T1
  INNER JOIN DDW_PROD.T_DDW_CFG_SEC_TRD_CL T2
   ON T1.EXG = T2.EXG AND SUBSTR(T1.SEC_CD,1,3) = T2.SEC_CD_PFX
  AND (SUBSTR(T1.SEC_CGY,1,1) = T2.SEC_CGY_PFX OR SUBSTR(T1.SEC_CGY,1,3) = T2.SEC_CGY_PFX)
  AND T1.ODR_CGY = T2.TRD_CGY
  AND T2.SEC_CL_CD IN ('001','002','003','004','005','006','007','008','015','016','063')
  LEFT JOIN EDW_PROD.T_EDW_T99_HLZH T3
   ON T1.CCY_CD = T3.BZDM
  AND T1.BUS_DATE = T3.BUS_DATE
  WHERE T1.BUS_DATE = %d{yyyyMMdd}
  group by T1.CUST_NO,T1.SYS_SRC,T1.SEC_CD,T2.BS_DRCT
;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_LM_CUST_STK_TRD_STATS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
invalidate metadata DDW_PROD.T_DDW_LM_CUST_STK_TRD_STATS;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:三板确权委托历史表                                                                       */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  


-------------删除临时表-------------------
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_TRD_T3BOD_RIGHT_ODR_DEL_HIS_TEMP ;
  CREATE  TABLE DDW_PROD.T_DDW_F00_TRD_T3BOD_RIGHT_ODR_DEL_HIS_TEMP 
  as SELECT      t1.KHH
                ,t1.RQ
				, 1  as BZ 
     FROM ( SELECT    t.KHH
	                 ,t.RQ
            FROM  ( SELECT    KHH
			                  ,RQ
                    FROM    EDW_PROD.T_EDW_T05_TYGTXTCZMX
                    WHERE   YWKM = '20090' 
					OR      ZY LIKE '%二代证验证%'
                    UNION ALL
                    SELECT     a.KHH
					          ,b.SQRQ as RQ
                    FROM       (SELECT YYB
					                  ,ZJBH
									  ,KHH
								FROM  EDW_PROD.T_EDW_T01_TKHXX 
								WHERE BUS_DATE = %d{yyyyMMdd}
								)     a
                   INNER JOIN (SELECT  ZJBH
				                       ,YYB
									   ,SQRQ
							   FROM  EDW_PROD.T_EDW_T02_TGMSFCXSQ 
							   WHERE CLJG = 1
							   )                b
                  ON           a.yyb = b.yyb
                  AND          a.zjbh = b.zjbh
                 ) t
           GROUP BY t.khh,t.rq
          )       t1
	  ; 

--------------插入ABOSS,RZRQ数据-------------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_TRD_T3BOD_RIGHT_ODR_DEL_HIS
(
                                     EVNT_SEQNBR                         --事件序号               
                                    ,BRH_NO                              --营业部编号              
                                    ,BRH_NAME                            --营业部名称              
                                    ,ODR_SEQNBR                          --委托序号               
                                    ,HOST_SECCO                          --主办券商               
                                    ,AGENCY_SECCO                        --代办券商               
                                    ,SEAT_CD                             --席位代码               
                                    ,SEC_CD                              --证券代码               
                                    ,M_BOD_SHRHLD_CD                     --主板股东代码             
                                    ,T3BOD_SHRHLD_CD                     --三板股东代码             
                                    ,SHRNUM                              --股数                 
                                    ,CTF_NO                              --证件号码               
                                    ,SHRHLD_NAME                         --股东姓名               
                                    ,COMM_ADDR                           --通讯地址               
                                    ,TEL_NO                              --电话号码               
                                    ,ODR_DT                              --委托日期               
                                    ,ODR_TM                              --委托时间               
                                    ,BIZ_CGY                             --业务类别               
                                    ,OPRT_TELR                           --操作柜员               
                                    ,CHRG_ACTNO                          --收费账号               
                                    ,T3BOD_ODR_DEAL_FLG                  --三板委托处理标志                      
                                    ,RIGHT_RSLT                          --确权结果                                      
                                    ,SECOND_CARD_VRFCTN                  --二代证验证 
                                  --  ,transmit_dt                         --加载日期									
) 
 partition(bus_date )
 SELECT 
                                    t.SEQNO                                as EVNT_SEQNBR                         --事件序号                                                              
                                   ,t.FSYYB                                as BRH_NO                              --营业部编号                                                             
                                   ,a1.BRH_SHRTNM                          as BRH_NAME                            --营业部名称                                                             
                                   ,t.WTXH                                 as ODR_SEQNBR                          --委托序号                                                                                                   
                                   ,t.ZBQS                                 as HOST_SECCO                          --主办券商                                                              
                                   ,t.DBQS                                 as AGENCY_SECCO                        --代办券商                                                              
                                   ,t.XWDM                                 as SEAT_CD                             --席位代码                                                              
                                   ,t.ZQDM                                 as SEC_CD                              --证券代码                                                              
                                   ,t.ZBGDDM                               as M_BOD_SHRHLD_CD                     --主板股东代码                                                            
                                   ,t.SBGDDM                               as T3BOD_SHRHLD_CD                     --三板股东代码                                                            
                                   ,t.DJGS                                 as SHRNUM                              --股数                                                                
                                   ,t.ZJHM                                 as CTF_NO                              --证件号码                                                              
                                   ,t.GDXM                                 as SHRHLD_NAME                         --股东姓名                                                              
                                   ,t.TXDZ                                 as COMM_ADDR                           --通讯地址                                                              
                                   ,t.DHHM                                 as TEL_NO                              --电话号码                                                              
                                   ,t.WTRQ                                 as ODR_DT                              --委托日期                                                              
                                   ,t.WTSJ                                 as ODR_TM                              --委托时间                                                                                                                                       
                                   ,t.SBQQ_YWLB                            as BIZ_CGY                             --业务类别                                                              
                                   ,a4.XM                                  as OPRT_TELR                           --操作柜员                                                                                        
                                   ,t.SFZH                                 as CHRG_ACTNO                          --收费账号                                                                                               
                                   ,t.SBQQ_CLBZ                            as T3BOD_ODR_DEAL_FLG                  --三板委托处理标志                                                                                                                      
                                   ,t.QQJGSM                               as RIGHT_RSLT                          --确权结果               
                                   ,CASE WHEN a2.BZ = 1 
                                         THEN '已验证'	
 										 ELSE '未验证'
										 END                               as SECOND_CARD_VRFCTN                  --二代证验证										 									 
                                 --   ,t.transmit_dt                         as transmit_dt                   --加载日期
									,t.BUS_DATE                            as BUS_DATE
                                   
                                                                                                                                                                              
  FROM          EDW_PROD.T_EDW_T05_TSBQQWTLS               t
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH               a1
  ON            t.FSYYB = a1.BRH_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd} 
  LEFT JOIN     DDW_PROD.T_DDW_F00_TRD_T3BOD_RIGHT_ODR_DEL_HIS_TEMP                      a2
  ON            SUBSTR(t.SFZH,1,12) = a2.KHH
  AND           t.WTRQ = a2.RQ
  LEFT JOIN     (SELECT XM,LOGINID,BUS_DATE FROM EDW_PROD.T_EDW_T01_TGYXX WHERE XTBS = 'JZJY')                     a4
  ON            t.CZGY = a4.LOGINID
  AND            a4.bus_date = %d{yyyyMMdd}
 -- WHERE         t.transmit_dt = '%d{yyyyMMdd}'      
 ;

--------------------结束插入------------------------------
-------------删除临时表-------------------
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_TRD_T3BOD_RIGHT_ODR_DEL_HIS_TEMP;
------------删除临时表结束-----------------

----------------------插入数据结束------------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_TRD_T3BOD_RIGHT_ODR_DEL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_F00_TRD_T3BOD_RIGHT_ODR_DEL_HIS ;
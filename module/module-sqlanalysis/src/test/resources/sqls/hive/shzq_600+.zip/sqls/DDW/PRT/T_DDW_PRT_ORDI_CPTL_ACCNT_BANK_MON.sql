 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:资金账户报表_普通账户_银行月表                                                      */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-11-14                                                                        */ 

------期初创建临时表1  
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP as
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MONKHH,YHDM,BZ,ZJZH
 FROM    JZJYCX.ACCOUNT_TCGZHDY    a
 WHERE  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                             FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                 WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                 AND BUS_DATE = %d{yyyyMMdd}
				            )  c
                     WHERE  CAST(a.DT as INT) = c.MON_START
			 )
 UNION 
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MONKHH,YHDM,BZ,ZJZH
 FROM    JZJYCX.ACCOUNT_TYZZZDY    a
 WHERE  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                             FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                 WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                 AND BUS_DATE = %d{yyyyMMdd}
				            )  c
                     WHERE  CAST(a.DT as INT) = c.MON_START
			 )
 
		 ;
--期末创建临时表		 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP1 as
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON,YHDM,BZ,ZJZH
 FROM    JZJYCX.ACCOUNT_TCGZHDY    a
 WHERE   DT = '%d{yyyyMMdd}'
 UNION 
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON,YHDM,BZ,ZJZH
 FROM    JZJYCX.ACCOUNT_TYZZZDY    a
 WHERE   DT = '%d{yyyyMMdd}'
		 ;

----
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP2 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP2 as
 SELECT CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON,YHDM,BZDM,SUM(DECODE(XTYWDM,1,FSJE,0)) as DEPIN_CPTL,SUM(DECODE(XTYWDM,2,0-FSJE,0)) as WTHDR_CPTL
 FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS a
 WHERE SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 AND   XTBS = 'JZJY'
 AND   XTYWDM IN (1,2)
 AND   CLJG = 111
 GROUP BY YHDM,BZDM,YEAR_MON
 UNION ALL
 SELECT CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON,WBJGDM as YHDM,BZDM,SUM(DECODE(XTYWDM,1,JYJE,0)) as DEPIN_CPTL,SUM(DECODE(XTYWDM,2,0-JYJE,0)) as WTHDR_CPTL
 FROM  EDW_PROD.T_EDW_T05_TZJJYSQLS_WB a
 WHERE SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 AND   XTBS = 'JZJY'
 AND   XTYWDM IN (1,2)
 AND   CLJG = 111
 GROUP BY YHDM,BZDM,YEAR_MON
  UNION ALL
 SELECT CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON,WBJGDM as YHDM,BZDM,SUM(DECODE(XTYWDM,1,JYJE,0)) as DEPIN_CPTL,SUM(DECODE(XTYWDM,2,0-JYJE,0)) as WTHDR_CPTL
 FROM  EDW_PROD.T_EDW_T05_TZJJYSQLS_ZQ a
 WHERE SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 AND   XTBS = 'JZJY'
 AND   XTYWDM IN (1,2)
 AND   CLJG = 111
 GROUP BY YHDM,BZDM,YEAR_MON
 ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP3 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP3 as
 SELECT CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON,YHDM,BZ,SUM(NVL(a1.ZHYE,0)) as STRT_CPTL_BAL
 FROM (SELECT YHDM,BZ,ZJZH FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP GROUP BY YHDM,ZJZH,BZ) t
 LEFT JOIN (SELECT * FROM EDW_PROD.T_EDW_T02_TZJZH  a 
            WHERE  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                          FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			              WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			              AND BUS_DATE = %d{yyyyMMdd}
				          )  c
                          WHERE  a.BUS_DATE = c.MON_START
			              )
			AND    a.XTBS = 'JZJY'
			 
			 
			  )      a1
 ON    t.ZJZH = a1.GTZJZH
 GROUP BY YHDM,BZ,YEAR_MON ;

  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP4 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP4 as
 SELECT CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON,YHDM,BZ,SUM(NVL(a1.ZHYE,0)) as FNL_CPTL_BAL
 FROM (SELECT YHDM,BZ,ZJZH FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP1 GROUP BY YHDM,ZJZH,BZ) t
 LEFT JOIN EDW_PROD.T_EDW_T02_TZJZH     a1
 ON    t.ZJZH = a1.GTZJZH
 AND   a1.BUS_DATE = %d{yyyyMMdd}
 GROUP BY YHDM,BZ,YEAR_MON ;
 
 
 INSERT OVERWRITE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON
 (
                                    BANK_CD                   --银行代码
                                   ,CCY                       --币种 
                                   ,STRT_ACCNT_ACTA           --期初账户数
								   ,FNL_ACCNT_ACTA            --期末账户数
								   ,STRT_CPTL_BAL             --期初资金余额
								   ,FNL_CPTL_BAL              --期末资金余额
								   ,DEPIN_CPTL                --资金存
								   ,WTHDR_CPTL                --资金取	                     
) 
PARTITION( YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT 
                                COALESCE(TRIM(t.YHDM),TRIM(a1.YHDM),TRIM(a2.YHDM),TRIM(a3.YHDM),TRIM(a4.YHDM)) as BANK_CD                   --银行代码               
                               ,COALESCE(TRIM(t.BZ),TRIM(a1.BZ),TRIM(a2.BZ),TRIM(a3.BZ),TRIM(a4.BZ)) as CCY                       --币种                
                               ,NVL(t.STRT_ACCNT_ACTA,0) as STRT_ACCNT_ACTA           --期初账户数                                                      
                               ,NVL(a1.FNL_ACCNT_ACTA,0)  as FNL_ACCNT_ACTA            --期末账户数               
                               ,NVL(a3.STRT_CPTL_BAL,0)  as STRT_CPTL_BAL             --期初资金余额              
                               ,NVL(a4.FNL_CPTL_BAL,0)   as FNL_CPTL_BAL              --期末资金余额               
                               ,NVL(a2.DEPIN_CPTL,0)     as DEPIN_CPTL                --资金存                 
                               ,NVL(a2.WTHDR_CPTL,0)     as WTHDR_CPTL                --资金取	                     
FROM (SELECT YHDM,BZ,COUNT(1) as STRT_ACCNT_ACTA FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP GROUP BY YHDM,BZ)   t  
FULL JOIN (SELECT YHDM,BZ,COUNT(1) as FNL_ACCNT_ACTA FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP1 GROUP BY YHDM,BZ)   a1   
ON   TRIM(t.YHDM) = TRIM(a1.YHDM)
AND  TRIM(t.BZ) = TRIM(a1.BZ)
FULL JOIN (SELECT YHDM,BZDM as BZ,SUM(DEPIN_CPTL) as DEPIN_CPTL,SUM(WTHDR_CPTL) as WTHDR_CPTL  FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP2 GROUP BY YHDM,BZ) a2
ON   COALESCE(TRIM(t.YHDM),TRIM(a1.YHDM)) = TRIM(a2.YHDM)   
AND  COALESCE(TRIM(t.BZ),TRIM(a1.BZ)) = TRIM(a2.BZ)   
FULL JOIN (SELECT YHDM,BZ as BZ,SUM(STRT_CPTL_BAL) as STRT_CPTL_BAL FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP3 GROUP BY YHDM,BZ) a3
ON   COALESCE(TRIM(t.YHDM),TRIM(a1.YHDM),TRIM(a2.YHDM)) = TRIM(a3.YHDM)   
AND  COALESCE(TRIM(t.BZ),TRIM(a1.BZ),TRIM(a2.BZ)) = TRIM(a3.BZ)  
FULL JOIN (SELECT YHDM,BZ as BZ,SUM(FNL_CPTL_BAL) as FNL_CPTL_BAL  FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP4 GROUP BY YHDM,BZ) a4
ON   COALESCE(TRIM(t.YHDM),TRIM(a1.YHDM),TRIM(a2.YHDM),TRIM(a3.YHDM)) = TRIM(a4.YHDM)   
AND  COALESCE(TRIM(t.BZ),TRIM(a1.BZ),TRIM(a2.BZ),TRIM(a3.BZ)) = TRIM(a4.BZ)  ;  

-------删除临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP1 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP2 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP3 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP4 ;  
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON_TEMP  ;                
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
     invalidate metadata DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_BANK_MON; 
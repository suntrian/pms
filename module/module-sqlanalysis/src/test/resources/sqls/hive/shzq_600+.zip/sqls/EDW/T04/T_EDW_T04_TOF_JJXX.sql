--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:基金信息表                                                                           */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T04_TOF_JJXX;
------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T04_TOF_JJXX
(                                       
										JJDM                                     --基金代码        
                                       ,TADM                                     --TA代码        
                                       ,FQRDM                                    --发起人代码       
                                       ,GLRDM                                    --管理人代码       
                                       ,TGRDM                                    --托管人代码       
                                       ,TJDM                                     --统计代码        
                                       ,JJMC                                     --基金名称        
                                       ,JJQC                                     --基金全称        
                                       ,OF_JJJYZT                                --基金交易状态      
                                       ,JJJZ                                     --基金净值        
                                       ,OF_JJFL                                  --基金分类        
                                       ,PYDM                                     --拼音代码        
                                       ,FXZFE                                    --基金发行总规模     
                                       ,JSBZDM                                   --结算币种        
                                       ,OF_SFFSFW                                --基金收费方式范围    
                                       ,FXJG                                     --发行价格        
                                       ,RGKSRQ                                   --认购开始日期      
                                       ,RGJSRQ                                   --认购结束日期      
                                       ,MRFS                                     --认购申购方式      
                                       ,RGJS                                     --认购基数        
                                       ,GRSCRGZDZJ                               --个人首次认购最低金额  
                                         
                                       ,JGSCRGZDZJ                               --机构首次认购最低金额  
                                       ,GRZJRGZDZJ                               --个人追加认购最低金额  
                                       ,JGZJRGZDZJ                               --机构追加认购最低金额  
                                       ,GRZDRGZJ                                 --个人最低认购金额    
                                       ,JGZDRGZJ                                 --机构最低认购金额    
                                       ,SGJS                                     --申购基数        
                                       ,GRZGCYBL                                 --个人最高持有比例    
                                       ,JGZGCYBL                                 --机构最高持有比例    
                                       ,GRSCSGZDZJ                               --个人首次申购最低金额  
                                       ,JGSCSGZDZJ                               --机构首次申购最低金额  
                                       ,GRZJSGZDZJ                               --个人追加申购最低金额  
                                       ,JGZJSGZDZJ                               --机构追加申购最低金额  
                                       ,GRSHZDFE                                 --个人赎回最低份额    
                                       ,JGSHZDFE                                 --机构赎回最低份额    
                                       ,GRCCZDFE                                 --个人持仓最低限额    
                                       ,JGCCZDFE                                 --机构持仓最低限额    
                                       ,SHSYTS                                   --赎回顺延天数      
                                       ,YXXGFHFS                                 --允许修改分红方式    
                                       ,MRFHFS                                   --默认分红方式      
                                       ,HLHKTS                                   --红利到款延迟天数    
                                       ,GRZDZHFE                                 --个人最低转换份额    
                                       ,JGZDZHFE                                 --机构最低转换份额    
                                       ,XGRQ                                     --信息更新日期      
                                       ,LJJZ                                     --累计净值        
                                       ,MWFSY                                    --没万分收益       
                                       ,NSYL                                     --年收益率        
                                       ,GRRGSGDBZGJE                             --个人认购申购单笔最高金额
                                       ,GRRGSGDTZGJE                             --个人认购申购当天最高金额
                                       ,JJFXDJ                                   --基金风险等级      
                                       ,JGRGSGDBZGJE                             --机构认购申购单笔最高金额
                                       ,JGRGSGDTZGJE                             --机构认购申购当天最高金额
                                       ,LCCPBZ                                   --理财产品标志      
                                       ,WTFS                                     --委托方式        
                                       ,GRSHJS                                   --个人赎回基数      
                                       ,JGSHJS                                   --机构赎回基数      
                                       ,GRSHDBSX                                 --个人赎回单笔上限    
                                       ,GRSHDRSX                                 --个人赎回当日上限    
                                       ,JGSHDBSX                                 --机构赎回单笔上限    
                                       ,JGSHDRSX                                 --机构赎回当日上限    
                                       ,OF_JJZT_ZH                               --基金转换状态      
                                       ,OF_JJZT_DT                               --基金定投状态      
                                       ,OF_JJZT_ZTG                              --基金转托管状态     
                                       ,FXRQ                                     --发行日期        
                                       ,TZQX                                     --投资期限        
                                       ,TZPZ                                     --投资品种 
                                        ,YQSY									   
                                       ,XTBS									   
)                                                                                
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                        t.JJDM                                as JJDM                                      --基金代码                 
                                       ,t.TADM                                as TADM                                     --TA代码                  
                                       ,t.FQRDM                               as FQRDM                                    --发起人代码                 
                                       ,t.GLRDM                               as GLRDM                                    --管理人代码                 
                                       ,t.TGRDM                               as TGRDM                                    --托管人代码                 
                                       ,t.TJDM                                as TJDM                                     --统计代码                  
                                       ,t.JJJC                                as JJMC                                     --基金名称                  
                                       ,t.JJQC                                as JJQC                                     --基金全称                  
                                       ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as OF_JJJYZT                                --基金交易状态                
                                       ,t.JJJZ                                as JJJZ                                     --基金净值                  
                                       ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JJFL AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as OF_JJFL                                  --基金分类                  
                                       ,t.PYDM                                as PYDM                                     --拼音代码                  
                                       ,t.FXZFE                               as FXZFE                                    --基金发行总规模               
                                       ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as JSBZDM                                   --结算币种                  
                                       ,t.SFFSFW                              as OF_SFFSFW                                --基金收费方式范围              
                                       ,t.FXJG                                as FXJG                                     --发行价格                  
                                       ,t.RGKSRQ                              as RGKSRQ                                   --认购开始日期                
                                       ,t.RGJSRQ                              as RGJSRQ                                   --认购结束日期                
                                       ,t.MRFS                                as MRFS                                     --认购申购方式                
                                       ,t.RGJS                                as RGJS                                     --认购基数                  
                                       ,t.GRSCRGZDZJ                          as GRSCRGZDZJ                               --个人首次认购最低金额            
                                       ,t.JGSCRGZDZJ                          as JGSCRGZDZJ                               --机构首次认购最低金额            
                                       ,t.GRZJRGZDZJ                          as GRZJRGZDZJ                               --个人追加认购最低金额            
                                       ,t.JGZJRGZDZJ                          as JGZJRGZDZJ                               --机构追加认购最低金额            
                                       ,t.GRZDRGZJ                            as GRZDRGZJ                                 --个人最低认购金额              
                                       ,t.JGZDRGZJ                            as JGZDRGZJ                                 --机构最低认购金额              
                                       ,t.SGJS                                as SGJS                                     --申购基数                  
                                       ,t.GRZGCYBL                            as GRZGCYBL                                 --个人最高持有比例              
                                       ,t.JGZGCYBL                            as JGZGCYBL                                 --机构最高持有比例              
                                       ,t.GRSCSGZDZJ                          as GRSCSGZDZJ                               --个人首次申购最低金额            
                                       ,t.JGSCSGZDZJ                          as JGSCSGZDZJ                               --机构首次申购最低金额            
                                       ,t.GRZJSGZDZJ                          as GRZJSGZDZJ                               --个人追加申购最低金额            
                                       ,t.JGZJSGZDZJ                          as JGZJSGZDZJ                               --机构追加申购最低金额            
                                       ,t.GRSHZDFE                            as GRSHZDFE                                 --个人赎回最低份额              
                                       ,t.JGSHZDFE                            as JGSHZDFE                                 --机构赎回最低份额              
                                       ,t.GRCCZDFE                            as GRCCZDFE                                 --个人持仓最低限额              
                                       ,t.JGCCZDFE                            as JGCCZDFE                                 --机构持仓最低限额              
                                       ,t.SHSYTS                              as SHSYTS                                   --赎回顺延天数                
                                       ,t.YXXGFHFS                            as YXXGFHFS                                 --允许修改分红方式              
                                       ,t.MRFHFS                              as MRFHFS                                   --默认分红方式                
                                       ,t.HLHKTS                              as HLHKTS                                   --红利到款延迟天数              
                                       ,t.GRZDZHFE                            as GRZDZHFE                                 --个人最低转换份额              
                                       ,t.JGZDZHFE                            as JGZDZHFE                                 --机构最低转换份额              
                                       ,t.XGRQ                                as XGRQ                                     --信息更新日期                
                                       ,t.LJJZ                                as LJJZ                                     --累计净值                  
                                       ,t.MWFSY                               as MWFSY                                    --没万分收益                 
                                       ,t.NSYL                                as NSYL                                     --年收益率                  
                                       ,t.GRRGSGDBZGJE                        as GRRGSGDBZGJE                             --个人认购申购单笔最高金额          
                                       ,t.GRRGSGDTZGJE                        as GRRGSGDTZGJE                             --个人认购申购当天最高金额          
                                       ,t.JJFXDJ                              as JJFXDJ                                   --基金风险等级                
                                       ,t.JGRGSGDBZGJE                        as JGRGSGDBZGJE                             --机构认购申购单笔最高金额          
                                       ,t.JGRGSGDTZGJE                        as JGRGSGDTZGJE                             --机构认购申购当天最高金额          
                                       ,t.LCCPBZ                              as LCCPBZ                                   --理财产品标志                
                                       ,t.WTFS                                as WTFS                                     --委托方式                  
                                       ,t.GRSHJS                              as GRSHJS                                   --个人赎回基数                
                                       ,t.JGSHJS                              as JGSHJS                                   --机构赎回基数                
                                       ,t.GRSHDBSX                            as GRSHDBSX                                 --个人赎回单笔上限              
                                       ,t.GRSHDRSX                            as GRSHDRSX                                 --个人赎回当日上限              
                                       ,t.JGSHDBSX                            as JGSHDBSX                                 --机构赎回单笔上限              
                                       ,t.JGSHDRSX                            as JGSHDRSX                                 --机构赎回当日上限              
                                       ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHSTAT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as OF_JJZT_ZH                               --基金转换状态                
                                       ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.DTSTAT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as OF_JJZT_DT                               --基金定投状态                
                                       ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZTGSTAT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                             as OF_JJZT_ZTG                              --基金转托管状态               
                                       ,t.FXRQ                                as FXRQ                                     --发行日期                  
                                       ,t.TZQX                                as TZQX                                     --投资期限                  
                                       ,t.TZPZ                                as TZPZ                                     --投资品种
                                       ,t.YQSY
									   ,'JZJY'	                              as XTBS								   
                              
 FROM 		   JZJYCX.OFS_TOF_JJXX    							t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t1 
 ON             t1.DMLX = 'OF_JJJYZT'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.JYZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t2
 ON             t2.DMLX = 'OF_JJFL'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.JJFL AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t3 
 ON             t3.DMLX = 'BZDM'
 AND            t3.YXT = 'JZJY'
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t4 
 ON             t4.DMLX = 'OF_JJZT_ZH'
 AND            t4.YXT = 'JZJY'
 AND            t4.YDM = CAST(t.ZHSTAT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t5 
 ON             t5.DMLX = 'OF_JJZT_DT'
 AND            t5.YXT = 'JZJY'
 AND            t5.YDM = CAST(t.DTSTAT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING			t6 
 ON             t6.DMLX = 'OF_JJZT_ZTG'
 AND            t6.YXT = 'JZJY'
 AND            t6.YDM = CAST(t.ZTGSTAT AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';

---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TOF_JJXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;                                                                                                                                                                                                                                                          
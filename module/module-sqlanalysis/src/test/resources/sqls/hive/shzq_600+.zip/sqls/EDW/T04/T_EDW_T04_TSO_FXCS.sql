--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:个股期权风险参数表                                                                   */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
  TRUNCATE TABLE EDW_PROD.T_EDW_T04_TSO_FXCS;
------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TSO_FXCS
 (
                                     SOP_FXLB                            --个股期权风险类别                           
                                    ,FXZB                                --风险指标名                              
                                    ,SM                                  --说明                                 
                                    ,SYDXFW                              --适用对像范围                             
                                    ,SYQQLXFW                            --适用期权类型范围                           
                                    ,SYZQPZFW                            --适用标的证券品种范围                         
                                    ,ZBZ                                 --指标值                                
                                    ,ZBZXX                               --指标值上限    
                                    ,XTBS 								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.LB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as SOP_FXLB                            --风险类别                                
                                    ,t.FXZB                                as FXZB                                --风险指标名                               
                                    ,t.FXSM                                as SM                                  --说明                                  
                                    ,t.SYDXFW                              as SYDXFW                              --适用对像范围                              
                                    ,t.SYQQLXFW                            as SYQQLXFW                            --适用期权类型范围                            
                                    ,t.SYZQPZFW                            as SYZQPZFW                            --适用标的证券品种范围                          
                                    ,t.ZBZ                                 as ZBZ                                 --指标值                                 
                                    ,t.ZBZXX                               as ZBZXX                               --指标值上限  
                                    ,'GGQQ'                                as XTBS								   
 FROM 			GGQQCX.SOPTION_TSO_FXCS 						t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t1 
 ON             t1.DMLX = 'SOP_FXLB'
 AND            t1.YXT = 'GGQQ'
 AND            t1.YDM = CAST(t.LB AS VARCHAR(20))
 WHERE 			t.DT = '%d{yyyyMMdd}';
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TSO_FXCS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
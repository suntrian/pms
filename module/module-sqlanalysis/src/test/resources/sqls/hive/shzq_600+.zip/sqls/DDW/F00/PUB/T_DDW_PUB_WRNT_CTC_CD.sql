------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:期权合约代码表                                                                      */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
TRUNCATE TABLE DDW_PROD.T_DDW_PUB_WRNT_CTC_CD ;
INSERT OVERWRITE DDW_PROD.T_DDW_PUB_WRNT_CTC_CD
(
                                   EXG                     --交易所        
                                  ,WRNT_CTC_CD             --期权合约代码 
                                  ,WRNT_CTC_SHRTNM         --期权合约简称                                 
                                  ,SEC_CD                  --标的证券代码 
								  ,SEC_CD_NAME             --基础证券名称  							                                   								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT         t.JYS	      as EXG                     --交易所                                
               ,t.HYDM        as WRNT_CTC_CD             --期权合约代码 
               ,t.HYMC        as WRNT_CTC_SHRTNM         --期权合约简称 	                                        						    
               ,t.ZQDM        as SEC_CD                  --标的证券代码 
               ,t.ZQMC        as SEC_CD_NAME             --基础证券名称 
 FROM           EDW_PROD.T_EDW_T99_TSO_HYDM                                 t       
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_WRNT_CTC_CD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_WRNT_CTC_CD;
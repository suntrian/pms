------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:组合信息表                                                                          */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2018-11-26                                                                        */ 

 
 --清除数据
 TRUNCATE TABLE EDW_PROD.T_EDW_T04_GROUP_INFO;
 
 ------插入数据s
  INSERT INTO EDW_PROD.T_EDW_T04_GROUP_INFO
(
                GROUP_ID         --组合id
			   ,GROUP_NAME       --组合名称
			   ,BUILD_DATE       --建仓日期
			   ,RECOMMEND_REASON --推荐理由
			   ,UPDATE_TIME      --更新时间
			   ,STATUS           --状态(备用) 
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     
                GROUP_ID         --组合id
			   ,GROUP_NAME       --组合名称
			   ,BUILD_DATE       --建仓日期
			   ,RECOMMEND_REASON --推荐理由
			   ,UPDATE_TIME      --更新时间
			   ,STATUS           --状态(备用)
FROM       JJLC.GROUP_INFO;

 
 ----删除临时表
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_GROUP_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:经客户关系表                                                                       */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2018-05-14                                                                       */ 


--------------插入数据-------------------
 INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_CUST_RLN 
 (
                                     CUST_NO                             --客户号                                             									
									,BRH_NO                              --营业部编号       
                                    ,BRH_NAME                            --营业部名称       
                                    ,STATS_DT                            --统计日期        
                                    ,CNCL_DT                             --注销日期 
                                    ,EXPR_DT                             --截至日期	
                                    ,EFF_DT                              --生效日期									
                                    ,SVC_RLN_TP                          --服务关系类型
								    ,ASS_TP                              --考核关系
									,PSN_STAT                            --人员状态
									,PSN_ID                              --人员信息         
                                    ,PSN_NO                              --人员编号       
                                    ,PSN_NAME                            --人员姓名       
                                    ,PSN_CGY                             --人员类别 
                                    ,PSN_BELTO_BRH                       --人员所属营业部									
                                    ,OPNAC_DT                            --开户日期        
                                    ,ENTRY_DT                            --入职日期 
									,RSG_DT                              --离职日期                                  								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                                    t.KHH                                    as CUST_NO                             --客户号                                                        
                                   ,t.YYB                                    as BRH_NO                              --营业部编号                                                   
                                   ,NVL(a6.BRH_SHRTNM,a7.FILIL_DEPT_SHRTNM)  as BRH_NAME                            --营业部名称                                                   
                                   ,t.TJRQ                                   as STATS_DT                            --统计日期                                                                                        
                                   ,t.ZXRQ                                   as CNCL_DT                             --注销日期 
                                   ,t.JZRQ                                   as EXPR_DT                             --截至日期							   
                                   ,t.SXRQ                                   as EFF_DT                              --生效日期				
								   ,t.FWGXLX                                 as SVC_RLN_TP                          --服务关系类型                                          
                                   ,t.KHGX                                   as ASS_TP                              --考核关系
								   ,t.RYZHZT                                 as PSN_STAT                            --人员状态
								   ,CAST(t.RYXX as STRING)                  as PSN_ID                              --人员信息         
								   ,a1.RYBH                                  as PSN_NO                              --人员编号                                                   
                                   ,a1.RYXM                                  as PSN_NAME                            --人员姓名                                                   
                                   ,a1.RYLB                                  as PSN_CGY                             --人员类别 
                                   ,a1.YYB                                   as PSN_BELTO_BRH                       --人员所属营业部										   
                                   ,a1.KHRQ                                  as OPNAC_DT                            --开户日期                                                   
                                   ,a1.RZRQ                                  as ENTRY_DT                            --入职日期 
                                   ,a1.LZRQ                                  as RSG_DT                              --离职日期            						   									 
  FROM          EDW_PROD.T_EDW_T01_TKHGX                  t
  LEFT JOIN     EDW_PROD.T_EDW_T01_TRYXX                  a1
  ON            t.RYXX = a1.ID   
  AND           a1.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH         a6
  ON            t.YYB = a6.BRH_NO   
  AND           a6.BUS_DATE = %d{yyyyMMdd} 
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a7
  ON            t.YYB = a7.FILIL_DEPT_CDG
  AND           a7.BUS_DATE = %d{yyyyMMdd}   
  WHERE         t.bus_date = %d{yyyyMMdd}
  AND           t.TJRQ < = %d{yyyyMMdd} 
  AND           t.SXRQ < = %d{yyyyMMdd}
    ;

  -----------------------------------结束插入---------
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_CUST_RLN',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_CUST_RLN ;
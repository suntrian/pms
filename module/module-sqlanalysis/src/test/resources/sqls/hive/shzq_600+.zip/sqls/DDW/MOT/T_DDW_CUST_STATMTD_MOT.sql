--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户对账单监控  */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-08-11                                                                        */ 
  

 

 
  ----插入数据--
   INSERT OVERWRITE DDW_PROD.T_DDW_CUST_STATMTD_MOT
   
 (
                                   CUST_NO                  --客户号         
                                  ,SRC_TABLE                --来源表						  
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT 
                     t.CUST_NO                       as CUST_NO           --客户号              
					,'T_DDW_CUST_STATMT_DAY'	 as SRC_TABLE         --来源表		   
  FROM       DDW_PROD.T_DDW_CUST_STATMT_DAY    t 
  LEFT JOIN  (SELECT SUM(tot_pret) as tot_pret 
                     ,CUST_NO
              FROM DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY
              WHERE BUS_DATE = %d{yyyyMMdd}
              AND   PROD_CGY = 6
              GROUP BY CUST_NO
              )               a1
  ON          t.CUST_NO = a1.CUST_NO
  AND         t.oth_yld = a1.tot_pret
   LEFT JOIN  (SELECT SUM(tot_pret) as tot_pret 
                     ,CUST_NO
              FROM DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY
              WHERE BUS_DATE = %d{yyyyMMdd}
              AND   PROD_CGY IN (1,2,5,7)
              GROUP BY CUST_NO
              )               a2
  ON          t.CUST_NO = a2.CUST_NO 
  AND         t.tol_yld = a2.tot_pret
  LEFT JOIN    (SELECT CUST_NO,SUM(ordi_acct_gl_add_prinp) as ordi_acct_gl_add_prinp
                FROM   DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS
                WHERE BUS_DATE = %d{yyyyMMdd}
                GROUP  BY CUST_NO
                ) a3
  ON          t.CUST_NO = a3.CUST_NO
  AND         t.oth_yld = (0-a3.ordi_acct_gl_add_prinp)
  WHERE       t.BUS_DATE = %d{yyyyMMdd}
  AND         abs(t.net_incm) > 0.11
  AND         a1.CUST_NO IS NULL 
  AND         a2.CUST_NO IS NULL 
  AND         a3.CUST_NO IS NULL 
  AND         t.oth_yld < > 0
  UNION ALL
  SELECT 
                     t.CUST_NO                       as CUST_NO           --客户号              
					,'T_DDW_CUST_STATMT_DAY'	 as SRC_TABLE         --来源表		   
  FROM       DDW_PROD.T_DDW_CUST_STATMT_DAY    t 
  WHERE      t.oth_yld < > 0
  AND         abs(t.net_incm) = 0
  and         abs(tol_yld) > 1
  and         t.BUS_DATE = %d{yyyyMMdd} 
  ;
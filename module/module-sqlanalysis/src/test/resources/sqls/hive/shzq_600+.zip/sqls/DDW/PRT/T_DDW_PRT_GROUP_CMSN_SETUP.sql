 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:群组佣金设置表                                                                       */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 
  /* T_DDW_F02_GROUP_CMSN_POLCY  修改为   T_DDW_DIM_CUST_GROUP_CMSN_POLCY             */
  TRUNCATE TABLE DDW_PROD.T_DDW_PRT_GROUP_CMSN_SETUP;
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_GROUP_CMSN_SETUP
(
							
								 BRH_NO                          --营业部编号
								,BRH_NAME                        --营业部名称
								,CUST_NO                         --客户号
								,CUST_NAME                       --客户姓名
								,GROUP1                          --群组
								,SRC                             --来源
								,SETUP_DT                        --设置日期
								,POLCY_NAME                      --策略名称
								,CMSN_FIXPRC_MOD                 --佣金定价方式
								,AUDT_FLG                        --审核标志
)
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
			
							 t.BRH_NO                AS BRH_NO                          --营业部编号
							,t.BRH_NAME              AS BRH_NAME                        --营业部名称
							,t.CUST_NO               AS CUST_NO                         --客户号
							,t.CUST_NAME             AS CUST_NAME                       --客户姓名
							,t.GROUP1                AS GROUP1                          --群组
							,t.SRC                   AS SRC                             --来源
							,t.SETUP_DT              AS SETUP_DT                        --设置日期
							,t.POLCY_NAME            AS POLCY_NAME                      --策略名称
							,t.CMSN_FIXPRC_MOD       AS CMSN_FIXPRC_MOD                 --佣金定价方式
							,t.AUDT_FLG              AS AUDT_FLG                        --审核标志
 FROM  		DDW_PROD.T_DDW_F00_DIM_CUST_GROUP_CMSN_POLCY  t
 WHERE 		t.bus_date = %d{yyyyMMdd} 
 AND        t.CUST_STAT <>'3'
 AND        t.CUST_RSK_LVL IN ('0','1','2','8','19')
 ;

-----------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_GROUP_CMSN_SETUP',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_GROUP_CMSN_SETUP;
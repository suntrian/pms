 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:股东账户开户表                                                                      */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 
/* T_DDW_F02_YGTCX_THBOD_AND_CNTRTHBOD_BIZ_APL	修改为	t_ddw_f00_cust_cif_src_biz_apl_his   */

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_SHRHLD_ACCNT_OPNAC
(
								 BRH_NO							 --营业部编号
								,BRH_NAME                        --营业部名称
								,APL_DT                          --申请日期
								,OPRT_TELR                       --操作柜员
								,AUDT_TELR                       --审核柜员
								,CUST_NO                         --客户号
								,CUST_NAME                       --客户姓名
								,SHRHLD_NO                       --股东账号
								,RSLT_EXPLN                      --结果说明
								,BIZE_CGY                        --业务类别
								,CGY_EXPLN                       --类别说明
								,SECOND_CARD_VRFCTN              --二代证验证
								,CTF_NO                          --证件编号
								,OPRT_MOD					     --操作方式
                                ,CTF_CGY
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
					 t.BRH_NO									 AS	 BRH_NO							 --营业部编号
					,t.BRH_NAME                                  AS  BRH_NAME                        --营业部名称
					,CAST(T.APL_DT AS DECIMAL(8,0))              AS  APL_DT                          --申请日期
					,t.OPRT_TELR                                 AS  OPRT_TELR                       --操作柜员
					,t.AUDT_TELR                                 AS  AUDT_TELR                       --审核柜员
					,t.CUST_NO                                   AS  CUST_NO                         --客户号
					,t.CUST_NAME                                 AS  CUST_NAME                       --客户姓名
					,t.SHRHLD_NO                                 AS  SHRHLD_NO                       --股东账号
					,t.RSLT_EXPLN                                AS  RSLT_EXPLN                      --结果说明
					,t.BIZ_CGY                                  AS  BIZE_CGY                        --业务类别
					,t.CGY_EXPLN                                 AS  CGY_EXPLN                       --类别说明
					,t.SECOND_CARD_VRFCTN                     	 AS  SECOND_CARD_VRFCTN              --二代证验证
					,t.CTF_NO                                   AS  CTF_NO                          --证件编号
					,t.OPRT_MOD									 AS  OPRT_MOD					     --操作方式
    				,a2.CTF_CGY_CD_NAME           AS   CTF_CGY  --开户证件类别
  FROM  		DDW_PROD.t_ddw_f00_cust_cif_src_biz_apl_his  	t
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a1
  ON            t.CUST_NO = a1.CUST_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD     a2
  ON            a1.CTF_CGY_CD = a2.CTF_CGY_CD
  WHERE 		t.bus_date = %d{yyyyMMdd}
  AND           t.SRC_CGY = 'ZDSH,ZDSZ'
  AND           t.EXG IN ('1','2')
  AND           t.BIZ_CGY = '1'
  AND           t.OPRT_MOD IN ('掌厅','临柜')
  UNION ALL
   SELECT 
					 t.BRH_NO									 AS	 BRH_NO							 --营业部编号
					,t.BRH_NAME                                  AS  BRH_NAME                        --营业部名称
					,CAST(T.APL_DT AS DECIMAL(8,0))              AS  APL_DT                          --申请日期
					,t.OPRT_TELR                                 AS  OPRT_TELR                       --操作柜员
					,t.AUDT_TELR                                 AS  AUDT_TELR                       --审核柜员
					,t.CUST_NO                                   AS  CUST_NO                         --客户号
					,t.CUST_NAME                                 AS  CUST_NAME                       --客户姓名
					,t.SHRHLD_NO                                 AS  SHRHLD_NO                       --股东账号
					,t.RSLT_EXPLN                                AS  RSLT_EXPLN                      --结果说明
					,t.BIZ_CGY                                  AS  BIZE_CGY                        --业务类别
					,t.CGY_EXPLN                                 AS  CGY_EXPLN                       --类别说明
					,t.SECOND_CARD_VRFCTN                     	 AS  SECOND_CARD_VRFCTN              --二代证验证
					,t.CTF_NO                                   AS  CTF_NO                          --证件编号
					,t.OPRT_MOD									 AS  OPRT_MOD					     --操作方式
      				,a2.CTF_CGY_CD_NAME           AS   CTF_CGY  --开户证件类别
  FROM  		DDW_PROD.t_ddw_f00_cust_cif_src_biz_apl_his  	t
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a1
  ON            t.CUST_NO = a1.CUST_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD     a2
  ON            a1.CTF_CGY_CD = a2.CTF_CGY_CD
  WHERE 		t.bus_date = %d{yyyyMMdd}
  AND           t.SRC_CGY = 'ZDZH'
  AND           t.BIZ_CGY ='102'
  AND           t.OPRT_MOD IN ('掌厅','临柜')
  ;

 
-----------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_SHRHLD_ACCNT_OPNAC',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
     invalidate metadata DDW_PROD.T_DDW_PRT_SHRHLD_ACCNT_OPNAC; 
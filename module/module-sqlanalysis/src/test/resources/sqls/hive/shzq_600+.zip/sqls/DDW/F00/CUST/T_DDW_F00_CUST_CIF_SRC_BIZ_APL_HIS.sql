 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:一柜通中登和柜台中登业务申请表                                                                      */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
--------------------------删除临时表------------------
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_APL_HIS_TEMP ;
-----------------------删除临时表-------------------- 

--------创建临时表 二代证验证------

CREATE TABLE  DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_APL_HIS_TEMP AS
  SELECT t1.khh,t1.rq, 1 as bz 
  FROM (
         SELECT t.khh,t.rq
         FROM (
	             SELECT  khh,rq 
                 FROM   EDW_PROD.T_EDW_T05_TYGTXTCZMX
                 WHERE  YWKM = '20090' OR  zy like '%二代证验证%'
                 UNION ALL
                 SELECT     a1.khh,a2.sqrq as rq
                 FROM       (SELECT yyb,zjbh,khh FROM  EDW_PROD.T_EDW_T01_TKHXX where bus_date = %d{yyyyMMdd})     a1
                 INNER JOIN (SELECT zjbh,yyb,sqrq FROM EDW_PROD.T_EDW_T02_TGMSFCXSQ WHERE CLJG = 1)                a2
                 ON           a1.yyb = a2.yyb
                 AND          a1.zjbh = a2.zjbh
              ) t
       GROUP BY t.khh,t.rq
      )   t1
	  ; 



--------插入------
 INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_APL_HIS
(
                                     BRH_NO                                        --营业部编号   
                                    ,BRH_NAME                                      --营业部名称   
                                    ,APL_DT                                        --申请日期    
                                    ,OPRT_TELR                                     --操作柜员    
                                    ,AUDT_TELR                                     --审核柜员    
                                    ,CUST_NO                                       --客户号     
                                    ,CUST_NAME                                     --客户姓名 
                                    ,EXG                                           --交易所   
                                    ,SHRHLD_NO                                     --股东账号    
                                    ,RSLT_EXPLN                                    --结果说明    
                                    ,BIZ_CGY                                      --业务类别                                            
                                    ,CGY_EXPLN                                     --类别说明    
                                    ,SECOND_CARD_VRFCTN                            --二代证验证 
                                    ,OPRT_MOD                                      --操作方式  
									,CTF_NO                                        --证件编号
                                    ,SRC_CGY                                       --来源类别
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                                    t.YYB                     as BRH_NO                                     --营业部编号                                                
                                   ,NVL(a1.BRH_SHRTNM,a8.FILIL_DEPT_SHRTNM)                   as BRH_NAME                                   --营业部名称                                                
                                   ,t.SQRQ                    as APL_DT                                     --申请日期                                                 
                                   ,a6.NAME                   as OPRT_TELR                                  --操作柜员                                                                                      
                                   ,a7.NAME                   as AUDT_TELR                                  --审核柜员                                                 
                                   ,t.KHH                     as CUST_NO                                    --客户号                                                  
                                   ,a2.KHXM                   as CUST_NAME                                  --客户姓名 
                                   ,t.ZD_JYS                  as EXG                                        --交易所                                                 
                                   ,t.ZQZH                    as SHRHLD_NO                                  --股东账号                                                 
                                   ,t.JGSM                    as RSLT_EXPLN                                 --结果说明                                                 
                                   ,t.YWLB                    as BIZ_CGY                                   --业务类别    
                                   ,a4.THBOD_BIZ_CGY_NAME     as CGY_EXPLN                                  --类别说明                                       
                                   ,CASE WHEN a3.BZ = 1 
                                         THEN '已验证'	
 										 ELSE '未验证'
										 END                  as SECOND_CARD_VRFCTN                         --二代证验证 
								   ,CASE WHEN t.SQGY = 9057        
										 THEN '掌厅'	
                                         WHEN a5.BRH_NO IS NOT NULL	
                                         THEN '临柜'
                                         ELSE '其他'
                                         END                   as OPRT_MOD                                  --操作方式  
								   ,t.ZJBH                     AS CTF_NO                                    --证件编号
                                   ,'ZDZH'                     as SRC_CGY                                   --来源类别                                                                                                                                        
  FROM          EDW_PROD.T_EDW_T02_TZD_ZHYWSQ                                              t
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                                                   a1
  ON            t.YYB = a1.BRH_NO   
  AND           a1.BUS_DATE = %d{yyyyMMdd} 
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT                                        a8
  ON            t.YYB = a8.FILIL_DEPT_CDG
  AND           a8.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     EDW_PROD.T_EDW_T01_TKHXX                                                   a2 
  ON            t.KHH = a2.KHH
  AND           a2.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_APL_HIS_TEMP                                                      a3
  ON            t.KHH = a3.KHH
  AND           t.SQRQ = a3.RQ
  LEFT JOIN     DDW_PROD.V_THBOD_BIZ_CGY   a4
  ON            t.YWLB = a4.THBOD_BIZ_CGY
  LEFT JOIN     (SELECT NAME,TUSER_ID,orgid,bus_date FROM EDW_PROD.T_EDW_T02_TUSER)        a6
  ON            t.SQGY = a6.TUSER_ID  
  AND           a6.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                                                       a5
  ON            CAST(a6.orgid AS STRING) = a5.BRH_NO
  AND           a5.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     EDW_PROD.T_EDW_T02_TUSER                                                    a7
  ON            t.SHGY = a7.TUSER_ID
  AND           a7.BUS_DATE = %d{yyyyMMdd}
  WHERE         t.bus_date = %d{yyyyMMdd}
  UNION ALL
    SELECT 
                                    t.YYB                     as BRH_NO                                     --营业部编号                                                
                                   ,NVL(a1.BRH_SHRTNM,a8.FILIL_DEPT_SHRTNM)                   as BRH_NAME                                   --营业部名称                                                
                                   ,t.SQRQ                    as APL_DT                                     --申请日期                                                 
                                   ,a6.NAME                   as OPRT_TELR                                  --操作柜员                                                                                      
                                   ,a7.NAME                   as AUDT_TELR                                  --审核柜员                                                 
                                   ,t.KHH                     as CUST_NO                                    --客户号                                                  
                                   ,a2.KHXM                   as CUST_NAME                                  --客户姓名 
                                   ,t.ZD_JYS                  as EXG                                        --交易所                                                 
                                   ,t.GDZH                    as SHRHLD_NO                                  --股东账号                                                 
                                   ,t.JGSM                    as RSLT_EXPLN                                 --结果说明                                                 
                                   ,t.YWLB                    as BIZ_CGY                                   --业务类别    
                                   ,a4.BIZ_CGY_NAME           as CGY_EXPLN                                  --类别说明                                       
                                   ,CASE WHEN a3.BZ = 1 
                                         THEN '已验证'	
 										 ELSE '未验证'
										 END                  as SECOND_CARD_VRFCTN                         --二代证验证 
								  ,CASE WHEN t.WTGY = 9057        
										THEN '掌厅'	
                                        WHEN a5.BRH_NO IS NOT NULL	
                                        THEN '临柜'
                                        ELSE '其他'
                                        END                   as OPRT_MOD                                  --操作方式  
								 ,t.ZJBH                     AS CTF_NO                                    ----证件编号
                                 ,'ZDSH,ZDSZ'                 as SRC_CGY                                   --来源类别                                                                                                                                        
  FROM          EDW_PROD.T_EDW_T02_TGT_ZDYWSQ                                              t
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                                                   a1
  ON            t.YYB = a1.BRH_NO   
  AND           a1.BUS_DATE = %d{yyyyMMdd} 
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT                                        a8
  ON            t.YYB = a8.FILIL_DEPT_CDG
  AND           a8.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     EDW_PROD.T_EDW_T01_TKHXX                                                   a2 
  ON            t.KHH = a2.KHH 
  AND           a2.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_APL_HIS_TEMP                                                       a3
  ON            t.KHH = a3.KHH
  AND           t.SQRQ = a3.RQ
  LEFT JOIN     DDW_PROD.V_BIZ_CGY   a4
  ON            t.YWLB = a4.BIZ_CGY
  LEFT JOIN     (SELECT NAME,TUSER_ID,orgid,bus_date FROM EDW_PROD.T_EDW_T02_TUSER)               a6
  ON            t.WTGY = a6.TUSER_ID 
  AND           a6.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                                                      a5
  ON            CAST(a6.orgid AS STRING) = a5.BRH_NO
  AND           a5.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     EDW_PROD.T_EDW_T02_TUSER                                                    a7
  ON            t.SHGY = a7.TUSER_ID
  AND           a7.BUS_DATE = %d{yyyyMMdd} 
  WHERE         t.bus_date = %d{yyyyMMdd}
;		
---------------- 插入数据结束 -----------------------
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_APL_HIS_TEMP ;
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_CIF_SRC_BIZ_APL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_APL_HIS ;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:转融通标的期限费率                                                                */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZRT_BDQXFL;   
-------插入数据开始-------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZRT_BDQXFL
(
                                    ZRT_YWLX                            --转融通业务类型                            
                                   ,JYS                                 --证券市场                               
                                   ,ZQDM                                --证券代码                               
                                   ,QX                                  --期限                                 
                                   ,RRFL                                --融入费率                               
                                   ,RCFL                                --融出费率                               
                                   ,GXRQ                                --更新日期    
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.YWLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZRT_YWLX                            --业务类型                                
                                   ,t.JYS                                 as JYS                                 --证券市场                                
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.QX                                  as QX                                  --期限                                  
                                   ,t.RRFL                                as RRFL                                --融入费率                                
                                   ,t.RCFL                                as RCFL                                --融出费率                                
                                   ,t.BDRQ                                as GXRQ                                --更新日期  
                                   ,'RZRQ'                                as XTBS								   
 FROM           RZRQCX.ZRT_TZRT_BDQXFL                    t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING    t1 
 ON             t1.DMLX = 'ZRT_YWLX'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.YWLX AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束-------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZRT_BDQXFL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TZRT_BDQXFL;
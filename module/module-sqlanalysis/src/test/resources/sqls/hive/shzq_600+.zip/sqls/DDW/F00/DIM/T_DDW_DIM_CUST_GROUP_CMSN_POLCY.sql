------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:群组佣金策略维表                                                                     */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

-------------------------------删除今天的数据---------------------------------------
ALTER TABLE DDW_PROD.T_DDW_DIM_CUST_GROUP_CMSN_POLCY DROP IF EXISTS PARTITION   (BUS_DATE = %d{yyyyMMdd});
------------------------------------删除今天的数据结束------------------------------

--------------插入数据JZJY的数据-------------------
INSERT INTO DDW_PROD.T_DDW_DIM_CUST_GROUP_CMSN_POLCY
(
                                    BRH_NO                                       --营业部编号    
                                   ,BRH_NAME                                     --营业部名称    
                                   ,CUST_NO                                      --客户号      
                                   ,CUST_NAME                                    --客户姓名 
                                   ,CUST_STAT	                                 --客户状态
                                   ,CUST_RSK_LVL	                             --客户风险级别
                                   ,CNCLACT_DT	                                 --销户日期								   
                                   ,GROUP1                                       --群组       
                                   ,SRC                                          --来源       
                                   ,SETUP_DT                                     --设置日期     
                                   ,POLCY_NAME                                   --策略名称     
                                   ,CMSN_FIXPRC_MOD                             --佣金定价方式   
                                   ,AUDT_FLG                                     --审核标志     
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                                    t.YYB                                                          as BRH_NO                                       --营业部编号   
                                   ,NVL(a1.BRH_SHRTNM,a10.FILIL_DEPT_SHRTNM)                                                       as BRH_NAME                                     --营业部名称   
                                   ,a3.KHH                                                         as CUST_NO                                      --客户号     
                                   ,a3.KHXM                                                        as CUST_NAME                                    --客户姓名 
                                   ,a3.JZJYKH_KHZTDM                                               as CUST_STAT	                                   --客户状态
                                   ,a3.KHFXJB                                                      as CUST_RSK_LVL	                               --客户风险级别
                                   ,a3.JZJYKH_XHRQ                                                 as CNCLACT_DT	                                --销户日期									   
                                   ,t.KHQZ                                                         as GROUP1                                        --群组      
                                   ,'ABOSS'                                                        as SRC                                          --来源      
                                   ,t.DJRQ                                                         as SETUP_DT                                     --设置日期    
                                   ,a2.CLMC                                                        as POLCY_NAME                                   --策略名称    
                                   ,t.YJDJFS                                                       as CMSN_FIXPRC_MOD                             --佣金定价方式  
                                   ,t.SHBZ                                                         as AUDT_FLG                                     --审核标志    
                           
                                                                              
  FROM          EDW_PROD.T_EDW_T02_TYJDJDX_QZ                                                     t
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                           a1
  ON            t.YYB = a1.BRH_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a10
  ON            t.YYB = a10.FILIL_DEPT_CDG
  AND           a10.BUS_DATE = %d{yyyyMMdd}    
  LEFT JOIN     (SELECT FID,CLMC,YJDJFS,BUS_DATE  FROM EDW_PROD.T_EDW_T02_TYJDJ_DJCLID WHERE XTBS = 'JZJY' AND BUS_DATE = %d{yyyyMMdd} )            a2  
  ON            t.FID = a2.FID
  AND           t.YJDJFS = a2.YJDJFS
  AND          t.BUS_DATE = a2.BUS_DATE
  LEFT JOIN     EDW_PROD.T_EDW_T01_TKHXX                                                         a3
  ON            t.KHQZ = a3.JZJYKH_KHQZ 
  AND           t.YYB  = a3.YYB
  AND          t.BUS_DATE = a3.BUS_DATE 
  WHERE         t.XTBS = 'JZJY' 
  AND           t.BUS_DATE = %d{yyyyMMdd}
  ;
		
---------------- 插入数据结束 -----------------------

--------------插入数据RZRQ的数据-------------------
INSERT INTO DDW_PROD.T_DDW_DIM_CUST_GROUP_CMSN_POLCY
(
                                    BRH_NO                                       --营业部编号    
                                   ,BRH_NAME                                     --营业部名称    
                                   ,CUST_NO                                      --客户号      
                                   ,CUST_NAME                                    --客户姓名 
                                   ,CUST_STAT	                                 --客户状态
                                   ,CUST_RSK_LVL	                             --客户风险级别
                                   ,CNCLACT_DT	                                 --销户日期									   
                                   ,GROUP1                                       --群组       
                                   ,SRC                                          --来源       
                                   ,SETUP_DT                                     --设置日期     
                                   ,POLCY_NAME                                   --策略名称     
                                   ,CMSN_FIXPRC_MOD                              --佣金定价方式   
                                   ,AUDT_FLG                                     --审核标志     
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                                    t.YYB                                                         as BRH_NO                                       --营业部编号   
                                   ,NVL(a1.BRH_SHRTNM,a10.FILIL_DEPT_SHRTNM)                                                       as BRH_NAME                                     --营业部名称   
                                   ,a3.KHH                                                        as CUST_NO                                      --客户号     
                                   ,a3.KHXM                                                       as CUST_NAME                                    --客户姓名
                                   ,a3.RZRQKH_KHZTDM                                              as CUST_STAT	                                   --客户状态
                                   ,a3.KHFXJB                                                     as CUST_RSK_LVL	                               --客户风险级别
                                   ,a3.RZRQKH_XHRQ                                                as CNCLACT_DT	                                --销户日期											   
                                   ,t.KHQZ                                                        as GROUP1                                        --群组      
                                   ,'RZRQ'                                                        as SRC                                          --来源      
                                   ,t.DJRQ                                                        as SETUP_DT                                     --设置日期    
                                   ,a2.CLMC                                                       as POLCY_NAME                                   --策略名称    
                                   ,t.YJDJFS                                                      as CMSN_FIXPRC_MOD                             --佣金定价方式  
                                   ,t.SHBZ                                                        as AUDT_FLG                                     --审核标志    
                           
                                                                              
  FROM          EDW_PROD.T_EDW_T02_TYJDJDX_QZ                                                        t
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                           a1
  ON            t.YYB = a1.BRH_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a10
  ON            t.YYB = a10.FILIL_DEPT_CDG
  AND           a10.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     (SELECT FID,CLMC,YJDJFS,BUS_DATE FROM EDW_PROD.T_EDW_T02_TYJDJ_DJCLID WHERE XTBS = 'RZRQ' AND BUS_DATE = %d{yyyyMMdd})  a2  
  ON            t.FID = a2.FID
  AND           t.YJDJFS = a2.YJDJFS
  AND          t.BUS_DATE = a2.BUS_DATE
  LEFT JOIN     EDW_PROD.T_EDW_T01_TKHXX                                                              a3
  ON            t.KHQZ = a3.RZRQKH_KHQZ 
  AND           t.YYB  = a3.YYB
  AND          t.BUS_DATE = a3.BUS_DATE 
  WHERE         t.XTBS = 'RZRQ'
  AND           t.BUS_DATE = %d{yyyyMMdd}             
  ;
		
---------------- 插入数据结束 -----------------------
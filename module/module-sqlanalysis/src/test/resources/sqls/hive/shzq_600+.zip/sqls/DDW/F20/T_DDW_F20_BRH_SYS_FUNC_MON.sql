------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:系统性能月表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2019-12-11                                                                       */
ALTER TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON DROP IF EXISTS PARTITION (YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT));
------创建委托人数
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP as
SELECT    t.BRH_NO
         ,'JZJY' as SYS_SRC		
         ,SUM(CASE WHEN a1.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			)     as ODR_NUM_PHONE --手机委托人数
		 ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_TEL  --电话委托人数
		 ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_ONLN --网上委托人数
		 ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_UNSCE --非现场委托人数
		 ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM       --总委托人数
FROM   DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
LEFT JOIN (SELECT   KHH       as CUST_NO    
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   WTFS = 64
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a1
ON         t.CUST_NO = a1.CUST_NO		   
LEFT JOIN (SELECT   KHH       as CUST_NO    
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   WTFS = 1
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO    
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   WTFS = 32
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a3
ON         t.CUST_NO = a3.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO
                    ,COUNT(1) as NUM    
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   WTFS IN (1,32,64)
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a4
ON         t.CUST_NO = a4.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO                    					
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a5
ON         t.CUST_NO = a5.CUST_NO
WHERE      t.BUS_DATE = %d{yyyyMMdd}
GROUP BY t.BRH_NO    
UNION ALL
SELECT    t.BRH_NO
         ,'RZRQ' as SYS_SRC		
         ,SUM(CASE WHEN a1.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			)     as ODR_NUM_PHONE --手机委托人数
		 ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_TEL  --电话委托人数
		 ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_ONLN --网上委托人数
		 ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_UNSCE --非现场委托人数
		 ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM       --总委托人数
FROM   DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
LEFT JOIN (SELECT   KHH       as CUST_NO    
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   WTFS = 64
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a1
ON         t.CUST_NO = a1.CUST_NO		   
LEFT JOIN (SELECT   KHH       as CUST_NO    
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   WTFS = 1
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO    
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   WTFS = 32
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a3
ON         t.CUST_NO = a3.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO   
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   WTFS IN (1,32,64)
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a4
ON         t.CUST_NO = a4.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO                    					
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a5
ON         t.CUST_NO = a5.CUST_NO
WHERE      t.BUS_DATE = %d{yyyyMMdd}
GROUP BY t.BRH_NO   
UNION ALL
SELECT    t.BRH_NO
         ,'GGQQ' as SYS_SRC
         ,SUM(CASE WHEN a1.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			)     as ODR_NUM_PHONE --手机委托人数
		 ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_TEL  --电话委托人数
		 ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_ONLN --网上委托人数
		 ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_UNSCE --非现场委托人数
		 ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM       --总委托人数
FROM   DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
LEFT JOIN (SELECT   KHH       as CUST_NO     
		   FROM  EDW_PROD.T_EDW_T05_TSO_WTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   WTFS = 64
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a1
ON         t.CUST_NO = a1.CUST_NO		   
LEFT JOIN (SELECT   KHH       as CUST_NO     
		   FROM  EDW_PROD.T_EDW_T05_TSO_WTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   WTFS = 1
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO     
		   FROM  EDW_PROD.T_EDW_T05_TSO_WTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   WTFS = 32
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a3
ON         t.CUST_NO = a3.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO   
           FROM  EDW_PROD.T_EDW_T05_TSO_WTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   WTFS IN (1,32,64)
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a4
ON         t.CUST_NO = a4.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO   
           FROM  EDW_PROD.T_EDW_T05_TSO_WTLS         
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a5
ON         t.CUST_NO = a5.CUST_NO
WHERE      t.BUS_DATE = %d{yyyyMMdd}
GROUP BY t.BRH_NO    ;

------创建转账人数
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP1 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP1 as
SELECT    t.BRH_NO
         ,'JZJY' as SYS_SRC
         ,SUM(CASE WHEN a1.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			)     as ODR_NUM_PHONE --手机委托人数
		 ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_TEL  --电话委托人数
		 ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_ONLN --网上委托人数
		 ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_UNSCE --非现场委托人数
		 ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM       --总委托人数		 		 		 				 
FROM   DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
LEFT JOIN (SELECT   KHH       as CUST_NO      
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS        
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   SQFS = 64
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a1
ON         t.CUST_NO = a1.CUST_NO		   
LEFT JOIN (SELECT   KHH       as CUST_NO     
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   SQFS = 1
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO     
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   SQFS = 32
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a3
ON         t.CUST_NO = a3.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO   
           FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   SQFS IN (1,32,64)
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a4
ON         t.CUST_NO = a4.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO    
           FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a5
ON         t.CUST_NO = a5.CUST_NO
WHERE      t.BUS_DATE = %d{yyyyMMdd}
GROUP BY t.BRH_NO    
UNION ALL
SELECT    t.BRH_NO
         ,'RZRQ' as SYS_SRC
         ,SUM(CASE WHEN a1.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			)     as ODR_NUM_PHONE --手机委托人数
		 ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_TEL  --电话委托人数
		 ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_ONLN --网上委托人数
		 ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_UNSCE --非现场委托人数
		 ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM       --总委托人数		 		 		 				 
FROM   DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
LEFT JOIN (SELECT   KHH       as CUST_NO      
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS        
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   SQFS = 64
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a1
ON         t.CUST_NO = a1.CUST_NO		   
LEFT JOIN (SELECT   KHH       as CUST_NO     
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   SQFS = 1
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO     
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   SQFS = 32
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a3
ON         t.CUST_NO = a3.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO   
           FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   SQFS IN (1,32,64)
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a4
ON         t.CUST_NO = a4.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO    
           FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a5
ON         t.CUST_NO = a5.CUST_NO
WHERE      t.BUS_DATE = %d{yyyyMMdd}
GROUP BY t.BRH_NO    
UNION ALL
SELECT    t.BRH_NO
         ,'GGQQ' as SYS_SRC
         ,SUM(CASE WHEN a1.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			)     as ODR_NUM_PHONE --手机委托人数
		 ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_TEL  --电话委托人数
		 ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_ONLN --网上委托人数
		 ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_UNSCE --非现场委托人数
		 ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM       --总委托人数		 		 		 				 
FROM   DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
LEFT JOIN (SELECT   KHH       as CUST_NO      
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS        
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   SQFS = 64
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a1
ON         t.CUST_NO = a1.CUST_NO		   
LEFT JOIN (SELECT   KHH       as CUST_NO     
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   SQFS = 1
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO     
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   SQFS = 32
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a3
ON         t.CUST_NO = a3.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO   
           FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
           AND   SQFS IN (1,32,64)
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a4
ON         t.CUST_NO = a4.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO    
           FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a5
ON         t.CUST_NO = a5.CUST_NO
WHERE      t.BUS_DATE = %d{yyyyMMdd}
GROUP BY t.BRH_NO    ;
-------------------
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP2 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP2 as 
SELECT  t.BRH_NO                     as BRH_NO                --营业部编码       
       ,t.SYS_SRC                    as SYS_SRC               --系统来源
       ,SUM(t.ODR_ITMS_PHONE)        as ODR_ITMS_PHONE        --手机委托笔数
       ,SUM(t.ODR_ITMS_TEL)          as ODR_ITMS_TEL          --电话委托笔数
       ,SUM(t.ODR_ITMS_ONLN)         as ODR_ITMS_ONLN         --网上委托笔数
       ,SUM(t.ODR_ITMS_UNSCE)        as ODR_ITMS_UNSCE        --非现场委托笔数
       ,SUM(t.ODR_ITMS)              as ODR_ITMS              --总委托笔数
       ,MAX(t.ODR_ITMS)              as ODR_ITMS_MAX_DAY      --日峰值委托笔数
       ,CAST(AVG(t.ODR_ITMS*1.00) as DECIMAL(38,1))              as ODR_ITMS_AVG_DAY      --日均委托笔数
       ,SUM(t.ODR_ITMS_TRD_SH)       as ODR_ITMS_TRD_SH           --沪市交易笔数
       ,SUM(t.ODR_ITMS_UNTRD_SH)     as ODR_ITMS_UNTRD_SH         --沪市非交易笔数
       ,SUM(t.ODR_ITMS_TRD_SZ)       as ODR_ITMS_TRD_SZ           --深市交易笔数
       ,SUM(t.ODR_ITMS_UNTRD_SZ)     as ODR_ITMS_UNTRD_SZ         --深市非交易笔数	
       ,SUM(t.ODR_ITMS_TRD_HK)       as ODR_ITMS_TRD_HK           --沪港通交易笔数
       ,SUM(t.ODR_ITMS_UNTRD_HK)     as ODR_ITMS_UNTRD_HK         --沪港通非交易笔数
       ,SUM(t.ODR_ITMS_TRD_SK)       as ODR_ITMS_TRD_SK           --深港通交易笔数
       ,SUM(t.ODR_ITMS_UNTRD_SK)     as ODR_ITMS_UNTRD_SK         --深港通非交易笔数
       ,SUM(t.ODR_ITMS_TRD_T3BOD)    as ODR_ITMS_TRD_T3BOD        --三板交易笔数
       ,SUM(t.ODR_ITMS_UNTRD_T3BOD)  as ODR_ITMS_UNTRD_T3BOD      --三板非交易笔数
       ,SUM(t.TFR_ODR_ITMS_PHONE)    as TFR_ODR_ITMS_PHONE        --转账手机委托笔数
       ,SUM(t.TFR_ODR_ITMS_TEL)      as TFR_ODR_ITMS_TEL          --转账电话委托笔数
       ,SUM(t.TFR_ODR_ITMS_ONLN)     as TFR_ODR_ITMS_ONLN         --转账网上委托笔数
       ,SUM(t.TFR_ODR_ITMS_UNSCE)    as TFR_ODR_ITMS_UNSCE        --转账非现场委托笔数
       ,SUM(t.TFR_ODR_ITMS)          as TFR_ODR_ITMS              --转账总委托笔数 
       ,AVG(ODR_ITMS_SZ_FUNC)        as ODR_ITMS_SZ_FUNC_AVG_DAY      --日均委托笔数(SZ)(性能)
       ,SUM(ODR_ITMS_SZ_FUNC)        as ODR_ITMS_SZ_FUNC_MAX_DAY      --日峰值委托笔数(SZ)(性能)
	   ,AVG(ODR_ITMS_SH_FUNC)        as ODR_ITMS_SH_FUNC_AVG_DAY      --日均委托笔数(SH)(性能)
       ,SUM(ODR_ITMS_SH_FUNC)        as ODR_ITMS_SH_FUNC_MAX_DAY      --日峰值委托笔数(SH)(性能)
	   ,AVG(ODR_ITMS_FUNC)           as ODR_ITMS_FUNC_AVG_DAY      --日均委托笔数(SH)(性能)
       ,SUM(ODR_ITMS_FUNC)           as ODR_ITMS_FUNC_MAX_DAY      --日峰值委托笔数(SH)(性能)
	   ,MAX(t.TFR_ODR_ITMS)          as TFR_ODR_ITMS_MAX_DAY      --日峰值转账委托笔数
       ,CAST(AVG(t.TFR_ODR_ITMS*1.00) as DECIMAL(38,1))           as TFR_ODR_ITMS_AVG_DAY      --日均转账委托笔数
       ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},QLFD_CSUT_VOL,0))         as QLFD_CSUT_VOL               --合格客户总数
       ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},TEL_ODR_OPN_NUM,0))       as TEL_ODR_OPN_NUM              --电话委托开通人数
       ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},ONLINE_ODR_OPN_NUM,0))    as ONLINE_ODR_OPN_NUM           --网上委托开通人数
       ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},PHONE_ODR_OPN_NUM,0))     as PHONE_ODR_OPN_NUM            --手机委托开通人数
       ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},UNSCE_ODR_OPN_NUM,0))     as UNSCE_ODR_OPN_NUM            --非现场委托开通人数
       ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},T3IP_DEPMGT_CUST_VOL,0))  as T3IP_DEPMGT_CUST_VOL         --三方存管客户数
FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY t
WHERE SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
AND  BELTO_FILIL_CDG < >  '0001'
GROUP BY  BRH_NO                           
         ,SYS_SRC           
;
-------------------		 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP3 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP3 as 
SELECT  t.BELTO_FILIL_CDG            as BELTO_FILIL_CDG 
       ,t.BELTO_FILIL                as BELTO_FILIL    
       ,t.BRH_NO                     as BRH_NO                --营业部编码
       ,t.BRH_FULLNM                 as BRH_FULLNM            --营业部名称
       ,t.SYS_SRC                    as SYS_SRC               --系统来源
       ,SUM(t.ODR_ITMS_PHONE)        as ODR_ITMS_PHONE        --手机委托笔数
       ,SUM(t.ODR_ITMS_TEL)          as ODR_ITMS_TEL          --电话委托笔数
       ,SUM(t.ODR_ITMS_ONLN)         as ODR_ITMS_ONLN         --网上委托笔数
       ,SUM(t.ODR_ITMS_UNSCE)        as ODR_ITMS_UNSCE        --非现场委托笔数
       ,SUM(t.ODR_ITMS)              as ODR_ITMS              --总委托笔数
       ,MAX(t.ODR_ITMS)              as ODR_ITMS_MAX_DAY      --日峰值委托笔数
       ,CAST(AVG(t.ODR_ITMS*1.00)as DECIMAL(38,1))              as ODR_ITMS_AVG_DAY      --日均委托笔数
       ,SUM(t.ODR_ITMS_TRD_SH)       as ODR_ITMS_TRD_SH           --沪市交易笔数
       ,SUM(t.ODR_ITMS_UNTRD_SH)     as ODR_ITMS_UNTRD_SH         --沪市非交易笔数
       ,SUM(t.ODR_ITMS_TRD_SZ)       as ODR_ITMS_TRD_SZ           --深市交易笔数
       ,SUM(t.ODR_ITMS_UNTRD_SZ)     as ODR_ITMS_UNTRD_SZ         --深市非交易笔数	
       ,SUM(t.ODR_ITMS_TRD_HK)       as ODR_ITMS_TRD_HK           --沪港通交易笔数
       ,SUM(t.ODR_ITMS_UNTRD_HK)     as ODR_ITMS_UNTRD_HK         --沪港通非交易笔数
       ,SUM(t.ODR_ITMS_TRD_SK)       as ODR_ITMS_TRD_SK           --深港通交易笔数
       ,SUM(t.ODR_ITMS_UNTRD_SK)     as ODR_ITMS_UNTRD_SK         --深港通非交易笔数
       ,SUM(t.ODR_ITMS_TRD_T3BOD)    as ODR_ITMS_TRD_T3BOD        --三板交易笔数
       ,SUM(t.ODR_ITMS_UNTRD_T3BOD)  as ODR_ITMS_UNTRD_T3BOD      --三板非交易笔数
       ,SUM(t.TFR_ODR_ITMS_PHONE)    as TFR_ODR_ITMS_PHONE        --转账手机委托笔数
       ,SUM(t.TFR_ODR_ITMS_TEL)      as TFR_ODR_ITMS_TEL          --转账电话委托笔数
       ,SUM(t.TFR_ODR_ITMS_ONLN)     as TFR_ODR_ITMS_ONLN         --转账网上委托笔数
       ,SUM(t.TFR_ODR_ITMS_UNSCE)    as TFR_ODR_ITMS_UNSCE        --转账非现场委托笔数
       ,SUM(t.TFR_ODR_ITMS)          as TFR_ODR_ITMS              --转账总委托笔数 
       ,MAX(t.TFR_ODR_ITMS)          as TFR_ODR_ITMS_MAX_DAY      --日峰值转账委托笔数
       ,CAST(AVG(t.TFR_ODR_ITMS*1.00) as DECIMAL(38,1))          as TFR_ODR_ITMS_AVG_DAY      --日均转账委托笔数
       ,SUM(t.WALL_ODR_ITMS)         as WALL_ODR_ITMS                --当月堵单笔数
	   ,MAX(ODR_ITMS_FUNC)           as ODR_ITMS_FUNC_MAX_DAY            --日峰值委托笔数(性能)
       ,AVG(ODR_ITMS_FUNC)           as ODR_ITMS_FUNC_AVG_DAY            --日均值委托笔数(性能)
	   ,SUM(ODR_ITMS_FUNC)           as ODR_ITMS_FUNC                    --当月委托笔数(性能)
	   ,SUM(WALL_ODR_ITMS_6S)        as WALL_ODR_ITMS_6S             --当月堵单时间超过6秒笔数
	   ,MAX(t.WALL_ODR_ITMS)         as WALL_ODR_ITMS_MAX_DAY        --日峰值堵单笔数
       ,CAST(AVG(t.WALL_ODR_ITMS*1.00)as DECIMAL(38,1))         as WALL_ODR_ITMS_AVG_DAY        --日均值堵单笔数 
	   ,MAX(t.ODR_ITMS_MAX_SS)       as ODR_ITMS_MAX_SS              --秒峰值委托笔数
       ,CAST(AVG(t.ODR_ITMS_AVG_SS*1.00)as DECIMAL(38,1))       as ODR_ITMS_AVG_SS              --平均每秒委托笔数
       ,MAX(WALL_ODR_ITMS_MAX_SS)    as WALL_ODR_ITMS_MAX_SS         --秒峰值堵单笔数
	   ,SUM(WALL_ODR_ITMS_SH)        as WALL_ODR_ITMS_SH             --当月堵单笔数(SH)
	   ,AVG(ODR_ITMS_SH_FUNC)       as ODR_ITMS_FUNC_SH_MAX_DAY      --日峰值委托笔数(性能)(SH)
	   ,MAX(ODR_ITMS_SH_FUNC)       as ODR_ITMS_FUNC_SH_AVG_DAY      --日均值委托笔数(性能)(SH)
	   ,SUM(ODR_ITMS_SH_FUNC)           as ODR_ITMS_SH_FUNC                    --当月委托笔数(性能)(SH)
	  ,SUM(WALL_ODR_ITMS_SH_6S)     as WALL_ODR_ITMS_SH_6S          --堵单时间超过6秒笔数（SH)
	   ,MAX(WALL_ODR_ITMS_SH)        as WALL_ODR_ITMS_SH_MAX_DAY     --日峰值堵单笔数(SH)
       ,CAST(AVG(WALL_ODR_ITMS_SH*1.00)as DECIMAL(38,1))        as WALL_ODR_ITMS_SH_AVG_DAY     --日均值堵单笔数(SH)
	   ,MAX(ODR_ITMS_SH_MAX_SS)      as ODR_ITMS_SH_MAX_SS           --秒峰值委托笔数(SH)
       ,CAST(AVG(ODR_ITMS_AVG_SH_SS*1.00)as DECIMAL(38,1))      as ODR_ITMS_AVG_SH_SS           --平均每秒委托笔数(SH)
       ,MAX(WALL_ODR_ITMS_SH_MAX_SS) as WALL_ODR_ITMS_SH_MAX_SS      --秒峰值堵单笔数(SH)
       ,SUM(WALL_ODR_ITMS_SZ)        as WALL_ODR_ITMS_SZ              --当月堵单笔数(SZ)
	   ,AVG(ODR_ITMS_SZ_FUNC)       as ODR_ITMS_FUNC_SZ_MAX_DAY      --日峰值委托笔数(性能)(SZ)
	   ,MAX(ODR_ITMS_SZ_FUNC)       as ODR_ITMS_FUNC_SZ_AVG_DAY      --日均值委托笔数(性能)(SZ)
	   ,SUM(ODR_ITMS_SZ_FUNC)           as ODR_ITMS_SZ_FUNC                    --当月委托笔数(性能)(SZ)
	   ,SUM(WALL_ODR_ITMS_SZ_6S)     as WALL_ODR_ITMS_SZ_6S          --堵单时间超过6秒笔数（SZ)
	   ,MAX(WALL_ODR_ITMS_SZ)        as WALL_ODR_ITMS_SZ_MAX_DAY     --日峰值堵单笔数(SZ)
       ,CAST(AVG(WALL_ODR_ITMS_SZ*1.00)as DECIMAL(38,1))        as WALL_ODR_ITMS_SZ_AVG_DAY     --日均值堵单笔数(SZ)
	   ,MAX(ODR_ITMS_SZ_MAX_SS)      as ODR_ITMS_SZ_MAX_SS           --秒峰值委托笔数(SZ)
	   ,CAST(AVG(ODR_ITMS_AVG_SZ_SS*1.00)as DECIMAL(38,1))      as ODR_ITMS_AVG_SZ_SS           --平均每秒委托笔数(SZ)     
       ,MAX(WALL_ODR_ITMS_SZ_MAX_SS) as WALL_ODR_ITMS_SZ_MAX_SS      --秒峰值堵单笔数(SZ)
       ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},QLFD_CSUT_VOL,0))         as QLFD_CSUT_VOL               --合格客户总数
       ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},TEL_ODR_OPN_NUM,0))       as TEL_ODR_OPN_NUM              --电话委托开通人数
       ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},ONLINE_ODR_OPN_NUM,0))    as ONLINE_ODR_OPN_NUM           --网上委托开通人数
       ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},PHONE_ODR_OPN_NUM,0))     as PHONE_ODR_OPN_NUM            --手机委托开通人数
       ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},UNSCE_ODR_OPN_NUM,0))     as UNSCE_ODR_OPN_NUM            --非现场委托开通人数
       ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},T3IP_DEPMGT_CUST_VOL,0))  as T3IP_DEPMGT_CUST_VOL         --三方存管客户数
       ,%d{yyyyMMdd} ETL_DT                               --加载日期
FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY t
WHERE SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
AND  BELTO_FILIL_CDG = '0001'
GROUP BY  BELTO_FILIL_CDG 
         ,BELTO_FILIL    
         ,BRH_NO            
         ,BRH_FULLNM        
         ,SYS_SRC ;          
-----插入		 
INSERT  INTO DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON
(
  BELTO_FILIL_CDG              --分公司编码
, BELTO_FILIL                  --分公司名称
, BRH_NO                       --营业部编码
, BRH_FULLNM                   --营业部名称
, SYS_SRC                      --系统来源
, ODR_NUM_PHONE                --手机委托人数
, ODR_NUM_TEL                  --电话委托人数
, ODR_NUM_ONLN                 --网上委托人数
, ODR_NUM_UNSCE                --非现场委托人数
, ODR_NUM                      --总委托人数
, ODR_ITMS_PHONE               --手机委托笔数
, ODR_ITMS_TEL                 --电话委托笔数
, ODR_ITMS_ONLN                --网上委托笔数
, ODR_ITMS_UNSCE               --非现场委托笔数
, ODR_ITMS                     --总委托笔数
, ODR_ITMS_MAX_DAY             --日峰值委托笔数
, ODR_ITMS_AVG_DAY             --日均委托笔数
, ODR_ITMS_TRD_SH              --沪市交易笔数
, ODR_ITMS_UNTRD_SH            --沪市非交易笔数
, ODR_ITMS_TRD_SZ              --深市交易笔数
, ODR_ITMS_UNTRD_SZ            --深市非交易笔数	
, ODR_ITMS_TRD_HK              --沪港通交易笔数
, ODR_ITMS_UNTRD_HK            --沪港通非交易笔数
, ODR_ITMS_TRD_SK              --深港通交易笔数
, ODR_ITMS_UNTRD_SK            --深港通非交易笔数
, ODR_ITMS_TRD_T3BOD           --三板交易笔数
, ODR_ITMS_UNTRD_T3BOD         --三板非交易笔数
, TFR_ODR_NUM_PHONE            --转账手机委托人数
, TFR_ODR_NUM_TEL              --转账电话委托人数
, TFR_ODR_NUM_ONLN             --转账网上委托人数
, TFR_ODR_NUM_UNSCE            --转账非现场委托人数
, TFR_ODR_NUM                  --转账总委托人数
, TFR_ODR_ITMS_PHONE           --转账手机委托笔数
, TFR_ODR_ITMS_TEL             --转账电话委托笔数
, TFR_ODR_ITMS_ONLN            --转账网上委托笔数
, TFR_ODR_ITMS_UNSCE           --转账非现场委托笔数
, TFR_ODR_ITMS                 --转账总委托笔数 
, TFR_ODR_ITMS_MAX_DAY         --日峰值转账委托笔数
, TFR_ODR_ITMS_AVG_DAY         --日均转账委托笔数
, WALL_ODR_ITMS                --当月堵单笔数
, ODR_ITMS_FUNC                --当月委托笔数(性能)
, ODR_ITMS_FUNC_MAX_DAY        --日峰值委托笔数(性能)
, ODR_ITMS_FUNC_AVG_DAY        --日均值委托笔数(性能)
, WALL_ODR_ITMS_6S             --当月堵单时间超过6秒笔数
, WALL_ODR_ITMS_MAX_DAY        --日峰值堵单笔数
, WALL_ODR_ITMS_AVG_DAY        --日均值堵单笔数 
, ODR_ITMS_MAX_SS              --秒峰值委托笔数
, ODR_ITMS_AVG_SS              --平均每秒委托笔数
, WALL_ODR_ITMS_MAX_SS         --秒峰值堵单笔数
, WALL_ODR_ITMS_SH             --当月堵单笔数(SH)
, ODR_ITMS_SH_FUNC             --当月委托笔数(性能)(SH)
, ODR_ITMS_FUNC_SH_MAX_DAY     --日峰值委托笔数(性能)(SH)
, ODR_ITMS_FUNC_SH_AVG_DAY     --日均值委托笔数(性能)(SH)
, WALL_ODR_ITMS_SH_6S          --堵单时间超过6秒笔数（SH)
, WALL_ODR_ITMS_SH_MAX_DAY     --日峰值堵单笔数(SH)
, WALL_ODR_ITMS_SH_AVG_DAY     --日均值堵单笔数(SH)
, ODR_ITMS_SH_MAX_SS           --秒峰值委托笔数(SH)
, ODR_ITMS_AVG_SH_SS           --平均每秒委托笔数(SH)
, WALL_ODR_ITMS_SH_MAX_SS      --秒峰值堵单笔数(SH)
, WALL_ODR_ITMS_SZ             --当月堵单笔数(SZ)
, ODR_ITMS_SZ_FUNC             --当月委托笔数(性能)(SZ)
, ODR_ITMS_FUNC_SZ_MAX_DAY     --日峰委托笔数(SZ)
, ODR_ITMS_FUNC_SZ_AVG_DAY     --日均委托笔数(SZ)
, WALL_ODR_ITMS_SZ_6S          --堵单时间超过6秒笔数（SZ)
, WALL_ODR_ITMS_SZ_MAX_DAY     --日峰值堵单笔数(SZ)
, WALL_ODR_ITMS_SZ_AVG_DAY     --日均值堵单笔数(SZ)
, ODR_ITMS_SZ_MAX_SS           --秒峰值委托笔数(SZ)
, ODR_ITMS_AVG_SZ_SS           --平均每秒委托笔数(SZ)     
, WALL_ODR_ITMS_SZ_MAX_SS      --秒峰值堵单笔数(SZ)
, QLFD_CSUT_VOL                --合格客户总数
, TEL_ODR_OPN_NUM              --电话委托开通人数
, ONLINE_ODR_OPN_NUM           --网上委托开通人数
, PHONE_ODR_OPN_NUM            --手机委托开通人数
, UNSCE_ODR_OPN_NUM            --非现场委托开通人数
, T3IP_DEPMGT_CUST_VOL         --三方存管客户数
, ETL_DT                       --加载日期                           
)PARTITION( YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
SELECT  a3.BELTO_FILIL_CDG              --分公司编码
      , a3.BELTO_FILIL                  --分公司名称
      , a3.BRH_NO                       --营业部编码
      , a3.BRH_FULLNM                   --营业部名称
      , t.SYS_SRC                      --系统来源
      , NVL(a1.ODR_NUM_PHONE,0)                --手机委托人数
      , NVL(a1.ODR_NUM_TEL,0)                  --电话委托人数
      , NVL(a1.ODR_NUM_ONLN,0)                 --网上委托人数
      , NVL(a1.ODR_NUM_UNSCE,0)                --非现场委托人数
      , NVL(a1.ODR_NUM,0)                      --总委托人数
      , t.ODR_ITMS_PHONE               --手机委托笔数
      , t.ODR_ITMS_TEL                 --电话委托笔数
      , t.ODR_ITMS_ONLN                --网上委托笔数
      , t.ODR_ITMS_UNSCE               --非现场委托笔数
      , t.ODR_ITMS                     --总委托笔数
      , t.ODR_ITMS_MAX_DAY             --日峰值委托笔数
      , t.ODR_ITMS_AVG_DAY             --日均委托笔数
      , t.ODR_ITMS_TRD_SH              --沪市交易笔数
      , t.ODR_ITMS_UNTRD_SH            --沪市非交易笔数
      , t.ODR_ITMS_TRD_SZ              --深市交易笔数
      , t.ODR_ITMS_UNTRD_SZ            --深市非交易笔数	
      , t.ODR_ITMS_TRD_HK              --沪港通交易笔数
      , t.ODR_ITMS_UNTRD_HK            --沪港通非交易笔数
      , t.ODR_ITMS_TRD_SK              --深港通交易笔数
      , t.ODR_ITMS_UNTRD_SK            --深港通非交易笔数
      , t.ODR_ITMS_TRD_T3BOD           --三板交易笔数
      , t.ODR_ITMS_UNTRD_T3BOD         --三板非交易笔数
      , NVL(a2.ODR_NUM_PHONE,0)            --转账手机委托人数
      , NVL(a2.ODR_NUM_TEL,0)              --转账电话委托人数
      , NVL(a2.ODR_NUM_ONLN,0)             --转账网上委托人数
      , NVL(a2.ODR_NUM_UNSCE,0)            --转账非现场委托人数
      , NVL(a2.ODR_NUM,0)                  --转账总委托人数
      , t.TFR_ODR_ITMS_PHONE           --转账手机委托笔数
      , t.TFR_ODR_ITMS_TEL             --转账电话委托笔数
      , t.TFR_ODR_ITMS_ONLN            --转账网上委托笔数
      , t.TFR_ODR_ITMS_UNSCE           --转账非现场委托笔数
      , t.TFR_ODR_ITMS                 --转账总委托笔数 
      , t.TFR_ODR_ITMS_MAX_DAY         --日峰值转账委托笔数
      , t.TFR_ODR_ITMS_AVG_DAY         --日均转账委托笔数
      , NULL as WALL_ODR_ITMS                 --当月堵单笔数
	  , NULL as ODR_ITMS_FUNC             --当月委托笔数(性能)
	  , NULL as ODR_ITMS_FUNC_MAX_DAY      --日峰值委托笔数(性能)
      , NULL as ODR_ITMS_FUNC_AVG_DAY      --日均值委托笔数(性能)
      , NULL as WALL_ODR_ITMS_6S              --当月堵单时间超过6秒笔数
      , NULL as WALL_ODR_ITMS_MAX_DAY         --日峰值堵单笔数
      , NULL as WALL_ODR_ITMS_AVG_DAY         --日均值堵单笔数 
      , NULL as ODR_ITMS_MAX_SS               --秒峰值委托笔数
      , NULL as ODR_ITMS_AVG_SS               --平均每秒委托笔数
      , NULL as WALL_ODR_ITMS_MAX_SS          --秒峰值堵单笔数
      , NULL as WALL_ODR_ITMS_SH              --当月堵单笔数(SH)
	  , NULL as ODR_ITMS_SH_FUNC             --当月委托笔数(性能)(SH)
	  , NULL as ODR_ITMS_FUNC_SH_MAX_DAY      --日峰值委托笔数(性能)(SH)
      , NULL as ODR_ITMS_FUNC_SH_AVG_DAY      --日均值委托笔数(性能)(SH)
      , NULL as WALL_ODR_ITMS_SH_6S           --堵单时间超过6秒笔数（SH)
      , NULL as WALL_ODR_ITMS_SH_MAX_DAY      --日峰值堵单笔数(SH)
      , NULL as WALL_ODR_ITMS_SH_AVG_DAY      --日均值堵单笔数(SH)
      , NULL as ODR_ITMS_SH_MAX_SS            --秒峰值委托笔数(SH)
      , NULL as ODR_ITMS_AVG_SH_SS            --平均每秒委托笔数(SH)
      , NULL as WALL_ODR_ITMS_SH_MAX_SS       --秒峰值堵单笔数(SH)
      , NULL as WALL_ODR_ITMS_SZ              --当月堵单笔数(SZ)
	  , NULL as ODR_ITMS_SZ_FUNC              --当月委托笔数(性能)(SZ)
	  , NULL as ODR_ITMS_FUNC_SZ_MAX_DAY      --日峰值委托笔数(性能)(SZ)
      , NULL as ODR_ITMS_FUNC_SZ_AVG_DAY      --日均值委托笔数(性能)(SZ)
	  , NULL as WALL_ODR_ITMS_SZ_6S           --堵单时间超过6秒笔数（SZ)
      , NULL as WALL_ODR_ITMS_SZ_MAX_DAY      --日峰值堵单笔数(SZ)
      , NULL as WALL_ODR_ITMS_SZ_AVG_DAY      --日均值堵单笔数(SZ)
      , NULL as ODR_ITMS_SZ_MAX_SS            --秒峰值委托笔数(SZ)
      , NULL as ODR_ITMS_AVG_SZ_SS            --平均每秒委托笔数(SZ)     
      , NULL as WALL_ODR_ITMS_SZ_MAX_SS       --秒峰值堵单笔数(SZ)
      , t.QLFD_CSUT_VOL                 --合格客户总数
      , t.TEL_ODR_OPN_NUM               --电话委托开通人数
      , t.ONLINE_ODR_OPN_NUM            --网上委托开通人数
      , t.PHONE_ODR_OPN_NUM             --手机委托开通人数
      , t.UNSCE_ODR_OPN_NUM             --非现场委托开通人数
      , t.T3IP_DEPMGT_CUST_VOL          --三方存管客户数
      , %d{yyyyMMdd} as ETL_DT                        --加载日期
FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP2 t
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP a1
ON        t.BRH_NO = a1.BRH_NO
AND       t.SYS_SRC = a1.SYS_SRC
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP1 a2
ON        t.BRH_NO = a2.BRH_NO
AND       t.SYS_SRC = a2.SYS_SRC
LEFT JOIN DDW_PROD.T_DDW_INR_ORG_BRH a3
ON        t.BRH_NO = a3.BRH_NO
AND       a3.BUS_DATE = %d{yyyyMMdd}
;


INSERT  INTO DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON
(
  BELTO_FILIL_CDG              --分公司编码
, BELTO_FILIL                  --分公司名称
, BRH_NO                       --营业部编码
, BRH_FULLNM                   --营业部名称
, SYS_SRC                      --系统来源
, ODR_NUM_PHONE                --手机委托人数
, ODR_NUM_TEL                  --电话委托人数
, ODR_NUM_ONLN                 --网上委托人数
, ODR_NUM_UNSCE                --非现场委托人数
, ODR_NUM                      --总委托人数
, ODR_ITMS_PHONE               --手机委托笔数
, ODR_ITMS_TEL                 --电话委托笔数
, ODR_ITMS_ONLN                --网上委托笔数
, ODR_ITMS_UNSCE               --非现场委托笔数
, ODR_ITMS                     --总委托笔数
, ODR_ITMS_MAX_DAY             --日峰值委托笔数
, ODR_ITMS_AVG_DAY             --日均委托笔数
, ODR_ITMS_TRD_SH              --沪市交易笔数
, ODR_ITMS_UNTRD_SH            --沪市非交易笔数
, ODR_ITMS_TRD_SZ              --深市交易笔数
, ODR_ITMS_UNTRD_SZ            --深市非交易笔数	
, ODR_ITMS_TRD_HK              --沪港通交易笔数
, ODR_ITMS_UNTRD_HK            --沪港通非交易笔数
, ODR_ITMS_TRD_SK              --深港通交易笔数
, ODR_ITMS_UNTRD_SK            --深港通非交易笔数
, ODR_ITMS_TRD_T3BOD           --三板交易笔数
, ODR_ITMS_UNTRD_T3BOD         --三板非交易笔数
, TFR_ODR_NUM_PHONE            --转账手机委托人数
, TFR_ODR_NUM_TEL              --转账电话委托人数
, TFR_ODR_NUM_ONLN             --转账网上委托人数
, TFR_ODR_NUM_UNSCE            --转账非现场委托人数
, TFR_ODR_NUM                  --转账总委托人数
, TFR_ODR_ITMS_PHONE           --转账手机委托笔数
, TFR_ODR_ITMS_TEL             --转账电话委托笔数
, TFR_ODR_ITMS_ONLN            --转账网上委托笔数
, TFR_ODR_ITMS_UNSCE           --转账非现场委托笔数
, TFR_ODR_ITMS                 --转账总委托笔数 
, TFR_ODR_ITMS_MAX_DAY         --日峰值转账委托笔数
, TFR_ODR_ITMS_AVG_DAY         --日均转账委托笔数
, WALL_ODR_ITMS                --当月堵单笔数
, ODR_ITMS_FUNC                --当月委托笔数(性能)
, ODR_ITMS_FUNC_MAX_DAY        --日峰值委托笔数(性能)
, ODR_ITMS_FUNC_AVG_DAY        --日均值委托笔数(性能)
, WALL_ODR_ITMS_6S             --当月堵单时间超过6秒笔数
, WALL_ODR_ITMS_MAX_DAY        --日峰值堵单笔数
, WALL_ODR_ITMS_AVG_DAY        --日均值堵单笔数 
, ODR_ITMS_MAX_SS              --秒峰值委托笔数
, ODR_ITMS_AVG_SS              --平均每秒委托笔数
, WALL_ODR_ITMS_MAX_SS         --秒峰值堵单笔数
, WALL_ODR_ITMS_SH             --当月堵单笔数(SH)
, ODR_ITMS_SH_FUNC             --当月委托笔数(性能)(SH)
, ODR_ITMS_FUNC_SH_MAX_DAY     --日峰值委托笔数(性能)(SH)
, ODR_ITMS_FUNC_SH_AVG_DAY     --日均值委托笔数(性能)(SH)
, WALL_ODR_ITMS_SH_6S          --堵单时间超过6秒笔数（SH)
, WALL_ODR_ITMS_SH_MAX_DAY     --日峰值堵单笔数(SH)
, WALL_ODR_ITMS_SH_AVG_DAY     --日均值堵单笔数(SH)
, ODR_ITMS_SH_MAX_SS           --秒峰值委托笔数(SH)
, ODR_ITMS_AVG_SH_SS           --平均每秒委托笔数(SH)
, WALL_ODR_ITMS_SH_MAX_SS      --秒峰值堵单笔数(SH)
, WALL_ODR_ITMS_SZ             --当月堵单笔数(SZ)
, ODR_ITMS_SZ_FUNC             --当月委托笔数(性能)(SZ)
, ODR_ITMS_FUNC_SZ_MAX_DAY     --日峰委托笔数(SZ)
, ODR_ITMS_FUNC_SZ_AVG_DAY     --日均委托笔数(SZ)
, WALL_ODR_ITMS_SZ_6S          --堵单时间超过6秒笔数（SZ)
, WALL_ODR_ITMS_SZ_MAX_DAY     --日峰值堵单笔数(SZ)
, WALL_ODR_ITMS_SZ_AVG_DAY     --日均值堵单笔数(SZ)
, ODR_ITMS_SZ_MAX_SS           --秒峰值委托笔数(SZ)
, ODR_ITMS_AVG_SZ_SS           --平均每秒委托笔数(SZ)     
, WALL_ODR_ITMS_SZ_MAX_SS      --秒峰值堵单笔数(SZ)
, QLFD_CSUT_VOL                --合格客户总数
, TEL_ODR_OPN_NUM              --电话委托开通人数
, ONLINE_ODR_OPN_NUM           --网上委托开通人数
, PHONE_ODR_OPN_NUM            --手机委托开通人数
, UNSCE_ODR_OPN_NUM            --非现场委托开通人数
, T3IP_DEPMGT_CUST_VOL         --三方存管客户数
, ETL_DT                       --加载日期                           
)PARTITION( YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
SELECT  t.BELTO_FILIL_CDG              --分公司编码
      , t.BELTO_FILIL                  --分公司名称
      , t.BRH_NO                       --营业部编码
      , t.BRH_FULLNM                   --营业部名称
      , t.SYS_SRC                      --系统来源
      , NVL(a1.ODR_NUM_PHONE,0)                --手机委托人数
      , NVL(a1.ODR_NUM_TEL,0)                  --电话委托人数
      , NVL(a1.ODR_NUM_ONLN,0)                 --网上委托人数
      , NVL(a1.ODR_NUM_UNSCE,0)                --非现场委托人数
      , NVL(a1.ODR_NUM,0)                      --总委托人数
      , t.ODR_ITMS_PHONE               --手机委托笔数
      , t.ODR_ITMS_TEL                 --电话委托笔数
      , t.ODR_ITMS_ONLN                --网上委托笔数
      , t.ODR_ITMS_UNSCE               --非现场委托笔数
      , t.ODR_ITMS                     --总委托笔数
      , t.ODR_ITMS_MAX_DAY             --日峰值委托笔数
      , t.ODR_ITMS_AVG_DAY             --日均委托笔数
      , t.ODR_ITMS_TRD_SH              --沪市交易笔数
      , t.ODR_ITMS_UNTRD_SH            --沪市非交易笔数
      , t.ODR_ITMS_TRD_SZ              --深市交易笔数
      , t.ODR_ITMS_UNTRD_SZ            --深市非交易笔数	
      , t.ODR_ITMS_TRD_HK              --沪港通交易笔数
      , t.ODR_ITMS_UNTRD_HK            --沪港通非交易笔数
      , t.ODR_ITMS_TRD_SK              --深港通交易笔数
      , t.ODR_ITMS_UNTRD_SK            --深港通非交易笔数
      , t.ODR_ITMS_TRD_T3BOD           --三板交易笔数
      , t.ODR_ITMS_UNTRD_T3BOD         --三板非交易笔数
      , NVL(a2.ODR_NUM_PHONE,0)            --转账手机委托人数
      , NVL(a2.ODR_NUM_TEL,0)              --转账电话委托人数
      , NVL(a2.ODR_NUM_ONLN,0)             --转账网上委托人数
      , NVL(a2.ODR_NUM_UNSCE,0)            --转账非现场委托人数
      , NVL(a2.ODR_NUM,0)                  --转账总委托人数
      , t.TFR_ODR_ITMS_PHONE           --转账手机委托笔数
      , t.TFR_ODR_ITMS_TEL             --转账电话委托笔数
      , t.TFR_ODR_ITMS_ONLN            --转账网上委托笔数
      , t.TFR_ODR_ITMS_UNSCE           --转账非现场委托笔数
      , t.TFR_ODR_ITMS                 --转账总委托笔数 
      , t.TFR_ODR_ITMS_MAX_DAY         --日峰值转账委托笔数
      , t.TFR_ODR_ITMS_AVG_DAY         --日均转账委托笔数
      , t.WALL_ODR_ITMS                 --当月堵单笔数
	  , t.ODR_ITMS_FUNC                 --当月委托笔数(性能)
	  , t.ODR_ITMS_FUNC_MAX_DAY         --日峰值委托笔数(性能)
	  , t.ODR_ITMS_FUNC_AVG_DAY         --日均值委托笔数(性能)
      , t.WALL_ODR_ITMS_6S              --当月堵单时间超过6秒笔数
      , t.WALL_ODR_ITMS_MAX_DAY         --日峰值堵单笔数
      , t.WALL_ODR_ITMS_AVG_DAY         --日均值堵单笔数 
      , t.ODR_ITMS_MAX_SS               --秒峰值委托笔数
      , t.ODR_ITMS_AVG_SS               --平均每秒委托笔数
      , t.WALL_ODR_ITMS_MAX_SS          --秒峰值堵单笔数
      , t.WALL_ODR_ITMS_SH              --当月堵单笔数(SH)
	  , t.ODR_ITMS_SH_FUNC              --当月委托笔数(性能)(SH)
	  , t.ODR_ITMS_FUNC_SH_MAX_DAY      --日峰值委托笔数(性能)(SH)
	  , t.ODR_ITMS_FUNC_SH_AVG_DAY      --日均值委托笔数(性能)(SH)
	  
      , t.WALL_ODR_ITMS_SH_6S           --堵单时间超过6秒笔数（SH)
      , t.WALL_ODR_ITMS_SH_MAX_DAY      --日峰值堵单笔数(SH)
      , t.WALL_ODR_ITMS_SH_AVG_DAY      --日均值堵单笔数(SH)
      , t.ODR_ITMS_SH_MAX_SS            --秒峰值委托笔数(SH)
      , t.ODR_ITMS_AVG_SH_SS            --平均每秒委托笔数(SH)
      , t.WALL_ODR_ITMS_SH_MAX_SS       --秒峰值堵单笔数(SH)
      , t.WALL_ODR_ITMS_SZ              --当月堵单笔数(SZ)
	  , t.ODR_ITMS_SZ_FUNC              --当月委托笔数(性能)(SZ)
      , t.ODR_ITMS_FUNC_SZ_MAX_DAY      --日峰委托笔数(性能)(SZ)
      , t.ODR_ITMS_FUNC_SZ_AVG_DAY      --日均委托笔数(性能)(SZ)
	  
      , t.WALL_ODR_ITMS_SZ_6S           --堵单时间超过6秒笔数（SZ)
      , t.WALL_ODR_ITMS_SZ_MAX_DAY      --日峰值堵单笔数(SZ)
      , t.WALL_ODR_ITMS_SZ_AVG_DAY      --日均值堵单笔数(SZ)
      , t.ODR_ITMS_SZ_MAX_SS            --秒峰值委托笔数(SZ)
      , t.ODR_ITMS_AVG_SZ_SS            --平均每秒委托笔数(SZ)     
      , t.WALL_ODR_ITMS_SZ_MAX_SS       --秒峰值堵单笔数(SZ)
      , t.QLFD_CSUT_VOL                 --合格客户总数
      , t.TEL_ODR_OPN_NUM               --电话委托开通人数
      , t.ONLINE_ODR_OPN_NUM            --网上委托开通人数
      , t.PHONE_ODR_OPN_NUM             --手机委托开通人数
      , t.UNSCE_ODR_OPN_NUM             --非现场委托开通人数
      , t.T3IP_DEPMGT_CUST_VOL          --三方存管客户数
      , %d{yyyyMMdd} as ETL_DT                        --加载日期
FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP3 t
LEFT JOIN (SELECT  SYS_SRC
                  ,SUM(ODR_NUM_PHONE)  as ODR_NUM_PHONE  
                  ,SUM(ODR_NUM_TEL)    as ODR_NUM_TEL   
                  ,SUM(ODR_NUM_ONLN)   as ODR_NUM_ONLN  
                  ,SUM(ODR_NUM_UNSCE)  as ODR_NUM_UNSCE 
                  ,SUM(ODR_NUM)        as ODR_NUM  

           FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP
		   GROUP BY SYS_SRC
		   ) a1
ON        t.SYS_SRC = a1.SYS_SRC
LEFT JOIN (SELECT  SYS_SRC
                  ,SUM(ODR_NUM_PHONE)  as ODR_NUM_PHONE  
                  ,SUM(ODR_NUM_TEL)    as ODR_NUM_TEL   
                  ,SUM(ODR_NUM_ONLN)   as ODR_NUM_ONLN  
                  ,SUM(ODR_NUM_UNSCE)  as ODR_NUM_UNSCE 
                  ,SUM(ODR_NUM)        as ODR_NUM  

           FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP1
		   GROUP BY SYS_SRC
		   ) a2
ON        t.SYS_SRC = a2.SYS_SRC
;


---------------- 插入数据结束 -----------------------
----
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP1 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP2 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON_TEMP3 ;
-----
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_SYS_FUNC_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
INVALIDATE METADATA DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_MON;
 
------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:基金账户累计销售明细表                                                      */
------/* 创建人:欧阳晶                                                                                 */
------/* 创建时间:2018-06-29                                                                           */ 

----基金交易临时表-从证券交易/产品交易表取数
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FND_TRD_STATS_DAY_TEMP1;
CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_FND_TRD_STATS_DAY_TEMP1
AS 
    SELECT
           T1.CUST_NO                                            --客户号
          ,T4.CUST_NAME                                          --客户名称
          ,T1.BRH_NO                                             --营业部编号
		  ,T2.BRH_FULLNM AS BRH_NAME                             --营业部名称
          ,T1.SEC_CD AS FND_CD                                   --基金代码
          ,COALESCE(T6.JJQC,T5.CPQC,t7.ZQMC) AS FND_NAME         --基金名称
          ,SUM(T1.MTCH_AMT) AS BUY_AMT                           --累计购买金额
		
    FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS T1
    INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
            ON T1.BRH_NO = T2.BRH_NO
           AND T2.BELTO_FILIL_CDG = '0032'
		   AND T2.BUS_DATE = %d{yyyyMMdd}
    INNER JOIN DDW_PROD.T_DDW_CFG_WZ_PROD T3
            ON T1.SEC_CD = T3.PROD_CD
    LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO T4
           ON T1.CUST_NO = T4.CUST_NO
          AND T4.BUS_DATE = %d{yyyyMMdd}
    LEFT JOIN EDW_PROD.T_EDW_T99_TJRCP_CPDM T5
           ON T1.SEC_CD = T5.CPDM
          AND T5.BUS_DATE = %d{yyyyMMdd}
    LEFT JOIN EDW_PROD.T_EDW_T04_TOF_JJXX T6
           ON T1.SEC_CD = T6.JJDM
          AND T6.BUS_DATE = %d{yyyyMMdd}
    LEFT JOIN EDW_PROD.T_EDW_T04_TZQDM T7
           ON T1.EXG = T7.JYS
          AND T1.SEC_CD = T7.ZQDM
          AND T7.BUS_DATE = %d{yyyyMMdd}
    WHERE T1.odr_cgy IN (1,1111,83,42)
      AND T1.BUS_DATE = %d{yyyyMMdd}
      AND ((SUBSTR(T1.SEC_CD,1,2) IN ('50','51','52') AND EXG = 'SH') OR (SUBSTR(T1.SEC_CD,1,2) IN ('15','16','18') AND EXG = 'SZ'))
    GROUP BY 
             T1.CUST_NO
            ,T4.CUST_NAME
            ,T1.BRH_NO
			,T2.BRH_FULLNM
            ,T1.SEC_CD
            ,COALESCE(T6.JJQC,T5.CPQC,t7.ZQMC)
		    ,T1.SYS_SRC
            ,T1.BUS_DATE
   UNION ALL
    SELECT 
           T1.CUST_NO                                            --客户号
          ,T4.CUST_NAME                                          --客户名称
          ,T1.BRH_NO                                             --营业部编号
		  ,T2.BRH_FULLNM AS BRH_NAME                             --营业部名称
          ,T1.PROD_CD AS FND_CD                                  --基金代码
          ,COALESCE(T6.JJQC,T5.CPQC,T8.CPQC) AS FND_NAME                 --基金名称
          ,SUM(T1.CNFM_AMT) AS BUY_AMT                           --购买金额
    FROM DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS T1
    INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
            ON T1.BRH_NO = T2.BRH_NO
           AND T2.BELTO_FILIL_CDG = '0032'
           AND T2.BUS_DATE = %d{yyyyMMdd}
    INNER JOIN DDW_PROD.T_DDW_CFG_WZ_PROD T3
            ON T1.PROD_CD = T3.PROD_CD
    LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO T4
           ON T1.CUST_NO = T4.CUST_NO
          AND T4.BUS_DATE = %d{yyyyMMdd}
    LEFT JOIN EDW_PROD.T_EDW_T99_TJRCP_CPDM T5
           ON T1.PROD_CD = T5.CPDM
          AND T5.BUS_DATE = %d{yyyyMMdd}
    LEFT JOIN EDW_PROD.T_EDW_T04_TOF_JJXX T6
           ON T1.PROD_CD = T6.JJDM
          AND T6.BUS_DATE = %d{yyyyMMdd}
	LEFT JOIN EDW_PROD.T_EDW_T04_TFP_CPDM T8
               ON T1.PROD_CD = T8.CPDM
              AND T8.BUS_DATE = %d{yyyyMMdd}
    WHERE T1.PROD_BIZ_CD IN ('122','130','139')
      AND T1.BUS_DATE = %d{yyyyMMdd}
    GROUP BY 
             T1.CUST_NO
            ,T4.CUST_NAME
            ,T1.BRH_NO
		    ,T2.BRH_FULLNM
            ,T1.PROD_CD
            ,COALESCE(T6.JJQC,T5.CPQC,T8.CPQC)
;

------插入数据开始
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_WZ_FND_TRD_STATS_DAY
(    CUST_NO                                     --客户号
    ,CUST_NANE                                   --客户名称
    ,BRH_NO                                      --营业部编号
	,BRH_NAME                                    --营业部名称
    ,FND_CD			                             --基金代码
    ,FND_NAME                                    --基金名称
	,BUY_AMT                                     --购买金额
 ) partition(BUS_DATE = %d{yyyyMMdd})
    SELECT 
           CUST_NO AS CUST_NO                    --客户号
	      ,CUST_NAME AS CUST_NAME                --客户名称
	      ,BRH_NO AS BRH_NO                      --营业部编号
		  ,BRH_NAME AS BRH_NAME                  --营业部名称
	      ,FND_CD AS FND_CD                      --基金代码
	      ,FND_NAME AS FND_NAME                  --基金名称
	      ,SUM(BUY_AMT) AS BUY_AMT               --购买金额
    FROM DDW_PROD.T_DDW_PRT_WZ_FND_TRD_STATS_DAY_TEMP1
    GROUP BY
	         CUST_NO
	        ,CUST_NAME
	        ,BRH_NO
			,BRH_NAME
	        ,FND_CD
	        ,FND_NAME
	        
	     
;
------插入数据结束

------删除临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FND_TRD_STATS_DAY_TEMP1;

-----------------------------加载结束--------------------
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_WZ_FND_TRD_STATS_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_WZ_FND_TRD_STATS_DAY ;  
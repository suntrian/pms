-- /* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:一人多户统计报表                                                               		*/
 -- /* 创建人:OYJ                                                                                   */
  --/* 创建时间:2019-08-13                                                                          */  

------插入数据
----临时表,数据主表,取状态不为"销户",证券账户非"0199XXXXXX"和"X99XXXXXXX"
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP1;
CREATE TABLE DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP1
AS
SELECT  DISTINCT
        T1.YMTH
       ,T1.ZHLB
       ,T3.NOTE AS ZHLBMC
       ,T1.ZQZH
       ,T2.KHMC AS ZHKHMC
       ,NVL(T2.ZJLB,'') AS ZJLB
       ,NVL(T4.NOTE,'') AS ZJLBMC
       ,NVL(T2.ZJDM,'') AS ZJBH
FROM YGTCX.CIF_TZDZH_ZQZHZL T1
LEFT JOIN YGTCX.CIF_TZDZH_YMTZL T2
ON T1.YMTH = T2.YMTH
LEFT JOIN YGTCX.CIF_TXTDM T3
ON T1.ZHLB = T3.CBM
AND T3.DT  = '%d{yyyyMMdd}'--REPLACE(TO_DATE(DAYS_ADD(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2)),DAYOFWEEK(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2))) * -1 - 1)),'-','')
AND T3.FLDM = 'ZDZH_ZHLB'
LEFT JOIN YGTCX.CIF_TXTDM T4
ON T2.ZJLB = T4.CBM
AND T4.DT  = '%d{yyyyMMdd}'--REPLACE(TO_DATE(DAYS_ADD(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2)),DAYOFWEEK(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2))) * -1 - 1)),'-','')
AND T4.FLDM = 'ZDZH_ZJLB'
WHERE T1.ZQZHZT <> '04'
AND T1.RQ <> T1.KHRQ
AND SUBSTR(T1.ZQZH,1,4) <> '0199'
AND SUBSTR(T1.ZQZH,2,2) <> '99'
;

----临时表,判断是否我司开户的证券账户
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP2;
CREATE TABLE DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP2
AS
SELECT DISTINCT KHH,ZHLB,ZQZH,HBRQ
FROM YGTCX.CIF_TZD_ZHYWHB
WHERE YWLB = 102
AND LENGTH(TRIM(NVL(ZQZH,''))) = 10
AND DT <= REPLACE(TO_DATE(DAYS_ADD(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2)),DAYOFWEEK(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2))) * -1 - 1)),'-','')
;

----临时表,限制同一一码通号和账户类别,存在多个证券账户
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP3;
CREATE TABLE DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP3
AS
SELECT YMTH,ZHLB
FROM DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP1
GROUP BY YMTH,ZHLB
HAVING COUNT(*) > 1
;

----临时表,限制当日数据不与之前历史数据重复
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP4;
CREATE TABLE DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP4
AS
SELECT DISTINCT T1.YMTH,T1.ZHLB
FROM DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP1 T1
LEFT JOIN 
(
  SELECT DISTINCT YMTH,ZHLB,ZQZH
  FROM DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS
  WHERE BUS_DATE < CAST(REPLACE(TO_DATE(DAYS_ADD(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2)),DAYOFWEEK(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2))) * -1 - 1)),'-','') AS INT)
) T2
ON T1.YMTH = T2.YMTH
AND T1.ZHLB = T2.ZHLB
AND T1.ZQZH = T2.ZQZH
WHERE T2.YMTH IS NULL
;

----临时表,限制至少有一个证券账户是在我司开户的
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP5;
CREATE TABLE DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP5
AS
SELECT DISTINCT T1.YMTH,T1.ZHLB
FROM DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP1 T1
INNER JOIN DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP2 T4
ON T1.ZHLB = NVL(CAST(T4.ZHLB AS STRING),'')
AND T1.ZQZH = T4.ZQZH
;

----插入当日数据
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS
(
   YMTH                     --  1 . 一码通号
  ,ZHLB                     --  2 . 账户类别代码
  ,ZHLBMC                   --  3 . 账户类别名称
  ,ZQZH                     --  4 . 证券账户
  ,ZHKHMC                   --  5 . 账户客户名称(中登)
  ,ZJLB                     --  6 . 账户客户证件类别代码(中登)
  ,ZJLBMC                   --  7 . 账户客户证件类别名称(中登)
  ,ZJBH                     --  8 . 账户客户证件编号(中登)
  ,FLG                      --  9 . 是否公司证券账户
  ,ZHKHRQ                   -- 10 . 证券账户开户日期
  ,YYB                      -- 11 . 营业部
  ,KHH                      -- 12 . 客户号
  ,KHXM                     -- 13 . 客户名称
  ,KHZJLB                   -- 14 . 客户证件类别代码
  ,KHZJLBMC                 -- 15 . 客户证件类别名称
  ,KHZJBH                   -- 16 . 客户证件编号
)
PARTITION( bus_date = CAST(REPLACE(TO_DATE(DAYS_ADD(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2)),DAYOFWEEK(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2))) * -1 - 1)),'-','') AS INT))
--CAST(REPLACE(TO_DATE(DAYS_ADD(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2)),DAYOFWEEK(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2))) * -1 - 1)),'-','') AS INT)   
SELECT 
        T1.YMTH
       ,T1.ZHLB
       ,T1.ZHLBMC
       ,T1.ZQZH
       ,T1.ZHKHMC
       ,T1.ZJLB
       ,T1.ZJLBMC
       ,T1.ZJBH
       ,CASE WHEN T4.ZQZH IS NOT NULL THEN '是公司证券账户' ELSE '不是公司证券账户' END AS FLG
       ,NVL(T4.HBRQ,0) AS ZHKHRQ
       ,NVL(CAST(T5.YYB AS STRING) ,'') AS YYB
       ,NVL(T5.KHH,'') AS KHH
       ,NVL(T5.KHMC,'') AS KHXM
       ,NVL(CAST(T5.ZJLB AS STRING) ,'') AS KHZJLB
       ,NVL(T6.NOTE,'') AS KHZJLBMC
	   ,NVL(T5.ZJBH,'') AS KHZJBH
FROM DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP1 T1
INNER JOIN DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP4 T2
ON T1.YMTH = T2.YMTH
AND T1.ZHLB = T2.ZHLB
INNER JOIN DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP3 T3
ON T1.YMTH = T3.YMTH
AND T1.ZHLB = T3.ZHLB
INNER JOIN DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP5 T7
ON T1.YMTH = T7.YMTH
AND T1.ZHLB = T7.ZHLB
LEFT JOIN DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP2 T4
ON T1.ZHLB = NVL(CAST(T4.ZHLB AS STRING),'')
AND T1.ZQZH = T4.ZQZH
LEFT JOIN YGTCX.CIF_TKHXX T5
ON T4.KHH = T5.KHH
AND T5.DT = '%d{yyyyMMdd}'--REPLACE(TO_DATE(DAYS_ADD(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2)),DAYOFWEEK(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2))) * -1 - 1)),'-','')
LEFT JOIN YGTCX.CIF_TXTDM T6
ON T5.ZJLB = T6.IBM
AND T6.DT  = '%d{yyyyMMdd}'--REPLACE(TO_DATE(DAYS_ADD(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2)),DAYOFWEEK(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2))) * -1 - 1)),'-','')
AND T6.FLDM = 'GT_ZJLB'
;

-------插入数据结束

DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP1;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP2;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP3;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP4;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS_TMP5;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_MLT_ACCNT_STATS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

INVALIDATE METADATA DDW_PROD.T_DDW_PRT_MLT_ACCNT_STATS;

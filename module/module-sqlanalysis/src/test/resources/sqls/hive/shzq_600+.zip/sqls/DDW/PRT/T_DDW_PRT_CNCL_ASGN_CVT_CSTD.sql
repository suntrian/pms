 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:撤指转托管表                                                                     */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 
 /* T_DDW_F05_CIF_CUST_OPE_DETAIL  修改为   T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS             */
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CNCL_ASGN_CVT_CSTD_TEMP;
CREATE TABLE  DDW_PROD.T_DDW_PRT_CNCL_ASGN_CVT_CSTD_TEMP  AS
  SELECT t1.khh
  FROM (
         SELECT t.khh,t.rq as RQ
         FROM (
	             SELECT  khh,rq 
                 FROM   EDW_PROD.T_EDW_T05_TYGTXTCZMX
                 WHERE  YWKM = '20090' OR  zy like '%二代证验证%'
                 UNION ALL
                 SELECT     a1.khh,a2.sqrq as rq
                 FROM       (SELECT yyb,zjbh,khh FROM  EDW_PROD.T_EDW_T01_TKHXX where bus_date = %d{yyyyMMdd})     a1
                 INNER JOIN (SELECT zjbh,yyb,sqrq FROM EDW_PROD.T_EDW_T02_TGMSFCXSQ WHERE CLJG = 1)                a2
                 ON           a1.yyb = a2.yyb
                 AND          a1.zjbh = a2.zjbh
              ) t
       GROUP BY t.khh,t.rq
      )   t1
 LEFT JOIN (SELECT a.TRD_DT,b.lst_trd_d 
            FROM      EDW_PROD.T_EDW_T99_TRD_DATE a 
			LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE b
			ON        a.BUS_DATE = b.BUS_DATE
			AND       a.lst_trd_d = b.TRD_DT
            where  a.BUS_DATE = %d{yyyyMMdd}
			AND    a.TRD_DT = %d{yyyyMMdd}
             ) a1
 ON    t1.RQ > = a1.lst_trd_d 
 AND   t1.RQ < = a1.TRD_DT
 GROUP BY t1.KHH
	  ; 
 
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CNCL_ASGN_CVT_CSTD
(
								 BRH_NO 					--营业部编号
								,BRH_NAME                   --营业部名称
								,OCC_BRH_NO                 --发生营业部
								,DT                         --日期
								,CUST_NO                    --客户号
								,CUST_NAME                  --客户姓名
								,BIZ_SBJ                    --业务科目
								,BIZ_SBJ_NAME               --业务科目名称
								,ABST                       --摘要
								,OPRT_TELR                  --操作柜员
								,SECOND_CARD_VRFCTN         --二代证验证
								,OPRT_MOD				    --操作方式
								,CTF_CGY                    --证件类别
)		
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
								 t.BRH_NO			  		 AS BRH_NO 					   --营业部编号
								,t.BRH_NAME                  AS BRH_NAME                   --营业部名称
								,t.OCC_BRH_NO                AS OCC_BRH_NO                 --发生营业部
								,t.DT                        AS DT                         --日期
								,t.CUST_NO                   AS CUST_NO                    --客户号
								,t.CUST_NAME                 AS CUST_NAME                  --客户姓名
								,t.BIZ_SBJ                   AS BIZ_SBJ                    --业务科目
								,t.BIZ_SBJ_NAME              AS BIZ_SBJ_NAME               --业务科目名称
								,t.ABST                      AS ABST                       --摘要
								,t.OPRT_TELR                 AS OPRT_TELR                  --操作柜员
								,CASE WHEN a1.KHH IS NOT NULL
								      THEN '已验证'
									  ELSE '未验证'
									  END                    AS SECOND_CARD_VRFCTN         --二代证验证
								,t.OPRT_MOD					 AS OPRT_MOD				    --操作方式
                                 ,a3.CTF_CGY_CD_NAME                       AS CTF_CGY                            --证件类别
  FROM  		DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS  	t
  LEFT JOIN     DDW_PROD.T_DDW_PRT_CNCL_ASGN_CVT_CSTD_TEMP   a1
  ON            t.CUST_NO = a1.KHH
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a2
  ON            t.CUST_NO = a2.CUST_NO
  AND           a2.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD     a3
  ON            a2.CTF_CGY_CD = a3.CTF_CGY_CD
  WHERE 		t.bus_date = %d{yyyyMMdd}
  AND           t.OPRT_MOD IN ('临柜','掌厅','指E通')
  AND           t.BIZ_SBJ IN ('50102','50201')
  ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CNCL_ASGN_CVT_CSTD_TEMP;
-----------------------------加载结束--------------------
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_CNCL_ASGN_CVT_CSTD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_CNCL_ASGN_CVT_CSTD;
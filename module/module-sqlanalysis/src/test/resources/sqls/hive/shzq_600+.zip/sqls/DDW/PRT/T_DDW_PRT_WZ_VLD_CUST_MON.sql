------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:温州分公司有效客户月表                                                              */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2019-01-04                                                                        */ 
  
  
----参与新客宝产品
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP
as 
SELECT   a.CUST_NO as CUST_NO
        ,MIN(a.BUS_DATE) as BUS_DATE
FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS  a
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH         b
ON         a.BRH_NO = b.BRH_NO
AND        b.BELTO_FILIL_CDG = '0032'
AND        b.BUS_DATE = %d{yyyyMMdd}
WHERE a.SEC_CD = '205021' 
AND a.EXG = 'SH'
AND SUBSTR(CAST(a.BUS_DATE as STRING),1,6)  = SUBSTR('%d{yyyyMMdd}',1,6)
AND a.ODR_CGY IN (5,35,36)
GROUP BY a.CUST_NO ; 

--证券市值达到 10000 元；说明：只要活动期间某一天达到即可
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP1 ;
CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP1
as
SELECT  a.CUST_NO
        ,MIN(a.BUS_DATE) as BUS_DATE
FROM   DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY  a
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH         b
ON         a.BRH_NO = b.BRH_NO
AND        b.BELTO_FILIL_CDG = '0032'
AND        b.BUS_DATE = %d{yyyyMMdd}
WHERE  a.TOT_MKTVAL > = 10000
AND SUBSTR(CAST(a.BUS_DATE as STRING),1,6)  = SUBSTR('%d{yyyyMMdd}',1,6)
GROUP BY a.CUST_NO ;

---参与基金定投，每期至少 1000 元，至少参与 3 期。说明：一只基金连续成功扣款3期
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP2 ;
CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP2 as 
SELECT t.CUST_NO
      ,MIN(BUS_DATE) as BUS_DATE
FROM
(SELECT   a.CUST_NO
         ,a.PROD_CD
		 ,a.BUS_DATE 
    ,ROW_NUMBER() OVER(PARTITION BY a.CUST_NO,a.PROD_CD ORDER BY a.BUS_DATE ) as NUM 
FROM DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS  a
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH         b
ON         a.BRH_NO = b.BRH_NO
AND        b.BELTO_FILIL_CDG = '0032'
AND        b.BUS_DATE = %d{yyyyMMdd}
WHERE a.PROD_BIZ_CD = '139'
AND a.BUS_DATE > = 20190101
AND a.BUS_DATE < = %d{yyyyMMdd}
AND a.CNFM_AMT >= 1000
)   t
WHERE t.NUM = 3
GROUP BY t.CUST_NO ;
----  
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP3 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP3 as  
    SELECT t.KHH as CUST_NO
 FROM 
 (SELECT a.NAT_DT,b.KHH,SUM(b.AMT) as AMT
  FROM (SELECT NAT_DT FROM EDW_PROD.T_EDW_T99_TRD_DATE
        WHERE  BUS_DATE = %d{yyyyMMdd}
		AND    NAT_DT BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,-60) as INT) AND %d{yyyyMMdd}
		--AND    NAT_DT > = 20190101
       ) a
 LEFT JOIN (SELECT a.KHH,a.BUS_DATE,SUM(ROUND(a.SRJE*NVL(b.ZHHL,1)-a.FCJE*NVL(b.ZHHL,1),2)) as AMT
                     
 FROM    EDW_PROD.T_EDW_T05_TZJMXLS  a
 LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH              b
 ON             a.BZDM = b.BZDM
 AND            b.BUS_DATE = a.BUS_DATE
 WHERE  SUBSTR(a.YWKM,1,3) IN ('101','102')
 AND    a.BUS_DATE > = 20190101
 AND    a.BUS_DATE < = %d{yyyyMMdd}
 GROUP BY a.KHH,a.BUS_DATE
 )  b
 ON a.NAT_DT  > = b.BUS_DATE
 --WHERE b.KHH = '105300098322'
 GROUP BY a.NAT_DT,b.KHH
 ORDER BY nat_dt) t
  WHERE t.AMT > = 1000
 GROUP BY CUST_NO
 HAVING COUNT(1)  >= 30
;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP4 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP4 as 
 SELECT   CUST_NO 
         ,CAST(SUBSTR(CAST(BUS_DATE as STRING),1,6) as INT) as YEAR_MON
 FROM     DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP
 UNION 
 SELECT   CUST_NO 
         ,CAST(SUBSTR(CAST(BUS_DATE as STRING),1,6) as INT) as YEAR_MON
 FROM     DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP1
 UNION 
 SELECT   CUST_NO 
         ,CAST(SUBSTR(CAST(BUS_DATE as STRING),1,6) as INT) as YEAR_MON
 FROM     DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP2
 UNION 
 SELECT   CUST_NO 
         ,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)                  as YEAR_MON
 FROM     DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP3 ;

-------温州分公司20170101年开户无效客户数 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP5 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP5 as 
SELECT         a.CUST_NO
              ,a.CUST_NAME
			  ,a.BRH_NO
			  ,a.BRH_NAME
			  ,a.CTCT_TEL
			  ,a.PHONE
			  ,a.ORDI_OPNAC_DT
FROM       DDW_PROD.T_DDW_F00_CUST_CUST_INFO  a
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH         b
ON         a.BRH_NO = b.BRH_NO
AND        b.BELTO_FILIL_CDG = '0032'
AND        b.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN (SELECT CUST_NO
           FROM   DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
           WHERE BUS_DATE BETWEEN 20170101 AND 20181231
           AND  TOT_MKTVAL >0
		   GROUP BY CUST_NO) c
ON         a.CUST_NO = c.CUST_NO
LEFT JOIN (SELECT CUST_NO
           FROM   DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
           WHERE BUS_DATE BETWEEN 20170101 AND 20181231
           AND   WRNT_TRD_VOL+ORDI_TRD_VOL_RMB+CRD_TRD_VOL+PROD_SCRP_AMT+PROD_PRCH_AMT+PROD_FIXINV_AMT+PROD_RDMPT_AMT >0
		   GROUP BY CUST_NO) d
ON         a.CUST_NO = d.CUST_NO
WHERE a.BUS_DATE = %d{yyyyMMdd}
AND   a.ORDI_CUST_STAT < > '3'
AND   a.ORDI_OPNAC_DT < 20170101
AND   c.CUST_NO IS NULL
AND   d.CUST_NO  IS NULL ;

-------温州分公司20170101-20171231年开户无效客户数
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP6 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP6 as 
SELECT         a.CUST_NO
              ,a.CUST_NAME
			  ,a.BRH_NO
			  ,a.BRH_NAME
			  ,a.CTCT_TEL
			  ,a.PHONE
			  ,a.ORDI_OPNAC_DT
			 ,CAST(EDW_PROD.G_DATE_ADD_STR(CAST(a.ORDI_OPNAC_DT as STRING),'yyyyMMdd','yyyyMMdd',2,0,0) as INT) as LAST_TWO_YEAR
FROM       DDW_PROD.T_DDW_F00_CUST_CUST_INFO  a
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH         b
ON         a.BRH_NO = b.BRH_NO
AND        b.BELTO_FILIL_CDG = '0032'
AND        b.BUS_DATE = %d{yyyyMMdd}
WHERE a.BUS_DATE = %d{yyyyMMdd}
AND   a.ORDI_CUST_STAT < > '3'
AND   a.ORDI_OPNAC_DT BETWEEN 20170101 AND 20171231 ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_CFG1 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_CFG1 as 
select CUST_NO,ordi_opnac_dt,CASE WHEN ordi_opnac_dt <20170101
                                  THEN 20181231
								  ELSE cast( EDW_PROD.G_DATE_ADD_STR(CAST(ordi_opnac_dt as STRING) ,'yyyyMMdd','yyyyMMdd',2,0,0) as int)
                                  END LAST_TWO_YEAR              
  from  DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_CFG ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP7 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP7 as 
SELECT         a.CUST_NO
              ,a.CUST_NAME
			  ,a.BRH_NO
			  ,a.BRH_NAME
			  ,a.CTCT_TEL
			  ,a.PHONE
			  ,a.ORDI_OPNAC_DT
FROM       DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_CFG  a

LEFT JOIN (SELECT a.CUST_NO,MIN(a.BUS_DATE) as BUS_DATE
           FROM   DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY a 
		   INNER JOIN  DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_CFG1   b
		   ON      a.CUST_NO = b.CUST_NO
		   AND     a.BUS_DATE > = b.ORDI_OPNAC_DT
		   AND     a.BUS_DATE < = b.LAST_TWO_YEAR
           AND  a.TOT_MKTVAL >0
		   GROUP BY a.CUST_NO) c
ON         a.CUST_NO = c.CUST_NO
LEFT JOIN (SELECT a.CUST_NO,MIN(a.BUS_DATE) as BUS_DATE
           FROM   DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY a
		   INNER JOIN  DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_CFG1   b
		   ON      a.CUST_NO = b.CUST_NO
		   AND     a.BUS_DATE > = b.ORDI_OPNAC_DT
		   AND     a.BUS_DATE < = b.LAST_TWO_YEAR
           WHERE  WRNT_TRD_VOL+ORDI_TRD_VOL_RMB+CRD_TRD_VOL+PROD_SCRP_AMT+PROD_PRCH_AMT+PROD_FIXINV_AMT+PROD_RDMPT_AMT >0
		   GROUP BY a.CUST_NO) d
ON         a.CUST_NO = d.CUST_NO
WHERE    SUBSTR(CAST(LEAST(c.BUS_DATE,d.BUS_DATE) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
 OR      (c.CUST_NO IS NULL AND d.CUST_NO IS NULL);

 -------温州分公司客户与员工的关系
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP8 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP8 as 
SELECT CUST_NO,BRK_NO as PSN_NO,'经纪关系' as PSN_CGY,BRK_NAME as PSN_NAME
         FROM   DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN         		 
		 WHERE %d{yyyyMMdd} > = STATS_DT 
           AND %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
	       AND BUS_DATE = %d{yyyyMMdd}
         UNION ALL
         SELECT CUST_NO,PSN_NO as PSN_NO,'强服务关系' as PSN_CGY,PSN_NAME
         FROM DDW_PROD.T_DDW_F00_CUST_CUST_RLN
         WHERE    %d{yyyyMMdd} > = STATS_DT 
         AND      %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
         AND      BUS_DATE = %d{yyyyMMdd}
         AND       SVC_RLN_TP IN ('4')
		 UNION ALL
         SELECT a.CUST_NO,MAX(a.PSN_NO) as PSN_NO,'弱服务关系' as PSN_CGY,MAX(a.PSN_NAME) as PSN_NAME
         FROM DDW_PROD.T_DDW_F00_CUST_CUST_RLN a
         WHERE    %d{yyyyMMdd} > = a.STATS_DT 
         AND      %d{yyyyMMdd} < NVL(a.EXPR_DT,99999999) 
         AND      a.BUS_DATE = %d{yyyyMMdd}
         AND       a.SVC_RLN_TP IN ('5')
		 AND  NOT EXISTS (SELECT 1
                          FROM   DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN  b       		 
		                  WHERE %d{yyyyMMdd} > = b.STATS_DT 
                          AND   %d{yyyyMMdd} < NVL(b.EXPR_DT,99999999) 
	                      AND b.BUS_DATE = %d{yyyyMMdd}
						  AND a.CUST_NO = b.CUST_NO
						  )
		 AND  NOT EXISTS (SELECT 1
                           FROM  DDW_PROD.T_DDW_F00_CUST_CUST_RLN  c
                           WHERE    %d{yyyyMMdd} > = c.STATS_DT 
                            AND      %d{yyyyMMdd} < NVL(c.EXPR_DT,99999999) 
                            AND      c.BUS_DATE = %d{yyyyMMdd}
                            AND       c.SVC_RLN_TP IN ('4') 
						  AND a.CUST_NO = c.CUST_NO
						  )
		 GROUP BY a.CUST_NO,a.PSN_CGY ;
---总表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP9 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP9 as 
   SELECT      a.CUST_NO
              ,a.CUST_NAME
			  ,a.BRH_NO
			  ,a.BRH_NAME
			  ,a.CTCT_TEL
			  ,a.PHONE
			  ,a.ORDI_OPNAC_DT
			  ,b.PSN_CGY
			  ,b.PSN_NAME
	FROM DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP5    a
	LEFT JOIN DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP8 b
	ON        a.CUST_NO = b.CUST_NO
	UNION ALL
	SELECT     a.CUST_NO
              ,a.CUST_NAME
			  ,a.BRH_NO
			  ,a.BRH_NAME
			  ,a.CTCT_TEL
			  ,a.PHONE
			  ,a.ORDI_OPNAC_DT
			  ,b.PSN_CGY
			  ,b.PSN_NAME
	FROM DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP7    a
	LEFT JOIN DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP8 b
	ON        a.CUST_NO = b.CUST_NO 
	UNION ALL
	SELECT      a.CUST_NO
              ,a.CUST_NAME
			  ,a.BRH_NO
			  ,a.BRH_NAME
			  ,a.CTCT_TEL
			  ,a.PHONE
			  ,a.ORDI_OPNAC_DT
			  ,c.PSN_CGY
			  ,c.PSN_NAME
	FROM       DDW_PROD.T_DDW_F00_CUST_CUST_INFO  a
    INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH         b
    ON         a.BRH_NO = b.BRH_NO
    AND        b.BELTO_FILIL_CDG = '0032'
    AND        b.BUS_DATE = %d{yyyyMMdd}
	LEFT JOIN DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP8 c
	ON        a.CUST_NO = c.CUST_NO
	WHERE a.BUS_DATE = %d{yyyyMMdd}
    AND   a.ORDI_CUST_STAT < > '3'
    AND   a.ORDI_OPNAC_DT > = 20190101 ;
	
----已经成为有效客户
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP10 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP10 as 
   SELECT * FROM DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON ;
----插入数据  
  INSERT  OVERWRITE  DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON
         (         CUST_NO          --客户号 
                  ,CUST_NAME        --客户姓名  
                  ,BRH_NO           --营业部编号
                  ,BRH_NAME         --营业部名称        
                  ,CTCT_TEL         --电话      
                  ,PHONE            --手机    
                  ,ORDI_OPNAC_DT    --开户日期    
                  ,PSN_CGY          --关系类别
                  ,PSN_NAME         --员工姓名  
          )	PARTITION(YEAR_MON)							   
   
   SELECT      t.CUST_NO
              ,a1.CUST_NAME
			  ,a1.BRH_NO
			  ,a1.BRH_NAME
			  ,a1.CTCT_TEL
			  ,a1.PHONE
			  ,a1.ORDI_OPNAC_DT
			  ,a1.PSN_CGY
			  ,a1.PSN_NAME
              ,t.YEAR_MON as YEAR_MON		  
   FROM (SELECT  CUST_NO
                ,MIN(YEAR_MON)  as YEAR_MON
         FROM   DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP4
		 GROUP BY CUST_NO
		 )   t
  INNER JOIN (SELECT CUST_NO
                    ,MAX(CUST_NAME)      as CUST_NAME
					,MAX(BRH_NO)         as BRH_NO
					,MAX(BRH_NAME)       as BRH_NAME
					,MAX(CTCT_TEL)       as CTCT_TEL
					,MAX(PHONE)          as PHONE
					,MAX(ORDI_OPNAC_DT)  as ORDI_OPNAC_DT
					,MAX(PSN_CGY)        as PSN_CGY
					,MAX(PSN_NAME)       as PSN_NAME
              FROM DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP9
			  GROUP BY CUST_NO) a1
  ON         t.CUST_NO = a1.CUST_NO
  WHERE NOT EXISTS(SELECT 1 FROM DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP10 b
                   WHERE t.CUST_NO = b.CUST_NO
                 )
  UNION ALL 
  SELECT       t.CUST_NO
              ,t.CUST_NAME
			  ,t.BRH_NO
			  ,t.BRH_NAME
			  ,t.CTCT_TEL
			  ,t.PHONE
			  ,t.ORDI_OPNAC_DT
			  ,t.PSN_CGY
			  ,t.PSN_NAME
              ,t.YEAR_MON as YEAR_MON		  
   FROM DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP10 t;
   --
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP ;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP1 ;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP2 ;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP3 ;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP4 ;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP5 ;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP6 ;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP7 ;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP8 ;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP9 ;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON_TEMP10 ;
     invalidate metadata DDW_PROD.T_DDW_PRT_WZ_VLD_CUST_MON ;
  --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户对账单年表                                                        */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-02-02                                                                        */ 
-------------------------------删除今天的数据------------------------------
ALTER TABLE DDW_PROD.T_DDW_CUST_STATMT_YEAR DROP IF EXISTS PARTITION   (YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT));
------------------------------------删除今天的数据结束------------------------------
----创建临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP as 
 SELECT       CUST_NO
             ,SUM(DECODE(t.YEAR_MON,CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'01') as INT),t.TOL_AST_START_M,0)) as TOL_AST_STRT                --期初资产
			 ,SUM(DECODE(t.YEAR_MON,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT),t.TOL_AST_END_M,0))   as TOL_AST_FNL                 --期末资产
			 ,SUM(DECODE(t.YEAR_MON,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT),t.TOL_GL_END_M,0))       as TOL_GL_FNL                  --期末负债
			 ,SUM(DECODE(t.YEAR_MON,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT),t.CPTL_BAL_END_M,0))  as CPTL_BAL_FNL                --期末资金余额
			 ,SUM(DECODE(t.YEAR_MON,CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT),t.UPNY_BAL_END_M,0))  as UPNY_BAL_FNL                --期末在途资金
			 ,SUM(TOL_YLD)                                       as TOL_YLD             --总的收益
			 ,SUM(STK_YLD)                   	                 as STK_YLD             --股票收益
             ,SUM(MNY_PROD_YLD)              	                 as MNY_PROD_YLD        --理财产品收益
             ,SUM(WRNT_YLD)                  	                 as WRNT_YLD            --期权收益
             ,SUM(OTH_YLD)                   	                 as OTH_YLD             --其他收益
             ,SUM(TFR_IN_MKTVAL)             	                 as TFR_IN_MKTVAL       --转入市值
             ,SUM(TURN_OUT_MKTVAL)           	                 as TURN_OUT_MKTVAL     --转出市值
             ,SUM(NET_FLW_IN_AMT)            	                 as NET_FLW_IN_AMT      --净流入资金
             ,SUM(TFR_IN_AMT)                	                 as TFR_IN_AMT          --转入资金
             ,SUM(TURN_OUT_AMT)              	                 as TURN_OUT_AMT        --转出资金
			 ,SUM(NVL(t.LOT_SH_STK,0)+NVL(t.LOT_SZ_STK,0))       as LOT_STK             --中签股票数
			 ,SUM(NVL(t.STK_TRD_VOL,0))                          as STK_TRD_VOL         --股票交易量
			 ,SUM(NVL(t.STK_BUYIN_TMS,0))                        as STK_BUYIN_TMS       --股票买入交易次数
			 ,SUM(NVL(STK_SELL_TMS,0))                           as STK_SELL_TMS        --股票卖出交易次数			 
 FROM        DDW_PROD.T_DDW_CUST_STATMT_MON t
 WHERE       SUBSTR(CAST(YEAR_MON as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
 GROUP BY    t.CUST_NO
 ;

---------持有股票的只数 创建临时表
 DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP1;
 CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP1
 as     SELECT a.CUST_NO
              ,SUM(CASE WHEN a.EXG IN ('SH','HB','HK','SZ','SB','SK')
	                    THEN 1
			            ELSE 0
			            END
		          )    as HLD_STK                   --持有的股票个数
        FROM  (SELECT      a.CUST_NO,a.EXG,a.SEC_CD 
               FROM        DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS  a
			   LEFT JOIN  (SELECT  EXG
	                              ,SEC_CD_PFX
				           FROM  DDW_PROD.T_DDW_CFG_SEC_TRD_CL
						   WHERE SEC_CL_CD IN ('001','002','003','004','005','063','015','016','012','013')  ---- 
				              OR   SEC_CL_CD BETWEEN '017' AND '053'
				              OR   SEC_CL_CD BETWEEN '054' AND '062'
				           GROUP BY EXG,SEC_CD_PFX,SEC_CL_CD
			               )                                b
               ON        a.EXG = b.EXG
               AND       SUBSTR(a.SEC_CD,1,3) = b.SEC_CD_PFX
              WHERE      a.BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'0101') as INT)
              AND        a.BUS_DATE < = %d{yyyyMMdd}			 
	          AND        a.EXG IN ('SH','SZ','HK','SK','HB','SB')
              AND        b.EXG IS NOT NULL
              GROUP BY   CUST_NO,EXG,SEC_CD
             )  a
        GROUP BY a.CUST_NO;  
----- 
   DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP3;
   CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP3
   AS SELECT        SUM(TOL_AST)  as TOL_AST --总资产				 
				   ,CUST_NO
				   ,AVG(TOL_AST+TURN_OUT_MKTVAL+TURN_OUT_AMT)  as TOL_AST_AVG --平均资产
				   ,AVG(net_incm) as net_incm_avg --平均收益率
				   ,COUNT(1)   as DAYS   --天数
      FROM         DDW_PROD.T_DDW_CUST_STATMT_DAY a  
      WHERE        a.BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'0101') as INT)
      AND          a.BUS_DATE < = %d{yyyyMMdd}
      GROUP BY     a.CUST_NO	  
 ;	  
  
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP4;
   CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP4 as
  SELECT      COUNT(1) as TOL_RANK
              ,2017    as YEAR
  FROM        DDW_PROD.T_DDW_F00_CUST_CUST_INFO  t
  LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP   a1
  ON          t.CUST_NO = a1.CUST_NO  
  LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP3    a4
  ON          t.CUST_NO = a4.CUST_NO
  LEFT JOIN   DDW_PROD.T_DDW_INR_ORG_BRH   a11
  ON          t.BRH_NO = a11.BRH_NO
  AND         a11.BUS_DATE = %d{yyyyMMdd}  
  WHERE       a11.BRH_NO IS NOT NULL
  AND         t.CUST_NO < > '100610335855'
  AND        (t.ORDI_CUST_STAT < > '3' OR ORDI_CNCLACT_DT > %d{yyyyMMdd})
  AND        (NVL(a4.TOL_AST_AVG,0) > 100 OR (NVL(a4.TOL_AST_AVG,0)> = 0 AND NVL(a1.TOL_YLD,0)< > 0))
  AND         t.BUS_DATE = %d{yyyyMMdd}
  GROUP BY   YEAR;		
 ---
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP5;
   CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP5 as
  SELECT     ROW_NUMBER() OVER(ORDER BY NVL(a1.TOL_YLD,0)/DECODE(NVL(a4.TOL_AST_AVG,0),0,9999999999,NVL(a4.TOL_AST_AVG,0)) DESC) as YLD_RANK
             ,t.CUST_NO
  FROM        DDW_PROD.T_DDW_F00_CUST_CUST_INFO  t
  LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP   a1
  ON          t.CUST_NO = a1.CUST_NO
  LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP3    a4
  ON          t.CUST_NO = a4.CUST_NO 
  LEFT JOIN   DDW_PROD.T_DDW_INR_ORG_BRH   a11
  ON          t.BRH_NO = a11.BRH_NO
  AND         a11.BUS_DATE = %d{yyyyMMdd}   
  WHERE       a11.BRH_NO is not null
  AND         t.CUST_NO < > '100610335855'
  AND        (t.ORDI_CUST_STAT < > '3' OR ORDI_CNCLACT_DT > %d{yyyyMMdd})
  AND        (NVL(a4.TOL_AST_AVG,0) > 100 OR NVL(a1.TOL_YLD,0)< > 0)
  AND        t.BUS_DATE  = %d{yyyyMMdd}; 
  
  -------波动率指标
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP6;
   CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP6 as
  SELECT        SQRT((t.net_incm_sum*250*1.000000/(t.DAYS-1))) as DT_RTO
                ,t.CUST_NO
	FROM 
  (SELECT        SUM(POWER((t.net_incm-a1.net_incm_avg),2)) as net_incm_sum
                ,t.CUST_NO
				,a1.DAYS
   FROM         DDW_PROD.T_DDW_CUST_STATMT_DAY   t
   LEFT JOIN    DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP3  a1
   ON           t.CUST_NO = a1.CUST_NO
   WHERE        t.BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'0101') as INT)
   AND          t.BUS_DATE < = %d{yyyyMMdd}
   AND          a1.CUST_NO IS NOT NULL
   GROUP BY     t.CUST_NO,a1.DAYS) t ;
--  

 INSERT OVERWRITE DDW_PROD.T_DDW_CUST_STATMT_YEAR
(
                                  
			CUST_NO                     --客户号         
           ,CUST_NAME                   --客户姓名           
		   ,BRH_NO                      --营业部编号         
		   ,BRH_NAME                    --营业部名称         
		   ,TOL_AST_STRT                --期初资产          
           ,TOL_AST_FNL                 --期末资产
           ,TOL_GL_FNL                  --期末负债
           ,CPTL_BAL_FNL                --期末资金余额
           ,UPNY_BAL_FNL                --期末在途资金
		   ,TOL_YLD                     --总的收益
		   ,STK_YLD                     --股票收益
           ,MNY_PROD_YLD                --理财产品收益
           ,WRNT_YLD                    --期权收益
           ,OTH_YLD                     --其他收益
           ,TFR_IN_MKTVAL               --转入市值
           ,TURN_OUT_MKTVAL             --转出市值
           ,NET_FLW_IN_AMT              --净流入资金
           ,TFR_IN_AMT                  --转入资金
           ,TURN_OUT_AMT                --转出资金
           ,LOT_STK                     --中签股票(只)
           ,STK_BUYIN_TMS               --股票买入交易次数
		   ,STK_SELL_TMS                --股票卖出交易次数
           ,NET_INCM                    --收益率
		   ,HLD_STK                     --持有股票(只)
		   ,AST_RANK                    --资产排名
		   ,TRD_RANK                    --交易排名
		   ,YLD_RANK                    --收益排名
		   ,YLD_RANK_RTO                --收益排名战胜率
		   ,DT_RTO                      --波动率
           ,ETL_DT                      --加载日期    	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )	
   SELECT      t.CUST_NO   	                 as CUST_NO                 --客户号          
              ,t.CUST_NAME                   as CUST_NAME            	--客户姓名              
              ,t.BRH_NO                      as BRH_NO          	    --营业部编号            
              ,t.BRH_NAME                    as BRH_NAME            	--营业部名称            
              ,NVL(a1.TOL_AST_STRT,0)        as TOL_AST_STRT            --年初总资产
              ,NVL(a1.TOL_AST_FNL,0)         as TOL_AST_FNL             --年末总资产
              ,NVL(a1.TOL_GL_FNL,0)          as TOL_GL_FNL              --年末负债
              ,NVL(a1.CPTL_BAL_FNL,0)        as CPTL_BAL_FNL            --年末资金余额
              ,NVL(a1.UPNY_BAL_FNL,0)        as UPNY_BAL_FNL            --年末在途资金
              ,NVL(a1.TOL_YLD,0)             as TOL_YLD                 --总的收益
              ,NVL(a1.STK_YLD,0)             as STK_YLD                 --股票收益
              ,NVL(a1.MNY_PROD_YLD,0)        as MNY_PROD_YL             --理财产品收益
              ,NVL(a1.WRNT_YLD,0)            as WRNT_YLD                --期权收益
              ,NVL(a1.OTH_YLD,0)             as OTH_YLD                 --其他收益
              ,NVL(a1.TFR_IN_MKTVAL,0)       as TFR_IN_MKTVAL           --转入市值
              ,NVL(a1.TURN_OUT_MKTVAL,0)     as TURN_OUT_MKTVAL         --转出市值
              ,NVL(a1.NET_FLW_IN_AMT,0)      as NET_FLW_IN_AMT          --净流入资金
              ,NVL(a1.TFR_IN_AMT,0)          as TFR_IN_AM               --转入资金
              ,NVL(a1.TURN_OUT_AMT,0)        as TURN_OUT_AMT            --转出资金
              ,NVL(a1.LOT_STK,0)             as LOT_STK                 --中签股票数
              ,NVL(a1.STK_BUYIN_TMS,0)       as STK_BUYIN_TMS           --股票买入交易次数
              ,NVL(a1.STK_SELL_TMS,0)        as STK_SELL_TMS            --股票卖出交易次数
			  ,CAST(NVL(a1.TOL_YLD,0)*1.000000/NVL(a4.TOL_AST_AVG,0) as DECIMAL(38,6))*100 as NET_INCM --收益率
			  ,NVL(a2.HLD_STK,0)             as HLD_STK                  --持有的股票个数						  
			  ,ROW_NUMBER() OVER(ORDER BY NVL(a1.TOL_AST_FNL,0) DESC)    as AST_RANK                   --资产排名
			  ,ROW_NUMBER() OVER(ORDER BY NVL(a1.STK_TRD_VOL,0) DESC)      as TRD_RANK                   --交易排名
			  ,a6.YLD_RANK                        as YLD_RANK        --收益排名
			  ,(CAST((a5.TOL_RANK-a6.YLD_RANK)*1.000000/a5.TOL_RANK as DECIMAL(38,6)))*100 as YLD_RANK_RTO                      --收益排名战胜率 
			  ,(NVL(CAST(ROUND(a7.DT_RTO,3) as DECIMAL(38,3)),0))*100              as DT_RTO                      --波动率
              ,%d{yyyyMMdd}                   as ETL_DT                      --加载日期
  FROM        (SELECT CUST_NO,BRH_NO,BRH_NAME,CUST_NAME,ORDI_CNCLACT_DT,ORDI_CUST_STAT,2017 as YEAR FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO
               WHERE BUS_DATE = %d{yyyyMMdd} 
              )  t
  LEFT JOIN    DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP   a1
  ON          t.CUST_NO = a1.CUST_NO   
  LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP1    a2
  ON          t.CUST_NO = a2.CUST_nO
  LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP3    a4
  ON          t.CUST_NO = a4.CUST_NO   
  LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP4    a5
  ON          t.YEAR = a5.YEAR
  LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP5    a6
  ON          t.CUST_NO = a6.CUST_NO
  LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP6    a7
  ON          t.CUST_NO = a7.CUST_NO
  LEFT JOIN   DDW_PROD.T_DDW_INR_ORG_BRH   a11
  ON          t.BRH_NO = a11.BRH_NO
  AND         a11.BUS_DATE = %d{yyyyMMdd} 
  WHERE       a11.BRH_NO IS NOT NULL
  AND         t.CUST_NO < > '100610335855'
  AND        (t.ORDI_CUST_STAT < > '3' OR t.ORDI_CNCLACT_DT > %d{yyyyMMdd})
  AND        (NVL(a4.TOL_AST_AVG,0) > 100 OR (NVL(a4.TOL_AST_AVG,0)> = 0 AND NVL(a1.TOL_YLD,0)< > 0))
 ;

 --删除临时表
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP;
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP1;
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP2;
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP3;
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP4;
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP5; 
  DROP TABLE  IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_YEAR_TEMP6;

-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_STATMT_YEAR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_CUST_STATMT_YEAR;  		

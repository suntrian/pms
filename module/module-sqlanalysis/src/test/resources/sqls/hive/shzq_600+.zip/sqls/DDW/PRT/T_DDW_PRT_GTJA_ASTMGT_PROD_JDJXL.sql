 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:国君自管产品君得金系列                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 

--DDW_PROD.T_DDW_PRT_GTJA_ASTMGT_PROD_JDJXL
--------插入数据开始-----------
------插入营业部
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_GTJA_ASTMGT_PROD_JDJXL
(
								 BELTO_FILIL                   --地区
								,BRH_NO 					   --营业部编号
								,BRH_NAME                      --营业部名称
								,PRCH_952222_7                 --申购_952222_7
								,RTAN_AMT_GT_952222_7          --累计保有量_952222_7
								,ASS_INCM_952222_7             --考核收入_952222_7
                                ,PRCH_952223_28                --申购_952223_28
								,RTAN_AMT_GT_952223_28         --累计保有量_952223_28
								,ASS_INCM_952223_28            --考核收入_952223_28
								,PRCH_952224_28                --申购_952224_28
								,RTAN_AMT_GT_952224_28         --累计保有量_952224_28
								,ASS_INCM_952224_28            --考核收入_952224_28
								,PRCH_952225_28                --申购_952225_28
								,RTAN_AMT_GT_952225_28         --累计保有量_952225_28
								,ASS_INCM_952225_28            --考核收入_952225_28
								,PRCH_952226_28                --申购_952226_28
								,RTAN_AMT_GT_952226_28         --累计保有量_952226_28
								,ASS_INCM_952226_28            --考核收入_952226_28
								,PRCH_28                       --申购汇总_28
								,RTAN_AMT_GT_28                --累计保有量汇总_28
								,ASS_INCM_28                   --考核收入汇总_28
								,PRCH_952227_91                --申购_952227_91
								,RTAN_AMT_GT_952227_91         --累计保有量_952227_91
								,ASS_INCM_952227_91            --考核收入_952227_91
								,PRCH_952228_91                --申购_952228_91
								,RTAN_AMT_GT_952228_91         --累计保有量_952228_91
								,ASS_INCM_952228_91            --考核收入_952228_91
								,PRCH_952229_91                --申购_952229_91
								,RTAN_AMT_GT_952229_91         --累计保有量_952229_91
								,ASS_INCM_952229_91            --考核收入_952229_91
								,PRCH_91                       --申购汇总_91
								,RTAN_AMT_GT_91                --累计保有量汇总_91
								,ASS_INCM_91                   --考核收入汇总_91	
								,PRCH_952230_182               --申购_952230_182
								,RTAN_AMT_GT_952230_182        --累计保有量_952230_182
								,ASS_INCM_952230_182           --考核收入_952230_182
								,PRCH_952231_182               --申购_952231_182
								,RTAN_AMT_GT_952231_182        --累计保有量_952231_182
								,ASS_INCM_952231_182           --考核收入_952231_182
								,PRCH_952232_182               --申购_952232_182
								,RTAN_AMT_GT_952232_182        --累计保有量_952232_182
								,ASS_INCM_952232_182           --考核收入_952232_182
								,PRCH_952233_182                --申购_952233_182	
								,RTAN_AMT_GT_952233_182        --累计保有量_952233_182
								,ASS_INCM_952233_182           --考核收入_952233_182
								,PRCH_952234_182               --申购_952234_182
								,RTAN_AMT_GT_952234_182        --累计保有量_952234_182
								,ASS_INCM_952234_182           --考核收入_952234_182
								,PRCH_952235_182               --申购_952235_182
								,RTAN_AMT_GT_952235_182        --累计保有量_952235_182
								,ASS_INCM_952235_182           --考核收入_952235_182
								,PRCH_182                      --申购汇总_182
								,RTAN_AMT_GT_182               --累计保有量汇总_182
								,ASS_INCM_182                  --考核收入汇总_182
								,PRCH_952280_365               --申购_952280_365
								,RTAN_AMT_GT_952280_365        --累计保有量_952280_365
								,ASS_INCM_952280_365           --考核收入_952280_365
								,PRCH_952281_365               --申购_952281_365
								,RTAN_AMT_GT_952281_365        --累计保有量_952281_365
								,ASS_INCM_952281_365           --考核收入_952281_365
								,PRCH_952282_365               --申购_952282_365
								,RTAN_AMT_GT_952282_365        --累计保有量_952282_365
								,ASS_INCM_952282_365           --考核收入_952282_365								
								,PRCH_952283_365                --申购_952283_365								
								,RTAN_AMT_GT_952283_365        --累计保有量_952283_365
								,ASS_INCM_952283_365           --考核收入_952283_365
								,PRCH_952284_365               --申购_952284_365
								,RTAN_AMT_GT_952284_365        --累计保有量_952284_365
								,ASS_INCM_952284_365           --考核收入_952284_365
								,PRCH_952285_365               --申购_952285_365
								,RTAN_AMT_GT_952285_365        --累计保有量_952285_365
								,ASS_INCM_952285_365           --考核收入_952285_365
								,PRCH_952286_365               --申购_952286_365
								,RTAN_AMT_GT_952286_365        --累计保有量_952286_365
								,ASS_INCM_952286_365           --考核收入_952286_365
								,PRCH_952287_365               --申购_952287_365
								,RTAN_AMT_GT_952287_365        --累计保有量_952287_365
								,ASS_INCM_952287_365           --考核收入_952287_365
								,PRCH_952288_365               --申购_952288_365
								,RTAN_AMT_GT_952288_365        --累计保有量_952288_365
								,ASS_INCM_952288_365           --考核收入_952288_365								
								,PRCH_952289_365               --申购_952289_365								
								,RTAN_AMT_GT_952289_365        --累计保有量_952289_365
								,ASS_INCM_952289_365           --考核收入_952289_365
								,PRCH_952290_365               --申购_952290_365
								,RTAN_AMT_GT_952290_365        --累计保有量_952290_365
								,ASS_INCM_952290_365           --考核收入_952290_365
								,PRCH_952291_365               --申购_952291_365
								,RTAN_AMT_GT_952291_365        --累计保有量_952291_365
								,ASS_INCM_952291_365           --考核收入_952291_365
								,PRCH_365                      --申购汇总_365
								,RTAN_AMT_GT_365               --累计保有量汇总_365
								,ASS_INCM_365                  --考核收入汇总_365
								,PRCH_952236                   --申购_952236
								,RTAN_AMT_GT_952236            --累计保有量_952236
								,ASS_INCM_952236               --考核收入_952236
								,PRCH                          --申购汇总
								,RTAN_AMT_GT                   --累计保有量汇总
								,ASS_INCM                      --收益考核汇总
								)		
 PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT 
								 t.BELTO_FILIL      as BELTO_FILIL    --地区
								,t.BRH_NO 			as BRH_NO		  --营业部编号
								,t.BRH_SHRTNM       as BRH_NAME       --营业部名称
								,ROUND(SUM(DECODE(a1.PROD_CD,'952222',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952222_7                --申购_952222_7
								,ROUND(SUM(DECODE(a1.PROD_CD,'952222',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952222_7         --累计保有量_952222_7
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952222',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952222_7            --考核收入_952222_7
		                        ,ROUND(SUM(DECODE(a1.PROD_CD,'952223',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952223_28               --申购_952223_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952223',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952223_28        --累计保有量_952223_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952223',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952223_28           --考核收入_952223_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952224',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952224_28               --申购_952224_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952224',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952224_28        --累计保有量_952224_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952224',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952224_28           --考核收入_952224_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952225',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952225_28               --申购_952225_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952225',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952225_28        --累计保有量_952225_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952225',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952225_28           --考核收入_952225_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952226',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952226_28               --申购_952226_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952226',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952226_28        --累计保有量_952226_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952226',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952226_28           --考核收入_952226_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952223','952224','952225','952226')
								                THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									            ELSE 0
									            END
									   ),6)                                                                                               as PRCH_28               --申购汇总_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952223','952224','952225','952226')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_28        --累计保有量汇总_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952223','952224','952225','952226')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_28                  --考核收入汇总_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952227',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952227_91                --申购_952227_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952227',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952227_91        --累计保有量_952227_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952227',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952227_91           --考核收入_952227_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952228',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952228_91               --申购_952228_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952228',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952228_91        --累计保有量_952228_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952228',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952228_91           --考核收入_952228_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952229',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952229_91               --申购_952229_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952229',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952229_91        --累计保有量_952229_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952229',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952229_91           --考核收入_952229_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952227','952228','952229')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_91               --申购汇总_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952227','952228','952229')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									) ,6)                                                                       as RTAN_AMT_GT_91        --累计保有量汇总_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952227','952228','952229')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_91               --考核收入汇总_91	
                                ,ROUND(SUM(DECODE(a1.PROD_CD,'952230',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952230_182               --申购_952230_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952230',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952230_182        --累计保有量_952230_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952230',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952230_182           --考核收入_952230_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952231',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952231_182               --申购_952231_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952231',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952231_182        --累计保有量_952231_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952231',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952231_182           --考核收入_952231_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952232',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952232_182               --申购_952232_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952232',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952232_182        --累计保有量_952232_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952232',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952232_182           --考核收入_952232_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952233',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952233_182                --申购_952233_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952233',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952233_182        --累计保有量_952233_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952233',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952233_182           --考核收入_952233_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952234',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952234_182               --申购_952234_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952234',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952234_182        --累计保有量_952234_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952234',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952234_182           --考核收入_952234_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952235',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952235_182               --申购_952235_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952235',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952235_182        --累计保有量_952235_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952235',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952235_182           --考核收入_952235_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952230','952231','952232','952233','952234','952235')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_182               --申购汇总_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952230','952231','952232','952233','952234','952235')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_182        --累计保有量汇总_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952230','952231','952232','952233','952234','952235')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_182               --考核收入汇总_182
                                ,ROUND(SUM(DECODE(a1.PROD_CD,'952280',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952280_365               --申购_952280_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952280',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952280_365        --累计保有量_952280_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952280',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952280_365           --考核收入_952280_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952281',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952281_365               --申购_952281_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952281',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952281_365        --累计保有量_952281_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952281',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952281_365           --考核收入_952281_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952282',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952282_365               --申购_952282_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952282',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952282_365        --累计保有量_952282_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952282',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952282_365           --考核收入_952282_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952283',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952283_365                --申购_952283_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952283',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952283_365        --累计保有量_952283_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952283',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952283_365           --考核收入_952283_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952284',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952284_365               --申购_952284_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952284',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952284_365        --累计保有量_952284_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952284',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952284_365           --考核收入_952284_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952285',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952285_365               --申购_952285_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952285',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952285_365        --累计保有量_952285_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952285',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952285_365           --考核收入_952285_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952286',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952286_365               --申购_952286_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952286',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952286_365        --累计保有量_952286_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952286',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952286_365           --考核收入_952286_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952287',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000) ,6)              as PRCH_952287_365               --申购_952287_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952287',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000) ,6)       as RTAN_AMT_GT_952287_365        --累计保有量_952287_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952287',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952287_365           --考核收入_952287_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952288',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952288_365               --申购_952288_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952288',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952288_365        --累计保有量_952288_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952288',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952288_365           --考核收入_952288_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952289',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952289_365               --申购_952289_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952289',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952289_365        --累计保有量_952289_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952289',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952289_365           --考核收入_952289_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952290',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952290_365               --申购_952290_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952290',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952290_365        --累计保有量_952290_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952290',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952290_365           --考核收入_952290_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952291',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952291_365               --申购_952291_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952291',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952291_365        --累计保有量_952291_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952291',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952291_365           --考核收入_952291_365
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_365               --申购汇总_365
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_365        --累计保有量汇总_365
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_365               --考核收入汇总_365
                                ,ROUND(SUM(DECODE(a1.PROD_CD,'952236',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952236               --申购_952236
								,ROUND(SUM(DECODE(a1.PROD_CD,'952236',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952236        --累计保有量_952236
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952236',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952236           --考核收入_952236
                                ,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH              --申购汇总
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									) ,6)                                                                       as RTAN_AMT_GT       --累计保有量汇总
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                         as ASS_INCM         --考核收入汇总
  FROM  		DDW_PROD.T_DDW_INR_ORG_BRH 	           t
  LEFT JOIN     DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON   a1
  ON            t.BRH_NO = a1.BRH_NO
  AND           a1.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
  AND           CAST(a1.YEAR_MON as STRING) = SUBSTR('%d{yyyyMMdd}',1,6)
  WHERE         t.BUS_DATE = %d{yyyyMMdd}
  GROUP BY BELTO_FILIL,BRH_NO,BRH_NAME 
---插入分公司
  UNION  ALL
   SELECT 
								 t.BELTO_FILIL       as BELTO_FILIL    --地区
								,t.BELTO_FILIL 		 as BRH_NO		  --营业部编号
								,t.BELTO_FILIL       as BRH_NAME       --营业部名称
								,ROUND(SUM(DECODE(a1.PROD_CD,'952222',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952222_7                --申购_952222_7
								,ROUND(SUM(DECODE(a1.PROD_CD,'952222',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952222_7         --累计保有量_952222_7
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952222',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952222_7            --考核收入_952222_7
		                        ,ROUND(SUM(DECODE(a1.PROD_CD,'952223',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952223_28               --申购_952223_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952223',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952223_28        --累计保有量_952223_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952223',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952223_28           --考核收入_952223_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952224',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952224_28               --申购_952224_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952224',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952224_28        --累计保有量_952224_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952224',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952224_28           --考核收入_952224_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952225',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952225_28               --申购_952225_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952225',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952225_28        --累计保有量_952225_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952225',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952225_28           --考核收入_952225_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952226',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952226_28               --申购_952226_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952226',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952226_28        --累计保有量_952226_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952226',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952226_28           --考核收入_952226_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952223','952224','952225','952226')
								                THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									            ELSE 0
									            END
									   ),6)                                                                                               as PRCH_28               --申购汇总_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952223','952224','952225','952226')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_28        --累计保有量汇总_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952223','952224','952225','952226')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_28                  --考核收入汇总_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952227',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952227_91                --申购_952227_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952227',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952227_91        --累计保有量_952227_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952227',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952227_91           --考核收入_952227_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952228',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952228_91               --申购_952228_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952228',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952228_91        --累计保有量_952228_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952228',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952228_91           --考核收入_952228_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952229',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952229_91               --申购_952229_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952229',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952229_91        --累计保有量_952229_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952229',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952229_91           --考核收入_952229_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952227','952228','952229')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_91               --申购汇总_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952227','952228','952229')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									) ,6)                                                                       as RTAN_AMT_GT_91        --累计保有量汇总_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952227','952228','952229')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_91               --考核收入汇总_91	
                                ,ROUND(SUM(DECODE(a1.PROD_CD,'952230',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952230_182               --申购_952230_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952230',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952230_182        --累计保有量_952230_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952230',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952230_182           --考核收入_952230_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952231',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952231_182               --申购_952231_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952231',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952231_182        --累计保有量_952231_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952231',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952231_182           --考核收入_952231_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952232',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952232_182               --申购_952232_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952232',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952232_182        --累计保有量_952232_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952232',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952232_182           --考核收入_952232_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952233',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952233_182                --申购_952233_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952233',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952233_182        --累计保有量_952233_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952233',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952233_182           --考核收入_952233_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952234',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952234_182               --申购_952234_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952234',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952234_182        --累计保有量_952234_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952234',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952234_182           --考核收入_952234_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952235',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952235_182               --申购_952235_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952235',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952235_182        --累计保有量_952235_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952235',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952235_182           --考核收入_952235_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952230','952231','952232','952233','952234','952235')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_182               --申购汇总_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952230','952231','952232','952233','952234','952235')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_182        --累计保有量汇总_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952230','952231','952232','952233','952234','952235')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_182               --考核收入汇总_182
                                ,ROUND(SUM(DECODE(a1.PROD_CD,'952280',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952280_365               --申购_952280_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952280',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952280_365        --累计保有量_952280_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952280',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952280_365           --考核收入_952280_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952281',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952281_365               --申购_952281_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952281',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952281_365        --累计保有量_952281_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952281',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952281_365           --考核收入_952281_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952282',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952282_365               --申购_952282_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952282',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952282_365        --累计保有量_952282_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952282',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952282_365           --考核收入_952282_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952283',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952283_365                --申购_952283_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952283',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952283_365        --累计保有量_952283_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952283',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952283_365           --考核收入_952283_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952284',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952284_365               --申购_952284_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952284',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952284_365        --累计保有量_952284_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952284',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952284_365           --考核收入_952284_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952285',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952285_365               --申购_952285_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952285',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952285_365        --累计保有量_952285_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952285',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952285_365           --考核收入_952285_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952286',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952286_365               --申购_952286_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952286',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952286_365        --累计保有量_952286_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952286',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952286_365           --考核收入_952286_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952287',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000) ,6)              as PRCH_952287_365               --申购_952287_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952287',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000) ,6)       as RTAN_AMT_GT_952287_365        --累计保有量_952287_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952287',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952287_365           --考核收入_952287_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952288',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952288_365               --申购_952288_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952288',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952288_365        --累计保有量_952288_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952288',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952288_365           --考核收入_952288_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952289',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952289_365               --申购_952289_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952289',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952289_365        --累计保有量_952289_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952289',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952289_365           --考核收入_952289_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952290',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952290_365               --申购_952290_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952290',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952290_365        --累计保有量_952290_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952290',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952290_365           --考核收入_952290_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952291',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952291_365               --申购_952291_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952291',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952291_365        --累计保有量_952291_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952291',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952291_365           --考核收入_952291_365
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_365               --申购汇总_365
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_365        --累计保有量汇总_365
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_365               --考核收入汇总_365
                                ,ROUND(SUM(DECODE(a1.PROD_CD,'952236',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952236               --申购_952236
								,ROUND(SUM(DECODE(a1.PROD_CD,'952236',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952236        --累计保有量_952236
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952236',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952236           --考核收入_952236
                                ,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH              --申购汇总
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									) ,6)                                                                       as RTAN_AMT_GT       --累计保有量汇总
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                         as ASS_INCM         --考核收入汇总
  FROM  		DDW_PROD.T_DDW_INR_ORG_BRH 	           t
  LEFT JOIN     DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON   a1
  ON            t.BRH_NO = a1.BRH_NO
  AND           a1.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
  AND           CAST(a1.YEAR_MON as STRING) = SUBSTR('%d{yyyyMMdd}',1,6)
  WHERE         t.BUS_DATE = %d{yyyyMMdd}
  GROUP BY BELTO_FILIL,BRH_NO,BRH_NAME 
  ---插入分公司
  UNION  ALL
   SELECT 
								 '上海证券总计'      as BELTO_FILIL    --地区
								,'上海证券总计' 	 as BRH_NO		  --营业部编号
								,'上海证券总计'      as BRH_NAME       --营业部名称
								,ROUND(SUM(DECODE(a1.PROD_CD,'952222',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952222_7                --申购_952222_7
								,ROUND(SUM(DECODE(a1.PROD_CD,'952222',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952222_7         --累计保有量_952222_7
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952222',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952222_7            --考核收入_952222_7
		                        ,ROUND(SUM(DECODE(a1.PROD_CD,'952223',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952223_28               --申购_952223_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952223',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952223_28        --累计保有量_952223_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952223',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952223_28           --考核收入_952223_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952224',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952224_28               --申购_952224_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952224',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952224_28        --累计保有量_952224_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952224',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952224_28           --考核收入_952224_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952225',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952225_28               --申购_952225_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952225',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952225_28        --累计保有量_952225_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952225',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952225_28           --考核收入_952225_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952226',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952226_28               --申购_952226_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952226',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)                      as RTAN_AMT_GT_952226_28        --累计保有量_952226_28
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952226',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)                 as ASS_INCM_952226_28           --考核收入_952226_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952223','952224','952225','952226')
								                THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									            ELSE 0
									            END
									   ),6)                                                                                               as PRCH_28               --申购汇总_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952223','952224','952225','952226')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_28        --累计保有量汇总_28
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952223','952224','952225','952226')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_28                  --考核收入汇总_28
								,ROUND(SUM(DECODE(a1.PROD_CD,'952227',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952227_91                --申购_952227_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952227',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952227_91        --累计保有量_952227_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952227',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952227_91           --考核收入_952227_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952228',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952228_91               --申购_952228_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952228',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952228_91        --累计保有量_952228_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952228',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952228_91           --考核收入_952228_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952229',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952229_91               --申购_952229_91
								,ROUND(SUM(DECODE(a1.PROD_CD,'952229',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952229_91        --累计保有量_952229_91
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952229',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952229_91           --考核收入_952229_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952227','952228','952229')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_91               --申购汇总_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952227','952228','952229')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									) ,6)                                                                       as RTAN_AMT_GT_91        --累计保有量汇总_91
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952227','952228','952229')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_91               --考核收入汇总_91	
                                ,ROUND(SUM(DECODE(a1.PROD_CD,'952230',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952230_182               --申购_952230_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952230',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952230_182        --累计保有量_952230_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952230',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952230_182           --考核收入_952230_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952231',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952231_182               --申购_952231_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952231',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952231_182        --累计保有量_952231_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952231',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952231_182           --考核收入_952231_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952232',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952232_182               --申购_952232_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952232',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952232_182        --累计保有量_952232_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952232',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952232_182           --考核收入_952232_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952233',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952233_182                --申购_952233_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952233',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952233_182        --累计保有量_952233_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952233',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952233_182           --考核收入_952233_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952234',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952234_182               --申购_952234_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952234',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952234_182        --累计保有量_952234_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952234',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952234_182           --考核收入_952234_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952235',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952235_182               --申购_952235_182
								,ROUND(SUM(DECODE(a1.PROD_CD,'952235',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952235_182        --累计保有量_952235_182
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952235',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952235_182           --考核收入_952235_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952230','952231','952232','952233','952234','952235')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_182               --申购汇总_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952230','952231','952232','952233','952234','952235')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_182        --累计保有量汇总_182
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952230','952231','952232','952233','952234','952235')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_182               --考核收入汇总_182
                                ,ROUND(SUM(DECODE(a1.PROD_CD,'952280',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952280_365               --申购_952280_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952280',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952280_365        --累计保有量_952280_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952280',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952280_365           --考核收入_952280_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952281',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952281_365               --申购_952281_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952281',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952281_365        --累计保有量_952281_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952281',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952281_365           --考核收入_952281_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952282',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952282_365               --申购_952282_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952282',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952282_365        --累计保有量_952282_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952282',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952282_365           --考核收入_952282_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952283',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952283_365                --申购_952283_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952283',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952283_365        --累计保有量_952283_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952283',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952283_365           --考核收入_952283_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952284',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952284_365               --申购_952284_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952284',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952284_365        --累计保有量_952284_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952284',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952284_365           --考核收入_952284_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952285',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952285_365               --申购_952285_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952285',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952285_365        --累计保有量_952285_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952285',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952285_365           --考核收入_952285_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952286',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952286_365               --申购_952286_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952286',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952286_365        --累计保有量_952286_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952286',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952286_365           --考核收入_952286_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952287',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000) ,6)              as PRCH_952287_365               --申购_952287_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952287',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000) ,6)       as RTAN_AMT_GT_952287_365        --累计保有量_952287_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952287',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952287_365           --考核收入_952287_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952288',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952288_365               --申购_952288_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952288',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952288_365        --累计保有量_952288_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952288',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952288_365           --考核收入_952288_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952289',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6) as PRCH_952289_365               --申购_952289_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952289',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952289_365        --累计保有量_952289_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952289',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952289_365           --考核收入_952289_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952290',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952290_365               --申购_952290_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952290',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952290_365        --累计保有量_952290_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952290',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952290_365           --考核收入_952290_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952291',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952291_365               --申购_952291_365
								,ROUND(SUM(DECODE(a1.PROD_CD,'952291',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952291_365        --累计保有量_952291_365
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952291',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952291_365           --考核收入_952291_365
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH_365               --申购汇总_365
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as RTAN_AMT_GT_365        --累计保有量汇总_365
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                        as ASS_INCM_365               --考核收入汇总_365
                                ,ROUND(SUM(DECODE(a1.PROD_CD,'952236',(a1.PRCH_AMT+a1.SCRP_AMT),0)*1.000000/10000),6)               as PRCH_952236               --申购_952236
								,ROUND(SUM(DECODE(a1.PROD_CD,'952236',a1.RTAN_AMT_AMT_GT,0)*1.000000/10000),6)        as RTAN_AMT_GT_952236        --累计保有量_952236
								,ROUND(SUM(ROUND(DECODE(a1.PROD_CD,'952236',a1.RTAN_AMT_AMT_GT,0)*0.0045/365,6)),6)   as ASS_INCM_952236           --考核收入_952236
                                ,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
								          THEN (a1.PRCH_AMT+a1.SCRP_AMT)*1.000000/10000
									      ELSE 0
									      END
									),6)                                                                        as PRCH              --申购汇总
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
								          THEN a1.RTAN_AMT_AMT_GT*1.000000/10000
									      ELSE 0
									      END
									) ,6)                                                                       as RTAN_AMT_GT       --累计保有量汇总
								,ROUND(SUM(CASE WHEN a1.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
								          THEN a1.RTAN_AMT_AMT_GT*0.0045/365
									      ELSE 0
									      END
									),6)                                                                         as ASS_INCM         --考核收入汇总
  FROM  		DDW_PROD.T_DDW_INR_ORG_BRH 	           t
  LEFT JOIN     DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON   a1
  ON            t.BRH_NO = a1.BRH_NO
  AND           a1.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
  AND           CAST(a1.YEAR_MON as STRING) = SUBSTR('%d{yyyyMMdd}',1,6)
  WHERE         t.BUS_DATE = %d{yyyyMMdd}
  GROUP BY BELTO_FILIL,BRH_NO,BRH_NAME 
 ;
 

 

 
-----------------------------加载结束--------------------
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_GTJA_ASTMGT_PROD_JDJXL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_GTJA_ASTMGT_PROD_JDJXL ;
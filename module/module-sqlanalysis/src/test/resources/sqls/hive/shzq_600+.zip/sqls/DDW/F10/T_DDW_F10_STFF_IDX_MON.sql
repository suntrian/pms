 /* ***************************************** SQL Begin ***************************************** */
 /* 脚本功能:员工指标月表                                                         */
 /* 创建人:黄勇华                                                                                 */
 /* 创建时间:2019-03-26                                                                         */

 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_STFF_IDX_MON_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_F10_STFF_IDX_MON_TEMP as 
 SELECT NVL(c.BELTO_FILIL_CDG,d.FILIL_DEPT_CDG)  as BELTO_FILIL_CDG
       ,NVL(c.BELTO_FILIL,d.FILIL_DEPT_FULLNM)   as BELTO_FILIL
       ,b.YYB                                    as BRH_NO
       ,NVL(a.BROK_RLN_PSN_NO,a.SVC_RLN_PSN_NO)  as STFF_NO
	   ,b.RYXM                                   as STFF_NAME
	   ,NVL(c.BRH_SHRTNM,d.FILIL_DEPT_SHRTNM)    as BRH_FULLNM
	   ,CASE WHEN  a.BROK_RLN_PSN_NO IS NOT NULL 
	         THEN '经纪关系'
			 WHEN  a.CUST_RLN = '强服务关系'
			 THEN  '强服务关系' 
			 END as CUST_RLN_TYPE
	   ,a.CUST_NO       as CUST_NO
	   ,a.BRH_NO        as CUST_BRH_NO  --客户所在营业部
	   ,CASE WHEN b.YYB = a.BRH_NO
	         THEN 0
			 ELSE 1
			 END    as IF_BRH_NO    --是否和服务人员同在一个营业部
	   ,a.OPNAC_DT  as OPNAC_DT     --开户日期
	   ,a.CUST_CGY  as CUST_CGY     --客户类别
 FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL  a
 LEFT JOIN (SELECT RYBH,MAX(RYXM) AS RYXM,MAX(YYB) as YYB  FROM EDW_PROD.T_EDW_T01_TRYXX WHERE BUS_DATE = %d{yyyyMMdd} GROUP BY RYBH)             b
 ON    NVL(a.BROK_RLN_PSN_NO,a.SVC_RLN_PSN_NO) = b.RYBH
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH       c
 ON            b.YYB = c.BRH_NO
 AND           c.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT  d
 ON            b.YYB = d.FILIL_DEPT_CDG
 AND           d.BUS_DATE = %d{yyyyMMdd}
 WHERE a.BUS_DATE = %d{yyyyMMdd}
 AND   (a.CUST_RLN = '强服务关系' OR  a.BROK_RLN_PSN_NO IS NOT NULL)
 AND   a.BRH_NO IN (SELECT BRH_NO FROM DDW_PROD.T_DDW_INR_ORG_BRH WHERE BUS_DATE = %d{yyyyMMdd} )
 UNION ALL

 SELECT NVL(c.BELTO_FILIL_CDG,d.FILIL_DEPT_CDG)  as BELTO_FILIL_CDG
       ,NVL(c.BELTO_FILIL,d.FILIL_DEPT_FULLNM)   as BELTO_FILIL
       ,b.YYB                                    as BRH_NO
       ,a.SVC_RLN_PSN_NO                         as STFF_NO
	   ,b.RYXM                                   as STFF_NAME
	   ,NVL(c.BRH_SHRTNM,d.FILIL_DEPT_SHRTNM)    as BRH_FULLNM
	   ,CASE WHEN  a.BROK_RLN_PSN_NO IS NOT NULL 
	         AND   a.SVC_RLN_PSN_NO IS NOT NULL
	         THEN  '弱服务关系'
			 WHEN  a.CUST_RLN = '弱服务关系'
			 THEN  '弱服务关系' 
			 END as CUST_RLN_TYPE
	   ,a.CUST_NO       as CUST_NO
	   ,a.BRH_NO        as CUST_BRH_NO  --客户所在营业部
	   ,CASE WHEN b.YYB = a.BRH_NO
	         THEN 0
			 ELSE 1
			 END    as IF_BRH_NO    --是否和服务人员同在一个营业部
	   ,a.OPNAC_DT  as OPNAC_DT     --开户日期
	   ,a.CUST_CGY  as CUST_CGY     --客户类别
 FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL  a
 LEFT JOIN (SELECT RYBH,MAX(RYXM) AS RYXM,MAX(YYB) as YYB  FROM EDW_PROD.T_EDW_T01_TRYXX WHERE BUS_DATE = %d{yyyyMMdd} GROUP BY RYBH)             b
 ON    a.SVC_RLN_PSN_NO = b.RYBH
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH       c
 ON            b.YYB = c.BRH_NO
 AND           c.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT  d
 ON            b.YYB = d.FILIL_DEPT_CDG
 AND           d.BUS_DATE = %d{yyyyMMdd}
 WHERE a.BUS_DATE = %d{yyyyMMdd}
 AND   ((a.SVC_RLN_PSN_NO IS NOT NULL AND   a.BROK_RLN_PSN_NO IS NOT NULL)  OR (a.CUST_RLN = '弱服务关系'))
 AND  a.BROK_RLN_PSN_NO < > a.SVC_RLN_PSN_NO
 AND   a.BRH_NO IN (SELECT BRH_NO FROM DDW_PROD.T_DDW_INR_ORG_BRH WHERE BUS_DATE = %d{yyyyMMdd} )
 ;
 INSERT OVERWRITE DDW_PROD.T_DDW_F10_STFF_IDX_MON 
   ( BELTO_FILIL_CDG                        --分公司编码
  ,BELTO_FILIL                              --分公司名称
  ,BRH_NO                                   --营业部编码
  ,BRH_FULLNM                               --营业部名称	
  ,STFF_NO                                  --员工编号
  ,STFF_NAME                                --员工姓名 
  ,CUST_RLN_TYPE                            --客户关系类型
  ,IF_BRH_NO                               --是否和服务人员同在一个营业部
  ,CUST_BRH_NO                             --客户所在营业部编号
  ,CUST_VOL                                --客户数
  ,CUST_AVG_AST                            --客户日均资产                                     
  ,CUST_FNL_AST                            --客户期末资产
  ,ADDED_CUST_AVG_AST                      --新增客户日均资产
  ,TISSU_GT_CUST_AVG_AST                   --本年累计客户日均资产
  ,ADDED_VLD_CUST_VOL                      --新增有效客户数
  ,TISSU_GT_ADDED_VLD_CUST_VOL             --本年累计新增有效客户数
  ,PROD_CUST_VOL                           --产品账户数
  ,FND_FIXINV_CUST_VOL                     --基金定投客户数
  ,ADDED_CRD_CUST_VOL                      --新增信用客户
  ,TISSU_GT_ADDED_CRD_CUST_VOL             --本年累计新增信用客户
  ,ADDED_VLD_CRD_CUST_VOL                  --新增有效信用客户
  ,TISSU_GT_ADDED_VLD_CRD_CUST_VOL         --本年累计新增有效信用客户
  ,ADDED_WRNT_CUST_VOL                     --新增期权客户
  ,TISSU_GT_ADDED_WRNT_CUST_VOL            --本年新增期权客户
  ,ADDED_VLD_WRNT_CUST_VOL                 --新增有效期权客户
  ,TISSU_GT_ADDED_VLD_WRNT_CUST_VOL        --本年累计新增有效期权客户
  ,ADDED_WRNT_IB_CUST_VOL                  --新增期货IB账户
  ,ADDED_VLD_WRNT_IB_CUST_VOL              --新增期货IB有效户
  ,NET_TFR_IN_NET_TOT_AST                  --资产净流入额
  ,AST_PLCG_ETMT_RTO                       --资产配售权益比
  ,STK_TRD_VOL                             --股基交易量
  ,NET_S1_INCM                             --净佣金收入
  ,ORDI_ACCNT_GL_INT                       --普通息差收入
  ,CRD_ACCNT_GL_INT                        --两融息差毛收入
  ,PRDCT_CRD_ACCNT_GL_INT                  --两融息差预估收入
  ,PUB_PROD_SALE_INCM                      --公募产品销售收入
  ,PP_PROD_SALE_INCM                       --私募产品销售收入
  ,GS_PROD_SALE_INCM                       --资管除现金添利外产品销售收入
  ,CASH_PROD_SALE_INCM                     --现金添利收入
  ,OTH_PROD_SALE_INCM                      --其他产品销售收入
  ,ADDED_IB_SALE_INCM                      --新增IB业务收入
  ,TISSU_GT_ADDED_PROD_SALE_INCM           --累计IB业务收入
  ,WRNT_ACCT_ADDED_S1_INCM                 --新增股票期权收入
  ,TISSU_GT_WRNT_ACCT_S1_INCM              --累计股票期权收入		
  ,PROD_BUY_AMT                            --产品购买金额
  ,ETL_DT                                  
   )PARTITION( YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 
 SELECT     t.BELTO_FILIL_CDG                         as BELTO_FILIL_CDG      --分公司编码
          , t.BELTO_FILIL                             as BELTO_FILIL          --分公司名称
          , t.BRH_NO                                  as BRH_NO               --营业部编码
          , t.BRH_FULLNM                              as BRH_FULLNM           --营业部名称	
          , t.STFF_NO                                 as STFF_NO              --员工编号
          , t.STFF_NAME                               as STFF_NAME            --员工姓名 
          , t.CUST_RLN_TYPE                           as CUST_RLN_TYPE        --客户关系类型
		  , t.IF_BRH_NO                               as IF_BRH_NO            --是否和服务人员同在一个营业部
		  , t.CUST_BRH_NO                             as CUST_BRH_NO          --客户所在营业部
		  , COUNT(1)                                  as CUST_VOL             --客户数
          , SUM(CAST(ROUND(NVL(a1.NET_TOT_AST,0)*1.0000/a4.NUM,2) as DECIMAL(38,2))) as CUST_AVG_AST --客户日均资产                                       
          , SUM(CAST(ROUND(NVL(a1.NET_TOT_AST,0)*1.0000,2) as DECIMAL(38,2))) as CUST_FNL_AST --客户期末资产
		  , SUM(CASE WHEN SUBSTR(CAST(t.OPNAC_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		             THEN CAST(ROUND(NVL(a1.NET_TOT_AST,0)*1.0000/a4.NUM,2) as DECIMAL(38,2))
				     ELSE 0
				     END 
				)                                     as ADDED_CUST_AVG_AST --新增客户日均资产
		  , SUM(CASE WHEN SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		             AND  t.OPNAC_DT <= %d{yyyyMMdd}
		             THEN CAST(ROUND(NVL(a1.NET_TOT_AST,0)*1.0000/a4.NUM,2) as DECIMAL(38,2))
				     ELSE 0
				     END 
				)                                     as TISSU_GT_CUST_AVG_AST --本年累计客户日均资产
		
		 , SUM(CASE  WHEN SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		             AND  t.OPNAC_DT <= %d{yyyyMMdd}
					 AND  SUBSTR(CAST(NVL(a6.BUS_DATE,0) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		             THEN 1
				     ELSE 0
				     END 
				)                                     as ADDED_VLD_CUST_VOL --新增有效客户数
		 , SUM(CASE  WHEN SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		             AND  t.OPNAC_DT <= %d{yyyyMMdd}
					 AND  SUBSTR(CAST(NVL(a6.BUS_DATE,0) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		             THEN 1
				     ELSE 0
				     END 
				)                                     as TISSU_GT_ADDED_VLD_CUST_VOL --本年累计新增有效客户数
		 , SUM(CASE  WHEN t.CUST_CGY = '2'
		             THEN 1
				     ELSE 0
				     END 
				)                                     as PROD_CUST_VOL --产品账户数
		 , SUM(CASE  WHEN a7.CUST_NO IS NOT NULL
		             THEN 1
				     ELSE 0
				     END 
				)                                     as FND_FIXINV_CUST_VOL --基金定投客户数
		, SUM(CASE  WHEN SUBSTR(CAST(NVL(a8.OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		             THEN 1
				     ELSE 0
				     END 
				)                                     as ADDED_CRD_CUST_VOL --新增信用客户
		, SUM(CASE  WHEN SUBSTR(CAST(NVL(a8.OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		            THEN 1
				    ELSE 0
				    END 
				)                                     as TISSU_GT_ADDED_CRD_CUST_VOL --本年累计新增信用客户
		, SUM(CASE  WHEN SUBSTR(CAST(NVL(a9.RZRQ,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		            THEN 1
				    ELSE 0
				    END 
				)                                     as ADDED_VLD_CRD_CUST_VOL --新增有效信用客户
		, SUM(CASE  WHEN SUBSTR(CAST(NVL(a9.RZRQ,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		            THEN 1
				    ELSE 0
				    END 
				)                                     as TISSU_GT_ADDED_VLD_CRD_CUST_VOL --本年累计新增有效信用客户
		, SUM(CASE  WHEN SUBSTR(CAST(NVL(a10.OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		             THEN 1
				     ELSE 0
				     END 
				)                                     as ADDED_WRNT_CUST_VOL --新增期权客户
		, SUM(CASE  WHEN SUBSTR(CAST(NVL(a10.OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		             THEN 1
				     ELSE 0
				     END 
				)                                     as TISSU_GT_ADDED_WRNT_CUST_VOL --本年新增期权客户
		, SUM(CASE  WHEN SUBSTR(CAST(NVL(a11.BUS_DATE,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		            THEN 1
				    ELSE 0
				    END 
				)                                     as ADDED_VLD_WRNT_CUST_VOL --新增有效期权客户
		, SUM(CASE  WHEN SUBSTR(CAST(NVL(a11.BUS_DATE,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		            THEN 1
				    ELSE 0
				    END 
				)                                     as TISSU_GT_ADDED_VLD_WRNT_CUST_VOL --本年累计新增有效期权客户
		,0                      as ADDED_WRNT_IB_CUST_VOL     --新增期货IB账户
		,0                      as ADDED_VLD_WRNT_IB_CUST_VOL --新增期货IB有效户
		,SUM(CAST(ROUND(NVL(a12.NET_TFR_IN_NET_TOT_AST,0)*1.000,2) as DECIMAL(38,2))) as NET_TFR_IN_NET_TOT_AST --资产净流入额
		,0                      as AST_PLCG_ETMT_RTO          --资产配售权益比
		,SUM(CAST(ROUND(NVL(a13.TRD_VOL,0)*1.000,2) as DECIMAL(38,2)))  as STK_TRD_VOL --股基交易量
		,0                                                             as NET_S1_INCM --净佣金收入
		,0                                                             as ORDI_ACCNT_GL_INT --普通息差收入
		,SUM(CAST(ROUND(NVL(a14.CRD_ACCNT_GL_INT,0)*1.000,2) as DECIMAL(38,2))) as CRD_ACCNT_GL_INT --两融息差毛收入
		,0                                                                      as PRDCT_CRD_ACCNT_GL_INT --两融息差预估收入
		,0                                                                      as PUB_PROD_SALE_INCM     --公募产品销售收入
		,0                                                                      as PP_PROD_SALE_INCM      --私募产品销售收入
		,0                                                                      as GS_PROD_SALE_INCM       --资管除现金添利外产品销售收入
        ,0                                                                      as CASH_PROD_SALE_INCM     --现金添利收入
        ,0                                                                      as OTH_PROD_SALE_INCM      --其他产品销售收入
        ,0                                                                      as ADDED_IB_SALE_INCM      --新增IB业务收入
        ,0                                                                      as TISSU_GT_ADDED_PROD_SALE_INCM      --累计IB业务收入
        , SUM(CASE  WHEN SUBSTR(CAST(NVL(a10.OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
		             THEN CAST(ROUND(NVL(a15.WRNT_NET_S1_INCM,0)*1.000,2) as DECIMAL(38,2))
				     ELSE 0
				     END 
				)                                     as WRNT_ACCT_ADDED_S1_INCM --新增股票期权收入
		,SUM(CAST(ROUND(NVL(a15.WRNT_NET_S1_INCM,0)*1.000,2) as DECIMAL(38,2))) as TISSU_GT_WRNT_ACCT_S1_INCM --累计股票期权收入		
		,0                                                                      as PROD_BUY_AMT      --产品购买金额
        ,%d{yyyyMMdd} as ETL_DT 
   FROM    (SELECT 1 as ID,* FROM   DDW_PROD.T_DDW_F10_STFF_IDX_MON_TEMP )   t
   LEFT JOIN (SELECT CUST_NO,SUM(NET_TOT_AST) as NET_TOT_AST 
               FROM    DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
               WHERE   SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			   GROUP BY CUST_NO
			  )   a1
   ON         t.CUST_NO = a1.CUST_NO

  
  LEFT JOIN (SELECT 1 as ID,COUNT(1) as NUM 
             FROM EDW_PROD.T_EDW_T99_TRD_DATE 
		     WHERE SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
             AND  BUS_DATE = %d{yyyyMMdd}
			 AND  TRD_DT < = %d{yyyyMMdd}
		     AND  NAT_DT =TRD_DT 
            )                                             a4
  ON   t.ID = a4.ID
   LEFT JOIN (SELECT CUST_NO,SUM(NET_TOT_AST) as NET_TOT_AST 
               FROM    DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
               WHERE   BUS_DATE = %d{yyyyMMdd}
			   GROUP BY CUST_NO
			  )   a5
   ON         t.CUST_NO = a5.CUST_NO
   LEFT JOIN (SELECT CUST_NO,MIN(BUS_DATE) as BUS_DATE
               FROM    DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
               WHERE   NET_TOT_AST > = 1000
			   AND     BUS_DATE < = %d{yyyyMMdd}
			   GROUP BY CUST_NO
			  )   a6
   ON         t.CUST_NO = a6.CUST_NO
   LEFT JOIN (SELECT KHH as CUST_NO
              FROM   JZJYCX.OFS_TOF_DQDESGXY
			  WHERE  DT = '%d{yyyyMMdd}'
			  AND    ZT IN (0,10)
			  GROUP BY CUST_NO
              )  a7
   ON         t.CUST_NO = a7.CUST_NO
   LEFT JOIN   ( SELECT CUST_NO,MIN(NVL(OPNAC_DT,99999999))   as OPNAC_DT
                  FROM DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
			      WHERE SYS_SRC IN ('信用账户')
			      AND   BUS_DATE = %d{yyyyMMdd}				 
				  GROUP BY CUST_NO
                 ) a8
  ON      t.CUST_NO = a8.CUST_NO
  LEFT JOIN   ( SELECT KHH as CUST_NO,MIN(RZRQ)   as RZRQ
                  FROM RZRQCX.DATACENTER_TJGMXLS
			      WHERE WTLB IN (61,64)
                  AND   CJJE > = 10000	
                  AND   RZRQ < = %d{yyyyMMdd}				  
				  GROUP BY CUST_NO
                 ) a9
  ON      t.CUST_NO = a9.CUST_NO
   LEFT JOIN   ( SELECT CUST_NO,MIN(NVL(OPNAC_DT,99999999))   as OPNAC_DT
                  FROM DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
			      WHERE SYS_SRC IN ('期权账户')
			      AND   BUS_DATE = %d{yyyyMMdd}				 
				  GROUP BY CUST_NO
                 ) a10
  ON      t.CUST_NO = a10.CUST_NO
  LEFT JOIN   ( SELECT  CUST_NO,MIN(BUS_DATE)   as BUS_DATE
                  FROM DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
			      WHERE WRNT_BS_DRCT IN ('1','2') 
                  AND BUS_DATE <= %d{yyyyMMdd}				  
				  GROUP BY CUST_NO
                 ) a11
  ON      t.CUST_NO = a11.CUST_NO
  LEFT JOIN (SELECT CUST_NO, SUM(FNL_NET_TOT_AST -STRT_NET_TOT_AST) as NET_TFR_IN_NET_TOT_AST
               FROM    DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON 
               WHERE   CAST(YEAR_MON as STRING) = SUBSTR('%d{yyyyMMdd}',1,6)
			   GROUP BY CUST_NO
			  )   a12
   ON         t.CUST_NO = a12.CUST_NO
     LEFT JOIN (SELECT CUST_NO, SUM(ORDI_TRD_VOL_RMB+CRD_TRD_VOL-ORDI_TRD_VOL_REPO-ORDI_TRD_VOL_BOND-CRD_TRD_VOL_BOND) as TRD_VOL
               FROM   DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON 
               WHERE   CAST(YEAR_MON as STRING) = SUBSTR('%d{yyyyMMdd}',1,6)
			   GROUP BY CUST_NO
			  )   a13
   ON         t.CUST_NO = a13.CUST_NO
   LEFT JOIN (SELECT CUST_NO, SUM(CRD_ACCT_ADDED_GL_INT) as CRD_ACCNT_GL_INT
               FROM    DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS 
               WHERE   SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			   GROUP BY CUST_NO
			  )   a14
   ON         t.CUST_NO = a14.CUST_NO
   LEFT JOIN (SELECT  CUST_NO,SUM(WRNT_NET_S1_INCM)   as WRNT_NET_S1_INCM
               FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON
			   WHERE  	  SUBSTR(CAST(YEAR_MON  as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)			  
			  GROUP BY CUST_NO
			  )   a15
   ON         t.CUST_NO = a15.CUST_NO
  GROUP BY  BELTO_FILIL_CDG
            ,BELTO_FILIL    
            ,BRH_NO         
            ,BRH_FULLNM     
            ,STFF_NO        
            ,STFF_NAME      
            ,CUST_RLN_TYPE            
            ,IF_BRH_NO
            ,CUST_BRH_NO			
;	

-- ------删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_STFF_IDX_MON_TEMP ;
-- 
-------------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_STFF_IDX_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F10_STFF_IDX_MON;		
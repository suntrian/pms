 --/* ***************************************** SQL Begin ***************************************** */
 --/* 脚本功能:服务产品公共属性表                                                                   */
 --/* 创建人:OYJ                                                                                    */
 --/* 创建时间:2019-01-10                                                                           */ 

-------插入数据开始--------------
INSERT OVERWRITE DDW_PROD.T_DDW_LM_SVC_PROD_PUBLIC_ATTR(
 ID                                                             -- 1 .ID
,PROD_CD                                                        -- 2 .产品编号
,PROD_CAT_CD                                                    -- 3 .产品目录
,PROD_CAT_NAME                                                  -- 4 .产品目录名称
,PROD_NAME                                                      -- 5 .产品名称
,PROD_MCGY                                                      -- 6 .产品大类
,PROD_CL_CD_LEV1                                                -- 7 .产品一级分类
,PROD_CL_CD                                                     -- 8 .产品分类
,PROD_CL_NAME                                                   -- 9 .产品分类名称
,PROD_STAT_CD                                                   -- 10.产品状态
,PROD_STAT_NAME                                                 -- 11.产品状态名称
,PROD_DSC                                                       -- 12.产品描述
,PROD_EG                                                        -- 13.产品样例
,RSK_RTG_EXPLN                                                  -- 14.风险评级说明
,PRD_EXPLN                                                      -- 15.周期说明
,SEL_PROD_QTY                                                   -- 16.可选产品数量
,SHELF_DT                                                       -- 17.上架日期
,QTY_LMT                                                        -- 18.最大数量限制
,PAY_EXPLN                                                      -- 19.支付说明
,IF_SVC_PROD_CD                                                 -- 20.是否A6服务产品
,IF_SVC_PROD_DSC                                                -- 21.是否A6服务产品描述
,VLD_DT                                                         -- 22.有效期
,PROD_SRC_CD                                                    -- 23.产品来源
,PROD_SRC_DSC                                                   -- 24.产品来源描述
,DEV_PSN                                                        -- 25.开发人员
,IA_INTRO                                                       -- 26.投顾介绍
,IVSM_IDEA                                                      -- 27.投资理念
,ESCAPE_CLAUSE                                                  -- 28.免责条款
,PROD_CL_CD_LEV2                                                -- 29.二级分类
,PROD_CL_NAME_LEV2                                              -- 30.二级分类名称
,PROD_RSK_LVL_CD                                                -- 31.产品风险等级
,PROD_RSK_LVL_DSC                                               -- 32.产品风险等级描述
,IF_RSK_WARNG_CD                                                -- 33.是否风险警示
,IF_RSK_WARNG_DSC                                               -- 34.是否风险警示描述
,BRH_SCP_CD                                                     -- 35.适合营业部范围
,BRH_SCP_NAME                                                   -- 36.适合营业部范围名称
,CUST_SCP_CD                                                    -- 37.适合客户范围
,CUST_SCP_NAME                                                  -- 38.适合客户范围名称
,CHRG_CGY_CD                                                    -- 39.收费类别
,CHRG_CGY_NAME                                                  -- 40.收费类别名称
,IF_HOT_CD                                                      -- 41.是否热销
,IF_HOT_DSC                                                     -- 42.是否热销描述
,IF_SP_CD                                                       -- 43.是否促销
,IF_SP_DSC                                                      -- 44.是否促销描述
,IF_NEW_CD                                                      -- 45.是否新产品
,IF_NEW_DSC                                                     -- 46.是否新产品描述
,IF_SIGN_CD                                                     -- 47.是否需签约产品
,IF_SIGN_DSC                                                    -- 48.是否需签约产品描述
,RCOMD_IDX_CD                                                   -- 49.推荐指数
,RCOMD_IDX_DSC                                                  -- 50.推荐指数描述
,PROD_ADMIN                                                     -- 51.管理人
,PROD_ADMIN_NAME                                                -- 52.管理人名称
)
PARTITION( BUS_DATE = %d{yyyyMMdd})
SELECT 
 ID            AS        ID                                                             -- 1 .ID
,CPBH          AS        PROD_CD                                                        -- 2 .产品编号
,CPML          AS        PROD_CAT_CD                                                    -- 3 .产品目录
,CPMLMC        AS        PROD_CAT_NAME                                                  -- 4 .产品目录名称
,CPMC          AS        PROD_NAME                                                      -- 5 .产品名称
,'J'           AS        PROD_MCGY                                                      -- 6 .产品大类
,''            AS        PROD_CL_CD_LEV1                                                -- 7 .产品一级分类
,CPFL          AS        PROD_CL_CD                                                     -- 8 .产品分类
,CPFLMC        AS        PROD_CL_NAME                                                   -- 9 .产品分类名称
,CPZT          AS        PROD_STAT_CD                                                   -- 10.产品状态
,CPZTMC        AS        PROD_STAT_NAME                                                 -- 11.产品状态名称
,CPMS          AS        PROD_DSC                                                       -- 12.产品描述
,''            AS        PROD_EG                                                        -- 13.产品样例
,''            AS        RSK_RTG_EXPLN                                                  -- 14.风险评级说明
,''            AS        PRD_EXPLN                                                      -- 15.周期说明
,KXCPSL        AS        SEL_PROD_QTY                                                   -- 16.可选产品数量
,SJRQ          AS        SHELF_DT                                                       -- 17.上架日期
,ZDSLXZ        AS        QTY_LMT                                                        -- 18.最大数量限制
,''            AS        PAY_EXPLN                                                      -- 19.支付说明
,SFAFWCP       AS        IF_SVC_PROD_CD                                                 -- 20.是否A6服务产品
,SFAFWCPZ      AS        IF_SVC_PROD_DSC                                                -- 21.是否A6服务产品描述
,YXQ           AS        VLD_DT                                                         -- 22.有效期
,CPLY          AS        PROD_SRC_CD                                                    -- 23.产品来源
,CPLYMC        AS        PROD_SRC_DSC                                                   -- 24.产品来源描述
,KFRY          AS        DEV_PSN                                                        -- 25.开发人员
,TGJS          AS        IA_INTRO                                                       -- 26.投顾介绍
,TZLN          AS        IVSM_IDEA                                                      -- 27.投资理念
,MZTK          AS        ESCAPE_CLAUSE                                                  -- 28.免责条款
,EJFL          AS        PROD_CL_CD_LEV2                                                -- 29.二级分类
,EJFLMC        AS        PROD_CL_NAME_LEV2                                              -- 30.二级分类名称
,CPFXDJ        AS        PROD_RSK_LVL_CD                                                -- 31.产品风险等级
,CPFXDJMC      AS        PROD_RSK_LVL_DSC                                               -- 32.产品风险等级描述
,SFFXJS        AS        IF_RSK_WARNG_CD                                                -- 33.是否风险警示
,SFFXJSZ       AS        IF_RSK_WARNG_DSC                                               -- 34.是否风险警示描述
,SHYYBFW       AS        BRH_SCP_CD                                                     -- 35.适合营业部范围
,SHYYBMC       AS        BRH_SCP_NAME                                                   -- 36.适合营业部范围名称
,SHKHFW        AS        CUST_SCP_CD                                                    -- 37.适合客户范围
,SHKHFWMC      AS        CUST_SCP_NAME                                                  -- 38.适合客户范围名称
,SFLB          AS        CHRG_CGY_CD                                                    -- 39.收费类别
,SFLBMC        AS        CHRG_CGY_NAME                                                  -- 40.收费类别名称
,SFRX          AS        IF_HOT_CD                                                      -- 41.是否热销
,RX            AS        IF_HOT_DSC                                                     -- 42.是否热销描述
,SFCX          AS        IF_SP_CD                                                       -- 43.是否促销
,CX            AS        IF_SP_DSC                                                      -- 44.是否促销描述
,SFXCP         AS        IF_NEW_CD                                                      -- 45.是否新产品
,XCP           AS        IF_NEW_DSC                                                     -- 46.是否新产品描述
,SFQY          AS        IF_SIGN_CD                                                     -- 47.是否需签约产品
,SFXYQYCP      AS        IF_SIGN_DSC                                                    -- 48.是否需签约产品描述
,TJZS          AS        RCOMD_IDX_CD                                                   -- 49.推荐指数
,TJZSZ         AS        RCOMD_IDX_DSC                                                  -- 50.推荐指数描述
,GLR           AS        PROD_ADMIN                                                     -- 51.管理人
,GLRMC         AS        PROD_ADMIN_NAME                                                -- 52.管理人名称
FROM EDW_PROD.T_EDW_T04_C5_VPIF_FWCP
WHERE BUS_DATE = %d{yyyyMMdd}
;
----插入数据结束--------------

--INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
--PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_LM_SVC_PROD_PUBLIC_ATTR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_LM_SVC_PROD_PUBLIC_ATTR;
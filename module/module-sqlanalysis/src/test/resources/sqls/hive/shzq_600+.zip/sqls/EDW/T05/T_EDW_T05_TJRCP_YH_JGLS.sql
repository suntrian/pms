 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:金融产品银行交割历史表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
---------------- 插入数据开始 -----------------------
INSERT OVERWRITE EDW_PROD.T_EDW_T05_TJRCP_YH_JGLS(
                                    SEQNO                               --事件序号                               
                                   ,JRCPJG_LSH                          --金融产品交割流水号                          
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,CPZH                                --产品帐号                               
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,JSZH                                --结算帐号                               
                                   ,FXJG                                --发行机构                               
                                   ,JRCP_YWDM                           --金融产品业务代码                           
                                   ,JRCP_SFFS                           --金融产品收费方式                           
                                   ,YZYWFQF                             --银证业务发起方                            
                                   ,SQBH                                --申请编号                               
                                   ,XYBH                                --协议编号                               
                                   ,CPDM                                --产品代码                               
                                   ,CPJC                                --产品简称                               
                                   ,WTRQ                                --委托日期                               
                                   ,WTFE                                --委托份额                               
                                   ,WTJE                                --委托金额                               
                                   ,WTFS                                --委托方式                               
                                   ,FSYYB                               --发生营业部                              
                                   ,BZDM                                --币种代码                               
                                   ,QRRQ                                --确认日期                               
                                   ,QRFE                                --确认份额                               
                                   ,QRJE                                --确认金额                               
                                   ,CPJZ                                --产品净值                               
                                   ,ZJYE                                --资金余额                               
                                   ,FEDJYE                              --份额冻结余额                             
                                   ,FEYE                                --份额余额                               
                                   ,ZKL                                 --折扣率                                
                                   ,LXS                                 --利息税                                
                                   ,SXF                                 --手续费                                
                                   ,DLF                                 --代理费                                
                                   ,YHS                                 --印花税                                
                                   ,QTF                                 --其他费                                
                                   ,YSJE                                --应收金额                               
                                   ,JSRQ                                --交收日期                               
                                   ,ZJMX_LSH                            --资金明细流水号                            
                                   ,ZY                                  --摘要                                 
                                   ,CZZD1                               --操作终端 
                                   ,XTBS                                --系统标识								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT   
                                   t.SEQNO                               as SEQNO                               --序号                                  
                                   ,t.LSH                                 as JRCPJG_LSH                          --流水号                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t5.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.CPZH                                as CPZH                                --产品帐号                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZJJSLX                              --结算类型                                
                                   ,t.JSJG                                as JSJG                                --结算机构                                
                                   ,t.JSZH                                as JSZH                                --结算帐号                                
                                   ,t.FXJG                                as FXJG                                --发行机构                                
                                   ,t.YWDM                                as JRCP_YWDM                           --业务代码                                
                                   ,t.SFFS                                as JRCP_SFFS                           --收费方式                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.FQF AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YZYWFQF                             --业务发起方                               
                                   ,t.SQBH                                as SQBH                                --申请编号                                
                                   ,t.XYBH                                as XYBH                                --协议编号                                
                                   ,t.CPDM                                as CPDM                                --产品代码                                
                                   ,t.CPJC                                as CPJC                                --产品简称                                
                                   ,t.WTRQ                                as WTRQ                                --委托日期                                
                                   ,t.WTFE                                as WTFE                                --委托份额                                
                                   ,t.WTJE                                as WTJE                                --委托金额                                
                                   ,CAST( EDW_PROD.G_WTFS_J_WTFS(CAST(t.WTFS AS INT),0,t.YYB,a1.WTGY,a1.CZZD) AS DECIMAL(38,0) )                              as WTFS                                --委托方式                    
                                   ,t.FSYYB                               as FSYYB                               --发生营业部                               
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.QRRQ                                as QRRQ                                --确认日期                                
                                   ,t.QRFE                                as QRFE                                --确认份额                                
                                   ,CAST(CASE WHEN t.QRFE > 0 
								          AND t.QRJE = 0
										  THEN t.QRFE*1
										  ELSE t.QRJE
										  END AS DECIMAL(16,2))              as QRJE                                --确认金额                                
                                   ,t.CPJZ                                as CPJZ                                --产品净值                                
                                   ,t.ZJYE                                as ZJYE                                --资金余额                                
                                   ,t.FEDJYE                              as FEDJYE                              --份额冻结余额                              
                                   ,t.FEYE                                as FEYE                                --份额余额                                
                                   ,t.ZKL                                 as ZKL                                 --折扣率                                 
                                   ,t.LXS                                 as LXS                                 --利息税                                 
                                   ,t.SXF                                 as SXF                                 --手续费                                 
                                   ,t.DLF                                 as DLF                                 --代理费                                 
                                   ,t.YHS                                 as YHS                                 --印花税                                 
                                   ,t.QTF                                 as QTF                                 --其他费                                 
                                   ,t.YSJE                                as YSJE                                --应收金额                                
                                   ,t.JSRQ                                as JSRQ                                --交收日期                                
                                   ,t.LSH_ZJMX                            as ZJMX_LSH                            --资金明细流水号                             
                                   ,t.ZY                                  as ZY                                  --摘要                                  
                                   ,EDW_PROD.G_WTFS_J_TERM(CAST(t.WTFS AS INT),0,t.FSYYB,a1.WTGY,a1.CZZD)          as CZZD1     --操作终端
                                   ,'JZJY'				                  as XTBS                                --系统标识				   
FROM 	    (SELECT * FROM JZJYCX.DATACENTER_TJRCP_YH_JGLS   WHERE DT =   '%d{yyyyMMdd}' AND  QRRQ = %d{yyyyMMdd} )            t
 LEFT JOIN (SELECT WTGY,CZZD,WTFS,SQBH FROM  JZJYCX.DATACENTER_TJRCP_YH_WTLS
			              WHERE WTRQ BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,-20) AS INT) AND %d{yyyyMMdd} 
						  AND   DT NOT LIKE '%back%'
			              GROUP BY WTGY,CZZD,WTFS,SQBH
			)   a1
ON         DECODE(LENGTH(TRIM(NVL(t.SQBH,''))),0,'-9999999',t.SQBH) = a1.SQBH	
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'ZJJSLX'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.JSLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'YZYWFQF'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.FQF AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'BZDM'
 AND            t3.YXT = 'JZJY'
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t5
 ON             t5.YXT = 'JZJY'
 AND            t5.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.QRRQ = %d{yyyyMMdd} 
 AND            t.DT  = '%d{yyyyMMdd}'
;

---------------- 插入数据结束 -----------------------


---------------- 插入数据开始 -----------------------
INSERT OVERWRITE EDW_PROD.T_EDW_T05_TJRCP_YH_JGLS(
                                    SEQNO                               --事件序号                               
                                   ,JRCPJG_LSH                          --金融产品交割流水号                          
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,CPZH                                --产品帐号                               
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,JSZH                                --结算帐号                               
                                   ,FXJG                                --发行机构                               
                                   ,JRCP_YWDM                           --金融产品业务代码                           
                                   ,JRCP_SFFS                           --金融产品收费方式                           
                                   ,YZYWFQF                             --银证业务发起方                            
                                   ,SQBH                                --申请编号                               
                                   ,XYBH                                --协议编号                               
                                   ,CPDM                                --产品代码                               
                                   ,CPJC                                --产品简称                               
                                   ,WTRQ                                --委托日期                               
                                   ,WTFE                                --委托份额                               
                                   ,WTJE                                --委托金额                               
                                   ,WTFS                                --委托方式                               
                                   ,FSYYB                               --发生营业部                              
                                   ,BZDM                                --币种代码                               
                                   ,QRRQ                                --确认日期                               
                                   ,QRFE                                --确认份额                               
                                   ,QRJE                                --确认金额                               
                                   ,CPJZ                                --产品净值                               
                                   ,ZJYE                                --资金余额                               
                                   ,FEDJYE                              --份额冻结余额                             
                                   ,FEYE                                --份额余额                               
                                   ,ZKL                                 --折扣率                                
                                   ,LXS                                 --利息税                                
                                   ,SXF                                 --手续费                                
                                   ,DLF                                 --代理费                                
                                   ,YHS                                 --印花税                                
                                   ,QTF                                 --其他费                                
                                   ,YSJE                                --应收金额                               
                                   ,JSRQ                                --交收日期                               
                                   ,ZJMX_LSH                            --资金明细流水号                            
                                   ,ZY                                  --摘要                                 
                                   ,CZZD1                               --操作终端 
                                   ,XTBS                                --系统标识								   
) 
PARTITION( bus_date = 19000101)
SELECT   
                                   t.SEQNO                               as SEQNO                               --序号                                  
                                   ,t.LSH                                 as JRCPJG_LSH                          --流水号                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t5.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.CPZH                                as CPZH                                --产品帐号                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZJJSLX                              --结算类型                                
                                   ,t.JSJG                                as JSJG                                --结算机构                                
                                   ,t.JSZH                                as JSZH                                --结算帐号                                
                                   ,t.FXJG                                as FXJG                                --发行机构                                
                                   ,t.YWDM                                as JRCP_YWDM                           --业务代码                                
                                   ,t.SFFS                                as JRCP_SFFS                           --收费方式                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.FQF AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YZYWFQF                             --业务发起方                               
                                   ,t.SQBH                                as SQBH                                --申请编号                                
                                   ,t.XYBH                                as XYBH                                --协议编号                                
                                   ,t.CPDM                                as CPDM                                --产品代码                                
                                   ,t.CPJC                                as CPJC                                --产品简称                                
                                   ,t.WTRQ                                as WTRQ                                --委托日期                                
                                   ,t.WTFE                                as WTFE                                --委托份额                                
                                   ,t.WTJE                                as WTJE                                --委托金额                                
                                   ,t.WTFS                              as WTFS                                --委托方式                    
                                   ,t.FSYYB                               as FSYYB                               --发生营业部                               
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.QRRQ                                as QRRQ                                --确认日期                                
                                   ,t.QRFE                                as QRFE                                --确认份额                                
                                   ,t.QRJE                                as QRJE                                --确认金额                                
                                   ,t.CPJZ                                as CPJZ                                --产品净值                                
                                   ,t.ZJYE                                as ZJYE                                --资金余额                                
                                   ,t.FEDJYE                              as FEDJYE                              --份额冻结余额                              
                                   ,t.FEYE                                as FEYE                                --份额余额                                
                                   ,t.ZKL                                 as ZKL                                 --折扣率                                 
                                   ,t.LXS                                 as LXS                                 --利息税                                 
                                   ,t.SXF                                 as SXF                                 --手续费                                 
                                   ,t.DLF                                 as DLF                                 --代理费                                 
                                   ,t.YHS                                 as YHS                                 --印花税                                 
                                   ,t.QTF                                 as QTF                                 --其他费                                 
                                   ,t.YSJE                                as YSJE                                --应收金额                                
                                   ,t.JSRQ                                as JSRQ                                --交收日期                                
                                   ,t.LSH_ZJMX                            as ZJMX_LSH                            --资金明细流水号                             
                                   ,t.ZY                                  as ZY                                  --摘要                                  
                                   ,NULL                                  as CZZD1     --操作终端
                                   ,'JZJY'				                  as XTBS                                --系统标识				   
 FROM 	    JZJYCX.DATACENTER_TJRCP_YH_JGLS                  t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'ZJJSLX'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.JSLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'YZYWFQF'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.FQF AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'BZDM'
 AND            t3.YXT = 'JZJY'
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t5
 ON             t5.YXT = 'JZJY'
 AND            t5.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.QRRQ = 0 
;

---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TJRCP_YH_JGLS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_TJRCP_YH_JGLS;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:权益补偿方案表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TXY_QYBCFA; 
----插入数据开始--------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TXY_QYBCFA
(
                                    JYS                                 --交易所                                
                                   ,QYDM                                --权益代码                               
                                   ,ZQDM                                --证券代码                               
                                   ,XY_QYXZ                             --权益性质                               
                                   ,XY_QYLB                             --权益类别                               
                                   ,XY_SGBCFS                           --信用送股补偿方式                           
                                   ,GQDJR                               --股权登记日                              
                                   ,ZQMC                                --证券名称                               
                                   ,MGXJHL                              --每股现金红利                             
                                   ,MGGPHL                              --每股股票红利                             
                                   ,PGJG                                --配股价格                               
                                   ,CQJG                                --除权价格                               
                                   ,CQCXRQ                              --除权除息日                              
                                   ,FHPXRQ                              --分红派息日                              
                                   ,XGRQ                                --修改日期                               
                                   ,ZY                                  --摘要                                 
                                   ,GFDZR                               --股份到帐日                              
                                   ,JYSFHPXR                            --交易所分红派息日   
                                   ,XTBS 								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.QYDM                                as QYDM                                --权益代码                                
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.QYXZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as XY_QYXZ                             --权益性质                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.QYLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as XY_QYLB                             --权益类别                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BCFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as XY_SGBCFS                           --补偿方式                                
                                   ,t.GQDJRQ                              as GQDJR                               --股权登记日                               
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.MGXJHL                              as MGXJHL                              --每股现金红利                              
                                   ,t.MGGPHL                              as MGGPHL                              --每股股票红利                              
                                   ,t.PGJG                                as PGJG                                --配股价格                                
                                   ,t.CQJG                                as CQJG                                --除权价格                                
                                   ,t.CQCXRQ                              as CQCXRQ                              --除权除息日                               
                                   ,t.FHPXRQ                              as FHPXRQ                              --分红派息日                               
                                   ,t.XGRQ                                as XGRQ                                --修改日期                                
                                   ,t.ZY                                  as ZY                                  --摘要                                  
                                   ,t.GFDZR                               as GFDZR                               --股份到帐日                               
                                   ,t.JYSFHPXR                            as JYSFHPXR                            --交易所分红派息日 
                                   ,'RZRQ'								  as XTBS
 FROM           RZRQCX.MARGIN_TXY_QYBCFA                   t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING     t1 
 ON             t1.DMLX = 'XY_QYXZ'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.QYXZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING     t2 
 ON             t2.DMLX = 'XY_QYLB'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.QYLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING      t3 
 ON             t3.DMLX = 'XY_SGBCFS'
 AND            t3.YXT = 'RZRQ'
 AND            t3.YDM = CAST(t.BCFS AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TXY_QYBCFA',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TXY_QYBCFA;
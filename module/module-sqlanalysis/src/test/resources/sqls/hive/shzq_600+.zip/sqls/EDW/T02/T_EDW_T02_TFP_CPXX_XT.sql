--/* ***************************************** SQL BEGIN ***************************************** */
--/* 脚本功能:信托产品信息表                                                                       */
--/* 创建人:常静静                                                                                 */
--/* 创建时间:2018-09-04                                                                           */  

TRUNCATE TABLE EDW_PROD.T_EDW_T02_TFP_CPXX_XT;
------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T02_TFP_CPXX_XT
 (
                                     ID					 	--1. ID
                                    ,CPDM               	--2. 产品代码
                                    ,CPFL                   --3. 产品大类
                                    ,CPLX                   --4. 产品类型
                                    ,CPMC                   --5. 产品名称
                                    ,TZQX                   --6. 投资期限
                                    ,CLRQ                   --7. 成立日期
                                    ,DQRQ                   --8. 到期日期
                                    ,FXGM                   --9. 发行规模(万)
                                    ,CPGM        			--10. 产品规模(万)
                                    ,SJGQSL                 --11. 涉及股权数量 
                                    ,YQSYL                  --12. 预期年化收益率%
                                    ,SJSYL                  --13. 实际年化收益率%
                                    ,SYLX                   --14. 收益类型 
                                    ,TZFG                   --15. 投资风格
                                    ,ZJTX                   --16. 资金投向
                                    ,FXJG                   --17. 发行机构 
                                    ,GLJG                   --18. 管理机构
                                    ,JJS                    --19. 经纪商
									,XTBS					--20. 系统标识
)
PARTITION( BUS_DATE =%d{yyyyMMdd})
SELECT 
                                     T.ID					--1. ID
                                    ,T.CPDM               	--2. 产品代码
                                    ,CAST(COALESCE(T1.MBDM,NULLIF(CONCAT('ERR',CAST(T.CPFL AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) 		AS CPFL                 --3. 产品大类
                                    ,CAST(COALESCE(T2.MBDM,NULLIF(CONCAT('ERR',CAST(T.CPLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) 		AS CPLX                 --4. 产品类型
                                    ,T.CPMC                 --5. 产品名称
                                    ,CAST(CASE WHEN T.TZQX IN (1,2,4)
								             -- AND T.TZQX IS NULL
 								              THEN T.TZQX
										      WHEN T.TZQX BETWEEN 5 AND 365
										      --AND  T.TZQX IS NULL
										      THEN 1
										      WHEN T.TZQX BETWEEN 365 AND 1825
										      --AND  T.TZQX IS NULL
										      THEN 2
										      WHEN T.TZQX > 1825
										      --AND  T.TZQX IS NULL
										      THEN 4
										      ELSE T.TZQX
										      END AS STRING)        AS TZQX                 --6. 投资期限
                                    ,T.CLRQ                 --7. 成立日期
                                    ,T.DQRQ                 --8. 到期日期
                                    ,T.FXGM                 --9. 发行规模(万)
                                    ,T.CPGM        			--10. 产品规模(万)
                                    ,T.SJGQSL               --11. 涉及股权数量 
                                    ,T.YQSYL                --12. 预期年化收益率%
                                    ,T.SJSYL                --13. 实际年化收益率%
                                    ,CAST(COALESCE(T3.MBDM,NULLIF(CONCAT('ERR',CAST(T.SYLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) 		AS SYLX                 --14. 收益类型 
                                    ,T.TZFG                 --15. 投资风格
                                    ,T.ZJTX                 --16. 资金投向
                                    ,T.FXJG                 --17. 发行机构 
                                    ,T.GLJG                 --18. 管理机构
                                    ,T.JJS                  --19. 经纪商
									,'OTC'					--20. 系统标识
 FROM 			OTCCX.PRODUCT_TFP_CPXX_XT T
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T1  
 ON             T1.DMLX = 'OTC_CPFL'
 AND            T1.YXT = 'OTC'
 AND            T1.YDM = CAST(T.CPFL AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T2 
 ON             T2.DMLX = 'OTC_CPLX'
 AND            T2.YXT = 'OTC'
 AND            T2.YDM = CAST(T.CPLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T3
 ON             T3.DMLX = 'OTC_SYLX'
 AND            T3.YXT = 'OTC'
 AND            T3.YDM = CAST(T.SYLX AS VARCHAR(20))
 WHERE 	T.DT = '%d{yyyyMMdd}';
 ----------插入数据结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TFP_CPXX_XT',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TFP_CPXX_XT;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:历史交割明细表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
----删除今天的数据--
-----------------------------------删除今天的数据--------------------
 ALTER TABLE EDW_PROD.T_EDW_T05_TJGMXLS DROP IF EXISTS PARTITION   (BUS_DATE = %d{yyyyMMdd});
----------------------------------删除今天的数据结束-----------------------
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_TEMP ;
 CREATE TABLE  EDW_PROD.T_EDW_T05_TJGMXLS_TEMP as 
SELECT  SEQNO         as SEQNO
       ,LSH           as LSH
	   ,JGZLLB        as JGZLLB
	   ,WTH           as WTH
	   ,KHH           as KHH
	   ,KHXM          as KHXM
	   ,KHQZ          as KHQZ
	   ,GSFL          as GSFL
	   ,GDH           as GDH
	   ,GDXM          as GDXM
	   ,JYS           as JYS
	   ,JSLX          as JSLX
	   ,JSJG          as JSJG
	   ,JSZH          as JSZH
	   ,ZHGLJG        as ZHGLJG
	   ,BZ            as BZ
	   ,WTFS          as WTFS
	   ,YYB           as YYB
	   ,XWDM          as XWDM
	   ,ZQDM          as ZQDM
	   ,ZQMC          as ZQMC
	   ,ZQLB          as ZQLB
	   ,WTLB          as WTLB
	   ,CJBH          as CJBH
	   ,CJRQ          as CJRQ
	   ,CJSJ          as CJSJ
	   ,SBSJ          as SBSJ
	   ,CJBS          as CJBS
	   ,CJSL          as CJSL
	   ,CJJG          as CJJG
	   ,JSJ           as JSJ
	   ,LXJG          as LXJG
	   ,CJJE          as CJJE
	   ,LXJE          as LXJE
	   ,BZS1          as BZS1
	   ,S1            as S1
	   ,S2            as S2
	   ,S3            as S3
	   ,S4            as S4
	   ,S5            as S5
	   ,S6            as S6
	   ,YSJE          as YSJE
	   ,S11           as S11
	   ,S12           as S12
	   ,S13           as S13
	   ,S15           as S15
	   ,S16           as S16
	   ,YSJE_YJ       as YSJE_YJ
	   ,BCYE          as BCYE
	   ,ZJMX_LSH      as ZJMX_LSH
	   ,DJJE          as DJJE
	   ,ZJDJMX_LSH    as ZJDJMX_LSH
	   ,YSSL          as YSSL
	   ,BCSL          as BCSL
	   ,BCDJSL        as BCDJSL
	   ,DJSL          as DJSL
	   ,BCYK          as BCYK
	   ,JSRQ          as JSRQ
	   ,RZRQ          as RZRQ
	   ,YJDJFS        as YJDJFS
	   ,FID           as FID
	   ,LOGINID       as LOGINID
	   ,DLSF          as DLSF
	   ,FHGY          as FHGY
	   ,FSYYB         as FSYYB
	   ,YWSQH         as YWSQH
	   ,FJXX          as FJXX 
 FROM   JZJYCX.DATACENTER_TJGMXLS 
 WHERE  DT = '%d{yyyyMMdd}'
 AND    RZRQ < = %d{yyyyMMdd}
 UNION ALL  
 SELECT  NULL          as SEQNO
        ,LSH           as LSH
		,JGZLLB        as JGZLLB
		,WTH           as WTH
		,KHH           as KHH
		,KHXM          as KHXM
		,KHQZ          as KHQZ
		,GSFL          as GSFL
		,GDH           as GDH
		,GDXM          as GDXM
		,JYS           as JYS
		,JSLX          as JSLX
		,JSJG          as JSJG
		,JSZH          as JSZH
		,ZHGLJG        as ZHGLJG
		,BZ            as BZ
		,WTFS          as WTFS
		,YYB           as YYB
		,XWDM          as XWDM
		,ZQDM          as ZQDM
		,ZQMC          as ZQMC
		,ZQLB          as ZQLB
		,WTLB          as WTLB
		,CJBH          as CJBH
		,CJRQ          as CJRQ
		,CJSJ          as CJSJ
		,SBSJ          as SBSJ
		,CJBS          as CJBS
		,CJSL          as CJSL
		,CJJG          as CJJG
		,JSJ           as JSJ
		,LXJG          as LXJG
		,CJJE          as CJJE
		,LXJE          as LXJE
		,BZS1          as BZS1
		,S1            as S1
		,S2            as S2
		,S3            as S3
		,S4            as S4
		,S5            as S5
		,S6            as S6
		,YSJE          as YSJE
		,S11           as S11
		,S12           as S12
		,S13           as S13
		,S15           as S15
		,S16           as S16
		,YSJE_YJ       as YSJE_YJ
		,BCYE          as BCYE
		,ZJMX_LSH      as ZJMX_LSH
		,DJJE          as DJJE
		,ZJDJMX_LSH    as ZJDJMX_LSH
		,YSSL          as YSSL
		,BCSL          as BCSL
		,BCDJSL        as BCDJSL
		,DJSL          as DJSL
		,BCYK          as BCYK
		,JSRQ          as JSRQ
		,RZRQ          as RZRQ
		,YJDJFS        as YJDJFS
		,FID           as FID
		,LOGINID       as LOGINID
		,DLSF          as DLSF
		,FHGY          as FHGY
		,FSYYB         as FSYYB
		,YWSQH         as YWSQH
		,FJXX          as FJXX 
FROM JZJYCX.SECURITIES_TJGMX  t
INNER JOIN (SELECT MAX(TRD_DT) as TRD_DT,MIN(NAT_DT) AS NAT_DT,MAX(NAT_DT) AS NAT_DT1  
             FROM  EDW_PROD.T_EDW_T99_TRD_DATE
			 WHERE ((TRD_DT = %d{yyyyMMdd} AND NAT_DT = TRD_DT)  OR (NXTM_TRD_D =  %d{yyyyMMdd} AND NAT_DT < > TRD_DT))
			 AND   BUS_DATE = %d{yyyyMMdd}
			 ) a1
  ON          t.RZRQ > = a1.NAT_DT 
  AND         t.RZRQ < = a1.NAT_DT1   
  WHERE   t.DT = '%d{yyyyMMdd}'
  AND    t.DT IN (SELECT MAX(DT) AS DT FROM JZJYCX.SECURITIES_TJGMX)
  ; 
  
  DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_TEMP1 ;
 CREATE TABLE  EDW_PROD.T_EDW_T05_TJGMXLS_TEMP1 as 
SELECT  SEQNO         as SEQNO
       ,LSH           as LSH
	   ,JGZLLB        as JGZLLB
	   ,WTH           as WTH
	   ,KHH           as KHH
	   ,KHXM          as KHXM
	   ,KHQZ          as KHQZ
	   ,GSFL          as GSFL
	   ,GDH           as GDH
	   ,GDXM          as GDXM
	   ,JYS           as JYS
	   ,JSLX          as JSLX
	   ,JSJG          as JSJG
	   ,JSZH          as JSZH
	   ,ZHGLJG        as ZHGLJG
	   ,BZ            as BZ
	   ,WTFS          as WTFS
	   ,YYB           as YYB
	   ,XWDM          as XWDM
	   ,ZQDM          as ZQDM
	   ,ZQMC          as ZQMC
	   ,ZQLB          as ZQLB
	   ,WTLB          as WTLB
	   ,CJBH          as CJBH
	   ,CJRQ          as CJRQ
	   ,CJSJ          as CJSJ
	   ,SBSJ          as SBSJ
	   ,CJBS          as CJBS
	   ,CJSL          as CJSL
	   ,CJJG          as CJJG
	   ,JSJ           as JSJ
	   ,LXJG          as LXJG
	   ,CJJE          as CJJE
	   ,LXJE          as LXJE
	   ,BZS1          as BZS1
	   ,S1            as S1
	   ,S2            as S2
	   ,S3            as S3
	   ,S4            as S4
	   ,S5            as S5
	   ,S6            as S6
	   ,YSJE          as YSJE
	   ,S11           as S11
	   ,S12           as S12
	   ,S13           as S13
	   ,S15           as S15
	   ,S16           as S16
	   ,YSJE_YJ       as YSJE_YJ
	   ,BCYE          as BCYE
	   ,ZJMX_LSH      as ZJMX_LSH
	   ,DJJE          as DJJE
	   ,ZJDJMX_LSH    as ZJDJMX_LSH
	   ,YSSL          as YSSL
	   ,BCSL          as BCSL
	   ,BCDJSL        as BCDJSL
	   ,DJSL          as DJSL
	   ,BCYK          as BCYK
	   ,JSRQ          as JSRQ
	   ,RZRQ          as RZRQ
	   ,YJDJFS        as YJDJFS
	   ,FID           as FID
	   ,LOGINID       as LOGINID
	   ,DLSF          as DLSF
	   ,FHGY          as FHGY
	   ,FSYYB         as FSYYB
	   ,YWSQH         as YWSQH
	   ,FJXX          as FJXX 
 FROM   RZRQCX.DATACENTER_TJGMXLS 
 WHERE  DT = '%d{yyyyMMdd}'
 AND    RZRQ < = %d{yyyyMMdd}
 UNION ALL  
 SELECT  NULL          as SEQNO
        ,LSH           as LSH
		,JGZLLB        as JGZLLB
		,WTH           as WTH
		,KHH           as KHH
		,KHXM          as KHXM
		,KHQZ          as KHQZ
		,GSFL          as GSFL
		,GDH           as GDH
		,GDXM          as GDXM
		,JYS           as JYS
		,JSLX          as JSLX
		,JSJG          as JSJG
		,JSZH          as JSZH
		,ZHGLJG        as ZHGLJG
		,BZ            as BZ
		,WTFS          as WTFS
		,YYB           as YYB
		,XWDM          as XWDM
		,ZQDM          as ZQDM
		,ZQMC          as ZQMC
		,ZQLB          as ZQLB
		,WTLB          as WTLB
		,CJBH          as CJBH
		,CJRQ          as CJRQ
		,CJSJ          as CJSJ
		,SBSJ          as SBSJ
		,CJBS          as CJBS
		,CJSL          as CJSL
		,CJJG          as CJJG
		,JSJ           as JSJ
		,LXJG          as LXJG
		,CJJE          as CJJE
		,LXJE          as LXJE
		,BZS1          as BZS1
		,S1            as S1
		,S2            as S2
		,S3            as S3
		,S4            as S4
		,S5            as S5
		,S6            as S6
		,YSJE          as YSJE
		,S11           as S11
		,S12           as S12
		,S13           as S13
		,S15           as S15
		,S16           as S16
		,YSJE_YJ       as YSJE_YJ
		,BCYE          as BCYE
		,ZJMX_LSH      as ZJMX_LSH
		,DJJE          as DJJE
		,ZJDJMX_LSH    as ZJDJMX_LSH
		,YSSL          as YSSL
		,BCSL          as BCSL
		,BCDJSL        as BCDJSL
		,DJSL          as DJSL
		,BCYK          as BCYK
		,JSRQ          as JSRQ
		,RZRQ          as RZRQ
		,YJDJFS        as YJDJFS
		,FID           as FID
		,LOGINID       as LOGINID
		,DLSF          as DLSF
		,FHGY          as FHGY
		,FSYYB         as FSYYB
		,YWSQH         as YWSQH
		,FJXX          as FJXX 
FROM RZRQCX.SECURITIES_TJGMX  t
INNER JOIN (SELECT MAX(TRD_DT) as TRD_DT,MIN(NAT_DT) AS NAT_DT,MAX(NAT_DT) AS NAT_DT1  
             FROM  EDW_PROD.T_EDW_T99_TRD_DATE
			 WHERE ((TRD_DT = %d{yyyyMMdd} AND NAT_DT = TRD_DT)  OR (NXTM_TRD_D =  %d{yyyyMMdd} AND NAT_DT < > TRD_DT))
			 AND   BUS_DATE = %d{yyyyMMdd}
			 ) a1
  ON          t.RZRQ > = a1.NAT_DT 
  AND         t.RZRQ < = a1.NAT_DT1   
  WHERE   t.DT = '%d{yyyyMMdd}'
  AND    t.DT IN (SELECT MAX(DT) AS DT FROM RZRQCX.SECURITIES_TJGMX)
  ; 

---------------- 插入集中交易数据开始 -----------------------
 INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS(
                                    SEQNO                               --事件序号                               
                                   ,ZQJG_LSH                            --证券交割流水号                            
                                   ,JGZLLB                              --交割资料类别                             
                                   ,WTH                                 --委托号                                
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,GDH                                 --股东号                                
                                   ,GDXM                                --股东姓名                               
                                   ,JYS                                 --交易所                                
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,JSZH                                --结算帐户                               
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,BZDM                                --币种代码                               
                                   ,WTFS                                --委托方式                               
                                   ,YYB                                 --营业部                                
                                   ,XWDM                                --席位代码                               
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQLB                                --证券类别                               
                                   ,WTLB                                --委托类别                               
                                   ,CJBH                                --成交编号                               
                                   ,CJRQ                                --成交日期                               
                                   ,CJSJ                                --成交时间                               
                                   ,SBSJ                                --申报时间                               
                                   ,CJBS                                --成交笔数                               
                                   ,CJSL                                --成交数量                               
                                   ,CJJG                                --成交价格                               
                                   ,JSJ                                 --结算费                                
                                   ,LXJG                                --利息价格                               
                                   ,CJJE                                --成交金额                               
                                   ,LXJE                                --利息金额                               
                                   ,BZS1                                --标准佣金                               
                                   ,S1                                  --实收佣金                               
                                   ,S2                                 --印花税                                
                                   ,S3                                  --过户费                                
                                   ,S4                                  --附加费                                
                                   ,S5                                  --证管费                                
                                   ,YSJE                                --应收金额                               
                                   ,S11                                 --一级费用-经手费                           
                                   ,S12                                 --一级费用-证管费                           
                                   ,S13                                 --一级费用-过户费                           
                                   ,S15                                 --一级费用-结算费                           
                                   ,S16                                 --一级费用-风险基金                          
                                   ,YSJE_YJ                             --一级应收金额                             
                                   ,BCYE                                --本次余额                               
                                   ,ZJMX_LSH                            --资金明细流水号                            
                                   ,DJJE                                --冻结金额                               
                                   ,LSH_ZJDJXM                          --资金冻结明细流水号                          
                                   ,YSSL                                --应收数量                               
                                   ,BCSL                                --本次数量                               
                                   ,BCDJSL                              --本次冻结数量                             
                                   ,DJSL                                --冻结数量                               
                                 --  ,BCYK                                --本次盈亏                               
                                   ,JSRQ                                --交收日期                               
                                   ,RZRQ                                --入帐日期                               
                                   ,YJDJFS                              --佣金策略类别                             
                                   ,FID                                 --佣金策略编号                             
                                   ,LOGINID                             --登陆ID                               
                                   ,DLSF                                --登陆身份                               
                                   ,FHGY                                --复核柜员                               
                                   ,FSYYB                               --发生营业部                              
                                   ,YWSQH                               --业务申请号                              
                                   ,S6                                  --交易规费                               
                                   ,CZZD1                               --操作终端                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.SEQNO                               as SEQNO                               --序号                                  
                                   ,t.LSH                                 as ZQJG_LSH                            --流水号                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JGZLLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as JGZLLB                              --交割资料类别                              
                                   ,t.WTH                                 as WTH                                 --委托号                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.GDXM                                as GDXM                                --股东姓名                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJJSLX                              --结算类型                                
                                   ,t.JSJG                                as JSJG                                --结算机构                                
                                   ,t.JSZH                                as JSZH                                --结算帐户                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,CASE WHEN a1.WTGY IS NULL
								         THEN t.WTFS
								         ELSE NVL(CAST( EDW_PROD.G_WTFS_J_WTFS(CAST(t.WTFS AS INT),NVL(CAST(a1.DDLX AS INT),-1),t.FSYYB,a1.WTGY,a1.CZZD) AS DECIMAL(38,0) ),t.WTFS)
										 END                              as WTFS                                --委托方式                                
                                   ,CAST(COALESCE(t6.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.XWDM                                as XWDM                                --席位代码                                
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.ZQLB                                as ZQLB                                --证券类别                                
                                   ,t.WTLB                                as WTLB                                --委托类别                                
                                   ,CASE WHEN t.WTLB = 18
								         AND t.CJBH = '特殊股份调账'
										 THEN '股份调账'
										 WHEN t.WTLB = 21
										 AND LENGTH(TRIM(NVL(CJBH,''))) = 0
										 THEN '非流通股转出'
										 WHEN t.WTLB = 18
										 AND t.CJBH = '非流通股份政策性'
										 THEN '非流通上市'
										 WHEN t.WTLB = 19
										 AND t.CJBH = '股份托管'
										 THEN '权益转出'
										 ELSE t.CJBH
										 END                               as CJBH                                --成交编号                                
                                   ,t.CJRQ                                as CJRQ                                --成交日期                                
                                   ,t.CJSJ                                as CJSJ                                --成交时间                                
                                   ,t.SBSJ                                as SBSJ                                --申报时间                                
                                   ,t.CJBS                                as CJBS                                --成交笔数                                
                                   ,t.CJSL                                as CJSL                                --成交数量                                
                                   ,t.CJJG                                as CJJG                                --成交价格                                
                                   ,t.JSJ                                 as JSJ                                 --结算费                                 
                                   ,t.LXJG                                as LXJG                                --利息价格                                
                                   ,t.CJJE                                as CJJE                                --成交金额                                
                                   ,t.LXJE                                as LXJE                                --利息金额                                
                                   ,t.BZS1                                as BZS1                                --标准佣金                                
                                   ,t.S1                                  as S1                                  --实收佣金                                
                                   ,t.S2                                  as S2                                 --印花税                                 
                                   ,t.S3                                  as S3                                  --过户费                                 
                                   ,t.S4                                  as S4                                  --附加费                                 
                                   ,t.S5                                  as S5                                  --证管费                                 
                                   ,t.YSJE                                as YSJE                                --应收金额                                
                                   ,t.S11                                 as S11                                 --一级费用-经手费                            
                                   ,t.S12                                 as S12                                 --一级费用-证管费                            
                                   ,t.S13                                 as S13                                 --一级费用-过户费                            
                                   ,t.S15                                 as S15                                 --一级费用-结算费                            
                                   ,t.S16                                 as S16                                 --一级费用-风险基金                           
                                   ,t.YSJE_YJ                             as YSJE_YJ                             --一级应收金额                              
                                   ,t.BCYE                                as BCYE                                --本次余额                                
                                   ,t.ZJMX_LSH                            as ZJMX_LSH                            --资金明细流水号                             
                                   ,t.DJJE                                as DJJE                                --冻结金额                                
                                   ,t.ZJDJMX_LSH                          as LSH_ZJDJXM                          --资金冻结明细流水号                           
                                   ,t.YSSL                                as YSSL                                --应收数量                                
                                   ,t.BCSL                                as BCSL                                --本次数量                                
                                   ,t.BCDJSL                              as BCDJSL                              --本次冻结数量                              
                                   ,t.DJSL                                as DJSL                                --冻结数量                                
                                  -- ,t.BCYK                                as BCYK                                --本次盈亏                                
                                   ,t.JSRQ                                as JSRQ                                --交收日期                                
                                   ,t.RZRQ                                as RZRQ                                --入帐日期                                
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.YJDJFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as YJDJFS                              --佣金定价方式                              
                                   ,t.FID                                 as FID                                 --ID号                                 
                                   ,t.LOGINID                             as LOGINID                             --登陆ID                                
                                   ,t.DLSF                                as DLSF                                --登陆身份                                
                                   ,t.FHGY                                as FHGY                                --复核柜员                                
                                   ,t.FSYYB                               as FSYYB                               --发生营业部                               
                                   ,t.YWSQH                               as YWSQH                               --业务申请号                               
                                   ,t.S6                                  as S6                                  --交易规费                                
                                   ,CASE WHEN a1.WTGY IS NULL 
								         THEN NULL
										 ELSE EDW_PROD.G_WTFS_J_TERM(CAST(t.WTFS AS INT),NVL(CAST(a1.DDLX AS INT),-1),t.FSYYB,a1.WTGY,a1.CZZD)
										 END                              as CZZD1                               --                                    
                                   ,'JZJY'                                as XTBS                                 --系统标识                                    
	FROM    EDW_PROD.T_EDW_T05_TJGMXLS_TEMP      t
	LEFT JOIN  (SELECT SBRQ,WTH,DDLX,WTGY,CZZD,KHH FROM JZJYCX.DATACENTER_TWTLS   
				WHERE           WTRQ BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,-20) AS INT) AND %d{yyyyMMdd} )       a1 
	ON      	    t.CJRQ = a1.SBRQ
	and             t.WTH = a1.WTH
	and             T.KHH = a1.KHH
    LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
	ON             t1.DMLX = 'JGZLLB'
	AND            t1.YXT = 'JZJY'
	AND            t1.YDM = CAST(t.JGZLLB AS VARCHAR(20)) 
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
	ON             t2.DMLX = 'ZJJSLX'
	AND            t2.YXT = 'JZJY'
	AND            t2.YDM = CAST(t.JSLX AS VARCHAR(20)) 
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
	ON             t3.DMLX = 'BZDM'
	AND            t3.YXT = 'JZJY'
	AND            t3.YDM = CAST(t.BZ AS VARCHAR(20)) 
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
	ON             t4.DMLX = 'YJDJFS'
	AND            t4.YXT = 'JZJY'
	AND            t4.YDM = CAST(t.YJDJFS AS VARCHAR(20)) 
	LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t6
	ON             t6.YXT = 'JZJY'
	AND            t6.JGDM = CAST(t.YYB AS VARCHAR(20));
	---
  INSERT  INTO  EDW_PROD.T_EDW_T05_TJGMXLS(
                                    SEQNO                               --事件序号                               
                                   ,ZQJG_LSH                            --证券交割流水号                            
                                   ,JGZLLB                              --交割资料类别                             
                                   ,WTH                                 --委托号                                
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,GDH                                 --股东号                                
                                   ,GDXM                                --股东姓名                               
                                   ,JYS                                 --交易所                                
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,JSZH                                --结算帐户                               
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,BZDM                                --币种代码                               
                                   ,WTFS                                --委托方式                               
                                   ,YYB                                 --营业部                                
                                   ,XWDM                                --席位代码                               
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQLB                                --证券类别                               
                                   ,WTLB                                --委托类别                               
                                   ,CJBH                                --成交编号                               
                                   ,CJRQ                                --成交日期                               
                                   ,CJSJ                                --成交时间                               
                                   ,SBSJ                                --申报时间                               
                                   ,CJBS                                --成交笔数                               
                                   ,CJSL                                --成交数量                               
                                   ,CJJG                                --成交价格                               
                                   ,JSJ                                 --结算费                                
                                   ,LXJG                                --利息价格                               
                                   ,CJJE                                --成交金额                               
                                   ,LXJE                                --利息金额                               
                                   ,BZS1                                --标准佣金                               
                                   ,S1                                  --实收佣金                               
                                   ,S2                                 --印花税                                
                                   ,S3                                  --过户费                                
                                   ,S4                                  --附加费                                
                                   ,S5                                  --证管费                                
                                   ,YSJE                                --应收金额                               
                                   ,S11                                 --一级费用-经手费                           
                                   ,S12                                 --一级费用-证管费                           
                                   ,S13                                 --一级费用-过户费                           
                                   ,S15                                 --一级费用-结算费                           
                                   ,S16                                 --一级费用-风险基金                          
                                   ,YSJE_YJ                             --一级应收金额                             
                                   ,BCYE                                --本次余额                               
                                   ,ZJMX_LSH                            --资金明细流水号                            
                                   ,DJJE                                --冻结金额                               
                                   ,LSH_ZJDJXM                          --资金冻结明细流水号                          
                                   ,YSSL                                --应收数量                               
                                   ,BCSL                                --本次数量                               
                                   ,BCDJSL                              --本次冻结数量                             
                                   ,DJSL                                --冻结数量                               
                                  -- ,BCYK                                --本次盈亏                               
                                   ,JSRQ                                --交收日期                               
                                   ,RZRQ                                --入帐日期                               
                                   ,YJDJFS                              --佣金策略类别                             
                                   ,FID                                 --佣金策略编号                             
                                   ,LOGINID                             --登陆ID                               
                                   ,DLSF                                --登陆身份                               
                                   ,FHGY                                --复核柜员                               
                                   ,FSYYB                               --发生营业部                              
                                   ,YWSQH                               --业务申请号                              
                                   ,S6                                  --交易规费                               
                                   ,CZZD1                               --操作终端                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd}) 
  
SELECT 
                                    t.SEQNO                               as SEQNO                               --序号                                  
                                   ,t.LSH                                 as ZQJG_LSH                            --流水号                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JGZLLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as JGZLLB                              --交割资料类别                              
                                   ,t.WTH                                 as WTH                                 --委托号                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.GDXM                                as GDXM                                --股东姓名                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJJSLX                              --结算类型                                
                                   ,t.JSJG                                as JSJG                                --结算机构                                
                                   ,t.JSZH                                as JSZH                                --结算帐户                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,CASE WHEN a1.WTGY IS NULL
								         THEN t.WTFS
								         ELSE NVL(CAST( EDW_PROD.G_WTFS_J_WTFS(CAST(t.WTFS AS INT),NVL(CAST(a1.DDLX AS INT),-1),t.FSYYB,a1.WTGY,a1.CZZD) AS DECIMAL(38,0) ),t.WTFS)
										 END                                as WTFS                                --委托方式                                
                                   ,CAST(COALESCE(t6.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.XWDM                                as XWDM                                --席位代码                                
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.ZQLB                                as ZQLB                                --证券类别                                
                                   ,t.WTLB                                as WTLB                                --委托类别                                
                                   ,CASE WHEN t.WTLB = 18
								         AND t.CJBH = '特殊股份调账'
										 THEN '股份调账'
										 WHEN t.WTLB = 21
										 AND LENGTH(TRIM(NVL(CJBH,''))) = 0
										 THEN '非流通股转出'
										 WHEN t.WTLB = 18
										 AND t.CJBH = '非流通股份政策性'
										 THEN '非流通上市'
										 WHEN t.WTLB = 19
										 AND t.CJBH = '股份托管'
										 THEN '权益转出'
										 ELSE t.CJBH
										 END                              as CJBH                                --成交编号                                
                                   ,t.CJRQ                                as CJRQ                                --成交日期                                
                                   ,t.CJSJ                                as CJSJ                                --成交时间                                
                                   ,t.SBSJ                                as SBSJ                                --申报时间                                
                                   ,t.CJBS                                as CJBS                                --成交笔数                                
                                   ,t.CJSL                                as CJSL                                --成交数量                                
                                   ,t.CJJG                                as CJJG                                --成交价格                                
                                   ,t.JSJ                                 as JSJ                                 --结算费                                 
                                   ,t.LXJG                                as LXJG                                --利息价格                                
                                   ,t.CJJE                                as CJJE                                --成交金额                                
                                   ,t.LXJE                                as LXJE                                --利息金额                                
                                   ,t.BZS1                                as BZS1                                --标准佣金                                
                                   ,t.S1                                  as S1                                  --实收佣金                                
                                   ,t.S2                                  as S2                                 --印花税                                 
                                   ,t.S3                                  as S3                                  --过户费                                 
                                   ,t.S4                                  as S4                                  --附加费                                 
                                   ,t.S5                                  as S5                                  --证管费                                 
                                   ,t.YSJE                                as YSJE                                --应收金额                                
                                   ,t.S11                                 as S11                                 --一级费用-经手费                            
                                   ,t.S12                                 as S12                                 --一级费用-证管费                            
                                   ,t.S13                                 as S13                                 --一级费用-过户费                            
                                   ,t.S15                                 as S15                                 --一级费用-结算费                            
                                   ,t.S16                                 as S16                                 --一级费用-风险基金                           
                                   ,t.YSJE_YJ                             as YSJE_YJ                             --一级应收金额                              
                                   ,t.BCYE                                as BCYE                                --本次余额                                
                                   ,t.ZJMX_LSH                            as ZJMX_LSH                            --资金明细流水号                             
                                   ,t.DJJE                                as DJJE                                --冻结金额                                
                                   ,t.ZJDJMX_LSH                          as LSH_ZJDJXM                          --资金冻结明细流水号                           
                                   ,t.YSSL                                as YSSL                                --应收数量                                
                                   ,t.BCSL                                as BCSL                                --本次数量                                
                                   ,t.BCDJSL                              as BCDJSL                              --本次冻结数量                              
                                   ,t.DJSL                                as DJSL                                --冻结数量                                
                                  -- ,t.BCYK                                as BCYK                                --本次盈亏                                
                                   ,t.JSRQ                                as JSRQ                                --交收日期                                
                                   ,t.RZRQ                                as RZRQ                                --入帐日期                                
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.YJDJFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as YJDJFS                              --佣金定价方式                              
                                   ,t.FID                                 as FID                                 --ID号                                 
                                   ,t.LOGINID                             as LOGINID                             --登陆ID                                
                                   ,t.DLSF                                as DLSF                                --登陆身份                                
                                   ,t.FHGY                                as FHGY                                --复核柜员                                
                                   ,t.FSYYB                               as FSYYB                               --发生营业部                               
                                   ,t.YWSQH                               as YWSQH                               --业务申请号                               
                                   ,t.S6                                  as S6                                  --交易规费                                
                                   ,CASE WHEN a1.WTGY IS NULL
								         THEN NULL
										 ELSE EDW_PROD.G_WTFS_J_TERM(CAST(t.WTFS AS INT),NVL(CAST(a1.DDLX AS INT),-1),t.FSYYB,a1.WTGY,a1.CZZD)
										 END                              as CZZD1                               --                                    
                                   ,'RZRQ'                                as XTBS                                --                                    
 FROM       EDW_PROD.T_EDW_T05_TJGMXLS_TEMP1           t
 LEFT JOIN   (
				SELECT SBRQ,WTH,DDLX,WTGY,CZZD,KHH FROM RZRQCX.DATACENTER_TWTLS   
				WHERE           WTRQ BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,-20) AS INT) AND %d{yyyyMMdd}
               
				)a1
    ON         t.CJRQ = a1.SBRQ
    AND        t.WTH = a1.WTH
	and             T.KHH = a1.KHH
    LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
	ON             t1.DMLX = 'JGZLLB'
	AND            t1.YXT = 'RZRQ'
	AND            t1.YDM = CAST(t.JGZLLB AS VARCHAR(20)) 
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
	ON             t2.DMLX = 'ZJJSLX'
	AND            t2.YXT = 'RZRQ'
	AND            t2.YDM = CAST(t.JSLX AS VARCHAR(20)) 
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
	ON             t3.DMLX = 'BZDM'
	AND            t3.YXT = 'RZRQ'
	AND            t3.YDM = CAST(t.BZ AS VARCHAR(20)) 
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
	ON             t4.DMLX = 'YJDJFS'
	AND            t4.YXT = 'RZRQ'
	AND            t4.YDM = CAST(t.YJDJFS AS VARCHAR(20))
	LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t6
	ON             t6.YXT = 'RZRQ'
	AND            t6.JGDM = CAST(t.YYB AS VARCHAR(20))
	WHERE          t.KHH < > '999999997777'
		;
		
	DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_TEMP1 ;
	DROP TABLE IF EXISTS EDW_PROD.T_EDW_T05_TJGMXLS_TEMP ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TJGMXLS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_TJGMXLS;
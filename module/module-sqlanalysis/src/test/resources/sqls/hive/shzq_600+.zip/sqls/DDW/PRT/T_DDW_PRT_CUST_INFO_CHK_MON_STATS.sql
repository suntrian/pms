-- /* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:月度开户股东号三要素一致性检查统计报表                                              */
 -- /* 创建人:OYJ                                                                                   */
  --/* 创建时间:2019-09-03                                                                          */  

------插入数据


ALTER TABLE DDW_PROD.T_DDW_PRT_CUST_INFO_CHK_MON_STATS DROP IF EXISTS PARTITION (YEAR_MTH = CAST(SUBSTR(REPLACE(TO_DATE(ADD_MONTHS(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-01'),-1)),'-',''),1,6) AS INT)) ; 

------插入集中交易数据
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_INFO_CHK_MON_STATS
(
 KHH               -- 1 .客户号
,GDH               -- 2 .股东号
,GDDJRQ            -- 3 .股东登记日期
,GDZT              -- 4 .股东状态
,JYS               -- 5 .交易所
,YYB               -- 6 .营业部
,YYBMC             -- 7 .营业部名称
,KHMC              -- 8 .客户名称
,ZJLB              -- 9 .证件类型代码
,ZJLBMC            -- 10.证件类型名称
,ZJBH              -- 11.证件编号
,YMTH              -- 12.一码通号
,KHMC_ZD           -- 13.客户名称_中登
,ZJLB_ZD           -- 14.证件类型代码_中登
,ZJLBMC_ZD         -- 15.证件类型名称_中登
,ZJBH_ZD           -- 16.证件编号_中登
,BZ                -- 17.备注
,XTBZ              -- 18.系统标志
,YEAR_MTH          -- 19.数据月度
)
SELECT T1.KHH
      ,T1.GDH
	  ,T1.GDDJRQ
	  ,T1.GDZT
	  ,T1.JYS
      ,T2.YYB
	  ,NVL(T6.BRH_FULLNM,'') AS YYBMC
	  ,T2.KHMC AS KHMC
	  ,T2.ZJLB AS ZJLB
      ,NVL(T4.NOTE,'') AS ZJLBMC
	  ,T2.ZJBH
	  ,T2.YMTH AS YMTH
      ,T3.KHMC AS KHMC_ZD
	  ,T3.ZJLB AS ZJLB_ZD
      ,NVL(T5.NOTE,'') AS ZJLBMC_ZD
	  ,T3.ZJDM AS ZJBH_ZD
	  ,CASE WHEN TRIM(NVL(T2.KHMC,'')) <> TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) <> NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) <> TRIM(NVL(T3.ZJDM,''))
            THEN '名称、证件类型、证件编号，皆不相符'
            WHEN TRIM(NVL(T2.KHMC,'')) <> TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) <> NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) = TRIM(NVL(T3.ZJDM,''))
            THEN '名称、证件类型，不相符'
            WHEN TRIM(NVL(T2.KHMC,'')) <> TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) = NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) <> TRIM(NVL(T3.ZJDM,''))
            THEN '名称、证件编号，不相符'
            WHEN TRIM(NVL(T2.KHMC,'')) = TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) <> NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) <> TRIM(NVL(T3.ZJDM,''))
            THEN '证件类型、证件编号，不相符'
            WHEN TRIM(NVL(T2.KHMC,'')) <> TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) = NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) = TRIM(NVL(T3.ZJDM,''))
            THEN '名称不相符'
            WHEN TRIM(NVL(T2.KHMC,'')) = TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) <> NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) = TRIM(NVL(T3.ZJDM,''))
            THEN '证件类型不相符'
            WHEN TRIM(NVL(T2.KHMC,'')) = TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) = NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) <> TRIM(NVL(T3.ZJDM,''))
            THEN '证件编号不相符'
       END AS BZ
	  ,'JZJY' AS XTBZ
	  ,CAST(SUBSTR(REPLACE(TO_DATE(ADD_MONTHS(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-01'),-1)),'-',''),1,6) AS INT) AS YEAR_MTH
FROM
(
 SELECT DISTINCT KHH,GDH,GDDJRQ,GDZT,JYS,DT
 FROM JZJYCX.DATACENTER_TGDH
 WHERE CAST(DT AS INT) IN (SELECT MAX(TRD_DT) FROM EDW_PROD.T_EDW_T99_TRD_DATE WHERE YEAR_MTH = CAST(SUBSTR(REPLACE(TO_DATE(ADD_MONTHS(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-01'),-1)),'-',''),1,6) AS INT))
 AND GDDJRQ BETWEEN CAST(CONCAT(SUBSTR(REPLACE(TO_DATE(ADD_MONTHS(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2)),-1)),'-',''),1,6),'01') AS INT) 
                AND CAST(CONCAT(SUBSTR(REPLACE(TO_DATE(ADD_MONTHS(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2)),-1)),'-',''),1,6),'31') AS INT)
) T1
INNER JOIN
(
 SELECT DISTINCT YYB,KHH,KHMC,ZJBH,YMTH,DT
 ,CASE WHEN ZJLB IS NULL THEN 999 ELSE ZJLB END AS ZJLB
 FROM YGTCX.CIF_TKHXX
 WHERE CAST(DT AS INT) IN (SELECT MAX(TRD_DT) FROM EDW_PROD.T_EDW_T99_TRD_DATE WHERE YEAR_MTH = CAST(SUBSTR(REPLACE(TO_DATE(ADD_MONTHS(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-01'),-1)),'-',''),1,6) AS INT))
) T2
ON T1.KHH = T2.KHH
AND T1.DT = T2.DT
INNER JOIN 
(
 SELECT DISTINCT ZQZH,YMTH
 FROM YGTCX.CIF_TZDZH_ZQZHZL
 WHERE ZQZHZT <> '04'
) T7
ON T1.GDH = T7.ZQZH
INNER JOIN
(
 SELECT DISTINCT YMTH,KHMC,ZJDM
 ,CASE WHEN ZJLB = '01' THEN 0
       WHEN ZJLB = '02' THEN 1
       WHEN ZJLB = '04' THEN 21
       WHEN ZJLB = '05' THEN 2
       WHEN ZJLB = '07' THEN 4
       WHEN ZJLB = '08' THEN 15
       WHEN ZJLB = '09' THEN 18
       WHEN ZJLB = '0A' THEN 19
       WHEN ZJLB = '0B' THEN 20
       WHEN ZJLB = '0C' THEN 5
       WHEN ZJLB = '0D' THEN 22
       WHEN ZJLB = '0E' THEN 23
       WHEN ZJLB = '10' THEN 8
       WHEN ZJLB = '11' THEN 24
       WHEN ZJLB = '12' THEN 7
       WHEN ZJLB = '13' THEN 25
       WHEN ZJLB = '14' THEN 26
       WHEN ZJLB = '15' THEN 27
       WHEN ZJLB = '99' THEN 99
ELSE 999 END AS ZJLB
 FROM YGTCX.CIF_TZDZH_YMTZL
) T3
ON T7.YMTH = T3.YMTH
LEFT JOIN YGTCX.CIF_TXTDM T4
ON T2.ZJLB = T4.IBM
AND T4.DT  = T2.DT
AND T4.FLDM = 'GT_ZJLB'
LEFT JOIN YGTCX.CIF_TXTDM T5
ON T3.ZJLB = T5.IBM
AND T5.DT  = T1.DT
AND T5.FLDM = 'GT_ZJLB'
LEFT JOIN DDW_PROD.T_DDW_INR_ORG_BRH T6
ON T6.BRH_NO = CAST(T2.YYB AS STRING)
WHERE TRIM(NVL(T2.KHMC,'')) <> TRIM(NVL(T3.KHMC,''))
OR NVL(T2.ZJLB,999) <> NVL(T3.ZJLB,999)
OR TRIM(NVL(T2.ZJBH,'')) <> TRIM(NVL(T3.ZJDM,''))
;

------插入融资融券数据
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_INFO_CHK_MON_STATS
(
 KHH               -- 1 .客户号
,GDH               -- 2 .股东号
,GDDJRQ            -- 3 .股东登记日期
,GDZT              -- 4 .股东状态
,JYS               -- 5 .交易所
,YYB               -- 6 .营业部
,YYBMC             -- 7 .营业部名称
,KHMC              -- 8 .客户名称
,ZJLB              -- 9 .证件类型代码
,ZJLBMC            -- 10.证件类型名称
,ZJBH              -- 11.证件编号
,YMTH              -- 12.一码通号
,KHMC_ZD           -- 13.客户名称_中登
,ZJLB_ZD           -- 14.证件类型代码_中登
,ZJLBMC_ZD         -- 15.证件类型名称_中登
,ZJBH_ZD           -- 16.证件编号_中登
,BZ                -- 17.备注
,XTBZ              -- 18.系统标志
,YEAR_MTH          -- 19.数据月度
)
SELECT T1.KHH
      ,T1.GDH
	  ,T1.GDDJRQ
	  ,T1.GDZT
	  ,T1.JYS
      ,T2.YYB
	  ,NVL(T6.BRH_FULLNM,'') AS YYBMC
	  ,T2.KHMC AS KHMC
	  ,T2.ZJLB AS ZJLB
      ,NVL(T4.NOTE,'') AS ZJLBMC
	  ,T2.ZJBH
	  ,T2.YMTH AS YMTH
      ,T3.KHMC AS KHMC_ZD
	  ,T3.ZJLB AS ZJLB_ZD
      ,NVL(T5.NOTE,'') AS ZJLBMC_ZD
	  ,T3.ZJDM AS ZJBH_ZD
	  ,CASE WHEN TRIM(NVL(T2.KHMC,'')) <> TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) <> NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) <> TRIM(NVL(T3.ZJDM,''))
            THEN '名称、证件类型、证件编号，皆不相符'
            WHEN TRIM(NVL(T2.KHMC,'')) <> TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) <> NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) = TRIM(NVL(T3.ZJDM,''))
            THEN '名称、证件类型，不相符'
            WHEN TRIM(NVL(T2.KHMC,'')) <> TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) = NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) <> TRIM(NVL(T3.ZJDM,''))
            THEN '名称、证件编号，不相符'
            WHEN TRIM(NVL(T2.KHMC,'')) = TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) <> NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) <> TRIM(NVL(T3.ZJDM,''))
            THEN '证件类型、证件编号，不相符'
            WHEN TRIM(NVL(T2.KHMC,'')) <> TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) = NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) = TRIM(NVL(T3.ZJDM,''))
            THEN '名称不相符'
            WHEN TRIM(NVL(T2.KHMC,'')) = TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) <> NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) = TRIM(NVL(T3.ZJDM,''))
            THEN '证件类型不相符'
            WHEN TRIM(NVL(T2.KHMC,'')) = TRIM(NVL(T3.KHMC,'')) AND NVL(T2.ZJLB,999) = NVL(T3.ZJLB,999) AND TRIM(NVL(T2.ZJBH,'')) <> TRIM(NVL(T3.ZJDM,''))
            THEN '证件编号不相符'
       END AS BZ
	  ,'RZRQ' AS XTBZ
	  ,CAST(SUBSTR(REPLACE(TO_DATE(ADD_MONTHS(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-01'),-1)),'-',''),1,6) AS INT) AS YEAR_MTH
FROM
(
 SELECT DISTINCT KHH,GDH,GDDJRQ,GDZT,JYS,DT
 FROM RZRQCX.DATACENTER_TGDH
 WHERE CAST(DT AS INT) IN (SELECT MAX(TRD_DT) FROM EDW_PROD.T_EDW_T99_TRD_DATE WHERE YEAR_MTH = CAST(SUBSTR(REPLACE(TO_DATE(ADD_MONTHS(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-01'),-1)),'-',''),1,6) AS INT))
 AND GDDJRQ BETWEEN CAST(CONCAT(SUBSTR(REPLACE(TO_DATE(ADD_MONTHS(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2)),-1)),'-',''),1,6),'01') AS INT) 
                AND CAST(CONCAT(SUBSTR(REPLACE(TO_DATE(ADD_MONTHS(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-',SUBSTR('%d{yyyyMMdd}',7,2)),-1)),'-',''),1,6),'31') AS INT)
) T1
INNER JOIN
(
 SELECT DISTINCT YYB,KHH,KHMC,ZJBH,YMTH,DT
 ,CASE WHEN ZJLB IS NULL THEN 999 ELSE ZJLB END AS ZJLB
 FROM YGTCX.CIF_TKHXX
 WHERE CAST(DT AS INT) IN (SELECT MAX(TRD_DT) FROM EDW_PROD.T_EDW_T99_TRD_DATE WHERE YEAR_MTH = CAST(SUBSTR(REPLACE(TO_DATE(ADD_MONTHS(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'-',SUBSTR('%d{yyyyMMdd}',5,2),'-01'),-1)),'-',''),1,6) AS INT))
) T2
ON T1.KHH = T2.KHH
AND T1.DT = T2.DT
INNER JOIN 
(
 SELECT DISTINCT ZQZH,YMTH
 FROM YGTCX.CIF_TZDZH_ZQZHZL
 WHERE ZQZHZT <> '04'
) T7
ON T1.GDH = T7.ZQZH
INNER JOIN
(
 SELECT DISTINCT YMTH,KHMC,ZJDM
 ,CASE WHEN ZJLB = '01' THEN 0
       WHEN ZJLB = '02' THEN 1
       WHEN ZJLB = '04' THEN 21
       WHEN ZJLB = '05' THEN 2
       WHEN ZJLB = '07' THEN 4
       WHEN ZJLB = '08' THEN 15
       WHEN ZJLB = '09' THEN 18
       WHEN ZJLB = '0A' THEN 19
       WHEN ZJLB = '0B' THEN 20
       WHEN ZJLB = '0C' THEN 5
       WHEN ZJLB = '0D' THEN 22
       WHEN ZJLB = '0E' THEN 23
       WHEN ZJLB = '10' THEN 8
       WHEN ZJLB = '11' THEN 24
       WHEN ZJLB = '12' THEN 7
       WHEN ZJLB = '13' THEN 25
       WHEN ZJLB = '14' THEN 26
       WHEN ZJLB = '15' THEN 27
       WHEN ZJLB = '99' THEN 99
ELSE 999 END AS ZJLB
 FROM YGTCX.CIF_TZDZH_YMTZL
) T3
ON T7.YMTH = T3.YMTH
LEFT JOIN YGTCX.CIF_TXTDM T4
ON T2.ZJLB = T4.IBM
AND T4.DT  = T2.DT
AND T4.FLDM = 'GT_ZJLB'
LEFT JOIN YGTCX.CIF_TXTDM T5
ON T3.ZJLB = T5.IBM
AND T5.DT  = T1.DT
AND T5.FLDM = 'GT_ZJLB'
LEFT JOIN DDW_PROD.T_DDW_INR_ORG_BRH T6
ON T6.BRH_NO = CAST(T2.YYB AS STRING)
WHERE TRIM(NVL(T2.KHMC,'')) <> TRIM(NVL(T3.KHMC,''))
OR NVL(T2.ZJLB,999) <> NVL(T3.ZJLB,999)
OR TRIM(NVL(T2.ZJBH,'')) <> TRIM(NVL(T3.ZJDM,''))
;


-------插入数据结束

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_CUST_INFO_CHK_MON_STATS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

INVALIDATE METADATA DDW_PROD.T_DDW_PRT_CUST_INFO_CHK_MON_STATS;

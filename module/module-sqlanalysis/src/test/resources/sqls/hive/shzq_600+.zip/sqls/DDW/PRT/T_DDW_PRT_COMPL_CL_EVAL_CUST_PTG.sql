 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:合规分类评价数据客户评级表                                                                  */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2019-02-18                                                                        */ 

  --新开客户数(经纪业务,融资融券,个股期权,非现场开户数)
  INSERT OVERWRITE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_CUST_PTG
(
	
     BRH_NO                                     --营业部
	,BRH_NAME                                   --营业部名称
	,BELTO_FILIL_CDG                            --地区
	,BELTO_FILIL                                --地区名称
    ,QLFD_CUST_ACTA                             --合格客户数	
    ,MAJOR_IVSTR_CUST_ACTA_A                    --A类专业投资者客户数
    ,MAJOR_IVSTR_CUST_ACTA_B                    --B类专业投资者客户数
	,MAJOR_IVSTR_CUST_ACTA_C                    --C类专业投资者客户数
    ,ED_FNSH_RSK_EVA_CUST_ACTA                  --已完成风险测评客户数
    ,ED_OVER_RSK_EVA_CUST_ACTA                  --已过期风险测评客户数  
    ,RSK_BEAR_ABLTY_CUST_ACTA_1                 --保守型(最低)客户数
    ,RSK_BEAR_ABLTY_CUST_ACTA_2                 --保守型客户数	  
    ,RSK_BEAR_ABLTY_CUST_ACTA_3                 --谨慎型客户数
	,RSK_BEAR_ABLTY_CUST_ACTA_4                 --稳健型客户数
	,RSK_BEAR_ABLTY_CUST_ACTA_5                 --积极型客户数
	,RSK_BEAR_ABLTY_CUST_ACTA_6                 --激进型客户数
    ,RSK_BEAR_ABLTY_CUST_ACTA                   --风险承受能力合计客户数
    ,RSK_BEAR_RENEW_ALL_CUST_ACTA               --其中2017年7月1日以前开户数
    ,RSK_BEAR_OLD_ALL_CUST_ACTA                 --2017年6月30日合格客户数        	   
)		
 PARTITION(YEAR = CAST(SUBSTR('20181228',1,4) as INT))

  SELECT     t.BRH_NO,t.BRH_SHRTNM as BRH_NAME,t.BELTO_FILIL_CDG,t.BELTO_FILIL
             ,COUNT(1)                                  as QLFD_CUST_ACTA --合格客户数	
             ,SUM(DECODE(NVL(a2.ZYJGBZ,99),3,1,0))      as MAJOR_IVSTR_CUST_ACTA_A --A类专业投资者客户数
             ,SUM(DECODE(NVL(a2.ZYJGBZ,99),2,1,0))      as MAJOR_IVSTR_CUST_ACTA_B --B类专业投资者客户数
			 ,SUM(DECODE(NVL(a2.ZYJGBZ,99),2,1,0)) 	    as MAJOR_IVSTR_CUST_ACTA_C --C类专业投资者客户数
             ,SUM(CASE WHEN NVL(a2.FXCSNL,0) IN (1,2,3,4,6,11,12,13,14,15,16)
                       THEN 1
				       ELSE 0
				       END
				)                                       as ED_FNSH_RSK_EVA_CUST_ACTA  --已完成风险测评客户数
			,SUM(CASE  WHEN NVL(a2.FXCSNL,0) IN (1,2,3,4,6,11,12,13,14,15,16)
			           AND  a2.YXRQ < = 20181228
                       THEN 1
				       ELSE 0
				       END
				)                                       as ED_OVER_RSK_EVA_CUST_ACTA  --已过期风险测评客户数

			,SUM(DECODE(NVL(a2.FXCSNL,99),11,1,0)) 	    as RSK_BEAR_ABLTY_CUST_ACTA_1 --保守型(最低)客户数
			,SUM(DECODE(NVL(a2.FXCSNL,99),12,1,0)) 	    as RSK_BEAR_ABLTY_CUST_ACTA_2 --保守型客户数
			,SUM(DECODE(NVL(a2.FXCSNL,99),13,1,0)) 	    as RSK_BEAR_ABLTY_CUST_ACTA_3 --谨慎型客户数
			,SUM(DECODE(NVL(a2.FXCSNL,99),14,1,0)) 	    as RSK_BEAR_ABLTY_CUST_ACTA_4 --稳健型客户数
			,SUM(DECODE(NVL(a2.FXCSNL,99),15,1,0)) 	    as RSK_BEAR_ABLTY_CUST_ACTA_5 --积极型客户数
			,SUM(DECODE(NVL(a2.FXCSNL,99),16,1,0)) 	    as RSK_BEAR_ABLTY_CUST_ACTA_6 --激进型客户数
            ,SUM(CASE WHEN NVL(a2.FXCSNL,0) IN (11,12,13,14,15,16)
                      THEN 1
				      ELSE 0
				      END
				)                                       as RSK_BEAR_ABLTY_CUST_ACTA  --风险承受能力合计客户数
		    ,SUM(CASE WHEN NVL(a2.FXCSNL,0) IN (11,12,13,14,15,16)
			          AND  a1.ORDI_OPNAC_DT < CAST(CONCAT(SUBSTR('20171228',1,4),'0701') as INT)
                      THEN 1
				      ELSE 0
				      END
				)                                       as RSK_BEAR_RENEW_ALL_CUST_ACTA  --其中2017年7月1日以前开户数
			,SUM(CASE WHEN  a1.ORDI_OPNAC_DT < CAST(CONCAT(SUBSTR('20171228',1,4),'0701') as INT)
                      THEN 1
				      ELSE 0
				      END
				)                                       as RSK_BEAR_OLD_ALL_CUST_ACTA  --2017年6月30日合格客户数					   
  FROM       DDW_PROD.T_DDW_INR_ORG_BRH  t
  LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO  a1
  ON        t.BRH_NO = a1.BRH_NO
  AND       a1.BUS_DATE = 20181228  
  LEFT JOIN EDW_PROD.T_EDW_T99_TKHSDXSX  a2
  ON        a1.CUST_NO = a2.KHH
  AND       a2.BUS_DATE = 20181228 
  WHERE    a1.ORDI_CUST_STAT = '0'
  AND      a1.CUST_RSK_LVL IN ('0','1','2','8','19')
  GROUP BY t.BRH_NO,t.BRH_SHRTNM ,t.BELTO_FILIL_CDG,t.BELTO_FILIL ;
   invalidate metadata DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_CUST_PTG ;

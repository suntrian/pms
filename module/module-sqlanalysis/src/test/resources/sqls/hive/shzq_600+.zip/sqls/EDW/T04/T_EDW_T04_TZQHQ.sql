--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:证券行情历史表                                                                       */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                        */
---注解FLAG(0正常代码,1退市代码,2,不计算市值,3,未上市,5.需要判断)
-----删除今天的数据---

---创建临时表
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TZQHQ_TEMP1;
 CREATE TABLE EDW_PROD.T_EDW_T04_TZQHQ_TEMP1
 as
  SELECT     a.SuspendDate
           ,a.ResumptionDate
           ,a.SECUCODE
           ,a.secumarket
           ,b.actualplaratio
           ,b.exrightdate 
           ,b.PlaPrice
 FROM 
(select      
             CAST(CONCAt(substr(a.SuspendDate,1,4),substr(a.SuspendDate,6,2),substr(a.SuspendDate,9,2) ) as INT) as SuspendDate
             ,CAST(DECODE(CONCAt(substr(a.ResumptionDate,1,4),substr(a.ResumptionDate,6,2),substr(a.ResumptionDate,9,2) ),'19000101','99999999',CONCAt(substr(a.ResumptionDate,1,4),substr(a.ResumptionDate,6,2),substr(a.ResumptionDate,9,2) )) as INT) as ResumptionDate
			 ,SUBSTR(b.SECUCODE,1,6) as SECUCODE
			 ,b.secumarket 
 from         fundext.dbo_LC_SuspendResumption  a
 left join    FUNDEXT.DBO_SECUMAIN               b
 ON           a.INNERCODE = b.INNERCODE
 AND          a.DT = b.DT
 --AND          b.DT = '%d{yyyyMMdd}'
 WHERE        a.DT = '%d{yyyyMMdd}'
 )                a
 LEFT JOIN 
 (SELECT       b.SECUCODE
              ,a.actualplaratio
              ,CAST(CONCAt(substr(a.exrightdate,1,4),substr(a.exrightdate,6,2),substr(a.exrightdate,9,2) ) as INT) as exrightdate
            --  ,a.exrightdate
              ,b.secumarket
              ,a.PlaPrice
 FROM 	     FUNDEXT.DBO_LC_ASHAREPLACEMENT	  a
 LEFT JOIN   FUNDEXT.DBO_SECUMAIN               b
 ON          a.INNERCODE = b.INNERCODE
 AND         a.DT = b.DT 
 WHERE     CONCAt(substr(payEndDate,1,4),substr(payEnddate,6,2),substr(payEndDate,9,2) ) > = '20140101'
 AND        a.DT = '%d{yyyyMMdd}'
 )   b
 ON a.secumarket = b.secumarket
 AND a.SECUCODE = b.SECUCODE
 AND a.SuspendDate < = b.exrightdate
 AND a.ResumptionDate > b.exrightdate
WHERE  b.SECUCODE IS NOT NULL ;


----红股红利除权问题
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TZQHQ_TEMP2;
 CREATE TABLE EDW_PROD.T_EDW_T04_TZQHQ_TEMP2
 as SELECT      a.SuspendDate
               ,a.ResumptionDate
               ,a.SECUCODE
               ,a.secumarket
               ,b.cashdivirmb
               ,b.bonusshareratio
               ,b.exrightdate
               ,ROW_NUMBER() OVER(PARTITION BY a.SuspendDate,a.ResumptionDate,a.SECUCODE,a.secumarket ORDER BY b.exrightdate) as NUM
 FROM 
 (select                  
              CAST(CONCAt(substr(a.SuspendDate,1,4),substr(a.SuspendDate,6,2),substr(a.SuspendDate,9,2) ) as INT) as SuspendDate
             ,CAST(DECODE(CONCAt(substr(a.ResumptionDate,1,4),substr(a.ResumptionDate,6,2),substr(a.ResumptionDate,9,2) ),'19000101','99999999',CONCAt(substr(a.ResumptionDate,1,4),substr(a.ResumptionDate,6,2),substr(a.ResumptionDate,9,2) )) as INT) as ResumptionDate
			 ,SUBSTR(b.SECUCODE,1,6) as SECUCODE
			 ,b.secumarket 
 from         fundext.dbo_LC_SuspendResumption  a
 left join    FUNDEXT.DBO_SECUMAIN               b
 ON           a.INNERCODE = b.INNERCODE
 AND          a.DT = b.DT
 --AND          b.DT = '%d{yyyyMMdd}'
 WHERE        a.DT = '%d{yyyyMMdd}'
 )                a
 LEFT JOIN 
 (SELECT       b.SECUCODE
              ,SUM(NVL(a.cashdivirmb,0))  as cashdivirmb
              ,SUM(NVL(a.BonusShareRatio,0)+NVL(a.TranAddShareRaio,0)) as bonusshareratio
              ,CAST(CONCAt(substr(a.ExDiviDate,1,4),substr(a.ExDiviDate,6,2),substr(a.ExDiviDate,9,2) ) as INT) as exrightdate
            --  ,a.exrightdate
              ,b.secumarket             
 FROM 	     FUNDEXT.DBO_LC_Dividend	  a
 LEFT JOIN   FUNDEXT.DBO_SECUMAIN               b
 ON          a.INNERCODE = b.INNERCODE
 AND         a.dt = b.DT 
 WHERE    CONCAt(substr(a.ExDiviDate,1,4),substr(a.ExDiviDate,6,2),substr(a.ExDiviDate,9,2) ) > '20140101'
 AND       a.DT = '%d{yyyyMMdd}'
GROUP BY  b.SECUCODE,exrightdate,b.secumarket 
 )   b
 ON a.secumarket = b.secumarket
 AND a.SECUCODE = b.SECUCODE
 AND a.SuspendDate < = b.exrightdate
 AND a.ResumptionDate > b.exrightdate
WHERE  b.SECUCODE IS NOT NULL ;

 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TZQHQ_TEMP3;
 CREATE TABLE EDW_PROD.T_EDW_T04_TZQHQ_TEMP3
 as SELECT      CASE WHEN t.NUM > 1 
                     THEN t.exrightdate
                     ELSE t.SuspendDate
                     END   as SuspendDate 
               ,CASE WHEN a1.SECUCODE IS NOT NULL
                     THEN a1.exrightdate
                     ELSE t.ResumptionDate
                     END  as ResumptionDate
               ,t.SECUCODE
               ,t.secumarket
               ,t.cashdivirmb
               ,t.bonusshareratio
               ,t.exrightdate
               ,t.NUM as NUM
              -- ,ROW_NUMBER() OVER(PARTITION BY a.SuspendDate,a.ResumptionDate,a.SECUCODE,a.secumarket ORDER BY b.exrightdate) as NUM
 FROM        EDW_PROD.T_EDW_T04_TZQHQ_TEMP2    t
 LEFT JOIN   EDW_PROD.T_EDW_T04_TZQHQ_TEMP2    a1
  ON         t.NUM = a1.NUM-1
  AND        t.SuspendDate = a1.SuspendDate
  AND        t.ResumptionDate = a1.ResumptionDate
  AND        t.SECUCODE = a1.SECUCODE
  AND        t.secumarket = a1.secumarket;
-------------
  DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TZQHQ_TEMP4;
  CREATE TABLE  EDW_PROD.T_EDW_T04_TZQHQ_TEMP4 as
 SELECT      
                                     %d{yyyyMMdd}          as RQ                                  --日期                                  
                                    ,t.JYS                 as JYS                                 --交易所                                 
                                    ,t.ZQDM                as ZQDM                                --证券代码
                                    ,t.ZQLB                as ZQLB                                --证券类别									
                                    ,t.JYDW                as JYDW                                --交易单位                                
                                    ,CASE WHEN t.ZXJ = 0
 									      THEN t.ZSP
										  ELSE t.ZXJ
										  END              as ZXJ                                 --最新价                                 
                                    ,t.ZSP                 as ZSP                                 --昨收盘                                                                                        
                                    ,NVL(t.ZXLX,0)         as ZXLX                                --债券利息 
                                    ,t.JJJYBZ              as JJJYBZ                              --净价交易标志	
                                    ,2                     as FLAG										  
                                    ,'JZJY'	               as XTBS	
                                    ,%d{yyyyMMdd}          as BUS_DATE						   
 FROM 	        JZJYCX.SECURITIES_TZQDM	 		t
 LEFT JOIN      (SELECT  	SEC_CD_PFX,EXG 
                 FROM    DDW_PROD.T_DDW_CFG_SEC 
			     WHERE   IF_AST = 0
			     GROUP BY SEC_CD_PFX,EXG 
				)                               a1
  ON          (SUBSTR(t.ZQDM,1,3) = a1.SEC_CD_PFX OR t.ZQDM = a1.SEC_CD_PFX) 
  AND         t.JYS = a1.EXG
  LEFT JOIN (SELECT SecurityCode,ExApplyingCode,DT 
		     FROM fundext.dbo_MF_FundArchives
			 WHERE length(trim(NVL(exapplyingcode,'')))>0
			 AND    securitycode <> exapplyingcode
			 AND    substr(securitycode,7,1) <> 'J'
			 AND    dt = '%d{yyyyMMdd}'
		    )                                    a2
  ON   t.ZQDM = a2.ExApplyingCode
  AND  (SUBSTR(t.ZQDM,1,3) = '519' AND t.JYS = 'SH')
  WHERE       (a1.EXG IS NOT NULL OR a2.ExApplyingCode IS NOT NULL)
  AND         t.DT = '%d{yyyyMMdd}'
  UNION 
   SELECT      
                                     %d{yyyyMMdd}          as RQ                                  --日期                                  
                                    ,t.JYS                 as JYS                                 --交易所                                 
                                    ,t.ZQDM                as ZQDM                                --证券代码
                                    ,t.ZQLB                as ZQLB                                --证券类别									
                                    ,t.JYDW                as JYDW                                --交易单位                                
                                    ,CASE WHEN t.ZQDM = '150772' THEN 100
									      WHEN t.ZXJ = 0
 									      THEN t.ZSP
										  ELSE t.ZXJ
										  END              as ZXJ                                 --最新价                                 
                                    ,t.ZSP                 as ZSP                                 --昨收盘                                                                                        
                                    ,NVL(t.ZXLX,0)         as ZXLX                                --债券利息 
                                    ,t.JJJYBZ              as JJJYBZ                              --净价交易标志	
                                    ,CASE WHEN t.JYS = 'SB' AND SUBSTR(t.ZQDM,1,3) IN ('238','299')
									      THEN 0 
										  WHEN t.ZQDM = '000000'
										  THEN 0
                                          WHEN t.JYS = 'SH' AND t.ZQDM = '600849'
                                          THEN 0										  
										  WHEN t.JYS = 'SH' AND SUBSTR(t.ZQDM,1,3) IN ('510','511','512','513','518') AND SUBSTR(t.ZQDM,6,1) < > '0'
										  THEN 2
										  WHEN t.JYS = 'SH' AND SUBSTR(t.ZQDM,1,3) IN ('522','523')
										  THEN 2
										  WHEN t.ZQDM IN ('519028','519521','519522','519523','519734')
										  THEN 2
										  WHEN t.ZQLB = 'F3' OR t.ZQLB = 'F5' 
										  THEN 2
										  WHEN SUBSTR(t.ZQLB,1,2) IN ('A4','A3','J3','L3','C3','J3') AND t.ZQDM NOT IN ('161912')
										  THEN 3
										  WHEN a3.ZQDM IS NOT NULL AND %d{yyyyMMdd} BETWEEN a3.SSRQ AND a3.TSRQ
                                          THEN 0 
                                          WHEN a3.ZQDM IS NOT NULL AND %d{yyyyMMdd} < a3.SSRQ 
                                          THEN 3
                                          WHEN a3.ZQDM IS NOT NULL AND %d{yyyyMMdd} > a3.TSRQ
                                          THEN 1
                                          ELSE 5										  
										  END              as FLAG										  
                                    ,'JZJY'	               as XTBS	
                                    ,%d{yyyyMMdd}          as BUS_DATE						   
 FROM 	        JZJYCX.SECURITIES_TZQDM	 		t
 LEFT JOIN      (SELECT  	SEC_CD_PFX,EXG 
                 FROM    DDW_PROD.T_DDW_CFG_SEC 
			     WHERE   IF_AST = 0
			     GROUP BY SEC_CD_PFX,EXG 
				)                               a1
  ON          (SUBSTR(t.ZQDM,1,3) = a1.SEC_CD_PFX OR t.ZQDM = a1.SEC_CD_PFX) 
  AND         t.JYS = a1.EXG
  LEFT JOIN (SELECT SecurityCode,ExApplyingCode,DT 
		     FROM fundext.dbo_MF_FundArchives
			 WHERE length(trim(NVL(exapplyingcode,'')))>0
			 AND    securitycode <> exapplyingcode
			 AND    substr(securitycode,7,1) <> 'J'
			 AND    dt = '%d{yyyyMMdd}'
		    )                                    a2
  ON   t.ZQDM = a2.ExApplyingCode
  AND  (SUBSTR(t.ZQDM,1,3) = '519' AND t.JYS = 'SH')
  LEFT JOIN  (  SELECT     NVL(a.JYS,b.JYS) as JYS
                              ,NVL(a.ZQDM,b.ZQDM) as ZQDM
							  ,LEAST(NVL(a.SSRQ,99999999),NVL(b.SSRQ,99999999)) as SSRQ
							  ,GREATEST(NVL(a.TSRQ,00000000),NVL(b.TSRQ,00000000)) as TSRQ
                    FROM      (SELECT JYS,ZQDM,SSRQ,TSRQ 
					           FROM EDW_PROD.T_EDW_T04_TSZQDM
							   WHERE BUS_DATE = %d{yyyyMMdd}
							   AND   CPLB IN (1,2,3,4,5,6,7,9)
							   AND   ZQDM NOT LIKE '%J'
							   ) a
			        FULL JOIN  (SELECT JYS,SUBSTR(ZQDM,1,6) as ZQDM,MIN(SSRQ) as SSRQ,MAX(TSRQ) as TSRQ,BUS_DATE FROM EDW_PROD.T_EDW_T04_TSZQDM
			                     WHERE CPLB = 5
				                 AND   ZQDM LIKE '%J'
								 AND BUS_DATE = %d{yyyyMMdd}
								 GROUP BY JYS,ZQDM,BUS_DATE
				                ) b
				    ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
				    AND          a.JYS = b.JYS			
             )   a3
  ON            t.ZQDM = a3.ZQDM
  AND           t.JYS = a3.JYS
  WHERE       a1.EXG IS  NULL 
  AND         a2.ExApplyingCode IS  NULL
  AND         t.DT = '%d{yyyyMMdd}'  ;
--插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TZQHQ
 (
                                  
                                 RQ               --日期
                                ,JYS              --交易所
                                ,ZQDM             --证券代码
								,ZQLB             --证券类别
                                ,JYDW             --交易单位
                                ,ZXJ              --最新价
                                ,ZSP              --昨收盘     
                                ,ZXLX             --债券利息
								,JJJYBZ           --交易净值标志
								,FLAG             --标志
								,XTBS          	  						   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT             DISTINCT 
                                 t.RQ               --日期
                                ,t.JYS              --交易所
                                ,t.ZQDM             --证券代码
								,t.ZQLB             --证券类别
                                ,t.JYDW             --交易单位
                                ,ROUND(CAST(CASE WHEN a1.SECUCODE IS NOT NULL
                                           -- AND t.BUS_DATE > = a1.exrightdate
                                           -- AND t.BUS_DATE < a1.ResumptionDate
                                            THEN (10*a5.ZXJ+a1.actualplaratio*a1.plaprice)*1.0000/(10+a1.actualplaratio)
                                            WHEN a2.SECUCODE IS NOT NULL AND a2.NUM = 2
                                          --  AND t.BUS_DATE > = a2.exrightdate
                                          --  AND t.BUS_DATE < a2.ResumptionDate
                                            THEN (10*a6.ZXJ-a2.cashdivirmb)*1.0000/(10+a2.bonusshareratio)
                                            WHEN a2.SECUCODE IS NOT NULL AND a2.NUM = 1
                                          --  AND t.BUS_DATE > = a2.exrightdate
                                          --  AND t.BUS_DATE < a2.ResumptionDate
                                            THEN (10*a7.ZXJ-a2.cashdivirmb)*1.0000/(10+a2.bonusshareratio)
                                            ELSE t.ZXJ
                                            END as DECIMAL(9,3)),3)  as ZXJ



                               --,t.zxj
                                ,t.ZSP              --昨收盘     
                                ,t.ZXLX             --债券利息
								,t.JJJYBZ           --交易净值标志
								,t.FLAG             --标志
								,t.XTBS 
                               -- ,t.BUS_DATE 
 FROM       EDW_PROD.T_EDW_T04_TZQHQ_TEMP4   t
 LEFT JOIN  EDW_PROD.T_EDW_T04_TZQHQ_TEMP1 a1
 ON         t.ZQDM = a1.SECUCODE
 AND        ((t.JYS = 'SH' AND a1.secumarket = 83)
 OR         (t.JYS = 'SZ' AND a1.secumarket = 90))
 AND        t.BUS_DATE > = a1.exrightdate
 AND        t.BUS_DATE < a1.ResumptionDate
 LEFT JOIN  EDW_PROD.T_EDW_T04_TZQHQ_TEMP3 a2
 ON         t.ZQDM = a2.SECUCODE
 AND        ((t.JYS = 'SH' AND a2.secumarket = 83)
 OR         (t.JYS = 'SZ' AND a2.secumarket = 90))
 AND        SUBSTR(a2.SECUCODE,1,3) NOT IN ('900','200')
 AND        t.BUS_DATE > = a2.exrightdate
 AND        t.BUS_DATE < a2.ResumptionDate
 LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE a4
 ON         a2.suspenddate = a4.TRD_DT
 AND        a4.NAT_DT = a4.TRD_DT
 AND        a4.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  EDW_PROD.T_EDW_T04_TZQHQ   a5
 ON         a1.suspenddate = a5.BUS_DATE
 AND         a5.ZQDM = a1.SECUCODE
 AND        ((a5.JYS = 'SH' AND a1.secumarket = 83)
 OR         (a5.JYS = 'SZ' AND a1.secumarket = 90))        
 LEFT JOIN EDW_PROD.T_EDW_T04_TZQHQ  a6
 ON         a4.lst_trd_d = a6.BUS_DATE
 AND         a6.ZQDM = a2.SECUCODE
 AND        ((a6.JYS = 'SH' AND a2.secumarket = 83)
 OR         (a6.JYS = 'SZ' AND a2.secumarket = 90))
  LEFT JOIN EDW_PROD.T_EDW_T04_TZQHQ  a7
 ON         a2.suspenddate = a7.BUS_DATE
 AND         a7.ZQDM = a2.SECUCODE
 AND        ((a7.JYS = 'SH' AND a2.secumarket = 83)
 OR         (a7.JYS = 'SZ' AND a2.secumarket = 90)) 
;


--插入数据 161131 161728 BY 2190321
--INSERT INTO EDW_PROD.T_EDW_T04_TZQHQ
-- (
--                                  
--                                 RQ               --日期
--                                ,JYS              --交易所
--                                ,ZQDM             --证券代码
--								,ZQLB             --证券类别
--                                ,JYDW             --交易单位
--                                ,ZXJ              --最新价
--                                ,ZSP              --昨收盘     
--                                ,ZXLX             --债券利息
--								,JJJYBZ           --交易净值标志
--								,FLAG             --标志
--								,XTBS          	  						   
-- ) 
-- PARTITION( bus_date = %d{yyyyMMdd})
--SELECT 
--                         %d{yyyyMMdd}                                 as RQ                                  --日期
--						,'SZ'                                         as JYS                                 --交易所
--                        ,t.SecurityCode                               as ZQDM                                --证券代码
--						,CONCAT('J0',CAST(t.TYPE as STRING))          as ZQLB                                --证券类别                           
--                        ,1                                            as JYDW                                --交易单位
--						,1                                            as ZXJ                                 --最新价
--                        ,1                                            as ZSP                                 --昨收盘
--						,0                                            as ZXLX                                --最新利息
--                        ,0                                            as JJJYBZ                              --净价交易标志                            
--                        ,0                                            AS FLAG                   
--                        ,'JZJY'                                       as XTBS
--FROM fundext.dbo_MF_FundArchives T
--WHERE SecurityCode in ('161131','161728','160142')
--and dt = '%d{yyyyMMdd}'
--;
 
 
-----
   DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TZQHQ_TEMP1;
   DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TZQHQ_TEMP2;
   DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TZQHQ_TEMP3;
   DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TZQHQ_TEMP4;
   DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TZQHQ_TEMP5;
   DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TZQHQ_TEMP6;

---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TZQHQ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ; 
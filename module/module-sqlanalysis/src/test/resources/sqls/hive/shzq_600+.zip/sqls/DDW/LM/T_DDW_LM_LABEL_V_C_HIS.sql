------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户标签结果表(历史)                                                                 */
------/* 创建人:OYJ                                                                                    */
------/* 创建时间:2018-09-26                                                                           */ 

INSERT OVERWRITE DDW_PROD.T_DDW_LM_LABEL_V_C_HIS
(
       CUST_NO
      ,LABEL_ID
      ,LABEL_VALUE
      ,BUILD_TIME
      ,BIZ_TIME_RANGE_START
      ,BIZ_TIME_RANGE_END
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT
       CUST_NO
      ,LABEL_ID
      ,LABEL_VALUE
      ,BUILD_TIME
      ,BIZ_TIME_RANGE_START
      ,BIZ_TIME_RANGE_END
FROM DDW_PROD.T_DDW_LM_LABEL_V_C
WHERE BUS_DATE = %d{yyyyMMdd}
;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_LM_LABEL_V_C_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
invalidate metadata DDW_PROD.T_DDW_LM_LABEL_V_C_HIS;
ALTER TABLE DDW_PROD.T_DDW_LM_LABEL_V_C_HIS RECOVER partitionS ;
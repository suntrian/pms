--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:个股期权佣金折扣参数单户表                                                           */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
 TRUNCATE TABLE EDW_PROD.T_EDW_T04_TSO_YJDJ_ZKCS;
------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TSO_YJDJ_ZKCS
 (
                                     BH                                  --编号                                 
                                    ,YYB                                 --营业部                                
                                    ,KHH                                 --客户号                                
                                    ,KHXM                                --客户姓名                               
                                    ,KHQZ                                --客户群组                               
                                    ,SOP_BDZQPZ                          --标的证券品种                             
                                    ,SOP_KPCBZ                           --开平仓标志                              
                                    ,SOP_FYLB                            --期权费用类别                             
                                    ,WTFSFW                              --委托方式范围                             
                                    ,ZKBL                                --折扣比例                               
                                    ,ZKXX                                --折扣下线                               
                                    ,ZKSX                                --折扣上限                               
                                    ,BDRQ                                --变动日期   
                                    ,XTBS                             								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.BH                                  as BH                                  --编号                                  
                                    ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                    ,t.KHH                                 as KHH                                 --客户号                                 
                                    ,t.KHXM                                as KHXM                                --客户姓名                                
                                    ,t.KHQZ                                as KHQZ                                --客户群组                                
                                    ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZQLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SOP_BDZQPZ                          --证券类型                                
                                    ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.KPBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SOP_KPCBZ                           --开平标志                                
                                    ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.FYLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SOP_FYLB                            --费用类别                                
                                    ,t.WTFSFW                              as WTFSFW                              --委托方式范围                              
                                    ,t.ZKBL                                as ZKBL                                --折扣比例                                
                                    ,t.ZKXX                                as ZKXX                                --折扣下线                                
                                    ,t.ZKSX                                as ZKSX                                --折扣上限                                
                                    ,t.BDRQ                                as BDRQ                                --变动日期   
                                    ,'GGQQ'				                   as XTBS				   
 FROM 		    GGQQCX.SOPTION_TSO_YJDJ_ZKCS					 t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 		 t1 
 ON             t1.DMLX = 'SOP_BDZQPZ'
 AND            t1.YXT = 'GGQQ'
 AND            t1.YDM = CAST(t.ZQLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 		 t2 
 ON             t2.DMLX = 'SOP_KPCBZ'
 AND            t2.YXT = 'GGQQ'
 AND            t2.YDM = CAST(t.KPBZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 		 t3 
 ON             t3.DMLX = 'SOP_FYLB'
 AND            t3.YXT = 'GGQQ'
 AND            t3.YDM = CAST(t.FYLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t4
 ON             t4.YXT = 'GGQQ'
 AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE 			t.DT = '%d{yyyyMMdd}';
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TSO_YJDJ_ZKCS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:产品交易明细历史表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */ 
  


--------------插入数据-------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS
(
                                   EVNT_SEQNBR                       --事件序号
                                  ,CUST_NO                           --客户号        
                                  ,CUST_NAME                         --客户姓名      
                                  ,BRH_NO                            --营业部编号                     
                                  ,ADMIN_CD                          --管理人代码
								  ,PROD_ACTNO                        --产品帐号
								  ,ISSUE_ORG                         --发行机构
                                  ,PROD_BIZ_CD                       --产品业务代码
								  ,APL_NO                            --申请编号
								  ,AGMT_NO                           --协议编号
                                  ,PROD_CD                           --产品代码
                                  ,PROD_NAME                         --产品名称
								  ,ODR_DT                            --委托日期
								  ,ODR_SHR                           --委托份额
                                  ,ODR_MOD                           --委托方式
                                  ,CCY_CD                            --币种代码
                                  ,CNFM_AMT                          --确认金额
								  ,CNFM_SHR                          --确认份额
								  ,CNFM_DT                           --确认日期
                                  ,CMSN_FEE                          --手续费
								  ,INT_AMT                           --利息金额
								  ,S7                                --代理费
								  ,S2                                --印花税
								  ,S99                               --其他费
								  ,OPRT_CLNT                         --操作终端
                                  ,PROD_CGY                          --产品类别
                                  ,MTCH_NO                           --成交编号								  
								  ,IF_TRD                            --是否算交易
								  ,IF_PRET                           --是否算赢亏
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT                  t.SEQNO                         as EVNT_SEQNBR                       --事件序号
                        ,t.KHH                           as CUST_NO                           --客户号        
                        ,t.KHXM                          as CUST_NAME                         --客户姓名      
                        ,t.YYB                           as BRH_NO                            --营业部编号        
                        ,a1.GLRDM                        as ADMIN_CD                          --管理人代码
                        ,t.JJZH                          as PROD_ACTNO                        --产品帐号
                        ,NULL                            as ISSUE_ORG                         --发行机构
                        ,t.YWDM                          as PROD_BIZ_CD                       --产品业务代码
                        ,t.SQBH                          as APL_NO                            --申请编号
                        ,NULL                            as AGMT_NO                           --协议编号
                        ,t.JJDM                          as PROD_CD                           --产品代码
                        ,t.JJJC                          as PROD_NAME                         --产品名称
                        ,t.WTRQ                          as ODR_DT                            --委托日期
                        ,t.WTFE                          as ODR_SHR                           --委托份额
                        ,t.WTFS                          as ODR_MOD                           --委托方式
                        ,t.JSBZDM                        as CCY_CD                            --币种代码
                        ,NVL(t.QRJE,0)                   as CNFM_AMT                          --确认金额
                        ,NVL(t.QRFE,0)                   as CNFM_SHR                          --确认份额
                        ,t.QRRQ                          as CNFM_DT                           --确认日期
                        ,NVL(t.SXF,0)                    as CMSN_FEE                          --手续费
                        ,NVL(t.LX,0)                     as INT_AMT                           --利息金额
                        ,NVL(t.DLF,0)                    as S7                                --代理费
                        ,NVL(t.YHS,0)                    as S2                                --印花税
                        ,NVL(t.QTF,0)                    as S99                               --其他费
                        ,t.CZZD1                         as OPRT_CLNT                         --操作终端
                        ,8                               as PROD_CGY                          --产品类别
                        ,t.CJBH                          as MTCH_NO                           --成交编号						
                       ,NVL(a2.IF_TRD,0)                 as IF_TRD                            --是否算交易
                       ,NVL(a2.IF_PRFT,0)                as IF_PRET                           --是否算赢亏
 FROM         EDW_PROD.T_EDW_T05_TOF_JJJGLS_XZB     t
 LEFT JOIN    EDW_PROD.T_EDW_T04_TOF_JJXX          a1
 ON           t.JJDM = a1.JJDM
 AND          t.TADM = a1.TADM           
 AND          a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN    (SELECT BIZ_CD
                     ,IF_TRD
                     ,IF_PRFT 
			   FROM DDW_PROD.T_DDW_CFG_FND
               GROUP BY BIZ_CD
			            ,IF_PRFT
						,IF_TRD
               )              a2
 ON            t.YWDM = a2.BIZ_CD
 WHERE         t.BUS_DATE = %d{yyyyMMdd}
 AND           t.BUS_DATE<>19000101
 UNION ALL
 SELECT                  t.SEQNO                         as EVNT_SEQNBR                       --事件序号
                        ,t.KHH                           as CUST_NO                           --客户号        
                        ,t.KHXM                          as CUST_NAME                         --客户姓名      
                        ,t.YYB                           as BRH_NO                            --营业部编号        
                        ,NULL                            as ADMIN_CD                          --管理人代码
                        ,t.CPZH                          as PROD_ACTNO                        --产品帐号
                        ,t.FXJG                          as ISSUE_ORG                         --发行机构
                        ,t.JRCP_YWDM                     as PROD_BIZ_CD                       --产品业务代码
                        ,t.SQBH                          as APL_NO                            --申请编号
                        ,t.XYBH                          as AGMT_NO                           --协议编号
                        ,t.CPDM                          as PROD_CD                           --产品代码
                        ,t.CPJC                          as PROD_NAME                         --产品名称
                        ,t.WTRQ                          as ODR_DT                            --委托日期
                        ,t.WTFE                          as ODR_SHR                           --委托份额
                        ,t.WTFS                          as ODR_MOD                           --委托方式
                        ,t.BZDM                          as CCY_CD                            --币种代码
                        ,NVL(t.QRJE,0)                   as CNFM_AMT                          --确认金额
                        ,NVL(t.QRFE,0)                   as CNFM_SHR                          --确认份额
                        ,t.QRRQ                          as CNFM_DT                           --确认日期
                        ,NVL(t.SXF,0)                    as CMSN_FEE                          --手续费
                        ,NVL(t.LXS,0)                    as INT_AMT                           --利息金额
                        ,NVL(t.DLF,0)                    as S7                                --代理费
                        ,NVL(t.YHS,0)                    as S2                                --印花税
                        ,NVL(t.QTF,0)                    as S99                               --其他费
                        ,t.CZZD1                         as OPRT_CLNT                         --操作终端
                        ,9                               as PROD_CGY                          --产品类别
                        ,NULL                            as MTCH_NO			                  --成交编号			
                       ,CASE WHEN t.JRCP_YWDM IN ('130','142','150')
							 THEN 1 				 
							 ELSE 0
							 END                          as IF_TRD                            --是否算交易
                       ,CASE WHEN t.JRCP_YWDM IN ('130','142','150')				 
							 THEN 1
							 ELSE 0
							 END                          as IF_PRET                           --是否算赢亏 
  FROM          EDW_PROD.T_EDW_T05_TJRCP_YH_JGLS                   t
  WHERE          t.BUS_DATE = %d{yyyyMMdd} 
  AND           t.BUS_DATE<>19000101
  UNION ALL 
   SELECT                NULL                            as EVNT_SEQNBR                       --事件序号
                        ,t.KHH                           as CUST_NO                           --客户号        
                        ,t.KHXM                          as CUST_NAME                         --客户姓名      
                        ,t.YYB                           as BRH_NO                            --营业部编号        
                        ,NULL                            as ADMIN_CD                          --管理人代码
                        ,t.TZZH                          as PROD_ACTNO                        --产品帐号
                        ,t.JGDM                          as ISSUE_ORG                         --发行机构
                        ,t.YWDM                          as PROD_BIZ_CD                       --产品业务代码
                        ,t.SQBH                          as APL_NO                            --申请编号
                        ,t.XYBH                          as AGMT_NO                           --协议编号
                        ,t.CPDM                          as PROD_CD                           --产品代码
                        ,a2.CPQC                          as PROD_NAME                         --产品名称
                        ,t.WTRQ                          as ODR_DT                            --委托日期
                        ,t.WTFE                          as ODR_SHR                           --委托份额
                        ,t.WTFS                          as ODR_MOD                           --委托方式
                        ,t.BZDM                          as CCY_CD                            --币种代码
                        ,NVL(t.QRJE,0)                   as CNFM_AMT                          --确认金额
                        ,NVL(t.QRFE,0)                   as CNFM_SHR                          --确认份额
                        ,t.JSRQ                          as CNFM_DT                           --确认日期
                        ,NVL(t.SXF,0)                    as CMSN_FEE                          --手续费
                        ,NVL(t.LXS,0)                    as INT_AMT                           --利息金额
                        ,NVL(t.DLF,0)                    as S7                                --代理费
                        ,NVL(t.YHS,0)                    as S2                                --印花税
                        ,NVL(t.QTF,0)                    as S99                               --其他费
                        ,null                            as OPRT_CLNT                         --操作终端
                        ,11                              as PROD_CGY                          --产品类别
                        ,NULL                            as MTCH_NO			                  --成交编号			
                       ,CASE WHEN t.YWDM IN ('130','142','150')
							 THEN 1 				 
							 ELSE 0
							 END                          as IF_TRD                            --是否算交易
                       ,CASE WHEN t.YWDM IN ('130','142','150')					 
							 THEN 1
							 ELSE 0
							 END                          as IF_PRET                           --是否算赢亏 
  FROM          EDW_PROD.T_EDW_T05_TFP_JGMXLS                   t
   LEFT JOIN     EDW_PROD.T_EDW_T04_TFP_CPDM    a2
  ON            t.CPDM = a2.CPDM
  AND           a2.BUS_DATE = %d{yyyyMMdd} 
  WHERE          t.BUS_DATE = %d{yyyyMMdd}  
 ;
 ----------------------插入数据结束------------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_TRD_PROD_TRD_DEL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS ;
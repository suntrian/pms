 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:信用账户负债明细                                                        */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */ 
  


--------------插入数据-------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS
(                                 
                                   CUST_NO                         --客户号           
                                  ,CUST_NAME                       --客户姓名         
                                  ,BRH_NO                          --营业部编号              
                                  ,EXG                             --交易所
                                  ,SEC_CD                          --证券代码
                                  ,SEC_NAME                        --证券名称
                                  ,SEC_CGY                         --证券类别    
                                  ,CCY_CD                          --币种代码
                                  ,TRD_CGY                         --交易类别
								--  ,GL_STAT                         --负债状态
								  ,CRD_ACCT_UN_GL_PRINP            --信用账户未还负债本金
								  ,CRD_ACCT_UN_PAY_GL_INT          --信用账户未还负债利息
								  ,CRD_ACCT_ADDED_GL_INT           --信用账户新增负债利息
								  ,CRD_ACCT_RTN_GL_INT             --信用账户当日归还负债利息
								  ,CRD_ACCT_GL_MRGNC_PRINP         --信用账户融资负债本金
								  ,CRD_ACCT_GT_MRGNS_PRINP         --信用账户融券负债本金
								  
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                                    t.KHH                                    as CUST_NO                         --客户号           
                                   ,t.KHXM                                   as CUST_NAME                       --客户姓名         
                                   ,t.YYB                                    as BRH_NO                          --营业部编号       
                                 --  ,a1.JGMC                                   as BRH_NAME                        --营业部名称       
                                   ,t.JYS                                    as EXG                             --交易所
                                   ,t.ZQDM                                   as SEC_CD                          --证券代码
                                   ,t.ZQMC                                   as SEC_NAME                        --证券名称        
                                   ,t.ZQLB                                   as SEC_CGY                         --证券类别    
                                   ,t.BZDM                                   as CCY_CD                          --币种代码               
                                   ,t.JYLB                                   as TRD_CGY                         --交易类别
								 --  ,t.FZZT                                   as GL_STAT                         --负债状态
                                   ,SUM(ROUND(CASE WHEN t.JYLB = 61
 								                   THEN t.FZBJ-t.HKJE+t.GHLX
										           WHEN t.JYLB = 64 AND a1.CD IS NOT NULL
										           THEN (a1.NEWST_PRC+a1.NEWST_INT*a1.NETPRC_TRD_FLG)*a1.TRD_UNIT*(t.RQSL-t.HQSL)
										           ELSE 0
										           END,2))                           as CRD_ACCT_UN_GL_PRINP            --信用账户未还负债本金金额                                 
                                   ,SUM(t.YJLX+t.FDLX+t.FXYJLX-t.GHLX)      as CRD_ACCT_UN_PAY_GL_INT          --信用账户未还负债利息
                                   ,SUM(t.YJLX+t.FDLX+t.FXYJLX-NVL(a2.YJLX,0)-NVL(a2.FDLX,0)-NVL(a2.FXYJLX,0))                   as CRD_ACCT_ADDED_GL_INT           --信用账户新增负债利息
								   ,SUM(t.GHLX)                              as CRD_ACCT_RTN_GL_INT             --信用账户当日归还负债利息
                                   ,SUM(ROUND(t.FZBJ,2))        as CRD_ACCT_GL_MRGNC_PRINP         --信用账户融资负债本金
                                   ,SUM(NVL(ROUND((a1.NEWST_PRC+a1.NEWST_INT*a1.NETPRC_TRD_FLG)*a1.TRD_UNIT*(t.RQSL-t.HQSL),2),0))			      as CRD_ACCT_GT_MRGNS_PRINP      --信用账户融券负债本金					   
  FROM      (SELECT KHH
                    ,KHXM
					,YYB
					,JYS
					,ZQDM
					,MAX(ZQMC) as ZQMC
					,MAX(ZQLB) as ZQLB
					,BZDM
					,JYLB
					,SUM(FZBJ)  as FZBJ
                    ,SUM(HKJE)  as HKJE
					,SUM(GHLX)  as GHJE
					,SUM(RQSL)  as RQSL
					,SUM(HQSL)  as HQSL
                    ,SUM(YJLX)  as YJLX
                    ,SUM(FDLX)  as FDLX
					,SUM(GHLX)	as GHLX
                    ,SUM(FXYJLX)	as FXYJLX
       			    ,SUM(FXGHLX)	as FXGHLX		
                    ,BUS_DATE   as BUS_DATE 					
            FROM EDW_PROD.T_EDW_T05_TXY_FZXXLS  
            WHERE BUS_DATE = %d{yyyyMMdd}
			GROUP BY KHH,KHXM,YYB,JYS,ZQDM,BZDM,JYLB,BUS_DATE
			)                             t
  LEFT JOIN     DDW_PROD.T_DDW_PUB_QOT                                       a1
  ON            t.JYS = a1.EXG
  AND           t.ZQDM = a1.CD
  AND           t.BUS_DATE = a1.BUS_DATE
  LEFT JOIN     (SELECT  a.KHH,a.JYS,a.ZQDM,a.JYLB,a.BUS_DATE
                        ,SUM(NVL(a.YJLX,0))  as YJLX
                        ,SUM(NVL(a.FDLX,0))  as FDLX
						,SUM(NVL(a.FXYJLX,0))	as FXYJLX
						--,SUM(DECODE(a.FZZT,3,0,a.FXYJLX))	as FXGHLX
                 FROM   EDW_PROD.T_EDW_T05_TXY_FZXXLS   a
				 WHERE  EXISTS (SELECT  1 FROM EDW_PROD.T_EDW_T99_TRD_DATE      b
		                                  WHERE   b.BUS_DATE = %d{yyyyMMdd} 
						                  AND     a.BUS_DATE = b.lst_trd_d
						                  AND     b.TRD_DT = %d{yyyyMMdd} 
								)
				 AND    a.FZZT < > 3
				 GROUP BY a.KHH,a.JYS,a.ZQDM,a.JYLB,a.BUS_DATE
                 )                                                            a2
  ON           t.KHH = a2.KHH
  AND          t.JYS = a2.JYS
  AND          t.ZQDM = a2.ZQDM
  AND          t.JYLB = a2.JYLB   
  GROUP BY      t.KHH,t.KHXM,t.YYB,t.JYS,t.ZQDM,t.ZQMC,t.ZQLB,t.BZDM,t.JYLB
;		
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS ;
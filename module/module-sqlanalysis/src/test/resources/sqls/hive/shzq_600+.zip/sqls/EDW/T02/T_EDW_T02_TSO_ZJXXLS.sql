 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:个股期权资金余额历史表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
---------插入数据开始-----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TSO_ZJXXLS(
                                    RQ                                  --日期                                 
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,KHJGBZ                              --客户机构标志                             
                                   ,BZDM                                --币种代码                               
                                   ,DRKC                                --当日开仓                               
                                   ,DRPC                                --当日平仓                               
                                   ,BZJ                                 --占用保证金                              
                                   ,BZJ_YJ                              --交易所保证金                             
                                   ,YDYSZ                               --抵押市值                               
                                   ,TDJE                                --市值保证金                              
                                   ,ZHYE                                --账户余额   
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.RQ                                  as RQ                                  --日期                                  
                                   ,t.ZJZH                                as GTZJZH                              --资金账户                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JGBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as KHJGBZ                              --机构标志                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.DRKC                                as DRKC                                --当日开仓                                
                                   ,t.DRPC                                as DRPC                                --当日平仓                                
                                   ,t.BZJ                                 as BZJ                                 --占用保证金                               
                                   ,t.BZJ_YJ                              as BZJ_YJ                              --交易所保证金                              
                                   ,t.DYSZ                                as YDYSZ                               --抵押市值                                
                                   ,t.TDJE                                as TDJE                                --市值保证金                               
                                   ,t.ZHYE                                as ZHYE                                --账户余额    
                                   ,'GGQQ'                                as XTBS								   
 FROM           GGQQCX.DATACENTER_TSO_ZJXXLS           t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'KHJGBZ'
 AND            t1.YXT = 'GGQQ'
 AND            t1.YDM = CAST(t.JGBZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'BZDM'
 AND            t2.YXT = 'GGQQ'
 AND            t2.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t3
 ON             t3.YXT = 'GGQQ'
 AND            t3.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TSO_ZJXXLS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TSO_ZJXXLS;
 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:债券市场合格投资者表                                                                       */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2017-03-07                                                                        */ 



--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_BOND_MKT_QLFD_IVSTR
(      BRH_NO                   --营业部编号  
      ,BRH_NAME                 --营业部名称
      ,OPN_PRVL_DT              --开通权限日期
      ,CUST_NO                  --客户号
      ,CUST_NAME                --客户姓名
      ,RSK_BEAR_ABLTY           --风险承受能力
      ,OPN_T_AST                --开通时资产额 
	  ,M_LAUND_RSK_LVL          --洗钱风险等级别
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
						 t.BRH_NO               		AS BRH_NO                   --营业部编号  
						,t.BRH_NAME             		AS BRH_NAME                 --营业部名称
						,t.DT      		                AS OPN_PRVL_DT              --开通权限日期 
						,t.CUST_NO              		AS CUST_NO                  --客户号
						,t.CUST_NAME            		AS CUST_NAME                --客户姓名
						,b1.RSK_BEAR_ABLTY_NAME         AS RSK_BEAR_ABLTY           --风险承受能力 
						,NVL(a2.NET_TOT_AST,0)          AS OPN_T_AST                --开通时资产额
						,b6.M_LAUND_RSK_LVL_NAME        AS M_LAUND_RSK_LVL          --洗钱风险等    
  FROM  		DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS     	t
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO 	    	  a1
  ON            t.CUST_NO = a1.CUST_NO
  AND           a1.bus_date = %d{yyyyMMdd} 
  LEFT JOIN     	DDW_PROD.V_RSK_BEAR_ABLTY                          	  b1
  ON            	a1.RSK_BEAR_ABLTY = b1.RSK_BEAR_ABLTY  
  LEFT JOIN      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY                     a2
  ON            t.cust_no = a2.cust_no
  and           t.BUS_DATE = a2.BUS_DATE
  LEFT JOIN  DDW_PROD.V_M_LAUND_RSK_LVL            b6
  ON         a1.M_LAUND_RSK_LVL = b6.M_LAUND_RSK_LVL
  WHERE			t.bus_date = %d{yyyyMMdd}
  AND           t.BIZ_SBJ = '21273' 
  ;
 
-----------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_BOND_MKT_QLFD_IVSTR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_BOND_MKT_QLFD_IVSTR ; 
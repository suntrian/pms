-- /* ***************************************** SQL Begin ***************************************** */
  ---/* 脚本功能:客户期权信息表                                                                      */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2016-11-02                                                                         */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T01_TKHQQXX; 
----插入数据开始------
 INSERT OVERWRITE EDW_PROD.T_EDW_T01_TKHQQXX
 (
                                    KHH                                 --客户号                                
                                   ,YWXT                                --业务系统                               
                                   ,YWZH                                --业务账号                               
                                   ,GLYWXT                              --关联业务系统                             
                                   ,GLYWZH                              --关联业务账号                             
                                   ,SOP_FXJB                            --个股期权投资者级别                          
                                   ,SOP_TZZFL                           --个股期权投资者分类                          
                                   ,ZDBZJ                               --最低保证金                              
                                   ,ZJGMSX                              --资金规模上限                             
                                   ,PJZF                                --评级总分                               
                                   ,SHXGEDSX                            --上海限购额度上限                           
                                   ,SZXGEDSX                            --深圳限购额度上限   
                                   ,XTBS								   
) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.YWXT                                as YWXT                                --业务系统                                
                                   ,t.YWZH                                as YWZH                                --业务账号                                
                                   ,t.GLYWXT                              as GLYWXT                              --关联业务系统                              
                                   ,t.GLYWZH                              as GLYWZH                              --关联业务账号                              
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.TZZFJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SOP_FXJB                            --投资者分级                               
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.TZZFL AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SOP_TZZFL                           --投资者分类                               
                                   ,t.ZDBZJ                               as ZDBZJ                               --最低保证金                               
                                   ,t.ZJGMSX                              as ZJGMSX                              --资金规模上限                              
                                   ,t.PJZF                                as PJZF                                --评级总分                                
                                   ,t.SHXGEDSX                            as SHXGEDSX                            --上海限购额度上限                            
                                   ,t.SZXGEDSX                            as SZXGEDSX                            --深圳限购额度上限   
                                   ,'YGT'                                 as XTBS								   
 FROM           YGTCX.CIF_TKHQQXX                            t
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING       t1 
 ON             t1.DMLX = 'SOP_FXJB'
 AND            t1.YXT = 'YGT'
 AND            t1.YDM = CAST(t.TZZFJ AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING       t2 
 ON             t2.DMLX = 'SOP_TZZFL'
 AND            t2.YXT = 'YGT'
 AND            t2.YDM = CAST(t.TZZFL AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
----插入数据结束-------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TKHQQXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T01_TKHQQXX;

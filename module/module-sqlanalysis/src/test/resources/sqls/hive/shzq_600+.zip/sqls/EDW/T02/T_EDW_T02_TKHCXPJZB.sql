 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户创新评级指标表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TKHCXPJZB; 
-------插入数据开始-----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TKHCXPJZB
(
                                    TKHCXPJZB_ID                        --客户创新评级指标主键                         
                                   ,KHH                                 --客户号                                
                                   ,CXYWLBDM                            --创新业务类别代码                           
                                   ,ZBBH                                --指标编号                               
                                   ,PJFS                                --评级分数                               
                                   ,PJSJ                                --评级数据                               
                                   ,PJSJLHZ                             --评级数据量化值                            
                                   ,PJSJZB                              --评级数据占比                             
                                   ,YPJFS                               --原评级分数                              
                                   ,YPJSJ                               --原评级数据                              
                                   ,YPJSJLHZ                            --原评级数据量化值                           
                                   ,YPJSJZB                             --原数据评级占比                            
                                   ,ZT                                  --状态                                 
                                   ,DJRQ                                --登记日期                               
                                   ,XGRQ                                --修改日期                               
                                   ,GYH                                 --修改柜员                               
                                   ,YWXT                                --业务系统                               
                                   ,YWZH                                --业务帐号 
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.ID                                  as TKHCXPJZB_ID                        --ID                                  
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.CXYWLB                              as CXYWLBDM                            --创新业务类别                              
                                   ,t.ZBBH                                as ZBBH                                --指标编号                                
                                   ,t.PJFS                                as PJFS                                --评级分数                                
                                   ,t.PJSJ                                as PJSJ                                --评级数据                                
                                   ,t.PJSJLHZ                             as PJSJLHZ                             --评级数据量化值                             
                                   ,t.PJSJZB                              as PJSJZB                              --评级数据占比                              
                                   ,t.YPJFS                               as YPJFS                               --原评级分数                               
                                   ,t.YPJSJ                               as YPJSJ                               --原评级数据                               
                                   ,t.YPJSJLHZ                            as YPJSJLHZ                            --原评级数据量化值                            
                                   ,t.YPJSJZB                             as YPJSJZB                             --原数据评级占比                             
                                   ,t.ZT                                  as ZT                                  --状态                                  
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.XGRQ                                as XGRQ                                --修改日期                                
                                   ,t.XGGY                                as GYH                                 --修改柜员                                
                                   ,t.YWXT                                as YWXT                                --业务系统                                
                                   ,t.YWZH                                as YWZH                                --业务帐号 
                                   ,'YGT'	                              as XTBS							   
 FROM      YGTCX.CIF_TKHCXPJZB   t
 WHERE     t.DT = '%d{yyyyMMdd}';
-----------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TKHCXPJZB',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TKHCXPJZB;
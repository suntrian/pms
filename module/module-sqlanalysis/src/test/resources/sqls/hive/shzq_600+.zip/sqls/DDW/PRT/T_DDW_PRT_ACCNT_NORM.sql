 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:规范账户表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2019-02-13                                                                        */ 

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP as 
SELECT   CASE WHEN a1.CUST_RSK_LVL in ('0','1','2','8')  
              THEN '合格账户'
              WHEN a1.CUST_RSK_LVL in ('7','10')  
              THEN '休眠账户'
			  WHEN a1.CUST_RSK_LVL in ('3','4','5','6','11','12','13','14','15','16','17','18')
              THEN '不合格账户'			 
              END  as ACCNT_CGY           --账户类别
        ,CASE WHEN a1.CUST_RSK_LVL in ('0','1','2','8')  
              THEN '合格账户'
              WHEN a1.CUST_RSK_LVL in ('7')  
              THEN '中登休眠(7)'
			  WHEN a1.CUST_RSK_LVL in ('10')  
              THEN '中登休眠(10)'			
			  WHEN a1.CUST_RSK_LVL in ('3')  
              THEN '身份不对应(3)第一类'
			  WHEN a1.CUST_RSK_LVL in ('4')  
              THEN '资料不规范(4)第一类'
			  WHEN a1.CUST_RSK_LVL in ('5')  
              THEN '代理关系不规范(5)第一类'
			  WHEN a1.CUST_RSK_LVL in ('6')  
              THEN '虚假身份(6)第一类'						  
			  WHEN a1.CUST_RSK_LVL in ('11')  
              THEN '国籍变更(11)第二类'
			  WHEN a1.CUST_RSK_LVL in ('12')  
              THEN '工商注销(12)第二类'
			  WHEN a1.CUST_RSK_LVL in ('13')  
              THEN '法人账户(13)第二类'
			  WHEN a1.CUST_RSK_LVL in ('14')  
              THEN '司法冻结(14)第二类'
			  WHEN a1.CUST_RSK_LVL in ('15','16','17','18')  
              THEN '不合格账户(其他)'
              END       as ACCNT_CGY_EXPLN     --账户类别说明
			,CASE WHEN a1.CUST_RSK_LVL in ('0','1','2','8')  
              THEN 1
              WHEN a1.CUST_RSK_LVL in ('7')  
              THEN 2
			  WHEN a1.CUST_RSK_LVL in ('10')  
              THEN 3
			  WHEN a1.CUST_RSK_LVL in ('3')  
              THEN 5
			  WHEN a1.CUST_RSK_LVL in ('4')  
              THEN 6
			  WHEN a1.CUST_RSK_LVL in ('5')  
              THEN 7
			  WHEN a1.CUST_RSK_LVL in ('6')  
              THEN 8			  
			  WHEN a1.CUST_RSK_LVL in ('11')  
              THEN 10
			  WHEN a1.CUST_RSK_LVL in ('12')  
              THEN 11
			  WHEN a1.CUST_RSK_LVL in ('13')  
              THEN 12
			  WHEN a1.CUST_RSK_LVL in ('14')  
              THEN 13
			  WHEN a1.CUST_RSK_LVL in ('15','16','17','18')  
              THEN 15
              END  as SEQNBR
        ,COUNT(1)         as TOT_CPTL_ACCNT_NUM  --总资金账户数
		,SUM(t.ACCNT_BAL) as CPTL_ACCNT_BAL      --资金账户余额
		,SUM(CASE WHEN a3.CUST_NO IS NULL
		          AND t.MAIN_ACCNT_FLG = 1
		          THEN 1
			      ELSE 0
			      END
			)             as PURE_ACCNT_NUM       --纯资金账户数
	    ,SUM(CASE WHEN a3.CUST_NO IS NULL		          
		          THEN t.ACCNT_BAL
			      ELSE 0
			      END
			)             as PURE_ACCNT_BAL       --纯资金账户余额
FROM        DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS t
INNER JOIN (SELECT  CUST_NO,BRH_NO,CUST_RSK_LVL 
            FROM    DDW_PROD.T_DDW_F00_CUST_CUST_INFO
            WHERE 	BUS_DATE = %d{yyyyMMdd}	
            AND     ORDI_OPNAC_DT < = %d{yyyyMMdd}
            AND   ORDI_CUST_STAT NOT IN ('3') 	
           ) a1
ON          t.CUST_NO = a1.CUST_NO
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a2
ON         t.BRH_NO = a2.BRH_NO
AND        a1.BRH_NO = a2.BRH_NO
AND        a2.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN (SELECT KHH as CUST_NO FROM JZJYCX.DATACENTER_TGDH WHERE DT = '%d{yyyyMMdd}' AND TRIM(JYS) IN ('SH','SZ','HK','SK','TA','G')
          -- AND SHRHLD_STAT  '0'
		   GROUP BY CUST_NO
          )                            a3
ON      NVL(t.CUST_NO,a1.CUST_NO) = a3.CUST_NO
WHERE   t.SYS_SRC = '普通账户'
AND     t.CCY_CD = 'RMB'
AND     NVL(t.CPTL_ACCNT_STAT,'1') < > '3' 
AND     t.BUS_DATE = %d{yyyyMMdd}
AND     a1.CUST_RSK_LVL in ('0','1','2','8','7','10','3','4','5','6','11','12','13','14','15','16','17','18') 
GROUP BY  ACCNT_CGY,ACCNT_CGY_EXPLN,SEQNBR 
;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP1 as 

SELECT   CASE WHEN a1.CUST_RSK_LVL in ('0','1','2','8')  
              THEN '合格账户'
              WHEN a1.CUST_RSK_LVL in ('7','10')  
              THEN '休眠账户'
			  WHEN a1.CUST_RSK_LVL in ('3','4','5','6','11','12','13','14','15','16','17','18')
              THEN '不合格账户'			 
              END  as ACCNT_CGY           --账户类别
        ,CASE WHEN a1.CUST_RSK_LVL in ('0','1','2','8')  
              THEN '合格账户'
              WHEN a1.CUST_RSK_LVL in ('7')  
              THEN '中登休眠(7)'
			  WHEN a1.CUST_RSK_LVL in ('10')  
              THEN '中登休眠(10)'
			  WHEN a1.CUST_RSK_LVL in ('3')  
              THEN '身份不对应(3)第一类'
			  WHEN a1.CUST_RSK_LVL in ('4')  
              THEN '资料不规范(4)第一类'
			  WHEN a1.CUST_RSK_LVL in ('5')  
              THEN '代理关系不规范(5)第一类'
			  WHEN a1.CUST_RSK_LVL in ('6')  
              THEN '虚假身份(6)第一类'			  
			  WHEN a1.CUST_RSK_LVL in ('11')  
              THEN '国籍变更(11)第二类'
			  WHEN a1.CUST_RSK_LVL in ('12')  
              THEN '工商注销(12)第二类'
			  WHEN a1.CUST_RSK_LVL in ('13')  
              THEN '法人账户(13)第二类'
			  WHEN a1.CUST_RSK_LVL in ('14')  
              THEN '司法冻结(14)第二类'
			  WHEN a1.CUST_RSK_LVL in ('15','16','17','18')  
              THEN '不合格账户(其他)'
              END       as ACCNT_CGY_EXPLN     --账户类别说明
		,CASE WHEN a1.CUST_RSK_LVL in ('0','1','2','8')  
              THEN 1
              WHEN a1.CUST_RSK_LVL in ('7')  
              THEN 2
			  WHEN a1.CUST_RSK_LVL in ('10')  
              THEN 3
			  WHEN a1.CUST_RSK_LVL in ('3')  
              THEN 5
			  WHEN a1.CUST_RSK_LVL in ('4')  
              THEN 6
			  WHEN a1.CUST_RSK_LVL in ('5')  
              THEN 7
			  WHEN a1.CUST_RSK_LVL in ('6')  
              THEN 8		  
			  WHEN a1.CUST_RSK_LVL in ('11')  
              THEN 10
			  WHEN a1.CUST_RSK_LVL in ('12')  
              THEN 11
			  WHEN a1.CUST_RSK_LVL in ('13')  
              THEN 12
			  WHEN a1.CUST_RSK_LVL in ('14')  
              THEN 13			 
			  WHEN a1.CUST_RSK_LVL in ('15','16','17','18')  
              THEN 15
              END  as SEQNBR
       ,SUM(CASE WHEN t.JYS = 'SH'
		          THEN 1
			      ELSE 0
			      END
			)         as SH_SHRHLD_NUM          --上海股东户数	
		,SUM(CASE WHEN t.JYS = 'SH'
		          AND   a3.CUST_NO IS NOT NULL
		          THEN a3.SEC_MKTVAL
			      ELSE 0
			      END
			)         as SH_MKTVAL          --上海市值	
		,SUM(CASE WHEN t.JYS = 'SH'
		          AND   a3.CUST_NO IS  NULL
		          THEN 1
			      ELSE 0
			      END
			)         as SH_EMP_ACCNT         --上海空账户数	
			
		,SUM(CASE WHEN t.JYS = 'SZ'
		          THEN 1
			      ELSE 0
			      END
			)            as SZ_SHRHLD_NUM       --深圳股东户数
			,SUM(CASE WHEN t.JYS = 'SZ'
		          AND   a3.CUST_NO IS NOT NULL
		          THEN a3.SEC_MKTVAL
			      ELSE 0
			      END
			)         as SZ_MKTVAL          --深圳市值	
		,SUM(CASE WHEN t.JYS = 'SZ'
		          AND   a3.CUST_NO IS  NULL
		          THEN 1
			      ELSE 0
			      END
			)         as SZ_EMP_ACCNT         --深圳空账户数
FROM    (SELECT KHH as CUST_NO,GDH,YYB as BRH_NO,TRIM(JYS) as JYS  FROM JZJYCX.DATACENTER_TGDH WHERE DT = '%d{yyyyMMdd}' AND TRIM(JYS) IN ('SH','SZ')   
          )  t
INNER JOIN (SELECT  CUST_NO,BRH_NO,CUST_RSK_LVL 
            FROM    DDW_PROD.T_DDW_F00_CUST_CUST_INFO
            WHERE 	BUS_DATE = %d{yyyyMMdd}	
            AND     ORDI_OPNAC_DT < = %d{yyyyMMdd}
            AND   ORDI_CUST_STAT NOT IN ('3') 	
           ) a1
ON          t.CUST_NO = a1.CUST_NO
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a2
ON         t.BRH_NO = a2.BRH_NO
AND        a1.BRH_NO = a2.BRH_NO
AND        a2.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN (SELECT CUST_NO,EXG,SHRHLD_NO,SUM(SEC_MKTVAL) AS SEC_MKTVAL 
           FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS 
		   WHERE BUS_DATE = %d{yyyyMMdd} AND EXG IN ('SH','SZ')
          GROUP BY CUST_NO,EXG,SHRHLD_NO) a3
ON        t.CUST_NO = a3.CUST_NO
AND       t.JYS = a3.EXG
AND       t.GDH = a3.SHRHLD_NO
WHERE           a1.CUST_RSK_LVL in ('0','1','2','8','7','10','3','4','5','6','11','12','13','14','15','16','17','18') 
GROUP BY  ACCNT_CGY,ACCNT_CGY_EXPLN,SEQNBR 
;


 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP2 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP2 as 
SELECT    CASE WHEN a1.CUST_RSK_LVL in ('7','10')  
              THEN '休眠账户'
			  WHEN a1.CUST_RSK_LVL in ('3','4','5','6','11','12','13','14')
              THEN '不合格账户'			 
              END  as ACCNT_CGY           --账户类别
        ,CASE WHEN a1.CUST_RSK_LVL in ('7','10')  
              THEN '休眠合计'			  
			  WHEN a1.CUST_RSK_LVL in ('3','4','5','6')
              THEN '不合格第一类小计'			  			  
			  WHEN a1.CUST_RSK_LVL in ('11','12','13','14')
			  THEN '不合格第二类小计'			 
			 
              END       as ACCNT_CGY_EXPLN     --账户类别说明
		,CASE WHEN a1.CUST_RSK_LVL in ('7','10')  
              THEN 4			 
			  WHEN a1.CUST_RSK_LVL in ('3','4','5','6')
              THEN 9			  			 
			  WHEN a1.CUST_RSK_LVL in ('11','12','13','14')
			  THEN 14			 			 
              END  as SEQNBR
        ,COUNT(1)         as TOT_CPTL_ACCNT_NUM  --总资金账户数
		,SUM(t.ACCNT_BAL) as CPTL_ACCNT_BAL      --资金账户余额
		,SUM(CASE WHEN a3.CUST_NO IS NULL
		          AND t.MAIN_ACCNT_FLG = 1
		          THEN 1
			      ELSE 0
			      END
			)             as PURE_ACCNT_NUM       --纯资金账户数
	    ,SUM(CASE WHEN a3.CUST_NO IS NULL		          
		          THEN t.ACCNT_BAL
			      ELSE 0
			      END
			)             as PURE_ACCNT_BAL       --纯资金账户余额
FROM        DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS t
INNER JOIN (SELECT  CUST_NO,BRH_NO,CUST_RSK_LVL 
            FROM    DDW_PROD.T_DDW_F00_CUST_CUST_INFO
            WHERE 	BUS_DATE = %d{yyyyMMdd}	
            AND     ORDI_OPNAC_DT < = %d{yyyyMMdd}
            AND   ORDI_CUST_STAT NOT IN ('3') 	
           ) a1
ON          t.CUST_NO = a1.CUST_NO
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a2
ON         t.BRH_NO = a2.BRH_NO
AND        a1.BRH_NO = a2.BRH_NO
AND        a2.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN (SELECT KHH as CUST_NO FROM JZJYCX.DATACENTER_TGDH WHERE DT = '%d{yyyyMMdd}' AND TRIM(JYS) IN ('SH','SZ','HK','SK','TA','G')
          -- AND SHRHLD_STAT  '0'
		   GROUP BY CUST_NO
          )                            a3
ON      NVL(t.CUST_NO,a1.CUST_NO) = a3.CUST_NO
WHERE   t.SYS_SRC = '普通账户'
AND     t.CCY_CD = 'RMB'
AND     NVL(t.CPTL_ACCNT_STAT,'1') < > '3' 
AND     t.BUS_DATE = %d{yyyyMMdd}
AND     a1.CUST_RSK_LVL in ('7','10','3','4','5','6','11','12','13','14') 
GROUP BY  ACCNT_CGY,ACCNT_CGY_EXPLN,SEQNBR 
;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP3 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP3 as 

SELECT   CASE WHEN a1.CUST_RSK_LVL in ('7','10')  
              THEN '休眠账户'
			  WHEN a1.CUST_RSK_LVL in ('3','4','5','6','11','12','13','14')
              THEN '不合格账户'			 
              END  as ACCNT_CGY           --账户类别
        ,CASE WHEN a1.CUST_RSK_LVL in ('7','10')  
              THEN '休眠合计'			  
			  WHEN a1.CUST_RSK_LVL in ('3','4','5','6')
              THEN '不合格第一类小计'			  			  
			  WHEN a1.CUST_RSK_LVL in ('11','12','13','14')
			  THEN '不合格第二类小计'			 
			 
              END       as ACCNT_CGY_EXPLN     --账户类别说明
		,CASE WHEN a1.CUST_RSK_LVL in ('7','10')  
              THEN 4			 
			  WHEN a1.CUST_RSK_LVL in ('3','4','5','6')
              THEN 9			  			 
			  WHEN a1.CUST_RSK_LVL in ('11','12','13','14')
			  THEN 14			 			 
              END  as SEQNBR
       ,SUM(CASE WHEN t.JYS = 'SH'
		          THEN 1
			      ELSE 0
			      END
			)         as SH_SHRHLD_NUM          --上海股东户数	
		,SUM(CASE WHEN t.JYS = 'SH'
		          AND   a3.CUST_NO IS NOT NULL
		          THEN a3.SEC_MKTVAL
			      ELSE 0
			      END
			)         as SH_MKTVAL          --上海市值	
		,SUM(CASE WHEN t.JYS = 'SH'
		          AND   a3.CUST_NO IS  NULL
		          THEN 1
			      ELSE 0
			      END
			)         as SH_EMP_ACCNT         --上海空账户数	
			
		,SUM(CASE WHEN t.JYS = 'SZ'
		          THEN 1
			      ELSE 0
			      END
			)            as SZ_SHRHLD_NUM       --深圳股东户数
			,SUM(CASE WHEN t.JYS = 'SZ'
		          AND   a3.CUST_NO IS NOT NULL
		          THEN a3.SEC_MKTVAL
			      ELSE 0
			      END
			)         as SZ_MKTVAL          --深圳市值	
		,SUM(CASE WHEN t.JYS = 'SZ'
		          AND   a3.CUST_NO IS  NULL
		          THEN 1
			      ELSE 0
			      END
			)         as SZ_EMP_ACCNT         --深圳空账户数
FROM    (SELECT KHH as CUST_NO,GDH,YYB as BRH_NO,TRIM(JYS) as JYS  FROM JZJYCX.DATACENTER_TGDH WHERE DT = '%d{yyyyMMdd}' AND TRIM(JYS) IN ('SH','SZ')   
          )  t
INNER JOIN (SELECT  CUST_NO,BRH_NO,CUST_RSK_LVL 
            FROM    DDW_PROD.T_DDW_F00_CUST_CUST_INFO
            WHERE 	BUS_DATE = %d{yyyyMMdd}	
            AND     ORDI_OPNAC_DT < = %d{yyyyMMdd}
            AND   ORDI_CUST_STAT NOT IN ('3') 	
           ) a1
ON          t.CUST_NO = a1.CUST_NO
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a2
ON         t.BRH_NO = a2.BRH_NO
AND        a1.BRH_NO = a2.BRH_NO
AND        a2.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN (SELECT CUST_NO,EXG,SHRHLD_NO,SUM(SEC_MKTVAL) AS SEC_MKTVAL 
           FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS 
		   WHERE BUS_DATE = %d{yyyyMMdd} AND EXG IN ('SH','SZ')
          GROUP BY CUST_NO,EXG,SHRHLD_NO) a3
ON        t.CUST_NO = a3.CUST_NO
AND       t.JYS = a3.EXG
AND       t.GDH = a3.SHRHLD_NO
WHERE           a1.CUST_RSK_LVL in  ('7','10','3','4','5','6','11','12','13','14') 
GROUP BY  ACCNT_CGY,ACCNT_CGY_EXPLN,SEQNBR 
;


 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP4 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP4 as 
SELECT    CASE WHEN a1.CUST_RSK_LVL in ('3','4','5','6','11','12','13','14','15','16','17','18')
              THEN '不合格账户'			 
              END  as ACCNT_CGY           --账户类别
        ,CASE WHEN a1.CUST_RSK_LVL in ('3','4','5','6','11','12','13','14','15','16','17','18')  
              THEN '不合格合计'			  			 		 			 
              END       as ACCNT_CGY_EXPLN     --账户类别说明
		,CASE WHEN a1.CUST_RSK_LVL in ('3','4','5','6','11','12','13','14','15','16','17','18')  
              THEN 16			 			 
              END  as SEQNBR
        ,COUNT(1)         as TOT_CPTL_ACCNT_NUM  --总资金账户数
		,SUM(t.ACCNT_BAL) as CPTL_ACCNT_BAL      --资金账户余额
		,SUM(CASE WHEN a3.CUST_NO IS NULL
		          AND t.MAIN_ACCNT_FLG = 1
		          THEN 1
			      ELSE 0
			      END
			)             as PURE_ACCNT_NUM       --纯资金账户数
	    ,SUM(CASE WHEN a3.CUST_NO IS NULL		          
		          THEN t.ACCNT_BAL
			      ELSE 0
			      END
			)             as PURE_ACCNT_BAL       --纯资金账户余额
FROM        DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS t
INNER JOIN (SELECT  CUST_NO,BRH_NO,CUST_RSK_LVL 
            FROM    DDW_PROD.T_DDW_F00_CUST_CUST_INFO
            WHERE 	BUS_DATE = %d{yyyyMMdd}	
            AND     ORDI_OPNAC_DT < = %d{yyyyMMdd}
            AND   ORDI_CUST_STAT NOT IN ('3') 	
           ) a1
ON          t.CUST_NO = a1.CUST_NO
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a2
ON         t.BRH_NO = a2.BRH_NO
AND        a1.BRH_NO = a2.BRH_NO
AND        a2.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN (SELECT KHH as CUST_NO FROM JZJYCX.DATACENTER_TGDH WHERE DT = '%d{yyyyMMdd}' AND TRIM(JYS) IN ('SH','SZ','HK','SK','TA','G')
          -- AND SHRHLD_STAT  '0'
		   GROUP BY CUST_NO
          )                            a3
ON      NVL(t.CUST_NO,a1.CUST_NO) = a3.CUST_NO
WHERE   t.SYS_SRC = '普通账户'
AND     t.CCY_CD = 'RMB'
AND     NVL(t.CPTL_ACCNT_STAT,'1') < > '3' 
AND     t.BUS_DATE = %d{yyyyMMdd}
AND     a1.CUST_RSK_LVL in ('3','4','5','6','11','12','13','14','15','16','17','18') 
GROUP BY  ACCNT_CGY,ACCNT_CGY_EXPLN,SEQNBR 
;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP5 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP5 as 

SELECT    CASE WHEN a1.CUST_RSK_LVL in ('3','4','5','6','11','12','13','14','15','16','17','18')
              THEN '不合格账户'			 
              END  as ACCNT_CGY           --账户类别
        ,CASE WHEN a1.CUST_RSK_LVL in ('3','4','5','6','11','12','13','14','15','16','17','18')  
              THEN '不合格合计'			  			 		 			 
              END       as ACCNT_CGY_EXPLN     --账户类别说明
		,CASE WHEN a1.CUST_RSK_LVL in ('3','4','5','6','11','12','13','14','15','16','17','18')  
              THEN 16			 			 
              END  as SEQNBR
       ,SUM(CASE WHEN t.JYS = 'SH'
		          THEN 1
			      ELSE 0
			      END
			)         as SH_SHRHLD_NUM          --上海股东户数	
		,SUM(CASE WHEN t.JYS = 'SH'
		          AND   a3.CUST_NO IS NOT NULL
		          THEN a3.SEC_MKTVAL
			      ELSE 0
			      END
			)         as SH_MKTVAL          --上海市值	
		,SUM(CASE WHEN t.JYS = 'SH'
		          AND   a3.CUST_NO IS  NULL
		          THEN 1
			      ELSE 0
			      END
			)         as SH_EMP_ACCNT         --上海空账户数	
			
		,SUM(CASE WHEN t.JYS = 'SZ'
		          THEN 1
			      ELSE 0
			      END
			)            as SZ_SHRHLD_NUM       --深圳股东户数
			,SUM(CASE WHEN t.JYS = 'SZ'
		          AND   a3.CUST_NO IS NOT NULL
		          THEN a3.SEC_MKTVAL
			      ELSE 0
			      END
			)         as SZ_MKTVAL          --深圳市值	
		,SUM(CASE WHEN t.JYS = 'SZ'
		          AND   a3.CUST_NO IS  NULL
		          THEN 1
			      ELSE 0
			      END
			)         as SZ_EMP_ACCNT         --深圳空账户数
FROM    (SELECT KHH as CUST_NO,GDH,YYB as BRH_NO,TRIM(JYS) as JYS  FROM JZJYCX.DATACENTER_TGDH WHERE DT = '%d{yyyyMMdd}' AND TRIM(JYS) IN ('SH','SZ')   
          )  t
INNER JOIN (SELECT  CUST_NO,BRH_NO,CUST_RSK_LVL 
            FROM    DDW_PROD.T_DDW_F00_CUST_CUST_INFO
            WHERE 	BUS_DATE = %d{yyyyMMdd}	
            AND     ORDI_OPNAC_DT < = %d{yyyyMMdd}
            AND   ORDI_CUST_STAT NOT IN ('3') 	
           ) a1
ON          t.CUST_NO = a1.CUST_NO
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a2
ON         t.BRH_NO = a2.BRH_NO
AND        a1.BRH_NO = a2.BRH_NO
AND        a2.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN (SELECT CUST_NO,EXG,SHRHLD_NO,SUM(SEC_MKTVAL) AS SEC_MKTVAL 
           FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS 
		   WHERE BUS_DATE = %d{yyyyMMdd} AND EXG IN ('SH','SZ')
          GROUP BY CUST_NO,EXG,SHRHLD_NO) a3
ON        t.CUST_NO = a3.CUST_NO
AND       t.JYS = a3.EXG
AND       t.GDH = a3.SHRHLD_NO
WHERE           a1.CUST_RSK_LVL in  ('3','4','5','6','11','12','13','14','15','16','17','18') 
GROUP BY  ACCNT_CGY,ACCNT_CGY_EXPLN,SEQNBR 
;



INSERT OVERWRITE DDW_PROD.T_DDW_PRT_ACCNT_NORM
(
								 ACCNT_CGY               --账户类别
								 ,ACCNT_CGY_EXPLN         --账户类别说明
								 ,TOT_CPTL_ACCNT_NUM      --总资金账户数
								 ,CPTL_ACCNT_BAL          --资金账户余额
								 ,PURE_ACCNT_NUM          --纯资金账户数
								 ,PURE_ACCNT_BAL          --纯资金账户余额
								 ,SH_SHRHLD_NUM           --上海股东户数	
								 ,SH_MKTVAL               --上海市值	
								 ,SH_EMP_ACCNT            --上海空账户数
								 ,SZ_SHRHLD_NUM           --深圳股东户数
								 ,SZ_MKTVAL               --深圳市值
								 ,SZ_EMP_ACCNT            --深圳空账户数
								 ,SEQNBR                  --序号
								
)		
 PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT                           t.ACCNT_CGY               --账户类别
								 ,t.ACCNT_CGY_EXPLN         --账户类别说明
								 ,t.TOT_CPTL_ACCNT_NUM      --总资金账户数
								 ,t.CPTL_ACCNT_BAL          --资金账户余额
								 ,t.PURE_ACCNT_NUM          --纯资金账户数
								 ,t.PURE_ACCNT_BAL          --纯资金账户余额
								 ,NVL(a1.SH_SHRHLD_NUM,0)           --上海股东户数	
								 ,NVL(a1.SH_MKTVAL,0)               --上海市值	
								 ,NVL(a1.SH_EMP_ACCNT,0)            --上海空账户数
								 ,NVL(a1.SZ_SHRHLD_NUM,0)           --深圳股东户数
								 ,NVL(a1.SZ_MKTVAL,0)               --深圳市值
								 ,NVL(a1.SZ_EMP_ACCNT,0)            --深圳空账户数
								 ,NVL(t.SEQNBR,a1.SEQNBR)
 FROM      DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP t
 LEFT JOIN DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP1 a1
 ON        t.ACCNT_CGY = a1.ACCNT_CGY
 AND       t.ACCNT_CGY_EXPLN = a1.ACCNT_CGY_EXPLN
 AND       t.SEQNBR = a1.SEQNBR
 UNION ALL
  SELECT                           t.ACCNT_CGY               --账户类别
								 ,t.ACCNT_CGY_EXPLN         --账户类别说明
								 ,t.TOT_CPTL_ACCNT_NUM      --总资金账户数
								 ,t.CPTL_ACCNT_BAL          --资金账户余额
								 ,t.PURE_ACCNT_NUM          --纯资金账户数
								 ,t.PURE_ACCNT_BAL          --纯资金账户余额
								 ,NVL(a1.SH_SHRHLD_NUM,0)           --上海股东户数	
								 ,NVL(a1.SH_MKTVAL,0)               --上海市值	
								 ,NVL(a1.SH_EMP_ACCNT,0)            --上海空账户数
								 ,NVL(a1.SZ_SHRHLD_NUM,0)           --深圳股东户数
								 ,NVL(a1.SZ_MKTVAL,0)               --深圳市值
								 ,NVL(a1.SZ_EMP_ACCNT,0)            --深圳空账户数
								 ,NVL(t.SEQNBR,a1.SEQNBR)
 FROM      DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP2 t
 LEFT JOIN DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP3 a1
 ON        t.ACCNT_CGY = a1.ACCNT_CGY
 AND       t.ACCNT_CGY_EXPLN = a1.ACCNT_CGY_EXPLN
 AND       t.SEQNBR = a1.SEQNBR
  UNION ALL
  SELECT                           t.ACCNT_CGY               --账户类别
								 ,t.ACCNT_CGY_EXPLN         --账户类别说明
								 ,t.TOT_CPTL_ACCNT_NUM      --总资金账户数
								 ,t.CPTL_ACCNT_BAL          --资金账户余额
								 ,t.PURE_ACCNT_NUM          --纯资金账户数
								 ,t.PURE_ACCNT_BAL          --纯资金账户余额
								 ,NVL(a1.SH_SHRHLD_NUM,0)           --上海股东户数	
								 ,NVL(a1.SH_MKTVAL,0)               --上海市值	
								 ,NVL(a1.SH_EMP_ACCNT,0)            --上海空账户数
								 ,NVL(a1.SZ_SHRHLD_NUM,0)           --深圳股东户数
								 ,NVL(a1.SZ_MKTVAL,0)               --深圳市值
								 ,NVL(a1.SZ_EMP_ACCNT,0)            --深圳空账户数
								 ,NVL(t.SEQNBR,a1.SEQNBR)
 FROM      DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP4 t
 LEFT JOIN DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP5 a1
 ON        t.ACCNT_CGY = a1.ACCNT_CGY
 AND       t.ACCNT_CGY_EXPLN = a1.ACCNT_CGY_EXPLN
 AND       t.SEQNBR = a1.SEQNBR
 ;
----
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP1 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP2 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP3 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP4 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ACCNT_NORM_TEMP5 ;
 
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_ACCNT_NORM',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_ACCNT_NORM ;
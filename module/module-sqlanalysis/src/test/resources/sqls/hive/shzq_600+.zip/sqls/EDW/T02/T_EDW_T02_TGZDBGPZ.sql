 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:约定购回标的证券表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TGZDBGPZ ; 
---------插入数据开始--------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TGZDBGPZ
(
                                    NBDM                                --内部代码                               
                                   ,DBGBH                               --代保管编号                              
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,SFZH                                --身份证号                               
                                   ,DBGME                               --代保管面额                              
                                   ,DQBX                                --到期本息                               
                                   ,DBGRQ                               --代保管日期                              
                                   ,DFRQ                                --兑付日期                               
                                   ,DQRQ                                --到期日期                               
                                   ,DFJE                                --兑付金额                               
                                   ,DFLL                                --兑付利率                               
                                   ,DFLX                                --兑付利息                               
                                   ,S1                                  --佣金                                 
                                   ,YHS                                 --印花税                                
                                   ,DBGGY                               --代保管柜员                              
                                   ,DFGY                                --兑付柜员                               
                                   ,DBGYYB                              --代保管营业部                             
                                   ,DFYYB                               --兑付营业部                              
                                   ,DQZT                                --DQZT                               
                                   ,GSRQ                                --GSRQ                               
                                   ,ZY                                  --摘要                                 
                                   ,S3                                  --过户费                                
                                   ,S4                                  --附加费                                
                                   ,LXSL                                --利息税率                               
                                   ,LXS                                 --利息税                                
                                   ,ZQMC                                --证券名称                               
                                   ,DFSJ                                --兑付时间                               
                                   ,DBGSJ                               --代保管时间                              
                                   ,GSSJ                                --GSSJ                               
                                   ,LSH                                 --流水号    
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
select 
                                    t.NBDM                                as NBDM                                --内部代码                                
                                   ,t.DBGBH                               as DBGBH                               --代保管编号                               
                                   ,t.ZJZH                                as GTZJZH                              --资金账号                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.SFZH                                as SFZH                                --身份证号                                
                                   ,t.DBGME                               as DBGME                               --代保管面额                               
                                   ,t.DQBX                                as DQBX                                --到期本息                                
                                   ,t.DBGRQ                               as DBGRQ                               --代保管日期                               
                                   ,t.DFRQ                                as DFRQ                                --兑付日期                                
                                   ,t.DQRQ                                as DQRQ                                --到期日期                                
                                   ,t.DFJE                                as DFJE                                --兑付金额                                
                                   ,t.DFLL                                as DFLL                                --兑付利率                                
                                   ,t.DFLX                                as DFLX                                --兑付利息                                
                                   ,t.S1                                  as S1                                  --佣金                                  
                                   ,t.S2                                  as YHS                                 --印花税                                 
                                   ,t.DBGGY                               as DBGGY                               --代保管柜员                               
                                   ,t.DFGY                                as DFGY                                --兑付柜员                                
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.DBGYYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as DBGYYB                              --代保管营业部                              
                                   ,CASE WHEN t.DFYYB IS NULL OR LENGTH(TRIM(nvl(t.DFYYB,''))) = 0
                                         THEN NULL								   
								         ELSE CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.DFYYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) 
										 END as DFYYB                               --兑付营业部                               
                                   ,t.DQZT                                as DQZT                                --                                    
                                   ,t.GSRQ                                as GSRQ                                --                                    
                                   ,t.ZY                                  as ZY                                  --摘要                                  
                                   ,t.S3                                  as S3                                  --过户费                                 
                                   ,t.S4                                  as S4                                  --附加费                                 
                                   ,t.LXSL                                as LXSL                                --利息税率                                
                                   ,t.LXS                                 as LXS                                 --利息税                                 
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.DFSJ                                as DFSJ                                --兑付时间                                
                                   ,t.DBGSJ                               as DBGSJ                               --代保管时间                               
                                   ,t.GSSJ                                as GSSJ                                --                                    
                                   ,t.LSH                                 as LSH                                 --流水号     
								   ,'JZJY'                                as XTBS
                                								   
 FROM           JZJYCX.SECURITIES_TGZDBGPZ                     t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'JZJY'
 AND            t1.JGDM = CAST(t.DBGYYB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t2
 ON             t2.YXT = 'JZJY'
 AND            t2.JGDM = CAST(t.DFYYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TGZDBGPZ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TGZDBGPZ;
 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:约定购回客户信息表                                                                 */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 

 TRUNCATE TABLE DDW_PROD.T_DDW_PRT_PROMS_RPHS_CUST_INFO;
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_PROMS_RPHS_CUST_INFO
(
						 BRH_NO                   --营业部编号 
						,BRH_NAME                 --营业部名称 
						,APL_DT                   --申请日期  
						,CUST_NO                  --客户号   
						,CUST_NAME                --客户姓名  
						,CTF_CGY_CD               --证件类别代码
						,CTF_NO                   --证件号码  
						,DEPMGT_BANK              --存管银行  
						,CTRL_ATTR                --控制属性  
						,IMAGE_TP                 --影像资料  
						,M_LAUND_RSK_LVL          --洗钱风险等级
						,RSK_BEAR_ABLTY           --风险承受能力
						,CTF_EXPR_DT              --证件截至日期
						,CTCT_ADDR                --联系地址  
						,CTCT_TEL                 --联系电话  
						,PHONE                    --手机    
						,EDU_CD                   --学历代码  
						,OCP_CD                   --职业代码  
) 
 PARTITION(bus_date=%d{yyyyMMdd})
SELECT 
						 a1.BRH_NO         	            AS BRH_NO                   --营业部编号         
						,a1.BRH_NAME       	            AS BRH_NAME                 --营业部名称         
						,t.OPN_DATE        	            AS APL_DT                   --申请日期          
						,t.CUST_NO        	            AS CUST_NO                  --客户号           
						,a1.CUST_NAME      	            AS CUST_NAME                --客户姓名          
						,b1.CTF_CGY_CD_NAME                  AS CTF_CGY_CD               --证件类别代码                
						,a1.CTF_NO                      AS CTF_NO                   --证件号码          
						,a1.DEPMGT_BANK                 AS DEPMGT_BANK              --存管银行          
						,a1.CTRL_ATTR                   AS CTRL_ATTR                --控制属性          
						,a1.IMAGE_TP                    AS IMAGE_TP                 --影像资料          
						,b6.M_LAUND_RSK_LVL_NAME             AS M_LAUND_RSK_LVL          --洗钱风险等级        
						,b2.RSK_BEAR_ABLTY_NAME              AS RSK_BEAR_ABLTY           --风险承受能力        
						,a1.CTF_EXPR_DT                 AS CTF_EXPR_DT              --证件截至日期        
						,a1.CTCT_ADDR                   AS CTCT_ADDR                --联系地址          
						,a1.CTCT_TEL                    AS CTCT_TEL                 --联系电话          
						,a1.PHONE                       AS PHONE                    --手机            
						,b3.EDU_CD_NAME                      AS EDU_CD                   --学历代码          
						,b4.OCP_CD_NAME                      AS OCP_CD                   --职业代码          
  FROM  		    (SELECT   CUST_NO AS CUST_NO
                         ,MIN(OPN_Dt) AS OPN_DATE
                         ,BUS_DATE AS BUS_DATE
                FROM     DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL       
                WHERE    opn_PRVL = 102  			
                GROUP BY CUST_NO,BUS_DATE
                )                                       	t   
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO              	a1
  ON            t.CUST_NO = a1.CUST_NO 
  AND           t.bus_date = a1.bus_date 
LEFT JOIN 		DDW_PROD.V_CTF_CGY_CD					b1
ON				a1.CTF_CGY_CD = b1.CTF_CGY_CD
LEFT JOIN 		DDW_PROD.V_RSK_BEAR_ABLTY				b2
ON				a1.RSK_BEAR_ABLTY = b2.RSK_BEAR_ABLTY
LEFT JOIN 		DDW_PROD.V_EDU_CD						b3
ON				a1.EDU_CD = b3.EDU_CD
LEFT JOIN 		DDW_PROD.V_OCP_CD						b4
ON				a1.OCP_CD = b4.OCP_CD 
LEFT JOIN  DDW_PROD.V_M_LAUND_RSK_LVL            b6
  ON         a1.M_LAUND_RSK_LVL = b6.M_LAUND_RSK_LVL 
  WHERE			t.bus_date = %d{yyyyMMdd}
  ;
-----------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_PROMS_RPHS_CUST_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_PROMS_RPHS_CUST_INFO;
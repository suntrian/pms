 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:上证英才排位赛产品销售统计表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-05-14                                                                       */ 
----临时表1
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_PROD_SALE_STATS_TEMP  ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_PROD_SALE_STATS_TEMP
 as 
 SELECT     t.CUST_NO       as CUST_NO
           ,t.SEC_CD        as PROD_CD
		   ,a1.PROD_NAME    as PROD_NAME
		   ,SUM(CAST(t.MTCH_AMT*1.000000/10000 as DECIMAL(38,6)))   as PROD_SALE_AMT
		   ,a1.PROD_CGY     as PROD_CGY
		   ,a1.CNVT_COFE_A  as CNVT_COFE_A
		   ,a1.CNVT_COFE_B  as CNVT_COFE_B
		   ,SUM(CAST(NVL(t.MTCH_AMT*1.000000/10000,0)*a1.CNVT_COFE_B/a1.CNVT_COFE_A as DECIMAL(38,6)))   as PROD_SALE_STD_AMT
 FROM      DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS  t
 LEFT JOIN DDW_PROD.T_DDW_CFG_FILIL_PROD_SALE      a1
 ON        t.SEC_CD = a1.PROD_CD
 LEFT JOIN (SELECT CUST_NO,SEC_CD,MTCH_DT 
            FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
			WHERE ODR_CGY = 80
			AND   SUBSTR(SEC_CGY,1,1) IN ('J','E','L')
			GROUP BY CUST_NO,SEC_CD,MTCH_DT
			)    a2
 ON   t.CUST_NO = a2.CUST_NO
 AND  t.SEC_CD = a2.SEC_CD
 AND  t.ODR_CGY = 83
 WHERE  t.ODR_CGY IN (1,29,1111,83,42)
 AND    t.BUS_DATE = %d{yyyyMMdd}
 AND    SUBSTR(t.SEC_CGY,1,1) IN ('J','E','L')
 AND    a1.PROD_CD IS NOT NULL
 AND    NVL(a2.MTCH_DT,t.MTCH_DT) BETWEEN a1.STRT_DT AND a1.END_DT
 GROUP BY CUST_NO,PROD_CD,PROD_CGY,CNVT_COFE_A,CNVT_COFE_B,PROD_NAME
 UNION ALL
  SELECT     t.CUST_NO       as CUST_NO
           ,t.PROD_CD        as PROD_CD
		   ,a1.PROD_NAME    as PROD_NAME
		   ,SUM(CAST(t.CNFM_AMT*1.000000/10000 as DECIMAL(38,6)))   as PROD_SALE_AMT
		   ,a1.PROD_CGY     as PROD_CGY
		   ,a1.CNVT_COFE_A  as CNVT_COFE_A
		   ,a1.CNVT_COFE_B  as CNVT_COFE_B
		   ,SUM(CAST(NVL(t.CNFM_AMT*1.000000/10000,0)*a1.CNVT_COFE_B/a1.CNVT_COFE_A as DECIMAL(38,6)))   as PROD_SALE_STD_AMT
 FROM      DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS  t
 LEFT JOIN DDW_PROD.T_DDW_CFG_FILIL_PROD_SALE      a1
 ON        t.PROD_CD = a1.PROD_CD
 WHERE  t.PROD_BIZ_CD IN ('122','130','139')
 AND    t.BUS_DATE = %d{yyyyMMdd}
 AND    a1.PROD_CD IS NOT NULL
 AND    t.ODR_DT BETWEEN a1.STRT_DT AND a1.END_DT
 GROUP BY CUST_NO,PROD_CD,PROD_CGY,CNVT_COFE_A,CNVT_COFE_B,PROD_NAME ;
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_PROD_SALE_STATS
(
		   PROD_CGY                --产品类别
          ,BRH_NO                  --营业部编号
          ,BRH_NAME                --营业部名称
          ,BELTO_FILIL             --所属分公司
		  ,BELTO_FILIL_CDG	 	   --所属分公司编码
          ,PSN_NO                  --人员编码
          ,PSN_NAME                --人员姓名 
          ,PSN_CGY                 --人员类别		  
          ,PROD_CD                 --产品代码
          ,PROD_NAME               --产品名称
		  ,CUST_NO                 --客户号
		  ,SALE_DT                 --销售日期
          ,PROD_SALE_AMT           --产品销售量
          ,CNVT_COFE               --折算系数
          ,PROD_SALE_STD_AMT       --产品销售标准额 
)		
 PARTITION(BUS_DATE = %d{yyyyMMdd} )
 SELECT 
		   t.PROD_CGY                  as PROD_CGY          --产品类别
          ,NVL(a4.JJRYYB,a5.YYB)       as BRH_NO            --营业部编号
          ,a7.brh_shrtnm               as BRH_NAME          --营业部名称
          ,a7.BELTO_FILIL              as BELTO_FILIL       --所属分公司
		  ,a7.BELTO_FILIL_CDG		   as BELTO_FILIL_CDG	--所属分公司编码
          ,a1.PSN_NO                   as PSN_NO            --人员编码
          ,NVL(a4.JJRXM,a5.RYXM)       as PSN_NAME          --人员姓名       
          ,a6.PSN_CGY_NAME             as PSN_CGY           --人员类别	
		  ,t.PROD_CD                   as PROD_CD           --产品代码
          ,t.PROD_NAME                 as PROD_NAME         --产品名称
		  ,t.CUST_NO                   as CUST_NO           --客户号
		  ,%d{yyyyMMdd}                    as SALE_DT           --销售日期
          ,SUM(t.PROD_SALE_AMT)        as PROD_SALE_AMT           --产品销售量
          ,CONCAT(CAST(CNVT_COFE_A as STRING),':',CAST(CNVT_COFE_B as STRING)) as CNVT_COFE               --折算系数
          ,SUM(t.PROD_SALE_STD_AMT)    as PROD_SALE_STD_AMT        --产品销售标准额 
  
  FROM  	DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_PROD_SALE_STATS_TEMP  t
LEFT JOIN    (SELECT CUST_NO,BRK_NO as PSN_NO,'经纪关系' as SVC_RLN_TP ,BRK_CGY as PSN_CGY
               FROM   DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN 
               WHERE  %d{yyyyMMdd} > = STATS_DT 
               AND      %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
			    AND     BUS_DATE = %d{yyyyMMdd}
              -- UNION ALL
              -- SELECT CUST_NO,PSN_NO as PSN_NO,'服务关系'  as SVC_RLN_TP,PSN_CGY
              -- FROM DDW_PROD.T_DDW_F00_CUST_CUST_RLN
              -- WHERE    %d{yyyyMMdd} > = STATS_DT 
              -- AND      %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
              -- AND      BUS_DATE = %d{yyyyMMdd}
              -- AND       SVC_RLN_TP = '4'
			   )           a1
 ON   t.CUST_NO	 = a1.CUST_NO
 LEFT JOIN  EDW_PROD.T_EDW_T01_TJJR a4
 ON  		a1.PSN_NO = a4.JJRBH
 AND  		a4.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  EDW_PROD.T_EDW_T01_TRYXX a5
 ON  		a1.PSN_NO = a5.RYBH
 AND  		a5.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN DDW_PROD.V_PSN_CGY                     a6
 ON        a1.PSN_CGY = a6.PSN_CGY 
 LEFT JOIN  DDW_PROD.T_DDW_INR_ORG_BRH              a7
 ON         NVL(a4.JJRYYB,a5.YYB)	 = a7.BRH_NO
 AND        a7.BUS_DATE =  %d{yyyyMMdd}
 WHERE      a1.CUST_NO IS NOT NULL
 GROUP BY   PROD_CGY    
            ,BRH_NO      
            ,BRH_NAME    
            ,BELTO_FILIL 
			,BELTO_FILIL_CDG
            ,PSN_NO      
            ,PSN_NAME    
            ,PROD_CD     
            ,PROD_NAME   
            ,CUST_NO     
            ,SALE_DT 
            ,CNVT_COFE
            ,PSN_CGY			;
-------
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_PROD_SALE_STATS_TEMP;			
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_SH_TALENT_RANK_PROD_SALE_STATS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_PROD_SALE_STATS;
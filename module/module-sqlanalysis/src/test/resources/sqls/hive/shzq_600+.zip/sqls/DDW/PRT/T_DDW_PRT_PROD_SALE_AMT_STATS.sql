 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:产品销售统计表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-05-14                                                                       */ 
----创建经纪关系销售临时表 
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_PROD_SALE_AMT_STATS
(
		   BRH_NO                     --营业部编号
          ,BRH_NAME                   --营业部名称
          ,BELTO_FILIL                --所属分公司
		  ,BELTO_FILIL_CDG			  --所属分公司编码
          ,PSN_NO                     --人员编码
          ,PSN_NAME                   --人员姓名
          ,PSN_CGY                    --人员类别
          ,PROD_CD                    --产品代码
          ,PROD_NAME                  --产品名称
          ,PROD_SALE_QTY              --产品销售数量
          ,BRK_RLN_PROD_SALE_QTY      --经纪关系客户销售数量
          ,SVC_RLN_PROD_SALE_QTY      --服务关系客户销售数量
          ,PROD_SALE_AMT              --产品销售金额
		  ,BRK_RLN_PROD_SALE_AMT	  --经纪关系客户销售金额			   
		  ,SVC_RLN_PROD_SALE_AMT	  --服务关系客户销售金额	   
)		
 PARTITION(BUS_DATE = %d{yyyyMMdd} )
 SELECT 
								 NVL(a4.JJRYYB,a5.YYB)			      AS BRH_NO                     --营业部编号
								,a7.brh_shrtnm                        AS BRH_NAME                   --营业部编号
								,a7.BELTO_FILIL                       AS BELTO_FILIL                --所属分公司
								,a7.BELTO_FILIL_CDG					  AS BELTO_FILIL_CDG			--所属分公司编码
								,NVL(t.PSN_NO,a1.PSN_NO)              AS PSN_NO                     --人员编码
								,NVL(a4.JJRXM,a5.RYXM)                AS PSN_NAME                   --人员姓名
								,a6.PSN_CGY_NAME                      AS PSN_CGY                    --人员类别
								,NVL(t.PROD_CD,a1.PROD_CD)            AS PROD_CD                    --产品代码
								,NVL(a2.CPQC,a3.JJQC)                 AS PROD_NAME                  --产品名称
								,NVL(t.BRK_RLN_PROD_SALE_QTY,0)+NVL(a1.SVC_RLN_PROD_SALE_QTY,0)             AS PROD_SALE_QTY              --产品销售数量
								,NVL(t.BRK_RLN_PROD_SALE_QTY,0)       AS BRK_RLN_PROD_SALE_QTY      --经纪关系客户销售数量
								,NVL(a1.SVC_RLN_PROD_SALE_QTY,0)      AS SVC_RLN_PROD_SALE_QTY      --服务关系客户销售数量	
                                ,NVL(t.BRK_RLN_PROD_SALE_AMT,0)+NVL(a1.SVC_RLN_PROD_SALE_AMT,0)                                      AS PROD_SALE_AMT              --产品销售金额
                                ,NVL(t.BRK_RLN_PROD_SALE_AMT,0)       AS BRK_RLN_PROD_SALE_AMT	  --经纪关系客户销售金额
                                ,NVL(a1.SVC_RLN_PROD_SALE_AMT,0)      AS SVC_RLN_PROD_SALE_AMT	  --服务关系客户销售金额
  
  FROM  	(SELECT PSN_NO
                   ,PROD_CD
				   ,SUM(SCRP_QTY+PRCH_QTY) as BRK_RLN_PROD_SALE_QTY
                   ,SUM(SCRP_AMT+PRCH_AMT) as BRK_RLN_PROD_SALE_AMT
             FROM   DDW_PROD.T_DDW_F10_CUST_PROD_IDX_DAY    	t
             WHERE  t.PROD_CGY < > '场内基金' 
             AND    t.SVC_RLN_TP = '经纪关系'
			 AND   BUS_DATE = %d{yyyyMMdd}
			 GROUP BY PSN_NO,PROD_CD
            )   t
 FULL JOIN  (SELECT PSN_NO
                   ,PROD_CD
				   ,SUM(SCRP_QTY+PRCH_QTY) as SVC_RLN_PROD_SALE_QTY
                   ,SUM(SCRP_AMT+PRCH_AMT) as SVC_RLN_PROD_SALE_AMT
             FROM   DDW_PROD.T_DDW_F10_CUST_PROD_IDX_DAY    	t
             WHERE  t.PROD_CGY < > '场内基金' 
             AND    t.SVC_RLN_TP = '服务关系'
			 AND   BUS_DATE = %d{yyyyMMdd}
			 GROUP BY PSN_NO,PROD_CD
            )   a1
 ON      t.PSN_NO = a1.PSN_NO
 AND     t.PROD_CD = a1.PROD_CD
 LEFT JOIN EDW_PROD.T_EDW_T04_TJRCP_CPDM    a2
 ON  NVL(t.PROD_CD,a1.PROD_CD) = a2.CPDM
 AND  a2.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN   EDW_PROD.T_EDW_T04_TOF_JJXX           a3
 ON  NVL(t.PROD_CD,a1.PROD_CD) = a3.JJDM
 AND  a3.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  EDW_PROD.T_EDW_T01_TJJR a4
 ON  NVL(t.PSN_NO,a1.PSN_NO) = a4.JJRBH
 AND  a4.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  EDW_PROD.T_EDW_T01_TRYXX a5
 ON  NVL(t.PSN_NO,a1.PSN_NO) = a5.RYBH
 AND  a5.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN DDW_PROD.V_PSN_CGY                     a6
 ON        NVL(a4.JJRLB,a5.RYLB) = a6.PSN_CGY 
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH              a7
 ON            NVL(a4.JJRYYB,a5.YYB)	 = a7.BRH_NO
 AND           a7.BUS_DATE =  %d{yyyyMMdd}
 ;
 
 
 ----------------------加载结束-------------
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_PROD_SALE_AMT_STATS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
     invalidate metadata DDW_PROD.T_DDW_PRT_PROD_SALE_AMT_STATS; 
--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:上海国债代码表                                                                       */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
  TRUNCATE TABLE EDW_PROD.T_EDW_T04_TSHGZDM; 
------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T04_TSHGZDM
(
                                    NBDM                                --内部代码                               
                                   ,GZQX                                --国债期限                               
                                   ,GZMZ                                --国债面值                               
                                   ,FXJG                                --发行价格                               
                                   ,DFJG                                --兑付价格                               
                                   ,MRJG                                --买入价格                               
                                   ,MCJG                                --卖出价格                               
                                   ,FXED                                --发行额度                               
                                   ,FXSL                                --发行数量                               
                                   ,YWFW                                --业务范围                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQQC                                --证券全称                               
                                   ,FXRQ                                --发行日期                               
                                   ,DFRQ                                --兑付日期                               
                                   ,ZQDM                                --证券代码                               
                                   ,GZLB                                --国债类别                               
                                   ,LXSL                                --利息税率      
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.NBDM                                as NBDM                                --内部代码                                
                                   ,t.GZQX                                as GZQX                                --国债期限                                
                                   ,t.GZMZ                                as GZMZ                                --国债面值                                
                                   ,t.FXJG                                as FXJG                                --发行价格                                
                                   ,t.DFJG                                as DFJG                                --兑付价格                                
                                   ,t.MRJG                                as MRJG                                --买入价格                                
                                   ,t.MCJG                                as MCJG                                --卖出价格                                
                                   ,t.FXED                                as FXED                                --发行额度                                
                                   ,t.FXSL                                as FXSL                                --发行数量                                
                                   ,t.YWFW                                as YWFW                                --业务范围                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.ZQQC                                as ZQQC                                --证券全称                                
                                   ,t.FXRQ                                as FXRQ                                --发行日期                                
                                   ,t.DFRQ                                as DFRQ                                --兑付日期                                
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.LB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as GZLB                                --类别                                  
                                   ,t.LXSL                                as LXSL                                --利息税率   
                                   ,'JZJY'                                as XTBS								   
 FROM 			JZJYCX.SECURITIES_TSHGZDM 						 t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING			 t1 
 ON             t1.DMLX = 'GZLB'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.LB AS VARCHAR(20))
 WHERE 			t.DT = '%d{yyyyMMdd}';
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TSHGZDM',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
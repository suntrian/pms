   --/* ****************** SQL BEGIN **************************/
  --/* 脚本功能:ODS数据问题监控                             */
  --/* 创建人:黄勇华				                         */
  --/* 创建时间:2018-04-24			                         */ 
  --/* 修改时间:2018-04-24			                         */ 
---创建目标表
ALTER TABLE DDW_PROD.T_ODS_DATA_WARNG_MOT DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ; 
--（0--错误，1预警）
----JZJY插入数据
 INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     1                                                 AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TJGMXLS'                              AS ODS_TABLE_NAME
		   ,'如果记录数小于1万条则报错，大于200万条则预警'    AS DSC
		   ,CASE WHEN t.NUM < 10000
		         THEN 0
				 ELSE 1
				 END                                          AS ERR_CGY
 FROM    ( SELECT COUNT(1) as NUM
           FROM  JZJYCX.DATACENTER_TJGMXLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )          t
 WHERE   t.NUM < 10000
 OR      t.NUM > 2000000
 ;
 
 
 
  INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     2                                                 AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TWTLS'                                AS ODS_TABLE_NAME
		   ,'如果记录数小于1万条则报错，大于200万条则预警'    AS DSC
		   ,CASE WHEN t.NUM < 10000
		         THEN 0
				 ELSE 1
				 END                                          AS ERR_CGY
 FROM    ( SELECT COUNT(1) as NUM
           FROM  JZJYCX.DATACENTER_TWTLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )           t
  WHERE   t.NUM < 10000
 OR      t.NUM > 2000000
 ;
 
   INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     3                                                 AS ID
           ,'JZJY'                                            AS SYS 
		   ,'TZJMXLS'                                         AS ODS_TABLE_NAME
		   ,'如果记录数小于1万条则报错，大于200万条则预警'    AS DSC
		   ,CASE WHEN t.NUM < 10000
		         THEN 0
				 ELSE 1
				 END                                          AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM  JZJYCX.DATACENTER_TZJMXLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )           t
  WHERE   t.NUM < 10000
  OR      t.NUM > 2000000
 ;
 
 
 
 
 
    INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     4                                                 AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TOF_JJJGLS'                           AS ODS_TABLE_NAME
		   ,'如果记录数小于1百条则报错，大于5万条则预警'      AS DSC
		   ,CASE WHEN t.NUM < 100
		         THEN 0
				 ELSE 1
				 END                                          AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM  JZJYCX.DATACENTER_TOF_JJJGLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )           t
  WHERE   t.NUM < 100
  OR      t.NUM > 50000
 ; 
 
    INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     5                                                 AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TOF_JJWTLS'                           AS ODS_TABLE_NAME
		   ,'如果记录数小于1百条则报错，大于5万条则预警'      AS DSC
		   ,CASE WHEN t.NUM < 100
		         THEN 0
				 ELSE 1
				 END                                          AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM  JZJYCX.DATACENTER_TOF_JJWTLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )           t
  WHERE   t.NUM < 100
  OR      t.NUM > 50000
 ;
 
     INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     6                                                AS ID
           ,'JZJY'                                           AS SYS 
		   ,'DATACENTER_TJRCP_YH_JGLS'                       AS ODS_TABLE_NAME
		   ,'记录数不为0'                                    AS DSC
		   ,1                                         AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM  JZJYCX.DATACENTER_TJRCP_YH_JGLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )           t
  WHERE   t.NUM = 0
 
 ;

 
     INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     7                                                AS ID
           ,'JZJY'                                           AS SYS 
		   ,'DATACENTER_TJRCP_YH_WTLS'                       AS ODS_TABLE_NAME
		   ,'记录数不为0'                                    AS DSC
		   ,1                                         AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM  JZJYCX.DATACENTER_TJRCP_YH_WTLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )           t
  WHERE   t.NUM = 0
 
 ; 
 
 ----
     INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     8                                                AS ID
           ,'JZJY'                                           AS SYS 
		   ,'DATACENTER_TZQGL'                               AS ODS_TABLE_NAME
		   ,'bdrq=日期不为0'                                    AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM  JZJYCX.DATACENTER_TZQGL
           WHERE     DT = '%d{yyyyMMdd}'
		   AND       BDRQ = 0
		 )           t
  WHERE   t.NUM > 0
 
 ; 

      INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     9                                                AS ID
           ,'JZJY'                                           AS SYS 
		   ,'DATACENTER_TZJZH'                               AS ODS_TABLE_NAME
		   ,'bdrq=日期不为0'                                 AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM  JZJYCX.DATACENTER_TZJZH
           WHERE     DT = '%d{yyyyMMdd}'
		   AND       BDRQ = 0
		 )           t
  WHERE   t.NUM > 0
 
 ;
 
      INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     10                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TOF_JJFE'                             AS ODS_TABLE_NAME
		   ,'bdrq=日期不为0'                                  AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM   JZJYCX.DATACENTER_TOF_JJFE 
           WHERE     DT = '%d{yyyyMMdd}'
		   AND       BDRQ = 0
		 )           t
  WHERE   t.NUM > 0
 
 ; 
 
 
       INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     11                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TOF_JJZH'                             AS ODS_TABLE_NAME
		   ,'KHRQ=日期不为0'                                  AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM   JZJYCX.DATACENTER_TOF_JJZH
           WHERE     DT = '%d{yyyyMMdd}'
		   AND       KHRQ = 0
		 )           t
  WHERE   t.NUM > 0
 
 ; 
 
 
        INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     12                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TGDH'                                 AS ODS_TABLE_NAME
		   ,'GDDJRQ=日期不为0'                                  AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM   JZJYCX.DATACENTER_TGDH
           WHERE     DT = '%d{yyyyMMdd}'
		   AND       GDDJRQ = 0
		 )           t
  WHERE   t.NUM > 0
 
 ; 
 
         INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     13                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TKHXX'                                 AS ODS_TABLE_NAME
		   ,'KHRQ=日期不为0'                                  AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM   JZJYCX.DATACENTER_TKHXX
           WHERE     DT = '%d{yyyyMMdd}'
		   AND      KHRQ = 0
		 )           t
  WHERE   t.NUM > 0
 
 ; 
 
         INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     14                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TDJSQSZL'                             AS ODS_TABLE_NAME
		   ,'记录数不为0'                                     AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   JZJYCX.DATACENTER_TDJSQSZL
           WHERE     DT = '%d{yyyyMMdd}'		 
		 )           t
  WHERE   t.NUM = 0
 
 ; 

         INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     15                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TJRCP_YH_CPFE'                        AS ODS_TABLE_NAME
		   ,'记录数不为0'                                     AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   JZJYCX.DATACENTER_TJRCP_YH_CPFE
           WHERE     DT = '%d{yyyyMMdd}'		 
		 )           t
  WHERE   t.NUM = 0
 
 ; 
 
    INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     16                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TJRCP_CPZH'                           AS ODS_TABLE_NAME
		   ,'记录数不为0'                                     AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   JZJYCX.DATACENTER_TJRCP_CPZH
           WHERE     DT = '%d{yyyyMMdd}'		 
		 )           t
  WHERE   t.NUM = 0
 
 ; 
 
     INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     17                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TCZMXLS'                              AS ODS_TABLE_NAME
		   ,'rq=日期记录数不为0'                              AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   JZJYCX.DATACENTER_TCZMXLS
           WHERE     DT = '%d{yyyyMMdd}'
           AND       RQ = 0		   
		 )           t
  WHERE   t.NUM > 0
 
 ; 

     INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     18                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'OFS_TOF_ELCHTXY'                                 AS ODS_TABLE_NAME
		   ,'QYRQ=日期记录数不为0'                            AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   JZJYCX.OFS_TOF_ELCHTXY
           WHERE     DT = '%d{yyyyMMdd}'
           AND       QYRQ = 0		   
		 )           t
  WHERE   t.NUM > 0
 
 ; 
 
      INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     19                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TZYHGLS'                              AS ODS_TABLE_NAME
		   ,'rq=日期记录数不为0'                              AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   JZJYCX.DATACENTER_TZYHGLS
           WHERE     DT = '%d{yyyyMMdd}'
           AND       RQ = 0		   
		 )           t
  WHERE   t.NUM > 0
 
 ; 
 
       INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     20                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'DATACENTER_TOF_JJJZ'                             AS ODS_TABLE_NAME
		   ,'rq=日期记录数不为0'                              AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   JZJYCX.DATACENTER_TOF_JJJZ
           WHERE     DT = '%d{yyyyMMdd}'
           AND       RQ = 0		   
		 )           t
  WHERE   t.NUM > 0
 
 ; 
 
        INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     21                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'OFS_TOF_DJS'                                AS ODS_TABLE_NAME
		   ,'rq=日期记录数不为0'                              AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   JZJYCX.OFS_TOF_DJS
           WHERE     DT = '%d{yyyyMMdd}'
           AND       WTRQ = 0		   
		 )           t
  WHERE   t.NUM > 0
 
 ; 
 
  
       INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     22                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'OFS_TOF_JJWT_DQS'                                AS ODS_TABLE_NAME
		   ,'WTRQ=日期记录数不为0'                              AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   JZJYCX.OFS_TOF_JJWT_DQS
           WHERE     DT = '%d{yyyyMMdd}'
           AND       WTRQ = 0		   
		 )           t
  WHERE   t.NUM > 0
 
 ; 
 
        INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     23                                                AS ID
           ,'JZJY'                                            AS SYS 
		   ,'SECURITIES_TZQDM'                                AS ODS_TABLE_NAME
		   ,'如果记录数小于1万条则报错'                       AS DSC
		   ,0                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   JZJYCX.SECURITIES_TZQDM
           WHERE     DT = '%d{yyyyMMdd}'              
		 )           t
  WHERE   t.NUM < 10000
 
 ; 
 
 
 
 
 --------------
 
 
 ----RZRQ插入数据
 INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     24                                                 AS ID
           ,'RZRQ'                                            AS SYS 
		   ,'DATACENTER_TJGMXLS'                              AS ODS_TABLE_NAME
		   ,'如果记录数小于1千条则报错，大于20万条则预警'     AS DSC
		   ,CASE WHEN t.NUM < 1000
		         THEN 0
				 ELSE 1
				 END                                          AS ERR_CGY
 FROM    ( SELECT COUNT(1) as NUM
           FROM  RZRQCX.DATACENTER_TJGMXLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )          t
 WHERE   t.NUM < 1000
 OR      t.NUM > 200000
 ;
 
 
 
  INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     25                                                 AS ID
           ,'RZRQ'                                            AS SYS 
		   ,'DATACENTER_TWTLS'                                AS ODS_TABLE_NAME
		   ,'如果记录数小于1千条则报错，大于20万条则预警'     AS DSC
		   ,CASE WHEN t.NUM < 1000
		         THEN 0
				 ELSE 1
				 END                                          AS ERR_CGY
 FROM    ( SELECT COUNT(1) as NUM
           FROM  RZRQCX.DATACENTER_TWTLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )           t
  WHERE   t.NUM < 1000
 OR      t.NUM > 200000
 ;
 
   INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     26                                                 AS ID
           ,'RZRQ'                                            AS SYS 
		   ,'TZJMXLS'                                         AS ODS_TABLE_NAME
		   ,'如果记录数小于1千条则报错，大于20万条则预警'     AS DSC
		   ,CASE WHEN t.NUM < 1000
		         THEN 0
				 ELSE 1
				 END                                          AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM  RZRQCX.DATACENTER_TZJMXLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )           t
  WHERE   t.NUM < 1000
  OR      t.NUM > 200000
 ;
 
  
 ----
     INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     27                                               AS ID
           ,'RZRQ'                                           AS SYS 
		   ,'DATACENTER_TZQGL'                               AS ODS_TABLE_NAME
		   ,'bdrq=日期不为0'                                 AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM  RZRQCX.DATACENTER_TZQGL
           WHERE     DT = '%d{yyyyMMdd}'
		   AND       BDRQ = 0
		 )           t
  WHERE   t.NUM > 0
 
 ; 

      INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     28                                               AS ID
           ,'RZRQ'                                           AS SYS 
		   ,'DATACENTER_TZJZH'                               AS ODS_TABLE_NAME
		   ,'bdrq=日期不为0'                                 AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM  RZRQCX.DATACENTER_TZJZH
           WHERE     DT = '%d{yyyyMMdd}'
		   AND       BDRQ = 0
		 )           t
  WHERE   t.NUM > 0
 
 ;
 
   
 
 
        INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     29                                                AS ID
           ,'RZRQ'                                            AS SYS 
		   ,'DATACENTER_TGDH'                                 AS ODS_TABLE_NAME
		   ,'GDDJRQ=日期不为0'                                  AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM   RZRQCX.DATACENTER_TGDH
           WHERE     DT = '%d{yyyyMMdd}'
		   AND       GDDJRQ = 0
		 )           t
  WHERE   t.NUM > 0
 
 ; 
 
         INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     30                                                AS ID
           ,'RZRQ'                                            AS SYS 
		   ,'DATACENTER_TKHXX'                                 AS ODS_TABLE_NAME
		   ,'KHRQ=日期不为0'                                  AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) as NUM
           FROM   RZRQCX.DATACENTER_TKHXX
           WHERE     DT = '%d{yyyyMMdd}'
		   AND      KHRQ = 0
		 )           t
  WHERE   t.NUM > 0
 
 ; 
 
 

 
     INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     31                                                AS ID
           ,'RZRQ'                                            AS SYS 
		   ,'DATACENTER_TCZMXLS'                              AS ODS_TABLE_NAME
		   ,'rq=日期记录数不为0'                              AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   RZRQCX.DATACENTER_TCZMXLS
           WHERE     DT = '%d{yyyyMMdd}'
           AND       RQ = 0		   
		 )           t
  WHERE   t.NUM > 0
 
 ; 

 
  INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     32                                                AS ID
           ,'RZRQ'                                            AS SYS 
		   ,'DATACENTER_TXY_HTXXLS'                           AS ODS_TABLE_NAME
		   ,'如果记录数小于1000条则报错'                      AS DSC
		   ,0                                                 AS ERR_CGY
 FROM    ( SELECT COUNT(1) as NUM
           FROM  RZRQCX.DATACENTER_TXY_HTXXLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )          t
 WHERE   t.NUM < 1000
 
 ;
 
  
  INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     33                                                AS ID
           ,'RZRQ'                                            AS SYS 
		   ,'DATACENTER_TXY_FZXXLS'                           AS ODS_TABLE_NAME
		   ,'如果记录数小于1000条则报错'                      AS DSC
		   ,0                                                 AS ERR_CGY
 FROM    ( SELECT COUNT(1) as NUM
           FROM  RZRQCX.DATACENTER_TXY_FZXXLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )          t
 WHERE   t.NUM < 1000
 
 ;
 
   INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     34                                                AS ID
           ,'RZRQ'                                            AS SYS 
		   ,'DATACENTER_TXY_FZBDMXLS'                         AS ODS_TABLE_NAME
		   ,'如果记录数小于100条则报错'                      AS DSC
		   ,0                                                 AS ERR_CGY
 FROM    ( SELECT COUNT(1) as NUM
           FROM  RZRQCX.DATACENTER_TXY_FZBDMXLS
           WHERE     DT = '%d{yyyyMMdd}'
		 )          t
 WHERE   t.NUM < 100
 
 ;
 
--          INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
-- (
--	  ID 					      				--编号
--	 ,SYS                                       --系统
--	 ,ODS_TABLE_NAME							--ODS表名
--	 ,DSC				      				    --描述
--	 ,ERR_CGY                                   --错误类别
-- ) PARTITION(BUS_DATE = %d{yyyyMMdd})
-- SELECT     35                                                AS ID
--           ,'RZRQ'                                            AS SYS 
--		   ,'DATACENTER_TDJSQSZL'                             AS ODS_TABLE_NAME
--		   ,'记录数不为0'                                     AS DSC
--		   ,1                                                 AS ERR_CGY
--  FROM    ( SELECT COUNT(1) AS NUM
--           FROM   RZRQCX.DATACENTER_TDJSQSZL
--           WHERE     DT = '%d{yyyyMMdd}'		 
--		 )           t
--  WHERE   t.NUM = 0
--   ;
   
   
   INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     36                                                AS ID
           ,'CIF'                                            AS SYS 
		   ,'CIF_LCFXCKH'                             AS ODS_TABLE_NAME
		   ,'SQRQ=日期不为0'                                     AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   YGTCX.CIF_LCFXCKH
           WHERE    DT = '%d{yyyyMMdd}'	
           AND      SQRQ = 0		   
		 )           t
  WHERE   t.NUM > 0
   ;
 
 
    INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     37                                                AS ID
           ,'CIF'                                            AS SYS 
		   ,'CIF_LCFXCKH'                             AS ODS_TABLE_NAME
		   ,'RQ=日期不为0'                                     AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   YGTCX.CIF_TCZMX
           WHERE    DT = '%d{yyyyMMdd}'	
           AND      RQ = 0		   
		 )           t
  WHERE   t.NUM > 0
   ;
 
 
    INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     38                                               AS ID
           ,'CIF'                                            AS SYS 
		   ,'CIF_TYWQQ'                                      AS ODS_TABLE_NAME
		   ,'SQRQ=日期不为0'                                 AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   YGTCX.CIF_TYWQQ
           WHERE    DT = '%d{yyyyMMdd}'	
           AND      SQRQ = 0		   
		 )           t
  WHERE   t.NUM > 0
   ;
   
   
       INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     39                                               AS ID
           ,'CIF'                                            AS SYS 
		   ,'CIF_TKHSDX'                                      AS ODS_TABLE_NAME
		   ,'记录数不为0'                                 AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   YGTCX.CIF_TKHSDX
           WHERE    DT = '%d{yyyyMMdd}'	           	   
		 )           t
  WHERE   t.NUM = 0
   ;
   
     
       INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     40                                               AS ID
           ,'CIF'                                            AS SYS 
		   ,'CIF_TKHYWSX'                                      AS ODS_TABLE_NAME
		   ,'记录数不为0'                                 AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   YGTCX.CIF_TKHYWSX
           WHERE    DT = '%d{yyyyMMdd}'	           	   
		 )           t
  WHERE   t.NUM = 0
   ;
 
        INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     41                                               AS ID
           ,'CIF'                                            AS SYS 
		   ,'CIF_TKHJYQX'                                      AS ODS_TABLE_NAME
		   ,'记录数不为0'                                 AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   YGTCX.CIF_TKHJYQX
           WHERE    DT = '%d{yyyyMMdd}'	           	   
		 )           t
  WHERE   t.NUM = 0
   ;
 
         INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     42                                               AS ID
           ,'CIF'                                            AS SYS 
		   ,'DATACENTER_TSO_HYCC'                                      AS ODS_TABLE_NAME
		   ,'记录数不为0'                                 AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   GGQQCX.DATACENTER_TSO_HYCC
           WHERE    DT = '%d{yyyyMMdd}'	           	   
		 )           t
  WHERE   t.NUM = 0
   ;
   
            INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     43                                               AS ID
           ,'CIF'                                            AS SYS 
		   ,'SOPTION_TSO_HYDM'                            AS ODS_TABLE_NAME
		   ,'记录数不为0'                                    AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   GGQQCX.SOPTION_TSO_HYDM
           WHERE    DT = '%d{yyyyMMdd}'	           	   
		 )           t
  WHERE   t.NUM = 0
   ;
   
               INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     44                                               AS ID
           ,'CIF'                                            AS SYS 
		   ,'DATACENTER_TSO_JGMXLS'                            AS ODS_TABLE_NAME
		   ,'记录数不为0'                                    AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   GGQQCX.DATACENTER_TSO_JGMXLS
           WHERE    DT = '%d{yyyyMMdd}'	           	   
		 )           t
  WHERE   t.NUM = 0
   ;
 
               INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     44                                               AS ID
           ,'CIF'                                            AS SYS 
		   ,'DATACENTER_TSO_WTLS'                            AS ODS_TABLE_NAME
		   ,'记录数不为0'                                    AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   GGQQCX.DATACENTER_TSO_WTLS
           WHERE    DT = '%d{yyyyMMdd}'	           	   
		 )           t
  WHERE   t.NUM = 0
   ;
   
   INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     46                                               AS ID
           ,'CIF'                                            AS SYS 
		   ,'DATACENTER_TSO_QQHQ'                            AS ODS_TABLE_NAME
		   ,'记录数不为0'                                    AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   GGQQCX.DATACENTER_TSO_QQHQ
           WHERE    DT = '%d{yyyyMMdd}'	           	   
		 )           t
  WHERE   t.NUM = 0
   ;  
   INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     47                                               AS ID
           ,'CIF'                                            AS SYS 
		   ,'DATACENTER_TZJMXLS'                            AS ODS_TABLE_NAME
		   ,'记录数不为0'                                    AS DSC
		   ,1                                                AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   GGQQCX.DATACENTER_TZJMXLS
           WHERE    DT = '%d{yyyyMMdd}'	           	   
		 )           t
  WHERE   t.NUM = 0
   ;  
 
 
    INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     48                                                AS ID
           ,'YGTCX'                                            AS SYS 
		   ,'YGTCX.CIF_TKHXX'                             AS ODS_TABLE_NAME
		   ,'KHrq日期为今天的数据不能为0'                              AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   YGTCX.CIF_TKHXX
           WHERE     DT = '%d{yyyyMMdd}'
           AND       KHRQ = %d{yyyyMMdd}		   
		 )           t
  WHERE   t.NUM = 0
 
 ; 
  INSERT INTO DDW_PROD.T_ODS_DATA_WARNG_MOT
 (
	  ID 					      				--编号
	 ,SYS                                       --系统
	 ,ODS_TABLE_NAME							--ODS表名
	 ,DSC				      				    --描述
	 ,ERR_CGY                                   --错误类别
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     48                                                AS ID
           ,'YGTCX'                                            AS SYS 
		   ,'YGTCX.CIF_lcfxckh'                             AS ODS_TABLE_NAME
		   ,'SQrq日期为今天的数据不能为0'                              AS DSC
		   ,1                                                 AS ERR_CGY
  FROM    ( SELECT COUNT(1) AS NUM
           FROM   YGTCX.CIF_lcfxckh
           WHERE     DT = '%d{yyyyMMdd}'
           AND       SQRQ = %d{yyyyMMdd}		   
		 )           t
  WHERE   t.NUM = 0
 
 ; 
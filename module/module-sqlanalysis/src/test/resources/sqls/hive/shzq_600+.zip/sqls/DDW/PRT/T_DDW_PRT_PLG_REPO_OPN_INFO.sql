 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:质押式回购开通信息表                                                                       */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 

 TRUNCATE TABLE DDW_PROD.T_DDW_PRT_PLG_REPO_OPN_INFO;  
  --删除临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_PLG_REPO_OPN_INFO_TEMP;
--创建临时表
CREATE TABLE DDW_PROD.T_DDW_PRT_PLG_REPO_OPN_INFO_TEMP
AS 
SELECT 
t.CUST_NO,SUM(NVL(t.MTCH_AMT,0))  AS MTCH_AMT
FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS   t
WHERE t.BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS DECIMAL(38,0)) AND %d{yyyyMMdd} 
AND   t.SEC_CGY  LIKE 'H%'
AND	  t.SEC_CGY  <> 'H4'
GROUP BY CUST_NO
;

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_PLG_REPO_OPN_INFO
(
				BRH_NO               --营业部编号
               ,BRH_NAME             --营业部名称
               ,CUST_NO              --客户号  
               ,CUST_NAME            --客户姓名 
               ,OPN_DT               --开通日期 
               ,MTCH_AMT             --成交金额 
			   ,RSK_BEAR_ABLTY       --风险承受能力
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
						 a1.BRH_NO    		       AS  BRH_NO               --营业部编号    
						,a1.BRH_NAME  		       AS  BRH_NAME             --营业部名称    
						,t.CUST_NO   		       AS  CUST_NO              --客户号      
						,a1.CUST_NAME 		       AS  CUST_NAME            --客户姓名     
						,t.OPN_DT   		       AS  OPN_DT               --开通日期     
						,NVL(a2.MTCH_AMT,0)  	   AS  MTCH_AMT             --成交金额 
                        ,b3.RSK_BEAR_ABLTY_NAME    AS  RSK_BEAR_ABLTY       --风险承受能力 						
  FROM  		 (SELECT CUST_NO AS CUST_NO
                     ,MIN(DT) AS OPN_DT
              FROM   DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS 
              WHERE  BIZ_SBJ IN ('20240','20241','20201')
              AND    (ABST LIKE '%回购融券%' OR  ABST LIKE '%回购融资%')     
              AND     OPRT_MOD = '临柜'
              GROUP BY CUST_NO
              )                                                     	t  
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO                         	a1
  ON            t.CUST_NO = a1.CUST_NO 
  AND           a1.bus_date = %d{yyyyMMdd}  
  LEFT JOIN		DDW_PROD.T_DDW_PRT_PLG_REPO_OPN_INFO_TEMP				a2
  ON			t.CUST_NO = a2.CUST_NO 
  LEFT JOIN     	DDW_PROD.V_RSK_BEAR_ABLTY                          	  b3
  ON            	a1.RSK_BEAR_ABLTY = b3.RSK_BEAR_ABLTY
  WHERE			CAST(t.OPN_DT AS STRING) > =  CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-3,0,0),1,4),'0101') 
  ;
--删除临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_PLG_REPO_OPN_INFO_TEMP;
-----------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_PLG_REPO_OPN_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_PLG_REPO_OPN_INFO ; 
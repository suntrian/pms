------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:营业部产品日表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2019-05-21                                                                       */

 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_PROD_DAY_TEMP;
 CREATE TABLE DDW_PROD.T_DDW_F20_BRH_NO_PROD_DAY_TEMP
 as SELECT a.DATA_SRC,a.PROD_CD,b.BRH_NO,a.BUS_DATE,a.PROD_CL_CD,a.PROD_CL_NAME
    FROM (SELECT       DISTINCT 1 AS ID,DATA_SRC,PROD_CD,BUS_DATE ,PROD_CL_CD,PROD_CL_NAME        
	      FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY	      
		  WHERE BUS_DATE = %d{yyyyMMdd}
	     ) a
	LEFT JOIN (SELECT 1 AS ID,* FROM DDW_PROD.T_DDW_INR_ORG_BRH WHERE BUS_DATE = %d{yyyyMMdd})  b
	ON   a.ID = b.ID
	
;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_PROD_DAY_TEMP1;
 CREATE TABLE DDW_PROD.T_DDW_F20_BRH_NO_PROD_DAY_TEMP1
 as SELECT  PROD_CD                   --产品代码
          , PROD_CL_CD                --产品分类代码
          , PROD_CL_NAME              --产品分类名称
          , DATA_SRC                  --数据来源
          , SUM(BUYIN_AMT)           as BUYIN_AMT                 --买入金额
          , SUM(SELL_AMT)            as SELL_AMT                 --卖入金额
          , SUM(SCRP_AMT)            as SCRP_AMT                  --认购金额
          , SUM(PRCH_AMT)            as PRCH_AMT                  --申购金额
          , SUM(FIXINV_AMT)          as FIXINV_AMT      --定投金额
          , SUM(RDMPT_AMT)           as RDMPT_AMT      --赎回金额
          , SUM(BUYIN_QTY)           as BUYIN_QTY      --买入数量
          , SUM(SELL_QTY)            as SELL_QTY      --卖入数量
          , SUM(SCRP_QTY)            as SCRP_QTY      --认购数量
          , SUM(PRCH_QTY)            as PRCH_QTY      --申购数量
          , SUM(FIXINV_QTY)          as FIXINV_QTY      --定投数量
          , SUM(RDMPT_QTY)           as RDMPT_QTY      --赎回数量
          , SUM(BNS_AMT)             as BNS_AMT      --红利金额
          , SUM(BUYIN_S1)            as BUYIN_S1      --买入佣金
          , SUM(SELL_S1)             as SELL_S1      --卖出佣金
          , SUM(SCRP_S1_CSMN_FEE)    as SCRP_S1_CSMN_FEE      --认购佣金及手续费收入
          , SUM(PRCH_S1_CSMN_FEE)    as PRCH_S1_CSMN_FEE      --申购佣金及手续费收入
          , SUM(FIXINV_S1_CSMN_FEE)  as FIXINV_S1_CSMN_FEE      --定投佣金及手续费收入
          , SUM(RDMPT_S1_CSMN_FEE)   as RDMPT_S1_CSMN_FEE      --赎回佣金及手续费收入
          , SUM(S1_CSMN_FEE)         as S1_CSMN_FEE      --佣金及手续费收入	  	  
          , SUM(HLD_AMT)             as HLD_AMT      --持仓金额
          , SUM(HLD_QTY)             as HLD_QTY      --持仓数量
		  , a.MAIN_SALE_FLG
		  --, a.PROD_CL_CD
		  , b.BRH_NO
    FROM   DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
	LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
	ON        a.CUST_NO = b.CUST_NO
	AND       b.BUS_DATE = %d{yyyyMMdd}
	WHERE  a.BUS_DATE = %d{yyyyMMdd}
	GROUP BY  PROD_CD     
	          ,PROD_CL_CD  
	          ,PROD_CL_NAME
              ,DATA_SRC
			  ,MAIN_SALE_FLG
			  ,PROD_CL_CD
			  ,BRH_NO
          	
 ;			  
   


INSERT OVERWRITE DDW_PROD.T_DDW_F20_BRH_NO_PROD_DAY
(               BRH_NO                  --营业部               
              , PROD_CD                 --产品代码
              , PROD_CL_CD              --产品分类代码
              , DATA_SRC                --数据来源
              , BUYIN_AMT               --买入金额
			  , BUYIN_QTY               --买入数量
			  , BUYIN_S1_INCM           --买入佣金收入
			  , SELL_AMT                --卖出金额
			  , SELL_QTY                --卖出数量
			  , SELL_S1_INCM            --卖出佣金收入
			  , SCRP_AMT                --认购金额
              , SCRP_QTY                --认购数量 
              , SCRP_S1_CSMN_FEE        --认购佣金及手续费收入
			  , PRCH_AMT                --申购金额
			  , PRCH_QTY                --申购数量
			  , PRCH_S1_CSMN_FEE        --申购佣金及手续费收入
			  , FIXINV_AMT              --定投金额
			  , FIXINV_QTY              --定投数量
			  , FIXINV_S1_CSMN_FEE      --定投佣金及手续费收入			  
              , RDMPT_AMT               --赎回金额              
              , RDMPT_QTY               --赎回数量
              , RDMPT_S1_CSMN_FEE       --赎回佣金及手续费收入
              , HLD_AMT                 --持仓金额
              , HLD_QTY                 --持仓数量
              , MAIN_SALE_FLG           --重点销售标志
              , IF_TRD_DATE             --是否交易日  				
 ) PARTITION(BUS_DATE )
 SELECT          
                t.BRH_NO                  --营业部               
              , t.PROD_CD                 --产品代码
              , t.PROD_CL_CD              --产品分类代码
              , t.DATA_SRC                --数据来源
              , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.BUYIN_AMT,0)
					 ELSE 0
					 END   as BUYIN_AMT               --买入金额
			  , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.BUYIN_QTY,0)
					 ELSE 0
					 END   as BUYIN_QTY               --买入数量
			  , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.BUYIN_S1,0)
					 ELSE 0
					 END  as BUYIN_S1_INCM           --买入佣金收入
			  , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.SELL_AMT,0)
					 ELSE 0
					 END  as SELL_AMT                --卖出金额
			  , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.SELL_QTY,0)
					 ELSE 0
					 END  as SELL_QTY                --卖出数量
			  , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.SELL_S1,0)
					 ELSE 0
					 END  as SELL_S1_INCM            --卖出佣金收入
			  , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.SCRP_AMT,0)
					 ELSE 0
					 END  as SCRP_AMT                --认购金额
              , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.SCRP_QTY,0)
					 ELSE 0
					 END  as SCRP_QTY                --认购数量 
              , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.SCRP_S1_CSMN_FEE,0)
					 ELSE 0
					 END as SCRP_S1_CSMN_FEE        --认购佣金及手续费收入
			  , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.PRCH_AMT,0)
					 ELSE 0
					 END as PRCH_AMT                --申购金额
			  , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.PRCH_QTY,0)
					 ELSE 0
					 END PRCH_QTY                --申购数量
			  , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.PRCH_S1_CSMN_FEE,0)
					 ELSE 0
					 END PRCH_S1_CSMN_FEE        --申购佣金及手续费收入
			  , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.FIXINV_AMT,0)
					 ELSE 0
					 END FIXINV_AMT              --定投金额
			  , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.FIXINV_QTY,0)
					 ELSE 0
					 END FIXINV_QTY              --定投数量
			  , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.FIXINV_S1_CSMN_FEE,0)
					 ELSE 0
					 END FIXINV_S1_CSMN_FEE      --定投佣金及手续费收入			  
              , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.RDMPT_AMT,0)
					 ELSE 0
					 END RDMPT_AMT               --赎回金额              
              , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.RDMPT_QTY,0)
					 ELSE 0
					 END RDMPT_QTY               --赎回数量
              , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN NVL(a1.RDMPT_S1_CSMN_FEE,0)
					 ELSE 0
					 END RDMPT_S1_CSMN_FEE       --赎回佣金及手续费收入
              , NVL(a1.HLD_AMT,0)  as  HLD_AMT               --持仓金额
              , NVL(a1.HLD_QTY,0)  as  HLD_QTY               --持仓数量
              , NVL(a1.MAIN_SALE_FLG,'0')  as MAIN_SALE_FLG           --重点销售标志
              , CASE WHEN t.BUS_DATE = a2.NAT_DT
			         THEN '是'
					 ELSE '否'
					 END as IF_TRD_DATE             --是否交易日 	
               , CAST(a2.NAT_DT  as INT)            as BUS_DATE						 
 FROM       DDW_PROD.T_DDW_F20_BRH_NO_PROD_DAY_TEMP               t 
 LEFT JOIN  DDW_PROD.T_DDW_F20_BRH_NO_PROD_DAY_TEMP1              a1
 ON         t.PROD_CD = a1.PROD_CD
 AND        t.DATA_SRC = a1.DATA_SRC
 AND        t.BRH_NO = a1.BRH_NO
 LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE                         a2
 ON         t.BUS_DATE = a2.TRD_DT
 AND        a2.BUS_DATE = %d{yyyyMMdd}
 
 ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_PROD_DAY_TEMP;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_PROD_DAY_TEMP1;
 
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_NO_PROD_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F20_BRH_NO_PROD_DAY;
------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:营业部客户统计月表                                                                  */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2018-04-25                                                                        */


----------------
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON_TEMP;
 CREATE TABLE DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON_TEMP
 as SELECT    t.BRH_NO
         ,SUM(CASE WHEN t.ORDI_CUST_STAT < > '3'
		           THEN 1
			       ELSE 0
			       END
			 )               as CUST_TOT         --客户数
		,SUM(CASE WHEN t.ORDI_CUST_STAT < > '3'
		           AND t.CUST_CGY = '1'
		           THEN 1
			       ELSE 0
			       END
			 )               as ORG_CUST_TOT	  --机构客户数
		,SUM(CASE WHEN  t.ORDI_CUST_STAT < > '3'
		           AND  t.CUST_CGY = '1'
				   AND  a1.CUST_NO  IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )               as PROD_CUST_TOT     --产品客户数

		,SUM(CASE WHEN t.ORDI_CUST_STAT < > '3'
		           AND t.CUST_CGY = '0'
		           THEN 1
			       ELSE 0
			       END
			 )               as IDV_CUST_TOT	  --个人客户数

		,SUM(CASE  WHEN  t.ORDI_OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
		           THEN 1
			       ELSE 0
			       END
			 )               as OPNAC_CUST_TOT_TMTH	  --当月开户数

		,SUM(CASE  WHEN  t.ORDI_CNCLACT_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
		           AND   t.ORDI_CUST_STAT = '3'
		           THEN 1
			       ELSE 0
			       END
			 )               as CNCLACT_CUST_TOT_TMTH	  --当月销户数

		,SUM(CASE  WHEN  t.ORDI_CUST_STAT NOT IN ('3')
		           AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
		           THEN 1
			       ELSE 0
			       END
			 )               as QLFD_CUST_TOT	  --合格客户数(含99)
		,SUM(CASE  WHEN  t.ORDI_CUST_STAT NOT IN ('3','99')
		           AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
		           THEN 1
			       ELSE 0
			       END
			 )               as QLFD_CUST_TOT_99	  --合格客户数(不含99)
		,SUM(CASE  WHEN  t.ORDI_CUST_STAT NOT IN ('3')
		           AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
				   AND   t.CUST_CGY = '1'
		           THEN 1
			       ELSE 0
			       END
			 )               as QLFD_ORG_CUST_TOT	  --合格机构客户数(含99)
		,SUM(CASE  WHEN  t.ORDI_CUST_STAT NOT IN ('3','99')
		           AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
				   AND   t.CUST_CGY = '1'
		           THEN 1
			       ELSE 0
			       END
			 )               as QLFD_ORG_CUST_TOT_99	  --合格机构客户数(不含99)

	    ,SUM(CASE  WHEN  t.ORDI_CUST_STAT NOT IN ('3')
		           AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
				   AND   t.CUST_CGY = '0'
		           THEN 1
			       ELSE 0
			       END
			 )               as QLFD_IDV_CUST_TOT	  --合格个人客户数(含99
		,SUM(CASE  WHEN  t.ORDI_CUST_STAT NOT IN ('3','99')
		           AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
				   AND   t.CUST_CGY = '0'
		           THEN 1
			       ELSE 0
			       END
			 )               as QLFD_IDV_CUST_TOT_99	  --合格个人客户数(不含99)
		,SUM(CASE  WHEN  t.ORDI_CUST_STAT  IN ('3')
		           AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
				   AND   t.ORDI_CNCLACT_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
		           THEN 1
			       ELSE 0
			       END
			 )               as CNCLACT_QLFD_CUST_TOT_TMTH	  --当月销户合格客户数
		,SUM(CASE  WHEN  t.ORDI_CUST_STAT  IN ('3')
		           AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
				   AND   t.ORDI_OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
		           THEN 1
			       ELSE 0
			       END
			 )               as QLFD_OPNAC_CNCLACT_CUST_TOT_TMTH	  --当月开户合格客户销户数
	    ,SUM(CASE  WHEN  t.ORDI_CUST_STAT  NOT IN ('3')
		           AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
				   AND   t.ORDI_OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
				   AND   t.CUST_CGY = '1'
		           THEN 1
			       ELSE 0
			       END
			 )               as ADDED_QLFD_ORG_CUST_TOT_TMTH	  --当月新增机构合格客户数(含99)
	   ,SUM(CASE  WHEN  t.ORDI_CUST_STAT  NOT IN ('3','99')
		           AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
				   AND   t.ORDI_OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
				   AND   t.CUST_CGY = '1'
		           THEN 1
			       ELSE 0
			       END
			 )               as ADDED_QLFD_ORG_CUST_TOT_TMTH_99	  --当月新增个人合格客户数(不含99)

	,SUM(CASE  WHEN  t.ORDI_CUST_STAT  NOT IN ('3')
		           AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
				   AND   t.ORDI_OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
				   AND   t.CUST_CGY = '0'
		           THEN 1
			       ELSE 0
			       END
			 )               as ADDED_QLFD_IDV_CUST_TOT_TMTH	  --当月新增个人合格客户数(含99)

		  ,SUM(CASE  WHEN  t.ORDI_CUST_STAT  NOT IN ('3')
		           AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
				   AND   t.ORDI_OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
				   AND   t.CUST_CGY = '0'
		           THEN 1
			       ELSE 0
			       END
			 )               as ADDED_QLFD_IDV_CUST_TOT_TMTH_99	  --当月新增个人人合格客户数(不含99)

		 ,SUM(CASE  WHEN  t.ORDI_CUST_STAT  NOT IN ('3')
		           AND   a1.CUST_NO IS NOT NULL
				   AND   t.ORDI_OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
				   AND   t.CUST_CGY = '1'
		           THEN 1
			       ELSE 0
			       END
			 )               as ADDED_QLFD_PROD_CUST_TOT_TMTH	  --当月新增产品客户数

FROM         DDW_PROD.T_DDW_F00_CUST_CUST_INFO   t
LEFT JOIN    DDW_PROD.T_DDW_F00_CUST_ORG_CUST_INFO a1
ON           t.CUST_NO = a1.CUST_NO
AND          a1.BUS_DATE = %d{yyyyMMdd}
AND          a1.PROD_CGY = 1
LEFT JOIN   DDW_PROD.T_DDW_INR_ORG_BRH                    a2
ON          t.BRH_NO = a2.BRH_NO
AND         a2.BUS_DATE = %d{yyyyMMdd}
WHERE       t.BUS_DATE = %d{yyyyMMdd}
AND        a2.BRH_NO IS NOT NULL
AND         NVL(t.ORDI_OPNAC_DT,99999999) <= %d{yyyyMMdd}
GROUP  BY BRH_NO
;



DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON_TEMP1;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON_TEMP1
as SELECT        t.BRH_NO      as BRH_NO  
                 ,SUM(CASE WHEN t.CPTL_ACCNT_STAT < > '3' 
               AND  t.SYS_SRC = '信用账户'
                           THEN 1
                           ELSE 0
                           END
            )       as CRD_CUST_TOT  --融资融券客户数   
                ,SUM(CASE WHEN t.CPTL_ACCNT_STAT < > '3' 
                       AND  t.SYS_SRC = '信用账户'
              AND  t.CUST_CGY = '1'
                          THEN 1
                          ELSE 0
                          END
           )    as CRD_ORG_CUST_TOT  --融资融券机构客户数  
               ,SUM(CASE WHEN t.CPTL_ACCNT_STAT < > '3' 
                      AND  t.SYS_SRC = '信用账户'
             AND  t.CUST_CGY = '0'
                         THEN 1
                         ELSE 0
                         END
          )    as CRD_IDV_CUST_TOT     --融资融券个人客户数 
           ,SUM(CASE WHEN   t.SYS_SRC = '信用账户'
               AND t.OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
                        THEN 1
                        ELSE 0
                        END
             )       as ADDED_CRD_CUST_TOT_TMTH --当月新增融资融券客户数 
             ,SUM(CASE WHEN t.SYS_SRC = '信用账户'
                       AND  t.CNCLACT_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
                       THEN 1
                       ELSE 0
                       END
    )    as CNCLACT_CRD_CUST_TOT_TMTH--当月销户融资融券客户数  
            ,SUM(CASE  WHEN t.SYS_SRC = '信用账户'
                       AND  t.OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
               AND  t.CNCLACT_DT = %d{yyyyMMdd}
                       THEN 1
                       ELSE 0
                       END
    )   as CRD_OPANC_CNCLACT_CUST_TOT_TMTH    --融资融券新增客户销户数   
           ,SUM(CASE WHEN t.SYS_SRC = '信用账户'
                   AND  t.OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
             AND  t.CUST_CGY = '1'
                     THEN 1
                     ELSE 0
                     END
    )    as ADDED_CRD_ORG_CUST_TOT_TMTH     --新增融资融券机构客户数  
          ,SUM(CASE WHEN t.SYS_SRC = '信用账户'
                 AND  t.OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
           AND  t.CUST_CGY = '0'
                    THEN 1
                    ELSE 0
                    END
     )       as ADDED_CRD_IDV_CUST_TOT_TMTH --新增融资融券个人客户数 
          ,SUM(CASE WHEN t.CPTL_ACCNT_STAT < > '3' AND t.SYS_SRC = '期权账户'
                    THEN 1
                    ELSE 0
                    END
     )       as WRNT_CUST_TOT  --个股期权客户数   
         ,SUM(CASE WHEN t.CPTL_ACCNT_STAT < > '3' 
                AND  t.SYS_SRC = '期权账户'
       AND  t.CUST_CGY = '1'
                   THEN 1
                   ELSE 0
                   END
    )    as WRNT_ORG_CUST_TOT  --个股期权机构客户数  
        ,SUM(CASE WHEN t.CPTL_ACCNT_STAT < > '3' 
               AND  t.SYS_SRC = '期权账户'
      AND  t.CUST_CGY = '0'
                  THEN 1
                  ELSE 0
                  END
   )    as WRNT_IDV_CUST_TOT     --个股期权个人客户数 
     ,SUM(CASE WHEN   t.SYS_SRC = '期权账户'
         AND t.OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
                  THEN 1
                  ELSE 0
                  END
      )       as  ADDED_WRNT_CUST_TOT_TMTH --当月新增个股期权客户数 
        ,SUM(CASE WHEN t.SYS_SRC = '期权账户'
                  AND  t.CNCLACT_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
                  THEN 1
                  ELSE 0
                  END
   )    as WRNT_CNCLACT_CUST_TOT_TMTH --个股期权销户客户数  
      ,SUM(CASE  WHEN t.SYS_SRC = '信用账户'
                 AND  t.OPNAC_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
         AND  t.CNCLACT_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
                 THEN 1
                 ELSE 0
                 END
     ) as WRNT_OPANC_CNCLACT_CUST_TOT_TMTH    --个股期权新增客户销户数   
     ,SUM(CASE WHEN t.SYS_SRC = '期权账户'
             AND  t.CNCLACT_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
       AND  t.CUST_CGY = '1'
               THEN 1
               ELSE 0
               END)    as ADDED_WRNT_ORG_CUST_TOT_TMTH     --新增个股期权机构客户数 
    ,SUM(CASE WHEN t.SYS_SRC = '期权账户'
           AND  t.CNCLACT_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
     AND  t.CUST_CGY = '0'
              THEN 1
              ELSE 0
              END)    as ADDED_WRNT_IDV_CUST_TOT_TMTH --新增个股期权个人客户数    
 FROM (SELECT t.CUST_NO as CUST_NO
              ,t.BRH_NO  as BRH_NO
     ,MIN(NVL(t.OPNAC_DT,99999999)) as OPNAC_DT
     ,MAX(NVL(t.CNCLACT_DT,99999999)) as CNCLACT_DT
     ,t.SYS_SRC  as SYS_SRC
     ,t.CPTL_ACCNT_STAT  as CPTL_ACCNT_STAT
     ,a1.CUST_CGY  as CUST_CGY
       FROM       DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS t
    LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_INFO a1
    ON         t.CUST_NO = a1.CUST_NO
    AND        t.BUS_DATE = a1.BUS_DATE
    LEFT JOIN DDW_PROD.T_DDW_INR_ORG_BRH                    a2
       ON        a1.BRH_NO = a2.BRH_NO
       AND       a2.BUS_DATE = %d{yyyyMMdd}
    WHERE      t.BUS_DATE = %d{yyyyMMdd}
    AND        t.SYS_SRC IN ('信用账户','期权账户')
    AND        a2.BRH_NO IS NOT NULL
    AND        t.CUST_NO < > '100610335855'
	AND       NVL(t.OPNAC_DT,99999999) < = %d{yyyyMMdd}
    GROUP BY CUST_NO,BRH_NO,SYS_SRC,CPTL_ACCNT_STAT,CUST_CGY 
     )   t
 GROUP BY    BRH_NO;




DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON_TEMP2;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON_TEMP2
as  SELECT  t.BRH_NO
         ,SUM(CASE WHEN t.OPN_PRVL = 888
             THEN 1
          ELSE 0
          END
    )             as OPN_T3BOD_PRVL_CUST_TOT    --开通三板权限客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 888 
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_T3BOD_PRVL_CUST_TOT_TMTH    --当月三板权限客户数
    ,SUM(CASE WHEN t.OPN_PRVL = 889
             THEN 1
          ELSE 0
          END
    )             as OPN_HK_PRVL_CUST_TOT    --开通沪港通限客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 889 
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_HK_PRVL_CUST_TOT_TMTH     --当月沪港通权限客户数
     ,SUM(CASE WHEN t.OPN_PRVL = 900
             THEN 1
          ELSE 0
          END
    )             as OPN_SK_PRVL_CUST_TOT    --开通深港通限客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 900 
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_SK_PRVL_CUST_TOT_TMTH    --当月深港通权限客户数
    ,SUM(CASE WHEN t.OPN_PRVL = 2
             THEN 1
          ELSE 0
          END
    )             as OPN_REPO_MRGNC_CUST_TOT    --开通回购融资客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 2 
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_REPO_MRGNC_CUST_TOT_TMTH    --当月开通回购融资客户数
             ,SUM(CASE WHEN t.OPN_PRVL = 3
             THEN 1
          ELSE 0
          END
    )             as OPN_REPO_MRGNS_CUST_TOT    --开通回购融券客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 3 
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_REPO_MRGNS_CUST_TOT_TMTH    --当月开通回购融券客户数
  ,SUM(CASE WHEN t.OPN_PRVL = 6
             THEN 1
          ELSE 0
          END
    )             as OPN_SHR_TFR_CUST_TOT    --开通股份转让客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 6 
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_SHR_TFR_CUST_TOT_TMTH  --当月开通股份转让客户数
        ,SUM(CASE WHEN t.OPN_PRVL = 7
             THEN 1
          ELSE 0
          END
    )             as OPN_GEM_CUST_TOT    --开通创业板客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 7 
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_GEM_CUST_TOT_TMTH    --当月开通创业板客户数
          ,SUM(CASE WHEN t.OPN_PRVL = 10
             THEN 1
          ELSE 0
          END
    )             as OPN_DLSTG_CUST_TOT    --开通退市整理客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 10 
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_DLSTG_CUST_TOT_TMTH  --当月开通退市整理客户数
    ,SUM(CASE WHEN t.OPN_PRVL = 12
             THEN 1
          ELSE 0
          END
    )             as OPN_BOND_QLFD_IVSM_CUST_TOT    --开通债券合格投资客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 12 
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_BOND_QLFD_IVSM_CUST_TOT_TMTH   --当月债券合格投资客户数
     ,SUM(CASE WHEN t.OPN_PRVL = 101
             THEN 1
          ELSE 0
          END
    )             as OPN_QOT_REPO_CUST_TOT    --开通报价回购客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 101 
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_QOT_REPO_CUST_TOT_TMTH    --当月报价回购客户数
   ,SUM(CASE WHEN t.OPN_PRVL = 102
             THEN 1
          ELSE 0
          END
    )             as OPN_PROMS_RPHS_CUST_TOT    --开通约定购回客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 102
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_PROMS_RPHS_CUST_TOT_TMTH   --当月约定购回客户数
  ,SUM(CASE WHEN t.OPN_PRVL = 106
             THEN 1
          ELSE 0
          END
    )             as OPN_PLG_REPO_CUST_TOT    --开通质押回购客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 106
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_PLG_REPO_CUST_TOT_TMTH   --当月质押回购客户数
   ,SUM(CASE WHEN t.OPN_PRVL = 110
             THEN 1
          ELSE 0
          END
    )             as OPN_STK_PLG_CUST_TOT    --开通股票质押快速放贷客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 110
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_STK_PLG_CUST_TOT_TMTH    --当月股票质押快速放贷客户数
  ,SUM(CASE WHEN t.OPN_PRVL = 117
             THEN 1
          ELSE 0
          END
    )             as OPN_STR_FND_PRVL_CUST_TOT    --开通分级基金权限客户数
       ,SUM(CASE WHEN t.OPN_PRVL = 117
              AND t.OPN_DT BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
              THEN 1
           ELSE 0
           END
      )             as OPN_STR_FND_PRVL_CUST_TOT_TMTH    --当月分级基金权限客户数
 FROM (SELECT CUST_NO
              ,CASE WHEN OPN_PRVL = 1 
           AND  EXG IN ('TA','TU')
     THEN 888
     WHEN OPN_PRVL = 1 
           AND  EXG IN ('HK')
     THEN 889 
     WHEN OPN_PRVL = 1 
           AND  EXG IN ('SK')
     THEN 900
     ELSE OPN_PRVL
     END as OPN_PRVL
     ,BRH_NO
     ,MIN(OPN_DT) as OPN_DT  
    FROM    DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
       WHERE   BUS_DATE = %d{yyyyMMdd}
    GROUP BY CUST_NO,OPN_PRVL,BRH_NO
    )  t
 GROUP BY t.BRH_NO
 ;
 
 
 INSERT OVERWRITE DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON
(
                                    BRH_NO                                   --营业部编号
								   ,CUST_TOT                                 --客户数
                                   ,ORG_CUST_TOT                             --机构客户数
                                   ,PROD_CUST_TOT                            --产品客户数
                                   ,IDV_CUST_TOT                             --个人客户数
                                   ,OPNAC_CUST_TOT_TMTH                      --当月开户数
                                   ,CNCLACT_CUST_TOT_TMTH                    --当月销户数
                                   ,QLFD_CUST_TOT                            --合格客户数(含99)
                                   ,QLFD_CUST_TOT_99                         --合格客户数(不含99)
                                   ,QLFD_ORG_CUST_TOT                        --合格机构客户数(含99)
                                   ,QLFD_ORG_CUST_TOT_99                     --合格机构客户数(不含99)
                                   ,QLFD_IDV_CUST_TOT                        --合格个人客户数(含99)
                                   ,QLFD_IDV_CUST_TOT_99                     --合格个人客户数(不含99)
                                   ,CNCLACT_QLFD_CUST_TOT_TMTH               --当月销户合格客户数
                                   ,QLFD_OPNAC_CNCLACT_CUST_TOT_TMTH         --当月开户合格客户销户数
                                   ,ADDED_QLFD_ORG_CUST_TOT_TMTH             --当月新增机构合格客户数(含99)
                                   ,ADDED_QLFD_ORG_CUST_TOT_TMTH_99          --当月新增机构合格客户数(不含99)
                                   ,ADDED_QLFD_IDV_CUST_TOT_TMTH             --当月新增个人合格客户数(含99)
                                   ,ADDED_QLFD_IDV_CUST_TOT_TMTH_99          --当月新增个人人合格客户数(不含99)
                                   ,ADDED_QLFD_PROD_CUST_TOT_TMTH            --当月新增产品客户数
                                   ,ACTVT_CUST_TOT_TMTH                      --当月激活客户数
                                   ,CRD_CUST_TOT                              --融资融券客户数
                                   ,CRD_ORG_CUST_TOT                         --融资融券机构客户数
                                   ,CRD_IDV_CUST_TOT                         --融资融券个人客户数
                                   ,ADDED_CRD_CUST_TOT_TMTH                  --当月新增融资融券客户数
                                   ,CNCLACT_CRD_CUST_TOT_TMTH                --当月销户融资融券客户数
                                   ,CRD_OPANC_CNCLACT_CUST_TOT_TMTH          --融资融券新增客户销户数 
                                   ,ADDED_CRD_ORG_CUST_TOT_TMTH              --新增融资融券机构客户数 
                                   ,ADDED_CRD_IDV_CUST_TOT_TMTH              --新增融资融券个人客户数
                                   ,WRNT_CUST_TOT                            --个股期权客户数
                                   ,WRNT_ORG_CUST_TOT                        --个股期权机构客户数 
                                   ,WRNT_IDV_CUST_TOT                        --个股期权个人客户数
                                   ,ADDED_WRNT_CUST_TOT_TMTH                 --当月新增个股期权客户数
                                   ,WRNT_CNCLACT_CUST_TOT_TMTH               --个股期权销户客户数
                                   ,WRNT_OPANC_CNCLACT_CUST_TOT_TMTH         --个股期权新增客户销户数
                                   ,ADDED_WRNT_ORG_CUST_TOT_TMTH             --新增个股期权机构客户数 
                                   ,ADDED_WRNT_IDV_CUST_TOT_TMTH             --新增个股期权个人客户数
                                   ,OPN_T3BOD_PRVL_CUST_TOT                  --开通三板权限客户数
                                   ,OPN_T3BOD_PRVL_CUST_TOT_TMTH             --当月三板权限客户数
                                   ,OPN_HK_PRVL_CUST_TOT                     --开通沪港通限客户数
                                   ,OPN_HK_PRVL_CUST_TOT_TMTH                --当月沪港通权限客户数
                                   ,OPN_SK_PRVL_CUST_TOT                     --开通深港通限客户数
                                   ,OPN_SK_PRVL_CUST_TOT_TMTH                --当月深港通权限客户数
                                   ,OPN_REPO_MRGNC_CUST_TOT                  --开通回购融资客户数
                                   ,OPN_REPO_MRGNC_CUST_TOT_TMTH             --当月开通回购融资客户数
                                   ,OPN_REPO_MRGNS_CUST_TOT                  --开通回购融券客户数
                                   ,OPN_REPO_MRGNS_CUST_TOT_TMTH             --当月开通回购融券客户数
                                   ,OPN_SHR_TFR_CUST_TOT                     --开通股份转让客户数
                                   ,OPN_SHR_TFR_CUST_TOT_TMTH                --当月开通股份转让客户数
                                   ,OPN_GEM_CUST_TOT                         --开通创业板客户数
                                   ,OPN_GEM_CUST_TOT_TMTH                    --当月开通创业板客户数
                                   ,OPN_DLSTG_CUST_TOT                       --开通退市整理客户数
                                   ,OPN_DLSTG_CUST_TOT_TMTH                  --当月开通退市整理客户数
                                   ,OPN_BOND_QLFD_IVSM_CUST_TOT              --开通债券合格投资客户数
                                   ,OPN_BOND_QLFD_IVSM_CUST_TOT_TMTH         --当月债券合格投资客户数
                                   ,OPN_QOT_REPO_CUST_TOT                    --开通报价回购客户数
                                   ,OPN_QOT_REPO_CUST_TOT_TMTH               --当月报价回购客户数
                                   ,OPN_PROMS_RPHS_CUST_TOT                  --开通约定购回客户数
                                   ,OPN_PROMS_RPHS_CUST_TOT_TMTH             --当月约定购回客户数
                                   ,OPN_PLG_REPO_CUST_TOT                    --开通质押回购客户数
                                   ,OPN_PLG_REPO_CUST_TOT_TMTH               --当月质押回购客户数
                                   ,OPN_STK_PLG_CUST_TOT                     --开通股票质押快速放贷客户数
                                   ,OPN_STK_PLG_CUST_TOT_TMTH                --当月股票质押快速放贷客户数
                                   ,OPN_STR_FND_PRVL_CUST_TOT                --开通分级基金权限客户数
								   ,OPN_STR_FND_PRVL_CUST_TOT_TMTH           --当月分级基金权限客户数
								   ,ETL_DT
 )
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT
                                    COALESCE(t.BRH_NO,a1.BRH_NO,a2.BRH_NO,a3.BRH_NO)          as BRH_NO                                --营业部
                               	   ,NVL(t.CUST_TOT,0)                                           as CUST_TOT                              --客户数
                                   ,NVL(t.ORG_CUST_TOT,0)                                       as ORG_CUST_TOT                          --机构客户数
                                   ,NVL(t.PROD_CUST_TOT,0)                                      as PROD_CUST_TOT                         --产品客户数
                                   ,NVL(t.IDV_CUST_TOT,0)                                       as IDV_CUST_TOT                          --个人客户数
                                   ,NVL(t.OPNAC_CUST_TOT_TMTH,0)                                as OPNAC_CUST_TOT_TMTH                   --当月开户数
                                   ,NVL(t.CNCLACT_CUST_TOT_TMTH,0)                              as CNCLACT_CUST_TOT_TMTH                 --当月销户数
                                   ,NVL(t.QLFD_CUST_TOT,0)                                      as QLFD_CUST_TOT                         --合格客户数(含99)
                                   ,NVL(t.QLFD_CUST_TOT_99,0)                                   as QLFD_CUST_TOT_99                      --合格客户数(不含99)
                                   ,NVL(t.QLFD_ORG_CUST_TOT,0)                                  as QLFD_ORG_CUST_TOT                     --合格机构客户数(含99)
                                   ,NVL(t.QLFD_ORG_CUST_TOT_99,0)                               as QLFD_ORG_CUST_TOT_99                  --合格机构客户数(不含99)
                                   ,NVL(t.QLFD_IDV_CUST_TOT,0)                                  as QLFD_IDV_CUST_TOT                     --合格个人客户数(含99)
                                   ,NVL(t.QLFD_IDV_CUST_TOT_99,0)                               as QLFD_IDV_CUST_TOT_99                  --合格个人客户数(不含99)
                                   ,NVL(t.CNCLACT_QLFD_CUST_TOT_TMTH,0)                         as CNCLACT_QLFD_CUST_TOT_TMTH            --当月销户合格客户数
                                   ,NVL(t.QLFD_OPNAC_CNCLACT_CUST_TOT_TMTH,0)                   as QLFD_OPNAC_CNCLACT_CUST_TOT_TMTH      --当月开户合格客户销户数
                                   ,NVL(t.ADDED_QLFD_ORG_CUST_TOT_TMTH,0)                       as ADDED_QLFD_ORG_CUST_TOT_TMTH          --当月新增机构合格客户数(含99)
                                   ,NVL(t.ADDED_QLFD_ORG_CUST_TOT_TMTH_99,0)                    as ADDED_QLFD_ORG_CUST_TOT_TMTH_99       --当月新增机构合格客户数(不含99)
                                   ,NVL(t.ADDED_QLFD_IDV_CUST_TOT_TMTH,0)                       as ADDED_QLFD_IDV_CUST_TOT_TMTH          --当月新增个人合格客户数(含99)
                                   ,NVL(t.ADDED_QLFD_IDV_CUST_TOT_TMTH_99,0)                    as ADDED_QLFD_IDV_CUST_TOT_TMTH_99       --当月新增个人人合格客户数(不含99)
                                   ,NVL(t.ADDED_QLFD_PROD_CUST_TOT_TMTH,0)                      as ADDED_QLFD_PROD_CUST_TOT_TMTH         --当月新增产品客户数                                     
                                   ,NVL(a1.CRD_CUST_TOT,0)                                      as CRD_CUST_TOT                          --融资融券客户数
                                   ,NVL(a1.CRD_ORG_CUST_TOT,0)                                  as CRD_ORG_CUST_TOT                      --融资融券机构客户数
                                   ,NVL(a1.CRD_IDV_CUST_TOT,0)                                  as CRD_IDV_CUST_TOT                      --融资融券个人客户数
                                   ,NVL(a1.ADDED_CRD_CUST_TOT_TMTH,0)                           as ADDED_CRD_CUST_TOT_TMTH               --当新增融资融券客户数
                                   ,NVL(a1.CNCLACT_CRD_CUST_TOT_TMTH,0)                         as CNCLACT_CRD_CUST_TOT_TMTH             --当月销户融资融券客户数
                                   ,NVL(a1.CRD_OPANC_CNCLACT_CUST_TOT_TMTH,0)                   as CRD_OPANC_CNCLACT_CUST_TOT_TMTH       --融资融券新增客户销户数 
                                   ,NVL(a1.ADDED_CRD_ORG_CUST_TOT_TMTH,0)                       as ADDED_CRD_ORG_CUST_TOT_TMTH           --新增融资融券机构客户数 
                                   ,NVL(a1.ADDED_CRD_IDV_CUST_TOT_TMTH,0)                       as ADDED_CRD_IDV_CUST_TOT_TMTH           --新增融资融券个人客户数
                                   ,NVL(a1.WRNT_CUST_TOT,0)                                     as WRNT_CUST_TOT                         --个股期权客户数
                                   ,NVL(a1.WRNT_ORG_CUST_TOT,0)                                 as WRNT_ORG_CUST_TOT                     --个股期权机构客户数 
                                   ,NVL(a1.WRNT_IDV_CUST_TOT,0)                                 as WRNT_IDV_CUST_TOT                     --个股期权个人客户数
                                   ,NVL(a1.ADDED_WRNT_CUST_TOT_TMTH,0)                          as ADDED_WRNT_CUST_TOT_TMTH              --当月新增个股期权客户数
                                   ,NVL(a1.WRNT_CNCLACT_CUST_TOT_TMTH,0)                        as WRNT_CNCLACT_CUST_TOT_TMTH            --个股期权销户客户数
                                   ,NVL(a1.WRNT_OPANC_CNCLACT_CUST_TOT_TMTH,0)                  as WRNT_OPANC_CNCLACT_CUST_TOT_TMTH      --个股期权新增客户销户数
                                   ,NVL(a1.ADDED_WRNT_ORG_CUST_TOT_TMTH,0)                      as ADDED_WRNT_ORG_CUST_TOT_TMTH          --新增个股期权机构客户数 
                                   ,NVL(a1.ADDED_WRNT_IDV_CUST_TOT_TMTH,0)                      as ADDED_WRNT_IDV_CUST_TOT_TMTH          --新增个股期权个人客户数
                                   ,NVL(a2.OPN_T3BOD_PRVL_CUST_TOT,0)                           as OPN_T3BOD_PRVL_CUST_TOT               --开通三板权限客户数
                                   ,NVL(a2.OPN_T3BOD_PRVL_CUST_TOT_TMTH,0)                      as OPN_T3BOD_PRVL_CUST_TOT_TMTH          --当月三板权限客户数
                                   ,NVL(a2.OPN_HK_PRVL_CUST_TOT,0)                              as OPN_HK_PRVL_CUST_TOT                  --开通沪港通限客户数
                                   ,NVL(a2.OPN_HK_PRVL_CUST_TOT_TMTH,0)                         as OPN_HK_PRVL_CUST_TOT_TMTH             --当月沪港通权限客户数
                                   ,NVL(a2.OPN_SK_PRVL_CUST_TOT,0)                              as OPN_SK_PRVL_CUST_TOT                  --开通深港通限客户数
                                   ,NVL(a2.OPN_SK_PRVL_CUST_TOT_TMTH,0)                         as OPN_SK_PRVL_CUST_TOT_TMTH             --当月深港通权限客户数
                                   ,NVL(a2.OPN_REPO_MRGNC_CUST_TOT,0)                           as OPN_REPO_MRGNC_CUST_TOT               --开通回购融资客户数
                                   ,NVL(a2.OPN_REPO_MRGNC_CUST_TOT_TMTH,0)                      as OPN_REPO_MRGNC_CUST_TOT_TMTH          --当月开通回购融资客户数
                                   ,NVL(a2.OPN_REPO_MRGNS_CUST_TOT,0)                           as OPN_REPO_MRGNS_CUST_TOT               --开通回购融券客户数
                                   ,NVL(a2.OPN_REPO_MRGNS_CUST_TOT_TMTH,0)                      as OPN_REPO_MRGNS_CUST_TOT_TMTH          --当月开通回购融券客户数
                                   ,NVL(a2.OPN_SHR_TFR_CUST_TOT,0)                              as OPN_SHR_TFR_CUST_TOT                  --开通股份转让客户数
                                   ,NVL(a2.OPN_SHR_TFR_CUST_TOT_TMTH,0)                         as OPN_SHR_TFR_CUST_TOT_TMTH             --当月开通股份转让客户数
                                   ,NVL(a2.OPN_GEM_CUST_TOT,0)                                  as OPN_GEM_CUST_TOT                      --开通创业板客户数
                                   ,NVL(a2.OPN_GEM_CUST_TOT_TMTH,0)                             as OPN_GEM_CUST_TOT_TMTH                 --当月开通创业板客户数
                                   ,NVL(a2.OPN_DLSTG_CUST_TOT,0)                                as OPN_DLSTG_CUST_TOT                    --开通退市整理客户数
                                   ,NVL(a2.OPN_DLSTG_CUST_TOT_TMTH,0)                           as OPN_DLSTG_CUST_TOT_TMTH               --当月开通退市整理客户数
                                   ,NVL(a2.OPN_BOND_QLFD_IVSM_CUST_TOT,0)                       as OPN_BOND_QLFD_IVSM_CUST_TOT           --开通债券合格投资客户数
                                   ,NVL(a2.OPN_BOND_QLFD_IVSM_CUST_TOT_TMTH,0)                  as OPN_BOND_QLFD_IVSM_CUST_TOT_TMTH      --当月债券合格投资客户数
                                   ,NVL(a2.OPN_QOT_REPO_CUST_TOT,0)                             as OPN_QOT_REPO_CUST_TOT                 --开通报价回购客户数
                                   ,NVL(a2.OPN_QOT_REPO_CUST_TOT_TMTH,0)                        as OPN_QOT_REPO_CUST_TOT_TMTH            --当月报价回购客户数
                                   ,NVL(a2.OPN_PROMS_RPHS_CUST_TOT,0)                           as OPN_PROMS_RPHS_CUST_TOT               --开通约定购回客户数
                                   ,NVL(a2.OPN_PROMS_RPHS_CUST_TOT_TMTH,0)                      as OPN_PROMS_RPHS_CUST_TOT_TMTH          --当月约定购回客户数
                                   ,NVL(a2.OPN_PLG_REPO_CUST_TOT,0)                             as OPN_PLG_REPO_CUST_TOT                 --开通质押回购客户数
                                   ,NVL(a2.OPN_PLG_REPO_CUST_TOT_TMTH,0)                        as OPN_PLG_REPO_CUST_TOT_TMTH            --当月质押回购客户数
                                   ,NVL(a2.OPN_STK_PLG_CUST_TOT,0)                              as OPN_STK_PLG_CUST_TOT                  --开通股票质押快速放贷客户数
                                   ,NVL(a2.OPN_STK_PLG_CUST_TOT_TMTH,0)                         as OPN_STK_PLG_CUST_TOT_TMTH             --当月股票质押快速放贷客户数
								   ,NVL(a2.OPN_STR_FND_PRVL_CUST_TOT,0)                         as OPN_STR_FND_PRVL_CUST_TOT             --开通分级基金权限客户数
                                   ,NVL(a2.OPN_STR_FND_PRVL_CUST_TOT_TMTH,0)                    as OPN_STR_FND_PRVL_CUST_TOT_TMTH        --当月分级基金权限客户数
                                   ,NVL(a3.ACTVT_CUST_TOT_TMTH,0)                               as ACTVT_CUST_TOT_TMTH                   --当月激活客户数
								   ,%d{yyyyMMdd}                                                    as ETL_DT                                --加载日期
 FROM       DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON_TEMP  t
 FULL JOIN  DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON_TEMP1  a1
 ON         t.BRH_NO = a1.BRH_NO
 FULL JOIN  DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON_TEMP2  a2
 ON        NVL(t.BRH_NO,a1.BRH_NO) = a2.BRH_NO
 FULL JOIN (SELECT  BRH_NO
                  ,COUNT(1) as ACTVT_CUST_TOT_TMTH --当月激活客户数
            FROM   DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS      
            WHERE  BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
            AND    BIZ_SBJ IN ('20071','20073')
           GROUP BY BRH_NO
		   )                                           a3
 ON     COALESCE(t.BRH_NO,a1.BRH_NO,a2.BRH_NO) = a3.BRH_NO
;



---------删除临时表
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON_TEMP;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON_TEMP1;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON_TEMP2;

 ------------------插入数据结束----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_CUST_STATS_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F20_BRH_CUST_STATS_MON;
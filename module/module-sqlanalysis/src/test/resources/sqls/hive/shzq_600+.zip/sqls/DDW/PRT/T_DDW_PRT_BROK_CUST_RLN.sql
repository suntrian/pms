 /* ***************************************** SQL Begin ******************************************/
 /* 脚本功能:经纪关系客户表                                                                     */
 /* 创建人:黄勇华                                                                              */
 /* 创建时间:2016-12-10                                                                       */ 
  


-------------插入数据开始--------------
TRUNCATE TABLE DDW_PROD.T_DDW_PRT_BROK_CUST_RLN ;
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_BROK_CUST_RLN
(
                                     BRH_NO                                            --营业部编号      
                                    ,BRH_NAME                                          --营业部名称      
                                    ,BRK_NO                                            --经纪人编号      
                                    ,BRK_CGY                                           --经纪人类别    
                                    ,BRK_NAME                                          --经纪人姓名      
                                    ,OPNAC_DT                                          --开户日期       
                                    ,OPNAC_MOD                                         --开户方式       
                                    ,CUST_NO                                           --客户号        
                                    ,CUST_NAME                                         --客户姓名       
                                    ,CTF_CGY_CD                                        --证件类别代码     
                                    ,CTF_NO                                            --证件号码       
                                    ,DEPMGT_BANK                                       --存管银行       
                                    ,CTRL_ATTR                                         --控制属性     
                                    ,IMAGE_TP                                          --影像资料       
                                    ,M_LAUND_RSK_LVL                                   --洗钱风险等级     
                                    ,RSK_BEAR_ABLTY                                    --风险承受能力     
                                    ,CTF_EXPR_DT                                       --证件截止日期    
                                    ,CTCT_ADDR                                         --联系地址      
                                    ,CTCT_TEL                                          --联系电话      
                                    ,PHONE                                             --手机        
                                    ,EDU_CD                                            --学历代码      
                                    ,OCP_CD                                            --职业代码
                                    ,CMSN_SETUP_DT                                     --佣金设置日期
                                    ,CMSN_SETUP_ABST                                   --佣金设置摘要										
                                    ,MTCH_AMT                                          --成交金额     
                                    ,GROSS_CMSN                                        --毛佣金      				
                                    ,IF_OPN_PHONE_ODR                                  --是否开通手机委托 
                                    ,WHITELIST_TMS                                     --白名单次数    
                                    ,BLACKLIST_TMS                                     --黑名单次数    



) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                                    t.BRH_NO                         as BRH_NO                                            --营业部编号                                              
                                   ,t.BRH_NAME                       as BRH_NAME                                          --营业部名称                                              
                                   ,t.BRK_NO                         as BRK_NO                                            --经纪人编号                                              
                                   ,t.BRK_CGY                        as BRK_CGY                                           --经纪人类别                                                                               
                                   ,t.BRK_NAME                       as BRK_NAME                                          --经纪人姓名                                              
                                   ,a1.ORDI_OPNAC_DT                      as OPNAC_DT                                          --开户日期                                               
                                   ,a1.OPNAC_MOD                     as OPNAC_MOD                                         --开户方式                                               
                                   ,a1.CUST_NO                       as CUST_NO                                           --客户号                                                
                                   ,a1.CUST_NAME                     as CUST_NAME                                         --客户姓名                                               
                                   ,a1.CTF_CGY_CD                    as CTF_CGY_CD                                        --证件类别代码                                             
                                   ,a1.CTF_NO                        as CTF_NO                                            --证件号码                                               
                                   ,a1.DEPMGT_BANK                   as DEPMGT_BANK                                       --存管银行                                               
                                   ,a1.CTRL_ATTR                     as CTRL_ATTR                                         --控制属性                                         
                                   ,a1.IMAGE_TP                      as IMAGE_TP                                          --影像资料                                               
                                   ,b2.M_LAUND_RSK_LVL_NAME           as M_LAUND_RSK_LVL                                   --洗钱风险等级                                             
                                   ,a4.RSK_BEAR_ABLTY_NAME           as RSK_BEAR_ABLTY                                    --风险承受能力                                             
                                   ,a1.CTF_EXPR_DT                   as CTF_EXPR_DT                                       --证件截止日期                                                                                                                      
                                   ,a1.CTCT_ADDR                     as CTCT_ADDR                                         --联系地址                                               
                                   ,a1.CTCT_TEL                      as CTCT_TEL                                          --联系电话                                                                         
                                   ,a1.PHONE                         as PHONE                                             --手机                                                                                  
                                   ,a1.EDU_CD                        as EDU_CD                                            --学历代码                                               
                                   ,a1.OCP_CD                        as OCP_CD                                            --职业代码  
                                   ,a1.CMSN_SETUP_DT                 as CMSN_SETUP_DT                                     --佣金设置日期
                                   ,a1.CMSN_SETUP_ABST               as CMSN_SETUP_ABST                                   --佣金设置摘要							   
                                   ,CAST(ROUND(NVL(a5.MTCH_AMT,0),2) as DECIMAL(30,2))      as MTCH_AMT                                          --成交金额           
                                   ,CAST(ROUND(NVL(a5.ACCNGROSS_CMSN,0),2) as DECIMAL(30,2)) as ACCNGROSS_CMSN                                    --毛佣金      						   
                                   ,a1.IF_OPN_PHONE_ODR              as IF_OPN_PHONE_ODR                                  --是否开通手机委托       
                                   ,NVL(a2.WHITELIST_TMS,0)          as WHITELIST_TMS                                     --白名单次数          
                                   ,NVL(a3.BLACKLIST_TMS,0)          as BLACKLIST_TMS                                     --黑名单次数          

   FROM          DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN                                             t
   LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO                                                a1
   ON            t.CUST_NO = a1.CUST_NO
   AND           t.BUS_DATE = a1.BUS_DATE   
   LEFT JOIN     (SELECT CLIENT_ID             AS CUST_NO
                        ,CAST(DT AS INT)       AS BUS_DATE  
						,COUNT(1)              AS WHITELIST_TMS 
				  FROM HSFK.HSMAN_CRM_CLIENTWHITELIST
				  GROUP BY CLIENT_ID,CAST(DT AS INT)
				  )                                                                          a2
   ON             t.CUST_NO = TRIM(a2.CUST_NO)
   AND            t.BUS_DATE = a2.BUS_DATE
   LEFT JOIN    (SELECT  a1.CUST_NO,COUNT(1) AS BLACKLIST_TMS
                  FROM    (SELECT CLIENT_ID AS CUST_NO,HOLDER_NAME AS CZZD,MIN(OC_DATE) AS DT 
				            FROM HSFK.HSMAN_HISICSENTRUST a							
							GROUP BY a.CLIENT_ID,a.HOLDER_NAME
						   ) a1
						   WHERE NOT EXISTS (SELECT 1 FROM HSFK.HSMAN_CRM_CLIENTWHITELIST a2
							                         WHERE a1.CUST_NO = a2.CLIENT_ID 
													 AND   a2.DT = '%d{yyyyMMdd}'
											)
				  GROUP BY a1.CUST_NO
                 )	                                                                          a3
   ON            t.CUST_NO = TRIM(a3.CUST_NO)		
   LEFT JOIN DDW_PROD.V_RSK_BEAR_ABLTY														  a4
   ON			a1.RSK_BEAR_ABLTY = a4.RSK_BEAR_ABLTY
   LEFT JOIN (SELECT SUM(ORDI_TRD_VOL_RMB+CRD_TRD_VOL) AS MTCH_AMT,SUM(ORDI_S1_INCM_RMB+CRD_S1_INCM) AS ACCNGROSS_CMSN,CUST_NO
				FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
				WHERE (BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd})
				GROUP BY CUST_NO
			) A5 ON T.CUST_NO = A5.CUST_NO 
  LEFT JOIN  DDW_PROD.V_M_LAUND_RSK_LVL            b2
  ON         a1.M_LAUND_RSK_LVL = b2.M_LAUND_RSK_LVL
   WHERE         t.BUS_DATE = %d{yyyyMMdd} 
   AND           t.BRK_CGY IN('1','2','3','4','103')    
 ;    
   
   
------结束----   

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_BROK_CUST_RLN',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_BROK_CUST_RLN; 
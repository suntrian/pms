--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:证券代码表                                                                           */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  

 TRUNCATE TABLE EDW_PROD.T_EDW_T04_TZQDM ;

 ---创建临时表---
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TZQDM_TEMP;
 CREATE TABLE EDW_PROD.T_EDW_T04_TZQDM_TEMP
 as SELECT             
                                     t.JYS                                 as JYS                                 --交易所                                 
                                    ,t.ZQDM                                as ZQDM                                --证券代码                                
                                    ,t.ZQMC                                as ZQMC                                --证券名称                                
                                    ,t.PYDM                                as PYDM                                --拼音代码                                
                                    ,t.ZQLB                                as ZQLB                                --证券类别                                
                                    ,t.JYDW                                as JYDW                                --交易单位                                
                                    ,t.ZQQC                                as ZQQC                                --证券全称                                
                                    ,t.FXRQ                                as FXRQ                                --发行日期                                
                                    ,t.DFRQ                                as DFRQ                                --兑付日期                                
                                    ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) as ZQJYZT   --交易状态                                
                                    ,CASE WHEN T.ZQDM = '149601' THEN 100 ELSE t.ZSP END as ZSP                   --昨收盘                                 
                                    ,CASE WHEN T.ZQDM = '149601' THEN 100 ELSE t.ZXJ END AS ZXJ                   --最新价                                 
                                    ,t.JJJYBZ                              as JJJYBZ                              --净价交易标志                              
                                    ,t.ZXLX                                as ZXLX                                --最新利息                                
                                    ,t.ZGBJ                                as ZGBJ                                --最高报价                                
                                    ,t.ZDBJ                                as ZDBJ                                --最低报价                                
                                    ,t.WTSX                                as WTSX                                --委托上限                                
                                    ,t.WTXX                                as WTXX                                --委托下限                                
                                    ,t.XQXZ                                as XQXZ                                --星期限制                                
                                    ,t.XGDM                                as XGDM                                --相关代码                                
                                    ,t.XJFS                                as XJFS                                --限价方式                                
                                    ,t.JSFBZ                               as JSFBZ                               --结算费标志                               
                                    ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) as BZDM --币种                                  
                                    ,t.JYJW                                as JYJW                                --交易价位                                
                                    ,t.MMXZ                                as MMXZ                                --买卖限制                                
                                    ,t.ZJJSTS                              as ZJJSTS                              --资金交收天数                              
                                    ,t.GFJSTS                              as GFJSTS                              --股份交收天数                              
                                    ,t.DDLXXZ                              as DDLXXZ                              --订单类型限制                              
                                    ,t.BSDDZXSL                            as BSDDZXSL                            --冰山订单最小数量                            
                                    ,t.BSDDZXPLSL                          as BSDDZXPLSL                          --冰山订单最小披露数量                          
                                    ,t.ISIN                                as ISIN                                --国际证券代码                              
                                    ,t.ZQMZ                                as ZQMZ                                --证券面值                                
                                    ,t.ZHDM                                as ZHDM                                --主证券代码                               
                                    ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZQFXDJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as ZQFXDJ                              --风险等级                                
                                    ,t.ZSS                                 as ZSS                                 --整手数  
                                    ,t1.HYDM                               as HYDM                                --行业代码                                
                                    ,t1.HYMC                               as HYMC                                --行业名称                                
                                    ,t1.ZGB                                as ZGB                                 --总股本                                 
                                    ,t1.LTG                                as LTG                                 --流通股                                 
                                    ,t1.MGZC                               as MGZC                                --每股净资产                               
                                    ,t1.MGSY                               as MGSY                                --每股收益                                
                                    ,t1.SNMGSY                             as SNMGSY                              --上年度每股收益                             
                                    ,t1.MGGJJ                              as MGGJJ                               --每股公积金                               
                                    ,t1.MGWFPLR                            as MGWFPLR                             --每股未分配利润                             
                                    ,t1.DZJGXX                             as DZJGXX                              --大宗交易价格下限                            
                                    ,t1.DZJGSX                             as DZJGSX                              --大宗交易价格上限                            
                                    ,t1.TDJJ                               as TDJJ                                --20日均价                               
                                    ,t1.GXRQ                               as GXRQ                                --更新日期                                
                                    ,t1.SHSYTS                             as SHSYTS                              --赎回顺延天数                              
                                    ,t1.HLSYTS                             as HLSYTS                              --红利顺延天数  
                                    ,'JZJY'                                as XTBS
									,t1.ZYBL                               as ZYBL
                                    ,CAST(t.DT as INT)                     as BUS_DATE									
 FROM 			JZJYCX.SECURITIES_TZQDM 						t             
 LEFT JOIN 		JZJYCX.SECURITIES_TZQDMEX 						t1
 ON 			t.JYS = t1.JYS
 AND 			t.ZQDM = t1.ZQDM
 AND            t.DT = t1.DT
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING			t2 
 ON             t2.DMLX = 'ZQJYZT'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.JYZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t3 
 ON             t3.DMLX = 'BZDM'
 AND            t3.YXT = 'JZJY'
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20)) 
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t4
 ON             t4.DMLX = 'ZQFXDJ'
 AND            t4.YXT = 'JZJY'
 AND            t4.YDM = CAST(t.ZQFXDJ AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}'
 ;

 -------插入数据结束
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TZQDM
 (
                                     JYS                                 --交易所                                
                                    ,ZQDM                                --证券代码                               
                                    ,ZQMC                                --证券名称                               
                                    ,PYDM                                --拼音代码                               
                                    ,ZQLB                                --证券类别                               
                                    ,JYDW                                --交易单位                               
                                    ,ZQQC                                --证券全称                               
                                    ,FXRQ                                --发行日期                               
                                    ,DFRQ                                --兑付日期                               
                                    ,ZQJYZT                              --证券交易状态                             
                                    ,ZSP                                 --昨收盘                                
                                    ,ZXJ                                 --最新价                                
                                    ,JJJYBZ                              --净价交易标志                             
                                    ,ZXLX                                --最新利息                               
                                    ,ZGBJ                                --最高报价                               
                                    ,ZDBJ                                --最低报价                               
                                    ,WTSX                                --委托上限                               
                                    ,WTXX                                --委托下限                               
                                    ,XQXZ                                --星期限制                               
                                    ,XGDM                                --相关代码                               
                                    ,XJFS                                --限价方式                               
                                    ,JSFBZ                               --结算费标志                              
                                    ,BZDM                                --币种代码                               
                                    ,JYJW                                --交易价位                               
                                    ,MMXZ                                --买卖限制                               
                                    ,ZJJSTS                              --资金交收天数                             
                                    ,GFJSTS                              --股份交收天数                             
                                    ,DDLXXZ                              --订单类型限制                             
                                    ,BSDDZXSL                            --冰山订单最小数量                           
                                    ,BSDDZXPLSL                          --冰山订单最小披露数量                         
                                    ,ISIN                                --国际证券代码                             
                                    ,ZQMZ                                --证券面值                               
                                    ,ZHDM                                --主证券代码                              
                                    ,ZQFXDJ                              --证券风险等级                             
                                    ,ZSS                                 --整手数    
                                    ,HYDM                                --行业代码                               
                                    ,HYMC                                --行业名称                               
                                    ,ZGB                                 --总股本                                
                                    ,LTG                                 --流通股                                
                                    ,MGZC                                --每股净资产                              
                                    ,MGSY                                --每股收益                               
                                    ,SNMGSY                              --上年度每股收益                            
                                    ,MGGJJ                               --每股公积金                              
                                    ,MGWFPLR                             --每股未分配利润                            
                                    ,DZJGXX                              --大宗交易价格下限                           
                                    ,DZJGSX                              --大宗交易价格上限                           
                                    ,TDJJ                                --20日均价                              
                                    ,GXRQ                                --更新日期                               
                                    ,SHSYTS                              --赎回顺延天数                             
                                    ,HLSYTS                              --红利顺延天数                             
                                    ,XTBS  
                             		,ZYBL
                                    ,FLAG 
 ) 
 PARTITION( bus_date = %d{yyyyMMdd}) 
 SELECT 
                        t.JYS                                 as JYS                                 --交易所                                 
                        ,t.ZQDM                                as ZQDM                                --证券代码                                
                        ,t.ZQMC                                as ZQMC                                --证券名称                                
                        ,t.PYDM                                as PYDM                                --拼音代码                                
                        ,CASE WHEN a2.SECUCODE IS NOT NULL and a2.bondnature BETWEEN 0 AND 9
						      THEN CONCAT('Z0',CAST(a2.bondnature as STRING))
							  WHEN a2.SECUCODE IS NOT NULL and a2.bondnature NOT BETWEEN 0 AND 9 
							  THEN CONCAT('Z',CAST(a2.bondnature as STRING))
							  WHEN a3.SecurityCode is not null
							  THEN CONCAT('J0',CAST(a3.TYPE as STRING))
							  ELSE t.zqlb
							  end                              as ZQLB                                --证券类别                                
                        ,t.JYDW                                as JYDW                                --交易单位                                
                        ,t.ZQQC                                as ZQQC                                --证券全称                                
                        ,t.FXRQ                                as FXRQ                                --发行日期                                
                        ,t.DFRQ                                as DFRQ                                --兑付日期                                
                        ,t.ZQJYZT                              as ZQJYZT                              --交易状态                                
                        ,t.ZSP                                 as ZSP                                 --昨收盘                                 
                        ,t.ZXJ                                 as ZXJ                                 --最新价                                 
                        ,t.JJJYBZ                              as JJJYBZ                              --净价交易标志                              
                        ,t.ZXLX                                as ZXLX                                --最新利息                                
                        ,t.ZGBJ                                as ZGBJ                                --最高报价                                
                        ,t.ZDBJ                                as ZDBJ                                --最低报价                                
                        ,t.WTSX                                as WTSX                                --委托上限                                
                        ,t.WTXX                                as WTXX                                --委托下限                                
                        ,t.XQXZ                                as XQXZ                                --星期限制                                
                        ,t.XGDM                                as XGDM                                --相关代码                                
                        ,t.XJFS                                as XJFS                                --限价方式                                
                        ,t.JSFBZ                               as JSFBZ                               --结算费标志                               
                        ,t.BZDM                                as BZDM                                --币种                                  
                        ,t.JYJW                                as JYJW                                --交易价位                                
                        ,t.MMXZ                                as MMXZ                                --买卖限制                                
                        ,t.ZJJSTS                              as ZJJSTS                              --资金交收天数                              
                        ,t.GFJSTS                              as GFJSTS                              --股份交收天数                              
                        ,t.DDLXXZ                              as DDLXXZ                              --订单类型限制                              
                        ,t.BSDDZXSL                            as BSDDZXSL                            --冰山订单最小数量                            
                        ,t.BSDDZXPLSL                          as BSDDZXPLSL                          --冰山订单最小披露数量                          
                        ,t.ISIN                                as ISIN                                --国际证券代码                              
                        ,t.ZQMZ                                as ZQMZ                                --证券面值                                
                        ,t.ZHDM                                as ZHDM                                --主证券代码                               
                        ,t.ZQFXDJ                              as ZQFXDJ                              --风险等级                                
                        ,t.ZSS                                 as ZSS                                 --整手数  
                        ,t.HYDM                               as HYDM                                --行业代码                                
                        ,t.HYMC                               as HYMC                                --行业名称                                
                        ,t.ZGB                                as ZGB                                 --总股本                                 
                        ,t.LTG                                as LTG                                 --流通股                                 
                        ,t.MGZC                               as MGZC                                --每股净资产                               
                        ,t.MGSY                               as MGSY                                --每股收益                                
                        ,t.SNMGSY                             as SNMGSY                              --上年度每股收益                             
                        ,t.MGGJJ                              as MGGJJ                               --每股公积金                               
                        ,t.MGWFPLR                            as MGWFPLR                             --每股未分配利润                             
                        ,t.DZJGXX                             as DZJGXX                              --大宗交易价格下限                            
                        ,t.DZJGSX                             as DZJGSX                              --大宗交易价格上限                            
                        ,t.TDJJ                               as TDJJ                                --20日均价                               
                        ,t.GXRQ                               as GXRQ                                --更新日期                                
                        ,t.SHSYTS                             as SHSYTS                              --赎回顺延天数                              
                        ,t.HLSYTS                             as HLSYTS                              --红利顺延天数  
                        ,'JZJY'                               as XTBS
                        ,t.ZYBL								  as ZYBL					
						,CASE WHEN t.ZQDM = '000000'
						      THEN 0
						      WHEN t.BUS_DATE BETWEEN a1.SSRQ AND a1.TSRQ
						      THEN 0
							  WHEN t.JYS = 'SB' AND SUBSTR(t.ZQDM,1,3) IN ('299','238')
							  THEN 0
							  WHEN a1.ZQDM is not null and t.BUS_DATE not BETWEEN a1.SSRQ AND a1.TSRQ
							  THEN 1
							  ELSE 2
							  END                             as FLag
 FROM           EDW_PROD.T_EDW_T04_TZQDM_TEMP    t
 LEFT JOIN      (SELECT     NVL(a.JYS,b.JYS) as JYS
                              ,NVL(a.ZQDM,b.ZQDM) as ZQDM
							  ,LEAST(NVL(a.SSRQ,99999999),NVL(b.SSRQ,99999999)) as SSRQ
							  ,GREATEST(NVL(a.TSRQ,00000000),NVL(b.TSRQ,00000000)) as TSRQ
                    FROM      (SELECT JYS,ZQDM,SSRQ,TSRQ 
					           FROM EDW_PROD.T_EDW_T04_TSZQDM
							   WHERE BUS_DATE = %d{yyyyMMdd}
							   AND   CPLB IN (1,2,3,4,5,6,7)
							   AND   ZQDM NOT LIKE '%J'
							   ) a
			        FULL JOIN  (SELECT JYS,SUBSTR(ZQDM,1,6) as ZQDM,MIN(SSRQ) as SSRQ,MAX(TSRQ) as TSRQ,BUS_DATE FROM EDW_PROD.T_EDW_T04_TSZQDM
			                     WHERE CPLB = 5
				                 AND   ZQDM LIKE '%J'
								 AND BUS_DATE = %d{yyyyMMdd}
								 GROUP BY JYS,ZQDM,BUS_DATE
				                ) b
				    ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
				    AND          a.JYS = b.JYS		)      a1
 ON             t.JYS = a1.JYS
 AND            t.ZQDM = a1.ZQDM
 LEFT JOIN      FUNDEXT.DBO_BOND_CODE              a2
 ON             t.BUS_DATE = CAST(a2.DT as INT)
 AND            t.ZQDM = a2.SECUCODE
 AND            ((t.JYS = 'SH' AND a2.SecuMarket = 83 )  OR (t.JYS = 'SZ' AND a2.SecuMarket = 90 ) )
 LEFT JOIN      fundext.dbo_MF_FundArchives      a3
 ON            t.BUS_DATE = CAST(a3.DT as INT)
 AND            t.ZQDM = a3.SecurityCode
 AND            ((t.JYS = 'SH' AND SUBSTR(t.ZQDM,1,3) IN ('500','501','502','505','519','510','511','512','513','518','515','506'))
 OR             (t.JYS = 'SZ' AND (SUBSTR(t.ZQDM,1,3) IN ('150','151','159','184') OR SUBSTR(t.ZQDM,1,2) = '16'))) 
 WHERE          t.BUS_DATE = %d{yyyyMMdd};
 
 ----增加146、149代码，从聚源取
 INSERT INTO EDW_PROD.T_EDW_T04_TZQDM
 (
                                     JYS                                 --交易所                                
                                    ,ZQDM                                --证券代码                               
                                    ,ZQMC                                --证券名称                               
                                    ,PYDM                                --拼音代码                               
                                    ,ZQLB                                --证券类别                               
                                    ,JYDW                                --交易单位                               
                                    ,ZQQC                                --证券全称                               
                                    ,FXRQ                                --发行日期                               
                                    ,DFRQ                                --兑付日期                               
                                    ,ZQJYZT                              --证券交易状态                             
                                    ,ZSP                                 --昨收盘                                
                                    ,ZXJ                                 --最新价                                
                                    ,JJJYBZ                              --净价交易标志                             
                                    ,ZXLX                                --最新利息                               
                                    ,ZGBJ                                --最高报价                               
                                    ,ZDBJ                                --最低报价                               
                                    ,WTSX                                --委托上限                               
                                    ,WTXX                                --委托下限                               
                                    ,XQXZ                                --星期限制                               
                                    ,XGDM                                --相关代码                               
                                    ,XJFS                                --限价方式                               
                                    ,JSFBZ                               --结算费标志                              
                                    ,BZDM                                --币种代码                               
                                    ,JYJW                                --交易价位                               
                                    ,MMXZ                                --买卖限制                               
                                    ,ZJJSTS                              --资金交收天数                             
                                    ,GFJSTS                              --股份交收天数                             
                                    ,DDLXXZ                              --订单类型限制                             
                                    ,BSDDZXSL                            --冰山订单最小数量                           
                                    ,BSDDZXPLSL                          --冰山订单最小披露数量                         
                                    ,ISIN                                --国际证券代码                             
                                    ,ZQMZ                                --证券面值                               
                                    ,ZHDM                                --主证券代码                              
                                    ,ZQFXDJ                              --证券风险等级                             
                                    ,ZSS                                 --整手数    
                                    ,HYDM                                --行业代码                               
                                    ,HYMC                                --行业名称                               
                                    ,ZGB                                 --总股本                                
                                    ,LTG                                 --流通股                                
                                    ,MGZC                                --每股净资产                              
                                    ,MGSY                                --每股收益                               
                                    ,SNMGSY                              --上年度每股收益                            
                                    ,MGGJJ                               --每股公积金                              
                                    ,MGWFPLR                             --每股未分配利润                            
                                    ,DZJGXX                              --大宗交易价格下限                           
                                    ,DZJGSX                              --大宗交易价格上限                           
                                    ,TDJJ                                --20日均价                              
                                    ,GXRQ                                --更新日期                               
                                    ,SHSYTS                              --赎回顺延天数                             
                                    ,HLSYTS                              --红利顺延天数                             
                                    ,XTBS
									,ZYBL
                                    ,FLAG 
 ) 
 PARTITION( bus_date = %d{yyyyMMdd}) 
 SELECT 
                         'SH'                                  as JYS                                 --交易所      SH                            
                        ,t.secucode                                as ZQDM                                --证券代码                                
                        ,t.secuabbr                                as ZQMC                                --证券名称                                
                        ,t.chispelling                                as PYDM                                --拼音代码                                
                        ,CASE WHEN t.SECUCODE IS NOT NULL and t.bondnature BETWEEN 0 AND 9
						      THEN CONCAT('Z0',CAST(t.bondnature as STRING))
							  WHEN t.SECUCODE IS NOT NULL and t.bondnature NOT BETWEEN 0 AND 9 
							  THEN CONCAT('Z',CAST(t.bondnature as STRING))
							  --WHEN a3.SecurityCode is not null
							  --THEN CONCAT('J0',CAST(a3.TYPE as STRING))
							  ELSE ''
							  end                              as ZQLB                                --证券类别                                
                        ,10                                as JYDW                                --交易单位    10                            
                        ,t.chiname                                as ZQQC                                --证券全称                                
                        ,0                                as FXRQ                                --发行日期    0                            
                        ,0                                as DFRQ                                --兑付日期    0                            
                        ,'0'                              as ZQJYZT                              --交易状态    0                            
                        ,100                                 as ZSP                                 --昨收盘     100                            
                        ,CAST((100-pay) as DECIMAL(38,2))                                 as ZXJ                                 --最新价      100                           
                        ,1                              as JJJYBZ                              --净价交易标志    1                          
                        ,0                                as ZXLX                                --最新利息       0                         
                        ,0                                as ZGBJ                                --最高报价       0                         
                        ,0                                as ZDBJ                                --最低报价        0                        
                        ,0                                as WTSX                                --委托上限         0                       
                        ,0                                as WTXX                                --委托下限        0                        
                        ,''                                as XQXZ                                --星期限制       0                         
                        ,''                                as XGDM                                --相关代码       ''                         
                        ,''                                as XJFS                                --限价方式        ''                        
                        ,0                              as JSFBZ                               --结算费标志      ''                         
                        ,'RMB'                                as BZDM                                --币种           RMB                       
                        ,0                                as JYJW                                --交易价位        0                        
                        ,0                                as MMXZ                                --买卖限制         0                       
                        ,0                              as ZJJSTS                              --资金交收天数     0                         
                        ,0                              as GFJSTS                              --股份交收天数   0                           
                        ,''                              as DDLXXZ                              --订单类型限制    0                          
                        ,0                            as BSDDZXSL                            --冰山订单最小数量      0                      
                        ,0                          as BSDDZXPLSL                          --冰山订单最小披露数量  0                        
                        ,''                                as ISIN                                --国际证券代码       ''                       
                        ,0                                as ZQMZ                                --证券面值        ''                        
                        ,''                                as ZHDM                                --主证券代码     ''                          
                        ,''                              as ZQFXDJ                              --风险等级        ''                        
                        ,0                                 as ZSS                                 --整手数    ''
                        ,''                               as HYDM                                --行业代码       ''                         
                        ,''                               as HYMC                                --行业名称      ''                        
                        ,0                                as ZGB                                 --总股本      0                           
                        ,0                                as LTG                                 --流通股       0                          
                        ,0                               as MGZC                                --每股净资产    0                           
                        ,0                               as MGSY                                --每股收益       0                         
                        ,0                             as SNMGSY                              --上年度每股收益      0                       
                        ,0                              as MGGJJ                               --每股公积金     0                          
                        ,0                            as MGWFPLR                             --每股未分配利润      0                       
                        ,0                             as DZJGXX                              --大宗交易价格下限 0                           
                        ,0                             as DZJGSX                              --大宗交易价格上限  0                          
                        ,0                               as TDJJ                                --20日均价   0                            
                        ,0                               as GXRQ                                --更新日期  0                              
                        ,0                            as SHSYTS                              --赎回顺延天数  0                            
                        ,0                             as HLSYTS                              --红利顺延天数  0
                        ,'JZJY'                        as XTBS
						,0                             as ZYBL
						,2                                  AS FLAG
FROM FUNDEXT.DBO_BOND_CODE T
LEFT JOIN (SELECT INNERCODE,SUM(payingprincipal) as pay FROM FUNDEXT.DBO_BOND_REDEMPTIONINFO WHERE DT = '%d{yyyyMMdd}' AND CONCAt(substr(regdate,1,4),substr(regdate,6,2),substr(regdate,9,2) ) < = '%d{yyyyMMdd}'  group by innercode) a1
on t.innercode = a1.innercode 
WHERE SecuMarket = 83
AND ( (SUBSTR(SECUCODE,1,3) IN ('146','149','156') and SECUCODE <> '149601')
     OR SECUCODE IN ('135678','159993','159992','159967','165053','165007','165046','165047','159997','159998','159955','168154','168155','168266','168249','168450','168451','168600','168625','168796','168797')
	)
and dt = '%d{yyyyMMdd}'

;

-----


-- INSERT INTO EDW_PROD.T_EDW_T04_TZQDM
-- (
--                                     JYS                                 --交易所                                
--                                    ,ZQDM                                --证券代码                               
--                                    ,ZQMC                                --证券名称                               
--                                    ,PYDM                                --拼音代码                               
--                                    ,ZQLB                                --证券类别                               
--                                    ,JYDW                                --交易单位                               
--                                    ,ZQQC                                --证券全称                               
--                                    ,FXRQ                                --发行日期                               
--                                    ,DFRQ                                --兑付日期                               
--                                    ,ZQJYZT                              --证券交易状态                             
--                                    ,ZSP                                 --昨收盘                                
--                                    ,ZXJ                                 --最新价                                
--                                    ,JJJYBZ                              --净价交易标志                             
--                                    ,ZXLX                                --最新利息                               
--                                    ,ZGBJ                                --最高报价                               
--                                    ,ZDBJ                                --最低报价                               
--                                    ,WTSX                                --委托上限                               
--                                    ,WTXX                                --委托下限                               
--                                    ,XQXZ                                --星期限制                               
--                                    ,XGDM                                --相关代码                               
--                                    ,XJFS                                --限价方式                               
--                                    ,JSFBZ                               --结算费标志                              
--                                    ,BZDM                                --币种代码                               
--                                    ,JYJW                                --交易价位                               
--                                    ,MMXZ                                --买卖限制                               
--                                    ,ZJJSTS                              --资金交收天数                             
--                                    ,GFJSTS                              --股份交收天数                             
--                                    ,DDLXXZ                              --订单类型限制                             
--                                    ,BSDDZXSL                            --冰山订单最小数量                           
--                                    ,BSDDZXPLSL                          --冰山订单最小披露数量                         
--                                    ,ISIN                                --国际证券代码                             
--                                    ,ZQMZ                                --证券面值                               
--                                    ,ZHDM                                --主证券代码                              
--                                    ,ZQFXDJ                              --证券风险等级                             
--                                    ,ZSS                                 --整手数    
--                                    ,HYDM                                --行业代码                               
--                                    ,HYMC                                --行业名称                               
--                                    ,ZGB                                 --总股本                                
--                                    ,LTG                                 --流通股                                
--                                    ,MGZC                                --每股净资产                              
--                                    ,MGSY                                --每股收益                               
--                                    ,SNMGSY                              --上年度每股收益                            
--                                    ,MGGJJ                               --每股公积金                              
--                                    ,MGWFPLR                             --每股未分配利润                            
--                                    ,DZJGXX                              --大宗交易价格下限                           
--                                    ,DZJGSX                              --大宗交易价格上限                           
--                                    ,TDJJ                                --20日均价                              
--                                    ,GXRQ                                --更新日期                               
--                                    ,SHSYTS                              --赎回顺延天数                             
--                                    ,HLSYTS                              --红利顺延天数                             
--                                    ,XTBS
--									,ZYBL
--                                    ,FLAG 
-- ) 
-- PARTITION( bus_date = %d{yyyyMMdd}) 
-- SELECT 
--                         'SZ'                                  as JYS                                 --交易所      SH                            
--                        ,DECODE(t.secucode,'139033','139550','139521')                              as ZQDM                                --证券代码                                
--                        , DECODE(t.secucode,'139033','139550','139521')                                as ZQMC                                --证券名称                                
--                        ,t.chispelling                                as PYDM                                --拼音代码                                
--                        ,CASE WHEN t.SECUCODE IS NOT NULL and t.bondnature BETWEEN 0 AND 9
--						      THEN CONCAT('Z0',CAST(t.bondnature as STRING))
--							  WHEN t.SECUCODE IS NOT NULL and t.bondnature NOT BETWEEN 0 AND 9 
--							  THEN CONCAT('Z',CAST(t.bondnature as STRING))
--							  --WHEN a3.SecurityCode is not null
--							  --THEN CONCAT('J0',CAST(a3.TYPE as STRING))
--							  ELSE ''
--							  end                              as ZQLB                                --证券类别                                
--                        ,1                                as JYDW                                --交易单位    10                            
--                        ,DECODE(t.secucode,'139033','139550','139521')                                as ZQQC                                --证券全称                                
--                        ,0                                as FXRQ                                --发行日期    0                            
--                        ,0                                as DFRQ                                --兑付日期    0                            
--                        ,'0'                              as ZQJYZT                              --交易状态    0                            
--                        ,100                                 as ZSP                                 --昨收盘     100                            
--                        ,100                                 as ZXJ                                 --最新价      100                           
--                        ,1                              as JJJYBZ                              --净价交易标志    1                          
--                        ,0                                as ZXLX                                --最新利息       0                         
--                        ,0                                as ZGBJ                                --最高报价       0                         
--                        ,0                                as ZDBJ                                --最低报价        0                        
--                        ,0                                as WTSX                                --委托上限         0                       
--                        ,0                                as WTXX                                --委托下限        0                        
--                        ,''                                as XQXZ                                --星期限制       0                         
--                        ,''                                as XGDM                                --相关代码       ''                         
--                        ,''                                as XJFS                                --限价方式        ''                        
--                        ,0                              as JSFBZ                               --结算费标志      ''                         
--                        ,'RMB'                                as BZDM                                --币种           RMB                       
--                        ,0                                as JYJW                                --交易价位        0                        
--                        ,0                                as MMXZ                                --买卖限制         0                       
--                        ,0                              as ZJJSTS                              --资金交收天数     0                         
--                        ,0                              as GFJSTS                              --股份交收天数   0                           
--                        ,''                              as DDLXXZ                              --订单类型限制    0                          
--                        ,0                            as BSDDZXSL                            --冰山订单最小数量      0                      
--                        ,0                          as BSDDZXPLSL                          --冰山订单最小披露数量  0                        
--                        ,''                                as ISIN                                --国际证券代码       ''                       
--                        ,0                                as ZQMZ                                --证券面值        ''                        
--                        ,''                                as ZHDM                                --主证券代码     ''                          
--                        ,''                              as ZQFXDJ                              --风险等级        ''                        
--                        ,0                                 as ZSS                                 --整手数    ''
--                        ,''                               as HYDM                                --行业代码       ''                         
--                        ,''                               as HYMC                                --行业名称      ''                        
--                        ,0                                as ZGB                                 --总股本      0                           
--                        ,0                                as LTG                                 --流通股       0                          
--                        ,0                               as MGZC                                --每股净资产    0                           
--                        ,0                               as MGSY                                --每股收益       0                         
--                        ,0                             as SNMGSY                              --上年度每股收益      0                       
--                        ,0                              as MGGJJ                               --每股公积金     0                          
--                        ,0                            as MGWFPLR                             --每股未分配利润      0                       
--                        ,0                             as DZJGXX                              --大宗交易价格下限 0                           
--                        ,0                             as DZJGSX                              --大宗交易价格上限  0                          
--                        ,0                               as TDJJ                                --20日均价   0                            
--                        ,0                               as GXRQ                                --更新日期  0                              
--                        ,0                            as SHSYTS                              --赎回顺延天数  0                            
--                        ,0                             as HLSYTS                              --红利顺延天数  0
--                        ,'JZJY'                        as XTBS
--						,0                             as ZYBL
--						,2                                  AS FLAG
--FROM FUNDEXT.DBO_BOND_CODE T
--WHERE SecuMarket = 90
--AND  SECUCODE IN ('139033','139047')
--and dt = '%d{yyyyMMdd}'
--;


INSERT INTO EDW_PROD.T_EDW_T04_TZQDM
 (
                                     JYS                                 --交易所                                
                                    ,ZQDM                                --证券代码                               
                                    ,ZQMC                                --证券名称                               
                                    ,PYDM                                --拼音代码                               
                                    ,ZQLB                                --证券类别                               
                                    ,JYDW                                --交易单位                               
                                    ,ZQQC                                --证券全称                               
                                    ,FXRQ                                --发行日期                               
                                    ,DFRQ                                --兑付日期                               
                                    ,ZQJYZT                              --证券交易状态                             
                                    ,ZSP                                 --昨收盘                                
                                    ,ZXJ                                 --最新价                                
                                    ,JJJYBZ                              --净价交易标志                             
                                    ,ZXLX                                --最新利息                               
                                    ,ZGBJ                                --最高报价                               
                                    ,ZDBJ                                --最低报价                               
                                    ,WTSX                                --委托上限                               
                                    ,WTXX                                --委托下限                               
                                    ,XQXZ                                --星期限制                               
                                    ,XGDM                                --相关代码                               
                                    ,XJFS                                --限价方式                               
                                    ,JSFBZ                               --结算费标志                              
                                    ,BZDM                                --币种代码                               
                                    ,JYJW                                --交易价位                               
                                    ,MMXZ                                --买卖限制                               
                                    ,ZJJSTS                              --资金交收天数                             
                                    ,GFJSTS                              --股份交收天数                             
                                    ,DDLXXZ                              --订单类型限制                             
                                    ,BSDDZXSL                            --冰山订单最小数量                           
                                    ,BSDDZXPLSL                          --冰山订单最小披露数量                         
                                    ,ISIN                                --国际证券代码                             
                                    ,ZQMZ                                --证券面值                               
                                    ,ZHDM                                --主证券代码                              
                                    ,ZQFXDJ                              --证券风险等级                             
                                    ,ZSS                                 --整手数    
                                    ,HYDM                                --行业代码                               
                                    ,HYMC                                --行业名称                               
                                    ,ZGB                                 --总股本                                
                                    ,LTG                                 --流通股                                
                                    ,MGZC                                --每股净资产                              
                                    ,MGSY                                --每股收益                               
                                    ,SNMGSY                              --上年度每股收益                            
                                    ,MGGJJ                               --每股公积金                              
                                    ,MGWFPLR                             --每股未分配利润                            
                                    ,DZJGXX                              --大宗交易价格下限                           
                                    ,DZJGSX                              --大宗交易价格上限                           
                                    ,TDJJ                                --20日均价                              
                                    ,GXRQ                                --更新日期                               
                                    ,SHSYTS                              --赎回顺延天数                             
                                    ,HLSYTS                              --红利顺延天数                             
                                    ,XTBS
									,ZYBL
                                    ,FLAG 
 ) 
 PARTITION( bus_date = %d{yyyyMMdd}) 
 SELECT 
                         'SZ'                                  as JYS                                     --交易所      SZ                           
                        ,'139380' AS ZQDM                                                                 --证券代码                                
                        ,'139380' AS ZQMC                                                                 --证券名称                                
                        ,t.chispelling                                as PYDM                             --拼音代码                                
                        ,CASE WHEN t.SECUCODE IS NOT NULL and t.bondnature BETWEEN 0 AND 9
						      THEN CONCAT('Z0',CAST(t.bondnature as STRING))
							  WHEN t.SECUCODE IS NOT NULL and t.bondnature NOT BETWEEN 0 AND 9 
							  THEN CONCAT('Z',CAST(t.bondnature as STRING))
							  --WHEN a3.SecurityCode is not null
							  --THEN CONCAT('J0',CAST(a3.TYPE as STRING))
							  ELSE '' END AS ZQLB                                                         --证券类别                                
                        ,1                                AS JYDW                                         --交易单位    10                            
                        ,'139380' AS ZQQC                                                                 --证券全称                                
                        ,0                                as FXRQ                                         --发行日期    0                            
                        ,0                                as DFRQ                                         --兑付日期    0                            
                        ,'0'                              as ZQJYZT                                       --交易状态    0                            
                        ,100                                 as ZSP                                       --昨收盘     100                            
                        ,100                                 as ZXJ                                       --最新价      100                           
                        ,1                              as JJJYBZ                                         --净价交易标志    1                          
                        ,0                                as ZXLX                                         --最新利息       0                         
                        ,0                                as ZGBJ                                         --最高报价       0                         
                        ,0                                as ZDBJ                                         --最低报价        0                        
                        ,0                                as WTSX                                         --委托上限         0                       
                        ,0                                as WTXX                                         --委托下限        0                        
                        ,''                                as XQXZ                                        --星期限制       0                         
                        ,''                                as XGDM                                        --相关代码       ''                         
                        ,''                                as XJFS                                        --限价方式        ''                        
                        ,0                              as JSFBZ                                          --结算费标志      ''                         
                        ,'RMB'                                as BZDM                                     --币种           RMB                       
                        ,0                                as JYJW                                         --交易价位        0                        
                        ,0                                as MMXZ                                         --买卖限制         0                       
                        ,0                              as ZJJSTS                                         --资金交收天数     0                         
                        ,0                              as GFJSTS                                         --股份交收天数   0                           
                        ,''                              as DDLXXZ                                        --订单类型限制    0                          
                        ,0                            as BSDDZXSL                                         --冰山订单最小数量      0                      
                        ,0                          as BSDDZXPLSL                                         --冰山订单最小披露数量  0                        
                        ,''                                as ISIN                                        --国际证券代码       ''                       
                        ,0                                as ZQMZ                                         --证券面值        ''                        
                        ,''                                as ZHDM                                        --主证券代码     ''                          
                        ,''                              as ZQFXDJ                                        --风险等级        ''                        
                        ,0                                 as ZSS                                         --整手数    ''
                        ,''                               as HYDM                                         --行业代码       ''                         
                        ,''                               as HYMC                                         --行业名称      ''                        
                        ,0                                as ZGB                                          --总股本      0                           
                        ,0                                as LTG                                          --流通股       0                          
                        ,0                               as MGZC                                          --每股净资产    0                           
                        ,0                               as MGSY                                          --每股收益       0                         
                        ,0                             as SNMGSY                                          --上年度每股收益      0                       
                        ,0                              as MGGJJ                                          --每股公积金     0                          
                        ,0                            as MGWFPLR                                          --每股未分配利润      0                       
                        ,0                             as DZJGXX                                          --大宗交易价格下限 0                           
                        ,0                             as DZJGSX                                          --大宗交易价格上限  0                          
                        ,0                               as TDJJ                                          --20日均价   0                            
                        ,0                               as GXRQ                                          --更新日期  0                              
                        ,0                            as SHSYTS                                           --赎回顺延天数  0                            
                        ,0                             as HLSYTS                                          --红利顺延天数  0
                        ,'JZJY'                        as XTBS
						,0                             as ZYBL
						,2                             AS FLAG
FROM FUNDEXT.DBO_BOND_CODE T
WHERE SecuMarket = 90
AND  SECUCODE IN ('139033')
and dt = '%d{yyyyMMdd}'
--union all
-- SELECT 
--                         'SZ'                                  as JYS                                     --交易所      SZ                           
--                        ,'138272' AS ZQDM                                                                 --证券代码                                
--                        ,'138272' AS ZQMC                                                                 --证券名称                                
--                        ,t.chispelling                                as PYDM                             --拼音代码                                
--                        ,CASE WHEN t.SECUCODE IS NOT NULL and t.bondnature BETWEEN 0 AND 9
--						      THEN CONCAT('Z0',CAST(t.bondnature as STRING))
--							  WHEN t.SECUCODE IS NOT NULL and t.bondnature NOT BETWEEN 0 AND 9 
--							  THEN CONCAT('Z',CAST(t.bondnature as STRING))
--							  --WHEN a3.SecurityCode is not null
--							  --THEN CONCAT('J0',CAST(a3.TYPE as STRING))
--							  ELSE '' END AS ZQLB                                                         --证券类别                                
--                        ,1                                AS JYDW                                         --交易单位    10                            
--                        ,'138272' AS ZQQC                                                                 --证券全称                                
--                        ,0                                as FXRQ                                         --发行日期    0                            
--                        ,0                                as DFRQ                                         --兑付日期    0                            
--                        ,'0'                              as ZQJYZT                                       --交易状态    0                            
--                        ,100                                 as ZSP                                       --昨收盘     100                            
--                        ,100                                 as ZXJ                                       --最新价      100                           
--                        ,1                              as JJJYBZ                                         --净价交易标志    1                          
--                        ,0                                as ZXLX                                         --最新利息       0                         
--                        ,0                                as ZGBJ                                         --最高报价       0                         
--                        ,0                                as ZDBJ                                         --最低报价        0                        
--                        ,0                                as WTSX                                         --委托上限         0                       
--                        ,0                                as WTXX                                         --委托下限        0                        
--                        ,''                                as XQXZ                                        --星期限制       0                         
--                        ,''                                as XGDM                                        --相关代码       ''                         
--                        ,''                                as XJFS                                        --限价方式        ''                        
--                        ,0                              as JSFBZ                                          --结算费标志      ''                         
--                        ,'RMB'                                as BZDM                                     --币种           RMB                       
--                        ,0                                as JYJW                                         --交易价位        0                        
--                        ,0                                as MMXZ                                         --买卖限制         0                       
--                        ,0                              as ZJJSTS                                         --资金交收天数     0                         
--                        ,0                              as GFJSTS                                         --股份交收天数   0                           
--                        ,''                              as DDLXXZ                                        --订单类型限制    0                          
--                        ,0                            as BSDDZXSL                                         --冰山订单最小数量      0                      
--                        ,0                          as BSDDZXPLSL                                         --冰山订单最小披露数量  0                        
--                        ,''                                as ISIN                                        --国际证券代码       ''                       
--                        ,0                                as ZQMZ                                         --证券面值        ''                        
--                        ,''                                as ZHDM                                        --主证券代码     ''                          
--                        ,''                              as ZQFXDJ                                        --风险等级        ''                        
--                        ,0                                 as ZSS                                         --整手数    ''
--                        ,''                               as HYDM                                         --行业代码       ''                         
--                        ,''                               as HYMC                                         --行业名称      ''                        
--                        ,0                                as ZGB                                          --总股本      0                           
--                        ,0                                as LTG                                          --流通股       0                          
--                        ,0                               as MGZC                                          --每股净资产    0                           
--                        ,0                               as MGSY                                          --每股收益       0                         
--                        ,0                             as SNMGSY                                          --上年度每股收益      0                       
--                        ,0                              as MGGJJ                                          --每股公积金     0                          
--                        ,0                            as MGWFPLR                                          --每股未分配利润      0                       
--                        ,0                             as DZJGXX                                          --大宗交易价格下限 0                           
--                        ,0                             as DZJGSX                                          --大宗交易价格上限  0                          
--                        ,0                               as TDJJ                                          --20日均价   0                            
--                        ,0                               as GXRQ                                          --更新日期  0                              
--                        ,0                            as SHSYTS                                           --赎回顺延天数  0                            
--                        ,0                             as HLSYTS                                          --红利顺延天数  0
--                        ,'JZJY'                        as XTBS
--						,0                             as ZYBL
--						,2                             AS FLAG
--FROM FUNDEXT.DBO_BOND_CODE T
--WHERE SecuMarket = 90
--AND  SECUCODE IN ('139033')
--and dt = '%d{yyyyMMdd}'
--union all
-- SELECT 
--                         'SZ'                                  as JYS                                     --交易所      SZ                           
--                        ,'138273' AS ZQDM                                                                 --证券代码                                
--                        ,'138273' AS ZQMC                                                                 --证券名称                                
--                        ,t.chispelling                                as PYDM                             --拼音代码                                
--                        ,CASE WHEN t.SECUCODE IS NOT NULL and t.bondnature BETWEEN 0 AND 9
--						      THEN CONCAT('Z0',CAST(t.bondnature as STRING))
--							  WHEN t.SECUCODE IS NOT NULL and t.bondnature NOT BETWEEN 0 AND 9 
--							  THEN CONCAT('Z',CAST(t.bondnature as STRING))
--							  --WHEN a3.SecurityCode is not null
--							  --THEN CONCAT('J0',CAST(a3.TYPE as STRING))
--							  ELSE '' END AS ZQLB                                                         --证券类别                                
--                        ,1                                AS JYDW                                         --交易单位    10                            
--                        ,'138273' AS ZQQC                                                                 --证券全称                                
--                        ,0                                as FXRQ                                         --发行日期    0                            
--                        ,0                                as DFRQ                                         --兑付日期    0                            
--                        ,'0'                              as ZQJYZT                                       --交易状态    0                            
--                        ,100                                 as ZSP                                       --昨收盘     100                            
--                        ,100                                 as ZXJ                                       --最新价      100                           
--                        ,1                              as JJJYBZ                                         --净价交易标志    1                          
--                        ,0                                as ZXLX                                         --最新利息       0                         
--                        ,0                                as ZGBJ                                         --最高报价       0                         
--                        ,0                                as ZDBJ                                         --最低报价        0                        
--                        ,0                                as WTSX                                         --委托上限         0                       
--                        ,0                                as WTXX                                         --委托下限        0                        
--                        ,''                                as XQXZ                                        --星期限制       0                         
--                        ,''                                as XGDM                                        --相关代码       ''                         
--                        ,''                                as XJFS                                        --限价方式        ''                        
--                        ,0                              as JSFBZ                                          --结算费标志      ''                         
--                        ,'RMB'                                as BZDM                                     --币种           RMB                       
--                        ,0                                as JYJW                                         --交易价位        0                        
--                        ,0                                as MMXZ                                         --买卖限制         0                       
--                        ,0                              as ZJJSTS                                         --资金交收天数     0                         
--                        ,0                              as GFJSTS                                         --股份交收天数   0                           
--                        ,''                              as DDLXXZ                                        --订单类型限制    0                          
--                        ,0                            as BSDDZXSL                                         --冰山订单最小数量      0                      
--                        ,0                          as BSDDZXPLSL                                         --冰山订单最小披露数量  0                        
--                        ,''                                as ISIN                                        --国际证券代码       ''                       
--                        ,0                                as ZQMZ                                         --证券面值        ''                        
--                        ,''                                as ZHDM                                        --主证券代码     ''                          
--                        ,''                              as ZQFXDJ                                        --风险等级        ''                        
--                        ,0                                 as ZSS                                         --整手数    ''
--                        ,''                               as HYDM                                         --行业代码       ''                         
--                        ,''                               as HYMC                                         --行业名称      ''                        
--                        ,0                                as ZGB                                          --总股本      0                           
--                        ,0                                as LTG                                          --流通股       0                          
--                        ,0                               as MGZC                                          --每股净资产    0                           
--                        ,0                               as MGSY                                          --每股收益       0                         
--                        ,0                             as SNMGSY                                          --上年度每股收益      0                       
--                        ,0                              as MGGJJ                                          --每股公积金     0                          
--                        ,0                            as MGWFPLR                                          --每股未分配利润      0                       
--                        ,0                             as DZJGXX                                          --大宗交易价格下限 0                           
--                        ,0                             as DZJGSX                                          --大宗交易价格上限  0                          
--                        ,0                               as TDJJ                                          --20日均价   0                            
--                        ,0                               as GXRQ                                          --更新日期  0                              
--                        ,0                            as SHSYTS                                           --赎回顺延天数  0                            
--                        ,0                             as HLSYTS                                          --红利顺延天数  0
--                        ,'JZJY'                        as XTBS
--						,0                             as ZYBL
--						,2                             AS FLAG
--FROM FUNDEXT.DBO_BOND_CODE T
--WHERE SecuMarket = 90
--AND  SECUCODE IN ('139033')
--and dt = '%d{yyyyMMdd}'
;
-- INSERT INTO EDW_PROD.T_EDW_T04_TZQDM
-- (
--                                     JYS                                 --交易所                                
--                                    ,ZQDM                                --证券代码                               
--                                    ,ZQMC                                --证券名称                               
--                                    ,PYDM                                --拼音代码                               
--                                    ,ZQLB                                --证券类别                               
--                                    ,JYDW                                --交易单位                               
--                                    ,ZQQC                                --证券全称                               
--                                    ,FXRQ                                --发行日期                               
--                                    ,DFRQ                                --兑付日期                               
--                                    ,ZQJYZT                              --证券交易状态                             
--                                    ,ZSP                                 --昨收盘                                
--                                    ,ZXJ                                 --最新价                                
--                                    ,JJJYBZ                              --净价交易标志                             
--                                    ,ZXLX                                --最新利息                               
--                                    ,ZGBJ                                --最高报价                               
--                                    ,ZDBJ                                --最低报价                               
--                                    ,WTSX                                --委托上限                               
--                                    ,WTXX                                --委托下限                               
--                                    ,XQXZ                                --星期限制                               
--                                    ,XGDM                                --相关代码                               
--                                    ,XJFS                                --限价方式                               
--                                    ,JSFBZ                               --结算费标志                              
--                                    ,BZDM                                --币种代码                               
--                                    ,JYJW                                --交易价位                               
--                                    ,MMXZ                                --买卖限制                               
--                                    ,ZJJSTS                              --资金交收天数                             
--                                    ,GFJSTS                              --股份交收天数                             
--                                    ,DDLXXZ                              --订单类型限制                             
--                                    ,BSDDZXSL                            --冰山订单最小数量                           
--                                    ,BSDDZXPLSL                          --冰山订单最小披露数量                         
--                                    ,ISIN                                --国际证券代码                             
--                                    ,ZQMZ                                --证券面值                               
--                                    ,ZHDM                                --主证券代码                              
--                                    ,ZQFXDJ                              --证券风险等级                             
--                                    ,ZSS                                 --整手数    
--                                    ,HYDM                                --行业代码                               
--                                    ,HYMC                                --行业名称                               
--                                    ,ZGB                                 --总股本                                
--                                    ,LTG                                 --流通股                                
--                                    ,MGZC                                --每股净资产                              
--                                    ,MGSY                                --每股收益                               
--                                    ,SNMGSY                              --上年度每股收益                            
--                                    ,MGGJJ                               --每股公积金                              
--                                    ,MGWFPLR                             --每股未分配利润                            
--                                    ,DZJGXX                              --大宗交易价格下限                           
--                                    ,DZJGSX                              --大宗交易价格上限                           
--                                    ,TDJJ                                --20日均价                              
--                                    ,GXRQ                                --更新日期                               
--                                    ,SHSYTS                              --赎回顺延天数                             
--                                    ,HLSYTS                              --红利顺延天数                             
--                                    ,XTBS
--									,ZYBL
--                                    ,FLAG 
-- ) 
-- PARTITION( bus_date = %d{yyyyMMdd}) 
-- SELECT 
--                         'SZ'                                  as JYS                                 --交易所      SH                            
--                        ,t.SecurityCode                                as ZQDM                                --证券代码                                
--                        ,t.SecurityCode                               as ZQMC                                --证券名称                                
--                        ,t.SecurityCode                                as PYDM                                --拼音代码                                
--                        ,CONCAT('J0',CAST(t.TYPE as STRING))                             as ZQLB                                --证券类别                                
--                        ,1                                as JYDW                                --交易单位    10                            
--                        ,t.SecurityCode                                as ZQQC                                --证券全称                                
--                        ,0                                as FXRQ                                --发行日期    0                            
--                        ,0                                as DFRQ                                --兑付日期    0                            
--                        ,'0'                              as ZQJYZT                              --交易状态    0                            
--                        ,1                                 as ZSP                                 --昨收盘     100                            
--                        ,1                                 as ZXJ                                 --最新价      100                           
--                        ,0                              as JJJYBZ                              --净价交易标志    1                          
--                        ,0                                as ZXLX                                --最新利息       0                         
--                        ,0                                as ZGBJ                                --最高报价       0                         
--                        ,0                                as ZDBJ                                --最低报价        0                        
--                        ,0                                as WTSX                                --委托上限         0                       
--                        ,0                                as WTXX                                --委托下限        0                        
--                        ,''                                as XQXZ                                --星期限制       0                         
--                        ,''                                as XGDM                                --相关代码       ''                         
--                        ,''                                as XJFS                                --限价方式        ''                        
--                        ,0                              as JSFBZ                               --结算费标志      ''                         
--                        ,'RMB'                                as BZDM                                --币种           RMB                       
--                        ,0                                as JYJW                                --交易价位        0                        
--                        ,0                                as MMXZ                                --买卖限制         0                       
--                        ,0                              as ZJJSTS                              --资金交收天数     0                         
--                        ,0                              as GFJSTS                              --股份交收天数   0                           
--                        ,''                              as DDLXXZ                              --订单类型限制    0                          
--                        ,0                            as BSDDZXSL                            --冰山订单最小数量      0                      
--                        ,0                          as BSDDZXPLSL                          --冰山订单最小披露数量  0                        
--                        ,''                                as ISIN                                --国际证券代码       ''                       
--                        ,0                                as ZQMZ                                --证券面值        ''                        
--                        ,''                                as ZHDM                                --主证券代码     ''                          
--                        ,''                              as ZQFXDJ                              --风险等级        ''                        
--                        ,0                                 as ZSS                                 --整手数    ''
--                        ,''                               as HYDM                                --行业代码       ''                         
--                        ,''                               as HYMC                                --行业名称      ''                        
--                        ,0                                as ZGB                                 --总股本      0                           
--                        ,0                                as LTG                                 --流通股       0                          
--                        ,0                               as MGZC                                --每股净资产    0                           
--                        ,0                               as MGSY                                --每股收益       0                         
--                        ,0                             as SNMGSY                              --上年度每股收益      0                       
--                        ,0                              as MGGJJ                               --每股公积金     0                          
--                        ,0                            as MGWFPLR                             --每股未分配利润      0                       
--                        ,0                             as DZJGXX                              --大宗交易价格下限 0                           
--                        ,0                             as DZJGSX                              --大宗交易价格上限  0                          
--                        ,0                               as TDJJ                                --20日均价   0                            
--                        ,0                               as GXRQ                                --更新日期  0                              
--                        ,0                            as SHSYTS                              --赎回顺延天数  0                            
--                        ,0                             as HLSYTS                              --红利顺延天数  0
--                        ,'JZJY'                        as XTBS
--						,0                             as ZYBL
--						,2                                  AS FLAG
--FROM fundext.dbo_MF_FundArchives T
--WHERE SecurityCode in ('161131','161728','160142')
--and dt = '%d{yyyyMMdd}'
--;



 ----删除临时表
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TZQDM_TEMP;
 
 ---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TZQDM',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
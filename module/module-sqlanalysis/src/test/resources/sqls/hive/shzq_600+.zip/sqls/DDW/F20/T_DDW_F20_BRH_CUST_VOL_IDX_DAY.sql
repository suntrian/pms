------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:营业部客户数指标日表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2018-04-20                                                                        */
---客户类别字典 0 个人 1 机构 2 产品 3 总计---实际机构 = 机构+产品
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_DAY_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_DAY_TEMP as
SELECT       
               t.BRH_NO                        as BRH_NO                      --营业部编码             
              ,t.CUST_CGY                       as CUST_CGY                     --客户类别
			  ,SUM(CASE WHEN t.CUST_STAT < > '3'
			            THEN 1
					    ELSE 0
					    END
				  )                           as CUST_VOL                     --客户数
			  ,SUM(CASE WHEN NVL(t.OPNAC_DT,99999999) = %d{yyyyMMdd}
			            THEN 1
					    ELSE 0
					    END
				  )                           as OPANC_VOL                     --开户数
			  ,SUM(CASE WHEN t.CUST_STAT = '3'
			            AND  NVL(t.CNCLACT_DT,99999999) = %d{yyyyMMdd}
						THEN 1
					    ELSE 0
					    END
				  )                           as CNCLACT_VOL                    --销户数
			  ,SUM(CASE WHEN t.CUST_STAT < > '3'
			            AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
						THEN 1
					    ELSE 0
					    END
				  )                           as QLFD_CUST_VOL                  --合格客户数
			  ,SUM(CASE WHEN t.CUST_STAT = '3'
			            AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
						AND  NVL(t.CNCLACT_DT,99999999) = %d{yyyyMMdd}
						THEN 1
					    ELSE 0
					    END
				  )                           as CNCLACT_QLFD_CUST_VOL          --销户合格客户数
			  ,SUM(CASE WHEN NVL(t.OPNAC_DT,99999999) = %d{yyyyMMdd}
			            AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
						THEN 1
					    ELSE 0
					    END
				  )                           as OPNAC_QLFD_CUST_VOL             --开户合格客户数
             
			 ,SUM(CASE WHEN t.T3BOD_OPNAC_DT IS NOT NULL
			           AND  t.IF_T3BOD < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as T3BOD_CUST_VOL                  --三板客户数
             
			 ,SUM(CASE WHEN t.HK_OPNAC_DT IS NOT NULL
			           AND  t.IF_HK < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as HK_CUST_VOL                     --沪港通客户数	
             ,SUM(CASE WHEN t.SK_OPNAC_DT IS NOT NULL
			           AND  t.IF_SK < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as SK_CUST_VOL                     --深港通客户数
             ,SUM(CASE WHEN t.H_K_OPNAC_DT IS NOT NULL
			           AND  t.IF_H_K < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as H_K_CUST_VOL                     --港股通客户数
             ,SUM(CASE WHEN t.REPO_MRGNC_OPNAC_DT IS NOT NULL
			           AND  t.IF_REPO_MRGNC < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as REPO_MRGNC_CUST_VOL               --回购融资客户数	
             ,SUM(CASE WHEN t.REPO_MRGNS_OPNAC_DT IS NOT NULL
			           AND  t.IF_REPO_MRGNS < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as REPO_MRGNS_CUST_VOL               --回购融券客户数		
             ,SUM(CASE WHEN t.NEW_T3BOD_OPNAC_DT IS NOT NULL
			           AND  t.IF_NEW_T3BOD < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as NEW_T3BOD_CUST_VOL                --新三板客户数
             ,SUM(CASE WHEN t.CRD_OPNAC_DT IS NOT NULL
			           AND  t.IF_CRD_CNCLACT < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as CRD_CUST_VOL                      --信用客户数		
             ,SUM(CASE WHEN t.WRNT_OPNAC_DT IS NOT NULL
			           AND  t.IF_WRNT_CNCLACT < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as WRNT_CUST_VOL                      --期权客户数
             ,SUM(CASE WHEN t.GEM_OPNAC_DT IS NOT NULL
			           AND  t.IF_GEM < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as GEM_CUST_VOL                      --创业板客户数
             ,SUM(CASE WHEN t.DLSTG_OPNAC_DT IS NOT NULL
			           AND  t.IF_DLSTG < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as DLSTG_CUST_VOL                      --退市整理客户数
             ,SUM(CASE WHEN t.BOND_QLFD_IVSM_OPNAC_DT IS NOT NULL
			           AND  t.IF_BOND_QLFD_IVSM < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as BOND_QLFD_IVSM_CUST_VOL                      --债券合格投资客户数
             ,SUM(CASE WHEN t.QOT_REPO_OPNAC_DT IS NOT NULL
			           AND  t.IF_QOT_REPO < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as QOT_REPO_CUST_VOL                            --报价回购客户数	
             ,SUM(CASE WHEN t.PROMS_RPHS_OPNAC_DT IS NOT NULL
			           AND  t.IF_PROMS_RPHS < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as PROMS_RPHS_CUST_VOL                          --约定购回客户数
             ,SUM(CASE WHEN t.PLG_REPO_OPNAC_DT IS NOT NULL
			           AND  t.IF_PLG_REPO < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as STK_PLG_CUST_VOL                          --股票质押客户数	
             ,SUM(CASE WHEN t.STK_PLG_OPNAC_DT IS NOT NULL
			           AND  t.IF_STK_PLG < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as MIN_LOAN_CUST_VOL                          --小微贷质押客户数
             ,SUM(CASE WHEN t.STR_FND_OPNAC_DT IS NOT NULL
			           AND  t.IF_STR_FND < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as STR_FND_CUST_VOL                          --分级基金客户数	
             ,SUM(CASE WHEN t.STIB_OPNAC_DT IS NOT NULL
			           AND  t.IF_STIB < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as STIB_CUST_VOL                          --科创板客户数	
             ,SUM(CASE WHEN t.LMT_NEW_T3BOD_OPNAC_DT IS NOT NULL
			           AND  t.IF_LMT_NEW_T3BOD < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as LMT_NEW_T3BOD_CUST_VOL                          --新三板(受限制)客户数	
             ,SUM(CASE WHEN t.CASH_PROD_OPNAC_DT IS NOT NULL
			           AND  t.IF_CASH_PROD < > 3
					   THEN 1
					   ELSE 0
					   END
				  )                           as CASH_PROD_CUST_VOL                          --现金添利客户数
           	         ,SUM(CASE WHEN t.T3BOD_OPNAC_DT = %d{yyyyMMdd}		           
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_T3BOD_CUST_VOL                --当日开通三板客户数
             
			 ,SUM(CASE WHEN t.HK_OPNAC_DT = %d{yyyyMMdd}			          
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_HK_CUST_VOL                     --当日开通沪港通客户数	
             ,SUM(CASE WHEN t.SK_OPNAC_DT = %d{yyyyMMdd}		          
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_SK_CUST_VOL                     --当日开通深港通客户数
             ,SUM(CASE WHEN t.H_K_OPNAC_DT = %d{yyyyMMdd}		           
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_H_K_CUST_VOL                     --当日开通港股通客户数
             ,SUM(CASE WHEN t.REPO_MRGNC_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_REPO_MRGNC_CUST_VOL               --当日开通回购融资客户数	
             ,SUM(CASE WHEN t.REPO_MRGNS_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_REPO_MRGNS_CUST_VOL               --当日开通回购融券客户数	
            
             ,SUM(CASE WHEN t.NEW_T3BOD_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_NEW_T3BOD_CUST_VOL                --当日开通新三板客户数
             ,SUM(CASE WHEN t.CRD_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPNAC_CRD_CUST_VOL                      --当日开户信用客户数		
             ,SUM(CASE WHEN t.WRNT_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPNAC_WRNT_CUST_VOL                      --当日开户期权客户数
             ,SUM(CASE WHEN t.GEM_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_GEM_CUST_VOL                      --当日开通创业板客户数
             ,SUM(CASE WHEN t.DLSTG_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_DLSTG_CUST_VOL                      --当日开通退市整理客户数
             ,SUM(CASE WHEN t.BOND_QLFD_IVSM_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_BOND_QLFD_IVSM_CUST_VOL                      --当日开通债券合格投资客户数
             ,SUM(CASE WHEN t.QOT_REPO_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_QOT_REPO_CUST_VOL                            --当日开通报价回购客户数	
             ,SUM(CASE WHEN t.PROMS_RPHS_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_PROMS_RPHS_CUST_VOL                          --当日开通约定购回客户数
             ,SUM(CASE WHEN t.PLG_REPO_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_STK_PLG_CUST_VOL                          --当日开通股票质押客户数	
             ,SUM(CASE WHEN t.STK_PLG_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_MIN_LOAN_CUST_VOL                          --当日开通小微贷质押客户数
             ,SUM(CASE WHEN t.STR_FND_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_STR_FND_CUST_VOL                          --当日开通分级基金客户数	
             ,SUM(CASE WHEN t.STIB_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_STIB_CUST_VOL                          --当日开通科创板客户数	
             ,SUM(CASE WHEN t.LMT_NEW_T3BOD_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_LMT_NEW_T3BOD_CUST_VOL                          --当日开通新三板(受限制)客户数	
             ,SUM(CASE WHEN t.CASH_PROD_OPNAC_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_CASH_PROD_CUST_VOL                          --当日开通现金添利客户数				  
             	         ,SUM(CASE WHEN t.T3BOD_CNCLACT_DT = %d{yyyyMMdd}		           
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_T3BOD_CUST_VOL                --当日关闭三板客户数
             
			 ,SUM(CASE WHEN t.HK_CNCLACT_DT = %d{yyyyMMdd}	          
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_HK_CUST_VOL                     --当日关闭沪港通客户数	
             ,SUM(CASE WHEN t.SK_CNCLACT_DT = %d{yyyyMMdd}	          
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_SK_CUST_VOL                     --当日关闭深港通客户数
             ,SUM(CASE WHEN t.H_K_CNCLACT_DT = %d{yyyyMMdd}	           
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_H_K_CUST_VOL                     --当日关闭港股通客户数
             ,SUM(CASE WHEN t.REPO_MRGNC_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_REPO_MRGNC_CUST_VOL               --当日关闭回购融资客户数	
             ,SUM(CASE WHEN t.REPO_MRGNS_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_REPO_MRGNS_CUST_VOL               --当日关闭回购融券客户数	
             ,SUM(CASE WHEN t.NEW_T3BOD_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_NEW_T3BOD_CUST_VOL                --当日关闭新三板客户数
             ,SUM(CASE WHEN t.CRD_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CNCLACT_CRD_CUST_VOL                      --当日销户信用客户数		
             ,SUM(CASE WHEN t.WRNT_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CNCLACT_WRNT_CUST_VOL                      --当日销户期权客户数
             ,SUM(CASE WHEN t.GEM_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_GEM_CUST_VOL                      --当日关闭创业板客户数
             ,SUM(CASE WHEN t.DLSTG_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_DLSTG_CUST_VOL                      --当日关闭退市整理客户数
             ,SUM(CASE WHEN t.BOND_QLFD_IVSM_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_BOND_QLFD_IVSM_CUST_VOL                      --当日关闭债券合格投资客户数
             ,SUM(CASE WHEN t.QOT_REPO_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_QOT_REPO_CUST_VOL                            --当日关闭报价回购客户数	
             ,SUM(CASE WHEN t.PROMS_RPHS_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_PROMS_RPHS_CUST_VOL                          --当日关闭约定购回客户数
             ,SUM(CASE WHEN t.PLG_REPO_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_STK_PLG_CUST_VOL                          --当日关闭股票质押客户数	
             ,SUM(CASE WHEN t.STK_PLG_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_MIN_LOAN_CUST_VOL                          --当日关闭小微贷质押客户数
             ,SUM(CASE WHEN t.STR_FND_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_STR_FND_CUST_VOL                          --当日关闭分级基金客户数	
             ,SUM(CASE WHEN t.STIB_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_STIB_CUST_VOL                          --当日关闭科创板客户数	
             ,SUM(CASE WHEN t.LMT_NEW_T3BOD_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_LMT_NEW_T3BOD_CUST_VOL                          --当日关闭新三板(受限制)客户数	
             ,SUM(CASE WHEN t.CASH_PROD_CNCLACT_DT = %d{yyyyMMdd}
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_CASH_PROD_CUST_VOL                          --当日关闭现金添利客户数

FROM          DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
WHERE         t.BUS_DATE = %d{yyyyMMdd}
AND           NVL(t.OPNAC_DT,99999999) < = %d{yyyyMMdd}
GROUP BY       BRH_NO                         
              ,CUST_CGY			    
;
INSERT OVERWRITE DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_DAY
(
  BELTO_FILIL_CDG                --分公司编码
, BELTO_FILIL                    --分公司名称
, BRH_NO                         --营业部编码
, BRH_FULLNM                     --营业部名称
, CUST_CGY                       --客户类别
, CUST_VOL                       --客户数
, OPANC_VOL                      --开户数
, CNCLACT_VOL                    --销户数
, QLFD_CUST_VOL                  --合格客户数
, CNCLACT_QLFD_CUST_VOL          --销户合格客户数
, OPNAC_QLFD_CUST_VOL            --开户合格客户数
, T3BOD_CUST_VOL                 --三板客户数
, HK_CUST_VOL                    --沪港通客户数	
, SK_CUST_VOL                    --深港通客户数
, H_K_CUST_VOL                   --港股通客户数
, REPO_MRGNC_CUST_VOL            --回购融资客户数	
, REPO_MRGNS_CUST_VOL            --回购融券客户数	
, NEW_T3BOD_CUST_VOL             --新三板客户数
, CRD_CUST_VOL                   --信用客户数		
, WRNT_CUST_VOL                  --期权客户数
, GEM_CUST_VOL                   --创业板客户数
, DLSTG_CUST_VOL                 --退市整理客户数
, BOND_QLFD_IVSM_CUST_VOL        --债券合格投资客户数
, QOT_REPO_CUST_VOL              --报价回购客户数	
, PROMS_RPHS_CUST_VOL            --约定购回客户数
, STK_PLG_CUST_VOL               --股票质押客户数	
, MIN_LOAN_CUST_VOL              --小微贷质押客户数
, STR_FND_CUST_VOL               --分级基金客户数	
, STIB_CUST_VOL                  --科创板客户数	
, LMT_NEW_T3BOD_CUST_VOL         --新三板(受限制)客户数	
, CASH_PROD_CUST_VOL             --现金添利客户数
, OPN_T3BOD_CUST_VOL             --当日开通三板客户数
, OPN_HK_CUST_VOL                --当日开通沪港通客户数	
, OPN_SK_CUST_VOL                --当日开通深港通客户数
, OPN_H_K_CUST_VOL               --当日开通港股通客户数
, OPN_REPO_MRGNC_CUST_VOL        --当日开通回购融资客户数	
, OPN_REPO_MRGNS_CUST_VOL        --当日开通回购融券客户数	
, OPN_NEW_T3BOD_CUST_VOL         --当日开通新三板客户数
, OPNAC_CRD_CUST_VOL             --当日开户信用客户数		
, OPNAC_WRNT_CUST_VOL            --当日开户期权客户数
, OPN_GEM_CUST_VOL               --当日开通创业板客户数
, OPN_DLSTG_CUST_VOL             --当日开通退市整理客户数
, OPN_BOND_QLFD_IVSM_CUST_VOL    --当日开通债券合格投资客户数
, OPN_QOT_REPO_CUST_VOL          --当日开通报价回购客户数	
, OPN_PROMS_RPHS_CUST_VOL        --当日开通约定购回客户数
, OPN_STK_PLG_CUST_VOL           --当日开通股票质押客户数	
, OPN_MIN_LOAN_CUST_VOL          --当日开通小微贷质押客户数
, OPN_STR_FND_CUST_VOL           --当日开通分级基金客户数	
, OPN_STIB_CUST_VOL              --当日开通科创板客户数	
	
, OPN_CASH_PROD_CUST_VOL         --当日开通现金添利客户数				  
, CLS_T3BOD_CUST_VOL             --当日关闭三板客户数
, CLS_HK_CUST_VOL                --当日关闭沪港通客户数	
, CLS_SK_CUST_VOL                --当日关闭深港通客户数
, CLS_H_K_CUST_VOL               --当日关闭港股通客户数
, CLS_REPO_MRGNC_CUST_VOL        --当日关闭回购融资客户数	
, CLS_REPO_MRGNS_CUST_VOL        --当日关闭回购融券客户数		
, CLS_NEW_T3BOD_CUST_VOL         --当日关闭新三板客户数
, CNCLACT_CRD_CUST_VOL           --当日销户信用客户数		
, CNCLACT_WRNT_CUST_VOL          --当日销户期权客户数
, CLS_GEM_CUST_VOL               --当日关闭创业板客户数
, CLS_DLSTG_CUST_VOL             --当日关闭退市整理客户数
, CLS_BOND_QLFD_IVSM_CUST_VOL    --当日关闭债券合格投资客户数
, CLS_QOT_REPO_CUST_VOL          --当日关闭报价回购客户数	
, CLS_PROMS_RPHS_CUST_VOL        --当日关闭约定购回客户数
, CLS_STK_PLG_CUST_VOL           --当日关闭股票质押客户数	
, CLS_MIN_LOAN_CUST_VOL          --当日关闭小微贷质押客户数
, CLS_STR_FND_CUST_VOL           --当日关闭分级基金客户数	
, CLS_STIB_CUST_VOL              --当日关闭科创板客户数	
, CLS_CASH_PROD_CUST_VOL         --当日关闭现金添利客户数               
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT     
  t.BELTO_FILIL_CDG                --分公司编码
, t.BELTO_FILIL                    --分公司名称
, t.BRH_NO                         --营业部编码
, t.BRH_FULLNM                     --营业部名称
, t.CUST_CGY                       --客户类别
, NVL(a1.CUST_VOL,0)                       --客户数
, NVL(a1.OPANC_VOL,0)                      --开户数
, NVL(a1.CNCLACT_VOL,0)                    --销户数
, NVL(a1.QLFD_CUST_VOL,0)                  --合格客户数
, NVL(a1.CNCLACT_QLFD_CUST_VOL,0)          --销户合格客户数
, NVL(a1.OPNAC_QLFD_CUST_VOL,0)            --开户合格客户数
, NVL(a1.T3BOD_CUST_VOL,0)                 --三板客户数
, NVL(a1.HK_CUST_VOL,0)                    --沪港通客户数	
, NVL(a1.SK_CUST_VOL,0)                    --深港通客户数
, NVL(a1.H_K_CUST_VOL,0)                   --港股通客户数
, NVL(a1.REPO_MRGNC_CUST_VOL,0)            --回购融资客户数	
, NVL(a1.REPO_MRGNS_CUST_VOL,0)            --回购融券客户数	
, NVL(a1.NEW_T3BOD_CUST_VOL,0)             --新三板客户数
, NVL(a1.CRD_CUST_VOL,0)                   --信用客户数		
, NVL(a1.WRNT_CUST_VOL,0)                  --期权客户数
, NVL(a1.GEM_CUST_VOL,0)                   --创业板客户数
, NVL(a1.DLSTG_CUST_VOL,0)                 --退市整理客户数
, NVL(a1.BOND_QLFD_IVSM_CUST_VOL,0)        --债券合格投资客户数
, NVL(a1.QOT_REPO_CUST_VOL,0)              --报价回购客户数	
, NVL(a1.PROMS_RPHS_CUST_VOL,0)            --约定购回客户数
, NVL(a1.STK_PLG_CUST_VOL,0)               --股票质押客户数	
, NVL(a1.MIN_LOAN_CUST_VOL,0)              --小微贷质押客户数
, NVL(a1.STR_FND_CUST_VOL,0)               --分级基金客户数	
, NVL(a1.STIB_CUST_VOL,0)                  --科创板客户数	
, NVL(a1.LMT_NEW_T3BOD_CUST_VOL,0)         --新三板(受限制)客户数	
, NVL(a1.CASH_PROD_CUST_VOL,0)             --现金添利客户数
, NVL(a1.OPN_T3BOD_CUST_VOL,0)             --当日开通三板客户数
, NVL(a1.OPN_HK_CUST_VOL,0)                --当日开通沪港通客户数	
, NVL(a1.OPN_SK_CUST_VOL,0)                --当日开通深港通客户数
, NVL(a1.OPN_H_K_CUST_VOL,0)               --当日开通港股通客户数
, NVL(a1.OPN_REPO_MRGNC_CUST_VOL,0)        --当日开通回购融资客户数	
, NVL(a1.OPN_REPO_MRGNS_CUST_VOL,0)        --当日开通回购融券客户数	
, NVL(a1.OPN_NEW_T3BOD_CUST_VOL,0)         --当日开通新三板客户数
, NVL(a1.OPNAC_CRD_CUST_VOL,0)             --当日开户信用客户数		
, NVL(a1.OPNAC_WRNT_CUST_VOL,0)            --当日开户期权客户数
, NVL(a1.OPN_GEM_CUST_VOL,0)               --当日开通创业板客户数
, NVL(a1.OPN_DLSTG_CUST_VOL,0)             --当日开通退市整理客户数
, NVL(a1.OPN_BOND_QLFD_IVSM_CUST_VOL,0)    --当日开通债券合格投资客户数
, NVL(a1.OPN_QOT_REPO_CUST_VOL,0)          --当日开通报价回购客户数	
, NVL(a1.OPN_PROMS_RPHS_CUST_VOL,0)        --当日开通约定购回客户数
, NVL(a1.OPN_STK_PLG_CUST_VOL,0)           --当日开通股票质押客户数	
, NVL(a1.OPN_MIN_LOAN_CUST_VOL,0)          --当日开通小微贷质押客户数
, NVL(a1.OPN_STR_FND_CUST_VOL,0)           --当日开通分级基金客户数	
, NVL(a1.OPN_STIB_CUST_VOL,0)              --当日开通科创板客户数	

, NVL(a1.OPN_CASH_PROD_CUST_VOL,0)         --当日开通现金添利客户数				  
, NVL(a1.CLS_T3BOD_CUST_VOL,0)             --当日关闭三板客户数
, NVL(a1.CLS_HK_CUST_VOL,0)                --当日关闭沪港通客户数	
, NVL(a1.CLS_SK_CUST_VOL,0)                --当日关闭深港通客户数
, NVL(a1.CLS_H_K_CUST_VOL,0)               --当日关闭港股通客户数
, NVL(a1.CLS_REPO_MRGNC_CUST_VOL,0)        --当日关闭回购融资客户数	
, NVL(a1.CLS_REPO_MRGNS_CUST_VOL,0)        --当日关闭回购融券客户数		
, NVL(a1.CLS_NEW_T3BOD_CUST_VOL,0)         --当日关闭新三板客户数
, NVL(a1.CNCLACT_CRD_CUST_VOL,0)           --当日销户信用客户数		
, NVL(a1.CNCLACT_WRNT_CUST_VOL,0)          --当日销户期权客户数
, NVL(a1.CLS_GEM_CUST_VOL,0)               --当日关闭创业板客户数
, NVL(a1.CLS_DLSTG_CUST_VOL,0)             --当日关闭退市整理客户数
, NVL(a1.CLS_BOND_QLFD_IVSM_CUST_VOL,0)    --当日关闭债券合格投资客户数
, NVL(a1.CLS_QOT_REPO_CUST_VOL,0)          --当日关闭报价回购客户数	
, NVL(a1.CLS_PROMS_RPHS_CUST_VOL,0)        --当日关闭约定购回客户数
, NVL(a1.CLS_STK_PLG_CUST_VOL,0)           --当日关闭股票质押客户数	
, NVL(a1.CLS_MIN_LOAN_CUST_VOL,0)          --当日关闭小微贷质押客户数
, NVL(a1.CLS_STR_FND_CUST_VOL,0)           --当日关闭分级基金客户数	
, NVL(a1.CLS_STIB_CUST_VOL,0)              --当日关闭科创板客户数	
, NVL(a1.CLS_CASH_PROD_CUST_VOL,0)         --当日关闭现金添利客户数  
FROM   (SELECT *,'0' as CUST_CGY 
        FROM  DDW_PROD.T_DDW_INR_ORG_BRH
        WHERE BUS_DATE = %d{yyyyMMdd}
       )		t
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_DAY_TEMP a1
ON        t.BRH_NO = a1.BRH_NO
AND       t.CUST_CGY = a1.CUST_CGY
UNION ALL
SELECT     
  t.BELTO_FILIL_CDG                --分公司编码
, t.BELTO_FILIL                    --分公司名称
, t.BRH_NO                         --营业部编码
, t.BRH_FULLNM                     --营业部名称
, t.CUST_CGY                       --客户类别
, NVL(a1.CUST_VOL,0)                       --客户数
, NVL(a1.OPANC_VOL,0)                      --开户数
, NVL(a1.CNCLACT_VOL,0)                    --销户数
, NVL(a1.QLFD_CUST_VOL,0)                  --合格客户数
, NVL(a1.CNCLACT_QLFD_CUST_VOL,0)          --销户合格客户数
, NVL(a1.OPNAC_QLFD_CUST_VOL,0)            --开户合格客户数
, NVL(a1.T3BOD_CUST_VOL,0)                 --三板客户数
, NVL(a1.HK_CUST_VOL,0)                    --沪港通客户数	
, NVL(a1.SK_CUST_VOL,0)                    --深港通客户数
, NVL(a1.H_K_CUST_VOL,0)                   --港股通客户数
, NVL(a1.REPO_MRGNC_CUST_VOL,0)            --回购融资客户数	
, NVL(a1.REPO_MRGNS_CUST_VOL,0)            --回购融券客户数	
, NVL(a1.NEW_T3BOD_CUST_VOL,0)             --新三板客户数
, NVL(a1.CRD_CUST_VOL,0)                   --信用客户数		
, NVL(a1.WRNT_CUST_VOL,0)                  --期权客户数
, NVL(a1.GEM_CUST_VOL,0)                   --创业板客户数
, NVL(a1.DLSTG_CUST_VOL,0)                 --退市整理客户数
, NVL(a1.BOND_QLFD_IVSM_CUST_VOL,0)        --债券合格投资客户数
, NVL(a1.QOT_REPO_CUST_VOL,0)              --报价回购客户数	
, NVL(a1.PROMS_RPHS_CUST_VOL,0)            --约定购回客户数
, NVL(a1.STK_PLG_CUST_VOL,0)               --股票质押客户数	
, NVL(a1.MIN_LOAN_CUST_VOL,0)              --小微贷质押客户数
, NVL(a1.STR_FND_CUST_VOL,0)               --分级基金客户数	
, NVL(a1.STIB_CUST_VOL,0)                  --科创板客户数	
, NVL(a1.LMT_NEW_T3BOD_CUST_VOL,0)         --新三板(受限制)客户数	
, NVL(a1.CASH_PROD_CUST_VOL,0)             --现金添利客户数
, NVL(a1.OPN_T3BOD_CUST_VOL,0)             --当日开通三板客户数
, NVL(a1.OPN_HK_CUST_VOL,0)                --当日开通沪港通客户数	
, NVL(a1.OPN_SK_CUST_VOL,0)                --当日开通深港通客户数
, NVL(a1.OPN_H_K_CUST_VOL,0)               --当日开通港股通客户数
, NVL(a1.OPN_REPO_MRGNC_CUST_VOL,0)        --当日开通回购融资客户数	
, NVL(a1.OPN_REPO_MRGNS_CUST_VOL,0)        --当日开通回购融券客户数	
, NVL(a1.OPN_NEW_T3BOD_CUST_VOL,0)         --当日开通新三板客户数
, NVL(a1.OPNAC_CRD_CUST_VOL,0)             --当日开户信用客户数		
, NVL(a1.OPNAC_WRNT_CUST_VOL,0)            --当日开户期权客户数
, NVL(a1.OPN_GEM_CUST_VOL,0)               --当日开通创业板客户数
, NVL(a1.OPN_DLSTG_CUST_VOL,0)             --当日开通退市整理客户数
, NVL(a1.OPN_BOND_QLFD_IVSM_CUST_VOL,0)    --当日开通债券合格投资客户数
, NVL(a1.OPN_QOT_REPO_CUST_VOL,0)          --当日开通报价回购客户数	
, NVL(a1.OPN_PROMS_RPHS_CUST_VOL,0)        --当日开通约定购回客户数
, NVL(a1.OPN_STK_PLG_CUST_VOL,0)           --当日开通股票质押客户数	
, NVL(a1.OPN_MIN_LOAN_CUST_VOL,0)          --当日开通小微贷质押客户数
, NVL(a1.OPN_STR_FND_CUST_VOL,0)           --当日开通分级基金客户数	
, NVL(a1.OPN_STIB_CUST_VOL,0)              --当日开通科创板客户数	
	
, NVL(a1.OPN_CASH_PROD_CUST_VOL,0)         --当日开通现金添利客户数				  
, NVL(a1.CLS_T3BOD_CUST_VOL,0)             --当日关闭三板客户数
, NVL(a1.CLS_HK_CUST_VOL,0)                --当日关闭沪港通客户数	
, NVL(a1.CLS_SK_CUST_VOL,0)                --当日关闭深港通客户数
, NVL(a1.CLS_H_K_CUST_VOL,0)               --当日关闭港股通客户数
, NVL(a1.CLS_REPO_MRGNC_CUST_VOL,0)        --当日关闭回购融资客户数	
, NVL(a1.CLS_REPO_MRGNS_CUST_VOL,0)        --当日关闭回购融券客户数		
, NVL(a1.CLS_NEW_T3BOD_CUST_VOL,0)         --当日关闭新三板客户数
, NVL(a1.CNCLACT_CRD_CUST_VOL,0)           --当日销户信用客户数		
, NVL(a1.CNCLACT_WRNT_CUST_VOL,0)          --当日销户期权客户数
, NVL(a1.CLS_GEM_CUST_VOL,0)               --当日关闭创业板客户数
, NVL(a1.CLS_DLSTG_CUST_VOL,0)             --当日关闭退市整理客户数
, NVL(a1.CLS_BOND_QLFD_IVSM_CUST_VOL,0)    --当日关闭债券合格投资客户数
, NVL(a1.CLS_QOT_REPO_CUST_VOL,0)          --当日关闭报价回购客户数	
, NVL(a1.CLS_PROMS_RPHS_CUST_VOL,0)        --当日关闭约定购回客户数
, NVL(a1.CLS_STK_PLG_CUST_VOL,0)           --当日关闭股票质押客户数	
, NVL(a1.CLS_MIN_LOAN_CUST_VOL,0)          --当日关闭小微贷质押客户数
, NVL(a1.CLS_STR_FND_CUST_VOL,0)           --当日关闭分级基金客户数	
, NVL(a1.CLS_STIB_CUST_VOL,0)              --当日关闭科创板客户数	
, NVL(a1.CLS_CASH_PROD_CUST_VOL,0)         --当日关闭现金添利客户数  
FROM   (SELECT *,'1' as CUST_CGY 
        FROM  DDW_PROD.T_DDW_INR_ORG_BRH
        WHERE BUS_DATE = %d{yyyyMMdd}
       )		t
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_DAY_TEMP a1
ON        t.BRH_NO = a1.BRH_NO
AND       t.CUST_CGY = a1.CUST_CGY
UNION ALL
SELECT     
  t.BELTO_FILIL_CDG                --分公司编码
, t.BELTO_FILIL                    --分公司名称
, t.BRH_NO                         --营业部编码
, t.BRH_FULLNM                     --营业部名称
, t.CUST_CGY                       --客户类别
, NVL(a1.CUST_VOL,0)                       --客户数
, NVL(a1.OPANC_VOL,0)                      --开户数
, NVL(a1.CNCLACT_VOL,0)                    --销户数
, NVL(a1.QLFD_CUST_VOL,0)                  --合格客户数
, NVL(a1.CNCLACT_QLFD_CUST_VOL,0)          --销户合格客户数
, NVL(a1.OPNAC_QLFD_CUST_VOL,0)            --开户合格客户数
, NVL(a1.T3BOD_CUST_VOL,0)                 --三板客户数
, NVL(a1.HK_CUST_VOL,0)                    --沪港通客户数	
, NVL(a1.SK_CUST_VOL,0)                    --深港通客户数
, NVL(a1.H_K_CUST_VOL,0)                   --港股通客户数
, NVL(a1.REPO_MRGNC_CUST_VOL,0)            --回购融资客户数	
, NVL(a1.REPO_MRGNS_CUST_VOL,0)            --回购融券客户数	
, NVL(a1.NEW_T3BOD_CUST_VOL,0)             --新三板客户数
, NVL(a1.CRD_CUST_VOL,0)                   --信用客户数		
, NVL(a1.WRNT_CUST_VOL,0)                  --期权客户数
, NVL(a1.GEM_CUST_VOL,0)                   --创业板客户数
, NVL(a1.DLSTG_CUST_VOL,0)                 --退市整理客户数
, NVL(a1.BOND_QLFD_IVSM_CUST_VOL,0)        --债券合格投资客户数
, NVL(a1.QOT_REPO_CUST_VOL,0)              --报价回购客户数	
, NVL(a1.PROMS_RPHS_CUST_VOL,0)            --约定购回客户数
, NVL(a1.STK_PLG_CUST_VOL,0)               --股票质押客户数	
, NVL(a1.MIN_LOAN_CUST_VOL,0)              --小微贷质押客户数
, NVL(a1.STR_FND_CUST_VOL,0)               --分级基金客户数	
, NVL(a1.STIB_CUST_VOL,0)                  --科创板客户数	
, NVL(a1.LMT_NEW_T3BOD_CUST_VOL,0)         --新三板(受限制)客户数	
, NVL(a1.CASH_PROD_CUST_VOL,0)             --现金添利客户数
, NVL(a1.OPN_T3BOD_CUST_VOL,0)             --当日开通三板客户数
, NVL(a1.OPN_HK_CUST_VOL,0)                --当日开通沪港通客户数	
, NVL(a1.OPN_SK_CUST_VOL,0)                --当日开通深港通客户数
, NVL(a1.OPN_H_K_CUST_VOL,0)               --当日开通港股通客户数
, NVL(a1.OPN_REPO_MRGNC_CUST_VOL,0)        --当日开通回购融资客户数	
, NVL(a1.OPN_REPO_MRGNS_CUST_VOL,0)        --当日开通回购融券客户数	
, NVL(a1.OPN_NEW_T3BOD_CUST_VOL,0)         --当日开通新三板客户数
, NVL(a1.OPNAC_CRD_CUST_VOL,0)             --当日开户信用客户数		
, NVL(a1.OPNAC_WRNT_CUST_VOL,0)            --当日开户期权客户数
, NVL(a1.OPN_GEM_CUST_VOL,0)               --当日开通创业板客户数
, NVL(a1.OPN_DLSTG_CUST_VOL,0)             --当日开通退市整理客户数
, NVL(a1.OPN_BOND_QLFD_IVSM_CUST_VOL,0)    --当日开通债券合格投资客户数
, NVL(a1.OPN_QOT_REPO_CUST_VOL,0)          --当日开通报价回购客户数	
, NVL(a1.OPN_PROMS_RPHS_CUST_VOL,0)        --当日开通约定购回客户数
, NVL(a1.OPN_STK_PLG_CUST_VOL,0)           --当日开通股票质押客户数	
, NVL(a1.OPN_MIN_LOAN_CUST_VOL,0)          --当日开通小微贷质押客户数
, NVL(a1.OPN_STR_FND_CUST_VOL,0)           --当日开通分级基金客户数	
, NVL(a1.OPN_STIB_CUST_VOL,0)              --当日开通科创板客户数	
	
, NVL(a1.OPN_CASH_PROD_CUST_VOL,0)         --当日开通现金添利客户数				  
, NVL(a1.CLS_T3BOD_CUST_VOL,0)             --当日关闭三板客户数
, NVL(a1.CLS_HK_CUST_VOL,0)                --当日关闭沪港通客户数	
, NVL(a1.CLS_SK_CUST_VOL,0)                --当日关闭深港通客户数
, NVL(a1.CLS_H_K_CUST_VOL,0)               --当日关闭港股通客户数
, NVL(a1.CLS_REPO_MRGNC_CUST_VOL,0)        --当日关闭回购融资客户数	
, NVL(a1.CLS_REPO_MRGNS_CUST_VOL,0)        --当日关闭回购融券客户数		
, NVL(a1.CLS_NEW_T3BOD_CUST_VOL,0)         --当日关闭新三板客户数
, NVL(a1.CNCLACT_CRD_CUST_VOL,0)           --当日销户信用客户数		
, NVL(a1.CNCLACT_WRNT_CUST_VOL,0)          --当日销户期权客户数
, NVL(a1.CLS_GEM_CUST_VOL,0)               --当日关闭创业板客户数
, NVL(a1.CLS_DLSTG_CUST_VOL,0)             --当日关闭退市整理客户数
, NVL(a1.CLS_BOND_QLFD_IVSM_CUST_VOL,0)    --当日关闭债券合格投资客户数
, NVL(a1.CLS_QOT_REPO_CUST_VOL,0)          --当日关闭报价回购客户数	
, NVL(a1.CLS_PROMS_RPHS_CUST_VOL,0)        --当日关闭约定购回客户数
, NVL(a1.CLS_STK_PLG_CUST_VOL,0)           --当日关闭股票质押客户数	
, NVL(a1.CLS_MIN_LOAN_CUST_VOL,0)          --当日关闭小微贷质押客户数
, NVL(a1.CLS_STR_FND_CUST_VOL,0)           --当日关闭分级基金客户数	
, NVL(a1.CLS_STIB_CUST_VOL,0)              --当日关闭科创板客户数	
, NVL(a1.CLS_CASH_PROD_CUST_VOL,0)         --当日关闭现金添利客户数  
FROM   (SELECT *,'2' as CUST_CGY 
        FROM  DDW_PROD.T_DDW_INR_ORG_BRH
        WHERE BUS_DATE = %d{yyyyMMdd}
       )		t
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_DAY_TEMP a1
ON        t.BRH_NO = a1.BRH_NO
AND       t.CUST_CGY = a1.CUST_CGY 
;
---------------- 插入数据结束 -----------------------
----
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_DAY_TEMP ;
-----
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_CUST_VOL_IDX_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_DAY;
 
--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:ETF基本信息表                                                                        */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
 TRUNCATE TABLE EDW_PROD.T_EDW_T04_TETF_JBXX;
------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T04_TETF_JBXX
(
                                    JYS                                 --交易所                                
                                   ,JJDM                                --基金代码                               
                                   ,JJMC                                --基金名称                               
                                   ,SGSHDM                              --一级市场代码                             
                                   ,XJDM                                --现金代码                               
                                   ,RGDM                                --认购代码                               
                                   ,RGQRDM                              --认购确认代码                             
                                   ,KSRQ_WXXJ                           --网下现金认购开始日期                         
                                   ,JSRQ_WXXJ                           --网下现金认购结束日期                         
                                   ,WSXJRGRQ                            --网上现金认购日期                           
                                   ,SGSHDW                              --最小申购赎回单位                           
                                   ,XJCE                                --T日每个篮子现金差额                         
                                   ,ZDXJTDBL                            --最大现金替代比例                           
                                   ,JZFBBZ                              --是否需要发布IOPV                         
                                   ,SGSHZT                              --申购赎回状态                             
                                   ,CFGSL                               --股票记录数                              
                                   ,RQ_T                                --T日日期                               
                                   ,RQ_PRET                             --T－1日日期                             
                                   ,XJYE                                --T－1日申购赎回单位现金余额                     
                                   ,SGSHDWJZ                            --T－1日申购赎回单位净值                       
                                   ,DWJZ                                --T－1日基金的单位净值                        
                                   ,WJLJ                                --公告文件路径                             
                                   ,TYPE_ETF                            --ETF基金类型    
                                   ,SRXJCE
								   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.JJDM                                as JJDM                                --基金代码                                
                                   ,t.JJMC                                as JJMC                                --基金名称                                
                                   ,t.SGSHDM                              as SGSHDM                              --一级市场代码(申购赎回)                        
                                   ,t.XJDM                                as XJDM                                --现金代码                                
                                   ,t.RGDM                                as RGDM                                --认购代码                                
                                   ,t.RGQRDM                              as RGQRDM                              --认购确认代码                              
                                   ,t.KSRQ_WXXJ                           as KSRQ_WXXJ                           --网下现金认购开始日期                          
                                   ,t.JSRQ_WXXJ                           as JSRQ_WXXJ                           --网下现金认购结束日期                          
                                   ,t.WSXJRGRQ                            as WSXJRGRQ                            --网上现金认购日期                            
                                   ,t.SGSHDW                              as SGSHDW                              --最小申购赎回单位                            
                                   ,t.XJCE                                as XJCE                                --T日每个篮子现金差额                          
                                   ,t.ZDXJTDBL                            as ZDXJTDBL                            --最大现金替代比例                            
                                   ,t.JZFBBZ                              as JZFBBZ                              --是否需要发布IOPV                          
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.SGSHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as SGSHZT                              --申购和赎回允许状态                           
                                   ,t.CFGSL                               as CFGSL                               --股票记录数                               
                                   ,t.RQ_T                                as RQ_T                                --T日日期                                
                                   ,t.RQ_PRET                             as RQ_PRET                             --T－1日日期                              
                                   ,t.XJYE                                as XJYE                                --T－1日申购赎回单位现金余额                      
                                   ,t.SGSHDWJZ                            as SGSHDWJZ                            --T－1日申购赎回单位净值                        
                                   ,t.DWJZ                                as DWJZ                                --T－1日基金的单位净值                         
                                   ,t.WJLJ                                as WJLJ                                --公告文件路径                              
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.TYPE AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as TYPE_ETF                            --基金类型  
                                   ,t.SRXJCE
								   ,'JZJY'								   
 FROM 			JZJYCX.SECURITIES_TETF_JBXX 					t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t1 
 ON             t1.DMLX = 'SGSHZT'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.SGSHZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING			t2 
 ON             t2.DMLX = 'TYPE_ETF'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.TYPE AS VARCHAR(20))
 WHERE 			t.DT = '%d{yyyyMMdd}';
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TETF_JBXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
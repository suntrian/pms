------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:流动性偏好字典表                                                                   */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2018-11-26                                                                        */ 

 
 --清除数据
 TRUNCATE TABLE EDW_PROD.T_EDW_T04_FLUIDITY_PREFER;
 
 ------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T04_FLUIDITY_PREFER
(
                 ID     --流动性偏好id
				,NAME   --流动性偏好名称
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     
                 ID     --流动性偏好id
				,NAME   --流动性偏好名称
FROM       JJLC.FLUIDITY_PREFER
;
 ----删除临时表
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_FLUIDITY_PREFER',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
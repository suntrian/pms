 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:基金开户信息表                                                                     */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 


--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_FND_OPNAC_INFO
(        
								 BRH_NO                             --营业部编号         
								,BRH_NAME                           --营业部名称  
                                ,OCC_BRH_NO                         --发生营业部								
								,OPNAC_DT                           --开户日期           
								,CUST_NO                            --客户号             
								,CUST_NAME                          --客户姓名  
                                ,BIZ_SBJ                            --业务科目    
								,BIZ_SBJ_NAME                       --业务科目名称
								,OPRT_TELR                           --操作柜员
								,ABST                               --摘要               
								,RSK_BEAR_ABLTY                     --风险承受能力       
								,SECOND_CARD_VRFCTN                 --二代证验证
                              --  ,OCC_BRH_NO								
								,FND_RSK_REVEAL                     --基金风险揭示  		 
								,RSK_REVEAL_REGST_DT                --风险揭示登记日     
								,RSK_REVEAL_CHG_DT                  --风险揭示变动日 
                                ,OPN_AGE                            --开通时年龄
                                ,OPRT_MOD                           --操作方式								
                                    ,CTF_CGY                        --开户证件类别
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
					 t.BRH_NO                               AS BRH_NO                             --营业部编号    
					,t.BRH_NAME                             AS BRH_NAME                           --营业部名称    
					,t.OCC_BRH_NO                           AS OCC_BRH_NO                         --发生营业部
					,t.DT                                   AS OPNAC_DT                           --开户日期      
					,t.CUST_NO                              AS CUST_NO                            --客户号        
					,t.CUST_NAME                            AS CUST_NAME                          --客户姓名      
					,t.BIZ_SBJ                              AS BIZ_SBJ                            --业务科目    
					,t.BIZ_SBJ_NAME                         AS BIZ_SBJ_NAME                       --业务科目名称
					,t.OPRT_TELR                            AS OPRT_TELR                          --操作柜员
					,t.ABST                                 AS ABST                               --摘要          
					,b1.RSK_BEAR_ABLTY_NAME                 AS RSK_BEAR_ABLTY                     --风险承受能力  
					,t.SECOND_CARD_VRFCTN                   AS SECOND_CARD_VRFCTN                 --二代证验证    
			        --,t.OCC_BRH_NO
				    ,a2.SXZ                                 AS FND_RSK_REVEAL                     --基金风险揭示  
                    ,a2.DJRQ                                AS RSK_REVEAL_REGST_DT                --风险揭示登记日
                    ,a2.BDRQ                                AS RSK_REVEAL_CHG_DT                  --风险揭示变动日
                    ,CAST(CASE WHEN NVL(a1.BRTH_YM,99999999) <>99999999 
							  THEN ROUND(EDW_PROD.G_DATE_COMPARE_DATE(CAST(t.DT AS STRING),'yyyyMMdd',CAST(a1.BRTH_YM AS STRING),'yyyyMMdd')/365,0)
							  ELSE NULL 
							  END AS DECIMAL(38,0)) 	    AS OPN_AGE                            --开通时年龄
					,t.OPRT_MOD                             AS OPRT_MOD                            --操作方式	 
      				,a5.CTF_CGY_CD_NAME           AS   CTF_CGY  --开户证件类别
  FROM  		 DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS     t
  LEFT JOIN      DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a1
  ON              t.CUST_NO = a1.CUST_NO
  AND       t.bus_date = a1.bus_date
  LEFT JOIN  (SELECT   KHH 
                      ,SXZ
                      ,DJRQ
                      ,BDRQ 
             FROM  EDW_PROD.T_EDW_T99_TKHSX 
             WHERE SXDM = 'JJFXJS' AND BUS_DATE = %d{yyyyMMdd} 
             )                                         a2
  ON        t.CUST_NO = a2.KHH
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD     a5
  ON            a1.CTF_CGY_CD = a5.CTF_CGY_CD
  LEFT JOIN 		DDW_PROD.V_RSK_BEAR_ABLTY				b1
ON				a1.RSK_BEAR_ABLTY = b1.RSK_BEAR_ABLTY  
  WHERE 		t.bus_date = %d{yyyyMMdd}
  AND       t.BIZ_SBJ IN ('20781','20401')
  AND       t.OPRT_MOD IN ('临柜','掌厅','指E通')
  ;
  ------结束----
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_FND_OPNAC_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_FND_OPNAC_INFO ;
 /* ***************************************** SQL Begin ******************************************/
 /* 脚本功能:CIF客户指标表                                                                    */
 /* 创建人:黄勇华                                                                              */
 /* 创建时间:2018-11-14                                                                       */ 

 
 
 
 
 
----前交易日 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP;
 CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP as
 SELECT a.TRD_DT,b.TRD_DT as TRD_DT_20,c.TRD_DT as TRD_DT_10,d.TRD_DT as TRD_DT_30,e.TRD_DT as TRD_DT_11
       ,CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) as INT) as TRD_DT_HALF
 FROM 
 (SELECT   TRD_DT,1 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND       TRD_DT = %d{yyyyMMdd}
  AND       BUS_DATE = %d{yyyyMMdd}
 )  a
 LEFT JOIN 
  (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC ) -19 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND       TRD_DT < = %d{yyyyMMdd}
  AND       BUS_DATE = %d{yyyyMMdd}
 )   b
 ON  a.NUM = b.NUM
 LEFT JOIN 
  (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC ) -9 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND       TRD_DT < = %d{yyyyMMdd}
  AND       BUS_DATE = %d{yyyyMMdd}
 )   c
 ON  a.NUM = c.NUM
  LEFT JOIN 
  (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC ) -29 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND       TRD_DT < = %d{yyyyMMdd}
  AND       BUS_DATE = %d{yyyyMMdd}
 )   d
 ON  a.NUM = d.NUM
  LEFT JOIN 
  (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC ) -10 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND       TRD_DT < = %d{yyyyMMdd}
  AND       BUS_DATE = %d{yyyyMMdd}
 )   e
 ON  a.NUM = e.NUM ;
 
 
 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP1;
CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP1 as
SELECT    %d{yyyyMMdd}                                 as RQ
         ,a.CUST_NO                                as KHH
		 ,'KH_ZZC_WXY'                             as ZBDM	
		 ,a.ORDI_NET_AST-NVL(b.SEC_MKTVAL,0)       as ZBZ
FROM      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    a
LEFT JOIN (SELECT CUST_NO,SUM(SEC_MKTVAL) as SEC_MKTVAL
           FROM  DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
		   WHERE BUS_DATE = %d{yyyyMMdd}
		   AND  (SUBSTR(SHRHLD_NO,1,1) = 'F' OR SUBSTR(SHRHLD_NO,1,2) = '05' OR SUBSTR(SHRHLD_NO,1,3) = '001')
		   AND   SUBSTR(SEC_CGY,1,1)  NOT IN ('A')
           AND  SYS_SRC = '普通账户' 		   
		   GROUP BY CUST_NO
		  )      b
ON    a.CUST_NO = b.CUST_NO    
WHERE a.BUS_DATE = %d{yyyyMMdd}
UNION ALL
SELECT    %d{yyyyMMdd}                      as RQ
         ,a.CUST_NO                     as KHH
		 ,'KH_ZZC'                      as ZBDM	
		 ,a.NET_TOT_AST                 as ZBZ
FROM      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    a 
WHERE a.BUS_DATE = %d{yyyyMMdd} 
UNION ALL
SELECT    %d{yyyyMMdd}                               as RQ
         ,a.CUST_NO                              as KHH
		 ,'KH_20RRJZQZHZC'                       as ZBDM	
		 ,SUM(CAST(a.NET_TOT_AST*1.000/20 as DECIMAL(38,2)))                 as ZBZ
FROM      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    a  
INNER JOIN     DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP           b
ON           a.BUS_DATE > = TRD_DT_20
INNER JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO     c
ON         a.CUST_NO = c.CUST_NO
AND        c.BUS_DATE = %d{yyyyMMdd}
--AND        c.ORDI_OPNAC_DT < = b.TRD_DT_20
WHERE      a.BUS_DATE < =  %d{yyyyMMdd}
GROUP BY   RQ
          ,KHH
          ,ZBDM
UNION ALL
SELECT    %d{yyyyMMdd}                                              as RQ
         ,a.CUST_NO                                             as KHH
		 ,'KH_20RRJZC'                                          as ZBDM	
		 ,sum(CAST((a.NET_TOT_AST-a.BANK_PROD_MKTVAL)*1.000/20 as DECIMAL(38,2)))                as ZBZ
FROM      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    a  
INNER JOIN     DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP           b
ON           a.BUS_DATE > = TRD_DT_20
INNER JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO     c
ON         a.CUST_NO = c.CUST_NO
AND        c.BUS_DATE = %d{yyyyMMdd}
WHERE      a.BUS_DATE < =  %d{yyyyMMdd}
GROUP BY   RQ
          ,KHH
          ,ZBDM
 UNION ALL
SELECT    %d{yyyyMMdd}                                              as RQ
         ,a.CUST_NO                                             as KHH
		 ,'20RRJZC_ZQHGTZZ'                                     as ZBDM	
		 ,SUM(CAST(a.NET_TOT_AST*1.000/20 as DECIMAL(38,2)))         as ZBZ
FROM      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    a  
INNER JOIN     DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP           b
ON           a.BUS_DATE > = TRD_DT_20
INNER JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO     c
ON         a.CUST_NO = c.CUST_NO
AND        c.BUS_DATE = %d{yyyyMMdd}
--AND        c.ORDI_OPNAC_DT < = b.TRD_DT_20
WHERE      a.BUS_DATE < =  %d{yyyyMMdd}
GROUP BY   RQ
          ,KHH
          ,ZBDM
 UNION ALL
SELECT    %d{yyyyMMdd}                                          as RQ
         ,a.CUST_NO                                             as KHH
		 ,'20RRJJZC_W20JYR'                                     as ZBDM	
		 ,SUM(CAST(a.NET_TOT_AST*1.000/20 as DECIMAL(38,2)))          as ZBZ
FROM      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    a  
INNER JOIN     DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP           b
ON           a.BUS_DATE > = TRD_DT_20
INNER JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO     c
ON         a.CUST_NO = c.CUST_NO
AND        c.BUS_DATE = %d{yyyyMMdd}
WHERE      a.BUS_DATE < =  %d{yyyyMMdd}
GROUP BY   RQ
          ,KHH
          ,ZBDM		  
		  
		  
 UNION ALL
SELECT    %d{yyyyMMdd}                                              as RQ
         ,a.CUST_NO                                             as KHH
		 ,'20RRJZC_GGQQ'                                        as ZBDM	
		 ,SUM(CAST(a.NET_TOT_AST*1.000/20 as DECIMAL(38,2)))                                    as ZBZ
FROM      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    a  
INNER JOIN     DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP           b
ON           a.BUS_DATE > = TRD_DT_20
WHERE      a.BUS_DATE < =  %d{yyyyMMdd}
GROUP BY   RQ
          ,KHH
          ,ZBDM
 UNION ALL
SELECT    %d{yyyyMMdd}                                              as RQ
         ,a.CUST_NO                                             as KHH
		 ,'10RRJZC_GZ'                                          as ZBDM	
		 ,AVG(a.NET_TOT_AST)                                    as ZBZ
FROM      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    a  
INNER JOIN     DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP           b
ON           a.BUS_DATE > = TRD_DT_10
INNER JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO     c
ON         a.CUST_NO = c.CUST_NO
AND        c.BUS_DATE = %d{yyyyMMdd}
AND        c.ORDI_OPNAC_DT < = b.TRD_DT_10
WHERE      a.BUS_DATE < =  %d{yyyyMMdd}
GROUP BY   RQ
          ,KHH
          ,ZBDM
 UNION ALL
SELECT    %d{yyyyMMdd}                                              as RQ
         ,a.CUST_NO                                             as KHH
		 ,'KH_10RRJZQZHZC'                                          as ZBDM	
		 ,ROUND(SUM(a.NET_TOT_AST*1.000/10),2)                                    as ZBZ
FROM      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    a  
INNER JOIN     DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP           b
ON           a.BUS_DATE > = TRD_DT_10
--INNER JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO     c
--ON         a.CUST_NO = c.CUST_NO
--AND        c.BUS_DATE = %d{yyyyMMdd}
--AND        c.ORDI_OPNAC_DT < = b.TRD_DT_10
WHERE      a.BUS_DATE < =  %d{yyyyMMdd}
GROUP BY   RQ
          ,KHH
          ,ZBDM
UNION ALL
SELECT    %d{yyyyMMdd}                      as RQ
         ,a.CUST_NO                     as KHH
		 ,'ONEYEARJZ_ZYTZZ'             as ZBDM	
		 ,a.YRBGN_NET_TOT_AST           as ZBZ
FROM      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR    a 
WHERE  YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT) 
--AND      a.BUS_DATE < =  %d{yyyyMMdd}
UNION ALL
SELECT    %d{yyyyMMdd}                                              as RQ
         ,a.CUST_NO                                             as KHH
		 ,'KH_BNHSRJSZ1'                                       as ZBDM	
		 ,SUM(CAST ((a.MKTVAL_HA+a.ORDI_MKTVAL_HB_USD*b.ZHHL-NVL(c.CRD_GL_HA,0)+a.MKTVAL_SA+a.MKTVAL_SMS+a.MKTVAL_GEM+a.ORDI_MKTVAL_SB_HKD*b.ZHHL-NVL(c.CRD_GL_SA,0))*1.000/d.NUM as DECIMAL(38,2)))                                   as ZBZ
FROM          (SELECT *,1 as ID  from  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
           WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) as INT) AND %d{yyyyMMdd}
		   )   a  
LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH              b
 ON            b.BZDM = 'USD'
 AND            a.BUS_DATE = b.BUS_DATE
LEFT JOIN  DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY   c
ON   a.CUST_NO = c.CUST_NO
AND  a.BUS_DATE = c.BUS_DATE
LEFT JOIN (SELECT 1 as ID,COUNT(1) as NUM 
        FROM EDW_PROD.T_EDW_T99_TRD_DATE 
		WHERE NAT_DT BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) as INT) AND %d{yyyyMMdd}
        AND  BUS_DATE = %d{yyyyMMdd}
		AND  NAT_DT =TRD_DT 
        ) d
 ON a.ID = d.ID
--WHERE  a.BUS_DATE BETWEEN  CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) as INT) AND %d{yyyyMMdd}
GROUP BY   RQ
          ,KHH
          ,ZBDM
UNION ALL
SELECT    %d{yyyyMMdd}                                              as RQ
         ,a.CUST_NO                                             as KHH
		 ,'KH_BNHSRJSZ'                                       as ZBDM	
		 ,SUM(CAST ((a.ORDI_SEC_MKTVAL+a.CRD_SEC_MKTVAL+a.WRNT_MKTVAL-a.TOTGL)*1.000/d.NUM as DECIMAL(38,2)))                                   as ZBZ
FROM          (SELECT *,1 as ID  from  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
           WHERE BUS_DATE > CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) as INT) 
		   AND BUS_DATE < = %d{yyyyMMdd}
		   )   a  
LEFT JOIN (SELECT 1 as ID,COUNT(1) as NUM 
        FROM EDW_PROD.T_EDW_T99_TRD_DATE 
		WHERE NAT_DT > CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) as INT) 
		AND  NAT_DT < = %d{yyyyMMdd}
        AND  BUS_DATE = %d{yyyyMMdd}
		AND  NAT_DT =TRD_DT 
        ) d
 ON a.ID = d.ID
--WHERE  a.BUS_DATE BETWEEN  CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) as INT) AND %d{yyyyMMdd}
GROUP BY   RQ
          ,KHH
          ,ZBDM
UNION ALL
SELECT    %d{yyyyMMdd}                                              as RQ
         ,a.CUST_NO                                             as KHH
		 ,'KH_BNHSRJZC'                                        as ZBDM	
		 ,SUM(CAST((a.MKTVAL_HA+a.ORDI_MKTVAL_HB_USD*b.ZHHL+a.ORDI_MKTVAL_HK+a.ORDI_MKTVAL_EXG_FND_SH+a.CRD_MKTVAL_EXG_FND_SH+a.ORDI_MKTVAL_BOND_SH+a.CRD_MKTVAL_BOND_SH+a.ORDI_UN_CIR_MKTVAL_SH-NVL(c.CRD_GL_HA,0))*1.000/d.NUM as DECIMAL(38,2)))    as ZBZ
FROM       (SELECT *,1 as ID  from  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
           WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) as INT) AND %d{yyyyMMdd}
		   )   a  
LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH              b
 ON            b.BZDM = 'HKD'
 AND            a.BUS_DATE = b.BUS_DATE
LEFT JOIN  DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY   c
ON   a.CUST_NO = c.CUST_NO
AND  a.BUS_DATE = c.BUS_DATE
LEFT JOIN (SELECT 1 as ID,COUNT(1) as NUM 
        FROM EDW_PROD.T_EDW_T99_TRD_DATE 
		WHERE NAT_DT BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) as INT) AND %d{yyyyMMdd}
        AND  BUS_DATE = %d{yyyyMMdd}
		AND  NAT_DT =TRD_DT 
        ) d
 ON a.ID = d.ID
--WHERE  a.BUS_DATE BETWEEN  CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) as INT) AND %d{yyyyMMdd}
GROUP BY   RQ
          ,KHH
          ,ZBDM
		  
 ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP2;
CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP2 as
SELECT   a.TRD_DT,b.TRD_DT as TRD_DT_20,c.TRD_DT as TRD_DT_21,d.TRD_DT as TRD_DT_3,e.TRD_DT as TRD_DT_1,f.TRD_DT as TRD_DT_60,h.TRD_DT as TRD_DT_30,m.TRD_DT as TRD_DT_11,n.TRD_DT as TRD_DT_10
FROM  
(SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC ) as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND       TRD_DT > = 20180101
  AND       BUS_DATE = %d{yyyyMMdd}
 )   a
 LEFT JOIN 
 (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC )-19 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND        TRD_DT > = 20180101
  AND       BUS_DATE = %d{yyyyMMdd}
 )   b
 ON a.NUM = b.NUM
  LEFT JOIN 
 (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC )-20 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND        TRD_DT > = 20180101
  AND       BUS_DATE = %d{yyyyMMdd}
 )   c
 ON a.NUM = c.NUM
  LEFT JOIN 
 (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC )+2 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND        TRD_DT > = 20180101
  AND       BUS_DATE = %d{yyyyMMdd}
 )   d
 ON a.NUM = d.NUM 
  LEFT JOIN 
 (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC )+1 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND        TRD_DT > = 20180101
  AND       BUS_DATE = %d{yyyyMMdd}
 )   e
 ON a.NUM = e.NUM
   LEFT JOIN 
 (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC )-59 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND        TRD_DT > = 20180101
  AND       BUS_DATE = %d{yyyyMMdd}
 )   f
 ON a.NUM = f.NUM
   LEFT JOIN 
 (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC )-29 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND        TRD_DT > = 20180101
  AND       BUS_DATE = %d{yyyyMMdd}
 )   h
 ON a.NUM = h.NUM
   LEFT JOIN 
 (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC )-10 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND        TRD_DT > = 20180101
  AND       BUS_DATE = %d{yyyyMMdd}
 )   m
 ON a.NUM = m.NUM
  LEFT JOIN 
 (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC )-9 as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND        TRD_DT > = 20180101
  AND       BUS_DATE = %d{yyyyMMdd}
 )   n
 ON a.NUM = n.NUM
 WHERE  a.TRD_DT = %d{yyyyMMdd} ;

  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP3;
CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP3 as
 SELECT distinct KHH FROM
 
 (SELECT KHH,CASE WHEN b.BZDM IS NOT NULL
                THEN a.SRJE*b.ZHHL
				ELSE a.SRJE
				END SRJE
		,a.BUS_DATE
FROM EDW_PROD.T_EDW_T05_TZJMXLS  a
LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH              b
ON             a.BZDM = b.BZDM
AND            b.BUS_DATE = a.BUS_DATE
WHERE (a.YWKM IN ('10399') OR SUBSTR(a.YWKM,1,3) in ('101')) AND a.BUS_DATE >= 20190101
AND a.BUS_DATE <= %d{yyyyMMdd}
) t
INNER JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP2 a1
ON         t.BUS_DATE > = a1.TRD_DT_20
WHERE t.SRJE > = 500000 ;



 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP4;
CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP4 as
SELECT t.CUST_NO,count(1) AS num
from 
(select CUST_NO,NET_TOT_AST,bus_date 
FROM  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
where bus_date > = 20180601
and   bus_date <= %d{yyyyMMdd}
AND NET_TOT_AST >= 500000
) t
INNER JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP2 a1
ON         t.BUS_DATE > = a1.TRD_DT_60 
AND        t.BUS_DATE < a1.TRD_DT_20
group by T.cust_no
having count(1) <= 5 ;


 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP5;
CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP5 as
 SELECT distinct KHH FROM
 
 (SELECT KHH,CASE WHEN b.BZDM IS NOT NULL
                THEN a.SRJE*b.ZHHL
				ELSE a.SRJE
				END SRJE
		,a.BUS_DATE
FROM EDW_PROD.T_EDW_T05_TZJMXLS  a
LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH              b
ON             a.BZDM = b.BZDM
AND            b.BUS_DATE = a.BUS_DATE
WHERE (a.YWKM IN ('10399') OR SUBSTR(a.YWKM,1,3) in ('101')) AND a.BUS_DATE >= 20190101
AND a.BUS_DATE <= %d{yyyyMMdd}
) t
INNER JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP2 a1
ON         t.BUS_DATE > = a1.TRD_DT_10
WHERE t.SRJE > = 2000000 ;



 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP6;
CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP6 as
SELECT t.CUST_NO,count(1) AS num
from 
(select CUST_NO,NET_TOT_AST,bus_date 
FROM  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
where bus_date > = 20180601
and   bus_date <= %d{yyyyMMdd}
AND NET_TOT_AST >= 2000000
) t
INNER JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP2 a1
ON         t.BUS_DATE > = a1.TRD_DT_30 
AND        t.BUS_DATE < = a1.TRD_DT_11
group by T.cust_no
having count(1) <= 3 ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP7;
CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP7 as
 SELECT distinct KHH FROM
 
 (SELECT KHH,CASE WHEN b.BZDM IS NOT NULL
                THEN a.SRJE*b.ZHHL
				ELSE a.SRJE
				END SRJE
		,a.BUS_DATE
FROM EDW_PROD.T_EDW_T05_TZJMXLS  a
LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH              b
ON             a.BZDM = b.BZDM
AND            b.BUS_DATE = a.BUS_DATE
WHERE (a.YWKM IN ('10399') OR SUBSTR(a.YWKM,1,3) in ('101')) AND a.BUS_DATE >= 20190101
AND a.BUS_DATE <= %d{yyyyMMdd}
) t
INNER JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP2 a1
ON         t.BUS_DATE > = a1.TRD_DT_10
WHERE t.SRJE > = 1500000 ;



 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP8;
CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP8 as
SELECT t.CUST_NO,count(1) AS num
from 
(select CUST_NO,NET_TOT_AST,bus_date 
FROM  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
where bus_date > = 20180601
and   bus_date <= %d{yyyyMMdd}
AND NET_TOT_AST >= 1500000
) t
INNER JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP2 a1
ON         t.BUS_DATE > = a1.TRD_DT_30 
AND        t.BUS_DATE < = a1.TRD_DT_11
group by T.cust_no
having count(1) <= 3 ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP9;
CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP9 as
 SELECT distinct KHH FROM
 
 (SELECT KHH,CASE WHEN b.BZDM IS NOT NULL
                THEN a.SRJE*b.ZHHL
				ELSE a.SRJE
				END SRJE
		,a.BUS_DATE
FROM EDW_PROD.T_EDW_T05_TZJMXLS  a
LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH              b
ON             a.BZDM = b.BZDM
AND            b.BUS_DATE = a.BUS_DATE
WHERE (a.YWKM IN ('10399') OR SUBSTR(a.YWKM,1,3) in ('101')) AND a.BUS_DATE >= 20190101
AND a.BUS_DATE <= %d{yyyyMMdd}
) t
INNER JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP2 a1
ON         t.BUS_DATE > = a1.TRD_DT_10
WHERE t.SRJE > = 1000000 ;



 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP10;
CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP10 as
SELECT t.CUST_NO,count(1) AS num
from 
(select CUST_NO,NET_TOT_AST,bus_date 
FROM  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
where bus_date > = 20180601
and   bus_date <= %d{yyyyMMdd}
AND NET_TOT_AST >= 1000000
) t
INNER JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP2 a1
ON         t.BUS_DATE > = a1.TRD_DT_30 
AND        t.BUS_DATE < = a1.TRD_DT_11
group by T.cust_no
having count(1) <= 3 ;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP11;
CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP11 as
SELECT SUM(t.NET_TOT_AST) as NET_TOT_AST 
      ,SUM(CASE WHEN t.BUS_DATE = a2.TRD_DT
	            AND  a2.TRD_DT = a2.NAT_DT
	            AND  SUBSTR(CAST(t.BUS_DATE as STRING),1,4) > = SUBSTR('%d{yyyyMMdd}',1,4)
				THEN t.TOT_PRFT
			    ELSE 0
			    END
		   ) as TOT_PRFT 
	 ,t.CUST_NO
FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY t
INNER JOIN (SELECT CUST_NO 
            FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO 
		    WHERE BUS_DATE = %d{yyyyMMdd}
			AND   CUST_STAT <> '3'
			AND    SUBSTR(CAST(OPNAC_DT as STRING),1,4) > = SUBSTR('%d{yyyyMMdd}',1,4)
			AND    CUST_NO < > '100610335855'
			AND    BRH_NO IN (SELECT BRH_NO FROM DDW_PROD.T_DDW_INR_ORG_BRH WHERE BUS_DATE = %d{yyyyMMdd}  )
           )  a1
ON         t.CUST_NO = a1.CUST_NO
INNER JOIN (SELECT TRD_DT,NAT_DT
            FROM EDW_PROD.T_EDW_T99_TRD_DATE 
            WHERE BUS_DATE = %d{yyyyMMdd}
		    AND   SUBSTR(CAST(NAT_DT as STRING),1,4)  = SUBSTR('%d{yyyyMMdd}',1,4)
			AND   TRD_DT < = %d{yyyyMMdd}
		   ) a2
ON  t.BUS_DATE = a2.TRD_DT
GROUP BY t.CUST_NO
UNION ALL
SELECT SUM(t.NET_TOT_AST) as NET_TOT_AST 
      ,SUM(CASE WHEN t.BUS_DATE = a2.TRD_DT
	            AND  a2.TRD_DT = a2.NAT_DT
				AND  SUBSTR(CAST(t.BUS_DATE as STRING),1,4) > = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4)
				THEN t.TOT_PRFT
			    ELSE 0
			    END
		   ) as TOT_PRFT 
	 ,t.CUST_NO
FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY t
INNER JOIN (SELECT CUST_NO 
            FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO 
		    WHERE BUS_DATE = %d{yyyyMMdd}
			AND   CUST_STAT <> '3'
			AND    SUBSTR(CAST(OPNAC_DT as STRING),1,4) < SUBSTR('%d{yyyyMMdd}',1,4)
			AND    CUST_NO < > '100610335855'
			AND    BRH_NO IN (SELECT BRH_NO FROM DDW_PROD.T_DDW_INR_ORG_BRH WHERE BUS_DATE = %d{yyyyMMdd}  )
           )  a1
ON         t.CUST_NO = a1.CUST_NO
INNER JOIN (SELECT TRD_DT,NAT_DT
            FROM EDW_PROD.T_EDW_T99_TRD_DATE 
            WHERE BUS_DATE = %d{yyyyMMdd}
		    AND   SUBSTR(CAST(NAT_DT as STRING),1,4)  = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4)

		   ) a2
ON  t.BUS_DATE = a2.TRD_DT
GROUP BY t.CUST_NO ;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP12;
CREATE TABLE DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP12 as
SELECT SUM(t.ORDI_TRD_VOL_RMB_80+t.CRD_TRD_VOL_80+WRNT_TRD_VOL) as TRD_VOL     
	 ,t.CUST_NO
FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY t
INNER JOIN (SELECT CUST_NO 
            FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO 
		    WHERE BUS_DATE = %d{yyyyMMdd}
			AND   CUST_STAT <> '3'
			AND    SUBSTR(CAST(OPNAC_DT as STRING),1,4) > = SUBSTR('%d{yyyyMMdd}',1,4)
			AND    CUST_NO < > '100610335855'
			AND    BRH_NO IN (SELECT BRH_NO FROM DDW_PROD.T_DDW_INR_ORG_BRH WHERE BUS_DATE = %d{yyyyMMdd}  )
           )  a1
ON         t.CUST_NO = a1.CUST_NO
WHERE SUBSTR(CAST(t.BUS_DATE as STRING),1,4)  = SUBSTR('%d{yyyyMMdd}',1,4)
GROUP BY t.CUST_NO
UNION ALL
SELECT SUM(t.ORDI_TRD_VOL_RMB_80+t.CRD_TRD_VOL_80+WRNT_TRD_VOL) as TRD_VOL     
	 ,t.CUST_NO
FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY t
INNER JOIN (SELECT CUST_NO 
            FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO 
		    WHERE BUS_DATE = %d{yyyyMMdd}
			AND   CUST_STAT <> '3'
			AND    SUBSTR(CAST(OPNAC_DT as STRING),1,4) < SUBSTR('%d{yyyyMMdd}',1,4)
			AND    CUST_NO < > '100610335855'
			AND    BRH_NO IN (SELECT BRH_NO FROM DDW_PROD.T_DDW_INR_ORG_BRH WHERE BUS_DATE = %d{yyyyMMdd}  )
           )  a1
ON         t.CUST_NO = a1.CUST_NO
WHERE SUBSTR(CAST(t.BUS_DATE as STRING),1,4)  = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4)
GROUP BY t.CUST_NO ;
-------------插入数据开始--------------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CIF_TKHZB1
(          ID	         --自增序号
          ,RQ	         --日期
          ,KHH	         --客户号
          ,ZBDM	         --指标代码
          ,ZBZ	         --指标值  
) 
 SELECT    ROW_NUMBER() OVER(ORDER BY KHH ) as ID	         --自增序号
          ,RQ	                 --日期
          ,KHH	                 --客户号
          ,ZBDM	                 --指标代码
          ,ROUND(ZBZ,4)	         --指标值  
              
 FROM    DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP1 
 WHERE KHH < > '099300000001' 
 union all
 SELECT    ROW_NUMBER() OVER(ORDER BY KHH ) as ID	         --自增序号
          ,%d{yyyyMMdd} as RQ	                 --日期
          ,t.cust_no	                 --客户号
          ,'KH_ZCBHZDGZ'	                 --指标代码
          ,CASE WHEN a1.KHH IS NOT NULL
                AND  a2.CUST_NO IS NOT NULL	
                THEN 1
                ELSE 0
                END 				--指标值  
              
 FROM    DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY  t
 LEFT JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP3 a1
  ON t.cust_no = a1.KHH
 LEFT JOIN  DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP4 a2
 ON t.cust_no = a2.CUST_NO
 WHERE t.CUST_NO < > '099300000001' 
 AND   t.BUS_DATE = %d{yyyyMMdd}
 union all
 SELECT    ROW_NUMBER() OVER(ORDER BY KHH ) as ID	         --自增序号
          ,%d{yyyyMMdd} as RQ	                 --日期
          ,t.cust_no	                 --客户号
          ,'GZHGTZZYD1'	                 --指标代码
          ,CASE WHEN a1.KHH IS NOT NULL
                AND  a2.CUST_NO IS NOT NULL	
                THEN 1
                ELSE 0
                END 				--指标值  
              
 FROM    DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY  t
 LEFT JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP5 a1
  ON t.cust_no = a1.KHH
 LEFT JOIN  DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP6 a2
 ON t.cust_no = a2.CUST_NO
 WHERE t.CUST_NO < > '099300000001' 
 AND   t.BUS_DATE = %d{yyyyMMdd}
 union all
 SELECT    ROW_NUMBER() OVER(ORDER BY KHH ) as ID	         --自增序号
          ,%d{yyyyMMdd} as RQ	                 --日期
          ,t.cust_no	                 --客户号
          ,'GZHGTZZYD2'	                 --指标代码
          ,CASE WHEN a1.KHH IS NOT NULL
                AND  a2.CUST_NO IS NOT NULL	
                THEN 1
                ELSE 0
                END 				--指标值  
              
 FROM    DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY  t
 LEFT JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP7 a1
  ON t.cust_no = a1.KHH
 LEFT JOIN  DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP8 a2
 ON t.cust_no = a2.CUST_NO
 WHERE t.CUST_NO < > '099300000001' 
 AND   t.BUS_DATE = %d{yyyyMMdd}
  union all
 SELECT    ROW_NUMBER() OVER(ORDER BY KHH ) as ID	         --自增序号
          ,%d{yyyyMMdd} as RQ	                 --日期
          ,t.cust_no	                 --客户号
          ,'GZHGTZZYD3'	                 --指标代码
          ,CASE WHEN a1.KHH IS NOT NULL
                AND  a2.CUST_NO IS NOT NULL	
                THEN 1
                ELSE 0
                END 				--指标值  
              
 FROM    DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY  t
 LEFT JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP9 a1
  ON t.cust_no = a1.KHH
 LEFT JOIN  DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP10 a2
 ON t.cust_no = a2.CUST_NO
 WHERE t.CUST_NO < > '099300000001' 
 AND   t.BUS_DATE = %d{yyyyMMdd}
 UNION ALL
 SELECT    ROW_NUMBER() OVER(ORDER BY t.CUST_NO ) as ID	         --自增序号
          ,%d{yyyyMMdd} as RQ	                 --日期
          ,t.cust_no	                 --客户号
          ,'XY_NHSYL'	                 --指标代码
          ,CASE WHEN t.NET_TOT_AST < = 0 
                THEN 0
                WHEN FLOOR(t.TOT_PRFT*36500/t.NET_TOT_AST)+100 >= 1300
                THEN 1300
                ELSE FLOOR(t.TOT_PRFT*36500/t.NET_TOT_AST)+100
                END 	AS ZBZ			--指标值  
              
 FROM    DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP11 t
 
 UNION ALL
 SELECT    ROW_NUMBER() OVER(ORDER BY t.CUST_NO ) as ID	         --自增序号
          ,%d{yyyyMMdd} as RQ	                 --日期
          ,t.cust_no	                 --客户号
          ,'XY_NHHSL'	                 --指标代码
          ,CASE WHEN t.NET_TOT_AST < = 0 
                THEN 0
                WHEN FLOOR(NVL(a1.TRD_VOL,0)*365/t.NET_TOT_AST) > 240
                THEN 240
                ELSE FLOOR(NVL(a1.TRD_VOL,0)*365/t.NET_TOT_AST)
                END 	AS ZBZ			--指标值  
              
 FROM    DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP11 t
 LEFT JOIN DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP12 a1
 ON        t.CUST_NO = a1.CUST_NO
 ;  
 
 
 
 
 
 
 
 
 
 

---
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP1; 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP2; 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP3; 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP4; 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP5; 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP6; 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP7; 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP8; 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP9; 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CIF_TKHZB_TEMP10; 

   

-------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_CIF_TKHZB1',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_CIF_TKHZB1 ;
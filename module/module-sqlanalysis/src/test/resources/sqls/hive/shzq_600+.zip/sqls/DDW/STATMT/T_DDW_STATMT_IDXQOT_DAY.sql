 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:指数行情表日表                                                                       */
  --/* 创建人:闫飞                                                                               */
  --/* 创建时间:2017-07-07                                                                        */ 
  --/* 修改时间:2018-08-24                                                                        */ 
  --/* 创建内容:增加从聚源的逻辑                                                                       */ 





--------------插入数据-------------
 INSERT 	OVERWRITE DDW_PROD.T_DDW_STATMT_IDXQOT_DAY
 (
                                   SEC_CD            --证券代码 
                                  ,EXG               --交易所 
                                  ,NEWST_PRC         --最新价 
                                  ,SEC_PRCCHG        --涨跌幅 
) 
 partition(bus_date= %d{yyyyMMdd})
 SELECT 
        NVL(T2.SEC_CD,T1.SEC_CD) AS SEC_CD                --证券代码
	   ,NVL(T2.EXG,T1.EXG) AS EXG                         --交易所
	   ,NVL(T2.NEWST_PRC,T1.NEWST_PRC) AS NEWST_PRC       --最新价
	   ,NVL(T2.SEC_PRCCHG,T1.SEC_PRCCHG) AS SEC_PRCCHG    --涨跌幅
 FROM 
 (
   SELECT 
           T.ZQDM	                  										as SEC_CD         		--证券代码 
           ,T.JYS                   										as EXG               	--交易所
           ,ROUND(CASE WHEN  T.ZXJ IS NOT NULL 
 					         THEN T.ZXJ
						     ELSE T.ZSP
						     END,4) 	      								as NEWST_PRC         	--最新价
			,ROUND(CASE WHEN NVL(T.ZXJ,0) =0 OR NVL(T.ZSP,0) = 0 
							THEN 0
						WHEN NVL(T.ZSP,0) > 0 
							THEN (T.ZXJ-T.ZSP)*1.00/T.ZSP
							ELSE 0 	
							END,4)											as SEC_PRCCHG			--涨跌幅
  FROM 		JZJYCX.datacenter_TZQHQ    T
  WHERE 		T.ZQDM='000000' 
AND         T.JYS IN ('SH','SZ') 
AND         T.DT = '%d{yyyyMMdd}'
) T1
FULL JOIN 
(
  SELECT     '000000' AS SEC_CD
           ,CASE WHEN INNERCODE = 1 THEN'SH' ELSE 'SZ' END AS EXG
           ,CAST(CLOSEPRICE AS DECIMAL(18,4)) AS NEWST_PRC
           ,CAST(CHANGEPCT / 100 AS DECIMAL(18,4)) AS SEC_PRCCHG
  FROM FUNDEXT.DBO_QT_INDEXQUOTE T1
  WHERE DT = '%d{yyyyMMdd}'
  AND INNERCODE IN( 1055,1)
) T2
ON T1.SEC_CD = T2.SEC_CD
AND T1.EXG = T2.EXG
;

-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_STATMT_IDXQOT_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_STATMT_IDXQOT_DAY;
 /* ***************************************** SQL Begin ***************************************** */
 /* 脚本功能:上证英才排位赛竞赛数据汇总表                                                         */
 /* 创建人:黄勇华                                                                                 */
 /* 创建时间:2018-05-14                                                                           */
 /* 修改时间:2018-07-12                                                                           */
 /* 创建内容:修改成每日跑本月及上月的数据，以修正客户成为有效户日期不再交易日的问题               */
----临时表1(数仓口径)
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR_TEMP1  ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR_TEMP1
 as 
 SELECT     t.KHH                          as CUST_NO
            ,NVL(a1.TOT_AST,0)*1.000000/10000   as TOT_AST
 FROM      NEWCRM.CRMII_TKHXX  t
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY a1
 ON        t.KHH = a1.CUST_NO
 AND       a1.BUS_DATE = %d{yyyyMMdd}
 WHERE     SUBSTR(CAST(t.YXQRRQ as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6);
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR_TEMP2  ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR_TEMP2
 as 
 SELECT     t.KHH                          as CUST_NO
            ,NVL(a1.FNL_TOT_AST,0)*1.000000/10000   as TOT_AST
 FROM      NEWCRM.CRMII_TKHXX  t
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON a1
 ON        t.KHH = a1.CUST_NO
 AND       a1.YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
 WHERE CAST(SUBSTR(CAST(T.YXQRRQ as STRING),1,6) AS INT) = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) AS INT)
 ;
----------CRM口径-----------
--
--
-- DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR_TEMP1;
-- CREATE TABLE DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR_TEMP1
--AS 
-- SELECT T.KHH AS CUST_NO
--       ,(NVL(A1.YMZZC,0)+NVL(A2.ZZC,0)+NVL(A3.QMZZC,0))*1.000000/10000  AS TOT_AST
-- FROM NEWCRM.CRMII_TKHXX T
-- LEFT JOIN NEWCRM.DSC_STAT_T_STAT_KHZC_Y A1
--        ON T.KHH = A1.KHH
--       AND A1.DT = SUBSTR('%d{yyyyMMdd}',1,6)
--LEFT JOIN NEWCRM.DSC_STAT_T_STAT_RZRQ_Y A2
--        ON T.KHH = A2.KHH
--       AND A2.DT = SUBSTR('%d{yyyyMMdd}',1,6)
--LEFT JOIN NEWCRM.DSC_STAT_T_STAT_GGQQ_Y A3
--        ON T.KHH = A3.KHH
--       AND A3.DT = SUBSTR('%d{yyyyMMdd}',1,6)	
-- WHERE SUBSTR(CAST(T.YXQRRQ as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6);
--
-- DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR_TEMP2;
-- CREATE TABLE DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR_TEMP2
--AS 
-- SELECT T.KHH AS CUST_NO
--      ,(NVL(A1.YMZZC,0)+NVL(A2.ZZC,0)+NVL(A3.QMZZC,0))*1.000000/10000  AS TOT_AST
-- FROM NEWCRM.CRMII_TKHXX T
-- LEFT JOIN NEWCRM.DSC_STAT_T_STAT_KHZC_Y A1
--        ON T.KHH = A1.KHH
--       AND A1.DT = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
--LEFT JOIN NEWCRM.DSC_STAT_T_STAT_RZRQ_Y A2
--        ON T.KHH = A2.KHH
--       AND A2.DT = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
--LEFT JOIN NEWCRM.DSC_STAT_T_STAT_GGQQ_Y A3
--        ON T.KHH = A3.KHH
--       AND A3.DT = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
-- WHERE CAST(SUBSTR(CAST(T.YXQRRQ as STRING),1,6) AS INT) = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) AS INT)
--;
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR
(
		   BRH_NO                     --营业部编号
          ,BRH_NAME                   --营业部名称
          ,BELTO_FILIL                --所属分公司
		  ,BELTO_FILIL_CDG	 	   	  --所属分公司编码
          ,PSN_NO                     --人员编码
          ,PSN_NAME                   --人员姓名
		  ,PSN_CGY                 	  --人员类别
          ,PROD_SALE_STD_AMT          --产品销售标准额 
          ,PROD_SALE_STD_AMT_SCO   	  --产品销售标准额得分
          ,ADDED_VLD_CUST_AST		  --新增有效客户资产
		  ,ADDED_VLD_CUST_AST_SCO	  --新增有效客户资产得分
		  ,ADDED_VLD_CUST		      --新增有效客户数
		  ,ADDED_VLD_CUST_SCO	      --新增有效客户数得分
		  ,ADDED_AGGR_SCO	          --增量类汇总得分
)		
 PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT 
		  NVL(a1.JJRYYB,a2.YYB)                as BRH_NO               --营业部编号
          ,a3.brh_shrtnm                        as BRH_NAME             --营业部名称
          ,a3.BELTO_FILIL                       as BELTO_FILIL          --所属分公司
		  ,a3.BELTO_FILIL_CDG					as BELTO_FILIL_CDG	 	--所属分公司编码
          ,t.PSN_NO                             as PSN_NO               --人员编码
          ,NVL(a1.JJRXM,a2.RYXM)                as PSN_NAME             --人员姓名
		  ,a6.PSN_CGY_NAME             			as PSN_CGY           	--人员类别
          ,SUM(ROUND(NVL(a4.PROD_SALE_STD_AMT,0),6))     as PROD_SALE_STD_AMT    --产品销售标准额 
          ,SUM(ROUND(NVL(a4.PROD_SALE_STD_AMT,0)*1.5,6)) as PROD_SALE_STD_AMT_SCO   	  --产品销售标准额得分
          ,SUM(ROUND(NVL(a5.TOT_AST,0),6))               as ADDED_VLD_CUST_AST		  --新增有效客户资产
		  ,SUM(ROUND(NVL(a5.TOT_AST,0)*1,6))	  --新增有效客户资产得分
		  ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		            THEN 1
				    ELSE 0
				    END)                             as ADDED_VLD_CUST		      --新增有效客户数
		  ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		            THEN 2
				    ELSE 0
				    END) 	      --新增有效客户数得分
		  ,SUM(ROUND(DECODE(a5.CUST_NO,NULL,0,2)+ NVL(a4.PROD_SALE_STD_AMT,0)*1.5+NVL(a5.TOT_AST,0)*1,6) )                 as ADDED_AGGR_SCO	          --增量类汇总得分
 FROM   (SELECT CUST_NO,BRK_NO as PSN_NO,BRK_CGY as PSN_CGY
         FROM DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN 
         
		 
		 WHERE %d{yyyyMMdd} > = STATS_DT 
           AND %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
	       AND BUS_DATE = %d{yyyyMMdd}
         --UNION ALL
         --SELECT CUST_NO,PSN_NO as PSN_NO,PSN_CGY
         --FROM DDW_PROD.T_DDW_F00_CUST_CUST_RLN
         --WHERE    %d{yyyyMMdd} > = STATS_DT 
         --AND      %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
         --AND      BUS_DATE = %d{yyyyMMdd}
         --AND       SVC_RLN_TP = '4'
		 ) t
 LEFT JOIN  EDW_PROD.T_EDW_T01_TJJR a1
 ON  		t.PSN_NO = a1.JJRBH
 AND  		a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  EDW_PROD.T_EDW_T01_TRYXX a2
 ON  		t.PSN_NO = a2.RYBH
 AND  		a2.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  DDW_PROD.T_DDW_INR_ORG_BRH              a3
 ON         NVL(a1.JJRYYB,a2.YYB)	 = a3.BRH_NO
 AND        a3.BUS_DATE =  %d{yyyyMMdd}
 LEFT JOIN DDW_PROD.V_PSN_CGY                     a6
 ON         t.PSN_CGY = a6.PSN_CGY 
 LEFT JOIN (SELECT PSN_NO
                  ,CUST_NO 
				  ,SUM(PROD_SALE_STD_AMT) as PROD_SALE_STD_AMT
            FROM  DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_PROD_SALE_STATS
			WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			GROUP BY PSN_NO,CUST_NO
			)                                a4
 ON       t.CUST_NO = a4.CUST_NO
 AND      t.PSN_NO = a4.PSN_NO
 LEFT JOIN DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR_TEMP1 a5
 ON        t.CUST_NO = a5.CUST_NO
 GROUP BY  BRH_NO      
           ,BRH_NAME    
           ,BELTO_FILIL 
		   ,BELTO_FILIL_CDG
           ,PSN_NO      
           ,PSN_NAME
		   ,PSN_CGY;
---- 插入上月数据
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR
(
		   BRH_NO                     --营业部编号
          ,BRH_NAME                   --营业部名称
          ,BELTO_FILIL                --所属分公司
		  ,BELTO_FILIL_CDG	 	   	  --所属分公司编码
          ,PSN_NO                     --人员编码
          ,PSN_NAME                   --人员姓名
		  ,PSN_CGY                 	  --人员类别
          ,PROD_SALE_STD_AMT          --产品销售标准额 
          ,PROD_SALE_STD_AMT_SCO   	  --产品销售标准额得分
          ,ADDED_VLD_CUST_AST		  --新增有效客户资产
		  ,ADDED_VLD_CUST_AST_SCO	  --新增有效客户资产得分
		  ,ADDED_VLD_CUST		      --新增有效客户数
		  ,ADDED_VLD_CUST_SCO	      --新增有效客户数得分
		  ,ADDED_AGGR_SCO	          --增量类汇总得分
)		
 PARTITION(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) AS INT) )
SELECT 
       NVL(A1.JJRYYB,A2.YYB) AS BRH_NO                                                                                         --营业部编号
      ,A3.BRH_SHRTNM AS BRH_NAME                                                                                               --营业部名称
      ,A3.BELTO_FILIL AS BELTO_FILIL                                                                                           --所属分公司
      ,A3.BELTO_FILIL_CDG AS BELTO_FILIL_CDG                                                                                   --所属分公司编码
      ,T.PSN_NO AS PSN_NO                                                                                                      --人员编码
      ,NVL(A1.JJRXM,A2.RYXM) AS PSN_NAME                                                                                       --人员姓名
      ,A6.PSN_CGY_NAME AS PSN_CGY                                                                                              --人员类别
      ,SUM(ROUND(NVL(A4.PROD_SALE_STD_AMT,0),6)) AS PROD_SALE_STD_AMT                                                          --产品销售标准额 
      ,SUM(ROUND(NVL(A4.PROD_SALE_STD_AMT,0)*1.5,6)) AS PROD_SALE_STD_AMT_SCO                                                  --产品销售标准额得分
      ,SUM(ROUND(NVL(A5.TOT_AST,0),6)) AS ADDED_VLD_CUST_AST                                                                   --新增有效客户资产
      ,SUM(ROUND(NVL(A5.TOT_AST,0)*1,6)) AS ADDED_VLD_CUST_AST_SCO                                                             --新增有效客户资产得分
      ,SUM(CASE WHEN A5.CUST_NO IS NOT NULL THEN 1 ELSE 0 END) AS ADDED_VLD_CUST                                               --新增有效客户数
      ,SUM(CASE WHEN A5.CUST_NO IS NOT NULL THEN 2 ELSE 0 END) AS ADDED_VLD_CUST_SCO                                           --新增有效客户数得分
      ,SUM(ROUND(DECODE(A5.CUST_NO,NULL,0,2)+ NVL(A4.PROD_SALE_STD_AMT,0)*1.5+NVL(A5.TOT_AST,0)*1,6) ) AS ADDED_AGGR_SCO       --增量类汇总得分
 FROM (SELECT CUST_NO,BRK_NO as PSN_NO,BRK_CGY as PSN_CGY 
         FROM DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN A
       INNER JOIN (SELECT MAX(TRD_DT) AS BUS_DATE
                     FROM  EDW_PROD.T_EDW_T99_TRD_DATE
                    WHERE BUS_DATE = %d{yyyyMMdd}
                      AND SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
                  ) B
               ON A.STATS_DT <= B.BUS_DATE 
		      AND B.BUS_DATE < NVL(a.EXPR_DT,99999999)
        WHERE A.BUS_DATE = %d{yyyyMMdd}
      ) T
 LEFT JOIN EDW_PROD.T_EDW_T01_TJJR A1
        ON T.PSN_NO = A1.JJRBH
       AND A1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN EDW_PROD.T_EDW_T01_TRYXX A2
        ON T.PSN_NO = A2.RYBH
       AND A2.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN DDW_PROD.T_DDW_INR_ORG_BRH A3
        ON NVL(A1.JJRYYB,A2.YYB) = A3.BRH_NO
       AND A3.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN DDW_PROD.V_PSN_CGY A6
        ON T.PSN_CGY = A6.PSN_CGY 
 LEFT JOIN (SELECT PSN_NO,CUST_NO ,SUM(PROD_SALE_STD_AMT) AS PROD_SALE_STD_AMT
              FROM DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_PROD_SALE_STATS
			 WHERE CAST(SUBSTR(CAST(BUS_DATE AS STRING),1,6) AS INT) = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) AS INT)
			GROUP BY PSN_NO,CUST_NO
		   ) A4
        ON T.CUST_NO = A4.CUST_NO
       AND T.PSN_NO = A4.PSN_NO
 LEFT JOIN DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR_TEMP2 A5
        ON T.CUST_NO = A5.CUST_NO
 GROUP BY BRH_NO ,BRH_NAME ,BELTO_FILIL ,BELTO_FILIL_CDG ,PSN_NO ,PSN_NAME ,PSN_CGY;
-------
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR_TEMP1;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR_TEMP2;
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_SH_TALENT_RANK_DATA_AGGR;
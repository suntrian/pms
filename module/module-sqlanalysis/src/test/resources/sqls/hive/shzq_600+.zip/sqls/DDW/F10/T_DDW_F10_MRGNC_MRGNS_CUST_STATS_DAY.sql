------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:融资融券客户统计日表                                                                */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

------信用市值临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP as
  SELECT     a.CUST_NO
           ,SUM(a.SEC_MKTVAL)                  as CRD_MKTVAL                   --信用市值
		   ,SUM(CASE WHEN b.JYS IS NOT NULL		            
					 THEN a.SEC_MKTVAL*b.ZSBL
					 ELSE 0
					 END
			   )                             as CASH_DEP_CRD_MKTVAL1          --可充抵保证金证券市值
		   ,SUM(CASE WHEN a.EXG = 'SH'
		             AND  SUBSTR(a.SEC_CGY,1,1) = 'A'
					 THEN a.SEC_MKTVAL
					 ELSE 0
					 END
			   )                             as CRD_MKTVAL_HA                --信用沪A市值
		    ,SUM(CASE WHEN a.EXG = 'SZ'
		             AND  SUBSTR(a.SEC_CGY,1,1) IN ('A','C')
					 THEN a.SEC_MKTVAL
					 ELSE 0
					 END
			   )                             as CRD_MKTVAL_SA                --信用深A市值
		     ,SUM(CASE WHEN a.EXG = 'SH'
		             AND  SUBSTR(a.SEC_CGY,1,1) = 'Z'
					 THEN a.SEC_MKTVAL
					 ELSE 0
					 END
			   )                             as CRD_MKTVAL_BOND_H            --信用沪债券市值
		    ,SUM(CASE WHEN a.EXG = 'SZ'
		             AND  SUBSTR(a.SEC_CGY,1,1) IN ('Z')
					 THEN a.SEC_MKTVAL
					 ELSE 0
					 END
			   )                             as CRD_MKTVAL_BOND_S            --信用深债券市值
		     ,SUM(CASE WHEN a.EXG = 'SH'
		             AND  SUBSTR(a.SEC_CGY,1,1) = 'J'
					 THEN a.SEC_MKTVAL
					 ELSE 0
					 END
			   )                             as CRD_MKTVAL_FND_H            --信用沪基金市值
		    ,SUM(CASE WHEN a.EXG = 'SZ'
		             AND  SUBSTR(a.SEC_CGY,1,1) IN ('J')
					 THEN a.SEC_MKTVAL
					 ELSE 0
					 END
			   )                             as CRD_MKTVAL_FND_S            --信用深基金市值
			,SUM(CASE WHEN a.EXG IN ('SZ','SZ')
		             AND  SUBSTR(a.SEC_CGY,1,1) NOT IN ('Z','A','C','J')
					 THEN a.SEC_MKTVAL
					 ELSE 0
					 END
			   )                             as CRD_MKTVAL_OTH            --信用深基金市值
			   
			 ,SUM(a.HLD_COST)                  as HLD_COST                  --持仓成本
 FROM  DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS  a
 left join rzrqCX.MARGIN_TXY_ZGZQ b
 ON     a.EXG = b.JYS
 AND    a.SEC_CD = b.ZQDM
 AND    b.DT =  '%d{yyyyMMdd}'
 AND    BITAND(CAST(b.ZQSX AS INT),4) = 4
 WHERE a.BUS_DATE = %d{yyyyMMdd}
 AND   a.SYS_SRC = '信用账户' 
 GROUP BY CUST_NO ;
 ----信用持仓成本
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP1 as
  SELECT  KHH          as CUST_NO
         ,SUM(CCCB)    as HLD_COST
  FROM   EDW_PROD.T_EDW_T02_TZQGL
  WHERE  BUS_DATE =  %d{yyyyMMdd}
  AND    XTBS = 'RZRQ'
  GROUP BY CUST_NO  ;
  --担保比例,可用保证金
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP2 ;
  CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP2 as
  SELECT  KHH          as CUST_NO
         ,SUM(DBBL)    as GNT_RTO                      --担保比例
		 ,SUM(KYBZJ)   as AVL_BOND                     --可用保证金
		 ,SUM(RZED)    as MRGNC_CRD_QUO                --融资授信额度
		 ,SUM(RQED)    as MRGNS_CRD_QUO                --融券授信额度
		 ,SUM(RZJE)    as MRGNC_INL_GL                 --融资初始负债
		 ,SUM(RQJE)    as MRGNS_INL_GL                 --融券初始负债
  FROM   EDW_PROD.T_EDW_T02_TXY_HTXXLS
  WHERE  BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO ;
    --信用负债
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP3 ;
  CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP3 as
  SELECT  CUST_NO          as CUST_NO
         ,SUM(CRD_ACCT_UN_GL_PRINP+CRD_ACCT_UN_PAY_GL_INT)    as CRD_GL                       --信用负债
		 ,SUM(DECODE(TRD_CGY,61,CRD_ACCT_UN_GL_PRINP+CRD_ACCT_UN_PAY_GL_INT,0))   as MRGNC_GL                     --融资负债
		 ,SUM(DECODE(TRD_CGY,64,CRD_ACCT_UN_GL_PRINP+CRD_ACCT_UN_PAY_GL_INT,0))   as MRGNS_GL                     --融券负债
         ,SUM(CASE WHEN EXG = 'SH' AND SEC_CGY LIKE 'A%'
		           THEN CRD_ACCT_UN_GL_PRINP+CRD_ACCT_UN_PAY_GL_INT
			       ELSE 0
			       END
			 )                                                                as CRD_GL_HA --沪A信用负债
		 ,SUM(CASE WHEN EXG = 'SZ' AND SUBSTR(SEC_CGY,1,1) IN ('A','C')
		           THEN CRD_ACCT_UN_GL_PRINP+CRD_ACCT_UN_PAY_GL_INT
			       ELSE 0
			       END
			 )                                                 as CRD_GL_SA                    --深A信用负债
			   
		,SUM(CRD_ACCT_ADDED_GL_INT)     as TDY_ADDED_CRD_INT            --当日新增信用利息
		,SUM(DECODE(TRD_CGY,61,CRD_ACCT_ADDED_GL_INT,0)) as TDY_ADDED_MRGNC_INT          --当日新增融资利息
		,SUM(DECODE(TRD_CGY,64,CRD_ACCT_ADDED_GL_INT,0)) as TDY_ADDED_MRGNS_INT          --当日新增融券利息
  FROM   DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS
  WHERE  BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO ;
  
  
  ---信用负债
    DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP4 ;
    CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP4 as
	SELECT   a.KHH     as CUST_NO	
             ,SUM(CASE WHEN b.JYS IS NOT NULL 
			          THEN (a.RZJE-(a.HKJE-a.GHLX))*b.ZSBL
					  ELSE 0
					  END
			    )	     as CASH_DEP_CRD_MKTVAL2          --可充抵保证金证券市值
			,SUM(CASE WHEN a.FZZT < > 3 
			          THEN a.DRGHLX
					  ELSE 0
					  END
			    )	     as TDY_RTN_INT                  --当日归还利息
			,SUM(a.GHLX)	         as RTN_INT                      --归还利息
            ,SUM(CASE WHEN a.FZZT < > 3 
			          THEN a.YJLX+a.FDLX+a.FXYJLX
					  ELSE 0
					  END) as PRDCT_INT                    --预计利息
			,SUM(CASE WHEN FZZT < > 3 
			          AND  JYLB = 61
			          THEN a.YJLX+a.FDLX+a.FXYJLX
					  ELSE 0
					  END) as MRGNC_PRDCT_INT              --融资预计利息
			,SUM(CASE WHEN a.FZZT < > 3 
			          AND  a.JYLB = 64
			          THEN a.YJLX+a.FDLX+a.FXYJLX
					  ELSE 0
					  END) as MRGNS_PRDCT_INT              --融券预计利息
		    ,SUM(a.HKJE)             as REP_AMT                      --还款金额
			,SUM(a.HQSL)             as REP_QTY                      --还券数量
	FROM     EDW_PROD.T_EDW_T05_TXY_FZXXLS a
	left join RZRQCX.MARGIN_TXY_ZGZQ  b
    ON     a.JYS = b.JYS
    AND    a.ZQDM = b.ZQDM
    AND    b.dt =  '%d{yyyyMMdd}'
    AND    BITAND(CAST(b.ZQSX AS INT),4) = 4
	AND    a.JYLB = 61
	WHERE    a.BUS_DATE = %d{yyyyMMdd}
	--AND      FZZT < > 3
    GROUP BY CUST_NO ;


	
	
---信用交割明细
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP6 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP6 as 
 SELECT   KHH     as CUST_NO
          ,SUM(CASE WHEN WTLB = 61
		            THEN CJJE
			        ELSE 0 
			        END)      as MRGNC_TRD_VOL                --融资买入交易量   WTLB = 61
          ,SUM(CASE WHEN WTLB = 64
		            THEN CJJE
			        ELSE 0 
			        END)      as MRGNS_TRD_VOL                --融券卖出交易量   WTLB = 64
		  
		 ,SUM(CASE WHEN WTLB = 62
		            THEN CJJE
			        ELSE 0 
			        END)      as SELL_TCK_PAY_TCK_TRD_VOL     --卖券还券交易量   WTLB = 62
          ,SUM(CASE WHEN WTLB = 63
		            THEN CJJE
			        ELSE 0 
			        END)      as BUY_TCK_PAY_TCK_TRD_VOL                --买券还券交易量   WTLB = 63
		 ,SUM(CASE WHEN WTLB = 71
		            THEN CJJE
			        ELSE 0 
			        END)      as MRGNC_COE_CP_TRD_VOL     --融资强平交易量   WTLB = 71
          ,SUM(CASE WHEN WTLB = 72
		            THEN CJJE
			        ELSE 0 
			        END)      as MRGNS_COE_CP_TRD_VOL               --融券强平交易量   WTLB = 72
		
	   
	      ,SUM(CASE WHEN WTLB = 61 
		            AND  SUBSTR(ZQLB,1,1) IN ('A','C')
					AND  JYS = 'SZ'
					THEN S1+S3-S11-S12-S13
					WHEN WTLB = 61
		            THEN s1-s11-s12
			        ELSE 0 
			        END)      as MRGNC_NET_S1                --融资买入净佣金   WTLB = 61
          ,SUM(CASE WHEN WTLB = 64 
		            AND  SUBSTR(ZQLB,1,1) IN ('A','C')
					AND  JYS = 'SZ'
					THEN S1+S3-S11-S12-S13
					WHEN WTLB = 64
		            THEN s1-s11-s12
			        ELSE 0  
			        END)      as MRGNS_NET_S1                --融券卖出净佣金   WTLB = 64
		  
		 ,SUM(CASE  WHEN WTLB = 62 
		            AND  SUBSTR(ZQLB,1,1) IN ('A','C')
					AND  JYS = 'SZ'
					THEN S1+S3-S11-S12-S13
					WHEN WTLB = 62
		            THEN s1-s11-s12
			        ELSE 0 
			        END)      as SELL_TCK_PAY_TCK_NET_S1     --卖券还券净佣金   WTLB = 62
          ,SUM(CASE WHEN WTLB = 63 
		            AND  SUBSTR(ZQLB,1,1) IN ('A','C')
					AND  JYS = 'SZ'
					THEN S1+S3-S11-S12-S13
					WHEN WTLB = 63
		            THEN s1-s11-s12
			        ELSE 0
			        END)      as BUY_TCK_PAY_TCK_NET_S1                --买券还券净佣金   WTLB = 63
		 ,SUM(CASE WHEN WTLB = 71 
		            AND  SUBSTR(ZQLB,1,1) IN ('A','C')
					AND  JYS = 'SZ'
					THEN S1+S3-S11-S12-S13
					WHEN WTLB = 71
		            THEN s1-s11-s12
			        ELSE 0 
			        END)      as MRGNC_COE_CP_NET_S1     --融资强平净佣金  WTLB = 71
          ,SUM(CASE WHEN WTLB = 72 
		            AND  SUBSTR(ZQLB,1,1) IN ('A','C')
					AND  JYS = 'SZ'
					THEN S1+S3-S11-S12-S13
					WHEN WTLB = 72
		            THEN s1-s11-s12
			        ELSE 0 
			        END)      as MRGNS_COE_CP_NET_S1               --融券强平净佣金   WTLB = 72
					
					
          ,SUM(CASE  WHEN WTLB IN (1,2,61,62,63,64,71,72,80)
		            THEN CJJE
			        ELSE 0 
			        END)     as TRD_VOL                      --交易量
          ,SUM(CASE  WHEN WTLB IN (1,2,80)
		             THEN CJJE
			         ELSE 0 
			         END)    as TRD_VOL_ORDI                 --交易量(普通) WTLB IN (1,2)
         ,SUM(CASE  WHEN WTLB IN (61,62,63,64,71,72)
		            THEN CJJE
			        ELSE 0 
			        END)    as TRD_VOL_CRD                  --交易量(信用) WTLB IN (61,62,63,64,71,72)
         ,SUM(CASE  WHEN WTLB IN (1,80)
		            THEN CJJE
			        ELSE 0 
			        END)  as BUYIN_TRD_VOL_ORDI           --买入交易量(普通) WTLB IN (1,2)
         ,SUM(CASE  WHEN WTLB IN (61,63)
		            THEN CJJE
			        ELSE 0 
			        END)  as BUYIN_TRD_VOL_CRD            --买入交易量(信用) WTLB IN (61,62,63,64,71,72)
         ,SUM(CASE  WHEN WTLB IN (2)
		            THEN CJJE
			        ELSE 0 
			        END) as SELL_TRD_VOL_ORDI            --卖出交易量(普通) WTLB IN (1,2)
         ,SUM(CASE  WHEN WTLB IN (62,64,71,72)
		            THEN CJJE
			        ELSE 0 
			        END) as SELL_TRD_VOL_CRD             --卖出交易量(信用) WTLB IN (61,62,63,64,71,72)

        ,SUM(CASE  WHEN WTLB IN (1,2,61,62,63,64,71,72)
		            THEN S1
			        ELSE 0 
			        END)        as S1                           --毛佣金
		,SUM(CASE  WHEN WTLB IN (1,2)
		            THEN S1
			        ELSE 0 
			        END)        as ORDI_TRD_S1                  --普通交易毛佣金
		,SUM(CASE  WHEN WTLB IN (61,62,63,64,71,72)
		            THEN S1
			        ELSE 0 
			        END)        as CRD_TRD_S1                   --信用交易毛佣金
		,SUM(CASE  WHEN WTLB IN (1,2,61,62,63,64,71,72)
		            AND JYS  = 'SZ'
					AND SUBSTR(ZQLB,1,1) IN ('A','C')
					THEN S1+S3-S11-S12-S13
					WHEN WTLB IN (1,2,61,62,63,64,71,72)
					THEN S1-S11-S12
			        ELSE 0 
			        END)        as NET_S1                       --净佣金
		,SUM(CASE   WHEN WTLB IN (1,2)
		            AND JYS  = 'SZ'
					AND SUBSTR(ZQLB,1,1) IN ('A','C')
					THEN S1+S3-S11-S12-S13
					WHEN WTLB IN (1,2)
					THEN S1-S11-S12
			        ELSE 0  
			        END)        as ORDI_TRD_NET_S1              --普通交易净佣金
		,SUM(CASE  WHEN WTLB IN (61,62,63,64,71,72)
		            AND JYS  = 'SZ'
					AND SUBSTR(ZQLB,1,1) IN ('A','C')
					THEN S1+S3-S11-S12-S13
					WHEN WTLB IN (61,62,63,64,71,72)
					THEN S1-S11-S12
			        ELSE 0 
			        END)        as CRD_TRD_NET_S1               --信用交易净佣金
        ,SUM(CASE  WHEN WTLB IN (1,2,61,62,63,64,71,72,80)
		            THEN 1
			        ELSE 0 
			        END) as MTCH_ITMS                    --成交笔数
		,SUM(CASE  WHEN WTLB IN (61)
		            THEN 1
			        ELSE 0 
			        END) as MRGNC_MTCH_ITMS              --融资成交笔数
		,SUM(CASE  WHEN WTLB IN (64)
		            THEN 1
			        ELSE 0 
			        END) as MRGNS_MTCH_ITMS              --融券成交笔数
		,SUM(CASE  WHEN WTLB IN (71,72)
		            THEN 1
			        ELSE 0 
			        END)			as CP_TMS                       --平仓次数 WTLB IN (71,72)
	   ,SUM(CASE WHEN  WTLB = 61
				 THEN s1+s2+s3+s4+s5+s6
				 ELSE 0
				 END
				 )    as MRGNC_FEE                    --融资费用
	 ,SUM(CASE WHEN  WTLB = 64
			   THEN s1+s2+s3+s4+s5+s6
			   ELSE 0
			   END
		  )    as MRGNS_FEE                    --融券费用	
	,SUM(CASE WHEN  WTLB = 61
			   THEN CJJE+s1+s2+s3+s4+s5+s6
			   WHEN  WTLB = 64
			   THEN CJJE
			   ELSE 0
			   END
				 )	   as TDY_MRGNC_MRGNS_AMT          --当日融资融券金额
		  
	 ,SUM(CASE WHEN  WTLB = 61
			   THEN CJJE+s1+s2+s3+s4+s5+s6
			   ELSE 0
			   END
				 )     as TDY_MRGNC_AMT                --当日融资金额
		 ,SUM(CASE WHEN  WTLB = 64
				   THEN CJJE
				   ELSE 0
				   END
			 )   as TDY_MRGNS_AMT                   --当日融券金额
 FROM EDW_PROD.T_EDW_T05_TJGMXLS
 WHERE XTBS = 'RZRQ'
 AND   BUS_DATE =  %d{yyyyMMdd}
 AND   WTLB IN (1,2,61,62,63,64,71,72,80)
 GROUP BY CUST_NO
 ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP7 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP7 as
 SELECT     CUST_NO
           ,SUM(SEC_MKTVAL)                  as CRD_NET_AST_Y                  --信用市值
 FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS a
 WHERE   EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
	             WHERE  c.BUS_DATE = %d{yyyyMMdd}
				 AND    c.TRD_DT = %d{yyyyMMdd}
				 AND    a.BUS_DATE = c.LST_TRD_D
	             )
 AND   SYS_SRC = '信用账户'
 GROUP BY CUST_NO
 UNION ALL 
   SELECT  CUST_NO          as CUST_NO
         ,SUM(-CRD_ACCT_UN_GL_PRINP-CRD_ACCT_UN_PAY_GL_INT)    as CRD_NET_AST_Y                       --信用负债		 
  FROM   DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS a 
  WHERE   EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
	             WHERE  c.BUS_DATE = %d{yyyyMMdd}
				 AND    c.TRD_DT = %d{yyyyMMdd}
				 AND    a.BUS_DATE = c.LST_TRD_D
	             )
  GROUP BY CUST_NO
  UNION ALL
  SELECT CUST_NO
         ,SUM(ACCNT_BAL)  as CRD_NET_AST_Y		 
 FROM  DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS a
 WHERE SYS_SRC = '信用账户'
 AND   EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
	             WHERE  c.BUS_DATE = %d{yyyyMMdd}
				 AND    c.TRD_DT = %d{yyyyMMdd}
				 AND    a.BUS_DATE = c.LST_TRD_D
	             )
 GROUP BY CUST_NO ;
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP8 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP8 as
 SELECT a.KHH as CUST_NO
        ,COUNT(1) as NUM
 FROM EDW_PROD.T_EDW_T05_TJGMXLS  a
 WHERE a.XTBS = 'RZRQ'
 AND   a.BUS_DATE =  %d{yyyyMMdd}
 AND   a.WTLB IN (71,72)
 AND  EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T05_TXY_FZXXLS b
             WHERE a.KHH = b.KHH 
			 AND   a.CJRQ = b.RQ 
			 AND   b.FZZT = 3
			 AND   NVL(b.BDRQ,0) > NVL(b.DQRQ,0)			
			 )
 GROUP BY CUST_NO ;


INSERT OVERWRITE DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY
(        CUST_NO                      --客户号                 
        ,BRH_NO                       --营业部编号                         
        ,CUST_CGY			          --客户类别
        ,CRD_LVL                      --信用等级
        ,CRD_AST                      --信用总资产
		,CRD_NET_AST                  --信用净资产
		,CRD_CPTL                     --信用资金余额
		,CRD_UNPY_CPTL                --信用在途资金余额
		,CRD_MKTVAL                   --信用市值
		,CRD_MKTVAL_HA                --信用沪A市值
		,CRD_MKTVAL_SA                --信用深A市值
		,CRD_MKTVAL_BOND_H            --信用沪债券市值
		,CRD_MKTVAL_BOND_S            --信用深债券市值
		,CRD_MKTVAL_FND_H             --信用沪场内基金市值
		,CRD_MKTVAL_FND_S             --信用深场内基金市值
		,CRD_MKTVAL_OTH               --信用其他市值
		,CRD_HLD_COST                 --信用持仓成本
		,CRD_GL                       --信用负债
		,MRGNC_GL                     --融资负债
		,MRGNS_GL                     --融券负债
		,MRGNC_INL_GL                 --融资初始负债
		,MRGNS_INL_GL                 --融券初始负债
		,CRD_GL_HA                    --沪A信用负债
		,CRD_GL_SA                    --深A信用负债
		,MRGNC_FEE                    --融资费用
		,MRGNS_FEE                    --融券费用
		,TDY_MRGNC_MRGNS_AMT          --当日融资融券金额
		,TDY_MRGNC_AMT                --当日融资金额
		,TDY_MRGNS_AMT                --当日融券金额
		,MRGNC_CRD_QUO                --融资授信额度
		,MRGNS_CRD_QUO                --融券授信额度
		,MRGNC_TRD_VOL                --融资交易量   WTLB = 61
		,MRGNS_TRD_VOL                --融券交易量   WTLB = 64
		,TRD_VOL                      --交易量
		,TRD_VOL_ORDI                 --交易量(普通) WTLB IN (1,2)
		,TRD_VOL_CRD                  --交易量(信用) WTLB IN (61,62,63,64,71,72)
		,BUYIN_TRD_VOL_ORDI           --买入交易量(普通) WTLB IN (1,2)
		,BUYIN_TRD_VOL_CRD            --买入交易量(信用) WTLB IN (61,62,63,64,71,72)
		,SELL_TRD_VOL_ORDI            --卖出交易量(普通) WTLB IN (1,2)
		,SELL_TRD_VOL_CRD             --卖出交易量(信用) WTLB IN (61,62,63,64,71,72)
		,S1                           --毛佣金
		,ORDI_TRD_S1                  --普通交易毛佣金
		,CRD_TRD_S1                   --信用交易毛佣金
		,NET_S1                       --净佣金
		,ORDI_TRD_NET_S1              --普通交易净佣金
		,CRD_TRD_NET_S1               --信用交易净佣金
		,MTCH_ITMS                    --成交笔数
		,MRGNC_MTCH_ITMS              --融资成交笔数
		,MRGNS_MTCH_ITMS              --融券成交笔数		
		,TDY_RTN_INT                  --当日归还利息
		,RTN_INT                      --归还利息
		,REP_AMT                      --还款金额
		,REP_QTY                      --还券数量
		,PRDCT_INT                    --预计利息
		,MRGNC_PRDCT_INT              --融资预计利息
		,MRGNS_PRDCT_INT              --融券预计利息
		,TDY_ADDED_CRD_INT            --当日新增信用利息
		,TDY_ADDED_MRGNC_INT          --当日新增融资利息
		,TDY_ADDED_MRGNS_INT          --当日新增融券利息
		,CP_TMS                       --平仓次数 WTLB IN (71,72)
		,ADD_BOND_TMS                 --追保次数 
		,CRD_TFR_IN_AMT               --信用转入资金
		,CRD_TURN_OUT_AMT             --信用转出资金
		,CRD_TFR_IN_MKTVAL            --信用转入市值
		,CRD_TURN_OUT_MKTVAL          --信用转出市值
		,HLD_COST                     --持仓成本
		,GNT_RTO                      --担保比例
		,AVL_BOND                     --可用保证金
		,CASH_DEP_CRD_MKTVAL          --可充抵保证金证券市值
		,OVDU_TMS                     --逾期次数
		,CRD_PRFT                     --信用盈亏
		,SELL_TCK_PAY_TCK_TRD_VOL      --卖券还券交易量   WTLB = 62
        ,BUY_TCK_PAY_TCK_TRD_VOL       --买券还券交易量   WTLB = 63
        ,MRGNC_COE_CP_TRD_VOL          --融资强平交易量   WTLB = 71
        ,MRGNS_COE_CP_TRD_VOL          --融券强平交易量   WTLB = 72
        ,MRGNC_NET_S1                  --融资买入净佣金   WTLB = 61
        ,MRGNS_NET_S1                  --融券卖出净佣金   WTLB = 64
        ,SELL_TCK_PAY_TCK_NET_S1       --卖券还券净佣金   WTLB = 62
        ,BUY_TCK_PAY_TCK_NET_S1        --买券还券净佣金   WTLB = 63
        ,MRGNC_COE_CP_NET_S1           --融资强平净佣金  WTLB = 71
        ,MRGNS_COE_CP_NET_S1           --融券强平净佣金   WTLB = 72
)PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT               
          t.CUST_NO                      --客户号                 
          ,t.BRH_NO                     --营业部编号                         
          ,t.CUST_CGY			         --客户类别
          ,a1.XYDJ                     --信用等级
        ,NVL(a7.CRD_CPTL,0)+NVL(a8.CRD_MKTVAL,0)+NVL(a7.CRD_UNPY_CPTL,0)    --信用总资产
		,NVL(a7.CRD_CPTL,0)+NVL(a8.CRD_MKTVAL,0)-NVL(a9.CRD_GL,0)+NVL(a7.CRD_UNPY_CPTL,0)     --信用净资产
		,NVL(a7.CRD_CPTL,0)                      --信用资金余额
		,NVL(a7.CRD_UNPY_CPTL,0)                 --信用在途资金余额
		,NVL(a8.CRD_MKTVAL,0)                    --信用市值
		,NVL(a8.CRD_MKTVAL_HA,0)                 --信用沪A市值
		,NVL(a8.CRD_MKTVAL_SA,0)                 --信用深A市值
		,NVL(a8.CRD_MKTVAL_BOND_H,0)             --信用沪债券市值
		,NVL(a8.CRD_MKTVAL_BOND_S,0)             --信用深债券市值
		,NVL(a8.CRD_MKTVAL_FND_H,0)              --信用沪场内基金市值
		,NVL(a8.CRD_MKTVAL_FND_S,0)              --信用深场内基金市值
		,NVL(a8.CRD_MKTVAL_OTH,0)                --信用其他市值
		,NVL(a8.HLD_COST,0)                      --信用持仓成本
		,NVL(a9.CRD_GL,0)                        --信用负债
		,NVL(a9.MRGNC_GL,0)                      --融资负债
		,NVL(a9.MRGNS_GL,0)                      --融券负债
		,NVL(a6.MRGNC_INL_GL,0)                  --融资初始负债
		,NVL(a6.MRGNS_INL_GL,0)                  --融券初始负债
		,NVL(a9.CRD_GL_HA,0)                     --沪A信用负债
		,NVL(a9.CRD_GL_SA,0)                     --深A信用负债
		,NVL(a11.MRGNC_FEE,0)                    --融资费用
		,NVL(a11.MRGNS_FEE,0)                    --融券费用
		,NVL(a11.TDY_MRGNC_MRGNS_AMT,0)        --当日融资融券金额
		,NVL(a11.TDY_MRGNC_AMT,0)              --当日融资金额
		,NVL(a11.TDY_MRGNS_AMT,0)              --当日融券金额
		,NVL(a6.MRGNC_CRD_QUO,0)                 --融资授信额度
		,NVL(a6.MRGNS_CRD_QUO,0)                 --融券授信额度
		,NVL(a11.MRGNC_TRD_VOL,0)                --融资交易量   WTLB = 61
		,NVL(a11.MRGNS_TRD_VOL,0)                --融券交易量   WTLB = 64
		,NVL(a11.TRD_VOL,0)                      --交易量
		,NVL(a11.TRD_VOL_ORDI,0)                 --交易量(普通) WTLB IN (1,2)
		,NVL(a11.TRD_VOL_CRD,0)                  --交易量(信用) WTLB IN (61,62,63,64,71,72)
		,NVL(a11.BUYIN_TRD_VOL_ORDI,0)           --买入交易量(普通) WTLB IN (1,2)
		,NVL(a11.BUYIN_TRD_VOL_CRD,0)            --买入交易量(信用) WTLB IN (61,62,63,64,71,72)
		,NVL(a11.SELL_TRD_VOL_ORDI,0)            --卖出交易量(普通) WTLB IN (1,2)
		,NVL(a11.SELL_TRD_VOL_CRD,0)             --卖出交易量(信用) WTLB IN (61,62,63,64,71,72)
		,NVL(a11.S1,0)                           --毛佣金
		,NVL(a11.ORDI_TRD_S1,0)                  --普通交易毛佣金
		,NVL(a11.CRD_TRD_S1,0)                   --信用交易毛佣金
		,NVL(a11.NET_S1,0)                       --净佣金
		,NVL(a11.ORDI_TRD_NET_S1,0)              --普通交易净佣金
		,NVL(a11.CRD_TRD_NET_S1,0)               --信用交易净佣金
		,NVL(a11.MTCH_ITMS,0)                    --成交笔数
		,NVL(a11.MRGNC_MTCH_ITMS,0)              --融资成交笔数
		,NVL(a11.MRGNS_MTCH_ITMS,0)              --融券成交笔数	
		,NVL(a10.TDY_RTN_INT,0)                  --当日归还利息
		,NVL(a10.RTN_INT,0)                    --归还利息
		,NVL(a10.REP_AMT,0)                     --还款金额
		,NVL(a10.REP_QTY,0)                     --还券数量
		,NVL(a10.PRDCT_INT,0)                    --预计利息
		,NVL(a10.MRGNC_PRDCT_INT,0)              --融资预计利息
		,NVL(a10.MRGNS_PRDCT_INT,0)              --融券预计利息
		,NVL(a9.TDY_ADDED_CRD_INT,0)             --当日新增信用利息
		,NVL(a9.TDY_ADDED_MRGNC_INT,0)           --当日新增融资利息
		,NVL(a9.TDY_ADDED_MRGNS_INT,0)           --当日新增融券利息
		,NVL(a11.CP_TMS,0)                       --平仓次数 WTLB IN (71,72)
		,NVL(a2.ADD_BOND_TMS,0)                  --追保次数 
		,NVL(a3.CRD_TFR_IN_AMT,0)                --信用转入资金
		,NVL(a3.CRD_TURN_OUT_AMT,0)              --信用转出资金
		,NVl(a4.CRD_TFR_IN_MKTVAL,0)             --信用转入市值
		,NVl(a4.CRD_TURN_OUT_MKTVAL,0)           --信用转出市值
		,NVL(a5.HLD_COST,0)                      --持仓成本
		,NVL(a6.GNT_RTO,0)                       --担保比例
		--,nvl(a8.CASH_DEP_CRD_MKTVAL1,0)-nvl(a10.CASH_DEP_CRD_MKTVAL2,0)    as CASH_DEP_CRD_MKTVAL          --可充抵保证金证券市值
		,NVL(a6.AVL_BOND,0)                      --可用保证金
		,CAST(nvl(a8.CASH_DEP_CRD_MKTVAL1,0)-nvl(a10.CASH_DEP_CRD_MKTVAL2,0) as DECIMAL(38,2))    as CASH_DEP_CRD_MKTVAL          --可充抵保证金证券市值
		,NVL(a13.NUM,0)
		,NVL(a7.CRD_CPTL,0)+NVL(a8.CRD_MKTVAL,0)-NVL(a9.CRD_GL,0)-NVL(a12.CRD_NET_AST_Y,0)+NVl(a4.CRD_TURN_OUT_MKTVAL,0)+NVL(a3.CRD_TURN_OUT_AMT,0)-NVL(a3.CRD_TFR_IN_AMT,0)- NVl(a4.CRD_TFR_IN_MKTVAL,0)                   
		,NVL(a11.SELL_TCK_PAY_TCK_TRD_VOL,0)      --卖券还券交易量   WTLB = 62
        ,NVL(a11.BUY_TCK_PAY_TCK_TRD_VOL,0)       --买券还券交易量   WTLB = 63
        ,NVL(a11.MRGNC_COE_CP_TRD_VOL,0)          --融资强平交易量   WTLB = 71
        ,NVL(a11.MRGNS_COE_CP_TRD_VOL,0)          --融券强平交易量   WTLB = 72
        ,NVL(a11.MRGNC_NET_S1,0)                  --融资买入净佣金   WTLB = 61
        ,NVL(a11.MRGNS_NET_S1,0)                  --融券卖出净佣金   WTLB = 64
        ,NVL(a11.SELL_TCK_PAY_TCK_NET_S1,0)       --卖券还券净佣金   WTLB = 62
        ,NVL(a11.BUY_TCK_PAY_TCK_NET_S1,0)        --买券还券净佣金   WTLB = 63
        ,NVL(a11.MRGNC_COE_CP_NET_S1,0)           --融资强平净佣金  WTLB = 71
        ,NVL(a11.MRGNS_COE_CP_NET_S1,0)           --融券强平净佣金   WTLB = 72
FROM (SELECT  a.CUST_NO
             ,a.BRH_NO
			 ,a.CUST_CGY
	  FROM    DDW_PROD.T_DDW_F00_CUST_CUST_INFO a
	  INNER  JOIN (SELECT KHH FROM EDW_PROD.T_EDW_T02_TZJZH
	               WHERE BUS_DATE = %d{yyyyMMdd}
				   AND KHRQ IS NOT NULL
				   AND KHRQ < = %d{yyyyMMdd}
				   AND XTBS = 'RZRQ'
				   AND (ZJZHZT < > '3'
	                   OR      XHRQ > %d{yyyyMMdd})
	                AND     SUBSTR(KHH,1,4) < > '9999'
				   GROUP BY KHH
				   )   b
	  ON       a.CUST_NO = b.KHH
	  WHERE   a.BUS_DATE = %d{yyyyMMdd}	 
      )               t
LEFT JOIN RZRQCX.MARGIN_TXY_KHXX a1
ON        t.CUST_NO = a1.KHH
AND       a1.DT = '%d{yyyyMMdd}'
LEFT JOIN (SELECT KHH as CUST_NO
                 ,COUNT(1) as ADD_BOND_TMS
           FROM RZRQCX.MARGIN_TXY_ZLXX
		   WHERE DT = '%d{yyyyMMdd}'
		   AND JSRQ = %d{yyyyMMdd}
		   GROUP BY CUST_NO
		   )                                 a2
ON         t.CUST_NO = a2.CUST_NO 
LEFT JOIN (SELECT CUST_NO
                  ,SUM(CASE WHEN (BIZ_SBJ LIKE '101%' OR BIZ_SBJ = '10399')
				             THEN INCM_AMT
						     ELSE 0
						     END)  as CRD_TFR_IN_AMT
				  ,SUM(CASE WHEN (BIZ_SBJ LIKE '102%' OR BIZ_SBJ = '10499')
				            THEN PAY_AMT
						    ELSE 0
						    END)  as CRD_TURN_OUT_AMT		 
           FROM DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS
		   WHERE SYS_SRC = '信用账户'
		   AND   BUS_DATE = %d{yyyyMMdd}
		   GROUP BY CUST_NO
		   )            a3
ON         t.CUST_NO = a3.CUST_NO 
LEFT JOIN (SELECT CUST_NO
                  ,SUM(CASE WHEN ODR_CGY IN (7,10,5555,7777,9999)
				             THEN MTCH_AMT
						     ELSE 0
						     END)  as CRD_TFR_IN_MKTVAL
				  ,SUM(CASE WHEN ODR_CGY IN (9,15,4444,6666,8888)
				            THEN MTCH_AMT
						    ELSE 0
						    END)  as CRD_TURN_OUT_MKTVAL		 
           FROM  DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
		   WHERE SYS_SRC = '信用账户'
		   AND   BUS_DATE = %d{yyyyMMdd}
		   GROUP BY CUST_NO
		   )            a4
ON         t.CUST_NO = a4.CUST_NO 
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP1 a5
ON        t.CUST_NO = a5.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP2 a6
ON        t.CUST_NO = a6.CUST_NO
LEFT JOIN (SELECT CUST_NO
                  ,SUM(ACCNT_BAL)  as CRD_CPTL
                  ,SUM(UNPY_AMT)   as CRD_UNPY_CPTL			  
           FROM  DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
		   WHERE SYS_SRC = '信用账户'
		   AND   BUS_DATE = %d{yyyyMMdd}
		   GROUP BY CUST_NO
		   )            a7
ON         t.CUST_NO = a7.CUST_NO 
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP a8
ON        t.CUST_NO = a8.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP3 a9
ON        t.CUST_NO = a9.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP4 a10
ON        t.CUST_NO = a10.CUST_NO
LEFT JOIN  DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP6 a11
ON        t.CUST_NO = a11.CUST_NO
LEFT JOIN (SELECT CUST_NO,SUM(CRD_NET_AST_Y) as CRD_NET_AST_Y
           FROM  DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP7 
		   GROUP BY CUST_NO
		   ) a12
ON        t.CUST_NO = a12.CUST_NO
LEFT JOIN  DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP8 a13
ON        t.CUST_NO = a13.CUST_NO  ;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP1;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP2;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP3;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP4;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP5;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP6;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP7;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY_TEMP8;


  INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY ;
 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:ETF权限开通表                                                                     */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-08-02                                                                       */ 
  
  

  
  
  INSERT OVERWRITE DDW_PROD.T_DDW_PRT_ETF_PRVL_OPN_INFO
(        
								 BRH_NO                   --营业部编号  
								,BRH_NAME                 --营业部名称
                                ,HAND_BRH_NO              --办理营业部 	
                                ,OPN_MOD                  --开通方式
								,ETF_PRVL_OPN_DT          --ETF权限开通日期 
								,CUST_NO                  --客户号      
								,CUST_NAME                --客户姓名 
							--	,RSK_RVLBOOK              --风险揭示书
								,RSK_BEAR_ABLTY           --风险承受能力
								,M_LAUND_RSK_LVL          --洗钱风险等级
								,TOT_AST                  --当前资产
								,SECOND_CARD_VRFCTN       --二代证验证
								,OPN_AGE                  --开通时年龄
                                ,ABST                     --摘要								
) 
 PARTITION(bus_date  )
 SELECT
 	                            t.BRH_NO                 as BRH_NO                   --营业部编号  
								,t.BRH_NAME              as BRH_NAME                 --营业部名称
                                ,t.OCC_BRH_NO            as HAND_BRH_NO              --办理营业部 	
                                ,t.OPRT_MOD              as OPN_MOD                  --开通方式
								,t.DT                    as ETF_PRVL_OPN_DT          --ETF权限开通日期 
								,t.CUST_NO               as CUST_NO                  --客户号      
								,t.CUST_NAME              CUST_NAME                --客户姓名 
							--	,              RSK_RVLBOOK              --风险揭示书
								,b2.RSK_BEAR_ABLTY_NAME  as RSK_BEAR_ABLTY           --风险承受能力
								,b6.M_LAUND_RSK_LVL_NAME as M_LAUND_RSK_LVL          --洗钱风险等级
								,NVL(a2.NET_TOT_AST,0)       as TOT_AST                  --当前资产
								,t.SECOND_CARD_VRFCTN    as SECOND_CARD_VRFCTN       --二代证验证
								,cast(CASE WHEN  a1.BRTH_YM  <>99999999 AND a1.BRTH_YM IS NOT NULL
								         THEN ROUND(EDW_PROD.G_DATE_COMPARE_DATE(CAST(t.DT AS STRING),'yyyyMMdd',CAST(a1.BRTH_YM AS STRING),'yyyyMMdd')/365,0)
										 ELSE NULL 
										 END as DECIMAL(38,0))             as OPN_AGE                  --开通时年龄	
                                 ,t.ABST                 as ABST                     --摘要
                                 ,t.BUS_DATE             as BUS_DATE
   FROM  		 DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS    	t
   LEFT JOIN      DDW_PROD.T_DDW_F00_CUST_CUST_INFO        		a1
   ON             t.CUST_NO = a1.CUST_NO
   AND            a1.BUS_DATE = %d{yyyyMMdd}
   LEFT JOIN      DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY       a2
   ON             t.CUST_NO = a2.CUST_NO
   AND            a2.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN 	 DDW_PROD.V_RSK_BEAR_ABLTY					b2
  ON			 a1.RSK_BEAR_ABLTY = b2.RSK_BEAR_ABLTY	
  LEFT JOIN  DDW_PROD.V_M_LAUND_RSK_LVL            b6
  ON         a1.M_LAUND_RSK_LVL = b6.M_LAUND_RSK_LVL
  WHERE t.BIZ_SBJ in ('20240','20241','20201','20243') and t.ABST LIKE '%ETF%'
  AND            t.BUS_DATE > 20150101
  ;
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_ETF_PRVL_OPN_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_ETF_PRVL_OPN_INFO ; 
--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:持仓表代码退市与异常的监控                                                                       */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-05-24                                                                        */ 
  
  ---FLAG(0是正常,1,退市,2异常,3,未上市)

 
  ----创建临时表
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP;
  CREATE TABLE DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP as
  SELECT    a.JYS
         ,a.ZQDM
         ,a.BUS_DATE		 
 FROM EDW_PROD.T_EDW_T02_TZQGL a
 WHERE ((a.JYS = 'SH' AND a.ZQDM NOT IN ('519305','519028') AND SUBSTR(a.ZQDM,1,4) <> '1009' AND (SUBSTR(a.ZQDM,1,3) IN ('501','502','500','505','519','360','600','601','603','000','009','010','018','019','020','100','110','113','120','121','122','123','124','125','126','127','128','129','130','131','132','135','136','137','139','140') OR SUBSTR(a.ZQDM,1,4) IN ('5800','5900') OR CONCAT(SUBSTR(a.ZQDM,1,3),SUBSTR(a.ZQDM,6,1)) IN ('5100','5110','5120','5130','5180')))
     OR (a.JYS = 'SZ' AND a.ZQDM NOT BETWEEN '101650' AND '101699' AND a.ZQDM NOT IN ('119118','038015') AND (SUBSTR(a.ZQDM,1,3) IN ('150','151','159','184','000','001','002','003','300','030','031','038','140','100','101','107','108','109','111','112','114','115','116','117','118','119','120','123','125','126','127','128','129') OR SUBSTR(a.ZQDM,1,2) = '16'))
	 OR (a.JYS = 'HB' AND SUBSTR(a.ZQDM,1,3) IN ('900'))
	 OR (a.JYS = 'SB' AND SUBSTR(a.ZQDM,1,3) IN ('200'))
	 OR (a.JYS = 'TA' AND SUBSTR(a.ZQDM,1,2)  IN ('82','83','89','40','87','83','43'))
	 OR (a.JYS = 'TU' AND SUBSTR(a.ZQDM,1,2) IN ('42'))
	 OR (a.JYS IN ('HK','SK') AND SUBSTR(a.ZQDM,1,1) = '0' AND SUBSTR(a.ZQDM,1,3) <> '029'))
 AND  a.BUS_DATE = %d{yyyyMMdd}
 AND  a.ZQSL > 0
 GROUP BY a.JYS,a.ZQDM,a.BUS_DATE
 ;
 
 ---
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP1;
 CREATE TABLE DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP1 as
 SELECT ApplyingCodeFront as ZQDM1,SecurityCode as ZQDM,a.DT
 FROM   FUNDEXT.DBO_MF_FundArchives  a
 WHERE a.DT = '%d{yyyyMMdd}'
 AND    length(trim(a.ApplyingCodeFront))>0
 AND   length(trim(a.SecurityCode))>0 
 AND   a.ApplyingCodeFront <> a.SecurityCode
 AND   substr(a.securitycode,7,1) <> 'J'
 UNION 
 SELECT ApplyingCodeBack as ZQDM1,SecurityCode as ZQDM,a.DT
 FROM   FUNDEXT.DBO_MF_FundArchives  a
 WHERE a.DT = '%d{yyyyMMdd}'
 AND    length(trim(a.ApplyingCodeBack))>0
 AND   length(trim(a.SecurityCode))>0 
 AND   a.ApplyingCodeBack <> a.SecurityCode
 AND   substr(a.securitycode,7,1) <> 'J'
 ;
 
 -----
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP2;
  CREATE TABLE DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP2
  as SELECT  t.JJDM,t.BUS_DATE,t.TADM 
     FROM    ( SELECT       
							
							 CASE WHEN a.JJDM = '519028'
							       THEN '519029'
								   WHEN a.JJDM = '180042'
								   THEN '180002'
								   WHEN  b.ZQDM1 IS NOT NULL
                                   THEN  b.ZQDM	
                                   ELSE a.JJDM
                                   END  as JJDM								   
                             ,a.BUS_DATE
							 ,a.TADM
                 FROM         EDW_PROD.T_EDW_T02_TOF_JJFE a
                 LEFT JOIN  ( SELECT   ZQDM1,MIN(ZQDM) as ZQDM 
				              FROM     DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP1
							  GROUP BY ZQDM1
							  ) b  
				ON         a.JJDM = b.ZQDM1
	          WHERE a.JJSL > 0 AND a.BUS_DATE = %d{yyyyMMdd}
	)          t
	WHERE       SUBSTR(t.JJDM,1,1)  < > 'A' 
	 AND        SUBSTR(t.JJDM,1,2)  < > '95'
	AND         t.JJDM NOT IN ('00954','536068','2460021','328004','1A0017','370003')
	GROUP BY t.JJDM,t.BUS_DATE,t.TADM;
 
  ----插入数据--
   INSERT OVERWRITE DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所                             
								  ,TRD_MKT           --交易市场
                                  ,FLAG              --标志	
                                  ,LSTD_DT           --上市日期
		                          ,DLSTG_DT          --退市日期								  
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT 
                    a.ZQDM                   as CD                --代码 
                    ,a.JYS                   as EXG               --交易所                  
					,1                       as TRD_MKT           --交易市场                
                    ,CASE WHEN b.ZQDM IS NULL
                          THEN 2
						  WHEN b.ZQDM IS NOT NULL AND a.BUS_DATE >   b.TSRQ
						  THEN 1
						  WHEN b.ZQDM IS NOT NULL AND a.BUS_DATE <   b.SSRQ
						  THEN 3
						  END as FLAG  
                   ,b.SSRQ                  as LSTD_DT
                   ,b.TSRQ                  as DLSTG_DT				   
  FROM       DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP   a
  LEFT JOIN  EDW_PROD.T_EDW_T04_TSZQDM      b
  ON         a.JYS = b.JYS 
  AND        a.ZQDM = b.ZQDM
  AND        b.CPLB IN (1,2,3,4,5,6,7)
  AND        b.BUS_DATE = %d{yyyyMMdd}
  WHERE  NOT EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT c
                    WHERE   c.BUS_DATE < %d{yyyyMMdd}
				     AND     a.JYS = c.EXG
				     AND     a.ZQDM = c.CD
				    AND     c.TRD_MKT = 1
				    AND     c.FLAG = 1
                    )
 AND   ((b.ZQDM IS NULL) OR (b.ZQDM IS NOT NULL AND a.BUS_DATE NOT BETWEEN b.SSRQ AND b.TSRQ))
 AND   ((a.JYS = 'SH' AND SUBSTR(a.ZQDM,1,3) NOT IN ('501','502','500','505','519','510','511','512','513','518'))
    OR (a.JYS = 'SZ' AND SUBSTR(a.ZQDM,1,3) NOT IN ('150','151','159','184') AND SUBSTR(a.ZQDM,1,2)<>'16')
    OR a.JYS IN ('HB','SB','HK','SK','TA','TU'))	
  AND       (a.BUS_DATE NOT BETWEEN b.SSRQ AND b.TSRQ OR b.ZQDM IS NULL)
  UNION ALL	
	SELECT 
                    a.ZQDM                   as CD                --代码 
                    ,a.JYS                   as EXG               --交易所                  
					,1                       as TRD_MKT           --交易市场                
                    ,CASE WHEN b.ZQDM IS NULL
                          THEN 2
						  WHEN b.ZQDM IS NOT NULL AND a.BUS_DATE > b.TSRQ
						  THEN 1
						  WHEN b.ZQDM IS NOT NULL AND a.BUS_DATE < b.SSRQ
						  THEN 3
						  END as FLAG
                   ,b.SSRQ                  as LSTD_DT
                   ,b.TSRQ                  as DLSTG_DT							  
  FROM       DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP   a
    LEFT JOIN      (  SELECT     a.JYS,a.ZQDM,LEAST(a.SSRQ,NVL(b.SSRQ,99999999)) as SSRQ,GREATEST(a.TSRQ,NVL(b.TSRQ,00000000)) as TSRQ
                       FROM       EDW_PROD.T_EDW_T04_TSZQDM a
					   LEFT JOIN  (SELECT * FROM EDW_PROD.T_EDW_T04_TSZQDM
			                       WHERE CPLB = 5
				                   AND   ZQDM LIKE '%J'
				                   ) b
				       ON          a.ZQDM = SUBSTR(b.ZQDM,1,6)
				       AND         a.JYS = b.JYS
				       AND         a.BUS_DATE = b.BUS_DATE 
				      where        a.CPLB = 5 
					  AND a.BUS_DATE = %d{yyyyMMdd}
                    )           b 
  ON         a.JYS = b.JYS 
  AND        a.ZQDM = b.ZQDM
  WHERE        ((a.JYS = 'SH' AND SUBSTR(a.ZQDM,1,3)  IN ('501','502','500','505','519','510','511','512','513','518'))
                OR (a.JYS = 'SZ' AND (SUBSTR(a.ZQDM,1,3) IN ('150','151','159','184') OR SUBSTR(a.ZQDM,1,2)='16'))
                 )	
  AND       (a.BUS_DATE NOT BETWEEN b.SSRQ AND b.TSRQ OR b.ZQDM IS NULL)
 UNION ALL
  SELECT      a.JJDM       as CD
              ,a.TADM      as EXG
			  ,2           as TRD_MKT           --交易市场 
              ,CASE WHEN b.ZQDM IS NULL
                          THEN 2
						  WHEN b.ZQDM IS NOT NULL AND a.BUS_DATE > b.TSRQ
						  THEN 1
						  WHEN b.ZQDM IS NOT NULL AND a.BUS_DATE <   b.SSRQ 
						  THEN 3
						  END as FLAG
			   ,b.SSRQ                  as LSTD_DT
               ,b.TSRQ                  as DLSTG_DT	
  FROM       DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP2   a
   LEFT JOIN      (  SELECT     a.JYS,a.ZQDM,LEAST(a.SSRQ,NVL(b.SSRQ,99999999)) as SSRQ,GREATEST(a.TSRQ,NVL(b.TSRQ,00000000)) as TSRQ
                       FROM       EDW_PROD.T_EDW_T04_TSZQDM a
					   LEFT JOIN  (SELECT * FROM EDW_PROD.T_EDW_T04_TSZQDM
			                       WHERE CPLB = 8
				                   AND   ZQDM LIKE '%J'
				                   ) b
				       ON          a.ZQDM = SUBSTR(b.ZQDM,1,6)
				       AND         a.JYS = b.JYS
				       AND         a.BUS_DATE = b.BUS_DATE 
				      where        a.CPLB = 8 
					  AND a.BUS_DATE = %d{yyyyMMdd}
                  )           b 
  ON         a.JJDM = b.ZQDM
  WHERE  (b.ZQDM IS NULL OR a.BUS_DATE NOT BETWEEN b.SSRQ AND b.TSRQ)

 ;
  -----删除临时表
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP_TEMP;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP_TEMP1;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_HLD_CD_DLSTG_EXCPT_MOT_TEMP_TEMP2;
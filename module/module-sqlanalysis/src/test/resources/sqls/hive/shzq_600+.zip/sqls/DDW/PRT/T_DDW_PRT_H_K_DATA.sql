------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:港股通数据表                                                                */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2019-04-04                                                                       */ 


 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_H_K_DATA_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_H_K_DATA_TEMP 
 as
 SELECT a.*
 FROM 
 (SELECT YR,QUA
      ,MIN(YEAR_MTH) as YEAR_MTH_MIN
 ,MAX(YEAR_MTH) as YEAR_MTH_MAX
 FROM EDW_PROD.T_EDW_T99_TRD_DATE
 WHERE  BUS_DATE =%d{yyyyMMdd}
 GROUP BY YR,QUA) a
 INNER JOIN 
 (
 SELECT YR,QUA 
 FROM EDW_PROD.T_EDW_T99_TRD_DATE
 WHERE YEAR_MTH = CAST(SUBSTR('20190329',1,6) as INT)
 AND BUS_DATE = %d{yyyyMMdd}
 GROUP BY YR,QUA
 ) b
 ON  a.YR = b.YR
 AND a.QUA = b.QUA ;


INSERT OVERWRITE DDW_PROD.T_DDW_PRT_H_K_DATA
(
   CUST_VOL             --开户数
  ,TRD_VOL_TMTH        --本月交易量
  ,TRD_VOL_SSON        --本季度交易量
  ,TRD_VOL_TYEAR       --本年累计交易量
  ,FNL_MKTVAL_HKD      --期末市值(HKD)
  ,FNL_MKTVAL_RMB      --期末市值(RMB)
  ,EXG_RATE            --汇率
  ,CGY                 --类别  
 ) PARTITION(YEAR_MON = CAST(SUBSTR('20190329',1,6) as INT))
 SELECT 
  t.SK_PRVL_CUST_VOL         as CUST_VOL          --开户数
  ,NVL(a1.ORDI_TRD_VOL_SK,0)  as TRD_VOL_TMTH        --本月交易量
  ,NVL(a2.ORDI_TRD_VOL_SK,0)  as TRD_VOL_SSON        --本季度交易量
  ,NVL(a3.ORDI_TRD_VOL_SK,0)  as TRD_VOL_TYEAR       --本年累计交易量
  ,ROUND(NVL(a5.FNL_MKTVAL_SK,0)*1.000/NVL(a4.ZHHL,1),2)  FNL_MKTVAL_HKD      --期末市值(HKD)
  ,NVL(a5.FNL_MKTVAL_SK,0)    as FNL_MKTVAL_RMB      --期末市值(RMB)
  ,NVL(a4.ZHHL,0)             as EXG_RATE            --汇率
  ,  '深港通'            --类别
 FROM (SELECT SUM(IDX_VAL) as SK_PRVL_CUST_VOL
             ,YEAR_MON 
       FROM DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON 
       WHERE YEAR_MON = CAST(SUBSTR('20190329',1,6) as INT)
       AND IDX_CDG = 'FNL_SK_PRVL_CUST_VOL' 
       AND CUST_CGY = '3'
       GROUP BY YEAR_MON 
	   )              t
 LEFT JOIN (SELECT SUM(ORDI_TRD_VOL_SK) as ORDI_TRD_VOL_SK
                  ,YEAR_MON
            FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON
            WHERE YEAR_MON = CAST(SUBSTR('20190329',1,6) as INT)
            GROUP BY YEAR_MON 
			)               a1
 ON      t.YEAR_MON = a1.YEAR_MON
  LEFT JOIN (SELECT SUM(ORDI_TRD_VOL_SK) as ORDI_TRD_VOL_SK
                   ,MAX(YEAR_MON)  as YEAR_MON
             FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON a
             INNER JOIN DDW_PROD.T_DDW_PRT_H_K_DATA_TEMP b
             ON     a.YEAR_MON > = b.YEAR_MTH_MIN
             AND     a.YEAR_MON <= b.YEAR_MTH_MAX
			 WHERE  a.YEAR_MON < = CAST(SUBSTR('20190329',1,6) as INT)
			)               a2
 ON      t.YEAR_MON = a2.YEAR_MON
  LEFT JOIN (SELECT SUM(ORDI_TRD_VOL_SK) as ORDI_TRD_VOL_SK
                   ,MAX(YEAR_MON) as YEAR_MON
             FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON
             WHERE SUBSTR(CAST(YEAR_MON as STRING),1,4)= SUBSTR('20190329',1,4) 
             AND YEAR_MON < = CAST(SUBSTR('20190329',1,6) as INT)
			)               a3
 ON      t.YEAR_MON = a3.YEAR_MON
   LEFT JOIN (SELECT  ZHHL
                      ,CAST(SUBSTR('20190329',1,6) as INT) as YEAR_MON
              FROM EDW_PROD.T_EDW_T99_HLZH
              WHERE BUS_DATE = 20190329
              AND   BZDM = 'HKD'
			)               a4
 ON      t.YEAR_MON = a4.YEAR_MON
    LEFT JOIN ( SELECT SUM(FNL_MKTVAL_SK) as FNL_MKTVAL_SK
                      ,YEAR_MON
                 FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON
                 WHERE YEAR_MON = CAST(SUBSTR('20190329',1,6) as INT)
                 GROUP BY YEAR_MON
			   )               a5
 ON      t.YEAR_MON = a5.YEAR_MON
 UNION ALL
  SELECT 
  t.SK_PRVL_CUST_VOL         as CUST_VOL          --开户数
  ,NVL(a1.ORDI_TRD_VOL_HK,0)  as TRD_VOL_TMTH        --本月交易量
  ,NVL(a2.ORDI_TRD_VOL_HK,0)  as TRD_VOL_SSON        --本季度交易量
  ,NVL(a3.ORDI_TRD_VOL_HK,0)  as TRD_VOL_TYEAR       --本年累计交易量
  ,ROUND(NVL(a5.FNL_MKTVAL_HK,0)*1.000/NVL(a4.ZHHL,1),2)  FNL_MKTVAL_HKD      --期末市值(HKD)
  ,NVL(a5.FNL_MKTVAL_HK,0)    as FNL_MKTVAL_RMB      --期末市值(RMB)
  ,NVL(a4.ZHHL,0)             as EXG_RATE            --汇率
  ,  '沪港通'            --类别
 FROM (SELECT SUM(IDX_VAL) as SK_PRVL_CUST_VOL
             ,YEAR_MON 
       FROM DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON 
       WHERE YEAR_MON = CAST(SUBSTR('20190329',1,6) as INT)
       AND IDX_CDG = 'FNL_HK_PRVL_CUST_VOL' 
       AND CUST_CGY = '3'
       GROUP BY YEAR_MON 
	   )              t
 LEFT JOIN (SELECT SUM(ORDI_TRD_VOL_HK) as ORDI_TRD_VOL_HK
                  ,YEAR_MON
            FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON
            WHERE YEAR_MON = CAST(SUBSTR('20190329',1,6) as INT)
            GROUP BY YEAR_MON 
			)               a1
 ON      t.YEAR_MON = a1.YEAR_MON
  LEFT JOIN (SELECT SUM(ORDI_TRD_VOL_HK) as ORDI_TRD_VOL_HK
                   ,MAX(YEAR_MON)  as YEAR_MON
             FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON a
             INNER JOIN DDW_PROD.T_DDW_PRT_H_K_DATA_TEMP b
             ON     a.YEAR_MON > = b.YEAR_MTH_MIN
             AND     a.YEAR_MON <= b.YEAR_MTH_MAX
			 WHERE  a.YEAR_MON < = CAST(SUBSTR('20190329',1,6) as INT)
			)               a2
 ON      t.YEAR_MON = a2.YEAR_MON
  LEFT JOIN (SELECT SUM(ORDI_TRD_VOL_HK) as ORDI_TRD_VOL_HK
                   ,MAX(YEAR_MON) as YEAR_MON
             FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON
             WHERE SUBSTR(CAST(YEAR_MON as STRING),1,4)= SUBSTR('20190329',1,4) 
             AND YEAR_MON < = CAST(SUBSTR('20190329',1,6) as INT)
			)               a3
 ON      t.YEAR_MON = a3.YEAR_MON
   LEFT JOIN (SELECT  ZHHL
                      ,CAST(SUBSTR('20190329',1,6) as INT) as YEAR_MON
              FROM EDW_PROD.T_EDW_T99_HLZH
              WHERE BUS_DATE = 20190329
              AND   BZDM = 'HKD'
			)               a4
 ON      t.YEAR_MON = a4.YEAR_MON
    LEFT JOIN ( SELECT SUM(FNL_MKTVAL_HK) as FNL_MKTVAL_HK
                      ,YEAR_MON
                 FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON
                 WHERE YEAR_MON = CAST(SUBSTR('20190329',1,6) as INT)
                 GROUP BY YEAR_MON
			   )               a5
 ON      t.YEAR_MON = a5.YEAR_MON
;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_H_K_DATA_TEMP ;
 invalidate metadata DDW_PROD.T_DDW_PRT_H_K_DATA ; 

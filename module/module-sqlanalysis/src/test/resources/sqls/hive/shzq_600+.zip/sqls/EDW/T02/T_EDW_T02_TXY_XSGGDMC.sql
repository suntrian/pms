 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:限售股股东名册表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TXY_XSGGDMC; 
--------插入数据开始--------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TXY_XSGGDMC
(
                                    JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,KHH                                 --客户号                                
                                   ,ZQDM                                --证券代码                               
                                   ,XY_XSGGDXZ                          --限售股股东性质                            
                                   ,XY_TJLY                             --添加来源                               
                                   ,XWH                                 --交易单元                               
                                   ,ZJBH                                --证件编号                               
                                   ,YYB                                 --营业部     
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
select 
                                    t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.GDXZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as XY_XSGGDXZ                          --股东性质                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.TJLY AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as XY_TJLY                             --提交来源                                
                                   ,t.XWH                                 as XWH                                 --交易单元                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部   
                                   ,'RZRQ'                                as XTBS								   
 FROM           RZRQCX.MARGIN_TXY_XSGGDMC                 t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING    t1 
 ON             t1.DMLX = 'XY_XSGGDXZ'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.GDXZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING    t2 
 ON             t2.DMLX = 'XY_TJLY'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.TJLY AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t3
 ON             t3.YXT = 'RZRQ'
 AND            t3.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束--------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TXY_XSGGDMC',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TXY_XSGGDMC;
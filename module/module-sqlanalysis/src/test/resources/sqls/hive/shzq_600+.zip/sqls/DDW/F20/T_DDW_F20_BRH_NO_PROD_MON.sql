------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:营业部产品月表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2019-05-21                                                                       */

 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_PROD_MON_TEMP;
 CREATE TABLE DDW_PROD.T_DDW_F20_BRH_NO_PROD_MON_TEMP
 as SELECT a.PROD_CD,b.BRH_NO,a.ID,a.PROD_CL_CD
    FROM (SELECT        1 AS ID,PROD_CD,MAX(PROD_CL_CD) as PROD_CL_CD         
	      FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY
	      WHERE        SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
		  group by PROD_CD,ID
	     ) a
	LEFT JOIN (SELECT 1 AS ID,* FROM DDW_PROD.T_DDW_INR_ORG_BRH WHERE BUS_DATE = %d{yyyyMMdd})  b
	ON   a.ID = b.ID
	
;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_PROD_MON_TEMP1;
 CREATE TABLE DDW_PROD.T_DDW_F20_BRH_NO_PROD_MON_TEMP1
 as SELECT  a.PROD_CD                   --产品代码
          , MAX(a.PROD_CL_CD) as PROD_CL_CD                --产品分类代码
          , MAX(a.PROD_CL_NAME) as PROD_CL_NAME              --产品分类名称
          , SUM(a.BUYIN_AMT)           as BUYIN_AMT                 --买入金额
          , SUM(a.SELL_AMT)            as SELL_AMT                 --卖入金额
          , SUM(a.SCRP_AMT)            as SCRP_AMT                  --认购金额
          , SUM(a.PRCH_AMT)            as PRCH_AMT                  --申购金额
          , SUM(a.FIXINV_AMT)          as FIXINV_AMT      --定投金额
          , SUM(a.RDMPT_AMT)           as RDMPT_AMT      --赎回金额
          , SUM(a.BUYIN_QTY)           as BUYIN_QTY      --买入数量
          , SUM(a.SELL_QTY)            as SELL_QTY      --卖入数量
          , SUM(a.SCRP_QTY)            as SCRP_QTY      --认购数量
          , SUM(a.PRCH_QTY)            as PRCH_QTY      --申购数量
          , SUM(a.FIXINV_QTY)          as FIXINV_QTY      --定投数量
          , SUM(a.RDMPT_QTY)           as RDMPT_QTY      --赎回数量
          , SUM(a.BNS_AMT)             as BNS_AMT      --红利金额
          , SUM(a.BUYIN_S1)            as BUYIN_S1      --买入佣金
          , SUM(a.SELL_S1)             as SELL_S1      --卖出佣金
          , SUM(a.SCRP_S1_CSMN_FEE)    as SCRP_S1_CSMN_FEE      --认购佣金及手续费收入
          , SUM(a.PRCH_S1_CSMN_FEE)    as PRCH_S1_CSMN_FEE      --申购佣金及手续费收入
          , SUM(a.FIXINV_S1_CSMN_FEE)  as FIXINV_S1_CSMN_FEE      --定投佣金及手续费收入
          , SUM(a.RDMPT_S1_CSMN_FEE)   as RDMPT_S1_CSMN_FEE      --赎回佣金及手续费收入
          , SUM(a.S1_CSMN_FEE)         as S1_CSMN_FEE      --佣金及手续费收入	  	  
          , SUM(a.HLD_AMT)             as HLD_AMT      --持仓金额
          , SUM(a.HLD_QTY)             as HLD_QTY      --持仓数量
          , SUM(DECODE(a.MAIN_SALE_FLG,'0',a.HLD_AMT,0)) as MAIN_SALE_HLD_AMT
		  , SUM(DECODE(a.BUS_DATE,%d{yyyyMMdd},a.HLD_AMT,0)) as FNL_HLD_AMT
		  , SUM(DECODE(a.BUS_DATE,%d{yyyyMMdd},a.HLD_QTY,0)) as FNL_HLD_QTY
		  , SUM(DECODE(a.MAIN_SALE_FLG,'1',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as MAIN_SALE
		  , b.BRH_NO
    FROM   DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
	LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
	ON        a.CUST_NO = b.CUST_NO
	AND       b.BUS_DATE = %d{yyyyMMdd}
	WHERE  SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
	GROUP BY  PROD_CD                 
			  ,BRH_NO
			  
 ;			  
   


INSERT OVERWRITE DDW_PROD.T_DDW_F20_BRH_NO_PROD_MON
(               BRH_NO                  --营业部               
              , PROD_CD                 --产品代码
              , PROD_CL_CD              --产品分类代码
              , BUYIN_AMT               --买入金额
			  , BUYIN_QTY               --买入数量
			  , BUYIN_S1_INCM           --买入佣金收入
			  , SELL_AMT                --卖出金额
			  , SELL_QTY                --卖出数量
			  , SELL_S1_INCM            --卖出佣金收入
			  , SCRP_AMT                --认购金额
              , SCRP_QTY                --认购数量 
              , SCRP_S1_CSMN_FEE        --认购佣金及手续费收入
			  , PRCH_AMT                --申购金额
			  , PRCH_QTY                --申购数量
			  , PRCH_S1_CSMN_FEE        --申购佣金及手续费收入
			  , FIXINV_AMT              --定投金额
			  , FIXINV_QTY              --定投数量
			  , FIXINV_S1_CSMN_FEE      --定投佣金及手续费收入			  
              , RDMPT_AMT               --赎回金额              
              , RDMPT_QTY               --赎回数量
              , RDMPT_S1_CSMN_FEE       --赎回佣金及手续费收入
              , FNL_HLD_AMT             --期末持仓金额
              , FNL_HLD_QTY             --期末持仓数量
			  , AVG_HLD_AMT             --日均持仓金额
			  , AVG_HLD_QTY             --日均持仓数量
			  , MAIN_SALE               --重点销量
			  , MAIN_AVG_HLD_AMT        --重点日均保有量
              , ETL_DT			  
 ) PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT          
                t.BRH_NO                  --营业部               
              , t.PROD_CD                 --产品代码
              , t.PROD_CL_CD              --产品分类代码            
              , NVL(a1.BUYIN_AMT,0)               --买入金额
			  , NVL(a1.BUYIN_QTY,0)               --买入数量
			  , NVL(a1.BUYIN_S1,0)           --买入佣金收入
			  , NVL(a1.SELL_AMT,0)                --卖出金额
			  , NVL(a1.SELL_QTY,0)                --卖出数量
			  , NVL(a1.SELL_S1,0)            --卖出佣金收入
			  , NVL(a1.SCRP_AMT,0)                --认购金额
              , NVL(a1.SCRP_QTY,0)                --认购数量 
              , NVL(a1.SCRP_S1_CSMN_FEE,0)        --认购佣金及手续费收入
			  , NVL(a1.PRCH_AMT,0)                --申购金额
			  , NVL(a1.PRCH_QTY,0)                --申购数量
			  , NVL(a1.PRCH_S1_CSMN_FEE,0)        --申购佣金及手续费收入
			  , NVL(a1.FIXINV_AMT,0)              --定投金额
			  , NVL(a1.FIXINV_QTY,0)              --定投数量
			  , NVL(a1.FIXINV_S1_CSMN_FEE,0)      --定投佣金及手续费收入			  
              , NVL(a1.RDMPT_AMT,0)               --赎回金额              
              , NVL(a1.RDMPT_QTY,0)               --赎回数量
              , NVL(a1.RDMPT_S1_CSMN_FEE,0)       --赎回佣金及手续费收入
              , NVL(a1.FNL_HLD_AMT,0)              --期末持仓金额
              , NVL(a1.FNL_HLD_QTY,0)              --期末持仓数量
			  , ROUND(NVL(a1.HLD_AMT,0)*1.000/a2.NUM,2)  as AVG_HLD_AMT              --日均持仓金额
			  , ROUND(NVL(a1.HLD_QTY,0)*1.000/a2.NUM,2)  as AVG_HLD_QTY              --日均持仓数量
			  , NVL(a1.MAIN_SALE,0)                      as MAIN_SALE                --重点销量
			  , ROUND(NVL(a1.MAIN_SALE,0)*1.000/a2.NUM,2)  as MAIN_AVG_HLD_AMT         --重点日均保有量	
              ,%d{yyyyMMdd}   as ETL_DT			  
 FROM       DDW_PROD.T_DDW_F20_BRH_NO_PROD_MON_TEMP               t 
 LEFT JOIN  DDW_PROD.T_DDW_F20_BRH_NO_PROD_MON_TEMP1              a1
 ON         t.PROD_CD = a1.PROD_CD
 AND        t.BRH_NO = a1.BRH_NO
 LEFT JOIN  (SELECT 1 as ID,COUNT(1) as NUM FROM EDW_PROD.T_EDW_T99_TRD_DATE 
             WHERE SUBSTR(CAST(NAT_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			 AND    BUS_DATE = %d{yyyyMMdd} 
			 )                          a2
 ON         t.ID = a2.ID
 
 ;
 
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_PROD_MON_TEMP;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_PROD_MON_TEMP1;
 
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_NO_PROD_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F20_BRH_NO_PROD_MON;

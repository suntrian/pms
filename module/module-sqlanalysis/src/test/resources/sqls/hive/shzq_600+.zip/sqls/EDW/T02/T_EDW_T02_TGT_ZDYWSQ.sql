 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:柜台中登业务申请表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
--------插入数据开始--------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TGT_ZDYWSQ
(
                                     TGT_ZDYWSQ_ID                       --柜台中登业务申请主键                         
                                   ,SQBH                                --申请编号                               
                                   ,SQRQ                                --申请日期                               
                                   ,SQSJ                                --申请时间                               
                                   ,ZD_JYS                              --中登交易所                                
                                   ,YWLB                                --业务类别                               
                                   ,KH_KHFS                             --开户_开户方式                            
                                   ,CDBZ                                --撤单标志                               
                                   ,YYB                                 --营业部                                
                                   ,WTGY                                --委托柜员                               
                                   ,SHGY                                --审核柜员                               
                                   ,SHYJ                                --审核意见                               
                                   ,KHH                                 --客户号                                
                                   ,YWPH                                --业务批号                               
                                   ,PRE_SQBH                            --前置申请编号                             
                                   ,QZGLXM                              --前置关联项目                             
                                   ,CZLB                                --处理标志                               
                                   ,JGSM                                --申请结果说明                             
                                   ,WF_ID                               --WF_ID                              
                                   ,WF_BXWC                             --WF_BXWC                            
                                   ,PRE_ID                              --PRE_ID                             
                                   ,PRE_READY                           --PRE_READY                          
                                   ,SBRQ                                --申报日期                               
                                   ,SBSJ                                --申报时间                               
                                   ,PZSM                                --凭证扫描                               
                                   ,GDZH                                --股东账号                               
                                   ,GDZH2                               --股东账号2                              
                                   ,ZD_ZJLB                             --中登证件类别                             
                                   ,ZJBH                                --证件编号                               
                                   ,ZJYXQ                               --证件有效期                              
                                   ,TZRMC                               --投资人名称                              
                                   ,TZRJC                               --投资人简称                              
                                   ,WWMC                                --股东外文名称                             
                                   ,XBDM                                --性别代码                               
                                   ,ZHLB                                --账户类别                               
                                   ,TZRLBDM                             --投资人类别代码                            
                                   ,GJDM                                --国籍代码                               
                                   ,CSRQ                                --出生日期                               
                                   ,XLDM                                --学历代码                               
                                   ,ZYDM                                --职业代码                               
                                   ,LXDH                                --联系电话                               
                                   ,TXDZ                                --通讯地址                               
                                   ,YZBM                                --邮政编码                               
                                   ,CZH                                 --传真号                                
                                   ,FRDB                                --法人代表                               
                                   ,FRDBSFZH                            --法人代表身份证号                           
                                   ,FRLBDM                              --法人类别代码                             
                                   ,QYLX                                --企业类型                               
                                   ,HYLX                                --行业类型                               
                                   ,GYSX                                --国有属性                               
                                   ,SSSXDM                              --上市属性代码                             
                                   ,ZBSXDM                              --资本属性代码                             
                                   ,YGT_JGLB                            --一柜通机构类别                            
                                   ,WLFWBZ                              --是否开通网络服务                           
                                   ,WLFWMM                              --网络服务密码                             
                                   ,LXDZ                                --联系地址                               
                                   ,LXYZBM                              --联系地址邮编                             
                                   ,ZZJGDM                              --组织机构代码证                            
                                   ,JGZJYXQ                             --机构证件有效期                            
                                   ,MOBILE                              --手机                                 
                                   ,DZYX                                --电子邮箱                               
                                   ,CGYH                                --存管银行                               
                                   ,YHJSZH                              --银行结算账户                             
                                   ,QSZY                                --券商自用                               
                                   ,FWMM1                               --服务密码1                              
                                   ,FWMM2                               --服务密码2                              
                                   ,BYNR                                --BYNR                               
                                   ,ZRCDFS                              --责任承担方式                             
                                   ,ZXSWHHR                             --执行事务合伙人                            
                                   ,ZD_SDXLB                            --中登适当性类别                            
                                   ,YTZRMC                              --原投资人名称                             
                                   ,YZJBH                               --原证件编号                              
                                   ,ZQDM                                --证券代码                               
                                   ,ZQDM2                               --要约代码                               
                                   ,ZQLB                                --证券类别                               
                                   ,LTLX                                --流通类型                               
                                   ,QYLB                                --权益类别                               
                                   ,GPNF                                --挂牌年份                               
                                   ,SGBZ                                --送股标志                               
                                   ,HLBZ                                --红利标志                               
                                   ,DXBZ                                --兑息标志                               
                                   ,DJBH                                --DJBH                               
                                   ,WTSL                                --委托数量                               
                                   ,LDSD                                --联动深度                               
                                   ,ZXJGLX                              --执行机构类型                             
                                   ,SQDW                                --申请单位                               
                                   ,ZHGFLB                              --账户规范类别                             
                                   ,BYBZ                                --备用标注                               
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期                               
                                   ,SLBH                                --受理编号                               
                                   ,HYDM                                --会员代码                               
                                   ,HYDM2                               --会员代码2                              
                                   ,XWH                                 --席位号                                
                                   ,XWH2                                --回报席位号2                             
                                   ,YWQQID                              --业务请求主键                             
                                   ,YWQQCLID                            --业务请求处理主键                           
                                   ,SBLX                                --SBLX                               
                                   ,GXDM                                --GXDM                               
                                   ,FZDM                                --FZDM                               
                                   ,QYCS                                --QYCS                               
                                   ,WTJG                                --委托价格                               
                                   ,WTJE                                --委托金额                               
                                   ,ISIN                                --ISIN                               
                                   ,GGBH                                --GGBH                               
                                   ,YABH                                --YABH                               
                                   ,ZCSL                                --ZCSL                               
                                   ,FDSL                                --FDSL                               
                                   ,QQSL                                --QQSL  
                                   ,XTBS								   
) 
PARTITION( bus_date  = %d{yyyyMMdd})
 SELECT 
                                    t.ID                                  as TGT_ZDYWSQ_ID                       --ID                                  
                                   ,t.SQBH                                as SQBH                                --申请编号                                
                                   ,t.SQRQ                                as SQRQ                                --申请日期                                
                                   ,t.SQSJ                                as SQSJ                                --申请时间                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as JYS                                 --交易所                                 
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.YWLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as YWLB                                --业务类别                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as KH_KHFS                             --开户方式                                
                                   ,t.CDBZ                                as CDBZ                                --撤单标志                                
                                   ,CAST(COALESCE(t19.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                 as YYB                                 --营业部                                 
                                   ,t.WTGY                                as WTGY                                --委托柜员                                
                                   ,t.SHGY                                as SHGY                                --审核柜员                                
                                   ,t.SHYJ                                as SHYJ                                --审核意见                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.YWPH                                as YWPH                                --业务批号                                
                                   ,t.PRE_SQBH                            as PRE_SQBH                            --前置申请编号                              
                                   ,t.QZGLXM                              as QZGLXM                              --前置关联项目                              
                                   ,t.CLBZ                                as CZLB                                --申请处理标志                              
                                   ,t.JGSM                                as JGSM                                --申请结果说明                              
                                   ,t.WF_ID                               as WF_ID                               --                                    
                                   ,t.WF_BXWC                             as WF_BXWC                             --                                    
                                   ,t.PRE_ID                              as PRE_ID                              --                                    
                                   ,t.PRE_READY                           as PRE_READY                           --                                    
                                   ,t.SBRQ                                as SBRQ                                --申报日期                                
                                   ,t.SBSJ                                as SBSJ                                --申报时间                                
                                   ,t.PZSM                                as PZSM                                --凭证扫描                                
                                   ,t.GDZH                                as GDZH                                --股东账号                                
                                   ,t.GDZH2                               as GDZH2                               --GDZH2                               
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZD_ZJLB                             --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,t.ZJYXQ                               as ZJYXQ                               --证件有效期                               
                                   ,t.TZRMC                               as TZRMC                               --投资人名称                               
                                   ,t.TZRJC                               as TZRJC                               --投资人简称                               
                                   ,t.WWMC                                as WWMC                                --股东外文名称                              
                                   ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.XB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as XBDM                                --性别                                  
                                   ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZHLB                                --账户类别                                
                                   ,CAST(COALESCE(t7.MBDM,NULLIF(CONCAT('ERR',CAST(t.TZRLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as TZRLBDM                             --投资人类别                               
                                   ,CAST(COALESCE(t8.MBDM,NULLIF(CONCAT('ERR',CAST(t.GJDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as GJDM                                --国籍代码                                
                                   ,t.CSRQ                                as CSRQ                                --出生日期                                
                                   ,CAST(COALESCE(t9.MBDM,NULLIF(CONCAT('ERR',CAST(t.XLDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as XLDM                                --学历代码                                
                                   ,CAST(COALESCE(t10.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZYDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZYDM                                --职业代码                                
                                   ,t.LXDH                                as LXDH                                --联系电话                                
                                   ,t.TXDZ                                as TXDZ                                --通讯地址                                
                                   ,t.YZBM                                as YZBM                                --邮政编码                                
                                   ,t.CZH                                 as CZH                                 --传真号                                 
                                   ,t.FRDB                                as FRDB                                --法人代表                                
                                   ,t.FRDBSFZH                            as FRDBSFZH                            --法人代表身份证号                            
                                   ,CAST(COALESCE(t18.MBDM,NULLIF(CONCAT('ERR',CAST(t.FRLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as FRLBDM                              --法人类型                                
                                   ,t.QYLX                                as QYLX                                --企业类型                                
                                   ,t.HYLX                                as HYLX                                --行业类型                                
                                   ,CAST(COALESCE(t11.MBDM,NULLIF(CONCAT('ERR',CAST(t.GYSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as GYSX                                --国有属性                                
                                   ,CAST(COALESCE(t12.MBDM,NULLIF(CONCAT('ERR',CAST(t.SSSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as SSSXDM                              --上市属性                                
                                   ,CAST(COALESCE(t17.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZBSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZBSXDM                              --资本属性                                
                                   ,CAST(COALESCE(t13.MBDM,NULLIF(CONCAT('ERR',CAST(t.JGLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as YGT_JGLB                            --机构或产品类别                             
                                   ,t.WLFWBZ                              as WLFWBZ                              --是否开通网络服务                            
                                   ,t.WLFWMM                              as WLFWMM                              --网络服务密码                              
                                   ,t.LXDZ                                as LXDZ                                --联系地址                                
                                   ,t.LXYZBM                              as LXYZBM                              --联系地址邮编                              
                                   ,t.ZZJG                                as ZZJGDM                              --组织机构代码证                             
                                   ,t.JGZJYXQ                             as JGZJYXQ                             --机构证件有效期                             
                                   ,t.MOBILE                              as MOBILE                              --手机                                  
                                   ,t.EMAIL                               as DZYX                                --电子邮箱                                
                                   ,t.CGYH                                as CGYH                                --存管银行                                
                                   ,t.YHJSZH                              as YHJSZH                              --银行结算账户                              
                                   ,t.QSZY                                as QSZY                                --券商自用                                
                                   ,t.PSWD1                               as FWMM1                               --服务密码1                               
                                   ,t.PSWD2                               as FWMM2                               --服务密码2                               
                                   ,t.BYNR                                as BYNR                                --BYNR                                
                                   ,CAST(COALESCE(t14.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZRCDFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as ZRCDFS                              --承担责任方式                              
                                   ,t.ZXSWHHR                             as ZXSWHHR                             --执行事务合伙人                             
                                   ,CAST(COALESCE(t15.MBDM,NULLIF(CONCAT('ERR',CAST(t.SDXLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZD_SDXLB                            --适当性类别                               
                                   ,t.YTZRMC                              as YTZRMC                              --原投资人名称                              
                                   ,t.YZJBH                               as YZJBH                               --原证件编号                               
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQDM2                               as ZQDM2                               --要约代码                                
                                   ,t.ZQLB                                as ZQLB                                --证券类别                                
                                   ,t.LTLX                                as LTLX                                --流通类型                                
                                   ,t.QYLB                                as QYLB                                --权益类别                                
                                   ,t.GPNF                                as GPNF                                --挂牌年份                                
                                   ,t.SGBZ                                as SGBZ                                --送股标志                                
                                   ,t.HLBZ                                as HLBZ                                --红利标志                                
                                   ,t.DXBZ                                as DXBZ                                --兑息标志                                
                                   ,t.DJBH                                as DJBH                                --DJBH                                
                                   ,t.WTSL                                as WTSL                                --委托数量                                
                                   ,t.LDSD                                as LDSD                                --联动深度                                
                                   ,t.ZXJGLX                              as ZXJGLX                              --执行机构类型                              
                                   ,t.SQDW                                as SQDW                                --申请单位                                
                                   ,CAST(COALESCE(t16.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHGFLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as ZHGFLB                              --账户规范类别                              
                                   ,t.BYBZ                                as BYBZ                                --备用标注                                
                                   ,t.KSRQ                                as KSRQ                                --开始日期                                
                                   ,t.JSRQ                                as JSRQ                                --结束日期                                
                                   ,t.SLBH                                as SLBH                                --受理编号                                
                                   ,t.HYDM                                as HYDM                                --会员代码                                
                                   ,t.HYDM2                               as HYDM2                               --会员代码2                               
                                   ,t.XWH                                 as XWH                                 --席位号                                 
                                   ,t.XWH2                                as XWH2                                --回报席位号2                              
                                   ,t.YWQQID                              as YWQQID                              --业务请求ID                              
                                   ,t.YWQQCLID                            as YWQQCLID                            --业务请求处理ID                            
                                   ,t.SBLX                                as SBLX                                --                                    
                                   ,t.GXDM                                as GXDM                                --                                    
                                   ,t.FZDM                                as FZDM                                --                                    
                                   ,t.QYCS                                as QYCS                                --                                    
                                   ,t.WTJG                                as WTJG                                --                                    
                                   ,t.WTJE                                as WTJE                                --                                    
                                   ,t.ISIN                                as ISIN                                --                                    
                                   ,t.GGBH                                as GGBH                                --                                    
                                   ,t.YABH                                as YABH                                --                                    
                                   ,t.ZCSL                                as ZCSL                                --                                    
                                   ,t.FDSL                                as FDSL                                --                                    
                                   ,t.QQSL                                as QQSL                                --       
                                   ,'YGT_ZD'				              as XTBS				   
 FROM           YGTCX.CIF_TGT_ZDYWSQ                    t
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'ZD_JYS'
 AND            t1.YXT = 'YGT_ZD'
 AND            t1.YDM = CAST(t.JYS AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'YWLB'
 AND            t2.YXT = 'YGT_ZD'
 AND            t2.YDM = CAST(t.YWLB AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'KH_KHFS'
 AND            t3.YXT = 'YGT_ZD'
 AND            t3.YDM = CAST(t.KHFS AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
 ON             t4.DMLX = 'ZD_ZJLB'
 AND            t4.YXT = 'YGT_ZD'
 AND            t4.YDM = CAST(t.ZJLB AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t5 
 ON             t5.DMLX = 'XBDM'
 AND            t5.YXT = 'YGT_ZD'
 AND            t5.YDM = CAST(t.XB AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t6 
 ON             t6.DMLX = 'ZHLB'
 AND            t6.YXT = 'YGT_ZD'
 AND            t6.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t7 
 ON             t7.DMLX = 'TZRLBDM'
 AND            t7.YXT = 'YGT_ZD'
 AND            t7.YDM = CAST(t.TZRLB AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t8 
 ON             t8.DMLX = 'GJDM'
 AND            t8.YXT = 'YGT_ZDSH'
 AND            t8.YDM = CAST(t.GJDM AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t9 
 ON             t9.DMLX = 'XLDM'
 AND            t9.YXT = 'YGT_ZD'
 AND            t9.YDM = CAST(t.XLDM AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t10 
 ON             t10.DMLX = 'ZYDM'
 AND            t10.YXT = 'YGT_ZD'
 AND            t10.YDM = CAST(t.ZYDM AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t11 
 ON             t11.DMLX = 'GYSX'
 AND            t11.YXT = 'YGT_ZD'
 AND            t11.YDM = CAST(t.GYSX AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t12 
 ON             t12.DMLX = 'SSSXDM'
 AND            t12.YXT = 'YGT_ZD'
 AND            t12.YDM = CAST(t.SSSX AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t13 
 ON             t13.DMLX = 'YGT_JGLB'
 AND            t13.YXT = 'YGT_ZD'
 AND            t13.YDM = CAST(t.JGLB AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t14 
 ON             t14.DMLX = 'ZRCDFS'
 AND            t14.YXT = 'YGT_ZD'
 AND            t14.YDM = CAST(t.ZRCDFS AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t15 
 ON             t15.DMLX = 'ZD_SDXLB'
 AND            t15.YXT = 'YGT_ZD'
 AND            t15.YDM = CAST(t.SDXLB AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t16 
 ON             t16.DMLX = 'ZHGFLB'
 AND            t16.YXT = 'YGT_ZD'
 AND            t16.YDM = CAST(t.ZHGFLB AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t17 
 ON             t17.DMLX = 'ZBSXDM'
 AND            t17.YXT = 'YGT_ZD'
 AND            t17.YDM = CAST(t.ZBSX AS VARCHAR(20))
 LEFT JOIN      edw_prod.T_EDW_T99_PUBLIC_CODE_MAPPING t18 
 ON             t18.DMLX = 'FRLBDM'
 AND            t18.YXT = 'YGT_ZDSH'
 AND            t18.YDM = CAST(t.FRLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t19
 ON             t19.YXT = 'CIF'
 AND            t19.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          CAST(t.DT AS INT) = ( SELECT MAX(LST_TRD_D) FROM EDW_PROD.T_EDW_T99_TRD_DATE WHERE NAT_DT = %d{yyyyMMdd} AND BUS_DATE = %d{yyyyMMdd} );
 ---------插入数据结束------
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TGT_ZDYWSQ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TGT_ZDYWSQ;
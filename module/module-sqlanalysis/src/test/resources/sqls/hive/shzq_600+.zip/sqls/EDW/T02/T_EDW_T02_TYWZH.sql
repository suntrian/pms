 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:业务账户表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TYWZH; 
-------插入数据开始--------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TYWZH
(
                                   YWXT                                --业务系统                               
                                   ,YWZH                                --业务账号                               
                                   ,KHH                                 --客户号                                
                                   ,GLYWXT                              --关联业务系统                             
                                   ,GLYWZH                              --关联业务账号                             
                                   ,YYB                                 --营业部   
                                   ,KHQZ                                --客户群组	
                                   ,ZFFS                                --支付方式                               
                                   ,YWZHZT                              --业务账户状态                             
                                   ,KHRQ                                --开户日期                               
                                   ,XHRQ                                --销户日期                               
                                   ,ZJZH                                --资金账号  
                                   ,XTBS							    --系统标识
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.YWXT                                as YWXT                                --业务系统                                
                                   ,t.YWZH                                as YWZH                                --业务账号                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.GLYWXT                              as GLYWXT                              --关联业务系统                              
                                   ,t.GLYWZH                              as GLYWZH                              --关联业务账号                              
                                   ,CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))            as YYB                                 --营业部  
                                   ,a1.KHQZ                               as KHQZ                                --客户群组  	
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZFFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZFFS                                --支付方式                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as YWZHZT                              --账户状态                                
                                   ,t.KHRQ                                as KHRQ                                --开户日期                                
                                   ,t.XHRQ                                as XHRQ                                --销户日期                                
                                   ,t.ZJZH                                as ZJZH                                --资金账号    
                                   ,'YGT'								   
 FROM           YGTCX.CIF_TYWZH                               t
 LEFT JOIN      YGTCX.CIF_TKHQZ                               a1
 ON             t.KHQZ = a1.ID
 AND            t.DT = a1.DT
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t1 
 ON             t1.DMLX = 'ZFFS'
 AND            t1.YXT = 'YGT'
 AND            t1.YDM = CAST(t.ZFFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t2 
 ON             t2.DMLX = 'YWZHZT'
 AND            t2.YXT = 'YGT_GT'
 AND            t2.YDM = CAST(t.ZHZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t3
 ON             t3.YXT = 'CIF'
 AND            t3.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';

----------插入数据结束--------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TYWZH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TYWZH;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:休眠资金币种账户表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
---------------- from YGTCX.CIF_TZJZH_XM start -----------------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TJZBZZH_XM(
                                   GTZJZH                               --柜台资金帐号
                                   ,ZJZH                                --资金账号                               
                                   ,KHH                                 --客户号                                
                                   ,YYB                                 --营业部                                
                                   ,ZZJZH                               --主资金账号                              
                                   ,GT_ZJZHLB                           --柜台资金账户类别                           
                                   ,ZZHBZ                               --主账户标志                              
                                   ,ZJZHZT                              --资金账户状态                             
                                   ,KHRQ                                --开户日期                               
                                   ,FSRQ                                --发生日期                               
                                   ,JHRQ                                --激活日期   
                                   ,BZDM                                --币种代码 
                                   ,XTBS							   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    a1.GTZJZH                              as GTZJZH                              --柜台资金账号 
                                   ,t.ZJZH                                as ZJZH                                --资金账号                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,CAST(COALESCE(t5.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as YYB                                 --营业部                                 
                                   ,t.ZZJZH                               as ZZJZH                               --主资金账号                               
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as GT_ZJZHLB                           --账户类别                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZZHBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as ZZHBZ                               --主账户标志                               
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJZHZT                              --账户状态                                
                                   ,t.KHRQ                                as KHRQ                                --开户日期                                
                                   ,t.FSRQ                                as FSRQ                                --发生日期                                
                                   ,t.JHRQ                                as JHRQ                                --激活日期 
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(a1.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种	
                                   ,'YGT_GT'                              as XTBS								   
 FROM           YGTCX.CIF_TZJZH_XM                                         t
 LEFT JOIN      YGTCX.CIF_TBZZH_XM                                         a1
 ON             t.ZJZH = a1.ZJZH
 AND      		t.DT = a1.DT
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING                     t1 
 ON             t1.DMLX = 'GT_ZJZHLB'
 AND            t1.YXT = 'YGT_GT'
 AND            t1.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING                     t2 
 ON             t2.DMLX = 'ZZHBZ'
 AND            t2.YXT = 'YGT_GT'
 AND            t2.YDM = CAST(t.ZZHBZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING                     t3 
 ON             t3.DMLX = 'ZJZHZT'
 AND            t3.YXT = 'YGT_GT'
 AND            t3.YDM = CAST(t.ZHZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING                     t4
 ON             t4.DMLX = 'BZDM'
 AND            t4.YXT = 'YGT_GT'
 AND            t4.YDM = CAST(a1.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING                        t5
 ON             t5.YXT = 'CIF'
 AND            t5.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}'
 ;
-------插入数据结束-------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TJZBZZH_XM',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TJZBZZH_XM;
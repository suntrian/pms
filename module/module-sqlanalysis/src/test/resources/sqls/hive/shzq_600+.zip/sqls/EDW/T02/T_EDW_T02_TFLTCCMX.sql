 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:非流通持仓明细表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TFLTCCMX ;
  
--------插入数据开始-----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TFLTCCMX(
                                    JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,XY_QYLB                             --权益类别                               
                                   ,ZQDM                                --证券代码                               
                                   ,GPNF                                --挂牌年份                               
                                   ,LTLX                                --流通类型                               
                                   ,ZQLB                                --证券类别                               
                                   ,ZQSL                                --证券数量                               
                                   ,RQ                                  --截止日期                               
                                   ,GXRQ                                --更新日期                               
                                   ,LTRQ                                --流通日期 
								   ,GFXZ                                --股份性质
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.QYLB                                as XY_QYLB                             --权益类别                                
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.GPNF                                as GPNF                                --挂牌年份                                
                                   ,t.LTLX                                as LTLX                                --流通类型                                
                                   ,t.ZQLB                                as ZQLB                                --证券类别                                
                                   ,t.ZQSL                                as ZQSL                                --证券数量                                
                                   ,t.RQ                                  as RQ                                  --截止日期                                
                                   ,t.GXRQ                                as GXRQ                                --更新日期                                
                                   ,t.LTRQ                                as LTRQ                                --流通日期    
                                   ,t.GFXZ                                as GFXZ                                --股份性质						   
								   ,'JZJY'                                as XTBS
 FROM      JZJYCX.SECURITIES_TFLTCCMX t
 WHERE     t.DT = '%d{yyyyMMdd}';
----------插入数据结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TFLTCCMX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
       invalidate metadata EDW_PROD.T_EDW_T02_TFLTCCMX; 
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:存管帐户对应关系表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 


--TRUNCATE TABLE EDW_PROD.T_EDW_T02_TCGZHDY; 

ALTER TABLE EDW_PROD.T_EDW_T02_TCGZHDY DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd});


---------------- 插入集中交易数据 -----------------------
insert  INTO EDW_PROD.T_EDW_T02_TCGZHDY(
                                     YHDM                                --银行代码                               
                                   ,YHZH                                --银行帐号                               
                                   ,BZDM                                --币种代码                               
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,CGYHLB                              --存管银行类别                             
                                   ,CGZH                                --存管帐户                               
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,DJRQ                                --登记日期                               
                                   ,ZH_YHZHGXZT                         --帐户与银行账号关系状态                                             
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,YHYE                                --银行余额                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
select 
                                    t.YHDM                                as YHDM                                --银行代码                                
                                   ,t.YHZH                                as YHZH                                --银行帐号                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.CGLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as CGYHLB                              --存管类别                                
                                   ,t.CGZH                                as CGZH                                --存管帐户                                
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.ZT                                  as YHZHZT                              --银行帐户状态                   
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.YHYE                                as YHYE                                --银行余额                                
                                   ,'JZJY'                                as XTBS                                --                                    
	from JZJYCX.ACCOUNT_TCGZHDY t
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
	ON             t1.DMLX = 'BZDM'
	AND            t1.YXT = 'JZJY'
	AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
	ON             t2.DMLX = 'CGYHLB'
	AND            t2.YXT = 'JZJY'
	AND            t2.YDM = CAST(t.CGLB AS VARCHAR(20))
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
	ON             t3.DMLX = 'ZJZHZT'
	AND            t3.YXT = 'JZJY'
	AND            t3.YDM = CAST(t.ZT AS VARCHAR(20))
	LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t4
	ON             t4.YXT = 'JZJY'
	AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
	WHERE t.DT = '%d{yyyyMMdd}';

	
------插入集中交易数据结束------------------

-------------------------------	插入个股期权数据---------------------------------
	insert  INTO EDW_PROD.T_EDW_T02_TCGZHDY(
                                     YHDM                                --银行代码                               
                                   ,YHZH                                --银行帐号                               
                                   ,BZDM                                --币种代码                               
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,CGYHLB                              --存管银行类别                             
                                   ,CGZH                                --存管帐户                               
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,DJRQ                                --登记日期                               
                                   ,ZH_YHZHGXZT                         --帐户与银行账号关系状态                                            
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,YHYE                                --银行余额                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
	SELECT 
                                    t.YHDM                                as YHDM                                --银行代码                                
                                   ,t.YHZH                                as YHZH                                --银行帐号                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.CGLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as CGYHLB                              --存管类别                                
                                   ,t.CGZH                                as CGZH                                --存管帐户                                
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.ZT                                  as YHZHZT                              --状态                                  
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.YHYE                                as YHYE                                --银行余额                                
                                   ,'GGQQ'                               as XTBS                                --                                    
	FROM 		   GGQQCX.ACCOUNT_TCGZHDY t
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
	ON             t1.DMLX = 'BZDM'
	AND            t1.YXT = 'GGQQ'
	AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
	ON             t2.DMLX = 'CGYHLB'
	AND            t2.YXT = 'GGQQ'
	AND            t2.YDM = CAST(t.CGLB AS VARCHAR(20))
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
	ON             t3.DMLX = 'ZJZHZT'
	AND            t3.YXT = 'GGQQ'
	AND            t3.YDM = CAST(t.ZT AS VARCHAR(20))
	LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t4
	ON             t4.YXT = 'CIF'
	AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
    WHERE 		   t.DT = '%d{yyyyMMdd}';
--------------------------------插入个股期权数据结束----------
-------------------------------插入融资融券数据-------------------------------
	INSERT  INTO EDW_PROD.T_EDW_T02_TCGZHDY(
                                     YHDM                                --银行代码                               
                                   ,YHZH                                --银行帐号                               
                                   ,BZDM                                --币种代码                               
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,CGYHLB                              --存管银行类别                             
                                   ,CGZH                                --存管帐户                               
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,DJRQ                                --登记日期                               
                                   ,ZH_YHZHGXZT                         --帐户与银行账号关系状态                             
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,YHYE                                --银行余额                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
	SELECT 
                                    t.YHDM                                as YHDM                                --银行代码                                
                                   ,t.YHZH                                as YHZH                                --银行帐号                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.CGLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as CGYHLB                              --存管类别                                
                                   ,t.CGZH                                as CGZH                                --存管帐户                                
                                   ,t.ZJZH                                as GTZJZH                              --资金帐号                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.ZT                                  as ZJZHZT                              --状态                                  
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.YHYE                                as YHYE                                --银行余额                                
                                   ,'RZRQ'                                as XTBS                                --                                    
	FROM 		   RZRQCX.ACCOUNT_TCGZHDY t
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
	ON             t1.DMLX = 'BZDM'
	AND            t1.YXT = 'RZRQ'
	AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
	ON             t2.DMLX = 'CGYHLB'
	AND            t2.YXT = 'RZRQ'
	AND            t2.YDM = CAST(t.CGLB AS VARCHAR(20))
	LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
	ON             t3.DMLX = 'ZJZHZT'
	AND            t3.YXT = 'RZRQ'
	AND            t3.YDM = CAST(t.ZT AS VARCHAR(20))
	LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t4
	ON             t4.YXT = 'CIF'
	AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
	WHERE 		   t.DT = '%d{yyyyMMdd}';
----------------结束插入 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TCGZHDY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TCGZHDY;
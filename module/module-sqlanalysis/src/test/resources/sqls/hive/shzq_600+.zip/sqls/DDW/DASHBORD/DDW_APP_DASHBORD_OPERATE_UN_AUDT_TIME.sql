--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:运营领导驾驶舱未审核时时表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2018-11-01                                                                        */ 
 ----每个人的总笔数,个人笔数,机构笔数
   DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_UN_AUDT_TIME_TEMP ;
  CREATE TABLE RPT_DB.DDW_APP_DASHBORD_OPERATE_UN_AUDT_TIME_TEMP 
  as 
       SELECT b.ywqqid,b.YWDM,unix_timestamp()-unix_timestamp(a.start_date) as TIMES,NVL(c.KHLB,'2') as CUST_CGY,a.start_date,b.KHH
               ,0 as CGY
	   FROM CIFSS.OS_CURRENTSTEP   a
       INNER JOIN 
       (
       SELECT a.instid,a.ywqqid,a.ywdm as YWDM,b.FQQD,b.KHH
       FROM CIFSS.LCGTYW_KHXXXG  a
       INNER JOIN CIFSS.TYWQQ     b
       ON        a.ywqqid = b.ID 
       AND     SQRQ = '%d{yyyyMMdd}'
       WHERE  instid < > '-1'
       UNION ALL
       SELECT a.instid,a.ywqqid,a.ywdm as YWDM,b.FQQD,b.KHH
       FROM CIFSS.LCGTYW  a
       INNER JOIN CIFSS.TYWQQ     b
       ON        a.ywqqid = b.ID 
       AND     SQRQ = '%d{yyyyMMdd}'
       WHERE  instid < > '-1'
       )   b
       ON a.entry_id = b.instid
       LEFT JOIN CIFSS.TKHXX c
       ON        b.KHH = c.KHH
       WHERE       (b.FQQD = '1' OR (b.YWDM = '20042' AND b.FQQD = '11'))
          AND   EXISTS(SELECT 1 
                       FROM (SELECT  b.YWDM
       				      FROM       CIFSS.TYWLC_TJ_SHJD a
       				      LEFT JOIN  CIFSS.TYWLC_TJ     b
       				      ON         a.tywlc_tj_id = b.ID
       				      WHERE      a.SHJS IN ('47','48','60','813')					  
       				      )      d
       				  WHERE DECODE(b.YWDM,'20322','20321','20323','20321',b.YWDM) = d.YWDM
                         )  
	UNION ALL
     SELECT b.ywqqid,b.YWDM,unix_timestamp()-unix_timestamp(a.start_date) as TIMES,NVL(c.KHLB,'2') as CUST_CGY,a.start_date,b.KHH
           ,1 as CGY
	   FROM CIFSS.OS_CURRENTSTEP   a
       INNER JOIN 
       (
       SELECT a.instid,a.ywqqid,a.ywdm as YWDM,b.FQQD,b.KHH
       FROM CIFSS.LCGTYW_KHXXXG  a
       INNER JOIN CIFSS.TYWQQ     b
       ON        a.ywqqid = b.ID 
       AND     SQRQ = '%d{yyyyMMdd}'
       WHERE  instid < > '-1'
       UNION ALL
       SELECT a.instid,a.ywqqid,a.ywdm as YWDM,b.FQQD,b.KHH
       FROM CIFSS.LCGTYW  a
       INNER JOIN CIFSS.TYWQQ     b
       ON        a.ywqqid = b.ID 
       AND     SQRQ = '%d{yyyyMMdd}'
       WHERE  instid < > '-1'
       )   b
       ON a.entry_id = b.instid
       LEFT JOIN CIFSS.TKHXX c
       ON        b.KHH = c.KHH
       WHERE       b.FQQD IN ('2','11')
          AND   EXISTS(SELECT 1 
                       FROM (SELECT  b.YWDM
       				      FROM       CIFSS.TYWLC_TJ_SHJD a
       				      LEFT JOIN  CIFSS.TYWLC_TJ     b
       				      ON         a.tywlc_tj_id = b.ID
       				      WHERE      a.SHJS IN ('809')					  
       				      )      d
       				  WHERE DECODE(b.YWDM,'20322','20321','20323','20321',b.YWDM) = d.YWDM
                         ) 	
		;
						 
	
	
	
	
	--- 插入数据
	  INSERT   OVERWRITE RPT_DB.DDW_APP_DASHBORD_OPERATE_UN_AUDT_TIME
  (
              BIZ_APL_ID    --业务请求ID
			 ,CUST_NO       --客户号
			 ,BIZ_NAME      --业务名称
			 ,START_TIME    --开始时间
			 ,CUST_CGY      --客户类别
			 ,IF_TMOUT_AUDT --是否超时
			 ,PRDCT_TIME    --预计耗时 
             ,CGY			 
  ) 
  SELECT    t.ywqqid               as BIZ_APL_ID  --业务请求ID
            ,t.KHH                 as CUST_NO     --客户号
            ,a2.YWMC               as BIZ_NAME    --业务名称
			,t.start_date          as START_TIME  --开始时间
			,DECODE(t.CUST_CGY,'0','个人','1','机构',NULL) as CUST_CGY --客户类别
			,CASE WHEN nvl(t.TIMES,0) > NVL(a1.AUDT_TIME,0) 
			      THEN '是'
				  ELSE '否'
				  END              as IF_TMOUT_AUDT --是否超时  
		    ,NVL(a1.AUDT_TIME,0)   as PRDCT_TIME    --预计耗时
			,t.CGY                 as CGY
  FROM (SELECT ywqqid ,CGY,SUM(ROUND(TIMES*1.000/60,2)) as TIMES,CUST_CGY,YWDM,MIN(START_DATE) as START_DATE,KHH
        FROM RPT_DB.DDW_APP_DASHBORD_OPERATE_UN_AUDT_TIME_TEMP
		GROUP BY CUST_CGY,ywqqid,YWDM,KHH,CGY
		)     t
  LEFT JOIN DDW_PROD.T_DDW_CFG_OPERATE_AUDT_TIME a1
  ON        t.CUST_CGY = a1.CUST_CGY
  AND       t.YWDM = a1.BIZ_CD 
  LEFT JOIN CIFSS.TYWDM    a2
  ON        t.YWDM = a2.YWDM ;
  DROP TABLE IF EXISTS RPT_DB.DDW_APP_DASHBORD_OPERATE_UN_AUDT_TIME_TEMP ;
         invalidate metadata RPT_DB.DDW_APP_DASHBORD_OPERATE_UN_AUDT_TIME ;
	
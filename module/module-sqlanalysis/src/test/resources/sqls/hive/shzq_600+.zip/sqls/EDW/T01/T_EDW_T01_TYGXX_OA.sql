--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:OA-CRM员工错误信息                                                                      */
--/* 创建人:黄勇华                                                                              */
--/* 创建时间:2016-11-02                                                                        */ 

TRUNCATE TABLE EDW_PROD.T_EDW_T01_TYGXX_OA;
INSERT OVERWRITE EDW_PROD.T_EDW_T01_TYGXX_OA
(
                                    SYSTEM_NAME                                    --系统名称
                                   ,COMPARE_TYPE                                   --类型
                                   ,BUSINESS_KEY                                   --工号
                                   ,MSG_ID                                         --错误ID
                                   ,MSG                                            --错误描述
                                   ,MSG_PARA                                       --错误员工信息   
                                  								   
) 
PARTITION( bus_date = %d{yyyyMMdd})

SELECT   'CRM'                                as system_name,
         'USER'                               as compare_type,
          CAST(result_.USERID AS STRING)      as business_key,
       --1.0
          CASE WHEN INOA = '0' 
		       THEN 'MSG_U_001'
               ELSE 
         --2.0
		       CASE WHEN PSTATUS = '0' 
			   THEN 'MSG_U_002'
               ELSE
           --3.0 
		      CASE WHEN SKIPFLG = '0' 
			       THEN  'MSG_U_003'
                   ELSE  'MSG_U_999'
                   END  
               END  
               END  as msg_id,
       --1.0
          CASE WHEN INOA = '0' 
		       THEN  '工号:%s 姓名:%s 在OA系统里不存在.'
               ELSE 
         --2.0
               CASE WHEN PSTATUS = '0' 
			   THEN '工号:%s 姓名:%s 在OA系统中处于【4:解聘/5:离职/6:退休/7:无效】状态.'
               ELSE
           --3.0 
               CASE WHEN SKIPFLG = '0' 
			   THEN  '工号:%s 姓名:%s 在OA系统中在【%s】部门. 当前系统中在【%s】部门.'
               ELSE 
            '-'
               END  
               END  
               END  as msg,
       --1.0
              CASE WHEN INOA = '0' 
			       THEN CONCAT(CAST(result_.USERID AS STRING), ',' , result_.NAME)
                   ELSE 
         --2.0
                   CASE WHEN PSTATUS = '0' 
				        THEN CONCAT(CAST(result_.USERID AS STRING) , ',' , result_.NAME)
                        ELSE
           --3.0 
                   CASE WHEN SKIPFLG = '0' 
				       THEN CONCAT(CAST(result_.USERID AS STRING) , ',' , result_.NAME,',' , result_.oa_org_name, ',' , result_.cis_org_name)
                       ELSE '-'
                        END  
                      END  
                 END as msg_para 
				 FROM (
  SELECT CASE WHEN a1.OA_USER_ID IS NULL 
	        THEN '0'
            ELSE '1'
            END AS INOA,
      CASE WHEN a1.OA_USER_STATUS > 3 
	       THEN '0'
           ELSE '1'
           END AS PSTATUS,
         SUBSTR(TRIM(a1.oa_org_name),
                LENGTH(TRIM(NVL(a1.oa_org_name,''))) - 8,
                LENGTH(TRIM(NVL(a1.oa_org_name,'')))),
         CASE
           WHEN t.cis_org_id IN (1, 3) THEN
            CASE
           WHEN (SUBSTR(TRIM(a1.oa_org_name),
                       LENGTH(TRIM(NVL(a1.oa_org_name,''))) - 8,
                        LENGTH(TRIM(NVL(a1.oa_org_name,'')))) = '营业部' OR
                SUBSTR(TRIM(a1.oa_org_name),
                        LENGTH(TRIM(NVL(a1.oa_org_name,''))) - 8,
                        LENGTH(TRIM(NVL(a1.oa_org_name,'')))) = '分公司') THEN
                        '0'
           ELSE '1' END ELSE  CASE
           WHEN t.cis_org_id = 1093 AND a1.oa_org_id = 130 THEN
            '1'
           ELSE
            '0'
         END  END AS skipflg,
     t.CIS_ORG_NAME,
     a1.OA_ORG_NAME,
     SUBSTR(TRIM(t.CIS_ORG_NAME), 7, LENGTH(TRIM(NVL(t.CIS_ORG_NAME,'')))) AS TRIMORGNAME,
     t.ID,
     t.USERID,
     t.WORKCODE,
     t.NAME,
     t.STATUS,
     t.CIS_ORG_ID,
     t.CIS_ORG_CODE
  FROM ( SELECT  a.ID         AS ID,
                 a.USERID     AS USERID,
                 a.USERID     AS WORKCODE,
                 a.NAME       AS NAME,
                 '01'         AS STATUS,
                 b.ID         AS CIS_ORG_ID,
                 b.ORGCODE    AS CIS_ORG_CODE,
                 b.NAME       AS CIS_ORG_NAME
          FROM C5CX.SPIF_TUSER a
          LEFT JOIN C5CX.SPIF_LBORGANIZATION b 
		  ON a.ORGID =	b.ID
		  AND b.DT = '%d{yyyyMMdd}'
		  WHERE a.DT = '%d{yyyyMMdd}'
          AND   UPPER(a.USERID) NOT LIKE 'KF%'
                AND UPPER(a.USERID) NOT IN ('WEBSERVICE', --WEBSERVICE
                                     'ESBUSER', --ESBUSER
                                      '99999', --总部报表查询
                                      'ADMIN', --管理员
                                      'WS1' --WS1
                                       )
           AND a.ZT = 0
           AND a.STATUS = 1
		   ) t
  LEFT JOIN (SELECT a.ID        AS OA_USER_ID, --ID
                    a.LOGINID   AS OA_USER_USERID, --系统登陆帐号
                    a.WORKCODE  AS OA_USER_WORKCODE, --工号
                    a.LASTNAME  AS OA_USER_NAME, --名
                    a.STATUS    AS OA_USER_STATUS, --状态
                    c.ID  AS OA_ORG_ID,
                    c.ID  AS OA_ORG_CODE,
                    c.DEPARTMENTNAME AS OA_ORG_NAME,
                    a.WORKCODE   , --编号(*)
                    a.ACCOUNTTYPE  , --帐号类型
                    b.ID            AS SUBID, --BELONGTO --所属主帐号
                    b.LOGINID       AS SUBLOGINID,
                    b.LASTNAME      AS SUBLASTNAME
               FROM OADB.ECOLOGY_HRMRESOURCE a
               LEFT JOIN OADB.ECOLOGY_HRMRESOURCE b 
			   ON a.BELONGTO =  b.ID -- AND RESOURCE_.ACCOUNTTYPE = '0'
			   AND b.DT = '%d{yyyyMMdd}'
               LEFT JOIN OADB.ECOLOGY_HRMDEPARTMENT c 
			   ON c.ID = a.DEPARTMENTID
			   AND c.DT = '%d{yyyyMMdd}'
			   WHERE a.DT = '%d{yyyyMMdd}'
			   
			   ) a1 
	ON t.WORKCODE =   a1.WORKCODE                                                                                       
 WHERE ((TRIM(a1.OA_ORG_NAME) <> TRIM(t.CIS_ORG_NAME) 
   AND CASE WHEN LENGTH(TRIM(nvl(t.CIS_ORG_NAME,''))) > 2 
                THEN SUBSTR(TRIM(t.CIS_ORG_NAME),7,LENGTH(TRIM(NVL(t.CIS_ORG_NAME,'')))) 
				ELSE '-'
                END <> TRIM(a1.OA_ORG_NAME)) OR a1.OA_USER_STATUS > 3)
    OR (a1.OA_USER_ID IS NULL AND LENGTH(NVL(t.WORKCODE,'')) = 5) ) result_
 WHERE CONCAT(INOA , PSTATUS , SKIPFLG) <> '111'
--///////////////////////////////////////////部门比较
--OA有, 业务系统没有
--drop table if exists ddw_prod.Temp; 
--create table ddw_prod.Temp as 
UNION ALL
SELECT 'CRM' AS system_name,
       'ORG' as compare_type,
	   CAST(result_.orgid AS STRING)
        as business_key,
       assertflg AS msg_id,
       CASE WHEN assertflg = 'O_10' THEN
         '部门:%s(上级部门:%s) 在业务系统中不存在.'
       ELSE 
         '部门:%s(上级部门:%s) 在OA系统中不存在.'
       END AS msg,
       CONCAT(result_.orgname ,',' , result_.supname)
       as msg_para FROM (
SELECT depart_.id AS orgid,
       depart_.departmentname AS orgname,
       'O_10' as assertflg,depart_.departmentname as supname
  FROM oadb.ecology_hrmdepartment depart_
                            LEFT JOIN oadb.ecology_hrmdepartment sup_ ON depart_.supdepid =
                                                                   sup_.id and LENGTH(TRIM(NVL(sup_.canceled,''))) = 0
																    and sup_.dt = '%d{yyyyMMdd}'
  WHERE NOT EXISTS (SELECT cmpdepart_.id
                    FROM oadb.ecology_hrmdepartment cmpdepart_
                    LEFT JOIN c5cx.spif_lborganization organ_ 
					ON TRIM(organ_.name) = TRIM(cmpdepart_.departmentname)
                    OR CASE WHEN LENGTH(TRIM(nvl(organ_.name,''))) > 2 
					    THEN SUBSTR(TRIM(organ_.name), 7, LENGTH(TRIM(NVL(NVL(organ_.name,''),'')))) ELSE '' END = TRIM(cmpdepart_.departmentname)
         WHERE cmpdepart_.id = depart_.id
           AND organ_.id IS NOT NULL
           AND LENGTH(TRIM(NVL(cmpdepart_.canceled,''))) = 0)
   AND depart_.id NOT IN (226, --党支部
        222, --党委
        22, --总经理室
        29, --风险管理总部
        39, --审计总部
        43, --财务管理总部
        47, --场外市场总部
        54, --固定收益总部
        68, --研究所
        79, --证券投资总部
        160, --其它
        161, --审计稽核办公室
        162, --创新发展总部
        176, --战略发展总部
        221, --党委办公室
        223, --纪委
        225, --工会
        224, --纪检监察室
        421 --海证期货
       )
   AND LENGTH(TRIM(NVL(depart_.canceled,''))) = 0
   and depart_.dt = '%d{yyyyMMdd}'
UNION ALL
--OA没有, 业务系统有
SELECT organ_.id AS orgid, organ_.name AS orgname, 'O_01' AS assertflg,suporgan_.name as supname
  FROM c5cx.spif_lborganization organ_
                            LEFT JOIN c5cx.spif_lborganization suporgan_ ON organ_.fid =
                                                                      suporgan_.id and suporgan_.dt = '%d{yyyyMMdd}'
 WHERE NOT EXISTS (SELECT cmporgan_.id
          FROM c5cx.spif_lborganization cmporgan_
          LEFT JOIN oadb.ecology_hrmdepartment depart_ ON TRIM(cmporgan_.name) =
                                                    TRIM(depart_.departmentname)
                                                 OR CASE WHEN
         LENGTH(TRIM(NVL(cmporgan_.name,''))) > 2 THEN SUBSTR(TRIM(cmporgan_.name), 7, LENGTH(TRIM(NVL(cmporgan_.name,'')))) ELSE '' END = TRIM(depart_.departmentname)
         WHERE cmporgan_.id = organ_.id
           AND depart_.id IS NOT NULL)
   AND organ_.id NOT IN (1, --上海证券
        3, --公司总部
        1093, --温州互联网营销中心
        7777, --投顾团队
        8888 --测试营业部0915
       ) 
	      and organ_.dt = '%d{yyyyMMdd}') result_ 
		  ;
		  
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TYGXX_OA',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T01_TYGXX_OA;
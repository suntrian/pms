 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:融券卖出剩余资金表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
   TRUNCATE TABLE EDW_PROD.T_EDW_T02_TXY_RQMCJE; 
----------插入数据开始------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TXY_RQMCJE
(
                                    KHH                                 --客户号                                
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,ZQDM                                --证券代码                               
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,RQSYZJ                              --融券剩余资金                             
                                   ,DRRQCJJE                            --当日融券成交金额                           
                                   ,MQDJJE                              --买券冻结金额                             
                                   ,MQQSJE                              --买券清算金额                             
                                   ,BDRQ                                --变动日期                               
                                   ,MRSGCJJE                            --买入申购成交金额    
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.RQSYZJ                              as RQSYZJ                              --融券剩余资金                              
                                   ,t.DRRQCJJE                            as DRRQCJJE                            --当日融券成交金额                            
                                   ,t.MQDJJE                              as MQDJJE                              --买券冻结金额                              
                                   ,t.MQQSJE                              as MQQSJE                              --买券清算金额                              
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.MRSGCJJE                            as MRSGCJJE                            --买入申购成交金额     
                                   ,'RZRQ'		                          as XTBS						   
 FROM      RZRQCX.MARGIN_TXY_RQMCJE    t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'RZRQ'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE     t.DT = '%d{yyyyMMdd}';
---------插入数据结束----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TXY_RQMCJE',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TXY_RQMCJE;
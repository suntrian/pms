 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:产品净值属性                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
-----------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T04_C5_TPIF_CPJZ(
                     ID     
                    ,CPID   
                    ,JZRQ   
                    ,DWJZ   
                    ,LJJZ   
                    ,FBR    
                    ,CZSJ   
                    ,SJLY   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                     t.ID     
                    ,t.CPID   
                    ,t.JZRQ   
                    ,t.DWJZ   
                    ,t.LJJZ   
                    ,t.FBR    
                    ,t.CZSJ   
                    ,t.SJLY 			   
 FROM       C5CX.SPIF_TPIF_CPJZ    t
 WHERE      t.DT = '%d{yyyyMMdd}';
----插入数据结束--------------
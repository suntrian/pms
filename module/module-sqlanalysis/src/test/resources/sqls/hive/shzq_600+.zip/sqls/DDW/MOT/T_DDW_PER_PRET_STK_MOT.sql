--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:个股盈亏监控  */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-08-11                                                                        */ 
  
----错误类别:
----(0:盈亏涨跌幅超过11%,1:新股涨跌幅,2.融资利息或者融券利息产生涨跌幅异常,3:者股息差别税产品涨跌幅异常,送股,红利涨跌幅异常 )
--
---删除当天的数据
 ALTER TABLE DDW_PROD.T_DDW_PER_PRET_STK_MOT DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ;  

 
  ----插入数据-
  ---A股涨幅度异常插入
   INSERT INTO DDW_PROD.T_DDW_PER_PRET_STK_MOT
   
 (
           CUST_NO           --客户号
          ,CD                --代码 
          ,EXG               --交易所          
          ,SRC_TABLE         --来源表
          ,PROD_CGY          --产品类别
          ,ERR_CGY           --错误类别						  
 ) 
 partition(bus_date = %d{yyyyMMdd})
  SELECT 
         t.CUST_NO                        as CUST_NO           --客户号
         ,t.SEC_CD                        as CD                --代码 
         ,t.EXG                           as EXG               --交易所          
         ,'T_DDW_CUST_STATMT_PER_PRET_STK_DAY'    as SRC_TABLE         --来源表
         ,t.PROD_CGY                      as PROD_CGY          --产品类别		
       	 ,CASE WHEN a2.ZQDM IS NOT NULL
               THEN 1
               WHEN a2.ZQDM IS NULL AND a3.SEC_CD IS NOT NULL 
               THEN 2
               WHEN a2.ZQDM IS NULL AND a3.SEC_CD IS  NULL AND a4.ZQDM IS NOT NULL
               THEN 3
               WHEN a6.ZQDM IS NOT NULL
               THEN 3
               ELSE 0
               END                        as ERR_CGY				
  FROM       DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY      t
  LEFT JOIN  (SELECT CUST_NO,SEC_CD,EXG,newst_mktval
              FROM   DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY a
              WHERE  EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE b
                            WHERE   a.BUS_DATE = b.lst_trd_d
                            AND     b.BUS_DATE = %d{yyyyMMdd}
                            AND     b.TRD_DT = %d{yyyyMMdd}
                            ) 
              AND   a.PROD_CGY = 1
             )                                         a1
 ON          t.CUST_NO = a1.CUST_NO
 AND         t.EXG = a1.EXG
 AND         t.SEC_CD = a1.SEC_CD
 LEFT JOIN   EDW_PROD.T_EDW_T04_TSZQDM                 a2
 ON          t.EXG = a2.JYS
 AND         t.SEC_CD = a2.ZQDM
 AND         a2.CPLB = 1
 AND         t.BUS_DATE = a2.SSRQ
 AND         a2.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN   (SELECT SUM(crd_acct_added_gl_int) as crd_acct_added_gl_int
                     ,EXG
                     ,CUST_NO
                     ,SEC_CD
              FROM DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS
              WHERE BUS_DATE = %d{yyyyMMdd}
              GROUP BY CUST_NO,SEC_CD,EXG
              )       a3
 ON          t.EXG = a3.EXG 
 AND         t.SEC_CD = a3.SEC_CD
 AND         t.CUST_NO = a3.CUST_NO 
 LEFT JOIN   (SELECT  JYS
                      ,ZQDM
                      ,KHH
                      ,SUM(YSJE) as YSJE
              FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
              WHERE WTLB = 93
              AND   BUS_DATE = %d{yyyyMMdd}
              GROUP BY JYS,ZQDM,KHH 
              )            a4
 ON          t.EXG = a4.JYS 
 AND         t.SEC_CD = a4.ZQDM
 AND         t.CUST_NO = a4.KHH
 LEFT JOIN   (SELECT  JYS
                      ,ZQDM
                      ,KHH
              FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
              WHERE WTLB IN (1,2)
              AND   BUS_DATE = %d{yyyyMMdd}
              GROUP BY JYS,ZQDM,KHH 
              )            a5
 ON          t.EXG = a5.JYS 
 AND         t.SEC_CD = a5.ZQDM
 AND         t.CUST_NO = a5.KHH
 LEFT JOIN   (SELECT  JYS
                      ,ZQDM
                      ,KHH
              FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
              WHERE ((WTLB = 16 AND JYS < > 'SZ') OR WTLB = 6)
              AND   BUS_DATE = %d{yyyyMMdd}
              GROUP BY JYS,ZQDM,KHH 
              )            a6
 ON          t.EXG = a6.JYS 
 AND         t.SEC_CD = a6.ZQDM
 AND         t.CUST_NO = a6.KHH
 --AND         t.BUS_DATE = a4.BUS_DATE 
 --AND         a4.WTLB IN (6,16,93)      
 WHERE       t.BUS_DATE = %d{yyyyMMdd}
 AND         t.PROD_CGY = 1
 AND         ((DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0
 AND          abs(t.TOT_PRET+NVL(a3.crd_acct_added_gl_int,0)-NVL(a4.YSJE,0))*1.000/DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0.11
 AND          a5.ZQDM IS NULL
 --AND          abs(t.TOT_PRET+NVL(a3.crd_acct_added_gl_int,0)-NVL(a4.YSJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.11
 )
              OR (DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) = 0)
              OR (DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0
 AND          abs(t.TOT_PRET+NVL(a3.crd_acct_added_gl_int,0)-NVL(a4.YSJE,0))*1.000/DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0.21  
 AND          a5.ZQDM IS NOT NULL
 --AND           abs(t.TOT_PRET+NVL(a3.crd_acct_added_gl_int,0)-NVL(a4.YSJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.21
 )
             )
  AND         t.TOT_PRET < > (0-NVL(a3.crd_acct_added_gl_int,0))
  AND         t.TOT_PRET < > NVL(a4.YSJE,0)
  AND          abs(t.TOT_PRET+NVL(a3.crd_acct_added_gl_int,0)-NVL(a4.YSJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.11

  ;
------B股涨幅度插入
  INSERT INTO DDW_PROD.T_DDW_PER_PRET_STK_MOT
   
 (
           CUST_NO           --客户号
          ,CD                --代码 
          ,EXG               --交易所          
          ,SRC_TABLE         --来源表
          ,PROD_CGY          --产品类别
          ,ERR_CGY           --错误类别						  
) 
 partition(bus_date = %d{yyyyMMdd})
  SELECT 
         t.CUST_NO                        as CUST_NO           --客户号
         ,t.SEC_CD                        as CD                --代码 
         ,t.EXG                           as EXG               --交易所          
         ,'T_DDW_CUST_STATMT_PER_PRET_STK_DAY'    as SRC_TABLE         --来源表
         ,t.PROD_CGY                      as PROD_CGY          --产品类别		
       	 ,CASE WHEN a2.ZQDM IS NOT NULL
               THEN 1
               WHEN  a6.ZQDM IS NOT NULL
               THEN 3
               ELSE 0
               END                        as ERR_CGY				
  FROM       DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY      t
  LEFT JOIN  (SELECT CUST_NO,SEC_CD,EXG,newst_mktval
              FROM   DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY a
              WHERE  EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE b
                            WHERE   a.BUS_DATE = b.lst_trd_d
                            AND     b.BUS_DATE = %d{yyyyMMdd}
                            AND     b.TRD_DT = %d{yyyyMMdd}
                            ) 
              AND   a.PROD_CGY = 2
             )                                         a1
 ON          t.CUST_NO = a1.CUST_NO
 AND         t.EXG = a1.EXG
 AND         t.SEC_CD = a1.SEC_CD
 LEFT JOIN   EDW_PROD.T_EDW_T04_TSZQDM                 a2
 ON          t.EXG = a2.JYS
 AND         t.SEC_CD = a2.ZQDM
 AND         a2.CPLB = 2
 AND         t.BUS_DATE = a2.SSRQ
 AND         a2.BUS_DATE = %d{yyyyMMdd}
   LEFT JOIN   (SELECT  JYS
                      ,ZQDM
                      ,KHH
                      ,SUM(cjje) as cjje
              FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
              WHERE WTLB = 6
              AND   BUS_DATE = %d{yyyyMMdd}
              AND   JYS IN ('HB','SB')
              GROUP BY JYS,ZQDM,KHH 
              )            a3
 ON          t.EXG = a3.JYS 
 AND         t.SEC_CD = a3.ZQDM
 AND         t.CUST_NO = a3.KHH
  LEFT JOIN   (SELECT  JYS
                      ,ZQDM
                      ,KHH
                      ,SUM(YSJE) as YSJE
              FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
              WHERE WTLB = 93
              AND   BUS_DATE = %d{yyyyMMdd}
              GROUP BY JYS,ZQDM,KHH 
              )            a4
 ON          t.EXG = a4.JYS 
 AND         t.SEC_CD = a4.ZQDM
 AND         t.CUST_NO = a4.KHH
 LEFT JOIN   (SELECT  JYS
                      ,ZQDM
                      ,KHH
              FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
              WHERE WTLB IN (1,2)
              AND   BUS_DATE = %d{yyyyMMdd}
              GROUP BY JYS,ZQDM,KHH 
              )            a5
 ON          t.EXG = a5.JYS 
 AND         t.SEC_CD = a5.ZQDM
 AND         t.CUST_NO = a5.KHH 
  LEFT JOIN   (SELECT  JYS
                      ,ZQDM
                      ,KHH
              FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
              WHERE WTLB = 16
              AND   BUS_DATE = %d{yyyyMMdd}
              AND   JYS IN ('HB','SB')
              GROUP BY JYS,ZQDM,KHH 
              )            a6
 ON          t.EXG = a6.JYS 
 AND         t.SEC_CD = a6.ZQDM
 AND         t.CUST_NO = a6.KHH    
 WHERE       t.BUS_DATE = %d{yyyyMMdd}
 AND         t.PROD_CGY = 2
 AND         ((DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0
 AND          abs(t.TOT_PRET-NVL(a4.YSJE,0)-NVL(a3.CJJE,0))*1.000/DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0.11
 AND          a5.ZQDM IS NULL
 -- AND          abs(t.TOT_PRET-NVL(a4.YSJE,0)-NVL(a3.CJJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost))> 0.11
 ) 
              OR (DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) = 0)
              OR (DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0
 AND          abs(t.TOT_PRET-NVL(a4.YSJE,0)-NVL(a3.CJJE,0))*1.000/DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0.21   
 AND          a5.ZQDM IS NOT NULL
-- AND    abs(t.TOT_PRET-NVL(a4.YSJE,0)-NVL(a3.CJJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.21 )
 --AND          abs(t.TOT_PRET-NVL(a4.YSJE,0)-NVL(a3.CJJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.20          
  ))
 AND         t.TOT_PRET < > NVL(a4.YSJE,0)
 AND         t.TOT_PRET < > NVL(a3.CJJE,0)
 AND          abs(t.TOT_PRET-NVL(a4.YSJE,0)-NVL(a3.CJJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost))> 0.11
  ;


-----场内基金
 ------
  INSERT OVERWRITE DDW_PROD.T_DDW_PER_PRET_STK_MOT
   
 (
           CUST_NO           --客户号
          ,CD                --代码 
          ,EXG               --交易所          
          ,SRC_TABLE         --来源表
          ,PROD_CGY          --产品类别
          ,ERR_CGY           --错误类别						  
) 
 partition(bus_date = %d{yyyyMMdd})
  SELECT 
         t.CUST_NO                        as CUST_NO           --客户号
         ,t.SEC_CD                        as CD                --代码 
         ,t.EXG                           as EXG               --交易所          
         ,'T_DDW_CUST_STATMT_PER_PRET_STK_DAY'    as SRC_TABLE         --来源表
         ,t.PROD_CGY                      as PROD_CGY          --产品类别		
       	 ,CASE WHEN a3.SEC_CD IS NOT NULL
               THEN 2
               WHEN a4.ZQDM IS NOT NULL 
               THEN 3
               ELSE 0
               END                        as ERR_CGY				
  FROM       DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY      t
  LEFT JOIN  (SELECT CUST_NO,SEC_CD,EXG,newst_mktval
              FROM   DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY a
              WHERE  EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE b
                            WHERE   a.BUS_DATE = b.lst_trd_d
                            AND     b.BUS_DATE = %d{yyyyMMdd}
                            AND     b.TRD_DT = %d{yyyyMMdd}
                            ) 
              AND   a.PROD_CGY = 5
             )                                         a1
 ON          t.CUST_NO = a1.CUST_NO
 AND         t.EXG = a1.EXG
 AND         t.SEC_CD = a1.SEC_CD
 LEFT JOIN   (SELECT  JYS
                      ,ZQDM
                      ,KHH
                      ,SUM(cjje) as cjje
              FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
              WHERE WTLB IN (6,45)
              AND   BUS_DATE = %d{yyyyMMdd}
              GROUP BY JYS,ZQDM,KHH 
              )            a2
 ON          t.EXG = a2.JYS 
 AND         t.SEC_CD = a2.ZQDM
 AND         t.CUST_NO = a2.KHH
 LEFT JOIN   (SELECT SUM(CRD_ACCT_ADDED_GL_INT) as crd_acct_added_gl_int
                     ,EXG
                     ,CUST_NO
                     ,SEC_CD
              FROM DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS
              WHERE BUS_DATE = %d{yyyyMMdd}
              GROUP BY CUST_NO,SEC_CD,EXG
              )       a3
 ON          t.EXG = a3.EXG 
 AND         t.SEC_CD = a3.SEC_CD
 AND         t.CUST_NO = a3.CUST_NO 
 LEFT JOIN  (SELECT JYS,ZQDM,KHH 
             FROM   EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
             WHERE  BUS_DATE = %d{yyyyMMdd}
             AND    WTLB IN (16,47,48)
             GROUP BY  JYS,ZQDM,KHH
             )            a4
 ON          t.EXG = a4.JYS 
 AND         t.SEC_CD = a4.ZQDM
 AND         t.CUST_NO = a4.KHH
 LEFT JOIN   (SELECT  JYS
                      ,ZQDM
                      ,KHH
              FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
              WHERE WTLB IN (1,2)
              AND   BUS_DATE = %d{yyyyMMdd}
              GROUP BY JYS,ZQDM,KHH 
              )            a5
 ON          t.EXG = a5.JYS 
 AND         t.SEC_CD = a5.ZQDM
 AND         t.CUST_NO = a5.KHH        
 WHERE       t.BUS_DATE = %d{yyyyMMdd}
 AND         t.PROD_CGY = 5
 AND         ((DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0
 AND          abs(t.TOT_PRET-NVL(a2.CJJE,0)-NVL(a3.crd_acct_added_gl_int,0))*1.000/DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0.11
 AND          a5.ZQDM IS NULL
-- AND          abs(t.TOT_PRET-NVL(a2.CJJE,0)-NVL(a3.crd_acct_added_gl_int,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.11
 )
              OR (DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) = 0)
              OR (DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0
 AND          abs(t.TOT_PRET-NVL(a2.CJJE,0)-NVL(a3.crd_acct_added_gl_int,0))*1.000/DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0.21
 AND          a5.ZQDM IS NOT NULL
 --AND          abs(t.TOT_PRET-NVL(a2.CJJE,0)-NVL(a3.crd_acct_added_gl_int,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.21
 )
             )
 AND         t.TOT_PRET < > NVL(a2.CJJE,0)
 AND        t.TOT_PRET < >(0-NVL(a3.crd_acct_added_gl_int,0))
 AND          abs(t.TOT_PRET-NVL(a2.CJJE,0)-NVL(a3.crd_acct_added_gl_int,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.11
 --AND          a6.ZQDM IS NULL
  ;


 ----港股涨幅度异常的数据
 INSERT INTO DDW_PROD.T_DDW_PER_PRET_STK_MOT
   
 (
           CUST_NO           --客户号
          ,CD                --代码 
          ,EXG               --交易所          
          ,SRC_TABLE         --来源表
          ,PROD_CGY          --产品类别
          ,ERR_CGY           --错误类别						  
) 
 partition(bus_date = %d{yyyyMMdd})
  SELECT 
         t.CUST_NO                        as CUST_NO           --客户号
         ,t.SEC_CD                        as CD                --代码 
         ,t.EXG                           as EXG               --交易所          
         ,'T_DDW_CUST_STATMT_PER_PRET_STK_DAY'    as SRC_TABLE         --来源表
         ,t.PROD_CGY                      as PROD_CGY          --产品类别		
       	 ,CASE WHEN a2.ZQDM IS NOT NULL
               THEN 1
               WHEN a2.ZQDM IS NULL  AND a4.ZQDM IS NOT NULL
               THEN 3
               ELSE 0
               END                        as ERR_CGY				
  FROM       DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY      t
  LEFT JOIN  (SELECT CUST_NO,SEC_CD,EXG,newst_mktval
              FROM   DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY a
              WHERE  EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE b
                            WHERE   a.BUS_DATE = b.lst_trd_d
                            AND     b.BUS_DATE = %d{yyyyMMdd}
                            AND     b.TRD_DT = %d{yyyyMMdd}
                            ) 
              AND   a.PROD_CGY = 7
             )                                         a1
 ON          t.CUST_NO = a1.CUST_NO
 AND         t.EXG = a1.EXG
 AND         t.SEC_CD = a1.SEC_CD
 LEFT JOIN   EDW_PROD.T_EDW_T04_TSZQDM                 a2
 ON          t.EXG = a2.JYS
 AND         t.SEC_CD = a2.ZQDM
 AND         a2.CPLB = 7
 AND         t.BUS_DATE = a2.SSRQ
 AND         a2.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN   (SELECT  JYS
                      ,ZQDM
                      ,KHH
                      ,SUM(cjje) as cjje
              FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
              WHERE WTLB IN (6)
              AND   BUS_DATE = %d{yyyyMMdd}
              GROUP BY JYS,ZQDM,KHH 
              )            a3
 ON          t.EXG = a3.JYS 
 AND         t.SEC_CD = a3.ZQDM
 AND         t.CUST_NO = a3.KHH
 LEFT JOIN  (SELECT JYS,ZQDM,KHH 
             FROM   EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
             WHERE  BUS_DATE = %d{yyyyMMdd}
             AND    WTLB IN (16,21)
             GROUP BY  JYS,ZQDM,KHH
             )            a4
 ON          t.EXG = a4.JYS 
 AND         t.SEC_CD = a4.ZQDM
 AND         t.CUST_NO = a4.KHH
 LEFT JOIN   (SELECT  JYS
                      ,ZQDM
                      ,KHH
              FROM EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
              WHERE WTLB IN (1,2)
              AND   BUS_DATE = %d{yyyyMMdd}
              GROUP BY JYS,ZQDM,KHH 
              )            a5
 ON          t.EXG = a5.JYS 
 AND         t.SEC_CD = a5.ZQDM
 AND         t.CUST_NO = a5.KHH    
 WHERE       t.BUS_DATE = %d{yyyyMMdd}
 AND         t.PROD_CGY = 7
 AND         ((DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0
 AND          abs(t.TOT_PRET-NVL(a3.CJJE,0))*1.000/DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0.11
 AND          a5.ZQDM IS NULL
 --AND          abs(t.TOT_PRET-NVL(a3.CJJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.11
 )
              OR (DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) = 0)
              OR (DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0
 AND          abs(t.TOT_PRET-NVL(a3.CJJE,0))*1.000/DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0.21
 AND          a5.ZQDM IS NOT NULL
 --AND          abs(t.TOT_PRET-NVL(a3.CJJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.21
 )
             )
 AND         t.TOT_PRET < > NVL(a3.CJJE,0)
 AND          abs(t.TOT_PRET-NVL(a3.CJJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.11
 
  ;

  ----场外基金
 INSERT INTO DDW_PROD.T_DDW_PER_PRET_STK_MOT
   
 (
           CUST_NO           --客户号
          ,CD                --代码 
          ,EXG               --交易所          
          ,SRC_TABLE         --来源表
          ,PROD_CGY          --产品类别
          ,ERR_CGY           --错误类别						  
) 
 partition(bus_date = %d{yyyyMMdd})
  SELECT 
         t.CUST_NO                        as CUST_NO           --客户号
         ,t.SEC_CD                        as CD                --代码 
         ,t.EXG                           as EXG               --交易所          
         ,'T_DDW_CUST_STATMT_PER_PRET_STK_DAY'    as SRC_TABLE         --来源表
         ,t.PROD_CGY                      as PROD_CGY          --产品类别		
       	 ,CASE WHEN  a4.JJDM IS NOT NULL
               THEN 3
               ELSE 0
               END                        as ERR_CGY				
  FROM       DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY      t
  LEFT JOIN  (SELECT CUST_NO,SEC_CD,EXG,newst_mktval
              FROM   DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY a
              WHERE  EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE b
                            WHERE   a.BUS_DATE = b.lst_trd_d
                            AND     b.BUS_DATE = %d{yyyyMMdd}
                            AND     b.TRD_DT = %d{yyyyMMdd}
                            ) 
              AND   a.PROD_CGY = 8
             )                                         a1
 ON          t.CUST_NO = a1.CUST_NO
 AND         t.SEC_CD = a1.SEC_CD
 LEFT JOIN  (SELECT JJDM,KHH,SUM(QRJE) as QRJE
             FROM  EDW_PROD.T_EDW_T05_TOF_JJJGLS_XZB 
             WHERE YWDM IN ('143','600')
             AND BUS_DATE = %d{yyyyMMdd}
             GROUP BY JJDM,KHH
            )           a4
 ON        t.SEC_CD = a4.JJDM
 AND         t.CUST_NO = a4.KHH 
  LEFT JOIN   (SELECT  
                      JJDM
                      ,KHH
              FROM EDW_PROD.T_EDW_T05_TOF_JJJGLS_XZB 
              WHERE YWDM IN ('122','142','124')
              AND   BUS_DATE = %d{yyyyMMdd}
              GROUP BY JJDM,KHH 
              )            a5
 ON          t.SEC_CD = a5.JJDM
 AND         t.CUST_NO = a5.KHH     
 WHERE       t.BUS_DATE = %d{yyyyMMdd}
 AND         t.PROD_CGY = 8
 AND         ((DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0
 AND          abs(t.TOT_PRET-NVL(a4.QRJE,0))*1.000/DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0.11
 AND          a5.JJDM IS NULL
 --AND          abs(t.TOT_PRET-NVL(a4.QRJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.11
 )
              OR (DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) = 0)
              OR (DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0
 AND          abs(t.TOT_PRET-NVL(a4.QRJE,0))*1.000/DECODE(SIGN(t.newst_mktval-NVL(a1.newst_mktval,0)),0,t.newst_mktval,1,t.newst_mktval,-1,NVL(a1.newst_mktval,0)) > 0.21  
 AND          a5.JJDM IS NOT NULL)
 --AND          abs(t.TOT_PRET-NVL(a4.QRJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.21          
  )
 AND         t.TOT_PRET < > NVL(a4.QRJE,0)
 AND          abs(t.TOT_PRET-NVL(a4.QRJE,0))*1.000/DECODE(t.trd_cost,0,0.01,abs(t.trd_cost)) > 0.11
  ;
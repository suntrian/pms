 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:个股期权限仓公司表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
     TRUNCATE TABLE EDW_PROD.T_EDW_T02_TSO_CCXZ_GS;  
--------插入数据开始-------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TSO_CCXZ_GS(
                                    SOP_TZZFL                           --个股期权投资者分类                          
                                   ,JYS                                 --交易所                                
                                   ,SOP_BDZQPZ                          --标的证券品种                             
                                   ,XGRQ                                --修改日期                               
                                   ,ZCC                                 --总持仓限额                              
                                   ,QLC                                 --权利仓持仓限额                            
                                   ,DRMRKC                              --当日买入开仓限额      
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.TZZFL AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as SOP_TZZFL                           --投资者分类                               
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZQLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SOP_BDZQPZ                          --证券类型                                
                                   ,t.XGRQ                                as XGRQ                                --修改日期                                
                                   ,t.ZCC                                 as ZCC                                 --总持仓限额                               
                                   ,t.QLC                                 as QLC                                 --权利仓持仓限额                             
                                   ,t.DRMRKC                              as DRMRKC                              --当日买入开仓限额 
                                   ,'GGQQ'							      as XTBS	   
 FROM           GGQQCX.SOPTION_TSO_CCXZ_GS               t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING   t1 
 ON             t1.DMLX = 'SOP_TZZFL'
 AND            t1.YXT = 'GGQQ'
 AND            t1.YDM = CAST(t.TZZFL AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING   t2 
 ON             t2.DMLX = 'SOP_BDZQPZ'
 AND            t2.YXT = 'GGQQ'
 AND            t2.YDM = CAST(t.ZQLX AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
-------插入数据结束-----------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TSO_CCXZ_GS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TSO_CCXZ_GS;
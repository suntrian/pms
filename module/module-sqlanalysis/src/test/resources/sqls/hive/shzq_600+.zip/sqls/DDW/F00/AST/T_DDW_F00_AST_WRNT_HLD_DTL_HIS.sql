 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:期权持仓历史表                                                         */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */ 
  


--------------插入数据-------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_AST_WRNT_HLD_DTL_HIS
(                                 
             CUST_NO                         --客户号           
            ,CUST_NAME                       --客户姓名       
            ,BRH_NO                          --营业部编号         
            ,EXG                             --交易所
			,SHRHLD_NO                       --股东号
            ,CCY_CD                          --币种代码
            ,WRNT_CTC_CD                     --期权合约代码
            ,WRNT_TP                         --期权类型
            ,WRNT_SEC_TP                     --标的证券类型
			,SEC_CD                          --标的证券
			,SEC_NAME                        --标的证券名称
            ,WRNT_BS_DRCT                    --期权买卖方向
            ,WRNT_CVD_LABL                   --期权备兑标签
            ,WRNT_CTC_QTY                    --期权合约数量
			,WRNT_FZN_QTY                    --期权冻结数量
			,OPNWH_DT                        --开仓日期
			,CHG_DT                          --变动日期
            ,WRNT_NEWST_MKTVAL               --期权最新市值								  								  
			,IF_AST                             						  
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT                       t.KHH                  as CUST_NO                        --客户号           
                             ,t.KHXM                 as CUST_NAME                      --客户姓名       
                             ,t.YYB                  as BRH_NO                         --营业部编号         
                             ,t.JYS                  as EXG                            --交易所
                             ,t.GDH                  as SHRHLD_NO                      --股东号
                             ,t.BZDM                 as CCY_CD                         --币种代码
                             ,t.HYDM                 as WRNT_CTC_CD                    --期权合约代码
                             ,t.SOP_QQLX             as WRNT_TP                        --期权类型
                             ,t.ZQLX                 as WRNT_SEC_TP                    --标的证券类型
							 ,t.ZQDM                 as SEC_CD                         --标的证券
							 ,t.ZQMC	             as SEC_NAME                       --标的证券名称
                             ,t.SOP_MMFX             as WRNT_BS_DRCT                   --期权买卖方向
                             ,t.SOP_BDBQ             as WRNT_CVD_LABL                  --期权备兑标签
                             ,NVL(t.ZQSL,0)          as WRNT_CTC_QTY                   --期权合约数量
                             ,NVL(t.DJSL,0)          as WRNT_FZN_QTY                   --期权冻结数量
                             ,t.KCRQ                 as OPNWH_DT                       --开仓日期
                             ,t.BDRQ                 as CHG_DT                         --变动日期
                             ,ROUND(a2.NEWST_PRC*a2.TRD_UNIT*t.ZQSL,2)  as WRNT_NEWST_MKTVAL                  --期权最新市值		
                             ,1                 as IF_AST                						  
  FROM          EDW_PROD.T_EDW_T02_TSO_HYCC                              t
  LEFT JOIN     DDW_PROD.T_DDW_PUB_QOT                                  a2
  ON            t.BUS_DATE = a2.BUS_DATE
  AND           t.JYS = a2.EXG
  AND           t.HYDM = a2.CD  
  AND           a2.TRD_MKT = 3
  WHERE         t.BUS_DATE = %d{yyyyMMdd}
  AND           t.SOP_MMFX = '1'    --期权资产
  AND           t.ZQSL < > 0                                           
  UNION ALL 
   SELECT                     t.KHH                  as CUST_NO                        --客户号           
                             ,t.KHXM                 as CUST_NAME                      --客户姓名       
                             ,t.YYB                  as BRH_NO                         --营业部编号         
                             ,t.JYS                  as EXG                            --交易所
                             ,t.GDH                  as SHRHLD_NO                      --股东号
                             ,t.BZDM                 as CCY_CD                         --币种代码
                             ,t.HYDM                 as WRNT_CTC_CD                    --期权合约代码
                             ,t.SOP_QQLX             as WRNT_TP                        --期权类型
                             ,t.ZQLX                 as WRNT_SEC_TP                    --标的证券类型
							 ,t.ZQDM                 as SEC_CD                         --标的证券
							 ,t.ZQMC	             as SEC_NAME                       --标的证券名称
                             ,t.SOP_MMFX             as WRNT_BS_DRCT                   --期权买卖方向
                             ,t.SOP_BDBQ             as WRNT_CVD_LABL                  --期权备兑标签
                             ,NVL(t.ZQSL,0)          as WRNT_CTC_QTY                   --期权合约数量
                             ,NVL(t.DJSL,0)          as WRNT_FZN_QTY                   --期权冻结数量
                             ,t.KCRQ                 as OPNWH_DT                       --开仓日期
                             ,t.BDRQ                 as CHG_DT                         --变动日期
                             ,0-ROUND(a2.NEWST_PRC*a2.TRD_UNIT*t.ZQSL,2)  as WRNT_NEWST_MKTVAL        --期权最新市值		
                             ,1                 as IF_AST 
  FROM          EDW_PROD.T_EDW_T02_TSO_HYCC                              t
  LEFT JOIN     DDW_PROD.T_DDW_PUB_QOT                                  a2
  ON            t.BUS_DATE = a2.BUS_DATE
  AND           t.JYS = a2.EXG
  AND           t.HYDM = a2.CD  
  AND           a2.TRD_MKT = 3 
  WHERE         t.BUS_DATE = %d{yyyyMMdd}
  AND           t.SOP_MMFX = '2'                                                                --期权负债
  AND           t.ZQSL < > 0	
  UNION ALL
  SELECT 
                                    t.KHH                     as CUST_NO                        --客户号            
                                   ,t.KHXM                    as CUST_NAME                      --客户姓名     
                                   ,t.YYB                     as BRH_NO                         --营业部编号     
                                   ,t.JYS                     as EXG                            --交易所
								   ,t.GDH                     as SHRHLD_NO                      --股东号
                                   ,t.JSBZDM                  as CCY_CD                         --币种代码
                                   ,t.HYDM                    as WRNT_CTC_CD                    --期权合约代码
                                   ,t.sop_qqlx                as WRNT_TP                        --期权类型    
                                   ,NULL                      as WRNT_SEC_TP                    --标的证券类型 
                                   ,t.ZQDM                    as SEC_CD                         --标的证券
							       ,a3.SEC_NAME	              as SEC_NAME                       --标的证券名称								   
                                   ,t.SOP_MMFX                as WRNT_BS_DRCT                   --期权买卖方向
                                   ,t.SOP_BDBQ                as WRNT_CVD_LABL                  --期权备兑标签                                 
                                   ,NVL(t.CJSL,0)             as WRNT_CTC_QTY                   --期权合约数量
								   ,0                         as WRNT_FZN_QTY                   --期权冻结数量
                                   ,NULL                      as OPNWH_DT                       --开仓日期
                                   ,NULL                      as CHG_DT                         --变动日期
                                   ,0-ROUND(a2.NEWST_PRC*a2.TRD_UNIT*t.CJSL,2) as WRNT_NEWST_MKTVAL      --期权最新市值
                                   ,2                         as IF_AST						
  FROM EDW_PROD.T_EDW_T05_TSO_JGMXLS        t
  LEFT JOIN   ( SELECT   a.NEWST_PRC
                         ,a.TRD_UNIT
						 ,a.CD
						 ,a.EXG
                FROM  (SELECT newst_prc
					          ,trd_unit
                              ,CD
					          ,EXG
                              ,ROW_NUMBER() OVER(PARTITION BY CD,EXG ORDER BY BUS_DATE DESC) as NUM					  
			           FROM   DDW_PROD.T_DDW_PUB_QOT
			           WHERE  TRD_MKT = 3
					   AND    BUS_DATE < = %d{yyyyMMdd}
                       ) a
               WHERE   a.NUM = 1					   
			  )                                a2
  ON            t.JYS = a2.EXG
  AND           t.HYDM = a2.CD
  LEFT JOIN   DDW_PROD.T_DDW_PUB_SEC_CD       a3
  ON            t.JYS = a3.EXG 
  AND           t.ZQDM = a3.SEC_CD
  AND           a3.BUS_DATE = %d{yyyyMMdd}  
  WHERE         t.HYDM < > '#'
  AND           t.SOP_KPCBZ = 'E'
  AND           %d{yyyyMMdd} > = t.CJRQ
  AND           %d{yyyyMMdd} < t.JSRQ  
;		
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_AST_WRNT_HLD_DTL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_AST_WRNT_HLD_DTL_HIS ;

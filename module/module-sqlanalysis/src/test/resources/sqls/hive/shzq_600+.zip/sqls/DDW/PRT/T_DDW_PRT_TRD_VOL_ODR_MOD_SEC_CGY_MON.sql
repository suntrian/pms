  /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:交易量_委托方式_证券类别月表                                                                   */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-11-14                                                                        */ 

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_SEC_CGY_MON_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_SEC_CGY_MON_TEMP 
 as SELECT     a.BRH_NO   as BRH_NO
              ,'普通账户' as SYS_SRC                        --系统来源
			  ,SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_HA+a.ORDI_TRD_VOL_SA+a.ORDI_TRD_VOL_SMS,0)) as TRD_VOL_ASTK                   --A股交易量
              ,SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_GEM,0)) as TRD_VOL_GEM                    --创业板交易量
			  ,SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_HB_USD,0)) as TRD_VOL_HBSTK_USD              --沪B交易量(USD)
			  ,SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_SB_HKD,0)) as TRD_VOL_SBSTK_HKD              --深B交易量(HKD)
			  ,ROUND(SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_HB_USD*b.ZHHL,'HKD',a.ORDI_TRD_VOL_SB_HKD*b.ZHHL,0)),2) as TRD_VOL_BSTK_RMB               --B股交易量(RMB)
              ,SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_EXG_FND,0)) as TRD_VOL_EXG_FND                --场内基金交易量
			  ,SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_BOND,0)) as TRD_VOL_BOND                   --债券交易量
			  ,SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_TU_USD,0)) as TRD_VOL_T3BOD_USD              --三板交易量(USD)
			  ,ROUND(SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_TU_USD*b.ZHHL,'HKD',a.ORDI_TRD_VOL_TA,0)),2) as TRD_VOL_T3BOD  
              ,SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_HK,0)) as TRD_VOL_HK                     --沪港通交易量
		      ,SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_SK,0)) as TRD_VOL_SK                     --深港通交易量
		      ,SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_HK,'HKD',a.ORDI_TRD_VOL_SK,0)) as TRD_VOL_HSTK                   --港股通交易量			  --三板总交易量(RMB)
              ,SUM(DECODE(b.BZDM,'USD',a.ORDI_TRD_VOL_REPO,0))  as TRD_VOL_REPO                   --回购交易量
    FROM       DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY   a
	LEFT JOIN  EDW_PROD.T_EDW_T99_HLZH                b
	ON         a.BUS_DATE = b.BUS_DATE
	WHERE    SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('20181122',1,6) 
	GROUP BY   BRH_NO,SYS_SRC 
    UNION ALL 	
	SELECT     a.BRH_NO   as BRH_NO
              ,'信用账户' as SYS_SRC                        --系统来源
			  ,SUM(a.CRD_TRD_VOL_HA+a.CRD_TRD_VOL_SA+a.CRD_TRD_VOL_SMS) as TRD_VOL_ASTK                   --A股交易量
              ,SUM(a.CRD_TRD_VOL_GEM) as TRD_VOL_GEM                    --创业板交易量
			  ,SUM(0) as TRD_VOL_HBSTK_USD              --沪B交易量(USD)
			  ,SUM(0) as TRD_VOL_SBSTK_HKD              --深B交易量(HKD)
			  ,SUM(0) as TRD_VOL_BSTK_RMB               --B股交易量(RMB)
              ,SUM(a.CRD_TRD_VOL_EXG_FND) as TRD_VOL_EXG_FND                --场内基金交易量
			  ,SUM(a.CRD_TRD_VOL_BOND) as TRD_VOL_BOND                   --债券交易量
			  ,SUM(0) as TRD_VOL_T3BOD_USD              --三板交易量(USD)
			  ,SUM(0) as TRD_VOL_T3BOD  
              ,SUM(0) as TRD_VOL_HK                     --沪港通交易量
		      ,SUM(0) as TRD_VOL_SK                     --深港通交易量
		      ,SUM(0) as TRD_VOL_HSTK                   --港股通交易量			  --三板总交易量(RMB)
              ,SUM(0)  as TRD_VOL_REPO                   --回购交易量
    FROM       DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY   a	
	WHERE    SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('20181122',1,6) 
	GROUP BY   BRH_NO,SYS_SRC ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_SEC_CGY_MON_TEMP1 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_SEC_CGY_MON_TEMP1	as
  SELECT       a.BRH_NO
             ,a.SYS_SRC
             ,ROUND(SUM(CASE WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS NOT NULL
					         AND  a.ODR_MOD = 1
				             THEN a.MTCH_AMT*b.ZHHL
				             WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS  NULL
					         AND  a.ODR_MOD = 1
				             THEN a.MTCH_AMT
				             ELSE 0
				             END
				       ),2)  as TRD_VOL_TEL_ODR                --电话委托交易量
			   ,ROUND(SUM(CASE WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS NOT NULL
					         AND  a.ODR_MOD = 2
				             THEN a.MTCH_AMT*b.ZHHL
				             WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS  NULL
					         AND  a.ODR_MOD = 2
				             THEN a.MTCH_AMT
				             ELSE 0
				             END
				       ),2)  as TRD_VOL_CARD_ODR               --磁卡委托交易量
				  ,ROUND(SUM(CASE WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS NOT NULL
					         AND  a.ODR_MOD = 4
				             THEN a.MTCH_AMT*b.ZHHL
				             WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS  NULL
					         AND  a.ODR_MOD = 4
				             THEN a.MTCH_AMT
				             ELSE 0
				             END
				       ),2)  as TRD_VOL_HOTKEY_ODR             --热键委托交易量
				,ROUND(SUM(CASE WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS NOT NULL
					         AND  a.ODR_MOD = 8
				             THEN a.MTCH_AMT*b.ZHHL
				             WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS  NULL
					         AND  a.ODR_MOD = 8
				             THEN a.MTCH_AMT
				             ELSE 0
				             END
				       ),2)  as TRD_VOL_CNTR_ODR               --柜台委托交易量
				,ROUND(SUM(CASE WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS NOT NULL
					         AND  a.ODR_MOD = 16
				             THEN a.MTCH_AMT*b.ZHHL
				             WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS  NULL
					         AND  a.ODR_MOD = 16
				             THEN a.MTCH_AMT
				             ELSE 0
				             END
				       ),2)  as TRD_VOL_REMOTE_ODR             --远程委托交易量
				,ROUND(SUM(CASE WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS NOT NULL
					         AND  a.ODR_MOD = 32
				             THEN a.MTCH_AMT*b.ZHHL
				             WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS  NULL
					         AND  a.ODR_MOD = 32
				             THEN a.MTCH_AMT
				             ELSE 0
				             END
				       ),2)  as TRD_VOL_ONLN_ODR               --网上委托交易量
			     ,ROUND(SUM(CASE WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS NOT NULL
					         AND  a.ODR_MOD = 64
				             THEN a.MTCH_AMT*b.ZHHL
				             WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS  NULL
					         AND  a.ODR_MOD = 64
				             THEN a.MTCH_AMT
				             ELSE 0
				             END
				       ),2)  as TRD_VOL_PHONE_ODR              --手机委托交易量
				  ,ROUND(SUM(CASE WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS NOT NULL
					         AND  a.ODR_MOD NOT IN (1,2,4,8,16,32,64)
				             THEN a.MTCH_AMT*b.ZHHL
				             WHEN c.BS_DRCT IN (1,2,3)
			                 AND  b.BZDM IS  NULL
					         AND  a.ODR_MOD NOT IN (1,2,4,8,16,32,64)
				             THEN a.MTCH_AMT
				             ELSE 0
				             END
				       ),2)  as TRD_VOL_OTH_ODR                --其他委托交易量
 FROM        DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS                 a
 LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH                             b
 ON             a.CCY_CD = b.BZDM
 AND            a.BUS_DATE = b.BUS_DATE
 LEFT JOIN      DDW_PROD.T_DDW_CFG_SEC_TRD_CL                      c
 ON             a.EXG = c.EXG
 AND            SUBSTR(a.SEC_CD,1,3) = c.SEC_CD_PFX
 AND            (SUBSTR(a.SEC_CGY,1,1) = c.SEC_CGY_PFX
 OR             SUBSTR(a.SEC_CGY,1,3) = c.SEC_CGY_PFX)
 AND            a.ODR_CGY = c.TRD_CGY
 WHERE        SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('20181122',1,6) 
 AND          c.EXG IS NOT NULL
 AND          a.BRH_NO NOT IN ('0001')
 GROUP BY  a.BRH_NO,a.SYS_SRC ;
				
	
  
------期初创建临时表1  
 INSERT OVERWRITE DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_SEC_CGY_MON
 (
           BRH_NO                         --营业部
		  ,BRH_NAME                       --营业部名称
          ,TRD_VOL_ASTK                   --A股交易量
		  ,TRD_VOL_GEM                    --创业板交易量
		  ,TRD_VOL_HBSTK_USD              --沪B交易量(USD)
		  ,TRD_VOL_SBSTK_HKD              --深B交易量(HKD)
          ,TRD_VOL_BSTK_RMB               --B股交易量(RMB)
		  ,TRD_VOL_EXG_FND                --场内基金交易量
		  ,TRD_VOL_BOND                   --债券交易量
		  ,TRD_VOL_T3BOD_USD              --三板交易量(USD)
		  ,TRD_VOL_T3BOD                  --三板总交易量(RMB)
		  ,TRD_VOL_HK                     --沪港通交易量
		  ,TRD_VOL_SK                     --深港通交易量
		  ,TRD_VOL_HSTK                   --港股通交易量
		  ,TRD_VOL_REPO                   --回购交易量
		  ,TRD_VOL_TEL_ODR                --电话委托交易量
		  ,TRD_VOL_CARD_ODR               --磁卡委托交易量
		  ,TRD_VOL_HOTKEY_ODR             --热键委托交易量
		  ,TRD_VOL_CNTR_ODR               --柜台委托交易量
		  ,TRD_VOL_REMOTE_ODR             --远程委托交易量
		  ,TRD_VOL_ONLN_ODR               --网上委托交易量
		  ,TRD_VOL_PHONE_ODR              --手机委托交易量
		  ,TRD_VOL_OTH_ODR                --其他委托交易量 
		  ,SYS_SRC                        --系统来源 
) 
PARTITION( YEAR_MON = CAST(SUBSTR('20181121',1,6) as INT))
 SELECT    NVL(t.BRH_NO,a1.BRH_NO)                  --营业部
		  ,a2.BRH_SHRTNM as BRH_NAME                --营业部名称
          ,NVL(t.TRD_VOL_ASTK,0)                    --A股交易量
		  ,NVL(t.TRD_VOL_GEM,0)                     --创业板交易量
		  ,NVL(t.TRD_VOL_HBSTK_USD,0)               --沪B交易量(USD)
		  ,NVL(t.TRD_VOL_SBSTK_HKD,0)               --深B交易量(HKD)
          ,NVL(t.TRD_VOL_BSTK_RMB,0)                --B股交易量(RMB)
		  ,NVL(t.TRD_VOL_EXG_FND,0)                 --场内基金交易量
		  ,NVL(t.TRD_VOL_BOND,0)                    --债券交易量
		  ,NVL(t.TRD_VOL_T3BOD_USD,0)               --三板交易量(USD)
		  ,NVL(t.TRD_VOL_T3BOD,0)                   --三板总交易量(RMB)
		  ,NVL(t.TRD_VOL_HK,0)                      --沪港通交易量
		  ,NVL(t.TRD_VOL_SK,0)                      --深港通交易量
		  ,NVL(t.TRD_VOL_HSTK,0)                    --港股通交易量
		  ,NVL(t.TRD_VOL_REPO,0)                    --回购交易量
		  ,NVL(a1.TRD_VOL_TEL_ODR,0)                --电话委托交易量
		  ,NVL(a1.TRD_VOL_CARD_ODR,0)               --磁卡委托交易量
		  ,NVL(a1.TRD_VOL_HOTKEY_ODR,0)             --热键委托交易量
		  ,NVL(a1.TRD_VOL_CNTR_ODR,0)               --柜台委托交易量
		  ,NVL(a1.TRD_VOL_REMOTE_ODR,0)             --远程委托交易量
		  ,NVL(a1.TRD_VOL_ONLN_ODR,0)               --网上委托交易量
		  ,NVL(a1.TRD_VOL_PHONE_ODR,0)              --手机委托交易量
		  ,NVL(a1.TRD_VOL_OTH_ODR,0)                --其他委托交易量 
		  ,NVL(t.SYS_SRC,a1.SYS_SRC)                --系统来源 
 FROM  DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_SEC_CGY_MON_TEMP t
 FULL JOIN DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_SEC_CGY_MON_TEMP1 a1
 ON        t.BRH_NO = a1.BRH_NO
 AND       t.SYS_SRC = a1.SYS_SRC
 INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH      a2
 ON         NVL(t.BRH_NO,a1.BRH_NO) = a2.BRH_NO
 AND        a2.BUS_DATE = 20181122 ;
 
 -----------------------加载结束---------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_TRD_VOL_ODR_MOD_SEC_CGY_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_SEC_CGY_MON ; 
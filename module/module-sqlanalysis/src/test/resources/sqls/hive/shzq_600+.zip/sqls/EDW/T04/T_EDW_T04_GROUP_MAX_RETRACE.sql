------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:客户资产汇总年表                                                                    */
------/* 创建人:组合最大回撤表                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

 
 --清除数据
-- TRUNCATE TABLE EDW_PROD.T_EDW_T04_GROUP_MAX_RETRACE;
 
 ------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T04_GROUP_MAX_RETRACE
(
              GROUP_ID      --组合id
			 ,MAX_RETRACE   --最大回撤
			 ,UPDATE_TIME
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT     
              GROUP_ID      --组合id
			 ,MAX_RETRACE   --最大回撤
			 ,UPDATE_TIME
FROM JJLC.GROUP_MAX_RETRACE
WHERE DT = '%d{yyyyMMdd}'
;

 ----删除临时表
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_GROUP_MAX_RETRACE',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
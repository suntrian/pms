--/* ***************************************** SQL BEGIN ***************************************** */
--/* 脚本功能:委托订单流水历史                                                                     */
--/* 创建人:常静静                                                                                 */
--/* 创建时间:2018-09-06                                                                           */  

------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T05_TFP_WTLS_LS
 (
                             DDID					 --单ID
                            ,WTH                     --托号
                            ,SBWTH                   --报委托号
                            ,YSBWTH                  --申报委托号
                            ,HYBH                    --员编号
                            ,PBU                     --易单元
                            ,KHH                     --户号
                            ,KHXM                    --户姓名
                            ,YYB                     --业部编号 
                            ,KHQZ                    --客户群组编码
                            ,GSFL                    --公司分类 
                            ,JSLX                    --结算类型 
                            ,JSJG                    --结算机构代码 
                            ,JSZH                    --结算账户
                            ,JGDM                    --发行机构代码 
                            ,TZZH                    --投资理财帐号
                            ,JYZH                    --交易帐号
                            ,YWDM                    --业务代码 
                            ,YWDM_JG                 --发行机构业务代码 
                            ,JYLX                    --交易类型
                            ,JYXZ                    --交易限制
                            ,JSFS                    --交收方式
                            ,CPDM                    --产品代码 
                            ,CPJC                    --产品简称
                            ,SFFS                    --收费方式
                            ,WTRQ                    --委托日期
                            ,SBRQ                    --申报日期
                            ,WTSJ                    --委托时间
                            ,WTSL                    --委托数量
                            ,WTJE                    --委托金额
                            ,WTJG                    --委托价格
                            ,DJZJ                    --冻结资金
                            ,SXF                     --手续费
                            ,ZKL                     --折扣率
                            ,JESHCLFS                --巨额赎回处理方式
                            ,HTH                     --合同/协议号 
                            ,YDH                     --约定号
                            ,YYBZ                    --预约标志
                            ,YYRQ                    --预约日期
                            ,GHYY                    --购回原因
                            ,DFXSSDM                 --对方销售商代码
                            ,DFWDH                   --对方网点号
                            ,DFJYZH                  --对方交易帐号
                            ,DFCPDM                  --对方产品代码
                            ,DFTZZH                  --对方投资帐号
                            ,DFFHFS                  --对方分红方式
                            ,FHFS                    --分红方式 
                            ,DJYY                    --冻结原因
                            ,JZRQ                    --截至日期
                            ,PLWTPCH                 --批量委托批次号
                            ,WTGY                    --委托柜员代码 
                            ,WTFS                    --委托方式
                            ,FSYYB                   --发生营业部 
                            ,CZZD                    --操作站点
                            ,BZ                      --币种
                            ,LSH_ZJ                  --资金冻结流水号
                            ,LSH_FE                  --份额冻结流水号
                            ,ZY                      --摘要
                            ,DDZT                    --订单状态
                            ,CLBZ                    --处理标志
                            ,QRRQ                    --确认日期
                            ,SFSD                    --是否适当
                            ,BSDSM                   --不适当说明
                            ,KHJL                    --客户经理
                            ,GDRQ                    --归档日期
                            ,DJBM                    --
                            ,CJJE                    --成交金额
                            ,CJSL                    --成交数量
                            ,LXR                     --联系人
                            ,SJ				         --手机
                            ,EMAIL		             --邮箱
                            ,LXDH                    --联系地址
                            ,SYR                     --受益人
                            ,SYRZH                   --受益人账户
                            ,SYRZHYH                 --受益人开户行
                            ,XSWD                    --销售网点
                            ,TXDZ                    --通讯地址
                            ,CDSL                    --撤单数量
                            ,CPFL                    --产品分类
                            ,KHLX                    --客户类型
                            ,KHTZPZ                  --客户投资品种
                            ,KHTZQX                  --客户投资期权
                            ,FXCSNL                  --风险承受能力
                            ,FXJB_FXF                --发行方评测的风险等级
                            ,CJJG                    --成交价格
                            ,CJSJ                    --成交时间
                            ,JSJE                    --结算金额
                            ,ZFFS                    --支付方式
                            ,ZFZH                    --支付账号
                            ,ZJHZFS                  --
                            ,GLDDH                   --
                            ,ZJCLFS                  --
                            ,SLID                    --
                            ,SDXBZ                   --
                            ,CPTZQX                  --产品投资期权
                            ,CPTZPZ                  --产品投资品种
                            ,CPFXPJ                  --产品风险评级
                            ,SMFXCSNL                --私募基金风险承受能力
                            ,WBQD                    --外部渠道
							, KHGMNL                  --客户购买时年龄             
                            , IP_PHONE                --IP地址/ 电话号码           
                            , MAC                     --MAC地址                    
                            , CZZD1                   --操作终端 
                            ,XTBS                    --系统标识
)
PARTITION( BUS_DATE = %d{yyyyMMdd})
SELECT 
                             T.DDID					   --1. 订单ID
                            ,T.WTH                     --2. 委托号
                            ,T.SBWTH                   --3. 申报委托号
                            ,T.YSBWTH                  --4. 原申报委托号
                            ,T.HYBH                    --5. 会员编号
                            ,T.PBU                     --6. 交易单元
                            ,T.KHH                     --7. 客户号
                            ,T.KHXM                    --8. 客户姓名
                            ,CAST(COALESCE(T1.MBJGDM,NULLIF(CONCAT('ERR',CAST(T.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS YYB                     --9. 营业部编号 
                            ,T.KHQZ                    --10. 客户群组编码
                            ,T.GSFL                    --11. 公司分类 
                            ,CAST(COALESCE(T2.MBDM,NULLIF(CONCAT('ERR',CAST(T.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS JSLX                    --12. 结算类型 
                            ,T.JSJG                    --13. 结算机构代码 
                            ,T.JSZH                    --14. 结算账户
                            ,T.JGDM                    --15. 发行机构代码 
                            ,T.TZZH                    --16. 投资理财帐号
                            ,T.JYZH                    --17. 交易帐号
                            ,T.YWDM                    --18. 业务代码 
                            ,T.YWDM_JG                 --19. 发行机构业务代码 
                            ,T.JYLX                    --20. 交易类型
                            ,CAST(COALESCE(T3.MBDM,NULLIF(CONCAT('ERR',CAST(T.JYXZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS JYXZ                    --21. 交易限制
                            ,CAST(COALESCE(T4.MBDM,NULLIF(CONCAT('ERR',CAST(T.JSFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS JSFS                    --22. 交收方式
                            ,T.CPDM                    --23. 产品代码 
                            ,T.CPJC                    --24. 产品简称
                            ,CAST(COALESCE(T5.MBDM,NULLIF(CONCAT('ERR',CAST(T.SFFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS SFFS                    --25. 收费方式
                            ,T.WTRQ                    --26. 委托日期
                            ,T.SBRQ                    --27. 申报日期
                            ,T.WTSJ                    --28. 委托时间
                            ,T.WTSL                    --29. 委托数量
                            ,T.WTJE                    --30. 委托金额
                            ,T.WTJG                    --31. 委托价格
                            ,T.DJZJ                    --32. 冻结资金
                            ,T.SXF                     --33. 手续费
                            ,T.ZKL                     --34. 折扣率
                            ,CAST(COALESCE(T6.MBDM,NULLIF(CONCAT('ERR',CAST(T.JESHCLFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS JESHCLFS                --35. 巨额赎回处理方式
                            ,T.HTH                     --36. 合同/协议号 
                            ,T.YDH                     --37. 约定号
                            ,T.YYBZ                    --38. 预约标志
                            ,T.YYRQ                    --39. 预约日期
                            ,T.GHYY                    --40. 购回原因
                            ,T.DFXSSDM                 --41. 对方销售商代码
                            ,T.DFWDH                   --42. 对方网点号
                            ,T.DFJYZH                  --43. 对方交易帐号
                            ,T.DFCPDM                  --44. 对方产品代码
                            ,T.DFTZZH                  --45. 对方投资帐号
                            ,T.DFFHFS                  --46. 对方分红方式
                            ,CAST(COALESCE(T7.MBDM,NULLIF(CONCAT('ERR',CAST(T.FHFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS FHFS                    --47. 分红方式 
                            ,CAST(COALESCE(T8.MBDM,NULLIF(CONCAT('ERR',CAST(T.DJYY AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS DJYY                    --48. 冻结原因
                            ,T.JZRQ                    --49. 截至日期
                            ,T.PLWTPCH                 --50. 批量委托批次号
                            ,T.WTGY                    --51. 委托柜员代码 
                          --  ,CAST( EDW_PROD.G_WTFS_J_WTFS(CAST(t.WTFS AS INT),0,t.FSYYB,CAST(t.WTGY AS STRING),t.CZZD) AS DECIMAL(38,0) ) as WTFS                    --52. 委托方式
                           ,WTFS
						   ,T.FSYYB                   --53. 发生营业部 
                            ,T.CZZD                    --54. 操作站点
                            ,CAST(COALESCE(T9.MBDM,NULLIF(CONCAT('ERR',CAST(T.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS BZ                      --55. 币种
                            ,T.LSH_ZJ                  --56. 资金冻结流水号
                            ,T.LSH_FE                  --57. 份额冻结流水号
                            ,T.ZY                      --58. 摘要
                            ,T.DDZT                    --59. 订单状态
                            ,CAST(COALESCE(T10.MBDM,NULLIF(CONCAT('ERR',CAST(T.CLBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS CLBZ                    --60. 处理标志
                            ,T.QRRQ                    --61. 确认日期
                            ,T.SFSD                    --62. 是否适当
                            ,T.BSDSM                   --63. 不适当说明
                            ,T.KHJL                    --64. 客户经理
                            ,T.GDRQ                    --65. 归档日期
                            ,T.DJBM                    --66. 定价编码
                            ,T.CJJE                    --67. 成交金额
                            ,T.CJSL                    --68. 成交数量
                            ,T.LXR                     --69. 联系人
                            ,T.SJ				       --70. 手机
                            ,T.EMAIL		           --71. 邮箱
                            ,T.LXDH                    --72. 联系地址
                            ,T.SYR                     --73. 受益人
                            ,T.SYRZH                   --74. 受益人账户
                            ,T.SYRZHYH                 --75. 受益人开户行
                            ,T.XSWD                    --76. 销售网点
                            ,T.TXDZ                    --77. 通讯地址
                            ,T.CDSL                    --78. 撤单数量
                            ,T.CPFL                    --79. 产品分类
                            ,T.KHLX                    --80. 客户类型
                            ,CAST(T.KHTZPZ AS STRING) AS KHTZPZ                --81. 客户投资品种   --CAST(COALESCE(T11.MBDM,NULLIF(CONCAT('ERR',CAST(T.KHTZPZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS KHTZPZ                  --81. 客户投资品种
                            ,CAST(CASE WHEN T.KHTZQX IN (1,2,4)
								             -- AND T.KHTZQX IS NULL
 								              THEN T.KHTZQX
										      WHEN T.KHTZQX BETWEEN 5 AND 365
										      --AND  T.KHTZQX IS NULL
										      THEN 1
										      WHEN T.KHTZQX BETWEEN 365 AND 1825
										      --AND  T.KHTZQX IS NULL
										      THEN 2
										      WHEN T.KHTZQX > 1825
										      --AND  T.KHTZQX IS NULL
										      THEN 4
										      ELSE T.KHTZQX
										      END AS STRING)        AS KHTZQX                  --82. 客户投资期权
                            ,CAST(COALESCE(T13.MBDM,NULLIF(CONCAT('ERR',CAST(T.FXCSNL AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS FXCSNL                  --83. 风险承受能力
                            ,T.FXJB_FXF                --84. 发行方评测的风险等级
                            ,T.CJJG                    --85. 成交价格
                            ,T.CJSJ                    --86. 成交时间
                            ,T.JSJE                    --87. 结算金额
                            ,CAST(COALESCE(T14.MBDM,NULLIF(CONCAT('ERR',CAST(T.ZFFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS ZFFS                    --88. 支付方式
                            ,T.ZFZH                    --89. 支付账号
                            ,T.ZJHZFS                  --90. 回款资金处理方式
                            ,T.GLDDH                   --91. 关联订单号
                            ,T.ZJCLFS                  --92. 资金处理方式	
                            ,T.SLID                    --93. 双录ID
                            ,T.SDXBZ                   --94. 适当性标志
                            ,CAST(CASE WHEN T.CPTZQX IN (1,2,4)
								             -- AND T.CPTZQX IS NULL
 								              THEN T.CPTZQX
										      WHEN T.CPTZQX BETWEEN 5 AND 365
										      --AND  T.CPTZQX IS NULL
										      THEN 1
										      WHEN T.CPTZQX BETWEEN 365 AND 1825
										      --AND  T.CPTZQX IS NULL
										      THEN 2
										      WHEN T.CPTZQX > 1825
										      --AND  T.CPTZQX IS NULL
										      THEN 4
										      ELSE T.CPTZQX
										      END AS STRING)        AS CPTZQX                  --95. 产品投资期权
                            ,CAST(COALESCE(T15.MBDM,NULLIF(CONCAT('ERR',CAST(T.CPTZPZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS CPTZPZ                    --96. 产品投资品种
                            ,CAST(COALESCE(T16.MBDM,NULLIF(CONCAT('ERR',CAST(T.CPFXPJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20))  AS CPFXPJ                  --97. 产品风险评级
                            ,T.SMFXCSNL                --98. 私募基金风险承受能力
                            ,T.WBQD                    --99. 外部渠道
                            ,CASE WHEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),5,2) AS INT) > CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(a1.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}                                      
									  THEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),1,4) AS INT) - CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),1,4) AS INT)
                                      WHEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),5,2) AS INT) < CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(a1.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
                                      THEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),1,4) AS INT) - CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),1,4) AS INT) - 1
                                      WHEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),5,2) AS INT) = CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(a1.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
                                      AND CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),7,2) AS INT) >= CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),7,2) AS INT)
                                      THEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),1,4) AS INT) - CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),1,4) AS INT)
                                      WHEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),5,2) AS INT) = CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(a1.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
                                      AND CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),7,2) AS INT) < CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),7,2) AS INT)
                                      THEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),1,4) AS INT) - CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),1,4) AS INT) - 1
                                      ELSE 0 END
									  --CASE WHEN NVL(t.SBRQ,0) > 0 AND a1.CSRQ <> 999999999  
								       --  THEN ROUND(EDW_PROD.G_DATE_COMPARE_DATE(CAST(t.SBRQ AS STRING),'yyyyMMdd',CAST(a1.CSRQ AS STRING),'yyyyMMdd')/365,0)
										-- ELSE NULL 
										-- END                             as KHGMNL                              --                                    
                            ,NULL      --,NVL(NVL(CONCAT(EDW_PROD.G_WTFS_J_IP(CAST(t.WTFS AS INT),0,t.FSYYB,CAST(t.WTGY AS STRING),t.CZZD),',',EDW_PROD.G_WTFS_J_PHONE(CAST(t.WTFS AS INT),0,t.FSYYB,CAST(t.WTGY AS STRING),t.CZZD)),EDW_PROD.G_WTFS_J_IP(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD)),EDW_PROD.G_WTFS_J_PHONE(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD))                            as IP_PHONE                            --IP地址/ 电话号码       
                            ,NULL       --,NVL(NVL(CONCAT(EDW_PROD.G_WTFS_J_MAC(CAST(t.WTFS AS INT),0,t.FSYYB,CAST(t.WTGY AS STRING),t.CZZD),',',EDW_PROD.G_WTFS_J_IMEI(CAST(t.WTFS AS INT),0,t.FSYYB,CAST(t.WTGY AS STRING),t.CZZD)),EDW_PROD.G_WTFS_J_MAC(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD)),EDW_PROD.G_WTFS_J_IMEI(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD))                           as MAC                                 --MAC地址                                  
                           ,NULL       -- ,EDW_PROD.G_WTFS_J_TERM(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD)                                as CZZD1                               --      
						   ,'XTBS'                    --100. 系统标识
 FROM 			(SELECT * FROM OTCCX.FPSS_HIS_TFP_WTLS_LS	WHERE 	DT = '%d{yyyyMMdd}'	)				T
  LEFT JOIN      (SELECT KHH,CSRQ FROM EDW_PROD.T_EDW_T01_TGRKHXX  WHERE  BUS_DATE = %d{yyyyMMdd})             a1
  ON             t.KHH = a1.KHH
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    			T1
 ON             T1.YXT = 'OTC'
 AND            T1.JGDM = CAST(T.YYB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T2 
 ON             T2.DMLX = 'OTC_JSLX'
 AND            T2.YXT = 'OTC'
 AND            T2.YDM = CAST(T.JSLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T3
 ON             T3.DMLX = 'OTC_JYXZ'
 AND            T3.YXT = 'OTC'
 AND            T3.YDM = CAST(T.JYXZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T4
 ON             T4.DMLX = 'OTC_JSFS'
 AND            T4.YXT = 'OTC'
 AND            T4.YDM = CAST(T.JSFS AS VARCHAR(20))
 LEFT JOIN     EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T5 
 ON             T5.DMLX = 'OTC_SFFS'
 AND            T5.YXT = 'OTC'
 AND            T5.YDM = CAST(T.SFFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T6  
 ON             T6.DMLX = 'OTC_JESHCLFS'
 AND            T6.YXT = 'OTC'
 AND            T6.YDM = CAST(T.JESHCLFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T7 
 ON             T7.DMLX = 'OF_FHFS'
 AND            T7.YXT = 'OTC'
 AND            T7.YDM = CAST(T.FHFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T8
 ON             T8.DMLX = 'OTC_DJYY'
 AND            T8.YXT = 'OTC'
 AND            T8.YDM = CAST(T.DJYY AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T9
 ON             T9.DMLX = 'BZDM'
 AND            T9.YXT = 'OTC'
 AND            T9.YDM = CAST(T.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T10 
 ON             T10.DMLX = 'OTC_CLBZ'
 AND            T10.YXT = 'OTC'
 AND            T10.YDM = CAST(T.CLBZ AS VARCHAR(20))
 --LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T11
 --ON             T11.DMLX = 'TZPZ'
 --AND            T11.YXT = 'OTC'
 --AND            T11.YDM = CAST(T.KHTZPZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T13
 ON             T13.DMLX = 'FXCSNL'
 AND            T13.YXT = 'OTC'
 AND            T13.YDM = CAST(T.FXCSNL AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T14
 ON             T14.DMLX = 'ZFFS'
 AND            T14.YXT = 'OTC'
 AND            T14.YDM = CAST(T.ZFFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T15
 ON             T15.DMLX = 'TZQX'
 AND            T15.YXT = 'OTC'
 AND            T15.YDM = CAST(T.CPTZQX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			T16
 ON             T16.DMLX = 'OTC_CPFXPJ'
 AND            T16.YXT = 'OTC'
 AND            T16.YDM = CAST(T.CPFXPJ AS VARCHAR(20))
 ;
 
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TFP_WTLS_LS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_TFP_WTLS_LS;
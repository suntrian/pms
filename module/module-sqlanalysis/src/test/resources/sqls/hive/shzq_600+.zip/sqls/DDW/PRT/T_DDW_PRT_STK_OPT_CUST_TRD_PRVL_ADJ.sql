 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:股票期权客户交易权限调整表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2017-03-09                                                                       */ 


--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_STK_OPT_CUST_TRD_PRVL_ADJ
(
								  BRH_NO               --营业部编号
								 ,BRH_NAME             --营业部名称
								 ,ADJ_DT               --调整日期
								 ,CUST_NO              --客户号
								 ,CUST_NAME            --客户姓名
								 ,BIZ_SBJ_NAME         --业务科目名称
								 ,OPRT_TELR            --操作柜员   
								 ,ABST                 --摘要
								 ,SRC                  --来源								
)		
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
								 t.BRH_NO  		    AS BRH_NO               --营业部编号 
								,t.BRH_NAME         AS BRH_NAME             --营业部名称
								,t.BUS_DATE         AS ADJ_DT               --调整日期
								,t.CUST_NO          AS CUST_NO              --客户号
								,t.CUST_NAME        AS CUST_NAME            --客户姓名 
								,t.BIZ_SBJ_NAME     AS BIZ_SBJ_NAME         --业务科目名称    
								,t.OPRT_TELR        AS OPRT_TELR            --操作柜员    
								,t.ABST             AS ABST                 --摘要
								,'CIF'              AS SRC                  --来源			
										 

  FROM  		DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS  	t
  LEFT JOIN     EDW_PROD.T_EDW_T01_TKHXX	                  a1
  ON            t.CUST_NO = a1.KHH 
  AND           t.BUS_DATE = a1.BUS_DATE  
  WHERE         t.BIZ_SBJ IN ('20813','20814','20815')
  AND         NOT EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS  a
                          WHERE  a.BIZ_SBJ = '20813' 
						  AND    t.CUST_NO = a.CUST_NO
						  AND    a.ABST LIKE '%投资者分类%'
						  AND    a.ABST LIKE '%资金规模上限%'
						  AND    t.BIZ_SBJ = a.BIZ_SBJ
						  AND    t.ABST = a.ABST						     
						  )
 AND          t.DT > GGQQKH_KHRQ
  AND          t.BUS_DATE = %d{yyyyMMdd}
 UNION ALL
  SELECT 
								 t.BRH_NO  		    AS BRH_NO               --营业部编号 
								,t.BRH_NAME         AS BRH_NAME             --营业部名称
								,t.BUS_DATE         AS ADJ_DT               --调整日期
								,t.CUST_NO          AS CUST_NO              --客户号
								,t.CUST_NAME        AS CUST_NAME            --客户姓名 
								,t.SBJ_NAME         AS BIZ_SBJ_NAME         --业务科目名称    
								,t.OPRT_TELR        AS OPRT_TELR            --操作柜员    
								,t.ABST             AS ABST                 --摘要
								,'JZJY'             AS SRC                  --来源			
										 

  FROM  		DDW_PROD.T_DDW_F00_CUST_TRD_SRC_OPE_DETAIL_HIS  	t
  LEFT JOIN     EDW_PROD.T_EDW_T01_TKHXX	                  a1
  ON            t.CUST_NO = a1.KHH 
  AND           t.BUS_DATE = a1.BUS_DATE  
  WHERE         (t.BIZ_SBJ = '20615' OR (t.BIZ_SBJ ='20611' AND (t.ABST LIKE '%额度%' OR t.ABST LIKE '%风险等级%')))
  AND         NOT EXISTS (SELECT 1 FROM DDW_PROD.t_ddw_f00_cust_trd_src_ope_detail_his a
                          WHERE  a.BIZ_SBJ = '20615' 
						  AND    t.CUST_NO = a.CUST_NO
						  AND    a.OPRT_TELR = '施霭云'
						  AND    a.SYS_SRC = 'GGQQ'
						  AND    t.BIZ_SBJ = a.BIZ_SBJ
						  AND    t.OPRT_TELR = a.OPRT_TELR
						  )
 AND          t.DT > GGQQKH_KHRQ 
 AND          t.SYS_SRC = 'GGQQ'
 AND          t.BUS_DATE = %d{yyyyMMdd}
						  
  ;

 
-----------------------------加载结束--------------------
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_STK_OPT_CUST_TRD_PRVL_ADJ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_STK_OPT_CUST_TRD_PRVL_ADJ;
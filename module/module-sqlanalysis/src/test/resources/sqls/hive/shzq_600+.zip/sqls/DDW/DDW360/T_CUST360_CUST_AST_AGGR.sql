 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360客户资产汇总表                                                                      */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-10-19                                                                        */ 
  /* T_DDW_F01_CUST_INFO 替换为 T_DDW_F00_CUST_CUST_INFO                                               */
  /* T_DDW_F02_SEC_HLD_DTL  替换为 T_DDW_F00_AST_SEC_HLD_DTL_HIS                                              */
/*   T_DDW_F02_WRNT_HLD_DTL  替换为 T_DDW_F00_AST_WRNT_HLD_DTL_HIS                                  */
/*   T_DDW_F02_PROD_HLD_DTL  替换为 T_DDW_F00_AST_PROD_HLD_DTL_HIS                                         * /
/*   T_DDW_F02_ACCNT_CPTL_BAL_INFO	替换为	T_DDW_F00_AST_CPTL_BAL_HIS                          */
/*   T_DDW_F02_CRD_ACCNT_GL_DTL 替换为 T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS                        */
/*   T_DDW_F02_ORDI_ACCNT_GL_DTL 替换为 T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS            */
/*   T_DDW_F04_QOT 替换为 T_DDW_PUB_QOT */

---------------- 插入数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_CUST_AST_AGGR
 (
	 CUST_NO                         --客户号
	,TOL_AST                         --总资产
	,CRD_TOL_AST                     --信用账户资产
	,WRNT_TOL_AST                    --期权账户资产
	,ORDI_TOL_AST_RMB                --普通账户资产-RMB
	,ORDI_TOL_AST_HKD                --普通账户资产-HKD
	,ORDI_TOL_AST_USD                --普通账户资产-USD
 )PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT      t.CUST_NO                  as CUST_NO                         --客户号
            ,NVL(a1.ORDT_SEC_NEWST_MKTVAL,0)+NVL(a2.CRD_SEC_NEWST_MKTVAL_RMB,0)+NVL(a3.WRNT_NEWST_MKTVAL_RMB,0)
             +NVL(a4.PROD_NEWST_MKTVAL_RMB,0)+NVL(a5.ORDT_ACCNT_BAL,0)+NVL(a6.WRNT_ACCNT_BAL_RMB,0)+NVL(a7.CRD_ACCNT_BAL_RMB,0)
             +NVL(a8.CRD_ACCNT_GL,0)+NVL(a9.ORDI_ACCNT_GL,0)-NVL(a10.ORDT_SEC_NEWST_MKTVAL,0)-NVL(a10.CRD_SEC_NEWST_MKTVAL,0)
             as TOL_AST                         --总资产
            ,NVL(a2.CRD_SEC_NEWST_MKTVAL_RMB,0)+NVL(a7.CRD_ACCNT_BAL_RMB,0)+NVL(a8.CRD_ACCNT_GL,0)-NVL(a10.CRD_SEC_NEWST_MKTVAL,0) as CRD_TOL_AST                     --信用账户资产
            ,NVL(a3.WRNT_NEWST_MKTVAL_RMB,0)+NVL(a6.WRNT_ACCNT_BAL_RMB,0) as WRNT_TOL_AST                    --期权账户资产
           ,NVL(a1.ORDT_SEC_NEWST_MKTVAL_RMB,0)
            +NVL(a4.PROD_NEWST_MKTVAL_RMB,0)+NVL(a5.ORDT_ACCNT_BAL_RMB,0)
            +NVL(a9.ORDI_ACCNT_GL,0)-NVL(a10.ORDT_SEC_NEWST_MKTVAL,0)
           as RDI_TOL_AST_RMB                --普通账户资产-RMB
          ,NVL(a1.ORDT_SEC_NEWST_MKTVAL_HKD,0)+NVL(a5.ORDT_ACCNT_BAL_HKD,0)   as ORDI_TOL_AST_HKD                --普通账户资产-HKD
          ,NVL(a1.ORDT_SEC_NEWST_MKTVAL_USD,0) +NVL(a5.ORDT_ACCNT_BAL_USD,0)  as ORDI_TOL_AST_USD                --普通账户资产-USD
 FROM         DDW_PROD.T_DDW_F00_CUST_CUST_INFO t
 LEFT JOIN   (SELECT  a.CUST_NO
                      ,SUM(DECODE(a.CCY_CD,'RMB',a.SEC_MKTVAL,0)) as ORDT_SEC_NEWST_MKTVAL_RMB 
                      ,SUM(DECODE(a.CCY_CD,'HKD',a.SEC_MKTVAL,0)) as ORDT_SEC_NEWST_MKTVAL_HKD
                      ,SUM(DECODE(a.CCY_CD,'USD',a.SEC_MKTVAL,0)) as ORDT_SEC_NEWST_MKTVAL_USD
                      ,SUM(ROUND(CASE WHEN b.BZDM IS NOT NULL 
                                      THEN a.SEC_MKTVAL*b.ZHHL
                                      WHEN b.BZDM IS  NULL 
                                      THEN a.SEC_MKTVAL
                                      ELSE 0
                                      END,2)
						   ) as ORDT_SEC_NEWST_MKTVAL
              FROM           DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS             a
              LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH        b
              ON             a.CCY_CD = b.BZDM
              AND            a.BUS_DATE = b.BUS_DATE
              WHERE          a.BUS_DATE = %d{yyyyMMdd}  
              AND            A.SYS_SRC = '普通账户'    
              GROUP BY      a.CUST_NO
              )                  a1
 ON          t.CUST_NO = a1.CUST_NO
 LEFT JOIN  (SELECT      a.CUST_NO
                         ,SUM(DECODE(a.CCY_CD,'RMB',sec_mktval,0)) as CRD_SEC_NEWST_MKTVAL_RMB                   
             FROM       DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS a
             WHERE      a.BUS_DATE = %d{yyyyMMdd}  
             AND        A.SYS_SRC = '信用账户'    
             GROUP BY   a.CUST_NO
            )                    a2
 ON         t.CUST_NO = a2.CUST_NO
 LEFT JOIN  (SELECT     a.CUST_NO
                       ,SUM(DECODE(a.CCY_CD,'RMB',A.WRNT_NEWST_MKTVAL,0)) as WRNT_NEWST_MKTVAL_RMB                   
             FROM       DDW_PROD.T_DDW_F00_AST_WRNT_HLD_DTL_HIS a
             WHERE       a.BUS_DATE = %d{yyyyMMdd}    
             GROUP BY    a.CUST_NO
            )                    a3
 ON         t.CUST_NO = a3.CUST_NO 
 LEFT JOIN  (SELECT     a.CUST_NO
                       ,SUM(DECODE(a.CCY_CD,'RMB',a.PROD_NEWST_MKTVAL,0)) as PROD_NEWST_MKTVAL_RMB                   
             FROM       DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS a
             WHERE      a.BUS_DATE = %d{yyyyMMdd}      
             GROUP BY   a.CUST_NO
             )             a4
 ON         t.CUST_NO = a4.CUST_NO
 LEFT JOIN  (SELECT    a.CUST_NO
                     ,SUM(DECODE(a.CCY_CD,'RMB',a.ACCNT_BAL,0)) as ORDT_ACCNT_BAL_RMB 
                     ,SUM(DECODE(a.CCY_CD,'HKD',a.ACCNT_BAL,0)) as ORDT_ACCNT_BAL_HKD
                     ,SUM(DECODE(a.CCY_CD,'USD',a.ACCNT_BAL,0)) as ORDT_ACCNT_BAL_USD
                     ,SUM(ROUND(CASE WHEN b.BZDM IS NOT NULL 
                                     THEN a.ACCNT_BAL*b.ZHHL
                                     WHEN b.BZDM IS  NULL 
                                     THEN a.ACCNT_BAL
                                     ELSE 0
                                     END,2)
						  ) as ORDT_ACCNT_BAL
            FROM         DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS a
            LEFT JOIN    EDW_PROD.T_EDW_T99_HLZH      b
            ON           a.CCY_CD = b.BZDM
            AND          a.BUS_DATE = b.BUS_DATE
            WHERE        a.BUS_DATE = %d{yyyyMMdd}
            AND          a.SYS_SRC = '普通账户'
            GROUP BY     CUST_NO 
            )                        a5
 ON      t.CUST_NO = a5.CUST_NO
 LEFT JOIN  (SELECT    a.CUST_NO
                      ,SUM(DECODE(a.CCY_CD,'RMB',a.ACCNT_BAL,0)) as WRNT_ACCNT_BAL_RMB                   
             FROM      DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS a 
             WHERE     a.BUS_DATE = %d{yyyyMMdd}
             AND       a.SYS_SRC = '期权账户'
             GROUP BY  CUST_NO 
            )                         a6
 ON      t.CUST_NO = a6.CUST_NO
 LEFT JOIN  (SELECT    a.CUST_NO
                       ,SUM(DECODE(a.CCY_CD,'RMB',a.ACCNT_BAL,0)) as CRD_ACCNT_BAL_RMB                   
             FROM       DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS a 
             WHERE     a.BUS_DATE = %d{yyyyMMdd}
             AND       a.SYS_SRC = '信用账户'
             GROUP BY  CUST_NO 
            )                       a7
 ON       t.CUST_NO = a7.CUST_NO
 LEFT JOIN  (SELECT    SUM(0-CRD_ACCT_UN_GL_PRINP-CRD_ACCT_UN_PAY_GL_INT) as CRD_ACCNT_GL
                       ,CUST_NO 
             FROM      DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS a   
             WHERE     a.BUS_DATE = %d{yyyyMMdd}
             GROUP BY  CUST_NO
             )                             a8
 ON          t.CUST_NO = a8.CUST_NO
 LEFT JOIN (SELECT      SUM(0-ORDI_ACCT_GL_PRINP-ORDI_ACCT_GL_TOT_PRINP) as ORDI_ACCNT_GL
                        ,CUST_NO 
            FROM       DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS a   
            WHERE      a.BUS_DATE = %d{yyyyMMdd}
            GROUP BY   CUST_NO
            )                             a9
 ON         t.CUST_NO = a9.CUST_NO
 LEFT JOIN   (SELECT     a.KHH      as CUST_NO
                        ,SUM(CASE WHEN a.XTBS = 'JZJY'
                                  THEN NVL(ROUND((b.NEWST_PRC+b.NEWST_INT*b.NETPRC_TRD_FLG)*b.TRD_UNIT*a.CJSL,2),0)
                                  ELSE 0
                                  END 
                            ) as ORDT_SEC_NEWST_MKTVAL
                       ,SUM(CASE WHEN a.XTBS = 'RZRQ'
                                 THEN NVL(ROUND((b.NEWST_PRC+b.NEWST_INT*b.NETPRC_TRD_FLG)*b.TRD_UNIT*a.CJSL,2),0)
                                 ELSE 0
                                 END 
                           ) as CRD_SEC_NEWST_MKTVAL         
             FROM     (SELECT    KHH,ZQDM,SUM(CJSL) as CJSL,JYS,BUS_DATE,XTBS  
                        FROM     EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
                        WHERE    BUS_DATE = %d{yyyyMMdd}
                        AND      JYS = 'SZ'
                        AND   WTLB = 16
                      GROUP BY KHH,ZQDM,JYS,BUS_DATE,xtbs
                       ) a
            LEFT JOIN   DDW_PROD.T_DDW_PUB_QOT         b
            ON          a.JYS = b.EXG
            AND         a.ZQDM = b.CD
            AND         a.BUS_DATE = b.BUS_DATE
            GROUP BY    CUST_NO
           )                                         a10
 ON        t.CUST_NO = a10.CUST_NO
 WHERE T.BUS_DATE =  %d{yyyyMMdd}
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_CUST_AST_AGGR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_CUST_AST_AGGR;
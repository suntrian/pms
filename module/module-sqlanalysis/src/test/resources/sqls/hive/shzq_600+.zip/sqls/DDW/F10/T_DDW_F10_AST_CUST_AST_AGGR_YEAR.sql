------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户资产汇总年表                                                                    */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

----------创建期初的临时表 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP	;
 CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP as
  SELECT  CUST_NO                                --客户号                          
         ,a.STRT_MKTVAL_HA                           as YRBGN_MKTVAL_HA                         --年初市值_沪A主板
         ,a.STRT_MKTVAL_SA                           as YRBGN_MKTVAL_SA                         --年初市值_深A主板
         ,a.STRT_MKTVAL_SMS                          as YRBGN_MKTVAL_SMS                        --年初市值_中小板
         ,a.STRT_MKTVAL_GEM                          as YRBGN_MKTVAL_GEM                        --年初市值_创业板		 
         ,a.STRT_MKTVAL_HB_USD                       as YRBGN_MKTVAL_HB_USD                     --年初市值_沪B_美元
		 ,a.STRT_MKTVAL_SB_HKD                       as YRBGN_MKTVAL_SB_HKD                     --年初市值_深B_港币
         ,a.STRT_MKTVAL_HK                           as YRBGN_MKTVAL_HK                         --年初市值_沪港通
		 ,a.STRT_MKTVAL_SK                           as YRBGN_MKTVAL_SK                         --年初市值_深港通
         ,a.STRT_MKTVAL_TA                           as YRBGN_MKTVAL_TA                         --年初市值_三板A股
		 ,a.STRT_MKTVAL_TU_USD                       as YRBGN_MKTVAL_TU_USD                     --年初市值_三板B股_美元
         ,a.STRT_MKTVAL_REPO                         as YRBGN_MKTVAL_REPO                       --年初市值_回购
         ,a.STRT_MKTVAL_EXG_FND                      as YRBGN_MKTVAL_EXG_FND                    --年初市值_场内基金	      		 
		 ,a.STRT_MKTVAL_CLS_FND                      as YRBGN_MKTVAL_CLS_FND                    --年初市值_封闭式基金
         ,a.STRT_MKTVAL_ETF_FND                      as YRBGN_MKTVAL_ETF_FND                    --年初市值_ETF		
         ,a.STRT_MKTVAL_OPN_FND                      as YRBGN_MKTVAL_OPN_FND                    --年初市值_开放式
         ,a.STRT_MKTVAL_LOF_FND                      as YRBGN_MKTVAL_LOF_FND                    --年初市值_LOF	
	     ,a.STRT_MKTVAL_FOF_FND                      as YRBGN_MKTVAL_FOF_FND                    --年初市值_FOF	
         ,a.STRT_MKTVAL_BOND                         as YRBGN_MKTVAL_BOND                       --年初市值_债券	
         ,a.STRT_AGN_FND_MKTVAL                      as YRBGN_AGN_FND_MKTVAL                    --年初代销基金市值
         ,a.STRT_GS_PROD_MKTVAL                      as YRBGN_GS_PROD_MKTVAL                    --年初公司产品市值
         ,a.STRT_GJ_PROD_MKTVAL                      as YRBGN_GJ_PROD_MKTVAL                    --年初国君产品市值        		 	
         ,a.STRT_BANK_PROD_MKTVAL                    as YRBGN_BANK_PROD_MKTVAL                  --年初银行产品市值	 
         ,a.STRT_OTC_PROD_MKTVAL                     as YRBGN_OTC_PROD_MKTVAL                   --年初OTC产品市值    		 
		 ,a.STRT_WRNT_RGHT_HLD_MKTVAL                as YRBGN_WRNT_RGHT_HLD_MKTVAL              --年初期权账户权利仓市值	
         ,a.STRT_WRNT_DUTY_HLD_MKTVAL                as YRBGN_WRNT_DUTY_HLD_MKTVAL              --年初期权账户义务仓市值
		 ,a.STRT_ORDI_MKTVAL_SEC_USD                 as YRBGN_ORDI_MKTVAL_SEC_USD               --年初普通账户证券市值_美元	
		 ,a.STRT_ORDI_MKTVAL_SEC_HKD                 as YRBGN_ORDI_MKTVAL_SEC_HKD               --年初普通账户证券市值_港币	
         ,a.STRT_ORDI_MKTVAL_SEC_RMD                 as YRBGN_ORDI_MKTVAL_SEC_RMD               --年初普通账户证券市值_人民币		
         ,a.STRT_ORDI_MKTVAL_PROD                    as YRBGN_ORDI_MKTVAL_PROD                  --年初普通账户产品市值			 
         ,a.STRT_ORDI_SEC_MKTVAL                     as YRBGN_ORDI_SEC_MKTVAL                   --年初普通账户证券市值(折算人民币)
         ,a.STRT_ORDI_MKTVAL                         as YRBGN_ORDI_MKTVAL                       --年初普通账户市值 
         ,a.STRT_ORDI_UN_CIR_MKTVAL                  as YRBGN_ORDI_UN_CIR_MKTVAL                --年初普通账户非流通市值(折算人民币)       
		 ,a.STRT_CRD_SEC_MKTVAL                      as YRBGN_CRD_SEC_MKTVAL                    --年初信用账户证券市值
         ,a.STRT_WRNT_MKTVAL                         as YRBGN_WRNT_MKTVAL                       --年初期权账户市值(权利仓市值-义务仓市值)		
		 ,a.STRT_WRNT_CNTS                           as YRBGN_WRNT_CNTS                         --年初期权账户张数	
         ,a.STRT_TOT_MKTVAL                          as YRBGN_TOT_MKTVAL                        --年初总市值		
         ,a.STRT_ORDI_CPTL_USD                       as YRBGN_ORDI_CPTL_USD                     --年初普通账户资金_美元	
         ,a.STRT_ORDI_CPTL_HKD                       as YRBGN_ORDI_CPTL_HKD                     --年初普通账户资金_港币	
		 ,a.STRT_ORDI_CPTL_RMB                       as YRBGN_ORDI_CPTL_RMB                     --年初普通账户资金_人民币		
		 ,a.STRT_ORDI_CPTL                           as YRBGN_ORDI_CPTL                         --年初普通账户资金(折算人民币)		
		 ,a.STRT_CRD_CPTL                            as YRBGN_CRD_CPTL                          --年初信用账户资金
		 ,a.STRT_WRNT_CPTL                           as YRBGN_WRNT_CPTL                         --年初期权账户资金	
		 ,a.STRT_TOT_UNPY_CPTL                       as YRBGN_TOT_UNPY_CPTL                     --年初总的在途资金		
         ,a.STRT_TOT_CPTL                            as YRBGN_TOT_CPTL                          --年初总资金		 
		 ,a.STRT_ORDI_GL                             as YRBGN_ORDI_GL                           --年初普通账户负债
         ,a.STRT_CRD_GL                              as YRBGN_CRD_GL                            --年初信用账户负债 		 
         ,a.STRT_TOTGL                               as YRBGN_TOTGL                             --年初总负债	 
		 ,a.STRT_ORDI_AST                            as YRBGN_ORDI_AST                          --年初普通资产	  
		 ,a.STRT_ORDI_NET_AST                        as YRBGN_ORDI_NET_AST                      --年初普通净资产
		 ,a.STRT_CRD_AST                             as YRBGN_CRD_AST                           --年初信用资产	 
		 ,a.STRT_WRNT_AST                            as YRBGN_WRNT_AST                          --年初期权资产
		 ,a.STRT_TOT_AST                             as YRBGN_TOT_AST                           --年初总资产
		 ,a.STRT_NET_TOT_AST                         as YRBGN_NET_TOT_AST                       --年初净总资产
		 ,a.STRT_EXG_NET_TOT_AST                     as YRBGN_EXG_NET_TOT_AST                   --年初场内净总资产    	   	   
	     ,a.STRT_ORDI_MKTVAL_NEW_TA                  as YRBGN_ORDI_MKTVAL_NEW_TA                --年初普通账户市值_新三板A股
         ,a.STRT_STK_PLG_AMT                         as YRBGN_STK_PLG_AMT                       --年初股票质押余额
         ,a.STRT_MIN_STK_PLG_AMT                     as YRBGN_MIN_STK_PLG_AMT                   --年初小微贷余额		 
	     ,a.STRT_ORDI_MKTVAL_EXG_FND_SH              as YRBGN_ORDI_MKTVAL_EXG_FND_SH            --年初普通账户市值_场内基金_沪市
         ,a.STRT_ORDI_MKTVAL_EXG_FND_SZ              as YRBGN_ORDI_MKTVAL_EXG_FND_SZ            --年初普通账户市值_场内基金_深市
         ,a.STRT_CRD_MKTVAL_EXG_FND_SH               as YRBGN_CRD_MKTVAL_EXG_FND_SH             --年初信用账户市值_场内基金_沪市
         ,a.STRT_CRD_MKTVAL_EXG_FND_SZ               as YRBGN_CRD_MKTVAL_EXG_FND_SZ             --年初信用账户市值_场内基金_深市
         ,a.STRT_ORDI_MKTVAL_BOND_SH                 as YRBGN_ORDI_MKTVAL_BOND_SH               --年初普通账户市值_债券_沪市
         ,a.STRT_ORDI_MKTVAL_BOND_SZ                 as YRBGN_ORDI_MKTVAL_BOND_SZ               --年初普通账户市值_债券_深市
         ,a.STRT_CRD_MKTVAL_BOND_SH                  as YRBGN_CRD_MKTVAL_BOND_SH                --年初信用账户市值_债券_沪市
         ,a.STRT_CRD_MKTVAL_BOND_SZ                  as YRBGN_CRD_MKTVAL_BOND_SZ                --年初信用账户市值_债券_深市
         ,a.STRT_ORDI_UN_CIR_MKTVAL_SH               as YRBGN_ORDI_UN_CIR_MKTVAL_SH             --年初普通账户沪市非流通市值(折算人民币)
         ,a.STRT_ORDI_UN_CIR_MKTVAL_SZ               as YRBGN_ORDI_UN_CIR_MKTVAL_SZ             --年初普通账户深市非流通市值(折算人民币)
         ,a.STRT_ORDI_MKTVAL_AK_STIB                 as YRBGN_ORDI_MKTVAL_AK_STIB               --年初普通账户市值_AK科创板
         ,a.STRT_ORDI_MKTVAL_RK_STIB                 as YRBGN_ORDI_MKTVAL_RK_STIB               --年初普通账户市值_RK科创CDR
         ,a.STRT_CRD_MKTVAL_AK_STIB                  as YRBGN_CRD_MKTVAL_AK_STIB                --年初信用账户市值_AK科创板
         ,a.STRT_CRD_MKTVAL_RK_STIB                  as YRBGN_CRD_MKTVAL_RK_STIB                --年初信用账户市值_RK科创CDR
	     ,a.STRT_WRNT_RGHT_HLD_MKTVAL_SH             as YRBGN_WRNT_RGHT_HLD_MKTVAL_SH   --年初期权账户权利仓市值(SH)
         ,a.STRT_WRNT_DUTY_HLD_MKTVAL_SH             as YRBGN_WRNT_DUTY_HLD_MKTVAL_SH   --年初期权账户义务仓市值(SH)      
         ,a.STRT_WRNT_MKTVAL_SH                      as YRBGN_WRNT_MKTVAL_SH            --年初期权账户市值(权利仓市值-义务仓市值)(SH)	
         ,a.STRT_WRNT_CNTS_SH                        as YRBGN_WRNT_CNTS_SH              --年初期权张数(SH)
         ,a.STRT_WRNT_RGHT_HLD_MKTVAL_SZ             as YRBGN_WRNT_RGHT_HLD_MKTVAL_SZ   --年初期权账户权利仓市值(SZ)
         ,a.STRT_WRNT_DUTY_HLD_MKTVAL_SZ             as YRBGN_WRNT_DUTY_HLD_MKTVAL_SZ   --年初期权账户义务仓市值(SZ)      
         ,a.STRT_WRNT_MKTVAL_SZ                      as YRBGN_WRNT_MKTVAL_SZ            --年初期权账户市值(权利仓市值-义务仓市值)(SZ)	
         ,a.STRT_WRNT_CNTS_SZ                        as YRBGN_WRNT_CNTS_SZ              --年初期权张数(SZ)
	   FROM        DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON    a
	  WHERE  EXISTS(SELECT 1 FROM (SELECT MIN(YEAR_MTH) as YEAR_MON 
                                    FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                       WHERE   SUBSTR(CAST(TRD_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
			                       AND BUS_DATE = %d{yyyyMMdd}
				                   )  b
                     WHERE  a.YEAR_MON = b.YEAR_MON
				      )
       ;	   
----------创建期末的临时表 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP1	;
 CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP1 as
  SELECT  CUST_NO                                --客户号                          
         ,a.MKTVAL_HA                                          as YREND_MKTVAL_HA                         --年末市值_沪A主板
         ,a.MKTVAL_SA                                          as YREND_MKTVAL_SA                         --年末市值_深A主板
         ,a.MKTVAL_SMS                                         as YREND_MKTVAL_SMS                        --年末市值_中小板
         ,a.MKTVAL_GEM                                         as YREND_MKTVAL_GEM                        --年末市值_创业板		 
         ,a.ORDI_MKTVAL_HB_USD                                 as YREND_MKTVAL_HB_USD                     --年末市值_沪B_美元
		 ,a.ORDI_MKTVAL_SB_HKD                                 as YREND_MKTVAL_SB_HKD                     --年末市值_深B_港币
         ,a.ORDI_MKTVAL_HK                                     as YREND_MKTVAL_HK                         --年末市值_沪港通
		 ,a.ORDI_MKTVAL_SK                                     as YREND_MKTVAL_SK                         --年末市值_深港通
         ,a.ORDI_MKTVAL_TA                                     as YREND_MKTVAL_TA                         --年末市值_三板A股
		 ,a.ORDI_MKTVAL_TU_USD                                 as YREND_MKTVAL_TU_USD                     --年末市值_三板B股_美元
         ,a.ORDI_MKTVAL_REPO                                   as YREND_MKTVAL_REPO                       --年末市值_回购
         ,a.ORDI_MKTVAL_EXG_FND + a.CRD_MKTVAL_EXG_FND         as YREND_MKTVAL_EXG_FND                    --年末市值_场内基金	      		 
		 ,a.ORDI_MKTVAL_CLS_FND + a.CRD_MKTVAL_CLS_FND         as YREND_MKTVAL_CLS_FND                    --年末市值_封闭式基金
         ,a.ORDI_MKTVAL_ETF_FND + a.CRD_MKTVAL_ETF_FND         as YREND_MKTVAL_ETF_FND                    --年末市值_ETF		
         ,a.ORDI_MKTVAL_OPN_FND + a.CRD_MKTVAL_OPN_FND         as YREND_MKTVAL_OPN_FND                    --年末市值_开放式
         ,a.ORDI_MKTVAL_LOF_FND + a.CRD_MKTVAL_LOF_FND         as YREND_MKTVAL_LOF_FND                    --年末市值_LOF	
	     ,a.ORDI_MKTVAL_FOF_FND + a.CRD_MKTVAL_FOF_FND         as YREND_MKTVAL_FOF_FND                    --年末市值_FOF	
         ,a.ORDI_MKTVAL_BOND+a.CRD_MKTVAL_BOND                 as YREND_MKTVAL_BOND                       --年末市值_债券	
         ,a.AGN_FND_MKTVAL                                     as YREND_AGN_FND_MKTVAL                    --年末代销基金市值
         ,a.GS_PROD_MKTVAL                                     as YREND_GS_PROD_MKTVAL                    --年末公司产品市值
         ,a.GJ_PROD_MKTVAL                                     as YREND_GJ_PROD_MKTVAL                    --年末国君产品市值        		 	
         ,a.BANK_PROD_MKTVAL                                   as YREND_BANK_PROD_MKTVAL                  --年末银行产品市值	 
         ,a.OTC_PROD_MKTVAL                                    as YREND_OTC_PROD_MKTVAL                   --年末OTC产品市值    		 
		 ,a.WRNT_RGHT_HLD_MKTVAL                               as YREND_WRNT_RGHT_HLD_MKTVAL              --年末期权账户权利仓市值	
         ,a.WRNT_DUTY_HLD_MKTVAL                               as YREND_WRNT_DUTY_HLD_MKTVAL              --年末期权账户义务仓市值
		 ,a.ORDI_MKTVAL_SEC_USD                                as YREND_ORDI_MKTVAL_SEC_USD               --年末普通账户证券市值_美元	
		 ,a.ORDI_MKTVAL_SEC_HKD                                as YREND_ORDI_MKTVAL_SEC_HKD               --年末普通账户证券市值_港币	
         ,a.ORDI_MKTVAL_SEC_RMD                                as YREND_ORDI_MKTVAL_SEC_RMD               --年末普通账户证券市值_人民币		
         ,a.ORDI_MKTVAL_PROD                                   as YREND_ORDI_MKTVAL_PROD                  --年末普通账户产品市值			 
         ,a.ORDI_SEC_MKTVAL                                    as YREND_ORDI_SEC_MKTVAL                   --年末普通账户证券市值(折算人民币)
         ,a.ORDI_MKTVAL                                        as YREND_ORDI_MKTVAL                       --年末普通账户市值 
         ,a.ORDI_UN_CIR_MKTVAL                                 as YREND_ORDI_UN_CIR_MKTVAL                --年末普通账户非流通市值(折算人民币)       
		 ,a.CRD_SEC_MKTVAL                                     as YREND_CRD_SEC_MKTVAL                    --年末信用账户证券市值
         ,a.WRNT_MKTVAL                                        as YREND_WRNT_MKTVAL                       --年末期权账户市值(权利仓市值-义务仓市值)		
		 ,a.WRNT_CNTS                                          as YREND_WRNT_CNTS                         --年末期权账户张数	
         ,a.TOT_MKTVAL                                         as YREND_TOT_MKTVAL                        --年末总市值		
         ,a.ORDI_CPTL_USD                                      as YREND_ORDI_CPTL_USD                     --年末普通账户资金_美元	
         ,a.ORDI_CPTL_HKD                                      as YREND_ORDI_CPTL_HKD                     --年末普通账户资金_港币	
		 ,a.ORDI_CPTL_RMB                                      as YREND_ORDI_CPTL_RMB                     --年末普通账户资金_人民币		
		 ,a.ORDI_CPTL                                          as YREND_ORDI_CPTL                         --年末普通账户资金(折算人民币)		
		 ,a.CRD_CPTL                                           as YREND_CRD_CPTL                          --年末信用账户资金
		 ,a.WRNT_CPTL                                          as YREND_WRNT_CPTL                         --年末期权账户资金	
		 ,a.TOT_UNPY_CPTL                                      as YREND_TOT_UNPY_CPTL                     --年末总的在途资金		
         ,a.TOT_CPTL                                           as YREND_TOT_CPTL                          --年末总资金		 
		 ,a.ORDI_GL                                            as YREND_ORDI_GL                           --年末普通账户负债
         ,a.CRD_GL                                             as YREND_CRD_GL                            --年末信用账户负债 		 
         ,a.TOTGL                                              as YREND_TOTGL                             --年末总负债	 
		 ,a.ORDI_AST                                           as YREND_ORDI_AST                          --年末普通资产	  
		 ,a.ORDI_NET_AST                                       as YREND_ORDI_NET_AST                      --年末普通净资产
		 ,a.CRD_AST                                            as YREND_CRD_AST                           --年末信用资产	 
		 ,a.WRNT_AST                                           as YREND_WRNT_AST                          --年末期权资产
		 ,a.TOT_AST                                            as YREND_TOT_AST                           --年末总资产
		 ,a.NET_TOT_AST                                        as YREND_NET_TOT_AST                       --年末净总资产
		 ,a.EXG_NET_TOT_AST                                    as YREND_EXG_NET_TOT_AST                   --年末场内净总资产    	   	   
	     ,a.ORDI_MKTVAL_NEW_TA                                 as YREND_ORDI_MKTVAL_NEW_TA                --年末普通账户市值_新三板A股
         ,a.STK_PLG_AMT                                        as YREND_STK_PLG_AMT                       --年末股票质押余额
         ,a.MIN_STK_PLG_AMT                                    as YREND_MIN_STK_PLG_AMT                   --年末小微贷余额
 	     ,a.ORDI_MKTVAL_EXG_FND_SH                             as YREND_ORDI_MKTVAL_EXG_FND_SH            --年末普通账户市值_场内基金_沪市
         ,a.ORDI_MKTVAL_EXG_FND_SZ                             as YREND_ORDI_MKTVAL_EXG_FND_SZ            --年末普通账户市值_场内基金_深市
         ,a.CRD_MKTVAL_EXG_FND_SH                              as YREND_CRD_MKTVAL_EXG_FND_SH             --年末信用账户市值_场内基金_沪市
         ,a.CRD_MKTVAL_EXG_FND_SZ                              as YREND_CRD_MKTVAL_EXG_FND_SZ             --年末信用账户市值_场内基金_深市
         ,a.ORDI_MKTVAL_BOND_SH                                as YREND_ORDI_MKTVAL_BOND_SH               --年末普通账户市值_债券_沪市
         ,a.ORDI_MKTVAL_BOND_SZ                                as YREND_ORDI_MKTVAL_BOND_SZ               --年末普通账户市值_债券_深市
         ,a.CRD_MKTVAL_BOND_SH                                 as YREND_CRD_MKTVAL_BOND_SH                --年末信用账户市值_债券_沪市
         ,a.CRD_MKTVAL_BOND_SZ                                 as YREND_CRD_MKTVAL_BOND_SZ                --年末信用账户市值_债券_深市
         ,a.ORDI_UN_CIR_MKTVAL_SH                              as YREND_ORDI_UN_CIR_MKTVAL_SH             --年末普通账户沪市非流通市值(折算人民币)
         ,a.ORDI_UN_CIR_MKTVAL_SZ                              as YREND_ORDI_UN_CIR_MKTVAL_SZ             --年末普通账户深市非流通市值(折算人民币)
         ,a.ORDI_MKTVAL_AK_STIB                                as YREND_ORDI_MKTVAL_AK_STIB               --年末普通账户市值_AK科创板
         ,a.ORDI_MKTVAL_RK_STIB                                as YREND_ORDI_MKTVAL_RK_STIB               --年末普通账户市值_RK科创CDR
         ,a.CRD_MKTVAL_AK_STIB                                 as YREND_CRD_MKTVAL_AK_STIB                --年末信用账户市值_AK科创板
         ,a.CRD_MKTVAL_RK_STIB                                 as YREND_CRD_MKTVAL_RK_STIB                --年末信用账户市值_RK科创CDR
          ,a.WRNT_RGHT_HLD_MKTVAL_SH                           as YREND_WRNT_RGHT_HLD_MKTVAL_SH               --年末期权账户权利仓市值(SH)
         ,a.WRNT_DUTY_HLD_MKTVAL_SH                            as YREND_WRNT_DUTY_HLD_MKTVAL_SH               --年末期权账户义务仓市值(SH)      
         ,a.WRNT_MKTVAL_SH                                     as YREND_WRNT_MKTVAL_SH                        --年末期权账户市值(权利仓市值-义务仓市值)(SH)	
         ,a.WRNT_CNTS_SH                                       as YREND_WRNT_CNTS_SH                          --年末期权张数(SH)
         ,a.WRNT_RGHT_HLD_MKTVAL_SZ                            as YREND_WRNT_RGHT_HLD_MKTVAL_SZ               --年末期权账户权利仓市值(SZ)
         ,a.WRNT_DUTY_HLD_MKTVAL_SZ                            as YREND_WRNT_DUTY_HLD_MKTVAL_SZ               --年末期权账户义务仓市值(SZ)      
         ,a.WRNT_MKTVAL_SZ                                     as YREND_WRNT_MKTVAL_SZ                        --年末期权账户市值(权利仓市值-义务仓市值)(SZ)	
         ,a.WRNT_CNTS_SZ                                       as YREND_WRNT_CNTS_SZ                          --年末期权张数(SZ)

	 FROM        DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    a
	   WHERE       a.BUS_DATE = %d{yyyyMMdd}
       ;	
-----------------------创建期月的临时表 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP2	;
 CREATE TABLE     DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP2 as
 SELECT   CUST_NO
          ,SUM(ORDI_DEPIN_AMT_USD)                     as ORDI_DEPIN_AMT_USD               --普通账户存入金额_美元
          ,SUM(ORDI_DEPIN_AMT_HKD)                     as ORDI_DEPIN_AMT_HKD               --普通账户存入金额_港币
          ,SUM(ORDI_DEPIN_AMT_RMB)                     as ORDI_DEPIN_AMT_RMB               --普通账户存入金额_人民币
          ,SUM(ORDI_TFR_IN_AMT)                        as ORDI_TFR_IN_AMT                  --普通账户转入金额(折算人民币)
          ,SUM(ORDI_WTHDR_AMT_USD)                     as ORDI_WTHDR_AMT_USD               --普通账户取出金额_美元
          ,SUM(ORDI_WTHDR_AMT_HKD)                     as ORDI_WTHDR_AMT_HKD               --普通账户取出金额_港币
          ,SUM(ORDI_WTHDR_AMT_RMB)                     as ORDI_WTHDR_AMT_RMB               --普通账户取出金额_人民币
          ,SUM(ORDI_TFR_OUT_AMT)                       as ORDI_TFR_OUT_AMT                 --普通账户转出金额(折算人民币)
          ,SUM(CRD_DEPIN_AMT)                          as CRD_DEPIN_AMT                    --信用账户存入金额
          ,SUM(CRD_TFR_IN_AMT)                         as CRD_TFR_IN_AMT                   --信用账户转入金额
          ,SUM(CRD_WTHDR_AMT)                          as CRD_WTHDR_AMT                    --信用账户取出金额
          ,SUM(CRD_TFR_OUT_AMT)                        as CRD_TFR_OUT_AMT                  --信用账户转出金额
          ,SUM(WRNT_DEPIN_AMT)                         as WRNT_DEPIN_AMT                   --期权账户存入金额
          ,SUM(WRNT_TFR_IN_AMT)                        as WRNT_TFR_IN_AMT                  --期权账户转入金额
          ,SUM(WRNT_WTHDR_AMT)                         as WRNT_WTHDR_AMT                   --期权账户取出金额
          ,SUM(WRNT_TFR_OUT_AMT)                       as WRNT_TFR_OUT_AMT                 --期权账户转出金额
          ,SUM(TFR_IN_AMT)                             as TFR_IN_AMT                       --转入资金
          ,SUM(TFR_OUT_AMT)                            as TFR_OUT_AMT                      --转出资金
          ,SUM(ORDI_NET_TFR_IN_AMT)                    as ORDI_NET_TFR_IN_AMT              --普通账户净转入资金
          ,SUM(CRD_NET_TFR_IN_AMT)                     as CRD_NET_TFR_IN_AMT               --信用账户净转入资金
          ,SUM(WRNT_NET_TFR_IN_AMT)                    as WRNT_NET_TFR_IN_AMT              --期权账户净转入资金
          ,SUM(NET_TFR_IN_AMT)                         as NET_TFR_IN_AMT                   --净转入资金
          ,SUM(ORDI_ASGN_TFR_IN_MKTVAL_RMB)            as ORDI_ASGN_TFR_IN_MKTVAL_RMB      --普通账户指定转入市值_人民币
          ,SUM(ORDI_ASGN_TFR_IN_MKTVAL_USD)            as ORDI_ASGN_TFR_IN_MKTVAL_USD      --普通账户指定转入市值_美元
          ,SUM(ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB)        as ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB  --普通账户转托管转入市值_人民币
          ,SUM(ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD)        as ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD  --普通账户转托管转入市值_港币
          ,SUM(CRD_ASGN_TFR_IN_MKTVAL)                 as CRD_ASGN_TFR_IN_MKTVAL           --信用账户指定转入市值		
          ,SUM(CRD_TFR_CSTD_TFR_IN_MKTVAL)             as CRD_TFR_CSTD_TFR_IN_MKTVAL       --信用账户转托管转入市值
          ,SUM(ORDI_ASGN_TFR_OUT_MKTVAL_RMB)           as ORDI_ASGN_TFR_OUT_MKTVAL_RMB     --普通账户撤指定转出市值_人民币
          ,SUM(ORDI_ASGN_TFR_OUT_MKTVAL_USD)           as ORDI_ASGN_TFR_OUT_MKTVAL_USD     --普通账户撤指定转出市值_美元
          ,SUM(ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB)       as ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB --普通账户转托管转出市值_人民币
          ,SUM(ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD)       as ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD --普通账户转托管转出市值_港币
          ,SUM(CRD_ASGN_TFR_OUT_MKTVAL)                as CRD_ASGN_TFR_OUT_MKTVAL          --信用账户指定转出市值		
          ,SUM(CRD_TFR_CSTD_TFR_OUT_MKTVAL)            as CRD_TFR_CSTD_TFR_OUT_MKTVAL      --信用账户转托管转出市值
          ,SUM(ORDI_TFR_IN_MKTVAL)                     as ORDI_TFR_IN_MKTVAL               --普通账户转入市值
          ,SUM(ORDI_TFR_OUT_MKTVAL)                    as ORDI_TFR_OUT_MKTVAL              --普通账户转出市值
          ,SUM(CRD_TFR_IN_MKTVAL)                      as CRD_TFR_IN_MKTVAL                --信用账户转入市值
          ,SUM(CRD_TFR_OUT_MKTVAL)                     as CRD_TFR_OUT_MKTVAL               --信用账户转出市值
          ,SUM(TFR_IN_MKTVAL)                          as TFR_IN_MKTVAL                    --转入市值
          ,SUM(TFR_OUT_MKTVAL)                         as TFR_OUT_MKTVAL                   --转出市值
          ,SUM(ORDI_NET_TFR_IN_MKTVAL)                 as ORDI_NET_TFR_IN_MKTVAL           --普通账户净转入市值
          ,SUM(CRD_NET_TFR_IN_MKTVAL)                  as CRD_NET_TFR_IN_MKTVAL            --信用账户净转入市值
          ,SUM(NET_TFR_IN_MKTVAL)                      as NET_TFR_IN_MKTVAL                --净转入市值		        
          ,SUM(ORDI_PRFT)                              as ORDI_PRFT                        --普通盈亏
          ,SUM(CRD_PRFT)                               as CRD_PRFT                         --信用盈亏
          ,SUM(WRNT_PRFT)                              as WRNT_PRFT                        --期权盈亏
          ,SUM(TOT_PRFT)                               as TOT_PRFT                         --总盈亏
		  ,AVG(ORDI_CPTL+ORDI_UNPY_CPTL)               as AVGDLY_ORDI_CPTL                 --日均普通账户资金
		  ,AVG(CRD_CPTL+CRD_UNPY_CPTL)                 as AVGDLY_CRD_CPTL                  --日均信用账户资金
		  ,AVG(WRNT_CPTL+WRNT_UNPY_CPTL)               as AVGDLY_WRNT_CPTL                 --日均期权账户资金
		  ,AVG(TOT_CPTL+TOT_UNPY_CPTL)                 as AVGDLY_TOT_CPTL                  --日均总资金		  
		  ,MAX(ORDI_CPTL+ORDI_UNPY_CPTL)               as MAX_ORDI_CPTL                    --当年普通账户最大资金
		  ,MAX(CRD_CPTL+CRD_UNPY_CPTL)                 as MAX_CRD_CPTL                     --当年信用账户最大资金
		  ,MAX(WRNT_CPTL+WRNT_UNPY_CPTL)               as MAX_WRNT_CPTL                    --当年期权账户最大资金
		  ,MAX(TOT_CPTL+TOT_UNPY_CPTL)                 as MAX_TOT_CPTL                     --当年最大总资金
		  ,MIN(ORDI_CPTL+ORDI_UNPY_CPTL)               as MIN_ORDI_CPTL                    --当年普通账户最小资金
		  ,MIN(CRD_CPTL+CRD_UNPY_CPTL)                 as MIN_CRD_CPTL                     --当年信用账户最小资金
		  ,MIN(WRNT_CPTL+WRNT_UNPY_CPTL)               as MIN_WRNT_CPTL                    --当年期权账户最小资金
		  ,MIN(TOT_CPTL+TOT_UNPY_CPTL)                 as MIN_TOT_CPTL                     --当年最小总资金		  
		  ,AVG(ORDI_MKTVAL)                            as AVGDLY_ORDI_MKTVAL                --日均普通账户市值
		  ,AVG(CRD_SEC_MKTVAL )                        as AVGDLY_CRD_MKTVAL                 --日均信用账户市值
		  ,AVG(WRNT_MKTVAL)                            as AVGDLY_WRNT_MKTVAL                --日均期权账户市值
		  ,AVG(TOT_MKTVAL)                             as AVGDLY_TOT_MKTVAL                 --日均总市值		  
		  ,MAX(ORDI_MKTVAL)                            as MAX_ORDI_MKTVAL                   --当年普通账户最大市值
		  ,MAX(CRD_SEC_MKTVAL )                        as MAX_CRD_MKTVAL                    --当年信用账户最大市值
		  ,MAX(WRNT_MKTVAL)                            as MAX_WRNT_MKTVAL                   --当年期权账户最大市值
		  ,MAX(TOT_MKTVAL)                             as MAX_TOT_MKTVAL                    --当年最大总市值	
		  ,MIN(ORDI_MKTVAL)                            as MIN_ORDI_MKTVAL                   --当年普通账户最小市值
		  ,MIN(CRD_SEC_MKTVAL )                        as MIN_CRD_MKTVAL                    --当年信用账户最小市值
		  ,MIN(WRNT_MKTVAL)                            as MIN_WRNT_MKTVAL                   --当年期权账户最小市值
		  ,MIN(TOT_MKTVAL)                             as MIN_TOT_MKTVAL                    --当年最小总市值          		  		  
		  ,AVG(ORDI_GL)                                as AVGDLY_ORDI_GL                    --日均普通账户负债
		  ,AVG(CRD_GL )                                as AVGDLY_CRD_GL                     --日均信用账户负债
		  ,AVG(TOTGL)                                  as AVGDLY_TOTGL                      --日均总负债
		  ,MAX(ORDI_GL)                                as MAX_ORDI_GL                       --当年普通账户最大负债
		  ,MAX(CRD_GL )                                as MAX_CRD_GL                        --当年信用账户最大负债
		  ,MAX(TOTGL)                                  as MAX_TOTGL                         --当年最大总负债
		  ,MIN(ORDI_GL)                                as MIN_ORDI_GL                       --当年普通账户最小负债
		  ,MIN(CRD_GL )                                as MIN_CRD_GL                        --当年信用账户最小负债
		  ,MIN(TOTGL)                                  as MIN_TOTGL                         --当年最小总负债
		  ,AVG(ORDI_AST)                               as AVGDLY_ORDI_AST                   --日均普通账户资产
		  ,AVG(CRD_AST)                                as AVGDLY_CRD_AST                    --日均信用账户资产
		  ,AVG(WRNT_AST)                               as AVGDLY_WRNT_AST                   --日均期权账户资产
		  ,AVG(TOT_AST)                                as AVGDLY_TOT_AST                    --日均总资产
		  ,MAX(ORDI_AST)                               as MAX_ORDI_AST                      --当年普通账户最大资产
		  ,MAX(CRD_AST)                                as MAX_CRD_AST                       --当年信用账户最大资产
		  ,MAX(WRNT_AST)                               as MAX_WRNT_AST                      --当年期权账户最大资产
		  ,MAX(TOT_AST)                                as MAX_TOT_AST                       --当年最大总资产
		  ,MIN(ORDI_AST)                               as MIN_ORDI_AST                      --当年普通账户最小资产
		  ,MIN(CRD_AST)                                as MIN_CRD_AST                       --当年信用账户最小资产
		  ,MIN(WRNT_AST)                               as MIN_WRNT_AST                      --当年期权账户最小资产
		  ,MIN(TOT_AST)                                as MIN_TOT_AST                       --当年最小总资产		  
		  ,AVG(ORDI_NET_AST)                           as AVGDLY_ORDI_NET_AST               --日均普通账户净资产
		  ,AVG(CRD_NET_AST)                            as AVGDLY_CRD_NET_AST                --日均信用账户净资产
		  ,AVG(WRNT_AST)                               as AVGDLY_WRNT_NET_AST               --日均期权账户净资产
		  ,AVG(NET_TOT_AST)                            as AVGDLY_TOT_NET_AST                --日均总净资产
		  ,MAX(ORDI_NET_AST)                           as MAX_ORDI_NET_AST                  --当年普通账户最大净资产
		  ,MAX(CRD_NET_AST)                            as MAX_CRD_NET_AST                   --当年信用账户最大净资产
		  ,MAX(WRNT_AST)                               as MAX_WRNT_NET_AST                  --当年期权账户最大净资产
		  ,MAX(NET_TOT_AST)                            as MAX_TOT_NET_AST                   --当年最大总净资产
		  ,MIN(ORDI_NET_AST)                           as MIN_ORDI_NET_AST                  --当年普通账户最小净资产
		  ,MIN(CRD_NET_AST)                            as MIN_CRD_NET_AST                   --当年信用账户最小净资产
		  ,MIN(WRNT_AST)                               as MIN_WRNT_NET_AST                  --当年期权账户最小净资产
		  ,MIN(NET_TOT_AST)                            as MIN_TOT_NET_AST                   --当年最小总净资产		  
		  ,AVG(EXG_NET_TOT_AST)                        as AVGDLY_EXG_NET_TOT_AST            --日均场内总净资产		  
		  ,MAX(EXG_NET_TOT_AST)                        as MAX_EXG_NET_TOT_AST               --当年场内最大总净资产
		  ,MIN(EXG_NET_TOT_AST)                        as MIN_EXG_NET_TOT_AST               --当年场内最小总净资产
		  ,SUM(STK_PLG_ADD_INT)                        as STK_PLG_ADD_INT                    --股票质押新增利息
          ,SUM(STK_PLG_ADD_TRD_AMT)                    as STK_PLG_ADD_TRD_AMT                --股票质押初始交易量
          ,SUM(MIN_STK_PLG_ADD_INT)                    as MIN_STK_PLG_ADD_INT                --小微贷新增利息
		  ,SUM(MIN_STK_PLG_ADD_TRD_AMT)                as MIN_STK_PLG_ADD_TRD_AMT            --小微贷初始交易量
		  
   FROM        DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    
   WHERE       SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
   GROUP BY    CUST_NO
       ;	
 
--------创建临时表3
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP3;
 CREATE TABLE  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP3 as
 SELECT    t.CUST_NO
           ,AVG(t.ORDI_CPTL+t.ORDI_UNPY_CPTL)       as AVGDLY_ORDI_CPTL1 
		   ,AVG(t.CRD_CPTL+t.CRD_UNPY_CPTL)         as AVGDLY_CRD_CPTL1  
		   ,AVG(t.WRNT_CPTL+t.WRNT_UNPY_CPTL)       as AVGDLY_WRNT_CPTL1 
		   ,AVG(t.TOT_CPTL+t.TOT_UNPY_CPTL)         as AVGDLY_CPTL1 
           ,AVG(t.STK_PLG_AMT)                      as AVGDLY_STK_PLG_AMT 
           ,AVG(t.MIN_STK_PLG_AMT)		            as AVGDLY_MIN_STK_PLG_AMT		   
 FROM        DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY   t
 LEFT  JOIN  EDW_PROD.T_EDW_T99_TRD_DATE                a1
 ON          t.BUS_DATE = a1.TRD_DT
 AND         a1.BUS_DATE = %d{yyyyMMdd}
 WHERE       SUBSTR(CAST(t.BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
 GROUP BY    t.CUST_NO  ;
 
 ------插入数据
  INSERT OVERWRITE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR
(        CUST_NO                                  --客户号                 
        ,BRH_NO                                     --营业部编号                         
        ,CUST_CGY		                            --客户类别
        ,YRBGN_MKTVAL_HA                            --年初市值_沪A主板
        ,YRBGN_MKTVAL_SA                            --年初市值_深A主板
        ,YRBGN_MKTVAL_SMS                           --年初市值_中小板
        ,YRBGN_MKTVAL_GEM                           --年初市值_创业板		 
        ,YRBGN_MKTVAL_HB_USD                        --年初市值_沪B_美元
        ,YRBGN_MKTVAL_SB_HKD                        --年初市值_深B_港币
        ,YRBGN_MKTVAL_HK                            --年初市值_沪港通
        ,YRBGN_MKTVAL_SK                            --年初市值_深港通
        ,YRBGN_MKTVAL_TA                            --年初市值_三板A股
        ,YRBGN_MKTVAL_TU_USD                        --年初市值_三板B股_美元
        ,YRBGN_MKTVAL_REPO                          --年初市值_回购
        ,YRBGN_MKTVAL_EXG_FND                       --年初市值_场内基金	      		 
        ,YRBGN_MKTVAL_CLS_FND                       --年初市值_封闭式基金
        ,YRBGN_MKTVAL_ETF_FND                       --年初市值_ETF		
        ,YRBGN_MKTVAL_OPN_FND                       --年初市值_开放式
        ,YRBGN_MKTVAL_LOF_FND                       --年初市值_LOF	
        ,YRBGN_MKTVAL_FOF_FND                       --年初市值_FOF	
        ,YRBGN_MKTVAL_BOND                          --年初市值_债券	
        ,YRBGN_AGN_FND_MKTVAL                       --年初代销基金市值
        ,YRBGN_GS_PROD_MKTVAL                       --年初公司产品市值
        ,YRBGN_GJ_PROD_MKTVAL                       --年初国君产品市值        		 	
        ,YRBGN_BANK_PROD_MKTVAL                     --年初银行产品市值	 
        ,YRBGN_OTC_PROD_MKTVAL                      --年初OTC产品市值    		 
        ,YRBGN_WRNT_RGHT_HLD_MKTVAL                 --年初期权账户权利仓市值	
        ,YRBGN_WRNT_DUTY_HLD_MKTVAL                 --年初期权账户义务仓市值
        ,YRBGN_ORDI_MKTVAL_SEC_USD                  --年初普通账户证券市值_美元	
        ,YRBGN_ORDI_MKTVAL_SEC_HKD                  --年初普通账户证券市值_港币	
        ,YRBGN_ORDI_MKTVAL_SEC_RMD                  --年初普通账户证券市值_人民币		
        ,YRBGN_ORDI_MKTVAL_PROD                     --年初普通账户产品市值			 
        ,YRBGN_ORDI_SEC_MKTVAL                      --年初普通账户证券市值(折算人民币)
        ,YRBGN_ORDI_MKTVAL                          --年初普通账户市值 
        ,YRBGN_ORDI_UN_CIR_MKTVAL                   --年初普通账户非流通市值(折算人民币) 
        ,YRBGN_CRD_SEC_MKTVAL                       --年初信用账户证券市值
        ,YRBGN_WRNT_MKTVAL                          --年初期权账户市值(权利仓市值-义务仓市
        ,YRBGN_WRNT_CNTS                            --年初期权账户张数	
        ,YRBGN_TOT_MKTVAL                           --年初总市值		
        ,YRBGN_ORDI_CPTL_USD                        --年初普通账户资金_美元	
        ,YRBGN_ORDI_CPTL_HKD                        --年初普通账户资金_港币	
        ,YRBGN_ORDI_CPTL_RMB                        --年初普通账户资金_人民币		
        ,YRBGN_ORDI_CPTL                            --年初普通账户资金(折算人民币)		
        ,YRBGN_CRD_CPTL                             --年初信用账户资金
        ,YRBGN_WRNT_CPTL                            --年初期权账户资金	
        ,YRBGN_TOT_UNPY_CPTL                        --年初总的在途资金		
        ,YRBGN_TOT_CPTL                             --年初总资金		 
        ,YRBGN_ORDI_GL                              --年初普通账户负债
        ,YRBGN_CRD_GL                               --年初信用账户负债 		 
        ,YRBGN_TOTGL                                --年初总负债	 
        ,YRBGN_ORDI_AST                             --年初普通资产	  
        ,YRBGN_ORDI_NET_AST                         --年初普通净资产
        ,YRBGN_CRD_AST                              --年初信用资产	 
        ,YRBGN_WRNT_AST                             --年初期权资产
        ,YRBGN_TOT_AST                              --年初总资产
        ,YRBGN_NET_TOT_AST                          --年初净总资产
        ,YRBGN_EXG_NET_TOT_AST                      --年初场内净总资产  
        ,YREND_MKTVAL_HA                             --年末市值_沪A主板  	   	   
        ,YREND_MKTVAL_SA                             --年末市值_深A主板
        ,YREND_MKTVAL_SMS                            --年末市值_中小板
        ,YREND_MKTVAL_GEM                            --年末市值_创业板		 
        ,YREND_MKTVAL_HB_USD                         --年末市值_沪B_美元
        ,YREND_MKTVAL_SB_HKD                         --年末市值_深B_港币
        ,YREND_MKTVAL_HK                             --年末市值_沪港通
        ,YREND_MKTVAL_SK                             --年末市值_深港通
        ,YREND_MKTVAL_TA                             --年末市值_三板A股
        ,YREND_MKTVAL_TU_USD                         --年末市值_三板B股_美元
        ,YREND_MKTVAL_REPO                           --年末市值_回购
        ,YREND_MKTVAL_EXG_FND                        --年末市值_场内基金	      		 
        ,YREND_MKTVAL_CLS_FND                        --年末市值_封闭式基金
        ,YREND_MKTVAL_ETF_FND                        --年末市值_ETF		
        ,YREND_MKTVAL_OPN_FND                        --年末市值_开放式
        ,YREND_MKTVAL_LOF_FND                        --年末市值_LOF	
        ,YREND_MKTVAL_FOF_FND                        --年末市值_FOF	
        ,YREND_MKTVAL_BOND                           --年末市值_债券	
        ,YREND_AGN_FND_MKTVAL                        --年末代销基金市值
        ,YREND_GS_PROD_MKTVAL                        --年末公司产品市值
        ,YREND_GJ_PROD_MKTVAL                        --年末国君产品市值        		 	
        ,YREND_BANK_PROD_MKTVAL                      --年末银行产品市值	 
        ,YREND_OTC_PROD_MKTVAL                       --年末OTC产品市值    		 
        ,YREND_WRNT_RGHT_HLD_MKTVAL                  --年末期权账户权利仓市值	
        ,YREND_WRNT_DUTY_HLD_MKTVAL                  --年末期权账户义务仓市值
        ,YREND_ORDI_MKTVAL_SEC_USD                   --年末普通账户证券市值_美元	
        ,YREND_ORDI_MKTVAL_SEC_HKD                   --年末普通账户证券市值_港币	
        ,YREND_ORDI_MKTVAL_SEC_RMD                   --年末普通账户证券市值_人民币		
        ,YREND_ORDI_MKTVAL_PROD                      --年末普通账户产品市值			 
        ,YREND_ORDI_SEC_MKTVAL                       --年末普通账户证券市值(折算人民币)
        ,YREND_ORDI_MKTVAL                           --年末普通账户市值 
        ,YREND_ORDI_UN_CIR_MKTVAL                    --年末普通账户非流通市值(折算人民币)       
        ,YREND_CRD_SEC_MKTVAL                        --年末信用账户证券市值
        ,YREND_WRNT_MKTVAL                           --年末期权账户市值(权利仓市值-义务仓市值)		
        ,YREND_WRNT_CNTS                             --年末期权账户张数	
        ,YREND_TOT_MKTVAL                            --年末总市值		
        ,YREND_ORDI_CPTL_USD                         --年末普通账户资金_美元	
        ,YREND_ORDI_CPTL_HKD                         --年末普通账户资金_港币	
        ,YREND_ORDI_CPTL_RMB                         --年末普通账户资金_人民币		
        ,YREND_ORDI_CPTL                             --年末普通账户资金(折算人民币)		
        ,YREND_CRD_CPTL                              --年末信用账户资金
        ,YREND_WRNT_CPTL                             --年末期权账户资金	
        ,YREND_TOT_UNPY_CPTL                         --年末总的在途资金		
        ,YREND_TOT_CPTL                              --年末总资金		 
        ,YREND_ORDI_GL                               --年末普通账户负债
        ,YREND_CRD_GL                                --年末信用账户负债 		 
        ,YREND_TOTGL                                 --年末总负债	 
        ,YREND_ORDI_AST                              --年末普通资产	  
        ,YREND_ORDI_NET_AST                          --年末普通净资产
        ,YREND_CRD_AST                               --年末信用资产	 
        ,YREND_WRNT_AST                              --年末期权资产
        ,YREND_TOT_AST                               --年末总资产
        ,YREND_NET_TOT_AST                           --年末净总资产
        ,YREND_EXG_NET_TOT_AST                       --年末场内净总资产
        ,ORDI_DEPIN_AMT_USD                        --普通账户存入金额_美元    	   	   
        ,ORDI_DEPIN_AMT_HKD                        --普通账户存入金额_港币
        ,ORDI_DEPIN_AMT_RMB                        --普通账户存入金额_人民币
        ,ORDI_TFR_IN_AMT                           --普通账户转入金额(折算人民币)
        ,ORDI_WTHDR_AMT_USD                        --普通账户取出金额_美元
        ,ORDI_WTHDR_AMT_HKD                        --普通账户取出金额_港币
        ,ORDI_WTHDR_AMT_RMB                        --普通账户取出金额_人民币
        ,ORDI_TFR_OUT_AMT                          --普通账户转出金额(折算人民币)
        ,CRD_DEPIN_AMT                             --信用账户存入金额
        ,CRD_TFR_IN_AMT                            --信用账户转入金额
        ,CRD_WTHDR_AMT                             --信用账户取出金额
        ,CRD_TFR_OUT_AMT                           --信用账户转出金额
        ,WRNT_DEPIN_AMT                            --期权账户存入金额
        ,WRNT_TFR_IN_AMT                           --期权账户转入金额
        ,WRNT_WTHDR_AMT                            --期权账户取出金额
        ,WRNT_TFR_OUT_AMT                          --期权账户转出金额
        ,TFR_IN_AMT                                --转入资金
        ,TFR_OUT_AMT                               --转出资金
        ,ORDI_NET_TFR_IN_AMT                       --普通账户净转入资金
        ,CRD_NET_TFR_IN_AMT                        --信用账户净转入资金
        ,WRNT_NET_TFR_IN_AMT                       --期权账户净转入资金
        ,NET_TFR_IN_AMT                            --净转入资金
        ,ORDI_ASGN_TFR_IN_MKTVAL_RMB               --普通账户指定转入市值_人民币
        ,ORDI_ASGN_TFR_IN_MKTVAL_USD               --普通账户指定转入市值_美元
        ,ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB           --普通账户转托管转入市值_人民币
        ,ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD           --普通账户转托管转入市值_港币
        ,CRD_ASGN_TFR_IN_MKTVAL                    --信用账户指定转入市值		
        ,CRD_TFR_CSTD_TFR_IN_MKTVAL                --信用账户转托管转入市值
        ,ORDI_ASGN_TFR_OUT_MKTVAL_RMB              --普通账户撤指定转出市值_人民币
        ,ORDI_ASGN_TFR_OUT_MKTVAL_USD              --普通账户撤指定转出市值_美元
        ,ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB          --普通账户转托管转出市值_人民币
        ,ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD          --普通账户转托管转出市值_港币
        ,CRD_ASGN_TFR_OUT_MKTVAL                   --信用账户指定转出市值		
        ,CRD_TFR_CSTD_TFR_OUT_MKTVAL               --信用账户转托管转出市值
        ,ORDI_TFR_IN_MKTVAL                        --普通账户转入市值
        ,ORDI_TFR_OUT_MKTVAL                       --普通账户转出市值
        ,CRD_TFR_IN_MKTVAL                         --信用账户转入市值
        ,CRD_TFR_OUT_MKTVAL                        --信用账户转出市值
        ,TFR_IN_MKTVAL                             --转入市值
        ,TFR_OUT_MKTVAL                            --转出市值
        ,ORDI_NET_TFR_IN_MKTVAL                    --普通账户净转入市值
        ,CRD_NET_TFR_IN_MKTVAL                     --信用账户净转入市值
        ,NET_TFR_IN_MKTVAL                         --净转入市值		        
        ,ORDI_PRFT                                 --普通盈亏
        ,CRD_PRFT                                  --信用盈亏
        ,WRNT_PRFT                                 --期权盈亏
        ,TOT_PRFT                                  --总盈亏
        ,AVGDLY_ORDI_CPTL                          --日均普通账户资金
        ,AVGDLY_CRD_CPTL                           --日均信用账户资金
        ,AVGDLY_WRNT_CPTL                          --日均期权账户资金
        ,AVGDLY_TOT_CPTL                           --日均总资金		  
        ,MAX_ORDI_CPTL                             --当年普通账户最大资金
        ,MAX_CRD_CPTL                              --当年信用账户最大资金
        ,MAX_WRNT_CPTL                             --当年期权账户最大资金
        ,MAX_TOT_CPTL                              --当年最大总资金
        ,MIN_ORDI_CPTL                             --当年普通账户最小资金
        ,MIN_CRD_CPTL                              --当年信用账户最小资金
        ,MIN_WRNT_CPTL                             --当年期权账户最小资金
        ,MIN_TOT_CPTL                              --当年最小总资金		  
        ,AVGDLY_ORDI_MKTVAL                        --日均普通账户市值
        ,AVGDLY_CRD_MKTVAL                         --日均信用账户市值
        ,AVGDLY_WRNT_MKTVAL                        --日均期权账户市值
        ,AVGDLY_TOT_MKTVAL                         --日均总市值		  
        ,MAX_ORDI_MKTVAL                           --当年普通账户最大市值
        ,MAX_CRD_MKTVAL                            --当年信用账户最大市值
        ,MAX_WRNT_MKTVAL                           --当年期权账户最大市值
        ,MAX_TOT_MKTVAL                            --当年最大总市值	
        ,MIN_ORDI_MKTVAL                           --当年普通账户最小市值
        ,MIN_CRD_MKTVAL                            --当年信用账户最小市值
        ,MIN_WRNT_MKTVAL                           --当年期权账户最小市值
        ,MIN_TOT_MKTVAL                            --当年最小总市值          	
        ,AVGDLY_ORDI_GL                            --日均普通账户负债
        ,AVGDLY_CRD_GL                             --日均信用账户负债
        ,AVGDLY_TOTGL                              --日均总负债
        ,MAX_ORDI_GL                               --当年普通账户最大负债
        ,MAX_CRD_GL                                --当年信用账户最大负债
        ,MAX_TOTGL                                 --当年最大总负债
        ,MIN_ORDI_GL                               --当年普通账户最小负债
        ,MIN_CRD_GL                                --当年信用账户最小负债
        ,MIN_TOTGL                                 --当年最小总负债
        ,AVGDLY_ORDI_AST                           --日均普通账户资产
        ,AVGDLY_CRD_AST                            --日均信用账户资产
        ,AVGDLY_WRNT_AST                           --日均期权账户资产
        ,AVGDLY_TOT_AST                            --日均总资产
        ,MAX_ORDI_AST                              --当年普通账户最大资产
        ,MAX_CRD_AST                               --当年信用账户最大资产
        ,MAX_WRNT_AST                              --当年期权账户最大资产
        ,MAX_TOT_AST                               --当年最大总资产
        ,MIN_ORDI_AST                              --当年普通账户最小资产
        ,MIN_CRD_AST                               --当年信用账户最小资产
        ,MIN_WRNT_AST                              --当年期权账户最小资产
        ,MIN_TOT_AST                               --当年最小总资产		  
        ,AVGDLY_ORDI_NET_AST                       --日均普通账户净资产
        ,AVGDLY_CRD_NET_AST                        --日均信用账户净资产
        ,AVGDLY_WRNT_NET_AST                       --日均期权账户净资产
        ,AVGDLY_TOT_NET_AST                        --日均总净资产
        ,MAX_ORDI_NET_AST                          --当年普通账户最大净资产
        ,MAX_CRD_NET_AST                           --当年信用账户最大净资产
        ,MAX_WRNT_NET_AST                          --当年期权账户最大净资产
        ,MAX_TOT_NET_AST                           --当年最大总净资产
        ,MIN_ORDI_NET_AST                          --当年普通账户最小净资产
        ,MIN_CRD_NET_AST                           --当年信用账户最小净资产
        ,MIN_WRNT_NET_AST                          --当年期权账户最小净资产
        ,MIN_TOT_NET_AST                           --当年最小总净资产		  
        ,AVGDLY_EXG_NET_TOT_AST                    --日均场内总净资产		  
        ,MAX_EXG_NET_TOT_AST                       --当年场内最大总净资产
        ,MIN_EXG_NET_TOT_AST                       --当年场内最小总净资产
        ,AVGDLY_ORDI_CPTL1                         --自然日日均普通账户资金
        ,AVGDLY_CRD_CPTL1                          --自然日日均信用账户资金
        ,AVGDLY_WRNT_CPTL1                         --自然日日均期权账户资金
        ,AVGDLY_CPTL1                              --自然日日均资金
        ,ETL_DT	
        ,YRBGN_ORDI_MKTVAL_NEW_TA                   --年初普通账户市值_新三板A股
        ,YRBGN_STK_PLG_AMT                          --年初股票质押余额 
        ,YRBGN_MIN_STK_PLG_AMT                      --年初小微贷余额	
        ,YREND_ORDI_MKTVAL_NEW_TA                   --年末普通账户市值_新三板A股
        ,YREND_STK_PLG_AMT                          --年末股票质押余额
        ,YREND_MIN_STK_PLG_AMT                      --年末小微贷余额
        ,STK_PLG_ADD_INT                            --股票质押新增利息
        ,STK_PLG_ADD_TRD_AMT                        --股票质押初始交易量
        ,MIN_STK_PLG_ADD_INT                        --小微贷新增利息
        ,MIN_STK_PLG_ADD_TRD_AMT                    --小微贷初始交易量	
        ,AVGDLY_STK_PLG_AMT                         --自然日日均股票质押余额
        ,AVGDLY_MIN_STK_PLG_AMT                     --自然日日均小微贷余额
       , YRBGN_ORDI_MKTVAL_EXG_FND_SH                          --年初普通账户市值_场内基金_沪市
       , YRBGN_ORDI_MKTVAL_EXG_FND_SZ                          --年初普通账户市值_场内基金_深市
       , YRBGN_CRD_MKTVAL_EXG_FND_SH                           --年初信用账户市值_场内基金_沪市
       , YRBGN_CRD_MKTVAL_EXG_FND_SZ                           --年初信用账户市值_场内基金_深市
       , YRBGN_ORDI_MKTVAL_BOND_SH                             --年初普通账户市值_债券_沪市
       , YRBGN_ORDI_MKTVAL_BOND_SZ                             --年初普通账户市值_债券_深市
       , YRBGN_CRD_MKTVAL_BOND_SH                              --年初信用账户市值_债券_沪市
       , YRBGN_CRD_MKTVAL_BOND_SZ                              --年初信用账户市值_债券_深市
       , YRBGN_ORDI_UN_CIR_MKTVAL_SH                           --年初普通账户沪市非流通市值(折算人民币)
       , YRBGN_ORDI_UN_CIR_MKTVAL_SZ                           --年初普通账户深市非流通市值(折算人民币)
       , YRBGN_ORDI_MKTVAL_AK_STIB                             --年初普通账户市值_AK科创板
       , YRBGN_ORDI_MKTVAL_RK_STIB                             --年初普通账户市值_RK科创CDR
       , YRBGN_CRD_MKTVAL_AK_STIB                              --年初信用账户市值_AK科创板
       , YRBGN_CRD_MKTVAL_RK_STIB                              --年初信用账户市值_RK科创CDR
       , YREND_ORDI_MKTVAL_EXG_FND_SH                          --年末普通账户市值_场内基金_沪市
       , YREND_ORDI_MKTVAL_EXG_FND_SZ                          --年末普通账户市值_场内基金_深市
       , YREND_CRD_MKTVAL_EXG_FND_SH                           --年末信用账户市值_场内基金_沪市
       , YREND_CRD_MKTVAL_EXG_FND_SZ                           --年末信用账户市值_场内基金_深市
       , YREND_ORDI_MKTVAL_BOND_SH                             --年末普通账户市值_债券_沪市
       , YREND_ORDI_MKTVAL_BOND_SZ                             --年末普通账户市值_债券_深市
       , YREND_CRD_MKTVAL_BOND_SH                              --年末信用账户市值_债券_沪市
       , YREND_CRD_MKTVAL_BOND_SZ                              --年末信用账户市值_债券_深市
       , YREND_ORDI_UN_CIR_MKTVAL_SH                           --年末普通账户沪市非流通市值(折算人民币)
       , YREND_ORDI_UN_CIR_MKTVAL_SZ                           --年末普通账户深市非流通市值(折算人民币)
       , YREND_ORDI_MKTVAL_AK_STIB                             --年末普通账户市值_AK科创板
       , YREND_ORDI_MKTVAL_RK_STIB                             --年末普通账户市值_RK科创CDR
       , YREND_CRD_MKTVAL_AK_STIB                              --年末信用账户市值_AK科创板
       , YREND_CRD_MKTVAL_RK_STIB                              --年末信用账户市值_RK科创CDR	
       ,YRBGN_WRNT_RGHT_HLD_MKTVAL_SH             --年初期权账户权利仓市值(SH)
       ,YRBGN_WRNT_DUTY_HLD_MKTVAL_SH             --年初期权账户义务仓市值(SH)      
       ,YRBGN_WRNT_MKTVAL_SH                      --年初期权账户市值(权利仓市值-义务仓市值)(SH)	
       ,YRBGN_WRNT_CNTS_SH                        --年初期权张数(SH)
       ,YRBGN_WRNT_RGHT_HLD_MKTVAL_SZ             --年初期权账户权利仓市值(SZ)
       ,YRBGN_WRNT_DUTY_HLD_MKTVAL_SZ             --年初期权账户义务仓市值(SZ)      
       ,YRBGN_WRNT_MKTVAL_SZ                      --年初期权账户市值(权利仓市值-义务仓市值)(SZ)	
       ,YRBGN_WRNT_CNTS_SZ                        --年初期权张数(SZ)
       ,YREND_WRNT_RGHT_HLD_MKTVAL_SH             --年末期权账户权利仓市值(SH)
       ,YREND_WRNT_DUTY_HLD_MKTVAL_SH             --年末期权账户义务仓市值(SH)      
       ,YREND_WRNT_MKTVAL_SH                      --年末期权账户市值(权利仓市值-义务仓市值)(SH)	
       ,YREND_WRNT_CNTS_SH                        --年末期权张数(SH)
       ,YREND_WRNT_RGHT_HLD_MKTVAL_SZ             --年末期权账户权利仓市值(SZ)
       ,YREND_WRNT_DUTY_HLD_MKTVAL_SZ             --年末期权账户义务仓市值(SZ)      
       ,YREND_WRNT_MKTVAL_SZ                      --年末期权账户市值(权利仓市值-义务仓市值)(SZ)	
       ,YREND_WRNT_CNTS_SZ                        --年末期权张数(SZ)	   
 ) partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT))
 SELECT  t.CUST_NO                                  --客户号                 
        ,t.BRH_NO                                     --营业部编号                         
        ,t.CUST_CGY		                            --客户类别
        ,NVL(a1.YRBGN_MKTVAL_HA,0)                            --期初市值_沪A主板
        ,NVL(a1.YRBGN_MKTVAL_SA,0)                            --期初市值_深A主板
        ,NVL(a1.YRBGN_MKTVAL_SMS,0)                           --期初市值_中小板
        ,NVL(a1.YRBGN_MKTVAL_GEM,0)                           --期初市值_创业板		 
        ,NVL(a1.YRBGN_MKTVAL_HB_USD,0)                        --期初市值_沪B_美元
        ,NVL(a1.YRBGN_MKTVAL_SB_HKD,0)                        --期初市值_深B_港币
        ,NVL(a1.YRBGN_MKTVAL_HK,0)                            --期初市值_沪港通
        ,NVL(a1.YRBGN_MKTVAL_SK,0)                            --期初市值_深港通
        ,NVL(a1.YRBGN_MKTVAL_TA,0)                            --期初市值_三板A股
        ,NVL(a1.YRBGN_MKTVAL_TU_USD,0)                        --期初市值_三板B股_美元
        ,NVL(a1.YRBGN_MKTVAL_REPO,0)                          --期初市值_回购
        ,NVL(a1.YRBGN_MKTVAL_EXG_FND,0)                       --期初市值_场内基金	      		 
        ,NVL(a1.YRBGN_MKTVAL_CLS_FND,0)                       --期初市值_封闭式基金
        ,NVL(a1.YRBGN_MKTVAL_ETF_FND,0)                       --期初市值_ETF		
        ,NVL(a1.YRBGN_MKTVAL_OPN_FND,0)                       --期初市值_开放式
        ,NVL(a1.YRBGN_MKTVAL_LOF_FND,0)                       --期初市值_LOF	
        ,NVL(a1.YRBGN_MKTVAL_FOF_FND,0)                       --期初市值_FOF	
        ,NVL(a1.YRBGN_MKTVAL_BOND,0)                          --期初市值_债券	
        ,NVL(a1.YRBGN_AGN_FND_MKTVAL,0)                       --期初代销基金市值
        ,NVL(a1.YRBGN_GS_PROD_MKTVAL,0)                       --期初公司产品市值
        ,NVL(a1.YRBGN_GJ_PROD_MKTVAL,0)                       --期初国君产品市值        		 	
        ,NVL(a1.YRBGN_BANK_PROD_MKTVAL,0)                     --期初银行产品市值	 
        ,NVL(a1.YRBGN_OTC_PROD_MKTVAL,0)                      --期初OTC产品市值    		 
        ,NVL(a1.YRBGN_WRNT_RGHT_HLD_MKTVAL,0)                 --期初期权账户权利仓市值	
        ,NVL(a1.YRBGN_WRNT_DUTY_HLD_MKTVAL,0)                 --期初期权账户义务仓市值
        ,NVL(a1.YRBGN_ORDI_MKTVAL_SEC_USD,0)                  --期初普通账户证券市值_美元	
        ,NVL(a1.YRBGN_ORDI_MKTVAL_SEC_HKD,0)                  --期初普通账户证券市值_港币	
        ,NVL(a1.YRBGN_ORDI_MKTVAL_SEC_RMD,0)                  --期初普通账户证券市值_人民币		
        ,NVL(a1.YRBGN_ORDI_MKTVAL_PROD,0)                     --期初普通账户产品市值			 
        ,NVL(a1.YRBGN_ORDI_SEC_MKTVAL,0)                      --期初普通账户证券市值(折算人民币)
        ,NVL(a1.YRBGN_ORDI_MKTVAL,0)                          --期初普通账户市值 
        ,NVL(a1.YRBGN_ORDI_UN_CIR_MKTVAL,0)                   --期初普通账户非流通市值(折算人民币) 
        ,NVL(a1.YRBGN_CRD_SEC_MKTVAL,0)                       --期初信用账户证券市值
        ,NVL(a1.YRBGN_WRNT_MKTVAL,0)                          --期初期权账户市值(权利仓市值-义务仓市
        ,NVL(a1.YRBGN_WRNT_CNTS,0)                            --期初期权账户张数	
        ,NVL(a1.YRBGN_TOT_MKTVAL,0)                           --期初总市值		
        ,NVL(a1.YRBGN_ORDI_CPTL_USD,0)                        --期初普通账户资金_美元	
        ,NVL(a1.YRBGN_ORDI_CPTL_HKD,0)                        --期初普通账户资金_港币	
        ,NVL(a1.YRBGN_ORDI_CPTL_RMB,0)                        --期初普通账户资金_人民币		
        ,NVL(a1.YRBGN_ORDI_CPTL,0)                            --期初普通账户资金(折算人民币)		
        ,NVL(a1.YRBGN_CRD_CPTL,0)                             --期初信用账户资金
        ,NVL(a1.YRBGN_WRNT_CPTL,0)                            --期初期权账户资金	
        ,NVL(a1.YRBGN_TOT_UNPY_CPTL,0)                        --期初总的在途资金		
        ,NVL(a1.YRBGN_TOT_CPTL,0)                             --期初总资金		 
        ,NVL(a1.YRBGN_ORDI_GL,0)                              --期初普通账户负债
        ,NVL(a1.YRBGN_CRD_GL,0)                               --期初信用账户负债 		 
        ,NVL(a1.YRBGN_TOTGL,0)                                --期初总负债	 
        ,NVL(a1.YRBGN_ORDI_AST,0)                             --期初普通资产	  
        ,NVL(a1.YRBGN_ORDI_NET_AST,0)                         --期初普通净资产
        ,NVL(a1.YRBGN_CRD_AST,0)                              --期初信用资产	 
        ,NVL(a1.YRBGN_WRNT_AST,0)                             --期初期权资产
        ,NVL(a1.YRBGN_TOT_AST,0)                              --期初总资产
        ,NVL(a1.YRBGN_NET_TOT_AST,0)                          --期初净总资产
        ,NVL(a1.YRBGN_EXG_NET_TOT_AST,0)                      --期初场内净总资产  
        ,NVL(a2.YREND_MKTVAL_HA,0)                             --期末市值_沪A主板  	   	   
        ,NVL(a2.YREND_MKTVAL_SA,0)                             --期末市值_深A主板
        ,NVL(a2.YREND_MKTVAL_SMS,0)                            --期末市值_中小板
        ,NVL(a2.YREND_MKTVAL_GEM,0)                            --期末市值_创业板		 
        ,NVL(a2.YREND_MKTVAL_HB_USD,0)                         --期末市值_沪B_美元
        ,NVL(a2.YREND_MKTVAL_SB_HKD,0)                         --期末市值_深B_港币
        ,NVL(a2.YREND_MKTVAL_HK,0)                             --期末市值_沪港通
        ,NVL(a2.YREND_MKTVAL_SK,0)                             --期末市值_深港通
        ,NVL(a2.YREND_MKTVAL_TA,0)                             --期末市值_三板A股
        ,NVL(a2.YREND_MKTVAL_TU_USD,0)                         --期末市值_三板B股_美元
        ,NVL(a2.YREND_MKTVAL_REPO,0)                           --期末市值_回购
        ,NVL(a2.YREND_MKTVAL_EXG_FND,0)                        --期末市值_场内基金	      		 
        ,NVL(a2.YREND_MKTVAL_CLS_FND,0)                        --期末市值_封闭式基金
        ,NVL(a2.YREND_MKTVAL_ETF_FND,0)                        --期末市值_ETF		
        ,NVL(a2.YREND_MKTVAL_OPN_FND,0)                        --期末市值_开放式
        ,NVL(a2.YREND_MKTVAL_LOF_FND,0)                        --期末市值_LOF	
        ,NVL(a2.YREND_MKTVAL_FOF_FND,0)                        --期末市值_FOF	
        ,NVL(a2.YREND_MKTVAL_BOND,0)                           --期末市值_债券	
        ,NVL(a2.YREND_AGN_FND_MKTVAL,0)                        --期末代销基金市值
        ,NVL(a2.YREND_GS_PROD_MKTVAL,0)                        --期末公司产品市值
        ,NVL(a2.YREND_GJ_PROD_MKTVAL,0)                        --期末国君产品市值        		 	
        ,NVL(a2.YREND_BANK_PROD_MKTVAL,0)                      --期末银行产品市值	 
        ,NVL(a2.YREND_OTC_PROD_MKTVAL,0)                       --期末OTC产品市值    		 
        ,NVL(a2.YREND_WRNT_RGHT_HLD_MKTVAL,0)                  --期末期权账户权利仓市值	
        ,NVL(a2.YREND_WRNT_DUTY_HLD_MKTVAL,0)                  --期末期权账户义务仓市值
        ,NVL(a2.YREND_ORDI_MKTVAL_SEC_USD,0)                   --期末普通账户证券市值_美元	
        ,NVL(a2.YREND_ORDI_MKTVAL_SEC_HKD,0)                   --期末普通账户证券市值_港币	
        ,NVL(a2.YREND_ORDI_MKTVAL_SEC_RMD,0)                   --期末普通账户证券市值_人民币		
        ,NVL(a2.YREND_ORDI_MKTVAL_PROD,0)                      --期末普通账户产品市值			 
        ,NVL(a2.YREND_ORDI_SEC_MKTVAL,0)                       --期末普通账户证券市值(折算人民币)
        ,NVL(a2.YREND_ORDI_MKTVAL,0)                           --期末普通账户市值 
        ,NVL(a2.YREND_ORDI_UN_CIR_MKTVAL,0)                    --期末普通账户非流通市值(折算人民币)       
        ,NVL(a2.YREND_CRD_SEC_MKTVAL,0)                        --期末信用账户证券市值
        ,NVL(a2.YREND_WRNT_MKTVAL,0)                           --期末期权账户市值(权利仓市值-义务仓市值)		
        ,NVL(a2.YREND_WRNT_CNTS,0)                             --期末期权账户张数	
        ,NVL(a2.YREND_TOT_MKTVAL,0)                            --期末总市值		
        ,NVL(a2.YREND_ORDI_CPTL_USD,0)                         --期末普通账户资金_美元	
        ,NVL(a2.YREND_ORDI_CPTL_HKD,0)                         --期末普通账户资金_港币	
        ,NVL(a2.YREND_ORDI_CPTL_RMB,0)                         --期末普通账户资金_人民币		
        ,NVL(a2.YREND_ORDI_CPTL,0)                             --期末普通账户资金(折算人民币)		
        ,NVL(a2.YREND_CRD_CPTL,0)                              --期末信用账户资金
        ,NVL(a2.YREND_WRNT_CPTL,0)                             --期末期权账户资金	
        ,NVL(a2.YREND_TOT_UNPY_CPTL,0)                         --期末总的在途资金		
        ,NVL(a2.YREND_TOT_CPTL,0)                              --期末总资金		 
        ,NVL(a2.YREND_ORDI_GL,0)                               --期末普通账户负债
        ,NVL(a2.YREND_CRD_GL,0)                                --期末信用账户负债 		 
        ,NVL(a2.YREND_TOTGL,0)                                 --期末总负债	 
        ,NVL(a2.YREND_ORDI_AST,0)                              --期末普通资产	  
        ,NVL(a2.YREND_ORDI_NET_AST,0)                          --期末普通净资产
        ,NVL(a2.YREND_CRD_AST,0)                               --期末信用资产	 
        ,NVL(a2.YREND_WRNT_AST,0)                              --期末期权资产
        ,NVL(a2.YREND_TOT_AST,0)                               --期末总资产
        ,NVL(a2.YREND_NET_TOT_AST,0)                           --期末净总资产
        ,NVL(a2.YREND_EXG_NET_TOT_AST,0)                       --期末场内净总资产
        ,NVL(a3.ORDI_DEPIN_AMT_USD,0)                        --普通账户存入金额_美元    	   	   
        ,NVL(a3.ORDI_DEPIN_AMT_HKD,0)                        --普通账户存入金额_港币
        ,NVL(a3.ORDI_DEPIN_AMT_RMB,0)                        --普通账户存入金额_人民币
        ,NVL(a3.ORDI_TFR_IN_AMT,0)                           --普通账户转入金额(折算人民币)
        ,NVL(a3.ORDI_WTHDR_AMT_USD,0)                        --普通账户取出金额_美元
        ,NVL(a3.ORDI_WTHDR_AMT_HKD,0)                        --普通账户取出金额_港币
        ,NVL(a3.ORDI_WTHDR_AMT_RMB,0)                        --普通账户取出金额_人民币
        ,NVL(a3.ORDI_TFR_OUT_AMT,0)                          --普通账户转出金额(折算人民币)
        ,NVL(a3.CRD_DEPIN_AMT,0)                             --信用账户存入金额
        ,NVL(a3.CRD_TFR_IN_AMT,0)                            --信用账户转入金额
        ,NVL(a3.CRD_WTHDR_AMT,0)                             --信用账户取出金额
        ,NVL(a3.CRD_TFR_OUT_AMT,0)                           --信用账户转出金额
        ,NVL(a3.WRNT_DEPIN_AMT,0)                            --期权账户存入金额
        ,NVL(a3.WRNT_TFR_IN_AMT,0)                           --期权账户转入金额
        ,NVL(a3.WRNT_WTHDR_AMT,0)                            --期权账户取出金额
        ,NVL(a3.WRNT_TFR_OUT_AMT,0)                          --期权账户转出金额
        ,NVL(a3.TFR_IN_AMT,0)                                --转入资金
        ,NVL(a3.TFR_OUT_AMT,0)                               --转出资金
        ,NVL(a3.ORDI_NET_TFR_IN_AMT,0)                       --普通账户净转入资金
        ,NVL(a3.CRD_NET_TFR_IN_AMT,0)                        --信用账户净转入资金
        ,NVL(a3.WRNT_NET_TFR_IN_AMT,0)                       --期权账户净转入资金
        ,NVL(a3.NET_TFR_IN_AMT,0)                            --净转入资金
        ,NVL(a3.ORDI_ASGN_TFR_IN_MKTVAL_RMB,0)               --普通账户指定转入市值_人民币
        ,NVL(a3.ORDI_ASGN_TFR_IN_MKTVAL_USD,0)               --普通账户指定转入市值_美元
        ,NVL(a3.ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB,0)           --普通账户转托管转入市值_人民币
        ,NVL(a3.ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD,0)           --普通账户转托管转入市值_港币
        ,NVL(a3.CRD_ASGN_TFR_IN_MKTVAL,0)                    --信用账户指定转入市值		
        ,NVL(a3.CRD_TFR_CSTD_TFR_IN_MKTVAL,0)                --信用账户转托管转入市值
        ,NVL(a3.ORDI_ASGN_TFR_OUT_MKTVAL_RMB,0)              --普通账户撤指定转出市值_人民币
        ,NVL(a3.ORDI_ASGN_TFR_OUT_MKTVAL_USD,0)              --普通账户撤指定转出市值_美元
        ,NVL(a3.ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB,0)          --普通账户转托管转出市值_人民币
        ,NVL(a3.ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD,0)          --普通账户转托管转出市值_港币
        ,NVL(a3.CRD_ASGN_TFR_OUT_MKTVAL,0)                   --信用账户指定转出市值		
        ,NVL(a3.CRD_TFR_CSTD_TFR_OUT_MKTVAL,0)               --信用账户转托管转出市值
        ,NVL(a3.ORDI_TFR_IN_MKTVAL,0)                        --普通账户转入市值
        ,NVL(a3.ORDI_TFR_OUT_MKTVAL,0)                       --普通账户转出市值
        ,NVL(a3.CRD_TFR_IN_MKTVAL,0)                         --信用账户转入市值
        ,NVL(a3.CRD_TFR_OUT_MKTVAL,0)                        --信用账户转出市值
        ,NVL(a3.TFR_IN_MKTVAL,0)                             --转入市值
        ,NVL(a3.TFR_OUT_MKTVAL,0)                            --转出市值
        ,NVL(a3.ORDI_NET_TFR_IN_MKTVAL,0)                    --普通账户净转入市值
        ,NVL(a3.CRD_NET_TFR_IN_MKTVAL,0)                     --信用账户净转入市值
        ,NVL(a3.NET_TFR_IN_MKTVAL,0)                         --净转入市值		        
        ,NVL(a3.ORDI_PRFT,0)                                 --普通盈亏
        ,NVL(a3.CRD_PRFT,0)                                  --信用盈亏
        ,NVL(a3.WRNT_PRFT,0)                                 --期权盈亏
        ,NVL(a3.TOT_PRFT,0)                                  --总盈亏
        ,NVL(a3.AVGDLY_ORDI_CPTL,0)                          --日均普通账户资金
        ,NVL(a3.AVGDLY_CRD_CPTL,0)                           --日均信用账户资金
        ,NVL(a3.AVGDLY_WRNT_CPTL,0)                          --日均期权账户资金
        ,NVL(a3.AVGDLY_TOT_CPTL,0)                           --日均总资金		  
        ,NVL(a3.MAX_ORDI_CPTL,0)                             --当月普通账户最大资金
        ,NVL(a3.MAX_CRD_CPTL,0)                              --当月信用账户最大资金
        ,NVL(a3.MAX_WRNT_CPTL,0)                             --当月期权账户最大资金
        ,NVL(a3.MAX_TOT_CPTL,0)                              --当月最大总资金
        ,NVL(a3.MIN_ORDI_CPTL,0)                             --当月普通账户最小资金
        ,NVL(a3.MIN_CRD_CPTL,0)                              --当月信用账户最小资金
        ,NVL(a3.MIN_WRNT_CPTL,0)                             --当月期权账户最小资金
        ,NVL(a3.MIN_TOT_CPTL,0)                              --当月最小总资金		  
        ,NVL(a3.AVGDLY_ORDI_MKTVAL,0)                        --日均普通账户市值
        ,NVL(a3.AVGDLY_CRD_MKTVAL,0)                         --日均信用账户市值
        ,NVL(a3.AVGDLY_WRNT_MKTVAL,0)                        --日均期权账户市值
        ,NVL(a3.AVGDLY_TOT_MKTVAL,0)                         --日均总市值		  
        ,NVL(a3.MAX_ORDI_MKTVAL,0)                           --当月普通账户最大市值
        ,NVL(a3.MAX_CRD_MKTVAL,0)                            --当月信用账户最大市值
        ,NVL(a3.MAX_WRNT_MKTVAL,0)                           --当月期权账户最大市值
        ,NVL(a3.MAX_TOT_MKTVAL,0)                            --当月最大总市值	
        ,NVL(a3.MIN_ORDI_MKTVAL,0)                           --当月普通账户最小市值
        ,NVL(a3.MIN_CRD_MKTVAL,0)                            --当月信用账户最小市值
        ,NVL(a3.MIN_WRNT_MKTVAL,0)                           --当月期权账户最小市值
        ,NVL(a3.MIN_TOT_MKTVAL,0)                            --当月最小总市值          	
        ,NVL(a3.AVGDLY_ORDI_GL,0)                            --日均普通账户负债
        ,NVL(a3.AVGDLY_CRD_GL,0)                             --日均信用账户负债
        ,NVL(a3.AVGDLY_TOTGL,0)                              --日均总负债
        ,NVL(a3.MAX_ORDI_GL,0)                               --当月普通账户最大负债
        ,NVL(a3.MAX_CRD_GL,0)                                --当月信用账户最大负债
        ,NVL(a3.MAX_TOTGL,0)                                 --当月最大总负债
        ,NVL(a3.MIN_ORDI_GL,0)                               --当月普通账户最小负债
        ,NVL(a3.MIN_CRD_GL,0)                                --当月信用账户最小负债
        ,NVL(a3.MIN_TOTGL,0)                                 --当月最小总负债
        ,NVL(a3.AVGDLY_ORDI_AST,0)                           --日均普通账户资产
        ,NVL(a3.AVGDLY_CRD_AST,0)                            --日均信用账户资产
        ,NVL(a3.AVGDLY_WRNT_AST,0)                           --日均期权账户资产
        ,NVL(a3.AVGDLY_TOT_AST,0)                            --日均总资产
        ,NVL(a3.MAX_ORDI_AST,0)                              --当月普通账户最大资产
        ,NVL(a3.MAX_CRD_AST,0)                               --当月信用账户最大资产
        ,NVL(a3.MAX_WRNT_AST,0)                              --当月期权账户最大资产
        ,NVL(a3.MAX_TOT_AST,0)                               --当月最大总资产
        ,NVL(a3.MIN_ORDI_AST,0)                              --当月普通账户最小资产
        ,NVL(a3.MIN_CRD_AST,0)                               --当月信用账户最小资产
        ,NVL(a3.MIN_WRNT_AST,0)                              --当月期权账户最小资产
        ,NVL(a3.MIN_TOT_AST,0)                               --当月最小总资产		  
        ,NVL(a3.AVGDLY_ORDI_NET_AST,0)                       --日均普通账户净资产
        ,NVL(a3.AVGDLY_CRD_NET_AST,0)                        --日均信用账户净资产
        ,NVL(a3.AVGDLY_WRNT_NET_AST,0)                       --日均期权账户净资产
        ,NVL(a3.AVGDLY_TOT_NET_AST,0)                        --日均总净资产
        ,NVL(a3.MAX_ORDI_NET_AST,0)                          --当月普通账户最大净资产
        ,NVL(a3.MAX_CRD_NET_AST,0)                           --当月信用账户最大净资产
        ,NVL(a3.MAX_WRNT_NET_AST,0)                          --当月期权账户最大净资产
        ,NVL(a3.MAX_TOT_NET_AST,0)                           --当月最大总净资产
        ,NVL(a3.MIN_ORDI_NET_AST,0)                          --当月普通账户最小净资产
        ,NVL(a3.MIN_CRD_NET_AST,0)                           --当月信用账户最小净资产
        ,NVL(a3.MIN_WRNT_NET_AST,0)                          --当月期权账户最小净资产
        ,NVL(a3.MIN_TOT_NET_AST,0)                           --当月最小总净资产		  
        ,NVL(a3.AVGDLY_EXG_NET_TOT_AST,0)                    --日均场内总净资产		  
        ,NVL(a3.MAX_EXG_NET_TOT_AST,0)                       --当月场内最大总净资产
        ,NVL(a3.MIN_EXG_NET_TOT_AST,0)                       --当月场内最小总净资产
        ,NVL(a4.AVGDLY_ORDI_CPTL1,0)                         --自然日日均普通账户资金
        ,NVL(a4.AVGDLY_CRD_CPTL1,0)                          --自然日日均信用账户资金
        ,NVL(a4.AVGDLY_WRNT_CPTL1,0)                         --自然日日均期权账户资金
        ,NVL(a4.AVGDLY_CPTL1,0)                              --自然日日均资金
        ,%d{yyyyMMdd}              as ETL_DT
        ,NVL(a1.YRBGN_ORDI_MKTVAL_NEW_TA,0)                   --年初普通账户市值_新三板A股
        ,NVL(a1.YRBGN_STK_PLG_AMT,0)                          --年初股票质押余额 
        ,NVL(a1.YRBGN_MIN_STK_PLG_AMT,0)                      --年初小微贷余额	
        ,NVL(a2.YREND_ORDI_MKTVAL_NEW_TA,0)                   --年末普通账户市值_新三板A股
        ,NVL(a2.YREND_STK_PLG_AMT,0)                          --年末股票质押余额
        ,NVL(a2.YREND_MIN_STK_PLG_AMT,0)                      --年末小微贷余额
        ,NVL(a3.STK_PLG_ADD_INT,0)                            --股票质押新增利息
        ,NVL(a3.STK_PLG_ADD_TRD_AMT,0)                        --股票质押初始交易量
        ,NVL(a3.MIN_STK_PLG_ADD_INT,0)                        --小微贷新增利息
        ,NVL(a3.MIN_STK_PLG_ADD_TRD_AMT,0)                    --小微贷初始交易量	
        ,NVL(a4.AVGDLY_STK_PLG_AMT,0)                         --自然日日均股票质押余额
        ,NVL(a4.AVGDLY_MIN_STK_PLG_AMT ,0)                    --自然日日均小微贷余额
       , NVL(a1.YRBGN_ORDI_MKTVAL_EXG_FND_SH,0)                          --年初普通账户市值_场内基金_沪市
       , NVL(a1.YRBGN_ORDI_MKTVAL_EXG_FND_SZ,0)                          --年初普通账户市值_场内基金_深市
       , NVL(a1.YRBGN_CRD_MKTVAL_EXG_FND_SH,0)                           --年初信用账户市值_场内基金_沪市
       , NVL(a1.YRBGN_CRD_MKTVAL_EXG_FND_SZ,0)                           --年初信用账户市值_场内基金_深市
       , NVL(a1.YRBGN_ORDI_MKTVAL_BOND_SH,0)                             --年初普通账户市值_债券_沪市
       , NVL(a1.YRBGN_ORDI_MKTVAL_BOND_SZ,0)                             --年初普通账户市值_债券_深市
       , NVL(a1.YRBGN_CRD_MKTVAL_BOND_SH,0)                              --年初信用账户市值_债券_沪市
       , NVL(a1.YRBGN_CRD_MKTVAL_BOND_SZ,0)                              --年初信用账户市值_债券_深市
       , NVL(a1.YRBGN_ORDI_UN_CIR_MKTVAL_SH,0)                           --年初普通账户沪市非流通市值(折算人民币)
       , NVL(a1.YRBGN_ORDI_UN_CIR_MKTVAL_SZ,0)                           --年初普通账户深市非流通市值(折算人民币)
       , NVL(a1.YRBGN_ORDI_MKTVAL_AK_STIB,0)                             --年初普通账户市值_AK科创板
       , NVL(a1.YRBGN_ORDI_MKTVAL_RK_STIB,0)                             --年初普通账户市值_RK科创CDR
       , NVL(a1.YRBGN_CRD_MKTVAL_AK_STIB,0)                              --年初信用账户市值_AK科创板
       , NVL(a1.YRBGN_CRD_MKTVAL_RK_STIB,0)                              --年初信用账户市值_RK科创CDR
       , NVL(a2.YREND_ORDI_MKTVAL_EXG_FND_SH,0)                          --年末普通账户市值_场内基金_沪市
       , NVL(a2.YREND_ORDI_MKTVAL_EXG_FND_SZ,0)                          --年末普通账户市值_场内基金_深市
       , NVL(a2.YREND_CRD_MKTVAL_EXG_FND_SH,0)                           --年末信用账户市值_场内基金_沪市
       , NVL(a2.YREND_CRD_MKTVAL_EXG_FND_SZ,0)                           --年末信用账户市值_场内基金_深市
       , NVL(a2.YREND_ORDI_MKTVAL_BOND_SH,0)                             --年末普通账户市值_债券_沪市
       , NVL(a2.YREND_ORDI_MKTVAL_BOND_SZ,0)                             --年末普通账户市值_债券_深市
       , NVL(a2.YREND_CRD_MKTVAL_BOND_SH,0)                              --年末信用账户市值_债券_沪市
       , NVL(a2.YREND_CRD_MKTVAL_BOND_SZ,0)                              --年末信用账户市值_债券_深市
       , NVL(a2.YREND_ORDI_UN_CIR_MKTVAL_SH,0)                           --年末普通账户沪市非流通市值(折算人民币)
       , NVL(a2.YREND_ORDI_UN_CIR_MKTVAL_SZ,0)                           --年末普通账户深市非流通市值(折算人民币)
       , NVL(a2.YREND_ORDI_MKTVAL_AK_STIB,0)                             --年末普通账户市值_AK科创板
       , NVL(a2.YREND_ORDI_MKTVAL_RK_STIB,0)                             --年末普通账户市值_RK科创CDR
       , NVL(a2.YREND_CRD_MKTVAL_AK_STIB,0)                              --年末信用账户市值_AK科创板
       , NVL(a2.YREND_CRD_MKTVAL_RK_STIB,0)                              --年末信用账户市值_RK科创CDR
       ,NVL(a1.YRBGN_WRNT_RGHT_HLD_MKTVAL_SH,0)             --年初期权账户权利仓市值(SH)
       ,NVL(a1.YRBGN_WRNT_DUTY_HLD_MKTVAL_SH,0)             --年初期权账户义务仓市值(SH)      
       ,NVL(a1.YRBGN_WRNT_MKTVAL_SH,0)                      --年初期权账户市值(权利仓市值-义务仓市值)(SH)	
       ,NVL(a1.YRBGN_WRNT_CNTS_SH,0)                        --年初期权张数(SH)
       ,NVL(a1.YRBGN_WRNT_RGHT_HLD_MKTVAL_SZ,0)             --年初期权账户权利仓市值(SZ)
       ,NVL(a1.YRBGN_WRNT_DUTY_HLD_MKTVAL_SZ,0)             --年初期权账户义务仓市值(SZ)      
       ,NVL(a1.YRBGN_WRNT_MKTVAL_SZ,0)                      --年初期权账户市值(权利仓市值-义务仓市值)(SZ)	
       ,NVL(a1.YRBGN_WRNT_CNTS_SZ,0)                        --年初期权张数(SZ)
       ,NVL(a2.YREND_WRNT_RGHT_HLD_MKTVAL_SH,0)             --年末期权账户权利仓市值(SH)
       ,NVL(a2.YREND_WRNT_DUTY_HLD_MKTVAL_SH,0)             --年末期权账户义务仓市值(SH)      
       ,NVL(a2.YREND_WRNT_MKTVAL_SH,0)                      --年末期权账户市值(权利仓市值-义务仓市值)(SH)	
       ,NVL(a2.YREND_WRNT_CNTS_SH,0)                        --年末期权张数(SH)
       ,NVL(a2.YREND_WRNT_RGHT_HLD_MKTVAL_SZ,0)             --年末期权账户权利仓市值(SZ)
       ,NVL(a2.YREND_WRNT_DUTY_HLD_MKTVAL_SZ,0)             --年末期权账户义务仓市值(SZ)      
       ,NVL(a2.YREND_WRNT_MKTVAL_SZ,0)                      --年末期权账户市值(权利仓市值-义务仓市值)(SZ)	
       ,NVL(a2.YREND_WRNT_CNTS_SZ,0)                        --年末期权张数(SZ)		   
 FROM (SELECT CUST_NO,BRH_NO,CUST_CGY 
       FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO 
	   WHERE BUS_DATE = %d{yyyyMMdd}
	   )                                        t
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP   a1
 ON        t.CUST_NO = a1.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP1   a2
 ON        t.CUST_NO = a2.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP2   a3
 ON        t.CUST_NO = a3.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP3   a4
 ON        t.CUST_NO = a4.CUST_NO
 WHERE  COALESCE(a1.CUST_NO,a2.CUST_NO,a3.CUST_NO,a4.CUST_NO) IS NOT NULL ;
 
 ----删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP  ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP1 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP2 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR_TEMP3 ;
 
-----------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_AST_CUST_AST_AGGR_YEAR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_YEAR;
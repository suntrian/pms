--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户对账单最大回撤年表                                                               */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-08-07                                                                        */ 
----
 --ALTER TABLE DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_UP_MON DROP IF EXISTS PARTITION (YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,0,0),1,6) as INT) ) ; 
-------创建临时表1
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MAX_DOWN_YEAR_TEMP;
  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_MAX_DOWN_YEAR_TEMP
  as SELECT MAX(YEAR_MON) as YEAR_MON
            ,CUST_NO
			,NET_INCM     
	 FROM  (SELECT  CUST_NO
	                ,NET_INCM
			        ,YEAR_MON
			        ,RANK() OVER(PARTITION BY CUST_NO ORDER BY NET_INCM DESC) as NUM
	        FROM    DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_UP_MON
	       WHERE    SUBSTR(CAST(YEAR_MON as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
	       )  t
	WHERE  t.NUM = 1
	GROUP BY CUST_NO,NET_INCM;
-------创建临时表2	
	  DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MAX_DOWN_YEAR_TEMP1;
  CREATE TABLE  DDW_PROD.T_DDW_CUST_STATMT_MAX_DOWN_YEAR_TEMP1
  as SELECT MIN(YEAR_MON) as YEAR_MON
            ,CUST_NO
			,NET_INCM     
	 FROM  (SELECT  CUST_NO
	                ,NET_INCM
			        ,YEAR_MON
			        ,RANK() OVER(PARTITION BY CUST_NO ORDER BY NET_INCM ASC) as NUM
	        FROM    DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_UP_MON a
	       WHERE    SUBSTR(CAST(YEAR_MON as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
		   AND      EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_CUST_STATMT_MAX_DOWN_YEAR_TEMP b
		                    WHERE  a.CUST_NO = b.CUST_NO
                            AND    a.YEAR_MON > = b.YEAR_MON							
		                   )
	       )  t
	WHERE  t.NUM = 1
	GROUP BY CUST_NO,NET_INCM;
  
 
 ---插入数据
  INSERT 	OVERWRITE DDW_PROD.T_DDW_CUST_STATMT_MAX_DOWN_YEAR
 (
            CUST_NO                      --客户号         
           ,MAX_MON                      --最大月份
           ,MIN_MON                      --最小月份
           ,MAX_DOWN		             --最大回撤
           ,ETL_DT                       --加载日期  							  
 ) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT) )
 SELECT     t.CUST_NO                  as CUST_NO                      --客户号
            ,a1.YEAR_MON               as MAX_MON                      --最大月份
            ,t.YEAR_MON   	           as MIN_MON                      --最小月份		
            ,a1.NET_INCM-t.NET_INCM    as MAX_DOWN		             --最大回撤
			,%d{yyyyMMdd}                  as ETL_DT                       --加载日期
 FROM        DDW_PROD.T_DDW_CUST_STATMT_MAX_DOWN_YEAR_TEMP1 t
 LEFT JOIN   DDW_PROD.T_DDW_CUST_STATMT_MAX_DOWN_YEAR_TEMP  a1
 ON          t.CUST_NO = a1.CUST_NO
 ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MAX_DOWN_YEAR_TEMP;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_MAX_DOWN_YEAR_TEMP1;
 
-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_STATMT_MAX_DOWN_YEAR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_CUST_STATMT_MAX_DOWN_YEAR;
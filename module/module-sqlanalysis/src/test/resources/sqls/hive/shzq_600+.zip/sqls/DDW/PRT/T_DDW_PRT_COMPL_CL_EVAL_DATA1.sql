 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:合规分类评价数据表1                                                                       */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2019-02-18                                                                        */ 

  --创建临时表(股票质押权限)
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP as
  SELECT     t.BRH_NO,t.BRH_SHRTNM as BRH_NAME,t.BELTO_FILIL_CDG,a1.CUST_CGY,a1.CUST_NO,a1.FNL_FLG,a1.ADDED_FLG
  FROM        DDW_PROD.T_DDW_INR_ORG_BRH  t
  LEFT JOIN   (SELECT a.CUST_NO
                     ,b.BRH_NO
					 ,b.CUST_CGY
					 ,MAX(CASE WHEN 20181228 BETWEEN a.OPN_DT AND a.CHG_DT
					           THEN 1
						       ELSE 0
						       END
						)   as FNL_FLG    
                     ,MAX(CASE WHEN SUBSTR(CAST(a.OPN_DT as STRING),1,4) = SUBSTR('20181228',1,4)
					           THEN 1
						       ELSE 0
						       END
						  )  as ADDED_FLG
              FROM (SELECT CUST_NO,EXG,OPN_PRVL,SHRHLD_NO,MIN(OPN_DT) as OPN_DT  
			               ,MAX(CHG_DT) as CHG_DT
			       FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL WHERE BUS_DATE = 20181228
				   GROUP BY CUST_NO,EXG,OPN_PRVL,SHRHLD_NO
				   ) a
			  LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO    b
			  ON        a.CUST_NO = b.CUST_NO
			  AND       b.BUS_DATE = 20190218
              WHERE  a.BUS_DATE = 20181228
              AND 	 ((20181228 BETWEEN a.OPN_DT AND a.CHG_DT)
			  OR    SUBSTR(CAST(OPN_DT as STRING),1,4) = SUBSTR('20181228',1,4))
			  AND    a.OPN_PRVL IN (106,110)
			  GROUP BY a.CUST_NO,b.BRH_NO,b.CUST_CGY
              )			  a1
 ON          t.BRH_NO = a1.BRH_NO
 WHERE  t.BUS_DATE = 20190218
 ;
    DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP_1;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP_1 as
 
 SELECT  t.BRH_NO                               --营业部
  , t.BRH_NAME                             --营业部名称
  ,t.BELTO_FILIL_CDG
  , SUM(CASE WHEN NVL(t.ADDED_FLG,0) = 1 
             AND  t.CUST_CGY = '0'
             THEN 1
		     ELSE 0
		     END
	   )             as STK_PLG_ADDED_IDV_ACTA               --股票质押新增个人客户数
  , SUM(CASE WHEN NVL(t.FNL_FLG,0) = 1
             AND  t.CUST_CGY = '0'
             THEN 1
		     ELSE 0
		     END
	   )            as STK_PLG_FNL_IDV_ACTA                 --股票质押期末个人客户数
  , SUM(CASE WHEN   t.CUST_CGY = '0'
             THEN   NVL(a1.MTCH_AMT,0)
			 ELSE 0
			 END 
  
        ) as STK_PLG_IDV_VOL                      --股票质押个人规模
  , SUM(CASE WHEN NVL(t.ADDED_FLG,0) = 1 
             AND  t.CUST_CGY = '1'
             THEN 1
		     ELSE 0
		     END
	   )   as STK_PLG_ADDED_ORG_ACTA               --股票质押新增机构客户数
  , SUM(CASE WHEN NVL(t.FNL_FLG,0) = 1
             AND  t.CUST_CGY = '1'
             THEN 1
		     ELSE 0
		     END
	   )  as STK_PLG_FNL_ORG_ACTA                 --股票质押期末机构客户数
  , SUM(CASE WHEN   t.CUST_CGY = '1'
             THEN   NVL(a1.MTCH_AMT,0)
			 ELSE 0
			 END 
  
        )  as STK_PLG_ORG_VOL                      --股票质押机构规模  
 FROM        DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP   t
 LEFT JOIN   (SELECT CUST_NO
                     ,SUM(MTCH_AMT)  as MTCH_AMT
              FROM  DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS 
              WHERE BUS_DATE =20181228 
			  AND   SEC_CGY NOT LIKE 'H%'
			  GROUP BY CUST_NO
			  )                                                      a1
 ON           t.CUST_NO = a1.CUST_NO
 GROUP BY  t.BRH_NO ,t.BRH_NAME,t.BELTO_FILIL_CDG
 ;
 
 
 
 
 
 
 
 
 
 --创建临时表(约定购回)
   DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP1;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP1 as
 SELECT     t.BRH_NO,t.BRH_SHRTNM as BRH_NAME,t.BELTO_FILIL_CDG,a1.CUST_CGY,a1.CUST_NO,a1.FNL_FLG,a1.ADDED_FLG
 FROM        DDW_PROD.T_DDW_INR_ORG_BRH  t
 LEFT JOIN   (SELECT a.CUST_NO
                    ,b.BRH_NO
					,b.CUST_CGY
					,MAX(CASE WHEN 20181228 BETWEEN a.OPN_DT AND a.CHG_DT
					       THEN 1
						   ELSE 0
						   END)   as FNL_FLG    
                    ,MAX(CASE WHEN SUBSTR(CAST(a.OPN_DT as STRING),1,4) = SUBSTR('20181228',1,4)
					          THEN 1
						      ELSE 0
						      END)  as ADDED_FLG
              FROM (SELECT CUST_NO,EXG,OPN_PRVL,SHRHLD_NO,MIN(OPN_DT) as OPN_DT  
			               ,MAX(CHG_DT) as CHG_DT
			       FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL WHERE BUS_DATE = 20181228
				   GROUP BY CUST_NO,EXG,OPN_PRVL,SHRHLD_NO) a
			  LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO    b
			  ON        a.CUST_NO = b.CUST_NO
			  AND       b.BUS_DATE = 20190218
              WHERE  a.BUS_DATE = 20181228
              AND 	 ((20181228 BETWEEN a.OPN_DT AND a.CHG_DT)
			  OR    SUBSTR(CAST(OPN_DT as STRING),1,4) = SUBSTR('20181228',1,4))
			  AND    a.OPN_PRVL IN (102)
			  GROUP BY a.CUST_NO,b.BRH_NO,b.CUST_CGY
              )			  a1
 ON          t.BRH_NO = a1.BRH_NO
 WHERE  t.BUS_DATE = 20190218
 ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP1_1 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP1_1 as
 SELECT  t.BRH_NO                               --营业部
  , t.BRH_NAME                             --营业部名称
  , SUM(CASE WHEN NVL(t.ADDED_FLG,0) = 1 
             AND  t.CUST_CGY = '0'
             THEN 1
		     ELSE 0
		     END
	   )             as  PROMS_RPHS_ADDED_IDV_ACTA            --约定购回新增个人客户数
  , SUM(CASE WHEN NVL(t.FNL_FLG,0) = 1
             AND  t.CUST_CGY = '0'
             THEN 1
		     ELSE 0
		     END
	   )            as PROMS_RPHS_FNL_IDV_ACTA              --约定购回期末个人客户数
  , SUM(0) as PROMS_RPHS_IDV_VOL                   --约定购回个人规模
  , SUM(CASE WHEN NVL(t.ADDED_FLG,0) = 1 
             AND  t.CUST_CGY = '1'
             THEN 1
		     ELSE 0
		     END
	   )   as  PROMS_RPHS_ADDED_ORG_ACTA            --约定购回新增机构客户数
  , SUM(CASE WHEN NVL(t.FNL_FLG,0) = 1
             AND  t.CUST_CGY = '1'
             THEN 1
		     ELSE 0
		     END
	   )  as PROMS_RPHS_FNL_ORG_ACTA              --约定购回期末机构客户数
  , SUM(0)  as PROMS_RPHS_ORG_VOL                   --约定购回机构规模
 FROM        DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP1   t
 GROUP BY  t.BRH_NO ,t.BRH_NAME
 ;
 
 ------创建临时表(债券回购表)
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP2;
  CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP2 as
 SELECT     t.BRH_NO,t.BRH_SHRTNM as BRH_NAME,t.BELTO_FILIL_CDG,a1.CUST_CGY,a1.CUST_NO,a1.FNL_FLG,a1.ADDED_FLG
 FROM        DDW_PROD.T_DDW_INR_ORG_BRH  t
 LEFT JOIN   (SELECT a.CUST_NO
                    ,b.BRH_NO
					,b.CUST_CGY
					,MAX(CASE WHEN 20181228 BETWEEN a.OPN_DT AND a.CHG_DT
					       THEN 1
						   ELSE 0
						   END)   as FNL_FLG    
                    ,MAX(CASE WHEN SUBSTR(CAST(a.OPN_DT as STRING),1,4) = SUBSTR('20181228',1,4)
					          THEN 1
						      ELSE 0
						      END)  as ADDED_FLG						   
              FROM (SELECT CUST_NO,EXG,OPN_PRVL,SHRHLD_NO,MIN(OPN_DT) as OPN_DT  
			               ,MAX(CHG_DT) as CHG_DT
			       FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL WHERE BUS_DATE = 20181228
				   GROUP BY CUST_NO,EXG,OPN_PRVL,SHRHLD_NO) a
			  LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO    b
			  ON        a.CUST_NO = b.CUST_NO
			  AND       b.BUS_DATE = 20190218
              WHERE  a.BUS_DATE = 20181228
              AND 	 ((20181228 BETWEEN a.OPN_DT AND a.CHG_DT)
			  OR    SUBSTR(CAST(OPN_DT as STRING),1,4) = SUBSTR('20181228',1,4))
			  AND    a.OPN_PRVL IN (2,3)
			  GROUP BY a.CUST_NO,b.BRH_NO,b.CUST_CGY
              )			  a1
 ON          t.BRH_NO = a1.BRH_NO
 WHERE  t.BUS_DATE = 20190218
 ;
 
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP2_1;
 CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP2_1 as
 SELECT  t.BRH_NO                               --营业部
  , t.BRH_NAME                             --营业部名称
  , SUM(CASE WHEN NVL(t.ADDED_FLG,0) = 1 
             AND  t.CUST_CGY = '0'
             THEN 1
		     ELSE 0
		     END
	   )             as BOND_REPO_ADDED_IDV_ACTA               --债券回购新增个人客户数
  , SUM(CASE WHEN NVL(t.FNL_FLG,0) = 1
             AND  t.CUST_CGY = '0'
             THEN 1
		     ELSE 0
		     END
	   )            as BOND_REPO_FNL_IDV_ACTA                 --债券回购期末个人客户数
  , SUM(CASE WHEN   t.CUST_CGY = '0'
             THEN   NVL(a1.MTCH_AMT,0)+NVL(a2.SEC_MKTVAL,0)
			 ELSE 0
			 END 
  
        ) as BOND_REPO_IDV_VOL                      --债券回购个人规模
  , SUM(CASE WHEN NVL(t.ADDED_FLG,0) = 1
             AND  t.CUST_CGY = '1'
             THEN 1
		     ELSE 0
		     END
	   )   as BOND_REPO_ADDED_ORG_ACTA               --债券回购新增机构客户数
  , SUM(CASE WHEN NVL(t.FNL_FLG,0) = 1
             AND  t.CUST_CGY = '1'
             THEN 1
		     ELSE 0
		     END
	   )  as BOND_REPO_FNL_ORG_ACTA                 --债券回购期末机构客户数
  , SUM(CASE WHEN   t.CUST_CGY = '1'
             THEN   NVL(a1.MTCH_AMT,0)+NVL(a2.SEC_MKTVAL,0)
			 ELSE 0
			 END 
  
        )  as BOND_REPO_ORG_VOL                      --债券回购机构规模  
 FROM        DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP2   t
 LEFT JOIN   (SELECT CUST_NO
                     ,SUM(MTCH_AMT)  as MTCH_AMT
              FROM  DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS 
              WHERE BUS_DATE =20181228 
			  AND   SEC_CGY  LIKE 'H%'
			  GROUP BY CUST_NO
			  )                                                      a1
 ON           t.CUST_NO = a1.CUST_NO
 LEFT JOIN   (SELECT CUST_NO
                     ,SUM(SEC_MKTVAL)  as SEC_MKTVAL
              FROM  DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS 
              WHERE BUS_DATE =20181228 
			  AND   SEC_CGY  LIKE 'H%'
			  GROUP BY CUST_NO
			  )                                                      a2
 ON           t.CUST_NO = a2.CUST_NO
 GROUP BY  t.BRH_NO ,t.BRH_NAME
 ;
-----
 --创建临时表(融资融券)
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP3;
 CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP3 as
 SELECT     t.BRH_NO,t.BRH_SHRTNM as BRH_NAME,a1.CUST_NO,MIN(OPNAC_DT) as OPNAC_DT
 FROM        DDW_PROD.T_DDW_INR_ORG_BRH  t
 LEFT JOIN   DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS  a1
 ON          t.BRH_NO = a1.BRH_NO
 AND         a1.BUS_DATE = 20181228
 AND         a1.SYS_SRC  = '信用账户'
 AND         a1.CPTL_ACCNT_STAT < > '3'
 WHERE  t.BUS_DATE = 20190218
 
 GROUP BY t.BRH_NO,t.BRH_SHRTNM,a1.CUST_NO
 ; 

 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP3_1;
 CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP3_1 as
SELECT                            t.BRH_NO                   --营业部
                                , t.BRH_NAME                 --营业部名称
                                , SUM(CASE WHEN SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) =  SUBSTR('20181228',1,4)
								           THEN 1
								           ELSE 0
									       END
									  )     as CRD_OPNAC_ACTA_YAER                  --信用当年开户数         
                                , SUM(CASE WHEN t.CUST_NO IS NULL
								           THEN 0
									       ELSE 1
									       END
									 )      as CRD_FNL_ACTA                         --信用期末户数
                                , SUM(NVL(a1.FNL_MRGNC_MRGNS_BAL,0)) as FNL_MRGNC_MRGNS_BAL      --期末融资融券余额								  
 FROM      DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP3    t
 LEFT JOIN (SELECT KHH,SUM(RZJE+RQJE) as FNL_MRGNC_MRGNS_BAL 
            FROM EDW_PROD.T_EDW_T02_TXY_HTXXLS 
		    WHERE BUS_DATE = 20181228   
		    GROUP BY KHH) a1
 ON        t.CUST_NO = a1.KHH
 GROUP BY  t.BRH_NO,t.BRH_NAME
 ;

-----产品认购申购赎回
 DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP4;
 CREATE TABLE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP4 as
 SELECT      t.BRH_NO
            ,t.BRH_SHRTNM as BRH_NAME
           ,SUM(CASE WHEN a2.PROD_CGY = 8
		             AND  a2.PROD_CD  < > 'A30003'
				     AND  a2.PROD_BIZ_CD = '130'
				     THEN a2.CNFM_SHR
				     ELSE 0
				     END
			    )          as FND_PROD_SCRP_SHR --场外基金产品认购份额
		   ,SUM(CASE WHEN a2.PROD_CGY = 8
		             AND  a2.PROD_CD  < > 'A30003'
				     AND  a2.PROD_BIZ_CD = '130'
				     THEN a2. CNFM_AMT
				     ELSE 0
				     END
			    )          as FND_PROD_SCRP_AMT --场外基金产品认购金额
		    ,SUM(CASE WHEN a2.PROD_CGY = 8
		             AND  a2.PROD_CD  < > 'A30003'
				     AND  a2.PROD_BIZ_CD IN ('122','139')
				     THEN a2.CNFM_SHR
				     ELSE 0
				     END
			    )          as FND_PROD_PRCH_SHR --场外基金产品申购份额
		   ,SUM(CASE WHEN a2.PROD_CGY = 8
		             AND  a2.PROD_CD  < > 'A30003'
				     AND  a2.PROD_BIZ_CD IN ('122','139')
				     THEN a2. CNFM_AMT
				     ELSE 0
				     END
			    )          as FND_PROD_PRCH_AMT --场外基金产品申购金额
		    ,SUM(CASE WHEN a2.PROD_CGY = 8
		             AND  a2.PROD_CD  < > 'A30003'
				     AND  a2.PROD_BIZ_CD IN ('124','142')
				     THEN a2.CNFM_SHR
				     ELSE 0
				     END
			    )          as FND_PROD_RDMPT_SHR --场外基金产品赎回份额
		   ,SUM(CASE WHEN a2.PROD_CGY = 8
		             AND  a2.PROD_CD  < > 'A30003'
				     AND  a2.PROD_BIZ_CD IN ('124','142')
				     THEN a2. CNFM_AMT
				     ELSE 0
				     END
			    )          as FND_PROD_RDMPT_AMT --场外基金产品赎回金额
		  ,SUM(CASE WHEN a2.PROD_CGY = 9
		             AND  a2.PROD_CD  < > 'A30003'
				     AND  a2.PROD_BIZ_CD = '130'
				     THEN a2.CNFM_SHR
				     ELSE 0
				     END
			    )          as BANK_PROD_SCRP_SHR --银行产品认购份额
		   ,SUM(CASE WHEN a2.PROD_CGY = 9
		             AND  a2.PROD_CD  < > 'A30003'
				     AND  a2.PROD_BIZ_CD = '130'
				     THEN a2. CNFM_AMT
				     ELSE 0
				     END
			    )          as BANK_PROD_SCRP_AMT --银行产品认购金额
		   ,SUM(CASE WHEN a2.PROD_CGY = 9
		             AND  a2.PROD_CD  < > 'A30003'
				     AND  a2.PROD_BIZ_CD IN ('124','142')
				     THEN a2.CNFM_SHR
				     ELSE 0
				     END
			    )          as BANK_PROD_RDMPT_SHR --银行产品赎回份额
		   ,SUM(CASE WHEN a2.PROD_CGY = 9
		             AND  a2.PROD_CD  < > 'A30003'
				     AND  a2.PROD_BIZ_CD IN ('124','142')
				     THEN a2. CNFM_AMT
				     ELSE 0
				     END
			    )          as BANK_PROD_RDMPT_AMT --银行产品赎回金额
 FROM        DDW_PROD.T_DDW_INR_ORG_BRH  t
 LEFT JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO   a1
 ON          t.BRH_NO = a1.BRH_NO
 AND         a1.BUS_DATE = 20190218
 LEFT JOIN   DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS  a2
 ON          a1.CUST_NO = a2.CUST_NO
 AND         SUBSTR(CAST(a2.BUS_DATE as STRING),1,4) = SUBSTR('20181228',1,4)
 WHERE  t.BUS_DATE = 20190218
 
 GROUP BY t.BRH_NO,t.BRH_SHRTNM ;
 
 
 
   
 
 
  
  INSERT OVERWRITE DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1
 (
   BRH_NO                              --营业部
  ,BRH_NAME                            --营业部名称
  ,BELTO_FILIL_CDG                     --地区代码
  ,STK_PLG_ADDED_IDV_ACTA              --股票质押新增个人客户数
  ,STK_PLG_FNL_IDV_ACTA                --股票质押期末个人客户数
  ,STK_PLG_IDV_VOL                     --股票质押个人规模
  ,STK_PLG_ADDED_ORG_ACTA              --股票质押新增机构客户数
  ,STK_PLG_FNL_ORG_ACTA                --股票质押期末机构客户数
  ,STK_PLG_ORG_VOL                     --股票质押机构规模  
  ,PROMS_RPHS_ADDED_IDV_ACTA           --约定购回新增个人客户数
  ,PROMS_RPHS_FNL_IDV_ACTA             --约定购回期末个人客户数
  ,PROMS_RPHS_IDV_VOL                  --约定购回个人规模
  ,PROMS_RPHS_ADDED_ORG_ACTA           --约定购回新增机构客户数
  ,PROMS_RPHS_FNL_ORG_ACTA             --约定购回期末机构客户数
  ,PROMS_RPHS_ORG_VOL                  --约定购回机构规模
  ,BOND_REPO_ADDED_IDV_ACTA            --债券回购新增个人客户数
  ,BOND_REPO_FNL_IDV_ACTA              --债券回购期末个人客户数
  ,BOND_REPO_IDV_VOL                   --债券回购个人规模
  ,BOND_REPO_ADDED_ORG_ACTA            --债券回购新增机构客户数
  ,BOND_REPO_FNL_ORG_ACTA              --债券回购期末机构客户数
  ,BOND_REPO_ORG_VOL                   --债券回购机构规模  
  ,CRD_OPNAC_ACTA_YAER                 --信用当年开户数
  ,CRD_FNL_ACTA                        --信用期末户数
  ,FNL_MRGNC_MRGNS_BAL                 --期末融资融券余额			
  ,FND_PROD_SCRP_SHR                   --场外基金产品认购份额
  ,FND_PROD_SCRP_AMT                   --场外基金产品认购金额
  ,FND_PROD_PRCH_SHR                   --场外基金产品申购份额
  ,FND_PROD_PRCH_AMT                   --场外基金产品申购金额
  ,FND_PROD_RDMPT_SHR                  --场外基金产品赎回份额
  ,FND_PROD_RDMPT_AMT                  --场外基金产品赎回金额
  ,FND_PROD_CY_SHR                     --场外基金产品代销份额
  ,FND_PROD_CY_AMT                     --场外基金产品代销金额
  ,BANK_PROD_SCRP_SHR                  --银行产品认购份额
  ,BANK_PROD_SCRP_AMT                  --银行产品认购金额
  ,BANK_PROD_RDMPT_SHR                 --银行产品赎回份额
  ,BANK_PROD_RDMPT_AMT                 --银行产品赎回金额 
  ,BANK_PROD_CY_SHR                    --银行产品代销份额
  ,BANK_PROD_CY_AMT                    --银行产品代销金额 
                                
 )  PARTITION(YEAR = CAST(SUBSTR('20181228',1,4) as INT))
 
 SELECT  t.BRH_NO                                      --营业部
        ,t.BRH_NAME                                    --营业部名称
        ,t.BELTO_FILIL_CDG                             --地区代码
        ,t.STK_PLG_ADDED_IDV_ACTA                      --股票质押新增个人客户数
        ,t.STK_PLG_FNL_IDV_ACTA                        --股票质押期末个人客户数
        ,t.STK_PLG_IDV_VOL                             --股票质押个人规模
        ,t.STK_PLG_ADDED_ORG_ACTA                      --股票质押新增机构客户数
        ,t.STK_PLG_FNL_ORG_ACTA                        --股票质押期末机构客户数
        ,t.STK_PLG_ORG_VOL                             --股票质押机构规模  
        ,NVL(a1.PROMS_RPHS_ADDED_IDV_ACTA,0)           --约定购回新增个人客户数
        ,NVL(a1.PROMS_RPHS_FNL_IDV_ACTA,0)             --约定购回期末个人客户数
        ,NVL(a1.PROMS_RPHS_IDV_VOL,0)                  --约定购回个人规模
        ,NVL(a1.PROMS_RPHS_ADDED_ORG_ACTA,0)           --约定购回新增机构客户数
        ,NVL(a1.PROMS_RPHS_FNL_ORG_ACTA,0)             --约定购回期末机构客户数
        ,NVL(a1.PROMS_RPHS_ORG_VOL,0)                  --约定购回机构规模
        ,NVL(a2.BOND_REPO_ADDED_IDV_ACTA,0)            --债券回购新增个人客户数
        ,NVL(a2.BOND_REPO_FNL_IDV_ACTA,0)              --债券回购期末个人客户数
        ,NVL(a2.BOND_REPO_IDV_VOL,0)                   --债券回购个人规模
        ,NVL(a2.BOND_REPO_ADDED_ORG_ACTA,0)            --债券回购新增机构客户数
        ,NVL(a2.BOND_REPO_FNL_ORG_ACTA,0)              --债券回购期末机构客户数
        ,NVL(a2.BOND_REPO_ORG_VOL,0)                   --债券回购机构规模  
        ,NVL(a3.CRD_OPNAC_ACTA_YAER,0)                 --信用当年开户数
        ,NVL(a3.CRD_FNL_ACTA,0)                        --信用期末户数
        ,NVL(a3.FNL_MRGNC_MRGNS_BAL,0)                 --期末融资融券余额			
        ,NVL(a4.FND_PROD_SCRP_SHR,0)                   --场外基金产品认购份额
        ,NVL(a4.FND_PROD_SCRP_AMT,0)                   --场外基金产品认购金额
        ,NVL(a4.FND_PROD_PRCH_SHR,0)                   --场外基金产品申购份额
        ,NVL(a4.FND_PROD_PRCH_AMT,0)                   --场外基金产品申购金额
        ,NVL(a4.FND_PROD_RDMPT_SHR,0)                  --场外基金产品赎回份额
        ,NVL(a4.FND_PROD_RDMPT_AMT,0)                  --场外基金产品赎回金额
        ,NVL(a4.FND_PROD_SCRP_SHR,0)+NVL(a4.FND_PROD_PRCH_SHR,0)- NVL(a4.FND_PROD_RDMPT_SHR,0)                    --场外基金产品代销份额
        ,NVL(a4.FND_PROD_SCRP_AMT,0)+NVL(a4.FND_PROD_PRCH_AMT,0)- NVL(a4.FND_PROD_RDMPT_AMT,0)                       --场外基金产品代销金额
        ,NVL(a4.BANK_PROD_SCRP_SHR,0)                  --银行产品认购份额
        ,NVL(a4.BANK_PROD_SCRP_AMT,0)                  --银行产品认购金额
        ,NVL(a4.BANK_PROD_RDMPT_SHR,0)                 --银行产品赎回份额
        ,NVL(a4.BANK_PROD_RDMPT_AMT,0)                 --银行产品赎回金额 
        ,NVL(a4.BANK_PROD_SCRP_SHR,0)- NVL(a4.BANK_PROD_RDMPT_SHR,0)                   --银行产品代销份额
        ,NVL(a4.BANK_PROD_SCRP_AMT,0)- NVL(a4.BANK_PROD_RDMPT_AMT,0)                    --银行产品代销金额 
 FROM        DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP_1   t
 LEFT JOIN   DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP1_1   a1                                                  
 ON           t.BRH_NO = a1.BRH_NO 
 LEFT JOIN   DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP2_1   a2                                                  
 ON           t.BRH_NO = a2.BRH_NO 
 LEFT JOIN   DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP3_1   a3                                                  
 ON           t.BRH_NO = a3.BRH_NO 
 LEFT JOIN   DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP4   a4                                                
 ON           t.BRH_NO = a4.BRH_NO 
 ;
 ---删除临时表
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP1;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEM2;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEM3;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEM4;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP_1;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEMP1_1;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEM2_1;
  DROP TABLE IF EXISTS  DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1_TEM3_1;
  
  
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_COMPL_CL_EVAL_DATA1',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_COMPL_CL_EVAL_DATA1 ;
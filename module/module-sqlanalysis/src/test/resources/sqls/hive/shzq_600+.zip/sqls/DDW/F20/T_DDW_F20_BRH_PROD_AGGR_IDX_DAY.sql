------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:营业部产品汇总指标日表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2019-05-21                                                                       */
--IF_MAIN  0--不重要 1-重要 2-全部

DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY_TEMP as 
SELECT        b.BRH_NO
             ,'0'  as IF_MAIN
			 , SUM(DECODE(a.PROD_CL_CD,'010100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'010400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'010500',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as ETMT_PUB_PROD_SALE            --权益类公募销量
			 , SUM(DECODE(a.PROD_CL_CD,'010200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as BOND_PUB_PROD_SALE            --债券类公募销量
             , SUM(DECODE(a.PROD_CL_CD,'010300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as CCY_PUB_PROD_SALE             --货币类公募销量
			 , SUM(DECODE(a.PROD_CL_CD,'080100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080500',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080600',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as FND_SPELACT_PROD_SALE         --基金专产品户销量
             , SUM(DECODE(a.PROD_CL_CD,'020100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'020200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'020300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'020400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as PRV_FND_PROD_SALE             --私募基金销量
             , SUM(DECODE(a.PROD_CL_CD,'050100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as BANK_PROD_SALE                --银行产品销量
			 , SUM(DECODE(a.PROD_CL_CD,'070100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'070200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'070300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'070400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as GTJA_PROD_SALE                --国君产品销量
			 , SUM(DECODE(a.PROD_CL_CD,'040100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'040200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'040300',0)) as SHZQ_PROD_SALE                --公司产品销量
			 , SUM(DECODE(a.PROD_CD,'A30003',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as CASH_PROD_SALE                --现金添利产品销量
			 , SUM(DECODE(a.PROD_CL_CD,'060100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as OTC_PROD_SALE             --OTC产品销量
			 , SUM(DECODE(a.PROD_CL_CD,'010100',a.HLD_AMT,'010400',a.HLD_AMT,'010500',a.HLD_AMT,0)) as ETMT_PUB_PROD_HLD_AMT         --权益类公募保有量			 
			 , SUM(DECODE(a.PROD_CL_CD,'010200',a.HLD_AMT,0)) as BOND_PUB_PROD_HLD_AMT         --债券类公募保有量
             , SUM(DECODE(a.PROD_CL_CD,'010300',a.HLD_AMT,0)) as CCY_PUB_PROD_HLD_AMT          --货币类公募保有量
			 , SUM(DECODE(a.PROD_CL_CD,'080100',a.HLD_AMT,'080200',a.HLD_AMT,'080300',a.HLD_AMT,'080400',a.HLD_AMT,'080500',a.HLD_AMT,'080600',a.HLD_AMT,0)) as FND_SPELACT_PROD_HLD_AMT      --基金专产品户保有量
             , SUM(DECODE(a.PROD_CL_CD,'020100',a.HLD_AMT,'020200',a.HLD_AMT,'020300',a.HLD_AMT,'020400',a.HLD_AMT,0)) as PRV_FND_PROD_HLD_AMT          --私募基金保有量
             , SUM(DECODE(a.PROD_CL_CD,'050100',a.HLD_AMT,0)) as BANK_PROD_HLD_AMT             --银行产品保有量
			 , SUM(DECODE(a.PROD_CL_CD,'070100',a.HLD_AMT,'070200',a.HLD_AMT,'070300',a.HLD_AMT,'070400',a.HLD_AMT,0)) as GTJA_PROD_HLD_AMT             --国君产品保有量
			 , SUM(DECODE(a.PROD_CL_CD,'040100',a.HLD_AMT,'040200',a.HLD_AMT,'040300',0)) as SHZQ_PROD_HLD_AMT             --公司产品保有量
			 , SUM(DECODE(a.PROD_CD,'A30003',a.HLD_AMT,0)) as CASH_PROD_HLD_AMT             --现金添利产品保有量
			 , SUM(DECODE(a.PROD_CL_CD,'060100',a.HLD_AMT,0)) as OTC_PROD_HLD_AMT             --OTC产品保有量
            
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
AND         b.BUS_DATE = %d{yyyyMMdd}
WHERE       a.MAIN_SALE_FLG = '0'
AND         a.BUS_DATE = %d{yyyyMMdd}
GROUP BY b.BRH_NO
 ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY_TEMP1 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY_TEMP1 as 
SELECT        b.BRH_NO
             ,'0'  as IF_MAIN
			 , SUM(DECODE(a.PROD_CL_CD,'010100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'010400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'010500',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as ETMT_PUB_PROD_SALE            --权益类公募销量
			 , SUM(DECODE(a.PROD_CL_CD,'010200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as BOND_PUB_PROD_SALE            --债券类公募销量
             , SUM(DECODE(a.PROD_CL_CD,'010300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as CCY_PUB_PROD_SALE             --货币类公募销量
			 , SUM(DECODE(a.PROD_CL_CD,'080100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080500',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080600',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as FND_SPELACT_PROD_SALE         --基金专产品户销量
             , SUM(DECODE(a.PROD_CL_CD,'020100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'020200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'020300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'020400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as PRV_FND_PROD_SALE             --私募基金销量
             , SUM(DECODE(a.PROD_CL_CD,'050100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as BANK_PROD_SALE                --银行产品销量
			 , SUM(DECODE(a.PROD_CL_CD,'070100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'070200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'070300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'070400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as GTJA_PROD_SALE                --国君产品销量
			 , SUM(DECODE(a.PROD_CL_CD,'040100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'040200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'040300',0)) as SHZQ_PROD_SALE                --公司产品销量
			 , SUM(DECODE(a.PROD_CD,'A30003',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as CASH_PROD_SALE                --现金添利产品销量
			 , SUM(DECODE(a.PROD_CL_CD,'060100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as OTC_PROD_SALE             --OTC产品销量
			 , SUM(DECODE(a.PROD_CL_CD,'010100',a.HLD_AMT,'010400',a.HLD_AMT,'010500',a.HLD_AMT,0)) as ETMT_PUB_PROD_HLD_AMT         --权益类公募保有量			 
			 , SUM(DECODE(a.PROD_CL_CD,'010200',a.HLD_AMT,0)) as BOND_PUB_PROD_HLD_AMT         --债券类公募保有量
             , SUM(DECODE(a.PROD_CL_CD,'010300',a.HLD_AMT,0)) as CCY_PUB_PROD_HLD_AMT          --货币类公募保有量
			 , SUM(DECODE(a.PROD_CL_CD,'080100',a.HLD_AMT,'080200',a.HLD_AMT,'080300',a.HLD_AMT,'080400',a.HLD_AMT,'080500',a.HLD_AMT,'080600',a.HLD_AMT,0)) as FND_SPELACT_PROD_HLD_AMT      --基金专产品户保有量
             , SUM(DECODE(a.PROD_CL_CD,'020100',a.HLD_AMT,'020200',a.HLD_AMT,'020300',a.HLD_AMT,'020400',a.HLD_AMT,0)) as PRV_FND_PROD_HLD_AMT          --私募基金保有量
             , SUM(DECODE(a.PROD_CL_CD,'050100',a.HLD_AMT,0)) as BANK_PROD_HLD_AMT             --银行产品保有量
			 , SUM(DECODE(a.PROD_CL_CD,'070100',a.HLD_AMT,'070200',a.HLD_AMT,'070300',a.HLD_AMT,'070400',a.HLD_AMT,0)) as GTJA_PROD_HLD_AMT             --国君产品保有量
			 , SUM(DECODE(a.PROD_CL_CD,'040100',a.HLD_AMT,'040200',a.HLD_AMT,'040300',0)) as SHZQ_PROD_HLD_AMT             --公司产品保有量
			 , SUM(DECODE(a.PROD_CD,'A30003',a.HLD_AMT,0)) as CASH_PROD_HLD_AMT             --现金添利产品保有量
			 , SUM(DECODE(a.PROD_CL_CD,'060100',a.HLD_AMT,0)) as OTC_PROD_HLD_AMT             --OTC产品保有量
            
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
AND         b.BUS_DATE = %d{yyyyMMdd}
WHERE       a.MAIN_SALE_FLG = '1'
AND         a.BUS_DATE = %d{yyyyMMdd}
GROUP BY b.BRH_NO
 ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY_TEMP2 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY_TEMP2 as 
SELECT        b.BRH_NO
             ,'2'  as IF_MAIN
			 , SUM(DECODE(a.PROD_CL_CD,'010100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'010400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'010500',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as ETMT_PUB_PROD_SALE            --权益类公募销量
			 , SUM(DECODE(a.PROD_CL_CD,'010200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as BOND_PUB_PROD_SALE            --债券类公募销量
             , SUM(DECODE(a.PROD_CL_CD,'010300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as CCY_PUB_PROD_SALE             --货币类公募销量
			 , SUM(DECODE(a.PROD_CL_CD,'080100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080500',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'080600',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as FND_SPELACT_PROD_SALE         --基金专产品户销量
             , SUM(DECODE(a.PROD_CL_CD,'020100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'020200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'020300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'020400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as PRV_FND_PROD_SALE             --私募基金销量
             , SUM(DECODE(a.PROD_CL_CD,'050100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as BANK_PROD_SALE                --银行产品销量
			 , SUM(DECODE(a.PROD_CL_CD,'070100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'070200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'070300',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'070400',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as GTJA_PROD_SALE                --国君产品销量
			 , SUM(DECODE(a.PROD_CL_CD,'040100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'040200',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,'040300',0)) as SHZQ_PROD_SALE                --公司产品销量
			 , SUM(DECODE(a.PROD_CD,'A30003',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as CASH_PROD_SALE                --现金添利产品销量
			 , SUM(DECODE(a.PROD_CL_CD,'060100',a.SCRP_AMT+a.PRCH_AMT+a.FIXINV_AMT,0)) as OTC_PROD_SALE             --OTC产品销量
			 , SUM(DECODE(a.PROD_CL_CD,'010100',a.HLD_AMT,'010400',a.HLD_AMT,'010500',a.HLD_AMT,0)) as ETMT_PUB_PROD_HLD_AMT         --权益类公募保有量			 
			 , SUM(DECODE(a.PROD_CL_CD,'010200',a.HLD_AMT,0)) as BOND_PUB_PROD_HLD_AMT         --债券类公募保有量
             , SUM(DECODE(a.PROD_CL_CD,'010300',a.HLD_AMT,0)) as CCY_PUB_PROD_HLD_AMT          --货币类公募保有量
			 , SUM(DECODE(a.PROD_CL_CD,'080100',a.HLD_AMT,'080200',a.HLD_AMT,'080300',a.HLD_AMT,'080400',a.HLD_AMT,'080500',a.HLD_AMT,'080600',a.HLD_AMT,0)) as FND_SPELACT_PROD_HLD_AMT      --基金专产品户保有量
             , SUM(DECODE(a.PROD_CL_CD,'020100',a.HLD_AMT,'020200',a.HLD_AMT,'020300',a.HLD_AMT,'020400',a.HLD_AMT,0)) as PRV_FND_PROD_HLD_AMT          --私募基金保有量
             , SUM(DECODE(a.PROD_CL_CD,'050100',a.HLD_AMT,0)) as BANK_PROD_HLD_AMT             --银行产品保有量
			 , SUM(DECODE(a.PROD_CL_CD,'070100',a.HLD_AMT,'070200',a.HLD_AMT,'070300',a.HLD_AMT,'070400',a.HLD_AMT,0)) as GTJA_PROD_HLD_AMT             --国君产品保有量
			 , SUM(DECODE(a.PROD_CL_CD,'040100',a.HLD_AMT,'040200',a.HLD_AMT,'040300',0)) as SHZQ_PROD_HLD_AMT             --公司产品保有量
			 , SUM(DECODE(a.PROD_CD,'A30003',a.HLD_AMT,0)) as CASH_PROD_HLD_AMT             --现金添利产品保有量
			 , SUM(DECODE(a.PROD_CL_CD,'060100',a.HLD_AMT,0)) as OTC_PROD_HLD_AMT             --OTC产品保有量
            
FROM         DDW_PROD.T_DDW_F10_CUST_PROD_DAY a
INNER JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  b
ON          a.CUST_NO = b.CUST_NO
AND         b.BUS_DATE = %d{yyyyMMdd}
WHERE       a.BUS_DATE = %d{yyyyMMdd}
GROUP BY b.BRH_NO
 ;

INSERT OVERWRITE  DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY
(              BELTO_FILIL_CDG               --分公司编码
             , BELTO_FILIL                   --分公司名称
             , BRH_NO                        --营业部编码
             , BRH_FULLNM                    --营业部名称
             , IF_MAIN                       --是否重要销售
             , ETMT_PUB_PROD_SALE            --权益类公募销量
			 , BOND_PUB_PROD_SALE            --债券类公募销量
             , CCY_PUB_PROD_SALE             --货币类公募销量
			 , FND_SPELACT_PROD_SALE         --基金专产品户销量
             , PRV_FND_PROD_SALE             --私募基金销量
             , BANK_PROD_SALE                --银行产品销量
			 , GTJA_PROD_SALE                --国君产品销量
			 , SHZQ_PROD_SALE                --公司产品销量
			 , CASH_PROD_SALE                --现金添利产品销量
			 , OTC_PROD_SALE                 --OTC产品销量
			 , ETMT_PUB_PROD_HLD_AMT         --权益类公募保有量			 
			 , BOND_PUB_PROD_HLD_AMT         --债券类公募保有量
             , CCY_PUB_PROD_HLD_AMT          --货币类公募保有量
			 , FND_SPELACT_PROD_HLD_AMT      --基金专产品户保有量
             , PRV_FND_PROD_HLD_AMT          --私募基金保有量
             , BANK_PROD_HLD_AMT             --银行产品保有量
			 , GTJA_PROD_HLD_AMT             --国君产品保有量
			 , SHZQ_PROD_HLD_AMT             --公司产品保有量
			 , CASH_PROD_HLD_AMT             --现金添利产品保有量
			 , OTC_PROD_HLD_AMT              --OTC产品保有量
			 , IF_TRD_DT                     --是否是交易日 				
 ) PARTITION(BUS_DATE )
 SELECT        t.BELTO_FILIL_CDG               --分公司编码
             , t.BELTO_FILIL                   --分公司名称
             , t.BRH_NO                        --营业部编码
             , t.BRH_FULLNM                    --营业部名称
             , t.IF_MAIN                       --是否重要销售
             , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.ETMT_PUB_PROD_SALE,0),0)            --权益类公募销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.BOND_PUB_PROD_SALE,0),0)            --债券类公募销量
             , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.CCY_PUB_PROD_SALE,0),0)             --货币类公募销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.FND_SPELACT_PROD_SALE,0),0)         --基金专产品户销量
             , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.PRV_FND_PROD_SALE,0),0)             --私募基金销量
             , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.BANK_PROD_SALE,0),0)                --银行产品销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.GTJA_PROD_SALE,0),0)                --国君产品销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.SHZQ_PROD_SALE,0),0)                --公司产品销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.CASH_PROD_SALE,0),0)                --现金添利产品销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.OTC_PROD_SALE,0),0)                 --OTC产品销量
			 , NVL(a1.ETMT_PUB_PROD_HLD_AMT,0)         --权益类公募保有量			 
			 , NVL(a1.BOND_PUB_PROD_HLD_AMT,0)         --债券类公募保有量
             , NVL(a1.CCY_PUB_PROD_HLD_AMT,0)          --货币类公募保有量
			 , NVL(a1.FND_SPELACT_PROD_HLD_AMT,0)      --基金专产品户保有量
             , NVL(a1.PRV_FND_PROD_HLD_AMT,0)          --私募基金保有量
             , NVL(a1.BANK_PROD_HLD_AMT,0)             --银行产品保有量
			 , NVL(a1.GTJA_PROD_HLD_AMT,0)             --国君产品保有量
			 , NVL(a1.SHZQ_PROD_HLD_AMT,0)             --公司产品保有量
			 , NVL(a1.CASH_PROD_HLD_AMT,0)             --现金添利产品保有量
			 , NVL(a1.OTC_PROD_HLD_AMT,0)             --OTC产品保有量
			 , CASE WHEN t.TRD_DT = a2.NAT_DT
			        THEN '是'
					ELSE '否'
					END     IF_TRD_DT                     --是否是交易日
             , CAST(a2.NAT_DT as INT) as BUS_DATE 			 
 FROM  (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
			  ,'0'  as IF_MAIN
			  ,%d{yyyyMMdd} as TRD_DT
        FROM  DDW_PROD.T_DDW_INR_ORG_BRH
		WHERE BUS_DATE = %d{yyyyMMdd}
		)                       t
 LEFT JOIN DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY_TEMP a1
 ON  t.BRH_NO = a1.BRH_NO
 LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE a2
 ON        t.TRD_DT = a2.TRD_DT
 AND       a2.BUS_DATE = %d{yyyyMMdd}
 UNION ALL
 SELECT        t.BELTO_FILIL_CDG               --分公司编码
             , t.BELTO_FILIL                   --分公司名称
             , t.BRH_NO                        --营业部编码
             , t.BRH_FULLNM                    --营业部名称
             , t.IF_MAIN                       --是否重要销售
             , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.ETMT_PUB_PROD_SALE,0),0)            --权益类公募销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.BOND_PUB_PROD_SALE,0),0)            --债券类公募销量
             , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.CCY_PUB_PROD_SALE,0),0)             --货币类公募销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.FND_SPELACT_PROD_SALE,0),0)         --基金专产品户销量
             , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.PRV_FND_PROD_SALE,0),0)             --私募基金销量
             , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.BANK_PROD_SALE,0),0)                --银行产品销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.GTJA_PROD_SALE,0),0)                --国君产品销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.SHZQ_PROD_SALE,0),0)                --公司产品销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.CASH_PROD_SALE,0),0)                --现金添利产品销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.OTC_PROD_SALE,0),0)                 --OTC产品销量
			 , NVL(a1.ETMT_PUB_PROD_HLD_AMT,0)         --权益类公募保有量			 
			 , NVL(a1.BOND_PUB_PROD_HLD_AMT,0)         --债券类公募保有量
             , NVL(a1.CCY_PUB_PROD_HLD_AMT,0)          --货币类公募保有量
			 , NVL(a1.FND_SPELACT_PROD_HLD_AMT,0)      --基金专产品户保有量
             , NVL(a1.PRV_FND_PROD_HLD_AMT,0)          --私募基金保有量
             , NVL(a1.BANK_PROD_HLD_AMT,0)             --银行产品保有量
			 , NVL(a1.GTJA_PROD_HLD_AMT,0)             --国君产品保有量
			 , NVL(a1.SHZQ_PROD_HLD_AMT,0)             --公司产品保有量
			 , NVL(a1.CASH_PROD_HLD_AMT,0)             --现金添利产品保有量
			 , NVL(a1.OTC_PROD_HLD_AMT,0)             --OTC产品保有量
			 , CASE WHEN t.TRD_DT = a2.NAT_DT
			        THEN '是'
					ELSE '否'
					END     IF_TRD_DT                     --是否是交易日
             , CAST(a2.NAT_DT as INT) as BUS_DATE 			 
 FROM  (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
			  ,'1'  as IF_MAIN
			  ,%d{yyyyMMdd} as TRD_DT
        FROM  DDW_PROD.T_DDW_INR_ORG_BRH
		WHERE BUS_DATE = %d{yyyyMMdd}
		)                       t
 LEFT JOIN DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY_TEMP1 a1
 ON  t.BRH_NO = a1.BRH_NO
 LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE a2
 ON        t.TRD_DT = a2.TRD_DT
 AND       a2.BUS_DATE = %d{yyyyMMdd}
 UNION ALL
 SELECT        t.BELTO_FILIL_CDG               --分公司编码
             , t.BELTO_FILIL                   --分公司名称
             , t.BRH_NO                        --营业部编码
             , t.BRH_FULLNM                    --营业部名称
             , t.IF_MAIN                       --是否重要销售
             , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.ETMT_PUB_PROD_SALE,0),0)            --权益类公募销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.BOND_PUB_PROD_SALE,0),0)            --债券类公募销量
             , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.CCY_PUB_PROD_SALE,0),0)             --货币类公募销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.FND_SPELACT_PROD_SALE,0),0)         --基金专产品户销量
             , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.PRV_FND_PROD_SALE,0),0)             --私募基金销量
             , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.BANK_PROD_SALE,0),0)                --银行产品销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.GTJA_PROD_SALE,0),0)                --国君产品销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.SHZQ_PROD_SALE,0),0)                --公司产品销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.CASH_PROD_SALE,0),0)                --现金添利产品销量
			 , NVL(DECODE(t.TRD_DT,a2.NAT_DT,a1.OTC_PROD_SALE,0),0)                 --OTC产品销量
			 , NVL(a1.ETMT_PUB_PROD_HLD_AMT,0)         --权益类公募保有量			 
			 , NVL(a1.BOND_PUB_PROD_HLD_AMT,0)         --债券类公募保有量
             , NVL(a1.CCY_PUB_PROD_HLD_AMT,0)          --货币类公募保有量
			 , NVL(a1.FND_SPELACT_PROD_HLD_AMT,0)      --基金专产品户保有量
             , NVL(a1.PRV_FND_PROD_HLD_AMT,0)          --私募基金保有量
             , NVL(a1.BANK_PROD_HLD_AMT,0)             --银行产品保有量
			 , NVL(a1.GTJA_PROD_HLD_AMT,0)             --国君产品保有量
			 , NVL(a1.SHZQ_PROD_HLD_AMT,0)             --公司产品保有量
			 , NVL(a1.CASH_PROD_HLD_AMT,0)             --现金添利产品保有量
			 , NVL(a1.OTC_PROD_HLD_AMT,0)             --OTC产品保有量
			 , CASE WHEN t.TRD_DT = a2.NAT_DT
			        THEN '是'
					ELSE '否'
					END     IF_TRD_DT                     --是否是交易日
             , CAST(a2.NAT_DT as INT) as BUS_DATE 			 
 FROM  (SELECT BELTO_FILIL_CDG
              ,BELTO_FILIL
			  ,BRH_NO
			  ,BRH_FULLNM
			  ,'2'  as IF_MAIN
			  ,%d{yyyyMMdd} as TRD_DT
        FROM  DDW_PROD.T_DDW_INR_ORG_BRH
		WHERE BUS_DATE = %d{yyyyMMdd}
		)                       t
 LEFT JOIN DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY_TEMP2 a1
 ON  t.BRH_NO = a1.BRH_NO
 LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE a2
 ON        t.TRD_DT = a2.TRD_DT
 AND       a2.BUS_DATE = %d{yyyyMMdd}
 ;
 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY_TEMP ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY_TEMP1 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY_TEMP2 ;
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_PROD_AGGR_IDX_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY;


 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:个股期权限仓客户表                                                                */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
TRUNCATE TABLE EDW_PROD.T_EDW_T02_TSO_CCXZ_KH;   
--------插入数据开始---------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TSO_CCXZ_KH
(
                                    KHH                                 --客户号                                
                                   ,JYS                                 --交易所                                
                                   ,ZQDM                                --标的证券                               
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,GGQQKH_KHQZ                         --个股期权客户客户群组                         
                                   ,ZQMC                                --标的证券名称                                                                                       
                                   ,ZCC                                 --总持仓限额                              
                                   ,QLC                                 --权利仓持仓限额                            
                                   ,DRMRKC                              --当日买入开仓限额                           
                                   ,BDRQ                                --变动日期            
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.ZQDM                                as ZQDM                                --标的证券                                
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as GGQQKH_KHQZ                         --客户群组                                
                                   ,t.ZQMC                                as ZQMC                                --标的证券名称                                                                    
                                   ,t.ZCC                                 as ZCC                                 --总持仓限额                               
                                   ,t.QLC                                 as QLC                                 --权利仓持仓限额                             
                                   ,t.DRMRKC                              as DRMRKC                              --当日买入开仓限额                            
                                   ,t.BDRQ                                as BDRQ                                --变动日期     
                                   ,'GGQQ'							      as XTBS	   
 FROM    GGQQCX.SOPTION_TSO_CCXZ_KH     t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'GGQQ'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE   t.DT = '%d{yyyyMMdd}';
---------插入数据结束-------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TSO_CCXZ_KH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TSO_CCXZ_KH;
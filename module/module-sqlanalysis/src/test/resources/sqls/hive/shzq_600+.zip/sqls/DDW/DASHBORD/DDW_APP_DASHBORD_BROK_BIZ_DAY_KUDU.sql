--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:经纪业务领导驾驶舱日表                                                        */
--/* 创建人:黄勇华                                                                              */
--/* 创建时间:2018-08-16                                                                        */ 
------------------- 删除数据
DELETE FROM RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_DAY_KUDU WHERE BUS_DATE = %d{yyyyMMdd};
---------------

-----插入客户数
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_DAY_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
	       , BUS_DATE
)
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'OPNAC_CUST_VOL'        as IDX_CODE        --指标代码
           , '开户数'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.OPNAC_CUST_VOL       as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as BUS_DATE          --加载日期	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.BUS_DATE = %d{yyyyMMdd} ;

-----插入交易量
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_DAY_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
	      , BUS_DATE
)
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'TRD_VOL'        as IDX_CODE        --指标代码
           , '交易量'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.TRD_VOL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as BUS_DATE          --加载日期	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.BUS_DATE = %d{yyyyMMdd} ;

-----插入资产净流入
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_DAY_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
	       , BUS_DATE
)
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'NET_TFR_IN_AST'        as IDX_CODE        --指标代码
           , '资产净流入'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.NET_TFR_IN_AST        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as BUS_DATE          --加载日期	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.BUS_DATE = %d{yyyyMMdd} ;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('RPT_DB','DDW_APP_DASHBORD_BROK_BIZ_DAY_KUDU',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
INVALIDATE METADATA RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_DAY_KUDU;
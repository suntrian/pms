 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:新开户信息表                                                                       */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 

   TRUNCATE TABLE DDW_PROD.T_DDW_PRT_NEW_OPNAC_INFO ; 
  --删除临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_NEW_OPNAC_INFO_TEMP;
--创建临时表
 CREATE TABLE DDW_PROD.T_DDW_PRT_NEW_OPNAC_INFO_TEMP
 as
 SELECT  SUM(ORDI_TRD_VOL_RMB+CRD_TRD_VOL+WRNT_TRD_VOL) AS MTCH_AMT
        ,SUM(ORDI_S1_INCM_RMB+CRD_S1_INCM) AS ACCNGROSS_CMSN
		,SUM(PROD_SCRP_AMT  +PROD_PRCH_AMT  +PROD_FIXINV_AMT+PROD_RDMPT_AMT) AS PROD_MTCH_AMT --代销金融产品确认金额
		,CUST_NO 
 FROM   DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
 WHERE (BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}) 
 GROUP BY CUST_NO
 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_NEW_OPNAC_INFO_TEMP1;
--创建临时表
 CREATE TABLE DDW_PROD.T_DDW_PRT_NEW_OPNAC_INFO_TEMP1
 as
 select T.KHH,ROUND((s1*1.00000/cjje),5) as rct_tm_s1_rate
 from (select khh,s1,cjje,bus_date,row_number() over(partition by khh order by bus_date desc) AS NUM
 from edw_prod.t_edw_t05_tjgmxls
 where wtlb in (1,2,61,62,63,64)
 AND JYS IN ('SH','SZ')
 AND SUBSTR(ZQLB,1,1) IN ('A','C')
AND S1>5
 ) T
 WHERE T.NUM = 1 ;
 
 
 

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_NEW_OPNAC_INFO
(
				   BRH_NO                             --营业部编号             
                  ,BRH_NAME                           --营业部名称             
                  ,OPNAC_MOD                          --开户方式               
                  ,OPNAC_DT                           --开户日期  
                  ,FSTTM_TRD_DT                       --首次交易日期				  
                  ,CUST_NO                            --客户号                 
                  ,CUST_NAME                          --客户姓名               
                  ,CTF_CGY_CD                         --证件类别代码           
                  ,CTF_NO                             --证件号码               
                  ,DEPMGT_BANK                        --存管银行               
                  ,CTRL_ATTR                          --控制属性               
                  ,M_LAUND_RSK_LVL                    --洗钱风险等             
                  ,FRIST_EVAL_DT                      --初次评测日期           
                  ,IMAGE_TP                           --影像资料               
                  ,RSK_BEAR_ABLTY                     --风险承受能力           
                  ,CTF_EXPR_DT                        --证件截至日期           
                  ,CTCT_ADDR                          --联系地址               
                  ,CTCT_TEL                           --联系电话 
                  ,OPNAC_AGE                          --开户年龄				  
                  ,PHONE                              --手机                   
                  ,EDU_CD                             --学历代码               
                  ,OCP_CD                             --职业代码               
                  ,CMSN_SETUP_DT                      --佣金设置日期           
                  ,CMSN_SETUP_ABST                    --佣金设置摘要           
                  ,MTCH_AMT                           --成交量                 
                  ,CMSN                               --佣金                   
                  ,SECOND_CARD_VRFCTN                 --二代证校验             
                  ,IF_OPN_PHONE_ODR                   --是否开通手机委托 
                  ,FCT_CTRL_PSN                       --实际控制人
                  ,FCT_YLD_PSN			              --实际收益人
				  ,T3IP_DEPMGT_TURNOUT			      --三方转出
				  ,PROD_MTCH_AMT                      --代销金融产品确认金额
                  ,ODR_MOD                            --委托方式
				  ,rct_tm_s1_rate
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
						 t.BRH_NO                    		AS  BRH_NO                             --营业部编号                
						,t.BRH_NAME                  		AS  BRH_NAME                           --营业部名称                
						,b1.OPNAC_MOD_NAME                 	AS  OPNAC_MOD                          --开户方式                 
						,t.ORDI_OPNAC_DT                    AS  OPNAC_DT                           --开户日期  
                        ,CASE WHEN a2.FSTTM_TRD_DT IS NOT NULL
                              THEN a2.FSTTM_TRD_DT
                              ELSE a2.THS_CO_FSTTM_TRD_DT
                              END                           AS  FSTTM_TRD_DT                       --首次交易日期							  
						,t.CUST_NO                   		AS  CUST_NO                            --客户号                  
						,t.CUST_NAME                 		AS  CUST_NAME                          --客户姓名                 
						,b2.CTF_CGY_CD_NAME                	AS  CTF_CGY_CD                         --证件类别代码               
						,t.CTF_NO                    		AS  CTF_NO                             --证件号码                 
						,t.DEPMGT_BANK               		AS  DEPMGT_BANK                        --存管银行                 
						,t.CTRL_ATTR                 		AS  CTRL_ATTR                          --控制属性                 
						,b6.M_LAUND_RSK_LVL_NAME            AS  M_LAUND_RSK_LVL                    --洗钱风险等                
						,t.FRIST_EVAL_DT                	AS  FRIST_EVAL_DT                      --初次评测日期               
						,t.IMAGE_TP                     	AS  IMAGE_TP                           --影像资料                 
						,b3.RSK_BEAR_ABLTY_NAME             AS  RSK_BEAR_ABLTY                     --风险承受能力               
						,CAST(t.CTF_EXPR_DT as DECIMAL(8,0))  AS  CTF_EXPR_DT                        --证件截至日期               
						,t.CTCT_ADDR                    	AS  CTCT_ADDR                          --联系地址                 
						,t.CTCT_TEL                     	AS  CTCT_TEL                           --联系电话 
                        ,CAST(CASE WHEN NVL(t.BRTH_YM,99999999) <>99999999 
							  THEN ROUND(EDW_PROD.G_DATE_COMPARE_DATE(CAST(t.ORDI_OPNAC_DT AS STRING),'yyyyMMdd',CAST(t.BRTH_YM AS STRING),'yyyyMMdd')/365,0)
							  ELSE NULL 
							  END AS DECIMAL(38,0))		    AS	OPNAC_AGE                          --开户年龄			
						,t.PHONE                        	AS  PHONE                              --手机                   
						,b4.EDU_CD_NAME                     AS  EDU_CD                             --学历代码                 
						,b5.OCP_CD_NAME                     AS  OCP_CD                             --职业代码                 
						,t.CMSN_SETUP_DT                	AS  CMSN_SETUP_DT                      --佣金设置日期               
						,t.CMSN_SETUP_ABST              	AS  CMSN_SETUP_ABST                    --佣金设置摘要               
						,NVL(a3.MTCH_AMT,0)                 AS  MTCH_AMT                           --成交量                  
						,NVL(a3.ACCNGROSS_CMSN,0)           AS  CMSN                               --佣金                   
						,t.SECOND_CARD_VRFCTN           	AS  SECOND_CARD_VRFCTN                 --二代证校验                
						,t.IF_OPN_PHONE_ODR             	AS  IF_OPN_PHONE_ODR                   --是否开通手机委托  
                        ,a4.SJKZR                           AS  FCT_CTRL_PSN                       --实际控制人
                        ,a4.SJSYR                           AS  FCT_YLD_PSN			              --实际收益人	
				        ,NVL(a9.T3IP_DEPMGT_TURNOUT,0)    as	T3IP_DEPMGT_TURNOUT			--三方转出	
				        ,NVL(a3.PROD_MTCH_AMT,0)         as PROD_MTCH_AMT                   --代销金融产品确认金额			
                        ,CONCAT(DECODE(FLOOR(t.ORDI_ODR_MOD_SCP/128),1,'银行',''),','
                               ,DECODE(FLOOR(MOD(t.ORDI_ODR_MOD_SCP,128)/64),1,'手机',''),','
	                           ,DECODE(FLOOR(MOD(MOD(t.ORDI_ODR_MOD_SCP,128),64)/32),1,'互联网',''),','
	                           ,DECODE(FLOOR(MOD(MOD(MOD(t.ORDI_ODR_MOD_SCP,128),64),32)/16),1,'远程',''),','
	                           ,DECODE(FLOOR(MOD(MOD(MOD(MOD(t.ORDI_ODR_MOD_SCP,128),64),32),16)/8),1,'柜台',''),','
	                           ,DECODE(FLOOR(MOD(MOD(MOD(MOD(MOD(t.ORDI_ODR_MOD_SCP,128),64),32),16),8)/4),1,'热键',''),','
	                           ,DECODE(FLOOR(MOD(MOD(MOD(MOD(MOD(MOD(t.ORDI_ODR_MOD_SCP,128),64),32),16),8),4)/2),1,'磁卡',''),','
	                           ,DECODE(FLOOR(MOD(MOD(MOD(MOD(MOD(MOD(MOD(t.ORDI_ODR_MOD_SCP,128),64),32),16),8),4),2)/1),1,'电话',''),',')  as ODR_MOD   --委托方式
							   ,a7.rct_tm_s1_rate
  FROM  	  		DDW_PROD.T_DDW_F00_CUST_CUST_INFO  	t 
  LEFT JOIN        (SELECT   CUST_NO,MIN(FSTTM_TRD_DT) AS FSTTM_TRD_DT ,BUS_DATE,MIN(THS_CO_FSTTM_TRD_DT)  AS THS_CO_FSTTM_TRD_DT 
                    FROM     DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO
					GROUP BY CUST_NO,BUS_DATE
					)                               a2
  ON                t.CUST_NO = a2.CUST_NO
  AND               t.BUS_DATE = a2.BUS_DATE 
  LEFT JOIN			DDW_PROD.T_DDW_PRT_NEW_OPNAC_INFO_TEMP				  a3
  ON				t.CUST_NO = a3.CUST_NO
  LEFT JOIN     	DDW_PROD.V_OPNAC_MOD			                      b1
  ON            	t.OPNAC_MOD = b1.OPNAC_MOD 
  LEFT JOIN     	DDW_PROD.V_CTF_CGY_CD			                      b2
  ON            	t.CTF_CGY_CD = b2.CTF_CGY_CD   
  LEFT JOIN     	DDW_PROD.V_RSK_BEAR_ABLTY                          	  b3
  ON            	t.RSK_BEAR_ABLTY = b3.RSK_BEAR_ABLTY
  LEFT JOIN     	DDW_PROD.V_EDU_CD			                          b4
  ON            	t.EDU_CD = b4.EDU_CD 
  LEFT JOIN     	DDW_PROD.V_OCP_CD			                          b5
  ON            	t.OCP_CD = b5.OCP_CD   
  LEFT JOIN    DDW_PROD.V_M_LAUND_RSK_LVL            b6
  ON           t.M_LAUND_RSK_LVL = b6.M_LAUND_RSK_LVL  
  LEFT JOIN        DDW_PROD.T_DDW_INR_ORG_BRH                           a5
  ON               t.BRH_NO = a5.BRH_NO
  AND              a5.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN (SELECT CUST_NO,SUM(CRD_WTHDR_AMT+ORDI_WTHDR_AMT_RMB+WRNT_WTHDR_AMT) AS T3IP_DEPMGT_TURNOUT 
              FROM    DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
			  WHERE   BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND  %d{yyyyMMdd} 			  
			  GROUP BY CUST_NO
             )	a9
   ON			 t.CUST_NO = a9.CUST_NO  
  LEFT JOIN  EDW_PROD.T_EDW_T99_TKHYWSX                        a4
  ON         t.CUST_NO = a4.KHH
  and        a4.bus_date = %d{yyyyMMdd}
  LEFT JOIN DDW_PROD.T_DDW_PRT_NEW_OPNAC_INFO_TEMP1 A7
  on       t.cust_no = a7.khh
  WHERE			  	t.bus_date = %d{yyyyMMdd}
  AND               CAST(t.ORDI_OPNAC_DT AS STRING) > =  CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-3,0,0),1,4),'0101') 
  AND               a5.BRH_NO IS NOT NULL
  AND         		t.CUST_CGY = '0' 
; 
--删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_NEW_OPNAC_INFO_TEMP;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_NEW_OPNAC_INFO_TEMP1;

-----------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_NEW_OPNAC_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_NEW_OPNAC_INFO ;
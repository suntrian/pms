 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:产品持仓历史表                                                         */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */ 
  

  ----删除当天的数据---
    ALTER TABLE DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ; 
   --------
 ---创建临时表1
 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_TEMP;
 CREATE TABLE DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_TEMP as
 SELECT ApplyingCodeFront as ZQDM1,SecurityCode as ZQDM,a.DT
 FROM   FUNDEXT.DBO_MF_FundArchives  a
 WHERE a.DT = '%d{yyyyMMdd}'
 AND    length(trim(NVL(a.ApplyingCodeFront,'')))>0
 AND   length(trim(NVL(a.SecurityCode,'')))>0 
 AND   a.ApplyingCodeFront <> a.SecurityCode
 AND   substr(a.securitycode,7,1) <> 'J'
 UNION 
 SELECT ApplyingCodeBack as ZQDM1,SecurityCode as ZQDM,a.DT
 FROM   FUNDEXT.DBO_MF_FundArchives  a
 WHERE a.DT = '%d{yyyyMMdd}'
 AND    length(trim(NVL(a.ApplyingCodeBack,'')))>0
 AND   length(trim(NVL(a.SecurityCode,'')))>0 
 AND   a.ApplyingCodeBack <> a.SecurityCode
 AND   substr(a.securitycode,7,1) <> 'J'
 ;
 ----上市之前的补充市值
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_TEMP1;
 CREATE TABLE DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_TEMP1 as
  SELECT   a.KHH
          ,a.KHXM 
		  ,a.YYB
		  ,a.JJZH
		  ,DECODE(NVL(b.ZQDM,a.JJDM),'519028','519029','180042','180002',NVL(b.ZQDM,a.JJDM)) as JJDM
		  ,a.JJJC
		  ,a.JSBZDM
		  ,a.BUS_DATE
		  ,a.QRFE
		  ,NVL(a.QRJE,0)+NVL(a.LX,0)-NVL(a.SXF,0) as QRJE
		  ,a.TADM
		  ,%d{yyyyMMdd} as RQ
 FROM         EDW_PROD.T_EDW_T05_TOF_JJJGLS_XZB      a 
 LEFT JOIN  ( SELECT   ZQDM1,MIN(ZQDM) as ZQDM 
			  FROM     DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_TEMP
			  GROUP BY ZQDM1
			) b  
 ON         a.JJDM = b.ZQDM1
 LEFT  JOIN  (  SELECT     NVL(a.JYS,b.JYS) as JYS
                              ,NVL(a.ZQDM,b.ZQDM) as ZQDM
							  ,LEAST(NVL(a.SSRQ,99999999),NVL(b.SSRQ,99999999)) as SSRQ
							  ,GREATEST(NVL(a.TSRQ,00000000),NVL(b.TSRQ,00000000)) as TSRQ
                    FROM      (SELECT JYS,ZQDM,SSRQ,TSRQ 
					           FROM EDW_PROD.T_EDW_T04_TSZQDM
							   WHERE BUS_DATE = %d{yyyyMMdd}
							   AND   CPLB = 8
							   AND   ZQDM NOT LIKE '%J'
							   ) a
			        FULL JOIN  (SELECT JYS,SUBSTR(ZQDM,1,6) as ZQDM,MIN(SSRQ) as SSRQ,MAX(TSRQ) as TSRQ,BUS_DATE FROM EDW_PROD.T_EDW_T04_TSZQDM
			                     WHERE CPLB = 8
				                 AND   ZQDM LIKE '%J'
								 AND BUS_DATE = %d{yyyyMMdd}
								 GROUP BY JYS,ZQDM,BUS_DATE
				                ) b
				    ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
				    AND          a.JYS = b.JYS
			 )           c
 ON    DECODE(NVL(b.ZQDM,a.JJDM),'519028','519029','180042','180002',NVL(b.ZQDM,a.JJDM)) = c.ZQDM
 WHERE  a.YWDM IN ('130','8888')
 AND    c.ZQDM IS NOT NULL
 AND    %d{yyyyMMdd} < c.SSRQ
 AND    %d{yyyyMMdd} > = a.BUS_DATE 
 AND   a.yzywfqf < > '-1' 
 UNION ALL
  SELECT   a.KHH
          ,a.KHXM 
		  ,a.YYB
		  ,a.JJZH
		  ,DECODE(NVL(b.ZQDM,a.JJDM),'519028','519029','180042','180002',NVL(b.ZQDM,a.JJDM)) as JJDM
		  ,a.JJJC
		  ,a.JSBZDM
		  ,a.BUS_DATE
		  ,a.QRFE
		  ,NVL(a.QRJE,0)+NVL(a.LX,0)-NVL(a.SXF,0) as QRJE
		  ,a.TADM
		  ,%d{yyyyMMdd} as RQ
 FROM         EDW_PROD.T_EDW_T05_TOF_JJJGLS_XZB      a 
 LEFT JOIN  ( SELECT   ZQDM1,MIN(ZQDM) as ZQDM 
			  FROM     DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_TEMP
			  GROUP BY ZQDM1
			) b  
 ON         a.JJDM = b.ZQDM1
 LEFT  JOIN  ( SELECT     NVL(a.JYS,b.JYS) as JYS
                              ,NVL(a.ZQDM,b.ZQDM) as ZQDM
							  ,LEAST(NVL(a.SSRQ,99999999),NVL(b.SSRQ,99999999)) as SSRQ
							  ,GREATEST(NVL(a.TSRQ,00000000),NVL(b.TSRQ,00000000)) as TSRQ
                    FROM      (SELECT JYS,ZQDM,SSRQ,TSRQ 
					           FROM EDW_PROD.T_EDW_T04_TSZQDM
							   WHERE BUS_DATE = %d{yyyyMMdd}
							   AND   CPLB = 8
							   AND   ZQDM NOT LIKE '%J'
							   ) a
			        FULL JOIN  (SELECT JYS,SUBSTR(ZQDM,1,6) as ZQDM,MIN(SSRQ) as SSRQ,MAX(TSRQ) as TSRQ,BUS_DATE FROM EDW_PROD.T_EDW_T04_TSZQDM
			                     WHERE CPLB = 8
				                 AND   ZQDM LIKE '%J'
								 AND BUS_DATE = %d{yyyyMMdd}
								 GROUP BY JYS,ZQDM,BUS_DATE
				                ) b
				    ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
				    AND          a.JYS = b.JYS
			 )           c
 ON    DECODE(NVL(b.ZQDM,a.JJDM),'519028','519029','180042','180002',NVL(b.ZQDM,a.JJDM)) = c.ZQDM
 LEFT JOIN (SELECT  KHH
                    ,JJDM
					,MIN(BUS_DATE) as SSRQ
			FROM  EDW_PROD.T_EDW_T02_TOF_JJFE
            WHERE JJSL > 0
            GROUP BY KHH,JJDM
           )                  d
 ON      a.KHH = d.KHH
 AND     a.JJDM = d.JJDM 
 WHERE  a.YWDM IN ('130','8888')
 AND    c.ZQDM IS  NULL
 AND    %d{yyyyMMdd} < d.SSRQ
 AND    %d{yyyyMMdd} > = a.BUS_DATE
 AND    a.yzywfqf < > '-1' 
 ;

--------------插入数据-------------
INSERT INTO DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS
(
                                   CUST_NO                      --客户号        
                                  ,CUST_NAME                    --客户姓名      
                                  ,BRH_NO                       --营业部编号       
                                  ,PROD_ACTNO                   --产品账号
                                  ,PROD_CD                      --产品代码              
                                  ,PROD_NAME                    --产品简称
                                  ,CCY_CD                       --币种代码                   
                                  ,PROD_CL                      --产品分类
                                  ,ADMIN_CD                     --管理人代码
								  ,PROD_SHR_QTY                 --份额数量
								  ,PROD_NEWST_MKTVAL            --产品最新市值
                                  ,PROD_CGY                     --产品来源			                                  																
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                          as CUST_NO                      --客户号                      
                                   ,t.KHXM                         as CUST_NAME                    --客户姓名      
                                   ,t.YYB                          as BRH_NO                       --营业部编号    
                                   ,t.CPZH                         as PROD_ACTNO                   --产品账号
                                   ,t.CPDM                         as PROD_CD                      --产品代码      
                                   ,t.CPJC                         as PROD_NAME                    --产品简称                                
                                   ,t.BZDM                         as CCY_CD                       --币种代码      
                                   ,NULL                           as PROD_CL                      --产品分类                                
                                   ,NULL                           as ADMIN_CD                     --管理人代码
                                   ,SUM(NVL(t.SL,0))               as PROD_SHR_QTY                 --份额数量                                                           
                                   ,SUM(1*NVL(t.SL,0))             as PROD_NEWST_MKTVAL            --产品最新市值                     						   
                                   ,9                              as PROD_CGY                     --产品来源																												                             
  FROM          EDW_PROD.T_EDW_T02_TJRCP_YH_CPFE                                                t
  WHERE         t.BUS_DATE =  %d{yyyyMMdd} 
  AND           t.SL > 0 
  GROUP BY      t.KHH,t.KHXM,t.YYB,t.CPZH,t.CPDM,t.CPJC,t.BZDM ;
  ----------------
  INSERT INTO DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS
(
                                   CUST_NO                      --客户号        
                                  ,CUST_NAME                    --客户姓名      
                                  ,BRH_NO                       --营业部编号        
                                  ,PROD_ACTNO                   --产品账号
                                  ,PROD_CD                      --产品代码              
                                  ,PROD_NAME                    --产品简称
                                  ,CCY_CD                       --币种代码                   
                                  ,PROD_CL                      --产品分类
                                  ,ADMIN_CD                     --管理人代码
								  ,PROD_SHR_QTY                 --份额数量
								  ,PROD_NEWST_MKTVAL            --产品最新市值
                                  ,PROD_CGY                     --产品来源			                                  																
) 
 partition(bus_date = %d{yyyyMMdd})
   SELECT 
                                    t.KHH                          as CUST_NO                      --客户号                      
                                   ,t.KHXM                         as CUST_NAME                    --客户姓名      
                                   ,t.YYB                          as BRH_NO                       --营业部编号                                        
                                   ,t.JJZH                         as PROD_ACTNO                   --产品账号
                                   ,t.JJDM                         as PROD_CD                      --产品代码      
                                   ,t.JJJC                         as PROD_NAME                    --产品简称                                
                                   ,t.BZDM                         as CCY_CD                       --币种代码      
                                   ,a2.OF_JJFL                     as PROD_CL                      --产品分类                                
                                   ,a2.GLRDM                       as ADMIN_CD                     --管理人代码
                                   ,NVL(t.JJSL,0)             as PROD_SHR_QTY                 --份额数量                                                           
                                   ,ROUND(NVL(t.JJSL,0)*NVL(a3.NEWST_PRC,1),2)  as PROD_NEWST_MKTVAL            --产品最新市值    
                                   ,8                              as PROD_CGY                     --产品来源																												                             
  FROM     (    SELECT       a.KHH
                             ,a.KHXM
							 ,a.YYB
							 ,a.JJZH
							 ,CASE WHEN a.JJDM = '519028'
							       THEN '519029'
								   WHEN a.JJDM = '180042'
								   THEN '180002'
								   WHEN  b.ZQDM1 IS NOT NULL
                                   THEN  b.ZQDM	
                                   ELSE a.JJDM
                                   END  as JJDM								   
							 ,a.JJJC
							 ,a.BZDM
							 ,a.JJSL
                             ,a.BUS_DATE
							 ,a.TADM
                 FROM         EDW_PROD.T_EDW_T02_TOF_JJFE a
                 LEFT JOIN  ( SELECT   ZQDM1,MIN(ZQDM) as ZQDM 
				              FROM     DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_TEMP
							  GROUP BY ZQDM1
							  ) b  
				ON         a.JJDM = b.ZQDM1
		 )                              t
  LEFT JOIN     EDW_PROD.T_EDW_T04_TOF_JJXX                                       a2
  ON            t.JJDM = a2.JJDM
  AND           t.TADM = a2.TADM
  AND           a2.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_PUB_QOT                                      a3
  ON            t.JJDM = a3.CD
  AND           t.TADM = a3.EXG 
  AND           t.BUS_DATE = a3.BUS_DATE
  AND           a3.TRD_MKT = 2 
  LEFT  JOIN   (   SELECT     NVL(a.JYS,b.JYS) as JYS
                              ,NVL(a.ZQDM,b.ZQDM) as ZQDM
							  ,LEAST(NVL(a.SSRQ,99999999),NVL(b.SSRQ,99999999)) as SSRQ
							  ,GREATEST(NVL(a.TSRQ,00000000),NVL(b.TSRQ,00000000)) as TSRQ
                    FROM      (SELECT JYS,ZQDM,SSRQ,TSRQ 
					           FROM EDW_PROD.T_EDW_T04_TSZQDM
							   WHERE BUS_DATE = %d{yyyyMMdd}
							   AND   CPLB = 8
							   AND   ZQDM NOT LIKE '%J'
							   ) a
			        FULL JOIN  (SELECT JYS,SUBSTR(ZQDM,1,6) as ZQDM,MIN(SSRQ) as SSRQ,MAX(TSRQ) as TSRQ,BUS_DATE FROM EDW_PROD.T_EDW_T04_TSZQDM
			                     WHERE CPLB = 8
				                 AND   ZQDM LIKE '%J'
								 AND BUS_DATE = %d{yyyyMMdd}
								 GROUP BY JYS,ZQDM,BUS_DATE
				                ) b
				    ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
				    AND          a.JYS = b.JYS
                )               				a4
 ON            t.JJDM = a4.ZQDM  
  WHERE         t.BUS_DATE =  %d{yyyyMMdd}
  AND           t.JJSL > 0
  AND          ( %d{yyyyMMdd} BETWEEN  a4.SSRQ AND a4.TSRQ
  OR            a4.ZQDM IS NULL )             
  ; 
 INSERT INTO DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS
 (
                                   CUST_NO                      --客户号        
                                  ,CUST_NAME                    --客户姓名      
                                  ,BRH_NO                       --营业部编号     
                                  ,PROD_ACTNO                   --产品账号
                                  ,PROD_CD                      --产品代码              
                                  ,PROD_NAME                    --产品简称
                                  ,CCY_CD                       --币种代码                   
                                  ,PROD_CL                      --产品分类
                                  ,ADMIN_CD                     --管理人代码
								  ,PROD_SHR_QTY                 --份额数量
								  ,PROD_NEWST_MKTVAL            --产品最新市值
                                  ,PROD_CGY                     --产品来源			                                  																
 ) 
 partition(bus_date = %d{yyyyMMdd})
   SELECT 
                                    t.KHH                          as CUST_NO                      --客户号                      
                                   ,t.KHXM                         as CUST_NAME                    --客户姓名      
                                   ,t.YYB                          as BRH_NO                       --营业部编号    
                                   ,t.JJZH                         as PROD_ACTNO                   --产品账号
                                   ,t.JJDM                         as PROD_CD                      --产品代码      
                                   ,t.JJJC                         as PROD_NAME                    --产品简称                                
                                   ,t.JSBZDM                       as CCY_CD                       --币种代码      
                                   ,a2.OF_JJFL                     as PROD_CL                      --产品分类                                
                                   ,a2.GLRDM                       as ADMIN_CD                     --管理人代码
                                   ,NVL(t.QRFE,0)             as PROD_SHR_QTY                 --份额数量                                                           
                                   ,ROUND(NVL(t.QRJE,0),2)  as PROD_NEWST_MKTVAL            --产品最新市值    
                                   ,8                            as PROD_CGY                     --产品来源			
 FROM DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_TEMP1  t
 LEFT JOIN     EDW_PROD.T_EDW_T04_TOF_JJXX                                       a2
 ON            t.JJDM = a2.JJDM
 AND           t.TADM = a2.TADM
 AND           a2.BUS_DATE = %d{yyyyMMdd} 
 WHERE         t.RQ =  %d{yyyyMMdd}   
;	

INSERT INTO DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS
(
                                   CUST_NO                      --客户号        
                                  ,CUST_NAME                    --客户姓名      
                                  ,BRH_NO                       --营业部编号       
                                  ,PROD_ACTNO                   --产品账号
                                  ,PROD_CD                      --产品代码              
                                  ,PROD_NAME                    --产品简称
                                  ,CCY_CD                       --币种代码                   
                                  ,PROD_CL                      --产品分类
                                  ,ADMIN_CD                     --管理人代码
								  ,PROD_SHR_QTY                 --份额数量
								  ,PROD_NEWST_MKTVAL            --产品最新市值
                                  ,PROD_CGY                     --产品来源			                                  																
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                          as CUST_NO                      --客户号                      
                                   ,t.KHXM                         as CUST_NAME                    --客户姓名      
                                   ,t.YYB                          as BRH_NO                       --营业部编号    
                                   ,t.TZZH                         as PROD_ACTNO                   --产品账号
                                   ,t.CPDM                         as PROD_CD                      --产品代码      
                                   ,a2.CPQC                        as PROD_NAME                    --产品简称                                
                                   ,'RMB'                          as CCY_CD                       --币种代码      
                                   ,CAST(t.CPFL as STRING)         as PROD_CL                      --产品分类                                
                                   ,NULL                           as ADMIN_CD                     --管理人代码
                                   ,SUM(NVL(t.CPFE,0))             as PROD_SHR_QTY                 --份额数量                                                           
                                   ,SUM(CAST((NVL(t.CPFE,0)*a1.NEWST_PRC) as DECIMAL(38,2))) as PROD_NEWST_MKTVAL            --产品最新市值                     						   
                                   ,11                              as PROD_CGY                     --产品来源																												                             
  FROM          EDW_PROD.T_EDW_T02_TFP_CPFE_LS                                                t
  LEFT JOIN     DDW_PROD.T_DDW_PUB_QOT                                      a1
  ON            t.CPDM = a1.CD
  AND           t.JGDM = a1.EXG 
  AND           t.BUS_DATE = a1.BUS_DATE
  AND           a1.TRD_MKT = 4 
  LEFT JOIN     EDW_PROD.T_EDW_T04_TFP_CPDM    a2
  ON            t.CPDM = a2.CPDM
--  AND           t.JGDM = a2.FXJG
  AND           a2.BUS_DATE = %d{yyyyMMdd}
  WHERE         t.BUS_DATE =  %d{yyyyMMdd} 
  GROUP BY     CUST_NO     
               ,CUST_NAME   
               ,BRH_NO      
               ,PROD_ACTNO  
               ,PROD_CD     
               ,PROD_NAME   
               ,CCY_CD      
               ,PROD_CL     
               ,ADMIN_CD 
               ,PROD_CGY			   
  ;
  
  
  
---------------- 插入数据结束 -----------------------
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_TEMP1;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_TEMP;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_AST_PROD_HLD_DTL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS ;

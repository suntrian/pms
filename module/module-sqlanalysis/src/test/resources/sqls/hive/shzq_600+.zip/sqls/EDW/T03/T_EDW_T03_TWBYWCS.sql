--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:外部业务参数表                                                                       */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  

------插入数据
TRUNCATE TABLE EDW_PROD.T_EDW_T03_TWBYWCS;
---------------- 插入集中交易数据 -----------------------
INSERT INTO EDW_PROD.T_EDW_T03_TWBYWCS
(
                                    JKLB                                --监控类别                               
                                   ,WBJGDM                              --外部机构代码                             
                                   ,JKYWDM                              --接口业务代码                             
                                   ,XTYWDM                              --系统业务代码                             
                                   ,YZYWFQF                             --银证业务发起方                            
                                   ,YWKM                                --业务科目                               
                                   ,YWMC                                --业务名称                               
                                   ,YZYWSFXYLX                          --银证业务身份校验类型                         
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.JKLB                                as JKLB                                --接口类别                                
                                   ,t.JGDM                                as WBJGDM                              --机构代码                                
                                   ,t.JKYWDM                              as JKYWDM                              --接口业务代码                              
                                   ,t.XTYWDM                              as XTYWDM                              --系统业务代码                              
                                   ,t.FQF                                 as YZYWFQF                             --发起方                                 
                                   ,t.YWKM                                as YWKM                                --业务科目                                
                                   ,t.YWMC                                as YWMC                                --业务名称                                
                                   ,t.SFJYLX                              as YZYWSFXYLX                          --身份校验类型                              
                                   ,'JZJY'                                as XTBS                                --系统标识                                     
FROM JZJYCX.ACCOUNT_TWBYWCS t
WHERE t.DT = '%d{yyyyMMdd}';

------插入集中交易数据结束------------------

-------------------------------插入融资融券数据-------------------------------
 INSERT INTO EDW_PROD.T_EDW_T03_TWBYWCS
 (
                                     JKLB                                --监控类别                               
                                    ,WBJGDM                              --外部机构代码                             
                                    ,JKYWDM                              --接口业务代码                             
                                    ,XTYWDM                              --系统业务代码                             
                                    ,YZYWFQF                             --银证业务发起方                            
                                    ,YWKM                                --业务科目                               
                                    ,YWMC                                --业务名称                               
                                    ,YZYWSFXYLX                          --银证业务身份校验类型                         
                                    ,XTBS                                --系统标识                               
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.JKLB                                as JKLB                                --接口类别                                
                                    ,t.JGDM                                as WBJGDM                              --机构代码                                
                                    ,t.JKYWDM                              as JKYWDM                              --接口业务代码                              
                                    ,t.XTYWDM                              as XTYWDM                              --系统业务代码                              
                                    ,t.FQF                                 as YZYWFQF                             --发起方                                 
                                    ,t.YWKM                                as YWKM                                --业务科目                                
                                    ,t.YWMC                                as YWMC                                --业务名称                                
                                    ,t.SFJYLX                              as YZYWSFXYLX                          --身份校验类型                              
                                    ,'RZRQ'                                as XTBS                                --系统标识                                     
 FROM RZRQCX.ACCOUNT_TWBYWCS t
 WHERE t.DT = '%d{yyyyMMdd}';

-------------------------------插入融资融券数据结束-------------------------------

-------------------------------	插入个股期权数据---------------------------------
 INSERT INTO EDW_PROD.T_EDW_T03_TWBYWCS
 (
                                     JKLB                                --监控类别                               
                                    ,WBJGDM                              --外部机构代码                             
                                    ,JKYWDM                              --接口业务代码                             
                                    ,XTYWDM                              --系统业务代码                             
                                    ,YZYWFQF                             --银证业务发起方                            
                                    ,YWKM                                --业务科目                               
                                    ,YWMC                                --业务名称                               
                                    ,YZYWSFXYLX                          --银证业务身份校验类型                         
                                    ,XTBS                                --系统标识                               
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.JKLB                                as JKLB                                --接口类别                                
                                    ,t.JGDM                                as WBJGDM                              --机构代码                                
                                    ,t.JKYWDM                              as JKYWDM                              --接口业务代码                              
                                    ,t.XTYWDM                              as XTYWDM                              --系统业务代码                              
                                    ,t.FQF                                 as YZYWFQF                             --发起方                                 
                                    ,t.YWKM                                as YWKM                                --业务科目                                
                                    ,t.YWMC                                as YWMC                                --业务名称                                
                                    ,t.SFJYLX                              as YZYWSFXYLX                          --身份校验类型                              
                                    ,'GGQQ'                                as XTBS                                --系统标识                                    
 FROM GGQQCX.ACCOUNT_TWBYWCS t
 WHERE t.DT = '%d{yyyyMMdd}';
----------------结束插入 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T03_TWBYWCS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T03_TWBYWCS; 
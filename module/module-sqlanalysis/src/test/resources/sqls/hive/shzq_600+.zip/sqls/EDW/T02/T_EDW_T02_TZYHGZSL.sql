 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:质押回购折算率                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZYHGZSL;
--------插入数据开始--------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZYHGZSL
(
                                    JYS                                 --交易所                                
                                   ,ZQFL                                --证券分类                               
                                   ,TS                                  --天数                                 
                                   ,ZQLBMC                              --证券类别名称                             
                                   ,ZSL                                 --折算率                                
                                   ,FDLL                                --浮动利率                               
                                   ,RQ                                  --日期                                 
                                   ,TYPE                                --类型                                 
                                   ,ZJYT                                --资金用途                               
                                   ,YJLYJ                               --预警履约金                              
                                   ,ZDLYJ                               --最低履约金                              
                                   ,TDLX                                --通道类型 
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.ZQFL                                as ZQFL                                --证券分类                                
                                   ,t.TS                                  as TS                                  --天数                                  
                                   ,t.ZQLBMC                              as ZQLBMC                              --证券类别名称                              
                                   ,t.ZSL                                 as ZSL                                 --折算率                                 
                                   ,t.FDLL                                as FDLL                                --浮动利率                                
                                   ,t.RQ                                  as RQ                                  --日期                                  
                                   ,t.TYPE                                as TYPE                                --类型                                  
                                   ,t.ZJYT                                as ZJYT                                --资金用途                                
                                   ,t.YJLYJ                               as YJLYJ                               --预警履约金                               
                                   ,t.ZDLYJ                               as ZDLYJ                               --最低履约金                               
                                   ,t.TDLX                                as TDLX                                --通道类型          
                                   ,'JZJY'								   
 FROM 		JZJYCX.SECURITIES_TZYHGZSL     t
 WHERE      t.DT = '%d{yyyyMMdd}';
---------插入数据结束----
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZYHGZSL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TZYHGZSL;
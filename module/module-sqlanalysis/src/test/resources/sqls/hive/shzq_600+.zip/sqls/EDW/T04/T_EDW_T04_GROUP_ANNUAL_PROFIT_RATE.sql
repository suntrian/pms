------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:组合年化收益率表                                                                    */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

 
 --清除数据
-- TRUNCATE TABLE EDW_PROD.T_EDW_T04_GROUP_ANNUAL_PROFIT_RATE;
 
 ------插入数据
  INSERT OVERWRITE EDW_PROD.T_EDW_T04_GROUP_ANNUAL_PROFIT_RATE
(
              GROUP_ID              --组合id
			 ,ANNUAL_PROFIT_RATE    --年化收益率
			 ,UPDATE_TIME       
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     
              GROUP_ID              --组合id
			 ,ANNUAL_PROFIT_RATE    --年化收益率
			 ,UPDATE_TIME
FROM       JJLC.GROUP_ANNUAL_PROFIT_RATE
WHERE DT = '%d{yyyyMMdd}'
;
 
 ----删除临时表
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_GROUP_ANNUAL_PROFIT_RATE',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
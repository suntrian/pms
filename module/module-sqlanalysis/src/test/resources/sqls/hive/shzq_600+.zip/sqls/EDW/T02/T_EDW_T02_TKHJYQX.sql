 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户交易权限表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 

-- TRUNCATE TABLE EDW_PROD.T_EDW_T02_TKHJYQX; 

------剔除不合格的股东号
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd};
 CREATE TABLE EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd} as 
 SELECT 
                                    t.JYQX                                as JYQX                                --交易权限                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.YWXT                                as YWXT                                --业务系统                                
                                   ,t.YWZH                                as YWZH                                --业务账号                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )          as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,CASE WHEN t.JYS = 1 AND SUBSTR(t.GDH,1,1) = 'F'
		                                  THEN '1'
			                              WHEN t.JYS = 2 AND SUBSTR(t.GDH,1,3) = '001'
			                              THEN '1'
                                          WHEN t.JYS = 2 AND SUBSTR(t.GDH,1,2) = '05'  
		                                  THEN '1'
			                              WHEN t.JYS = 1 AND SUBSTR(t.GDH,1,1) = 'E'
			                              THEN '2'
			                              WHEN t.JYS = 2 AND SUBSTR(t.GDH,1,2) = '06'  
		                                  THEN '2'
			                              WHEN t.JYS = 1 AND SUBSTR(t.GDH,1,1) IN ('A','B','D')
		                                  THEN '3'
			                              WHEN t.JYS = 2 AND SUBSTR(t.GDH,1,1) IN ('0','4')
		                                  THEN '3'
			                              WHEN t.JYS = 3 AND SUBSTR(t.GDH,1,2) IN ('C1')
			                              THEN '4'
		                                  WHEN t.JYS = 3 AND SUBSTR(t.GDH,1,2) IN ('C9')
			                              THEN '5'
			                              WHEN t.JYS = 4 AND SUBSTR(t.GDH,1,1) IN ('2')
			                              THEN '6'
			                              WHEN t.JYS = 5 AND SUBSTR(t.GDH,1,1) IN ('0','4')
			                              THEN '7'
			                              WHEN t.JYS = 6 AND SUBSTR(t.GDH,1,1) IN ('0','2','4')
			                              THEN '8'
			                              WHEN t.JYS = 7 AND SUBSTR(t.GDH,1,1) IN ('A','B','D')
			                              THEN '9'
			                              WHEN t.JYS = 8 AND SUBSTR(t.GDH,1,1) IN ('0','4')
			                              THEN '10'
    		                              END AS GDZHLB
								   ,t.SX1                                 as SX1                                 --属性1                                 
                                   ,t.SX2                                 as SX2                                 --属性2                                 
                                   ,CASE WHEN t.YYB = 8003
								         THEN '8003'
										 ELSE CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                 
										 END                        as YYB                                 --营业部                                 
                                   ,t.ZT                                  as ZT                                  --状态                                  
                                   ,NVL(t.KTRQ,t3.KTRQ)							      as KTRQ                                --开通日期                                
                                   ,t.GBRQ                                as GBRQ                                --关闭日期                                
                                   ,t.YWQQID                              as YWQQID                              --业务请求ID 
                                   ,'YGT_GT'	                          as XTBS							   
 FROM           YGTCX.CIF_TKHJYQX t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'JYS'
 AND            t1.YXT = 'YGT_GT'
 AND            t1.YDM = CAST(t.JYS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING     t2
 ON             t2.YXT = 'CIF'
 AND            t2.JGDM = CAST(t.YYB AS VARCHAR(20)) 
 LEFT JOIN      DDW_PROD.T_DDW_CFG_TRD_PRVL_CRCT   t3
 ON             t.KHH = t3.KHH
 AND            t.JYS = CAST(t3.JYS as INT)
 AND            t.GDH = t3.GDH
 AND            t.JYQX = t3.JYQX
  WHERE          t.DT = '%d{yyyyMMdd}'
 AND     ((t.JYS = 1 AND SUBSTR(t.GDH,1,1) IN ('A','B','D','E','F'))
            OR (t.JYS = 2 AND SUBSTR(t.GDH,1,1) IN ('0','4'))
            OR (t.JYS = 3 AND SUBSTR(t.GDH,1,2) IN ('C1','C9'))
	        OR (t.JYS = 4 AND SUBSTR(t.GDH,1,1) IN ('2'))
	        OR ((t.JYS = 5 AND SUBSTR(t.GDH,1,1) IN ('0','4')) AND SUBSTR(t.GDH,1,2) NOT IN ('05','06') AND  SUBSTR(t.GDH,1,3) NOT IN ('001'))
	        OR ((t.JYS = 6 AND SUBSTR(t.GDH,1,1) IN ('0','4','2')) AND SUBSTR(t.GDH,1,2) NOT IN ('05','06') AND  SUBSTR(t.GDH,1,3) NOT IN ('001'))
	        OR (t.JYS = 7 AND SUBSTR(t.GDH,1,1) IN ('A','B','D'))
	        OR ((t.JYS = 8 AND SUBSTR(t.GDH,1,1) IN ('0','4')) AND SUBSTR(t.GDH,1,2) NOT IN ('05','06') AND  SUBSTR(t.GDH,1,3) NOT IN ('001'))
	     ) 
		 
-- AND NOT EXISTS (SELECT 1 FROM (SELECT khh
--                                      ,jys
--	                                  ,gdh
--	                                  ,SUM(case when LENGTH(NVL(TRIM(GDZDSX),'')) = 0
--                                                THEN 0
--                                                when GDZDSX = '0'
--                                                THEN 0	
--                                                ELSE 1
--                                                END 
--                                         ) as 	GDZDSX			 
--                            FROM YGTCX.CIF_TGDZH 
--                            WHERE  DT = '%d{yyyyMMdd}'
--                            AND    JYS IN (1,3,7)
--                            GROUP BY KHH,JYS,GDH
--							) a
--				 where   t.KHH = a.KHH
--				 AND   t.GDH = a.GDH
--				 and   t.jys = a.jys
--				 and   a.GDZDSX = 0
--               )
 AND  t.GDH IS NOT NULL
 AND  LENGTH(TRIM(t.GDH)) = 10
 ;
	

 INSERT OVERWRITE EDW_PROD.T_EDW_T02_TKHJYQX
 (
                                    JYQX                                --交易权限                               
                                   ,KHH                                 --客户号                                
                                   ,YWXT                                --业务系统                               
                                   ,YWZH                                --业务账号                               
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号 
                                   ,GDZHLB                                --股东类别								   
                                   ,SX1                                 --属性1                                
                                   ,SX2                                 --属性2                                
                                   ,YYB                                 --营业部                                
                                   ,ZT                                  --状态                                 
                                   ,KTRQ                                --开通日期                               
                                   ,GBRQ                                --关闭日期                               
                                   ,YWQQID                              --业务请求主键 ,
                                   ,IF_TJ							   
                                   ,XTBS
                                  								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})	
 SELECT                             t.JYQX                                --交易权限                               
                                   ,t.KHH                                 --客户号                                
                                   ,t.YWXT                                --业务系统                               
                                   ,t.YWZH                                --业务账号                               
                                   ,t.JYS                                 --交易所                                
                                   ,t.GDH                                 --股东号 
                                   ,t.GDZHLB                                --股东类别								   
                                   ,t.SX1                                 --属性1                                
                                   ,t.SX2                                 --属性2                                
                                   ,t.YYB                                 --营业部                                
                                   ,t.ZT                                  --状态                                 
                                   ,t.KTRQ                                --开通日期                               
                                   ,t.GBRQ                                --关闭日期                               
                                   ,t.YWQQID                              --业务请求主键   
                                   ,DECODE(a1.IF_TJ,NULL,3,a1.IF_TJ)
								   ,t.XTBS

 FROM          EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd}  t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING                        t1
 ON             t1.YXT = 'CIF'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN     EDW_PROD.T_EDW_T99_TCCWGDH_PZB   a1
 ON            t.JYS = a1.JYS
 AND           t.GDZHLB = a1.GDZHLB
 AND           t.JYQX = a1.JYQX
 WHERE         a1.IF_TJ < > 2
 AND  t.JYQX NOT IN (21,22)
 UNION ALL
  SELECT                             6                                --交易权限                               
                                   ,t.KHH                                 --客户号                                
                                   ,t.YWXT                                --业务系统                               
                                   ,t.YWZH                                --业务账号                               
                                   ,t.JYS                                 --交易所                                
                                   ,t.GDH                                 --股东号 
                                   ,t.GDZHLB                                --股东类别								   
                                   ,t.SX1                                 --属性1                                
                                   ,t.SX2                                 --属性2                                
                                   ,t.YYB                                 --营业部                                
                                   ,t.ZT                                  --状态                                 
                                   ,t.KTRQ                                --开通日期                               
                                   ,t.GBRQ                                --关闭日期                               
                                   ,t.YWQQID                              --业务请求主键   
                                   ,DECODE(a1.IF_TJ,NULL,3,a1.IF_TJ)
								   ,t.XTBS

 FROM          EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd}  t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING                        t1
 ON             t1.YXT = 'CIF'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN     EDW_PROD.T_EDW_T99_TCCWGDH_PZB   a1
 ON            t.JYS = a1.JYS
 AND           t.GDZHLB = a1.GDZHLB
 AND           t.JYQX = a1.JYQX
 WHERE         a1.IF_TJ < > 2
 AND  t.JYQX  IN (21)
 AND  t.KHH IN (SELECT KHH FROM EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd} WHERE JYQX = 6)
 UNION ALL
  SELECT                             6                                --交易权限                               
                                   ,t.KHH                                 --客户号                                
                                   ,t.YWXT                                --业务系统                               
                                   ,t.YWZH                                --业务账号                               
                                   ,t.JYS                                 --交易所                                
                                   ,t.GDH                                 --股东号 
                                   ,t.GDZHLB                                --股东类别								   
                                   ,t.SX1                                 --属性1                                
                                   ,t.SX2                                 --属性2                                
                                   ,t.YYB                                 --营业部                                
                                   ,t.ZT                                  --状态                                 
                                   ,t.KTRQ                                --开通日期                               
                                   ,t.GBRQ                                --关闭日期                               
                                   ,t.YWQQID                              --业务请求主键   
                                   ,DECODE(a1.IF_TJ,NULL,3,a1.IF_TJ)
								   ,t.XTBS

 FROM          EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd}  t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING                        t1
 ON             t1.YXT = 'CIF'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN     EDW_PROD.T_EDW_T99_TCCWGDH_PZB   a1
 ON            t.JYS = a1.JYS
 AND           t.GDZHLB = a1.GDZHLB
 AND           t.JYQX = a1.JYQX
 WHERE         a1.IF_TJ < > 2
 AND  t.JYQX IN (22)
 AND  t.KHH IN (SELECT KHH FROM EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd} WHERE JYQX = 6)
UNION ALL
  SELECT                             21                                --交易权限                               
                                   ,t.KHH                                 --客户号                                
                                   ,t.YWXT                                --业务系统                               
                                   ,t.YWZH                                --业务账号                               
                                   ,t.JYS                                 --交易所                                
                                   ,t.GDH                                 --股东号 
                                   ,t.GDZHLB                                --股东类别								   
                                   ,t.SX1                                 --属性1                                
                                   ,t.SX2                                 --属性2                                
                                   ,t.YYB                                 --营业部                                
                                   ,t.ZT                                  --状态                                 
                                   ,t.KTRQ                                --开通日期                               
                                   ,t.GBRQ                                --关闭日期                               
                                   ,t.YWQQID                              --业务请求主键   
                                   ,DECODE(a1.IF_TJ,NULL,3,a1.IF_TJ)
								   ,t.XTBS

 FROM          EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd}  t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING                        t1
 ON             t1.YXT = 'CIF'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN     EDW_PROD.T_EDW_T99_TCCWGDH_PZB   a1
 ON            t.JYS = a1.JYS
 AND           t.GDZHLB = a1.GDZHLB
 AND           t.JYQX = a1.JYQX
 WHERE         a1.IF_TJ < > 2
 AND  t.JYQX  IN (21)
 AND  t.KHH NOT IN (SELECT KHH FROM EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd} WHERE JYQX = 6)
 UNION ALL
SELECT                             21                                --交易权限                               
                                   ,t.KHH                                 --客户号                                
                                   ,t.YWXT                                --业务系统                               
                                   ,t.YWZH                                --业务账号                               
                                   ,t.JYS                                 --交易所                                
                                   ,t.GDH                                 --股东号 
                                   ,t.GDZHLB                                --股东类别								   
                                   ,t.SX1                                 --属性1                                
                                   ,t.SX2                                 --属性2                                
                                   ,t.YYB                                 --营业部                                
                                   ,t.ZT                                  --状态                                 
                                   ,t.KTRQ                                --开通日期                               
                                   ,t.GBRQ                                --关闭日期                               
                                   ,t.YWQQID                              --业务请求主键   
                                   ,DECODE(a1.IF_TJ,NULL,3,a1.IF_TJ)
								   ,t.XTBS

 FROM          EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd}  t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING                        t1
 ON             t1.YXT = 'CIF'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN     EDW_PROD.T_EDW_T99_TCCWGDH_PZB   a1
 ON            t.JYS = a1.JYS
 AND           t.GDZHLB = a1.GDZHLB
 AND           t.JYQX = a1.JYQX
 WHERE         a1.IF_TJ < > 2
 AND  t.JYQX  IN (22)
 AND  t.KHH NOT IN (SELECT KHH FROM EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd} WHERE JYQX = 6)
 AND  t.KHH  IN (SELECT KHH FROM EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd} WHERE JYQX = 21)
 UNION ALL
SELECT                             22                                --交易权限                               
                                   ,t.KHH                                 --客户号                                
                                   ,t.YWXT                                --业务系统                               
                                   ,t.YWZH                                --业务账号                               
                                   ,t.JYS                                 --交易所                                
                                   ,t.GDH                                 --股东号 
                                   ,t.GDZHLB                                --股东类别								   
                                   ,t.SX1                                 --属性1                                
                                   ,t.SX2                                 --属性2                                
                                   ,t.YYB                                 --营业部                                
                                   ,t.ZT                                  --状态                                 
                                   ,t.KTRQ                                --开通日期                               
                                   ,t.GBRQ                                --关闭日期                               
                                   ,t.YWQQID                              --业务请求主键   
                                   ,DECODE(a1.IF_TJ,NULL,3,a1.IF_TJ)
								   ,t.XTBS

 FROM          EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd}  t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING                        t1
 ON             t1.YXT = 'CIF'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN     EDW_PROD.T_EDW_T99_TCCWGDH_PZB   a1
 ON            t.JYS = a1.JYS
 AND           t.GDZHLB = a1.GDZHLB
 AND           t.JYQX = a1.JYQX
 WHERE         a1.IF_TJ < > 2
 AND  t.JYQX  IN (22)
 AND  t.KHH NOT IN (SELECT KHH FROM EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd} WHERE JYQX = 6)
 AND  t.KHH NOT IN (SELECT KHH FROM EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd} WHERE JYQX = 21)
 ;
 
DROP TABLE IF EXISTS EDW_PROD.T_EDW_T02_TKHJYQX_TEMP_%d{yyyyMMdd};

------------插入数据结束--
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TKHJYQX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata EDW_PROD.T_EDW_T02_TKHJYQX;
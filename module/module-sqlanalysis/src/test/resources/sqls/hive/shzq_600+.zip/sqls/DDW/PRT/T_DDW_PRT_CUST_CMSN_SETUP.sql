 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:单户佣金设置表                                                                       */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 
  TRUNCATE TABLE DDW_PROD.T_DDW_PRT_CUST_CMSN_SETUP;

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CUST_CMSN_SETUP
(
									 BRH_NO                  --营业部编号
									,BRH_NAME                --营业部名称
									,SRC                     --来源
									,CUST_NO                 --客户号
									,CUST_NAME               --客户姓名
									,SETUP_DT                --设置日期
									,POLCY_NAME              --策略名称
									,CMSN_FIXPRC_MOD         --佣金定价方式
									,AUDT_FLG                --审核标志
)	
 PARTITION(bus_date=%d{yyyyMMdd})
  SELECT 						
							 t.BRH_NO                AS BRH_NO                  --营业部编号
							,NVL(a4.BRH_SHRTNM,a5.filil_dept_shrtnm)          AS BRH_NAME                --营业部名称
							,t.SRC                   AS SRC                     --来源
							,t.CUST_NO               AS CUST_NO                 --客户号
							,a2.CUST_NAME            AS CUST_NAME               --客户姓名
							,t.SETUP_DT              AS SETUP_DT                --设置日期
							,t.POLCY_NAME            AS POLCY_NAME              --策略名称
							,t.CMSN_FIXPRC_MOD       AS CMSN_FIXPRC_MOD         --佣金定价方式
							,t.AUDT_FLG              AS AUDT_FLG                --审核标志
 FROM  		DDW_PROD.T_DDW_F00_DIM_CUST_CMSN_POLCY  t
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                a4
 ON            t.BRH_NO = a4.BRH_NO
 AND           a4.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT                 a5
 ON            t.BRH_NO = a5.FILIL_DEPT_CDG
 AND           a5.BUS_DATE = %d{yyyyMMdd} 
 LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO              			a2
  ON            t.CUST_NO = a2.CUST_NO 		
  AND           a2.bus_date  = 	%d{yyyyMMdd}
 WHERE 		t.bus_date = %d{yyyyMMdd} AND (a2.ordi_cust_stat < > '3' OR a2.ordi_cnclact_dt > %d{yyyyMMdd} )

 ;

-----------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_CUST_CMSN_SETUP',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_CUST_CMSN_SETUP ;
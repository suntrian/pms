 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:非现场开户表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 --    TRUNCATE TABLE EDW_PROD.T_EDW_T02_LCFXCKH; 
------插入数据开始-------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_LCFXCKH
(
                                    LCFXCKH_ID                          --非现场开户主键                            
                                   ,INSTID                              --INSTID                             
                                   ,SQRQ                                --申请日期                               
                                   ,SQSJ                                --申请时间                               
                                   ,KH_KHFS                             --开户_开户方式                            
                                   ,KHZD                                --开户终端                               
                                   ,KHJGBZ                              --客户机构标志                             
                                   ,YYB                                 --营业部                                
                                   ,GTKHH                               --柜台客户号                              
                                   ,KHLYDM                              --客户来源代码                             
                                   ,KHXM                                --客户姓名                               
                                   ,KHQC                                --客户全称                               
                                   ,DJR                                 --登记人                                
                                   ,SHGY                                --审核柜员                               
                                   ,CZZD                                --操作站点                               
                                   ,KHXZR                               --开户协助人                              
                                   ,JZR                                 --见证人                                
                                   ,QDBM                                --渠道编码                               
                                   ,YXRY                                --营销人员                               
                                   ,DN                                  --DN                                 
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,XBDM                                --性别代码                               
                                   ,CSRQ                                --出生日期                               
                                   ,ZJYXQ                               --证件有效期                              
                                   ,ZJDZ                                --证件地址                               
                                   ,ZJDZYB                              --证件地址邮编                             
                                   ,ZJFZJG                              --证件发证机关                             
                                   ,ZJZP                                --ZJZP                               
                                   ,ZJYZLY                              --证件验证来源                             
                                   ,EDZ                                 --是否二代证                              
                                   ,YYZZNJRQ                            --营业执照年检日期                           
                                   ,LXDZ                                --联系地址                               
                                   ,YZBM                                --邮政编码                               
                                   ,JTDZ                                --家庭地址                               
                                   ,JTDZYB                              --家庭地址邮编                             
                                   ,MOBILE                              --手机                                 
                                   ,DH                                  --电话                                 
                                   ,CZ                                  --传真                                 
                                   ,EMAIL                               --EMAIL                              
                                   ,ZYDM                                --职业代码                               
                                   ,HYZKDM                              --婚姻状况代码                             
                                   ,XLDM                                --学历代码                               
                                   ,GZDW                                --工作单位                               
                                   ,GZDW_DZ                             --工作单位地址                             
                                   ,MZDM                                --民族代码                               
                                   ,JG                                  --籍贯                                 
                                   ,GJDM                                --国籍代码                               
                                   ,PROVINCE                            --省份                                 
                                   ,CITY                                --城市                                 
                                   ,SEC                                 --区县                                 
                                   ,TBSM                                --特别说明                               
                                   ,FXQHYLBDM                           --反洗钱行业类别代码                          
                                   ,XQFXDJDM                            --洗钱风险等级代码                           
                                   ,QYXZ                                --机构客户企业性质                           
                                   ,HYLB                                --行业代码                               
                                   ,FRLBDM                              --法人类别代码                             
                                   ,YWMC                                --英文名称                               
                                   ,JGGSDH                              --机构国税代码                             
                                   ,JGZCDZ                              --机构注册地址                             
                                   ,JGZCRQ                              --机构注册日期                             
                                   ,JGJYFW                              --机构经营范围                             
                                   ,JGZCZB                              --机构注册资本                             
                                   ,JGZGB                               --机构总股本                              
                                   ,JGLTGB                              --机构流通股本                             
                                   ,ZZJGDM                              --组织机构代码证                            
                                   ,ZZJGDMYXQ                           --组织机构代码证有效期                         
                                   ,ZZJGDMFZJG                          --组织机构代码发证机关                         
                                   ,ZZJGDMNJRQ                          --组织机构代码年检日期                         
                                   ,SWDJZ                               --税务登记证                              
                                   ,SWDJZYXQ                            --税务登记证有效期                           
                                   ,SWDJZFZJG                           --税务登记证发证机关                          
                                   ,SWDJZNJRQ                           --税务登记证年检日期                          
                                   ,FRDBXM                              --法人代表姓名                             
                                   ,FRDBZJLBDM                          --法人代表证件类别代码                         
                                   ,FRDBZJBH                            --法人代表证件编号                           
                                   ,FRDBZJYXQ                           --法人代表证件有效期                          
                                   ,JBRXM                               --经办人姓名                              
                                   ,JBRZJLBDM                           --经办人证件类别                            
                                   ,JBRZJBH                             --经办人证件编号                            
                                   ,JBRZJYXQ                            --经办人证件有效期                           
                                   ,JBRXBDM                             --经办人性别代码                            
                                   ,JBRDH                               --经办人电话                              
                                   ,JBRSJ                               --经办人手机                              
                                   ,BZDM                                --币种代码                               
                                   ,KHQZ                                --客户群组                               
                                   ,KHKH                                --客户卡号                               
                                   ,WTFS                                --委托方式                               
                                   ,FWXM                                --服务项目                               
                                   ,KHFXJBDM                            --客户风险级别代码                           
                                   ,TZZFL                               --风险承受能力                             
                                   ,GPFXCSNL                            --股票风险承受能力                           
                                   ,SFTB                                --密码是否同步                             
                                   ,JYMM                                --交易密码                               
                                   ,ZJMM                                --ZJMM                               
                                   ,FWMM                                --服务密码                               
                                   ,SQJJZH                              --申请基金账号                             
                                   ,GDKH_SH                             --沪A股东开户                             
                                   ,GDDJ_SH                             --沪A股东登记                             
                                   ,GDKH_HJ                             --沪基股东开户                             
                                   ,GDDJ_HJ                             --沪基股东登记                             
                                   ,GDKH_HB                             --沪B股东开户                             
                                   ,GDDJ_HB                             --沪B股东登记                             
                                   ,GDKH_SZ                             --深A股东开户                             
                                   ,GDDJ_SZ                             --深A股东登记                             
                                   ,GDKH_SJ                             --深基股东开户                             
                                   ,GDDJ_SJ                             --深基股东登记                             
                                   ,GDKH_SB                             --深B股东开户                             
                                   ,GDDJ_SB                             --深B股东登记                             
                                   ,GDKH_TA                             --三板A股东开户                            
                                   ,GDDJ_TA                             --三板A股东登记                            
                                   ,GDKH_TU                             --三板B股东开户                            
                                   ,GDDJ_TU                             --三板B股东登记                            
                                   ,GDJYQX_SH                           --沪A股东交易权限                           
                                   ,GDJYQX_HJ                           --沪基股东交易权限                           
                                   ,GDJYQX_HB                           --沪B股东交易权限                           
                                   ,GDJYQX_SZ                           --深A股东交易权限                           
                                   ,GDJYQX_SJ                           --深基股东交易权限                           
                                   ,GDJYQX_SB                           --深B股东交易权限                           
                                   ,GDJYQX_TA                           --三板A股东交易权限                          
                                   ,GDJYQX_TU                           --三板B股东交易权限                          
                                   ,SHZDJY                              --沪A指定交易                             
                                   ,HBZDJY                              --沪B指定交易                             
                                   ,SFWLFW                              --SFWLFW                             
                                   ,WLFWMM                              --WLFWMM                             
                                   ,CYBKT                               --是否开通创业板                            
                                   ,CYBKTFS                             --业板开通方式                             
                                   ,CGYHZH                              --存管银行帐号                             
                                   ,CGYHMM                              --存管银行密码                             
                                   ,YHDM_USD                            --银行代码（USD）                          
                                   ,DJFS_USD                            --登记方式（USD）                          
                                   ,YHZH_USD                            --银行帐号（USD）                          
                                   ,YHMM_USD                            --银行密码（USD）                          
                                   ,YHDM_HKD                            --银行代码（HKD）                          
                                   ,DJFS_HKD                            --登记方式（HKD）                          
                                   ,YHZH_HKD                            --银行帐号（KHD）                          
                                   ,YHMM_HKD                            --银行密码（HKD）                          
                                   ,KHZP                                --KHZP                               
                                   ,KHSP                                --KHSP                               
                                   ,HFRQ                                --回访日期                               
                                   ,HFSJ                                --回访时间                               
                                   ,HFGYDM                              --回访柜员代码                             
                                   ,HFGYXM                              --回访柜员姓名                             
                                   ,HFJG                                --回访结果                               
                                   ,HFJGSM                              --回访结果说明                             
                                   ,HFTJ                                --HFTJ                               
                                   ,SHZT                                --审核状态                               
                                   ,STEP                                --STEP                               
                                   ,CLJGSM                              --处理结果说明                             
                                   ,FHYJ                                --FHYJ                               
                                   ,WJID                                --问卷ID                               
                                   ,TMDAC                               --题目答案                               
                                   ,HFWJID                              --回访问卷ID                             
                                   ,HFTMDAC                             --回访题目答案                                                                                        
                                   ,YWQQID                              --业务请求主键                             
                                   ,YWDM                                --业务代码                               
                                   ,FQQD                                --发起渠道                               
                                   ,YGT_JGLB                            --一柜通机构类别                            
                                   ,ZBSXDM                              --资本属性代码                             
                                   ,GYSX                                --国有属性                               
                                   ,JGWZDZ                              --机构网站地址                             
                                   ,ZZJGDMZJDZ                          --组织机构代码证件地址                         
                                   ,SPLX                                --SPLX                               
                                   ,RLDBSBL                             --RLDBSBL                            
                                   ,RLGY                                --RLGY                               
                                   ,CPDF                                --测评得分                               
                                   ,YSBZ                                --YSBZ                               
                                   ,YSXX                                --YSXX                               
                                   ,SSSXDM                              --上市属性代码                             
                                   ,JGZCBZ                              --JGZCBZ                             
                                   ,YJZT                                --YJZT   
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.ID                                  as LCFXCKH_ID                          --ID                                  
                                   ,t.INSTID                              as INSTID                              --                                    
                                   ,t.SQRQ                                as SQRQ                                --申请日期                                
                                   ,t.SQSJ                                as SQSJ                                --申请时间                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as KH_KHFS                             --开户方式                                
                                   ,CAST(COALESCE(t23.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHZD AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as KHZD                                --开户终端                                
                                   ,t.JGBZ                                as KHJGBZ                              --机构标志                                
                                   ,CASE WHEN t.YYB = 0
								         THEN '0'
										 ELSE CAST(COALESCE(t24.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )           
										 END                              as YYB                                 --营业部                                 
                                   ,t.GTKHH                               as GTKHH                               --柜台客户号                               
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHLY AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as KHLYDM                              --客户来源                                
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.KHQC                                as KHQC                                --客户全称                                
                                   ,t.DJR                                 as DJR                                 --登记人                                 
                                   ,t.SHGY                                as SHGY                                --审核柜员                                
                                   ,t.CZZD                                as CZZD                                --操作站点                                
                                   ,t.KHXZR                               as KHXZR                               --开户协助人                               
                                   ,t.JZR                                 as JZR                                 --见证人                                 
                                   ,t.QDBM                                as QDBM                                --渠道编码                                
                                   ,t.YXRY                                as YXRY                                --营销人员                                
                                   ,t.DN                                  as DN                                  --                                    
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.XB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as XBDM                                --性别                                  
                                   ,t.CSRQ                                as CSRQ                                --出生日期                                
                                   ,t.ZJYXQ                               as ZJYXQ                               --证件有效期                               
                                   ,t.ZJDZ                                as ZJDZ                                --证件地址                                
                                   ,t.ZJDZYB                              as ZJDZYB                              --证件地址邮编                              
                                   ,t.ZJFZJG                              as ZJFZJG                              --证件发证机关                              
                                   ,t.ZJZP                                as ZJZP                                --                                    
                                   ,t.ZJYZLY                              as ZJYZLY                              --证件验证来源                              
                                   ,t.EDZ                                 as EDZ                                 --是否二代证                               
                                   ,t.YYZZNJRQ                            as YYZZNJRQ                            --营业执照年检日期                            
                                   ,t.DZ                                  as LXDZ                                --联系地址                                
                                   ,t.YZBM                                as YZBM                                --邮政编码                                
                                   ,t.JTDZ                                as JTDZ                                --家庭地址                                
                                   ,t.JTDZYB                              as JTDZYB                              --家庭地址邮编                              
                                   ,t.SJ                                  as MOBILE                              --手机                                  
                                   ,t.DH                                  as DH                                  --电话                                  
                                   ,t.CZ                                  as CZ                                  --传真                                  
                                   ,t.EMAIL                               as EMAIL                               --EMAIL                               
                                   ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZYDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZYDM                                --职业代码                                
                                   ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.HYZK AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as HYZKDM                              --婚姻状况                                
                                   ,CAST(COALESCE(t7.MBDM,NULLIF(CONCAT('ERR',CAST(t.XL AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as XLDM                                --学历                                  
                                   ,t.GZDW                                as GZDW                                --工作单位                                
                                   ,t.GZDWDZ                              as GZDW_DZ                             --工作单位地址                              
                                   ,CAST(COALESCE(t8.MBDM,NULLIF(CONCAT('ERR',CAST(t.MZDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as MZDM                                --民族代码                                
                                   ,t.JG                                  as JG                                  --籍贯                                  
                                   ,CAST(COALESCE(t9.MBDM,NULLIF(CONCAT('ERR',CAST(t.GJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as GJDM                                --国籍                                  
                                   ,t.PROVINCE                            as PROVINCE                            --省份                                  
                                   ,t.CITY                                as CITY                                --城市                                  
                                   ,t.SEC                                 as SEC                                 --区县                                  
                                   ,t.TBSM                                as TBSM                                --特别说明                                
                                   ,CAST(COALESCE(t10.MBDM,NULLIF(CONCAT('ERR',CAST(t.FXQHYLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                             as FXQHYLBDM                           --反洗钱行业类别                             
                                   ,CAST(COALESCE(t11.MBDM,NULLIF(CONCAT('ERR',CAST(t.XQFXDJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as XQFXDJDM                            --洗钱风险等级                              
                                   ,CAST(COALESCE(t12.MBDM,NULLIF(CONCAT('ERR',CAST(t.QYXZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as QYXZ                                --企业性质                                
                                   ,CAST(COALESCE(t13.MBDM,NULLIF(CONCAT('ERR',CAST(t.HYDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as HYLB                                --行业代码                                
                                   ,CAST(COALESCE(t14.MBDM,NULLIF(CONCAT('ERR',CAST(t.FRLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as FRLBDM                              --法人类别                                
                                   ,t.YWMC                                as YWMC                                --英文名称                                
                                   ,t.JGGSDH                              as JGGSDH                              --机构国税代码                              
                                   ,t.JGZCDZ                              as JGZCDZ                              --机构注册地址                              
                                   ,t.JGZCRQ                              as JGZCRQ                              --机构注册日期                              
                                   ,t.JGJYFW                              as JGJYFW                              --机构经营范围                              
                                   ,t.JGZCZB                              as JGZCZB                              --机构注册资本                              
                                   ,t.JGZGB                               as JGZGB                               --机构总股本                               
                                   ,t.JGLTGB                              as JGLTGB                              --机构流通股本                              
                                   ,t.ZZJGDM                              as ZZJGDM                              --组织机构代码证                             
                                   ,t.ZZJGDMYXQ                           as ZZJGDMYXQ                           --组织机构代码证有效期                          
                                   ,t.ZZJGDMFZJG                          as ZZJGDMFZJG                          --组织机构代码发证机关                          
                                   ,t.ZZJGDMNJRQ                          as ZZJGDMNJRQ                          --组织机构代码年检日期                          
                                   ,t.SWDJZ                               as SWDJZ                               --税务登记证                               
                                   ,t.SWDJZYXQ                            as SWDJZYXQ                            --税务登记证有效期                            
                                   ,t.SWDJZFZJG                           as SWDJZFZJG                           --税务登记证发证机关                           
                                   ,t.SWDJZNJRQ                           as SWDJZNJRQ                            --税务登记证年检日期                           
                                   ,t.FRDBXM                              as FRDBXM                              --法人代表姓名                              
                                   ,CAST(COALESCE(t15.MBDM,NULLIF(CONCAT('ERR',CAST(t.FRDBZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                            as FRDBZJLBDM                          --法人代表证件类别                            
                                   ,t.FRDBZJBH                            as FRDBZJBH                            --法人代表证件编号                            
                                   ,t.FRDBZJYXQ                           as FRDBZJYXQ                           --法人代表证件有效期                           
                                   ,t.JBRXM                               as JBRXM                               --经办人姓名                               
                                   ,CAST(COALESCE(t16.MBDM,NULLIF(CONCAT('ERR',CAST(t.JBRZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                             as JBRZJLBDM                           --经办人证件类别                             
                                   ,t.JBRZJBH                             as JBRZJBH                             --经办人证件编号                             
                                   ,t.JBRZJYXQ                            as JBRZJYXQ                            --经办人证件有效期                            
                                   ,CAST(COALESCE(t17.MBDM,NULLIF(CONCAT('ERR',CAST(t.JBRXB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as JBRXBDM                             --经办人性别                               
                                   ,t.JBRDH                               as JBRDH                               --经办人电话                               
                                   ,t.JBRSJ                               as JBRSJ                               --经办人手机                               
                                   ,CAST(COALESCE(t18.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.KHKH                                as KHKH                                --客户卡号                                
                                   ,t.WTFS                                as WTFS                                --委托方式                                
                                   ,t.FWXM                                as FWXM                                --服务项目                                
                                   ,t.FXJB                                as KHFXJBDM                            --风险级别                                
                                   ,t.FXCSNL                              as TZZFL                               --风险承受能力                              
                                   ,t.GPFXCSNL                            as GPFXCSNL                            --股票风险承受能力                            
                                   ,t.SFTB                                as SFTB                                --密码是否同步                              
                                   ,t.JYMM                                as JYMM                                --交易密码                                
                                   ,t.ZJMM                                as ZJMM                                --                                    
                                   ,t.FWMM                                as FWMM                                --服务密码                                
                                   ,t.SQJJZH                              as SQJJZH                              --申请基金账号                              
                                   ,t.GDKH_SH                             as GDKH_SH                             --沪A股东开户                              
                                   ,t.GDDJ_SH                             as GDDJ_SH                             --沪A股东登记                              
                                   ,t.GDKH_HJ                             as GDKH_HJ                             --沪基股东开户                              
                                   ,t.GDDJ_HJ                             as GDDJ_HJ                             --沪基股东登记                              
                                   ,t.GDKH_HB                             as GDKH_HB                             --沪B股东开户                              
                                   ,t.GDDJ_HB                             as GDDJ_HB                             --沪B股东登记                              
                                   ,t.GDKH_SZ                             as GDKH_SZ                             --深A股东开户                              
                                   ,t.GDDJ_SZ                             as GDDJ_SZ                             --深A股东登记                              
                                   ,t.GDKH_SJ                             as GDKH_SJ                             --深基股东开户                              
                                   ,t.GDDJ_SJ                             as GDDJ_SJ                             --深基股东登记                              
                                   ,t.GDKH_SB                             as GDKH_SB                             --深B股东开户                              
                                   ,t.GDDJ_SB                             as GDDJ_SB                             --深B股东登记                              
                                   ,t.GDKH_TA                             as GDKH_TA                             --三板A股东开户                             
                                   ,t.GDDJ_TA                             as GDDJ_TA                             --三板A股东登记                             
                                   ,t.GDKH_TU                             as GDKH_TU                             --三板B股东开户                             
                                   ,t.GDDJ_TU                             as GDDJ_TU                             --三板B股东登记                             
                                   ,t.GDJYQX_SH                           as GDJYQX_SH                           --沪A股东交易权限                            
                                   ,t.GDJYQX_HJ                           as GDJYQX_HJ                           --沪基股东交易权限                            
                                   ,t.GDJYQX_HB                           as GDJYQX_HB                           --沪B股东交易权限                            
                                   ,t.GDJYQX_SZ                           as GDJYQX_SZ                           --深A股东交易权限                            
                                   ,t.GDJYQX_SJ                           as GDJYQX_SJ                           --深基股东交易权限                            
                                   ,t.GDJYQX_SB                           as GDJYQX_SB                           --深B股东交易权限                            
                                   ,t.GDJYQX_TA                           as GDJYQX_TA                           --三板A股东交易权限                           
                                   ,t.GDJYQX_TU                           as GDJYQX_TU                           --三板B股东交易权限                           
                                   ,t.SHZDJY                              as SHZDJY                              --沪A指定交易                              
                                   ,t.HBZDJY                              as HBZDJY                              --沪B指定交易                              
                                   ,t.SFWLFW                              as SFWLFW                              --                                    
                                   ,t.WLFWMM                              as WLFWMM                              --                                    
                                   ,t.CYBKT                               as CYBKT                               --是否开通创业板                             
                                   ,t.CYBKTFS                             as CYBKTFS                             --业板开通方式                              
                                   ,t.CGYHZH                              as CGYHZH                              --存管银行帐号                              
                                   ,t.CGYHMM                              as CGYHMM                              --存管银行密码                              
                                   ,t.YHDM_USD                            as YHDM_USD                            --银行代码（USD）                           
                                   ,t.DJFS_USD                            as DJFS_USD                            --登记方式（USD）                           
                                   ,t.YHZH_USD                            as YHZH_USD                            --银行帐号（USD）                           
                                   ,t.YHMM_USD                            as YHMM_USD                            --银行密码（USD）                           
                                   ,t.YHDM_HKD                            as YHDM_HKD                            --银行代码（HKD）                           
                                   ,t.DJFS_HKD                            as DJFS_HKD                            --登记方式（HKD）                           
                                   ,t.YHZH_HKD                            as YHZH_HKD                            --银行帐号（KHD）                           
                                   ,t.YHMM_HKD                            as YHMM_HKD                            --银行密码（HKD）                           
                                   ,t.KHZP                                as KHZP                                --                                    
                                   ,t.KHSP                                as KHSP                                --                                    
                                   ,t.HFRQ                                as HFRQ                                --回访日期                                
                                   ,t.HFSJ                                as HFSJ                                --回访时间                                
                                   ,t.HFGYDM                              as HFGYDM                              --回访柜员代码                              
                                   ,t.HFGYXM                              as HFGYXM                              --回访柜员姓名                              
                                   ,t.HFJG                                as HFJG                                --回访结果                                
                                   ,t.HFJGSM                              as HFJGSM                              --回访结果说明                              
                                   ,t.HFTJ                                as HFTJ                                --                                    
                                   ,t.SHZT                                as SHZT                                --审核状态                                
                                   ,t.STEP                                as STEP                                --                                    
                                   ,t.CLJGSM                              as CLJGSM                              --处理结果说明                              
                                   ,t.FHYJ                                as FHYJ                                --                                    
                                   ,t.WJID                                as WJID                                --问卷ID                                
                                   ,t.TMDAC                               as TMDAC                               --题目答案                                
                                   ,t.HFWJID                              as HFWJID                              --回访问卷ID                              
                                   ,t.HFTMDAC                             as HFTMDAC                             --回访题目答案                                                             
                                   ,t.YWQQID                              as YWQQID                              --业务请求ID                              
                                   ,t.YWDM                                as YWDM                                --业务代码                                
                                   ,t.FQQD                                as FQQD                                --发起渠道                                
                                   ,CAST(COALESCE(t22.MBDM,NULLIF(CONCAT('ERR',CAST(t.JGLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as YGT_JGLB                            --机构类别                                
                                   ,CAST(COALESCE(t19.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZBSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZBSXDM                              --资本属性                                
                                   ,CAST(COALESCE(t20.MBDM,NULLIF(CONCAT('ERR',CAST(t.GYSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as GYSX                                --国有属性                                
                                   ,t.JGWZDZ                              as JGWZDZ                              --机构网站地址                              
                                   ,t.ZZJGDMZJDZ                          as ZZJGDMZJDZ                          --组织机构代码证件地址                          
                                   ,t.SPLX                                as SPLX                                --                                    
                                   ,t.RLDBSBL                             as RLDBSBL                             --                                    
                                   ,t.RLGY                                as RLGY                                --                                    
                                   ,t.CPDF                                as CPDF                                --测评得分                                
                                   ,t.YSBZ                                as YSBZ                                --                                    
                                   ,t.YSXX                                as YSXX                                --                                    
                                   ,CAST(COALESCE(t20.MBDM,NULLIF(CONCAT('ERR',CAST(t.SSSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SSSXDM                              --上市属性                                
                                   ,t.JGZCBZ                              as JGZCBZ                              --                                    
                                   ,t.YJZT                                as YJZT                                --  
                                   ,'YGT_GT'								   
 FROM           YGTCX.CIF_LCFXCKH                      t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'KH_KHFS'
 AND            t1.YXT = 'YGT_GT'
 AND            t1.YDM = CAST(t.KHFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'KHLYDM'
 AND            t2.YXT = 'YGT_GT'
 AND            t2.YDM = CAST(t.KHLY AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'ZJLBDM'
 AND            t3.YXT = 'YGT_GT'
 AND            t3.YDM = CAST(t.ZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
 ON             t4.DMLX = 'XBDM'
 AND            t4.YXT = 'YGT_GT'
 AND            t4.YDM = CAST(t.XB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t5 
 ON             t5.DMLX = 'ZYDM'
 AND            t5.YXT = 'YGT_GT'
 AND            t5.YDM = CAST(t.ZYDM AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t6 
 ON             t6.DMLX = 'HYZKDM'
 AND            t6.YXT = 'YGT_GT'
 AND            t6.YDM = CAST(t.HYZK AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t7 
 ON             t7.DMLX = 'XLDM'
 AND            t7.YXT = 'YGT_GT'
 AND            t7.YDM = CAST(t.XL AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t8 
 ON             t8.DMLX = 'MZDM'
 AND            t8.YXT = 'YGT_GT'
 AND            t8.YDM = CAST(t.MZDM AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t9 
 ON             t9.DMLX = 'GJDM'
 AND            t9.YXT = 'YGT'
 AND            t9.YDM = CAST(t.GJ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t10 
 ON             t10.DMLX = 'FXQHYLBDM'
 AND            t10.YXT = 'YGT'
 AND            t10.YDM = CAST(t.FXQHYLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t11 
 ON             t11.DMLX = 'XQFXDJDM'
 AND            t11.YXT = 'YGT'
 AND            t11.YDM = CAST(t.XQFXDJ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t12 
 ON             t12.DMLX = 'QYXZ'
 AND            t12.YXT = 'YGT_GT'
 AND            t12.YDM = CAST(t.QYXZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t13 
 ON             t13.DMLX = 'HYLB'
 AND            t13.YXT = 'YGT_GT'
 AND            t13.YDM = CAST(t.HYDM AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t14 
 ON             t14.DMLX = 'FRLBDM'
 AND            t14.YXT = 'YGT_GT'
 AND            t14.YDM = CAST(t.FRLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t15 
 ON             t15.DMLX = 'ZJLBDM'
 AND            t15.YXT = 'YGT_GT'
 AND            t15.YDM = CAST(t.FRDBZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t16 
 ON             t16.DMLX = 'ZJLBDM'
 AND            t16.YXT = 'YGT_GT'
 AND            t16.YDM = CAST(t.JBRZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t17
 ON             t17.DMLX = 'XBDM'
 AND            t17.YXT = 'YGT_GT'
 AND            t17.YDM = CAST(t.JBRXB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t18 
 ON             t18.DMLX = 'BZDM'
 AND            t18.YXT = 'YGT_GT'
 AND            t18.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t19 
 ON             t19.DMLX = 'ZBSXDM'
 AND            t19.YXT = 'YGT_GT'
 AND            t19.YDM = CAST(t.ZBSX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t20 
 ON             t20.DMLX = 'GYSX'
 AND            t20.YXT = 'YGT_GT'
 AND            t20.YDM = CAST(t.GYSX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t21 
 ON             t21.DMLX = 'SSSXDM'
 AND            t21.YXT = 'YGT_GT'
 AND            t21.YDM = CAST(t.SSSX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t22 
 ON             t22.DMLX = 'YGT_JGLB'
 AND            t22.YXT = 'YGT_GT'
 AND            t22.YDM = CAST(t.JGLB AS VARCHAR(20))
  LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t23
 ON             t23.DMLX = 'KH_KHZD'
 AND            t23.YXT = 'YGT'
 AND            t23.YDM = CAST(t.KHZD AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING     t24
 ON             t24.YXT = 'CIF'
 AND            t24.JGDM = CAST(t.YYB AS VARCHAR(20)) 
 WHERE          t.DT = '%d{yyyyMMdd}';
---------插入数据结束---------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_LCFXCKH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_LCFXCKH;
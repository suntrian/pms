   --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户对账单收益区段分布年表                                                        */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-02-02                                                                        */ 
-----删除今年的数据---
ALTER TABLE DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR DROP IF EXISTS PARTITION (YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT) ) ; 

  
 INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期  	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  0      as NET_INCM_MIN
         ,5  as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  0
 AND   t.NET_INCM < = 5
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT);
 
  
 INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期  	 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT   5            as NET_INCM_MIN                 --最小收益率
         ,10            as NET_INCM_MAX                 --最大收益率
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  5
 AND   t.NET_INCM < = 10 
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT);
 
 
  INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT   10          as NET_INCM_MIN                 --最小收益率
         ,15        as NET_INCM_MAX                 --最大收益率
         ,count(1)      as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  10
 AND   t.NET_INCM < = 15
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT) ;
 
 
   INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT   15       as NET_INCM_MIN                 --最小收益率
         ,20       as NET_INCM_MAX                 --最大收益率
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  15
 AND   t.NET_INCM < = 20
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT) ;
 
 
 
    INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  20      as NET_INCM_MIN
         ,25     as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  20
 AND   t.NET_INCM < = 25
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
    INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
            NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  25   as NET_INCM_MIN
         ,30   as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  25
 AND   t.NET_INCM < = 30
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT) 
  ;
      INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
            NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期  	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  30      as NET_INCM_MIN
         ,35      as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  30
 AND   t.NET_INCM < = 35
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
        INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期  	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  35     as NET_INCM_MIN
         ,40     as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  35
 AND   t.NET_INCM < = 40
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
          INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  40        as NET_INCM_MIN
         ,45      as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  40
 AND   t.NET_INCM < = 45
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
           INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  45    as NET_INCM_MIN
         ,50      as NET_INCM_MAX
         ,count(1)    as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  45
 AND   t.NET_INCM < = 50
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
             INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
		    NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  50        as NET_INCM_MIN
         ,55      as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  50
 AND   t.NET_INCM < = 55
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
  INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期  	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  55       as NET_INCM_MIN
         ,60      as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  55
 AND   t.NET_INCM < = 60
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
    INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期  	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  60       as NET_INCM_MIN
         ,65      as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  60
 AND   t.NET_INCM < = 65
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
    INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  65  as NET_INCM_MIN
         ,70   as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  65
 AND   t.NET_INCM < = 70
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
      INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  70      as NET_INCM_MIN
         ,75      as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  70
 AND   t.NET_INCM < = 75
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
       INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  75   as NET_INCM_MIN
         ,80   as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  75
 AND   t.NET_INCM < = 80
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
        INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  80        as NET_INCM_MIN
         ,85      as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  80
 AND   t.NET_INCM < = 85
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
         INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  85   as NET_INCM_MIN
         ,90   as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  85
 AND   t.NET_INCM < = 90
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
        INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  90        as NET_INCM_MIN
         ,95      as NET_INCM_MAX 
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  90
 AND   t.NET_INCM < = 95
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ; 
    
        INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  95    as NET_INCM_MIN
         ,100       as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  95
 AND   t.NET_INCM < = 100
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;


        INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  100   as NET_INCM_MIN
         ,100    as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM >  100
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ; 
  
  INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -5     as NET_INCM_MIN
         ,0        as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < = 0
 AND   t.NET_INCM >  -5
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT) ;
 
  
 INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
		    NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -10        as NET_INCM_MIN
         ,-5      as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM  < = -5
 AND   t.NET_INCM >  -10
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT) ;
 
 
  INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期  	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -15        as NET_INCM_MIN
         ,-10        as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < = -10
 AND   t.NET_INCM >  -15
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT) ;
 
 
   INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期  	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -20         as NET_INCM_MIN
         ,-15       as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -15
 AND   t.NET_INCM >  -20
 AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT) ;
 
 
 
    INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -25   as NET_INCM_MIN
         ,-20   as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -20
 AND   t.NET_INCM > -25 
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
    INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
		    NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -30  as NET_INCM_MIN
         ,-25 as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM <  -25
 AND   t.NET_INCM > -30 
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
  
  
  
      INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期   	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -35   as NET_INCM_MIN
         ,-30   as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -30
 AND   t.NET_INCM > -35
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
        INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
          	NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -40   as NET_INCM_MIN
         ,-35  as NET_INCM_MAX 
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -35
 AND   t.NET_INCM > -40
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
          INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
        	NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期  	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -45   as NET_INCM_MIN
         ,-40   as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -40
 AND   t.NET_INCM > -45
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
           INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期  	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -50         as NET_INCM_MIN
         ,-45       as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -45
 AND   t.NET_INCM > -50
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
             INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -55   as NET_INCM_MIN
         ,-50   as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -50
 AND   t.NET_INCM > -55
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
  INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期   	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -60   as NET_INCM_MIN
         ,-55 as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -55
 AND   t.NET_INCM > -60
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
    INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
         	NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -65   as NET_INCM_MIN
         ,-60  as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -60
 AND   t.NET_INCM > -65
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
    INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -70   as NET_INCM_MIN
         ,-65 as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -65
 AND   t.NET_INCM > -70
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
      INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -75   as NET_INCM_MIN
         ,-70   as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -70
 AND   t.NET_INCM > -75
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
       INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -80  as NET_INCM_MIN
         ,-75 as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -75
 AND   t.NET_INCM > -80
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
  
        INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期  	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -85       as NET_INCM_MIN
         ,-80       as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -80
 AND   t.NET_INCM > -85
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
         INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -90   as NET_INCM_MIN
         ,-85 as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -85
 AND   t.NET_INCM > -90
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;
        INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期  	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -95     as NET_INCM_MIN
         ,-90        as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -90
 AND   t.NET_INCM > -95
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ; 
    
        INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -100         as NET_INCM_MIN
         ,-95     as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -95
 AND   t.NET_INCM > -100
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ;


        INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR
(
                                  
			NET_INCM_MIN                 --最小收益率
		   ,NET_INCM_MAX                 --最大收益率
		   ,PSN_VOL                      --人数
		   ,ETL_DT                       --加载日期 	
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT  -100   as NET_INCM_MIN
         ,-100    as NET_INCM_MAX
         ,count(1)  as PSN_VOL
         ,%d{yyyyMMdd}  as ETL_DT
 FROM DDW_PROD.T_DDW_CUST_STATMT_YEAR t
 WHERE t.NET_INCM < =  -100
  AND  t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
  ; 
  
-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_RANGE_DS_YEAR;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:债券抵押明细表                                                                     */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
   TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZQDYMX; 
----------插入数据开始------------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZQDYMX
(
                                    JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,ZQDM                                --债券代码                               
                                   ,BZQDM                               --标准券代码                              
                                   ,KHH                                 --客户号                                
                                   ,DYSL                                --抵押数量                               
                                   ,JYSSL                               --交易所数量  
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.ZQDM                                as ZQDM                                --债券代码                                
                                   ,t.BZQDM                               as BZQDM                               --标准券代码                               
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.DYSL                                as DYSL                                --抵押数量                                
                                   ,t.JYSSL                               as JYSSL                               --交易所数量   
								   ,'JZJY'                                as XTBS
                                   								   
 FROM       JZJYCX.SECURITIES_TZQDYMX t
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束-----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZQDYMX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TZQDYMX;
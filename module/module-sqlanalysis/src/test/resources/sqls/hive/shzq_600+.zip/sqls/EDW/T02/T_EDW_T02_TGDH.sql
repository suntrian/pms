 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:股东账号表                                                                */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:'201'6-11-02                                                                       */

TRUNCATE TABLE EDW_PROD.T_EDW_T02_TGDH ;

---------创建股东账号临时表1----------------------
 ------------------------删除临时表--------------------------------
DROP TABLE  IF EXISTS   EDW_PROD.T_EDW_T02_TGDH_TEMP;
 -----------------------删除结束----------------------------------
 
CREATE TABLE EDW_PROD.T_EDW_T02_TGDH_TEMP AS
 SELECT  t.KHH
        ,CAST(COALESCE(t9.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) AS YYB
        ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) AS JYS
        ,t.GDH
        ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )  AS BZ
        ,t.GDMC
        ,t.GDJC
        ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) AS ZJLB
        ,t.ZJBH
        ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.GDZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) AS GDZT
        ,CASE WHEN t.JYS = 1 AND SUBSTR(t.GDH,1,1) = 'F'
		      THEN '1'
			  WHEN t.JYS = 2 AND SUBSTR(t.GDH,1,3) = '001'
			  THEN '1'
              WHEN t.JYS = 2 AND SUBSTR(t.GDH,1,2) = '05'  
		      THEN '1'
			  WHEN t.JYS = 1 AND SUBSTR(t.GDH,1,1) = 'E'
			  THEN '2'
			  WHEN t.JYS = 2 AND SUBSTR(t.GDH,1,2) = '06'  
		      THEN '2'
			  WHEN t.JYS = 1 AND SUBSTR(t.GDH,1,1) IN ('A','B','D')
		      THEN '3'
			  WHEN t.JYS = 2 AND SUBSTR(t.GDH,1,1) IN ('0','4')
		      THEN '3'
			  WHEN t.JYS = 3 AND SUBSTR(t.GDH,1,2) IN ('C1')
			  THEN '4'
		      WHEN t.JYS = 3 AND SUBSTR(t.GDH,1,2) IN ('C9')
			  THEN '5'
			  WHEN t.JYS = 4 AND SUBSTR(t.GDH,1,1) IN ('2')
			  THEN '6'
			  WHEN t.JYS = 5 AND SUBSTR(t.GDH,1,1) IN ('0','4')
			  THEN '7'
			  WHEN t.JYS = 6 AND SUBSTR(t.GDH,1,1) IN ('0','2','4')
			  THEN '8'
			  WHEN t.JYS = 7 AND SUBSTR(t.GDH,1,1) IN ('A','B','D')
			  THEN '9'
			  WHEN t.JYS = 8 AND SUBSTR(t.GDH,1,1) IN ('0','4')
			  THEN '10'
    		  END AS ZHLB
        ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.GDLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) AS GDLB
        ,CAST(COALESCE(t7.MBDM,NULLIF(CONCAT('ERR',CAST(t.SBJB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) AS SBJB
        ,t.KHRQ
        ,t.XHRQ
        ,t.SCJYRQ
        ,t.QSRQ
        ,t.SXRQ
        ,CAST(COALESCE(t8.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZZHBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) AS ZZHBZ
        ,t.GDZDSX
        ,t.GDKZSX
        ,t.GDZDXW
        ,t.BPGDH
        ,t.SYXXBZ
        ,t.YWXT
        ,t.YWZH
  FROM   		 YGTCX.CIF_TGDZH 						t
  LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
  ON             t1.DMLX = 'JYS'
  AND            t1.YXT = 'YGT_GT'
  AND            t1.YDM = CAST(t.JYS AS VARCHAR(20))
  LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
  ON             t2.DMLX = 'BZDM'
  AND            t2.YXT = 'YGT_GT'
  AND            t2.YDM = CAST(t.BZ AS VARCHAR(20))
  LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
  ON             t3.DMLX = 'ZJLBDM'
  AND            t3.YXT = 'YGT_GT'
  AND            t3.YDM = CAST(t.ZJLB AS VARCHAR(20))
  LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
  ON             t4.DMLX = 'GDZT'
  AND            t4.YXT = 'YGT_GT'
  AND            t4.YDM = CAST(t.GDZT AS VARCHAR(20))
  LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t5 
  ON             t5.DMLX = 'GDZHLB'
  AND            t5.YXT = 'YGT_GT'
  AND            t5.YDM = CAST(t.ZHLB AS VARCHAR(20))
  LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t6 
  ON             t6.DMLX = 'GDLB'
  AND            t6.YXT = 'YGT_GT'
  AND            t6.YDM = CAST(t.GDLB AS VARCHAR(20))
  LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t7 
  ON             t7.DMLX = 'GDSBJBDM'
  AND            t7.YXT = 'YGT_GT'
  AND            t7.YDM = CAST(t.SBJB AS VARCHAR(20))
  LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t8 
  ON             t8.DMLX = 'GDZZHBZ'
  AND            t8.YXT = 'YGT_GT'
  AND            t8.YDM = CAST(t.ZZHBZ AS VARCHAR(20))
  LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t9
  ON             t9.YXT = 'CIF'
  AND            t9.JGDM = CAST(t.YYB AS VARCHAR(20))
  WHERE          t.JYS <> 0 
  AND            t.DT = '%d{yyyyMMdd}' 
  AND            ((t.JYS = 1 AND SUBSTR(t.GDH,1,1) IN ('A','B','D','E','F'))
  OR (t.JYS = 2 AND SUBSTR(t.GDH,1,1) IN ('0','4'))
    OR (t.JYS = 3 AND SUBSTR(t.GDH,1,2) IN ('C1','C9'))
	OR (t.JYS = 4 AND SUBSTR(t.GDH,1,1) IN ('2'))
	OR (t.JYS = 5 AND SUBSTR(t.GDH,1,1) IN ('0','4'))
	OR (t.JYS = 6 AND SUBSTR(t.GDH,1,1) IN ('0','4','2'))
	OR (t.JYS = 7 AND SUBSTR(t.GDH,1,1) IN ('A','B','D'))
	OR (t.JYS = 8 AND SUBSTR(t.GDH,1,1) IN ('0','4'))
	)
 ;
 ---------------------------创建临时表结束----------------------
 
 --------------------插入集中交易营业部为4444的客户------
 INSERT INTO EDW_PROD.T_EDW_T02_TGDH(
                                    KHH                                 --客户号                                
                                   ,YYB                                 --营业部                                
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,BZDM                                --币种代码                               
                                   ,GDMC                                --股东名称                               
                                   ,GDJC                                --股东简称                               
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,GDZT                                --股东状态                               
                                   ,GDZHLB                              --股东账户类别                             
                                   ,GDLB                                --股东类别                               
                                   ,GDSBJBDM                            --股东帐户申报级别代码                         
                                   ,KHRQ                                --开户日期                               
                                   ,XHRQ                                --销户日期                               
                                   ,SCJYRQ                              --首次交易日期                             
                                   ,QSRQ                                --签署日期                               
                                   ,SXRQ                                --生效日期                               
                                   ,GDZZHBZ                             --股东主账户标志                            
                                   ,GDZDSX                              --股东指定属性                             
                                   ,GDKZSX                              --股东控制属性                             
                                   ,GDZDXW                              --股东指定席位                             
                                   ,BPGDH                               --报盘股东号                              
                                   ,SYXXBZ                              --使用信息标志                             
                                   ,YWXT                                --业务系统                               
                                   ,YWZH                                --业务账号    
                                   ,KHQZ                                --客户群组                               
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,JSZH                                --结算帐户                               
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,JYFW                                --交易范围                               
                                   ,GDDJRQ                              --股东登记日期                             
                                   ,FWXM                                --服务项目                               
                                   ,ZHSZ                                --帐户市值                               
                                   ,BGSSCJYRQ                           --本公司的首次交易日期  
								   ,XTBS
  								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT                           t.KHH                         AS KHH                                 --客户号        
                                 ,CAST(COALESCE(t7.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                         AS YYB                                 --营业部        
                                 ,t.JYS                         AS JYS                                 --交易所        
                                 ,t.GDH                         AS GDH                                 --股东号        
                                 ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                          AS BZDM                                --币种代码       
                                 ,t.KHXM                        AS GDMC                                --股东名称       
                                 ,NULL                          AS GDJC                                --股东简称       
                                 ,NULL                          AS ZJLBDM                              --证件类别代码     
                                 ,t.GDSFZH                      AS ZJBH                                --证件编号       
                                 ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.GDZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )       as GDZT                                                       --股东状态       
                                 ,CASE WHEN t.JYS = 'SH' AND SUBSTR(t.GDH,1,1) = 'F'
		                               THEN '1'
			                           WHEN t.JYS = 'SZ' AND SUBSTR(t.GDH,1,3) = '001'
			                           THEN '1'
                                       WHEN t.JYS = 'SZ' AND SUBSTR(t.GDH,1,2) = '05'  
		                               THEN '1'
			                           WHEN t.JYS = 'SH' AND SUBSTR(t.GDH,1,1) = 'E'
			                           THEN '2'
			                           WHEN t.JYS = 'SZ' AND SUBSTR(t.GDH,1,2) = '06'  
		                               THEN '2'
			                           WHEN t.JYS = 'SH' AND SUBSTR(t.GDH,1,1) IN ('A','B','D')
		                               THEN '3'
			                           WHEN t.JYS = 'SZ' AND SUBSTR(t.GDH,1,1) IN ('0','4')
		                               THEN '3'
			                           WHEN t.JYS = 'HB' AND SUBSTR(t.GDH,1,2) IN ('C1')
			                           THEN '4'
		                               WHEN t.JYS = 'HB' AND SUBSTR(t.GDH,1,2) IN ('C9')
			                           THEN '5'
			                           WHEN t.JYS = 'SB' AND SUBSTR(t.GDH,1,1) IN ('2')
			                           THEN '6'
			                           WHEN t.JYS = 'TA' AND SUBSTR(t.GDH,1,1) IN ('0','4')
			                           THEN '7'
			                           WHEN t.JYS = 'TU' AND SUBSTR(t.GDH,1,1) IN ('0','2','4')
			                           THEN '8'
			                           WHEN t.JYS = 'HK' AND SUBSTR(t.GDH,1,1) IN ('A','B','D')
			                           THEN '9'
			                           WHEN t.JYS = 'SK' AND SUBSTR(t.GDH,1,1) IN ('0','4')
			                           THEN '10'
    		                           END                           AS GDZHLB                              --股东账户类别     
                                 ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.GDLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )      as GDLB                                                       --股东类别       
                                 ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.SBJB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )       as GDSBJBDM                                                   --股东帐户申报级别代码 
                                 ,t.GDDJRQ                      AS KHRQ                                --开户日期       
                                 ,NULL                          AS XHRQ                                --销户日期       
                                 ,NULL                          AS SCJYRQ                              --首次交易日期     
                                 ,NULL                          AS QSRQ                                --签署日期       
                                 ,NULL                          AS SXRQ                                --生效日期       
                                 ,CAST(t.ZZHBZ AS STRING)       AS GDZZHBZ                             --股东主账户标志    
                                 ,t.GDZDSX                      AS GDZDSX                              --股东指定属性     
                                 ,t.GDKZSX                      AS GDKZSX                              --股东控制属性     
                                 ,NULL                          AS GDZDXW                              --股东指定席位     
                                 ,t.BPGDH                       AS BPGDH                               --报盘股东号      
                                 ,NULL                          AS SYXXBZ                              --使用信息标志     
                                 ,NULL                          AS YWXT                                --业务系统       
                                 ,NULL                          AS YWZH                                --业务账号       
                                 ,t.KHQZ                        AS KHQZ                                --客户群组       
                                 ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                        AS ZJJSLX                              --交易资金结算类型   
                                 ,t.JSJG                        AS JSJG                                --结算机构       
                                 ,t.JSZH                        AS JSZH                                --结算帐户       
                                 ,t.ZHGLJG                      AS ZHGLJG                              --帐户管理机构     
                                 ,CAST(CASE WHEN t.JYS = 'HK' AND t.JYFW = 1 
								  THEN '201' 
								  ELSE CAST(t.JYFW AS VARCHAR(20))  
								  END AS VARCHAR(20)) AS JYFW                                --交易范围       
                                 ,t.GDDJRQ                      AS GDDJRQ                              --股东登记日期     
                                 ,t.FWXM                        AS FWXM
                                 ,t.ZHSZ                        AS ZHSZ
								 ,a1.BGSSCJYRQ                  AS BGSSCJYRQ
							     ,'JZJY'                        AS XTBS
 FROM 			JZJYCX.DATACENTER_TGDH                            t
 LEFT JOIN ( SELECT  khh
                    ,gdh
                    ,CAST(min(CJRQ) AS STRING) AS BGSSCJYRQ 
			 FROM   JZJYCX.DATACENTER_TJGMXLS 
	         WHERE  WTLB IN (1,2,57,58,59,60) 
	         AND    (ZQLB LIKE 'A%' OR  ZQLB LIKE 'B%' OR  ZQLB LIKE 'C%' OR ZQLB LIKE 'G%')
	         GROUP BY  khh,gdh
	       )                                            a1
 ON        		t.khh = a1.khh
 AND       		t.gdh = a1.gdh
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'GDZT'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.GDZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3
 ON             t3.DMLX = 'GDLB'
 AND            t3.YXT = 'JZJY'
 AND            t3.YDM = CAST(t.GDLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
 ON             t4.DMLX = 'GDSBJBDM'
 AND            t4.YXT = 'JZJY'
 AND            t4.YDM = CAST(t.SBJB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t5 
 ON             t5.DMLX = 'ZJJSLX'
 AND            t5.YXT = 'JZJY'
 AND            t5.YDM = CAST(t.JSLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t6 
 ON             t6.DMLX = 'GDJYQX'
 AND            t6.YXT = 'JZJY'
 AND            t6.YDM = CAST(t.JYFW AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t7
 ON             t7.YXT = 'JZJY'
 AND            t7.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}' AND t.YYB = '4444'
  AND            ((t.JYS = 'SH' AND SUBSTR(t.GDH,1,1) IN ('A','B','D','E','F'))
                   OR (t.JYS = 'SZ' AND SUBSTR(t.GDH,1,1) IN ('0','4'))
                   OR (t.JYS = 'HB' AND SUBSTR(t.GDH,1,2) IN ('C1','C9'))
	               OR (t.JYS = 'SB' AND SUBSTR(t.GDH,1,1) IN ('2'))
	               OR (t.JYS = 'TA' AND SUBSTR(t.GDH,1,1) IN ('0','4'))
	               OR (t.JYS = 'TU' AND SUBSTR(t.GDH,1,1) IN ('0','4','2'))
	               OR (t.JYS = 'HK' AND SUBSTR(t.GDH,1,1) IN ('A','B','D'))
	               OR (t.JYS = 'SK' AND SUBSTR(t.GDH,1,1) IN ('0','4'))
	              )
 ;
 
 --------------------插入集中交易营业部为4444的客户结束------
 
  --------------------插入融资融券营业部为9999的客户------
 INSERT INTO EDW_PROD.T_EDW_T02_TGDH(
                                    KHH                                 --客户号                                
                                   ,YYB                                 --营业部                                
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,BZDM                                --币种代码                               
                                   ,GDMC                                --股东名称                               
                                   ,GDJC                                --股东简称                               
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,GDZT                                --股东状态                               
                                   ,GDZHLB                              --股东账户类别                             
                                   ,GDLB                                --股东类别                               
                                   ,GDSBJBDM                            --股东帐户申报级别代码                         
                                   ,KHRQ                                --开户日期                               
                                   ,XHRQ                                --销户日期                               
                                   ,SCJYRQ                              --首次交易日期                             
                                   ,QSRQ                                --签署日期                               
                                   ,SXRQ                                --生效日期                               
                                   ,GDZZHBZ                             --股东主账户标志                            
                                   ,GDZDSX                              --股东指定属性                             
                                   ,GDKZSX                              --股东控制属性                             
                                   ,GDZDXW                              --股东指定席位                             
                                   ,BPGDH                               --报盘股东号                              
                                   ,SYXXBZ                              --使用信息标志                             
                                   ,YWXT                                --业务系统                               
                                   ,YWZH                                --业务账号    
                                   ,KHQZ                                --客户群组                               
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,JSZH                                --结算帐户                               
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,JYFW                                --交易范围                               
                                   ,GDDJRQ                              --股东登记日期                             
                                   ,FWXM                                --服务项目                               
                                   ,ZHSZ                                --帐户市值                               
                                   ,BGSSCJYRQ                           --本公司的首次交易日期  
								   ,XTBS
  								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT                           t.KHH                         AS KHH                                 --客户号        
                                 ,CAST(COALESCE(t7.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                         AS YYB                                 --营业部        
                                 ,t.JYS                         AS JYS                                 --交易所        
                                 ,t.GDH                         AS GDH                                 --股东号        
                                 ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                          AS BZDM                                --币种代码       
                                 ,t.KHXM                        AS GDMC                                --股东名称       
                                 ,NULL                          AS GDJC                                --股东简称       
                                 ,NULL                          AS ZJLBDM                              --证件类别代码     
                                 ,t.GDSFZH                      AS ZJBH                                --证件编号       
                                 ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.GDZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )       as GDZT                                                    --股东状态       
                                 ,CASE WHEN t.JYS = 'SH' AND SUBSTR(t.GDH,1,1) = 'F'
		                               THEN '1'
			                           WHEN t.JYS = 'SZ' AND SUBSTR(t.GDH,1,3) = '001'
			                           THEN '1'
                                       WHEN t.JYS = 'SZ' AND SUBSTR(t.GDH,1,2) = '05'  
		                               THEN '1'
			                           WHEN t.JYS = 'SH' AND SUBSTR(t.GDH,1,1) = 'E'
			                           THEN '2'
			                           WHEN t.JYS = 'SZ' AND SUBSTR(t.GDH,1,2) = '06'  
		                               THEN '2'
			                           WHEN t.JYS = 'SH' AND SUBSTR(t.GDH,1,1) IN ('A','B','D')
		                               THEN '3'
			                           WHEN t.JYS = 'SZ' AND SUBSTR(t.GDH,1,1) IN ('0','4')
		                               THEN '3'
			                           WHEN t.JYS = 'HB' AND SUBSTR(t.GDH,1,2) IN ('C1')
			                           THEN '4'
		                               WHEN t.JYS = 'HB' AND SUBSTR(t.GDH,1,2) IN ('C9')
			                           THEN '5'
			                           WHEN t.JYS = 'SB' AND SUBSTR(t.GDH,1,1) IN ('2')
			                           THEN '6'
			                           WHEN t.JYS = 'TA' AND SUBSTR(t.GDH,1,1) IN ('0','4')
			                           THEN '7'
			                           WHEN t.JYS = 'TU' AND SUBSTR(t.GDH,1,1) IN ('0','2','4')
			                           THEN '8'
			                           WHEN t.JYS = 'HK' AND SUBSTR(t.GDH,1,1) IN ('A','B','D')
			                           THEN '9'
			                           WHEN t.JYS = 'SK' AND SUBSTR(t.GDH,1,1) IN ('0','4')
			                           THEN '10'
    		                           END                          AS GDZHLB                              --股东账户类别     
                                 ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.GDLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )       as GDLB                                                      --股东类别       
                                 ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.SBJB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )       as GDSBJBDM                                                  --股东帐户申报级别代码 
                                 ,t.GDDJRQ                      AS KHRQ                                --开户日期       
                                 ,NULL                          AS XHRQ                                --销户日期       
                                 ,NULL                          AS SCJYRQ                              --首次交易日期     
                                 ,NULL                          AS QSRQ                                --签署日期       
                                 ,NULL                          AS SXRQ                                --生效日期       
                                 ,CAST(t.ZZHBZ AS STRING)       AS GDZZHBZ                             --股东主账户标志    
                                 ,t.GDZDSX                      AS GDZDSX                              --股东指定属性     
                                 ,t.GDKZSX                      AS GDKZSX                              --股东控制属性     
                                 ,NULL                          AS GDZDXW                              --股东指定席位     
                                 ,t.BPGDH                       AS BPGDH                               --报盘股东号      
                                 ,NULL                          AS SYXXBZ                              --使用信息标志     
                                 ,NULL                          AS YWXT                                --业务系统       
                                 ,NULL                          AS YWZH                                --业务账号       
                                 ,t.KHQZ                        AS KHQZ                                --客户群组       
                                 ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                        AS ZJJSLX                              --交易资金结算类型   
                                 ,t.JSJG                        AS JSJG                                --结算机构       
                                 ,t.JSZH                        AS JSZH                                --结算帐户       
                                 ,t.ZHGLJG                      AS ZHGLJG                              --帐户管理机构     
                                 ,CAST(CASE WHEN t.JYS = 'HK' AND t.JYFW = 1 
								  THEN '201' 
								  ELSE CAST(t.JYFW AS VARCHAR(20))  
								  END AS VARCHAR(20)) AS JYFW                                --交易范围       
                                 ,t.GDDJRQ                      AS GDDJRQ                              --股东登记日期     
                                 ,t.FWXM                        AS FWXM
                                 ,t.ZHSZ                        AS ZHSZ
								 ,a1.BGSSCJYRQ                  AS BGSSCJYRQ
							     ,'RZRQ'                        AS XTBS
 FROM 			RZRQCX.DATACENTER_TGDH                            t
 LEFT JOIN ( SELECT  khh
                    ,gdh
                    ,CAST(min(CJRQ) AS STRING) AS BGSSCJYRQ 
			 FROM   RZRQCX.DATACENTER_TJGMXLS 
	         where WTLB IN (1,2,57,58,59,60,61,62,63,64) 
	         AND (ZQLB LIKE 'A%' OR  ZQLB LIKE 'B%' OR  ZQLB LIKE 'C%' OR ZQLB LIKE 'G%')
	         GROUP BY  khh,gdh
	       )                                            a1
 ON        		t.khh = a1.khh
 AND       		t.gdh = a1.gdh
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'GDZT'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.GDZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3
 ON             t3.DMLX = 'GDLB'
 AND            t3.YXT = 'RZRQ'
 AND            t3.YDM = CAST(t.GDLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
 ON             t4.DMLX = 'GDSBJBDM'
 AND            t4.YXT = 'RZRQ'
 AND            t4.YDM = CAST(t.SBJB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t5 
 ON             t5.DMLX = 'ZJJSLX'
 AND            t5.YXT = 'RZRQ'
 AND            t5.YDM = CAST(t.JSLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t6 
 ON             t6.DMLX = 'GDJYQX'
 AND            t6.YXT = 'RZRQ'
 AND            t6.YDM = CAST(t.JYFW AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t7
 ON             t7.YXT = 'RZRQ'
 AND            t7.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}' AND t.YYB = '9999'
 AND            ((t.JYS = 'SH' AND SUBSTR(t.GDH,1,1) IN ('A','B','D','E','F'))
                   OR (t.JYS = 'SZ' AND SUBSTR(t.GDH,1,1) IN ('0','4'))
                   OR (t.JYS = 'HB' AND SUBSTR(t.GDH,1,2) IN ('C1','C9'))
	               OR (t.JYS = 'SB' AND SUBSTR(t.GDH,1,1) IN ('2'))
	               OR (t.JYS = 'TA' AND SUBSTR(t.GDH,1,1) IN ('0','4'))
	               OR (t.JYS = 'TU' AND SUBSTR(t.GDH,1,1) IN ('0','4','2'))
	               OR (t.JYS = 'HK' AND SUBSTR(t.GDH,1,1) IN ('A','B','D'))
	               OR (t.JYS = 'SK' AND SUBSTR(t.GDH,1,1) IN ('0','4'))
	              )
 ;
 
 --------------------插入融资融券营业部为9999的客户结束------
 
 -------------------------插入CIF系统的数据------------------
  INSERT INTO EDW_PROD.T_EDW_T02_TGDH(
                                    KHH                                 --客户号                                
                                   ,YYB                                 --营业部                                
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,BZDM                                --币种代码                               
                                   ,GDMC                                --股东名称                               
                                   ,GDJC                                --股东简称                               
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,GDZT                                --股东状态                               
                                   ,GDZHLB                              --股东账户类别                             
                                   ,GDLB                                --股东类别                               
                                   ,GDSBJBDM                            --股东帐户申报级别代码                         
                                   ,KHRQ                                --开户日期                               
                                   ,XHRQ                                --销户日期                               
                                   ,SCJYRQ                              --首次交易日期                             
                                   ,QSRQ                                --签署日期                               
                                   ,SXRQ                                --生效日期                               
                                   ,GDZZHBZ                             --股东主账户标志                            
                                   ,GDZDSX                              --股东指定属性                             
                                   ,GDKZSX                              --股东控制属性                             
                                   ,GDZDXW                              --股东指定席位                             
                                   ,BPGDH                               --报盘股东号                              
                                   ,SYXXBZ                              --使用信息标志                             
                                   ,YWXT                                --业务系统                               
                                   ,YWZH                                --业务账号    
                                   ,KHQZ                                --客户群组                               
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,JSZH                                --结算帐户                               
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,JYFW                                --交易范围                               
                                   ,GDDJRQ                              --股东登记日期                             
                                   ,FWXM                                --服务项目                               
                                   ,ZHSZ                                --帐户市值                               
                                   ,BGSSCJYRQ                           --本公司的首次交易日期  
								   ,XTBS
  								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT                       
                                    t.KHH              AS KHH                                 --客户号                  
                                   ,CAST(t.YYB  AS STRING)     AS YYB                                 --营业部                                                   
								   ,t.JYS              AS JYS                                 --交易所                  
                                   ,t.GDH              AS GDH                                 --股东号                  
                                   ,t.BZ               AS BZDM                                --币种代码                
                                   ,t.GDMC             AS GDMC                                --股东名称                
                                   ,t.GDJC             AS GDJC                                --股东简称                
                                   ,t.ZJLB             AS ZJLBDM                              --证件类别代码            
                                   ,t.ZJBH             AS ZJBH                                --证件编号                
                                   ,t.GDZT             AS GDZT                                --股东状态                
                                   ,t.ZHLB             AS GDZHLB                              --股东账户类别            
                                   ,t.GDLB             AS GDLB                                --股东类别                
                                   ,t.SBJB             AS GDSBJBDM                            --股东帐户申报级别代码    
                                   ,t.KHRQ             AS KHRQ                                --开户日期                
                                   ,t.XHRQ             AS XHRQ                                --销户日期                
                                   ,LEAST(NVL(t.SCJYRQ,99999999),NVL(a3.SCJYRQ,99999999))           AS SCJYRQ                              --首次交易日期            
                                   ,t.QSRQ             AS QSRQ                                --签署日期                
                                   ,t.SXRQ             AS SXRQ                                --生效日期                
                                   ,t.ZZHBZ            AS GDZZHBZ                             --股东主账户标志                                      								              
                                   ,CAST(t.GDZDSX AS DECIMAL(38,0))     AS GDZDSX                              --股东指定属性       
                                   ,CAST(t.GDKZSX AS DECIMAL(38,0))		AS GDKZSX                              --股东控制属性
								   ,t.GDZDXW           AS GDZDXW                              --股东指定席位            
                                   ,t.BPGDH            AS BPGDH                               --报盘股东号              
                                   ,t.SYXXBZ           AS SYXXBZ                              --使用信息标志            
                                   ,t.YWXT             AS YWXT                                --业务系统                
                                   ,t.YWZH             AS YWZH                                --业务账号                
                                   ,a1.KHQZ            AS KHQZ                                --客户群组                
                                   ,a1.JSLX            AS ZJJSLX                              --交易资金结算类型        
                                   ,a1.JSJG            AS JSJG                                --结算机构                
                                   ,a1.JSZH            AS JSZH                                --结算帐户                
                                   ,a1.ZHGLJG          AS ZHGLJG                              --帐户管理机构            
                                   ,a1.JYFW            AS JYFW                                --交易范围                
                                   ,a1.GDDJRQ          AS GDDJRQ                              --股东登记日期            
                                   ,a1.FWXM            AS FWXM                                --服务项目                
                                   ,a1.ZHSZ            AS ZHSZ                                --帐户市值                
                                   ,a2.BGSSCJYRQ       AS BGSSCJYRQ                           --本公司的首次交易日期          
                                   ,'YGT_GT'           AS XTBS 
 FROM 			EDW_PROD.T_EDW_T02_TGDH_TEMP	           t
 LEFT JOIN (
              SELECT    t.JYS             AS JYS
			           ,t.GDH             AS GDH
					   ,t.KHQZ            AS KHQZ
					   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) AS JSLX
					   ,t.JSJG            AS JSJG
					   ,t.JSZH            AS JSZH
					   ,t.ZHGLJG          AS ZHGLJG
					   ,CAST(CASE WHEN t.JYS = 'HK' AND t.JYFW = 1 
								  THEN '201' 
								  ELSE CAST(t.JYFW AS VARCHAR(20))  
								  END AS VARCHAR(20)) AS JYFW            
					   ,t.GDDJRQ           AS GDDJRQ
					   ,t.FWXM             AS FWXM
					   ,t.ZHSZ             AS ZHSZ
			 FROM  JZJYCX.DATACENTER_TGDH t
             LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1
             ON             t1.DMLX = 'ZJJSLX'
             AND            t1.YXT = 'JZJY'
             AND            t1.YDM = CAST(t.JSLX AS VARCHAR(20))
             LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
             ON             t2.DMLX = 'GDJYQX'
             AND            t2.YXT = 'JZJY'
             AND            t2.YDM = CAST(t.JYFW AS VARCHAR(20)) 
             WHERE t.DT = '%d{yyyyMMdd}'  
			 UNION ALL
        	 SELECT    t.JYS             AS JYS
			           ,t.GDH             AS GDH
					   ,t.KHQZ            AS KHQZ
					   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) ) AS JSLX
					   ,t.JSJG            AS JSJG
					   ,t.JSZH            AS JSZH
					   ,t.ZHGLJG          AS ZHGLJG
					   ,CAST(CASE WHEN t.JYS = 'HK' AND t.JYFW = 1 
								  THEN '201' 
								  ELSE CAST(t.JYFW AS VARCHAR(20))  
								  END AS VARCHAR(20)) AS JYFW            
					   ,t.GDDJRQ           AS GDDJRQ
					   ,t.FWXM             AS FWXM
					   ,t.ZHSZ             AS ZHSZ
			 FROM  			RZRQCX.DATACENTER_TGDH t
             LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1
             ON             t1.DMLX = 'ZJJSLX'
             AND            t1.YXT = 'RZRQ'
             AND            t1.YDM = CAST(t.JSLX AS VARCHAR(20))
             LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
             ON             t2.DMLX = 'GDJYQX'
             AND            t2.YXT = 'RZRQ'
             AND            t2.YDM = CAST(t.JYFW AS VARCHAR(20)) 
             WHERE t.DT = '%d{yyyyMMdd}'  		 
             )                                        a1
 ON  		t.JYS = a1.JYS
 AND 		t.GDH = a1.GDH
 LEFT JOIN ( SELECT   KHH,gdh,CAST(min(CJRQ) AS STRING) AS BGSSCJYRQ 
             FROM     JZJYCX.DATACENTER_TJGMXLS 
	         WHERE    WTLB IN (1,2,57,58,59,60) 
	         AND     (ZQLB LIKE 'A%' OR  ZQLB LIKE 'B%' OR  ZQLB LIKE 'C%' OR ZQLB LIKE 'G%')
	         GROUP BY KHH,gdh
	         UNION ALL 
	         SELECT    	
						 KHH
						,gdh
						,CAST(min(CJRQ) AS STRING) AS BGSSCJYRQ 
			 FROM      RZRQCX.DATACENTER_TJGMXLS   t
			 WHERE     WTLB IN (1,2,57,58,59,60,61,62,63,64) 
	         AND (ZQLB LIKE 'A%' OR  ZQLB LIKE 'B%' OR  ZQLB LIKE 'C%' OR ZQLB LIKE 'G%')
	         GROUP BY KHH,gdh
             )                                          a2
 ON 		t.KHH = a2.KHH
 AND 		t.GDH = a2.GDH
 LEFT JOIN (SELECT a.KHH ,MIN(b.SCJYRQ) as SCJYRQ
            FROM (SELECT ZJLB,ZJBH,KHH FROM YGTCX.CIF_TKHXX WHERE DT = '20200526' )   a
            INNER JOIN (SELECT ZJLB,ZJBH,MIN(SCJYRQ) AS SCJYRQ
            FROM YGTCX.CIF_TZD_GDCXJG
            WHERE DT = '20200526'
            AND NVL(SCJYRQ,0) > 0
            GROUP BY ZJLB,ZJBH
		     )   b
            ON  a.ZJLB = b.ZJLB
            AND a.ZJBH = b.ZJBH
            GROUP BY a.KHH
			)  a3
ON   t.KHH = a3.KHH
  ;
 ----------------------------插入CIF系统的数据结束------------------
 ----------------------------插入结束---------------------------------
 
 ------------------------删除临时表--------------------------------
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T02_TGDH_TEMP;
 -----------------------删除结束----------------------------------
 ----------------------删除昨天的数据-----------------------------
 
----------插入数据结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TGDH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TGDH; 
--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:程序入口表                                                                           */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  

------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T05_OS_WFENTRY
(
                                    ID               --ID	    
                                   ,NAME             --名称	
                                   ,STATE            --状态	
                                   ,INITIATOR        --发起人	
                                   ,INIT_DATE        --发起日期
                                   ,SUBJECT          --主题	
                                   ,PRIORITY         --优先级	
								   ,XTBS         
) 
PARTITION( bus_date)
SELECT 
                                    t.ID             as ID            --ID	    
                                   ,t.NAME           as NAME          --角色类型
                                   ,t.STATE          as STATE         --角色名称
                                   ,t.INITIATOR      as INITIATOR     --目录	
                                   ,t.INIT_DATE      as INIT_DATE     --角色编码
                                   ,t.SUBJECT        as SUBJECT       --隶属部门
								   ,t.PRIORITY       as PRIORITY 
                                   ,'YGT'		     as XTBS
                                   ,CAST(CASE WHEN a1.NAT_DT = a1.TRD_DT
							        THEN a1.TRD_DT
								    WHEN a1.NAT_DT <> a1.TRD_DT
							        THEN a2.TRD_DT
								    ELSE CAST(CONCAT(SUBSTR(t.INIT_DATE,1,4),SUBSTR(t.INIT_DATE,6,2),SUBSTR(t.INIT_DATE,9,2)) as INT)
                                    END AS INT) as BUS_DATE								   
 FROM 		     YGTCX.CIF_OS_WFENTRY 				            t
 LEFT JOIN      EDW_PROD.T_EDW_T99_TRD_DATE  a1
 ON             CAST(CONCAT(SUBSTR(t.INIT_DATE,1,4),SUBSTR(t.INIT_DATE,6,2),SUBSTR(t.INIT_DATE,9,2)) as INT) = a1.NAT_DT
 AND            a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN      EDW_PROD.T_EDW_T99_TRD_DATE    a2
 ON             a2.NAT_DT = a2.TRD_DT
 AND            a2.BUS_DATE = %d{yyyyMMdd}
 AND            a1.TRD_DT = a2.LST_TRD_D
 WHERE           t.DT = '%d{yyyyMMdd}'
 UNION ALL 
 SELECT 
                                    t.ID             as ID            --ID	    
                                   ,t.NAME           as NAME          --角色类型
                                   ,t.STATE          as STATE         --角色名称
                                   ,t.INITIATOR      as INITIATOR     --目录	
                                   ,t.INIT_DATE      as INIT_DATE     --角色编码
                                   ,t.SUBJECT        as SUBJECT       --隶属部门
								   ,t.PRIORITY       as PRIORITY 
                                   ,'YGT'		     as XTBS
                                   ,CAST(CASE WHEN a1.NAT_DT = a1.TRD_DT
							        THEN a1.TRD_DT
								    WHEN a1.NAT_DT <> a1.TRD_DT
							        THEN a2.TRD_DT
								    ELSE CAST(CONCAT(SUBSTR(t.INIT_DATE,1,4),SUBSTR(t.INIT_DATE,6,2),SUBSTR(t.INIT_DATE,9,2)) as INT)
                                    END AS INT) as BUS_DATE								   
 FROM 		     YGTCX.CIF_OS_WFENTRY 				            t
 LEFT JOIN      EDW_PROD.T_EDW_T99_TRD_DATE  a1
 ON             CAST(CONCAT(SUBSTR(t.INIT_DATE,1,4),SUBSTR(t.INIT_DATE,6,2),SUBSTR(t.INIT_DATE,9,2)) as INT) = a1.NAT_DT
 AND            a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN      EDW_PROD.T_EDW_T99_TRD_DATE    a2
 ON             a2.NAT_DT = a2.TRD_DT
 AND            a2.BUS_DATE = %d{yyyyMMdd}
 AND            a1.TRD_DT = a2.LST_TRD_D
 WHERE           EXISTS (SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE a
                         WHERE a.BUS_DATE = %d{yyyyMMdd}
						 AND   a.TRD_DT = %d{yyyyMMdd}
						 AND   CAST(t.DT as INT) = a.LST_TRD_D
                         )
 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_OS_WFENTRY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_OS_WFENTRY;
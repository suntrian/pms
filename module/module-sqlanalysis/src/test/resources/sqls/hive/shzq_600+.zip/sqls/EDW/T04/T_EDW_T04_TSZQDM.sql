--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:退市证券代码表                                                                       */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2017-04-10                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T04_TSZQDM ;
 ---A 股1 B 股 2 权证 3 债券4 基金5 三板 6 港股7 场外基金 9科创板
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_AG_TEMP;
 CREATE TABLE EDW_PROD.T_EDW_T04_TSZQDM_AG_TEMP as
 SELECT     
             b.SECUCODE as ZQDM
			 ,a.SECUMARKET as SC
            ,MAX(CAST(CASE WHEN CHANGETYPE = 1
                  THEN CONCAt(substr(CHANGEDATE,1,4),substr(CHANGEDATE,6,2),substr(CHANGEDATE,9,2) )
                  END as INT))   as SSRQ
			,MIN(CAST(CASE WHEN b.SECUCODE in ('600747','600074')
                           THEN '99999999'
                           WHEN CHANGETYPE = 4
			               THEN EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(CHANGEDATE,1,4),substr(CHANGEDATE,6,2),substr(CHANGEDATE,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,30) 
				           WHEN CHANGETYPE = 5
				           THEN EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(CHANGEDATE,1,4),substr(CHANGEDATE,6,2),substr(CHANGEDATE,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,30) 
				           ELSE '99999999'
				           END as INT))   as TSRQ
 FROM        FUNDEXT.DBO_LC_LISTSTATUS  a
 LEFT JOIN   FUNDEXT.DBO_SECUMAIN    b
 ON          a.INNERCODE = b.INNERCODE
 --AND         a.SECUMARKET = b.SECUMARKET
 AND         b.DT = '%d{yyyyMMdd}'
 LEFT JOIN   (SELECT EXG as JYS,sec_cd_pfx as ZQDMQD 
              FROM   DDW_PROD.T_DDW_CFG_SEC_TRD_CL  
			  WHERE sec_cl_cd IN ('001','002','003','004')
			  GROUP BY JYS,ZQDMQD 
			  )                           c
 ON         ((b.SECUMARKET = 83 AND c.JYS = 'SH' AND SUBSTR(b.SECUCODE,1,3) = c.ZQDMQD)
            OR (b.SECUMARKET = 90 AND c.JYS = 'SZ' AND SUBSTR(b.SECUCODE,1,3) = c.ZQDMQD)
			)
 WHERE       a.DT = '%d{yyyyMMdd}'
 AND         b.SECUMARKET IN (83,90)
 AND         c.ZQDMQD IS NOT NULL
 GROUP BY ZQDM,SC
 ;
 
 
 
 
 -------
 -----创建B股的上市和退市的临时,表行情表中(zqdm=000000无用代码)---
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_BG_TEMP;
 CREATE TABLE EDW_PROD.T_EDW_T04_TSZQDM_BG_TEMP as
 SELECT t.ZQDM,t.SC,t.SSRQ,CASE WHEN t.ZQDM IN ('900935','900950')
                           THEN 2018010
                           WHEN t.SSRQ < t.TSRQ
                           THEN t.TSRQ
						   ELSE 99999999
						   END as TSRQ
  FROM 					                             
 (SELECT     
             b.SECUCODE as ZQDM
			 ,a.SECUMARKET as SC
            ,MAX(CAST(CASE WHEN CHANGETYPE = 1
                  THEN CONCAt(substr(CHANGEDATE,1,4),substr(CHANGEDATE,6,2),substr(CHANGEDATE,9,2) ) 
                  END as INT))   as SSRQ
			,MIN(CAST(CASE WHEN CHANGETYPE = 4
			      THEN EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(CHANGEDATE,1,4),substr(CHANGEDATE,6,2),substr(CHANGEDATE,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,10)
				  WHEN CHANGETYPE = 5
				  THEN EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(CHANGEDATE,1,4),substr(CHANGEDATE,6,2),substr(CHANGEDATE,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,10)
				  ELSE '99999999'
				  END as INT))   as TSRQ
 FROM        FUNDEXT.DBO_LC_LISTSTATUS  a
 LEFT JOIN   FUNDEXT.DBO_SECUMAIN    b
 ON          a.INNERCODE = b.INNERCODE
 --AND         a.SECUMARKET = b.SECUMARKET
 AND         b.DT = '%d{yyyyMMdd}'
 LEFT JOIN   (SELECT EXG as JYS,sec_cd_pfx as ZQDMQD 
              FROM   DDW_PROD.T_DDW_CFG_SEC_TRD_CL  
			  WHERE sec_cl_cd IN ('005','063')
			  GROUP BY JYS,ZQDMQD 
			  )                           c
 ON         ((b.SECUMARKET = 83 AND c.JYS = 'HB' AND SUBSTR(b.SECUCODE,1,3) = c.ZQDMQD)
            OR (b.SECUMARKET = 90 AND c.JYS = 'SB' AND SUBSTR(b.SECUCODE,1,3) = c.ZQDMQD)
			)
 WHERE       a.DT = '%d{yyyyMMdd}'
 AND         b.INNERCODE IS NOT NULL
 AND         b.SECUMARKET IN (83,90)
 AND         c.ZQDMQD IS NOT NULL
 GROUP BY    ZQDM,SC
 )                        t
 ;
 ------权证---
  DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_QZ_TEMP;
 CREATE TABLE EDW_PROD.T_EDW_T04_TSZQDM_QZ_TEMP 
 as SELECT  b.SECUCODE  as ZQDM
            ,c.EXG as SC
			,CAST(CONCAt(substr(DurationFrom,1,4),substr(DurationFrom,6,2),substr(DurationFrom,9,2) ) as INT) as SSRQ 
            ,CAST(CONCAt(substr(DurationTo,1,4),substr(DurationTo,6,2),substr(DurationTo,9,2) ) as INT) as TSRQ 
  FROM      FUNDEXT.DBO_LC_WarrantSummary      a
  LEFT JOIN FUNDEXT.DBO_SECUMAIN               b
  ON        a.INNERCODE = b.INNERCODE
  AND       a.DT = b.DT
   LEFT JOIN      (SELECT  	SEC_CD_PFX,EXG 
                 FROM    DDW_PROD.T_DDW_CFG_SEC 
			     WHERE STK_CGY = '权证'
			     GROUP BY SEC_CD_PFX,EXG 
				)                               c
  ON          (SUBSTR(b.SECUCODE,1,3) = c.SEC_CD_PFX OR b.SECUCODE =  c.SEC_CD_PFX) 
 
			   			  
  WHERE     a.DT = '%d{yyyyMMdd}' 
  AND         c.EXG IS NOT NULL  ;
  
  
   
  
  
 
-----创建债券的上市和退市的临时,表行情表中()---
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_ZQ_TEMP;
 CREATE TABLE EDW_PROD.T_EDW_T04_TSZQDM_ZQ_TEMP 
 as SELECT    b.SECUCODE as ZQDM
              ,b.SECUMARKET as SC
			  ,CAST(CASE WHEN b.SECUCODE = '128053'
			             THEN '20190221'
						 WHEN b.SECUCODE = '128054'
			             THEN '20190225'
						 WHEN b.SECUCODE in ('128055','128056')
			             THEN '20190307'
						 WHEN b.SECUCODE = '128057'
			             THEN '20190312'
						 WHEN b.SECUCODE = '128058'
			             THEN '20190314'
						 WHEN b.SECUCODE = '128059'
			             THEN '20190319'
						 WHEN b.SECUCODE = '128061'
			             THEN '20190404'
						 WHEN b.SECUCODE = '128062'
			             THEN '20190411'
						 WHEN b.SECUCODE = '128064'
			             THEN '20190416'
						 WHEN b.SECUCODE = '128069'
			             THEN '20190701'
						 WHEN b.SECUCODE = '128071'
			             THEN '20190823'
					     WHEN b.SECUCODE = '128075'
			             THEN '20191011'
						 WHEN b.SECUCODE = '128097'
			             THEN '20200313'
						 WHEN b.SECUCODE = '123019' AND b.SECUMARKET = 90
						 THEN '20190306'
						 WHEN b.SECUCODE = '123020' AND b.SECUMARKET = 90
						 THEN '20190308'
						 WHEN b.SECUCODE = '123021' AND b.SECUMARKET = 90
						 THEN '20190313'
						 WHEN b.SECUCODE = '123022' AND b.SECUMARKET = 90
						 THEN '20190325'
						 WHEN b.SECUCODE = '127011' AND b.SECUMARKET = 90
						 THEN '20190318'
						 WHEN b.SECUCODE = '127012' AND b.SECUMARKET = 90
						 THEN '20190408'
						 WHEN b.SECUCODE = '127013' AND b.SECUMARKET = 90
						 THEN '20190423'
						 WHEN b.SECUCODE = '123026' AND b.SECUMARKET = 90
						 THEN '20190618'
						 WHEN b.SECUCODE = '123027' AND b.SECUMARKET = 90
						 THEN '20190619'
						 WHEN b.SECUCODE = '123028' AND b.SECUMARKET = 90
						 THEN '20190703'
						 WHEN b.SECUCODE = '139380' AND b.SECUMARKET = 90
						 THEN '20130101'
			             WHEN LENGTH(TRIM(NVL(e.Exchangeday,''))) > 0
		                 THEN CONCAt(substr(e.Exchangeday,1,4),substr(Exchangeday,6,2),substr(Exchangeday,9,2) )
				         WHEN LENGTH(TRIM(NVL(b.listeddate,''))) > 0
				         THEN CONCAt(substr(b.listeddate,1,4),substr(b.listeddate,6,2),substr(b.listeddate,9,2) )
				         ELSE  '99999999' 
				         END  as INT
					)  as SSRQ
               ,CASE WHEN b.SECUCODE = '136204'
			         THEN 99999999
					 WHEN b.SECUCODE = '136863'
			         THEN 99999999
					 WHEN b.SECUCODE = '120301'
			         THEN 99999999
					 WHEN b.SECUCODE = '122356'
			         THEN 99999999
                     WHEN b.SECUCODE = '122776'
                     THEN 99999999
                     WHEN b.SECUCODE = '114217'
                     THEN 99999999
			         WHEN c.MainCode IS NOT NULL
			         THEN GREATEST(CAST(EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(c.DelistDate,1,4),substr(c.DelistDate,6,2),substr(c.DelistDate,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,365) as INT),CAST(EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(c.EndDate,1,4),substr(c.EndDate,6,2),substr(c.EndDate,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,365) as INT))
                     WHEN  b.INNERCODE IS NOT NULL AND c.MainCode IS  NULL AND LENGTH(TRIM(NVL(b.DelistDate,''))) > 0
					 THEN  CAST(EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(b.DelistDate,1,4),substr(b.DelistDate,6,2),substr(b.DelistDate,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,365) as INT)
					 WHEN  c.MainCode IS  NULL AND LENGTH(TRIM(NVL(b.DelistDate,''))) = 0 AND LENGTH(TRIM(NVL(d.changedate,'')))> 0
					 THEN  CAST(EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(d.changedate,1,4),substr(d.changedate,6,2),substr(d.changedate,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,365) as INT)
					 ELSE  99999999
					 END   as TSRQ
	FROM  FUNDEXT.DBO_BOND_CODE        b  
	LEFT JOIN  FUNDEXT.DBO_BOND_BASICINFO   c
	ON         b.DT = c.DT
	AND        b.MainCode = c.MainCode
	AND        LENGTH(TRIM(NVL(c.DelistDate,''))) > 0
	LEFT JOIN  (SELECT INNERCODE
                     ,secumarket
					 ,MIN(changedate) as changedate 
			     FROM  FUNDEXT.DBO_LC_LISTSTATUS
			     WHERE secumarket in (83,90) 
			     and   changetype = 4 
			     and   dt = '%d{yyyyMMdd}'
			    GROUP BY INNERCODE,secumarket
			     )    d
	ON         b.INNERCODE = d.INNERCODE
  --  AND        a.secumarket = d.secumarket         
	LEFT JOIN FUNDEXT.DBO_BOND_CONBDISSUE    e
	ON          b.INNERCODE = e.INNERCODE
    AND         b.DT = e.DT
	LEFT JOIN   (SELECT EXG as JYS,sec_cd_pfx as ZQDMQD 
              FROM   DDW_PROD.T_DDW_CFG_SEC_TRD_CL  
			  WHERE sec_cl_cd BETWEEN '017' AND '053'
			  GROUP BY JYS,ZQDMQD 
			  )                           f
  ON         ((b.SECUMARKET = 83 AND f.JYS = 'SH' AND SUBSTR(b.SECUCODE,1,3) = f.ZQDMQD )
            OR (b.SECUMARKET = 90 AND f.JYS = 'SZ' AND SUBSTR(b.SECUCODE,1,3) = f.ZQDMQD )
			) 
	WHERE b.DT = '%d{yyyyMMdd}'  
	AND    f.ZQDMQD IS NOT NULL
	AND    ((b.SECUMARKET = 90 AND SUBSTR(b.SECUCODE,1,3) < > '112' ) OR  b.SECUMARKET = 83)
   UNION ALL			
   SELECT    a.SECUCODE as ZQDM
              ,a.SECUMARKET as SC
			  ,CAST(CASE WHEN LENGTH(TRIM(NVL(e.Exchangeday,''))) > 0 
		                 THEN CONCAt(substr(e.Exchangeday,1,4),substr(Exchangeday,6,2),substr(Exchangeday,9,2) )
				         WHEN  LENGTH(TRIM(NVL(b.listeddate,''))) > 0
				         THEN CONCAt(substr(b.listeddate,1,4),substr(b.listeddate,6,2),substr(b.listeddate,9,2) )
				         ELSE '99999999' 
				         END  as INT
					)  as SSRQ
               ,CASE WHEN a.SECUCODE = '112048'
			         THEN 99999999
                     WHEN A.SECUCODE = '112110'
			         THEN 99999999
                     WHEN A.SECUCODE = '112243'
			         THEN 99999999
			         WHEN c.INNERCODE IS NOT NULL
			         THEN CAST(EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(c.regdate,1,4),substr(c.regdate,6,2),substr(c.regdate,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,0) as INT) 
                     WHEN  b.INNERCODE IS NOT NULL AND c.INNERCODE IS  NULL AND LENGTH(TRIM(NVL(b.DelistDate,''))) > 0
					 THEN  CAST(CONCAt(substr(b.DelistDate,1,4),substr(b.DelistDate,6,2),substr(b.DelistDate,9,2) ) as INT)
					 WHEN  c.INNERCODE IS  NULL AND LENGTH(TRIM(NVL(b.DelistDate,''))) = 0 AND LENGTH(TRIM(NVL(d.changedate,'')))> 0
					 THEN  CAST(CONCAt(substr(d.changedate,1,4),substr(d.changedate,6,2),substr(d.changedate,9,2) ) as INT)
					 ELSE  99999999
					 END   as TSRQ					
    FROM       FUNDEXT.DBO_SecuMain         a
	LEFT JOIN  FUNDEXT.DBO_BOND_CODE        b
	ON         a.INNERCODE = b.INNERCODE
	AND        a.DT = b.DT
	AND        a.secumarket = b.secumarket 
	LEFT JOIN (SELECT INNERCODE,MIN(regdate) as regdate,DT
               FROM  fundext.dbo_BOND_REDEMPTIONINFO 
               WHERE   dt = '%d{yyyyMMdd}'
			   AND     LENGTH(TRIM(NVL(regdate,''))) > 0
			   GROUP BY INNERCODE,DT)	c
	ON         a.DT = c.DT
	AND        a.INNERCODE = c.INNERCODE
	AND        LENGTH(TRIM(NVL(c.regdate,''))) > 0
	LEFT JOIN  (SELECT INNERCODE
                     ,secumarket
					 ,MIN(changedate) as changedate 
			     FROM  FUNDEXT.DBO_LC_LISTSTATUS
			     WHERE secumarket in (83,90) 
			     and   changetype = 4 
			     and   dt = '%d{yyyyMMdd}'
			    GROUP BY INNERCODE,secumarket
			     )    d
	ON         a.INNERCODE = d.INNERCODE
    AND        a.secumarket = d.secumarket         
	LEFT JOIN FUNDEXT.DBO_BOND_CONBDISSUE    e
	ON          a.INNERCODE = e.INNERCODE
    AND         a.DT = e.DT
	WHERE a.DT = '%d{yyyyMMdd}' 
	AND       (a.SECUMARKET = 90 AND SUBSTR(a.SECUCODE,1,3) = '112' ) 
    	 
 ;

-------场内基金退市----
--------场内基金退市----
   DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_JJ_TEMP;
 CREATE TABLE EDW_PROD.T_EDW_T04_TSZQDM_JJ_TEMP
 as  SELECT      a.SecurityCode as ZQDM
                 ,d.JYS      as SC
              ,CAST(CASE WHEN a.SecurityCode = '164302'
                         THEN '20170125'
                         WHEN a.SecurityCode = '160220J'
                         THEN '20140102'
						 WHEN a.SecurityCode = '159963'
						 THEN '20190306'
						 WHEN a.SecurityCode = '161912'
						 THEN '20190327'
						 WHEN a.SecurityCode = '163209'
						 THEN '20190530'
                    WHEN LENGTH(TRIM(NVL(a.listeddate,''))) > 0 AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) > 0
                    THEN LEAST(CONCAt(substr(a.listeddate,1,4),substr(a.listeddate,6,2),substr(a.listeddate,9,2) ),CONCAt(substr(b.applyopeningdate,1,4),substr(b.applyopeningdate,6,2),substr(b.applyopeningdate,9,2) ))
			        WHEN LENGTH(TRIM(NVL(a.listeddate,''))) > 0
                    THEN CONCAt(substr(a.listeddate,1,4),substr(a.listeddate,6,2),substr(a.listeddate,9,2) )
					WHEN LENGTH(TRIM(NVL(b.listeddate,''))) > 0 AND LENGTH(TRIM(NVL(a.listeddate,''))) = 0 
					THEN CONCAt(substr(b.listeddate,1,4),substr(b.listeddate,6,2),substr(b.listeddate,9,2) )
					WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) = 0
					AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) > 0 AND LENGTH(TRIM(NVL(b.redeemopeningdate,''))) = 0
					THEN CONCAt(substr(b.applyopeningdate,1,4),substr(b.applyopeningdate,6,2),substr(b.applyopeningdate,9,2) )
                    WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) = 0
					AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) = 0 AND LENGTH(TRIM(NVL(b.redeemopeningdate,''))) > 0
					THEN CONCAt(substr(b.redeemopeningdate,1,4),substr(b.redeemopeningdate,6,2),substr(b.redeemopeningdate,9,2) )	
                    WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) = 0
					AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) > 0 AND LENGTH(TRIM(NVL(b.redeemopeningdate,''))) > 0
					AND b.applyopeningdate > = b.redeemopeningdate
					THEN CONCAt(substr(b.redeemopeningdate,1,4),substr(b.redeemopeningdate,6,2),substr(b.redeemopeningdate,9,2) )
                     WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) = 0
					AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) > 0 AND LENGTH(TRIM(NVL(b.redeemopeningdate,''))) > 0
					AND b.applyopeningdate < b.redeemopeningdate
					THEN CONCAt(substr(b.applyopeningdate,1,4),substr(b.applyopeningdate,6,2),substr(b.applyopeningdate,9,2) )
                     WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) = 0
					AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) = 0 AND LENGTH(TRIM(NVL(b.redeemopeningdate,''))) = 0
                    AND LENGTH(TRIM(NVL(a.expiredate,''))) > 0
                    THEN CONCAt(substr(a.expiredate,1,4),substr(a.expiredate,6,2),substr(a.expiredate,9,2) )
					 WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) = 0
					AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) = 0 AND LENGTH(TRIM(NVL(b.redeemopeningdate,''))) = 0
                    AND LENGTH(TRIM(NVL(a.expiredate,''))) = 0 AND LENGTH(TRIM(NVL(c.changedate,''))) > 0 
                    THEN CONCAt(substr(c.changedate,1,4),substr(c.changedate,6,2),substr(c.changedate,9,2) )
                    ELSE '99999999'	
                    END as INT)    as SSRQ
              		,CAST(CASE WHEN a.SecurityCode = '150154'
                               THEN '99999999'
						       WHEN a.SecurityCode = '184689'
                               THEN '20140128'
						       WHEN a.SecurityCode = '150079'
                               THEN '20140428'
							   WHEN a.SecurityCode = '184690'
                               THEN '20140515'
							   WHEN a.SecurityCode = '150041'
                               THEN '20140526'
							   WHEN a.SecurityCode = '150038'
                               THEN '20140604'
							   WHEN a.SecurityCode = '150043'
                               THEN '20140611' 
							   WHEN a.SecurityCode = '150115'
                               THEN '20140630' 
							   WHEN a.SecurityCode = '184693'
                               THEN '20140704' 
							   WHEN a.SecurityCode = '184698'
                               THEN '20140801' 
							   WHEN a.SecurityCode = '150045'
                               THEN '20140902' 
							   WHEN a.SecurityCode = '150044'
                               THEN '20140902' 
							   WHEN a.SecurityCode = '184699'
                               THEN '20141204' 
							   WHEN a.SecurityCode = '150062'
                               THEN '20141216' 
							   WHEN a.SecurityCode = '150063'
                               THEN '20141216' 
							   WHEN a.SecurityCode = '150068'
                               THEN '20150217' 
							   WHEN a.SecurityCode = '150078'
                               THEN '20150310'
							   WHEN a.SecurityCode = '150069'
                               THEN '20150324'
							   WHEN a.SecurityCode = '150070'
                               THEN '20150324'
							   WHEN a.SecurityCode = '150072'
                               THEN '20150331'
							   WHEN a.SecurityCode = '150071'
                               THEN '20150331'
							   WHEN a.SecurityCode = '150132'
                               THEN '20150505'
							   WHEN a.SecurityCode = '150110'
                               THEN '20150513'
							   WHEN a.SecurityCode = '150098'
                               THEN '20150522'
							   WHEN a.SecurityCode = '150099'
                               THEN '20150522'
							   WHEN a.SecurityCode = '150080'
                               THEN '20150605'
							   WHEN a.SecurityCode = '150137'
                               THEN '20150727'
							   WHEN a.SecurityCode = '159917'
                               THEN '20150831'
							   WHEN a.SecurityCode = '150027'
                               THEN '20151204'
							   WHEN a.SecurityCode = '150128'
                               THEN '20160308'
							   WHEN a.SecurityCode = '150120'
                               THEN '20160426'
							   WHEN a.SecurityCode = '150035'
                               THEN '20160516'
							   WHEN a.SecurityCode = '150034'
                               THEN '20160516'
							   WHEN a.SecurityCode = '150088'
                               THEN '20160825'
							   WHEN a.SecurityCode = '150089'
                               THEN '20160825'
							   WHEN a.SecurityCode = '150154'
                               THEN '99999999'
							   WHEN a.SecurityCode = '150147'
                               THEN '20160920'
							   WHEN a.SecurityCode = '162308'
                               THEN '20170721'
							   WHEN a.SecurityCode = '164815'
                               THEN '20170816'
							   WHEN a.SecurityCode = '159921'
                               THEN '20180109'
							   WHEN a.SecurityCode = '150160'
                               THEN '20161213'
							   WHEN a.SecurityCode = '150161'
                               THEN '20170125'
							   WHEN a.SecurityCode = '150133'
                               THEN '20170421'
							   WHEN a.SecurityCode = '150134'
                               THEN '20170421'
							   WHEN a.SecurityCode = '150086'
                               THEN '20170509'
							   WHEN a.SecurityCode = '150141'
                               THEN '20170901'
							   WHEN a.SecurityCode = '150109'
                               THEN '20170913'
							   WHEN a.SecurityCode = '160809'
                               THEN '20180324'
							   WHEN a.SecurityCode = '184728'
                               THEN '20170110'
							   WHEN a.SecurityCode = '150154'
							   THEN '99999999'
                               WHEN a.SecurityCode in ('150256','150226','150225')
							   THEN '20200808'
						  WHEN LENGTH(TRIM(NVL(a.expiredate,''))) > 0
                          THEN EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(a.expiredate,1,4),substr(a.expiredate,6,2),substr(a.expiredate,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,365)	  
                          WHEN LENGTH(TRIM(NVL(a.expiredate,''))) = 0 AND LENGTH(TRIM(NVL(c.changedate,''))) > 0
						  THEN EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(c.changedate,1,4),substr(c.changedate,6,2),substr(c.changedate,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,365)					  
  						  ELSE '99999999'
                          END as INT) as TSRQ						  
 FROM        fundext.dbo_MF_FundArchives       a
 LEFT JOIN   FUNDEXT.DBO_MF_IssueAndListing    b
 ON          a.INNERCODE = b.INNERCODE
 AND         a.DT = b.DT 
 LEFT JOIN  (SELECT INNERCODE
					 ,MIN(changedate) as changedate 
			  FROM  FUNDEXT.DBO_LC_LISTSTATUS
			  WHERE    changetype IN (4,20) 
			  and   dt = '%d{yyyyMMdd}'
			  GROUP BY INNERCODE
			  ) c
 ON           a.INNERCODE = c.INNERCODE 
 LEFT JOIN   (SELECT EXG as JYS,sec_cd_pfx as ZQDMQD 
              FROM   DDW_PROD.T_DDW_CFG_SEC_TRD_CL  
			  WHERE sec_cl_cd BETWEEN '054' AND '062'
			  GROUP BY JYS,ZQDMQD 
			  )                         d
  ON        (SUBSTR(a.SecurityCode,1,3) = d.ZQDMQD OR CONCAT(SUBSTR(a.SecurityCode,1,3),SUBSTR(a.SecurityCode,6,1)) = d.ZQDMQD)
 WHERE      d.ZQDMQD IS NOT NULL   
 AND         a.DT = '%d{yyyyMMdd}';
 



-------创建三板的上市和退市时间-------
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_SB_TEMP;
 CREATE TABLE EDW_PROD.T_EDW_T04_TSZQDM_SB_TEMP as
 SELECT 
  t.ZQDM
 ,CASE WHEN T.ZQDM = '400066' THEN 19000101 ELSE NVL(T.SSRQ,99999999) END AS SSRQ
 ,CASE WHEN  t.ZQDM IN ('870755','835920','831437','831781','835855','430614','832065','834448','833794','831639','836889','831120','834444','834841','830968','832168','430237','430512','832243','430618','830937','832540','836238','832201','870585','839927','430312')
                           THEN 99999999
						   WHEN t.ZQDM = '833209'
	                       THEN 20170608
						   WHEN  t.ZQDM = '834265'
                           THEN  20170525
						   WHEN  t.ZQDM = '833344'
						   THEN  20170627 
						   WHEN  t.ZQDM = '835594'
						   THEN  20170525
                           WHEN  t.ZQDM = '831600'
                           THEN  20170628
                           WHEN  t.ZQDM = '430591'
                           THEN  20170815	
                           WHEN  t.ZQDM = '831329'
                           THEN  20170914
						   WHEN  t.ZQDM = '832675'
                           THEN  20170831
						   WHEN  t.ZQDM = '835998'
						   THEN  20171221
						   WHEN  t.ZQDM = '832801'
						   THEN  20171114
						   WHEN  t.zqdm = '836615'
						   THEN  20171109
						   WHEN  t.ZQDM = '836914'
						   THEN  20170907
						   WHEN  t.ZQDM = '833766'
						   THEN 20170919
						   WHEN  t.ZQDM = '834124'
						   THEN  20170921
						   WHEN  t.ZQDM = '832090'
						   THEN  20171121
						   WHEN  t.ZQDM IN ('830805','831458','832096')
						   THEN  20171207
						   WHEN  t.ZQDM IN ('832187')
						   THEN 20171214
						   WHEN t.ZQDM IN ('838824','834449')
						   THEN 20171226
						   WHEN t.ZQDM = '832639'
						   THEN 20171219
						   WHEN t.ZQDM IN ('834034','835780')
						   THEN 20171221
     				       WHEN  t.ZQDM IN ('831189','835994')
                           THEN  20170905 
                           WHEN t.ZQDM IN ('836298','833641','833761')
                           THEN 20180119
                           
						   WHEN t.SSRQ < t.TSRQ
                           THEN t.TSRQ
						   ELSE 99999999
						   END as TSRQ
					 ,t.SC as SC
  FROM 					                             
 (SELECT     
             b.SECUCODE as ZQDM
            ,MAX(CAST(CASE WHEN CHANGETYPE = 1
                  THEN CONCAt(substr(CHANGEDATE,1,4),substr(CHANGEDATE,6,2),substr(CHANGEDATE,9,2) ) 
                  WHEN a.INNERCODE IS NULL
				  THEN CONCAt(substr(listeddate,1,4),substr(listeddate,6,2),substr(listeddate,9,2) ) 
				  END as INT))   as SSRQ
			,MIN(CAST(CASE WHEN CHANGETYPE = 4
			      THEN EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(CHANGEDATE,1,4),substr(CHANGEDATE,6,2),substr(CHANGEDATE,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,365)
				  WHEN CHANGETYPE = 5
				  THEN EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(CHANGEDATE,1,4),substr(CHANGEDATE,6,2),substr(CHANGEDATE,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,365)
				  ELSE '99999999'
				  END as INT))   as TSRQ
		    ,c.JYS  as SC
 FROM        FUNDEXT.DBO_NQ_SECUMAIN    b 
 LEFT JOIN   FUNDEXT.DBO_LC_LISTSTATUS  a
 ON          a.INNERCODE = b.INNERCODE
 --AND         a.SECUMARKET = b.SECUMARKET
 AND         a.DT = '%d{yyyyMMdd}'
 LEFT JOIN   (SELECT EXG as JYS ,sec_cd_pfx as ZQDMQD 
              FROM   DDW_PROD.T_DDW_CFG_SEC_TRD_CL  
			  WHERE sec_cl_cd IN ('006','007','008')
			  GROUP BY JYS,ZQDMQD 
			  )                         c
 ON           SUBSTR(b.SECUCODE,1,3) = c.ZQDMQD
			  
 WHERE       b.DT = '%d{yyyyMMdd}'
 AND         b.INNERCODE IS NOT NULL
 AND         b.SECUMARKET = 81
 AND         c.ZQDMQD IS NOT NULL
 GROUP BY    ZQDM,SC
 )                 t
 ;
 
 ---创建港股退市上市临时表(以4开头的去除)--
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_GB_TEMP;
 CREATE TABLE EDW_PROD.T_EDW_T04_TSZQDM_GB_TEMP as				                             
   SELECT     
             a.SECUCODE as ZQDM
            ,CASE WHEN a.SECUCODE = '03699' 
			      THEN 20140101
				  WHEN a.SECUCODE = '01833'
			      THEN 20140101
			      ELSE CAST(CONCAt(substr(a.listeddate,1,4),substr(a.listeddate,6,2),substr(a.listeddate,9,2) ) as INT)
				  END as SSRQ
			,CAST(CASE WHEN a.SECUCODE = '01833'
			      THEN '99999999'
				  WHEN a.SECUCODE = '00566'
			      THEN '99999999'
                  WHEN a.SECUCODE = '06863'
                  THEN '99999999'
                  WHEN a.SECUCODE = '03823'
                  THEN '99999999'
                  WHEN a.SECUCODE = '01619'
                  THEN '99999999'
			      WHEN listedstate = 5	AND LENGTH(TRIM(NVL(a.delistingdate,''))) > 0		     
			      THEN CONCAt(substr(a.XGRQ,1,4),substr(a.xgrq,6,2),substr(a.xgrq,9,2) )				
				  ELSE '99999999'
				  END as INT)   as TSRQ
            ,b.JYS as SC
 FROM       FUNDEXT.DBO_HK_SECUMAIN    a
  LEFT JOIN   (SELECT EXG as JYS,sec_cd_pfx as ZQDMQD 
              FROM   DDW_PROD.T_DDW_CFG_SEC_TRD_CL  
			  WHERE sec_cl_cd IN ('015','016')
			  GROUP BY JYS,ZQDMQD
			  )                         b
 ON           SUBSTR(a.SECUCODE,1,3) = b.ZQDMQD
 WHERE       a.DT = '%d{yyyyMMdd}'
 AND         a.SECUMARKET = 72
 AND         LENGTH(TRIM(NVL(a.listeddate,'')))>0
 AND         SUBSTR(a.SECUCODE,1,1) = '0' 
 ;
 
 --------场外基金退市
  DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_CWJJ_TEMP;
 CREATE TABLE EDW_PROD.T_EDW_T04_TSZQDM_CWJJ_TEMP
 as  SELECT      a.SecurityCode as ZQDM
              ,CAST(CASE WHEN a.SecurityCode = '160322'
			         THEN '20170105'
					 WHEN a.SecurityCode IN ('160220','582003','160220J')
					 THEN '20140102'
					WHEN a.SecurityCode = '000189'
					THEN '20140101'
					WHEN a.SecurityCode = '952024'
					THEN '20130101'
			        WHEN LENGTH(TRIM(NVL(a.listeddate,''))) > 0 AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) > 0
                    THEN LEAST(CONCAt(substr(a.listeddate,1,4),substr(a.listeddate,6,2),substr(a.listeddate,9,2) ),CONCAt(substr(b.applyopeningdate,1,4),substr(b.applyopeningdate,6,2),substr(b.applyopeningdate,9,2) ))
                    WHEN LENGTH(TRIM(NVL(a.listeddate,''))) > 0
                    THEN CONCAt(substr(a.listeddate,1,4),substr(a.listeddate,6,2),substr(a.listeddate,9,2) )
					WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) > 0
					THEN CONCAt(substr(b.listeddate,1,4),substr(b.listeddate,6,2),substr(b.listeddate,9,2) )
					WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) = 0
					AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) > 0 AND LENGTH(TRIM(NVL(b.redeemopeningdate,''))) = 0
					THEN CONCAt(substr(b.applyopeningdate,1,4),substr(b.applyopeningdate,6,2),substr(b.applyopeningdate,9,2) )
                    WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) = 0
					AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) = 0 AND LENGTH(TRIM(NVL(b.redeemopeningdate,''))) > 0
					THEN CONCAt(substr(b.redeemopeningdate,1,4),substr(b.redeemopeningdate,6,2),substr(b.redeemopeningdate,9,2) )	
                    WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) = 0
					AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) > 0 AND LENGTH(TRIM(NVL(b.redeemopeningdate,''))) > 0
					AND b.applyopeningdate > = b.redeemopeningdate
					THEN CONCAt(substr(b.redeemopeningdate,1,4),substr(b.redeemopeningdate,6,2),substr(b.redeemopeningdate,9,2) )
                     WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) = 0
					AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) > 0 AND LENGTH(TRIM(NVL(b.redeemopeningdate,''))) > 0
					AND b.applyopeningdate < b.redeemopeningdate
					THEN CONCAt(substr(b.applyopeningdate,1,4),substr(b.applyopeningdate,6,2),substr(b.applyopeningdate,9,2) )
                     WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) = 0
					AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) = 0 AND LENGTH(TRIM(NVL(b.redeemopeningdate,''))) = 0
                    AND LENGTH(TRIM(NVL(a.expiredate,''))) > 0
                    THEN CONCAt(substr(a.expiredate,1,4),substr(a.expiredate,6,2),substr(a.expiredate,9,2) )
					 WHEN LENGTH(TRIM(NVL(a.listeddate,''))) = 0 AND LENGTH(TRIM(NVL(b.listeddate,''))) = 0
					AND LENGTH(TRIM(NVL(b.applyopeningdate,''))) = 0 AND LENGTH(TRIM(NVL(b.redeemopeningdate,''))) = 0
                    AND LENGTH(TRIM(NVL(a.expiredate,''))) = 0 AND LENGTH(TRIM(NVL(c.changedate,''))) > 0 
                    THEN CONCAt(substr(c.changedate,1,4),substr(c.changedate,6,2),substr(c.changedate,9,2) )
                    ELSE '99999999'	
                    END as INT)    as SSRQ
              		,CAST(CASE WHEN a.SecurityCode = '150154'
                               THEN '99999999'
						       WHEN a.SecurityCode = '184689'
                               THEN '20140128'
						       WHEN a.SecurityCode = '150079'
                               THEN '20140428'
							   WHEN a.SecurityCode = '184690'
                               THEN '20140515'
							   WHEN a.SecurityCode = '150041'
                               THEN '20140526'
							   WHEN a.SecurityCode = '150038'
                               THEN '20140604'
							   WHEN a.SecurityCode = '150043'
                               THEN '20140611' 
							   WHEN a.SecurityCode = '150115'
                               THEN '20140630' 
							   WHEN a.SecurityCode = '184693'
                               THEN '20140704' 
							   WHEN a.SecurityCode = '184698'
                               THEN '20140801' 
							   WHEN a.SecurityCode = '150154'
                               THEN '99999999'
							   WHEN a.SecurityCode = '150045'
                               THEN '20140902'
    						   WHEN a.SecurityCode = '184722'
                               THEN '20170829'   
							   WHEN a.SecurityCode = '150044'
                               THEN '20140902' 
							   WHEN a.SecurityCode = '184699'
                               THEN '20141204' 
							   WHEN a.SecurityCode = '150062'
                               THEN '20141216' 
							   WHEN a.SecurityCode = '150063'
                               THEN '20141216' 
							   WHEN a.SecurityCode = '150068'
                               THEN '20150217' 
							   WHEN a.SecurityCode = '150078'
                               THEN '20150310'
							   WHEN a.SecurityCode = '150069'
                               THEN '20150324'
							   WHEN a.SecurityCode = '150070'
                               THEN '20150324'
							   WHEN a.SecurityCode = '150072'
                               THEN '20150331'
							   WHEN a.SecurityCode = '150154'
							   THEN '99999999'
							   WHEN a.SecurityCode = '150071'
                               THEN '20150331'
							   WHEN a.SecurityCode = '150132'
                               THEN '20150505'
							   WHEN a.SecurityCode = '150110'
                               THEN '20150513'
							   WHEN a.SecurityCode = '150098'
                               THEN '20150522'
							   WHEN a.SecurityCode = '150099'
                               THEN '20150522'
							   WHEN a.SecurityCode = '150080'
                               THEN '20150605'
							   WHEN a.SecurityCode = '150137'
                               THEN '20150727'
							   WHEN a.SecurityCode = '159917'
                               THEN '20150831'
							   WHEN a.SecurityCode = '150027'
                               THEN '20151204'
							   WHEN a.SecurityCode = '150128'
                               THEN '20160308'
							   WHEN a.SecurityCode = '162308'
                               THEN '20170721'
							   WHEN a.SecurityCode = '164815'
                               THEN '20170816'
							   WHEN a.SecurityCode = '159921'
                               THEN '20180109'
							   WHEN a.SecurityCode = '150120'
                               THEN '20160426'
							   WHEN a.SecurityCode = '150035'
                               THEN '20160516'
							   WHEN a.SecurityCode = '150034'
                               THEN '20160516'
							   WHEN a.SecurityCode = '150088'
                               THEN '20160825'
							   WHEN a.SecurityCode = '150089'
                               THEN '20160825'
							   WHEN a.SecurityCode = '150147'
                               THEN '20160920'
							   WHEN a.SecurityCode = '150160'
                               THEN '20161213'
							   WHEN a.SecurityCode = '150161'
                               THEN '20170125'
							   WHEN a.SecurityCode = '150133'
                               THEN '20170421'
							   WHEN a.SecurityCode = '150134'
                               THEN '20170421'
							   WHEN a.SecurityCode = '150086'
                               THEN '20170509'
							   WHEN a.SecurityCode = '150141'
                               THEN '20170901'
							   WHEN a.SecurityCode = '150109'
                               THEN '20170913'
							   WHEN a.SecurityCode = '160809'
                               THEN '20180324'
							   WHEN a.SecurityCode = '184728'
                               THEN '20170110'
						  WHEN LENGTH(TRIM(NVL(a.expiredate,''))) > 0
                          THEN EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(a.expiredate,1,4),substr(a.expiredate,6,2),substr(a.expiredate,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,365)	  
                          WHEN LENGTH(TRIM(NVL(a.expiredate,''))) = 0 AND LENGTH(TRIM(NVL(c.changedate,''))) > 0
						  THEN EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(c.changedate,1,4),substr(c.changedate,6,2),substr(c.changedate,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,365)					  
  						  ELSE '99999999'
                          END as INT) as TSRQ							  
 FROM        fundext.dbo_MF_FundArchives       a
 LEFT JOIN   FUNDEXT.DBO_MF_IssueAndListing    b
 ON          a.INNERCODE = b.INNERCODE
 AND         a.DT = b.DT 
 LEFT JOIN  (SELECT INNERCODE
					 ,MIN(changedate) as changedate 
			  FROM  FUNDEXT.DBO_LC_LISTSTATUS
			  WHERE    changetype IN (4,20) 
			  and   dt = '%d{yyyyMMdd}'
			  GROUP BY INNERCODE
			  ) c
 ON           a.INNERCODE = c.INNERCODE 
 WHERE         a.DT = '%d{yyyyMMdd}'
 
 ;
---------科创板
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_KC_TEMP;
 CREATE TABLE EDW_PROD.T_EDW_T04_TSZQDM_KC_TEMP as
 SELECT     
             b.SECUCODE as ZQDM
			 ,b.SECUMARKET as SC
            ,MAX(CAST(CASE WHEN CHANGETYPE = 1
                  THEN CONCAt(substr(CHANGEDATE,1,4),substr(CHANGEDATE,6,2),substr(CHANGEDATE,9,2) )
				  ELSE '99999999'
                  END as INT))   as SSRQ
			,MIN(CAST(CASE WHEN CHANGETYPE = 4
			      THEN EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(CHANGEDATE,1,4),substr(CHANGEDATE,6,2),substr(CHANGEDATE,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,30) 
				  WHEN CHANGETYPE = 5
				  THEN EDW_PROD.G_DATE_ADD_STR(CONCAt(substr(CHANGEDATE,1,4),substr(CHANGEDATE,6,2),substr(CHANGEDATE,9,2) ),'yyyyMMdd','yyyyMMdd',0,0,30) 
				  ELSE '99999999'
				  END as INT))   as TSRQ
 FROM        FUNDEXT.DBO_SECUMAIN   b
 LEFT JOIN   FUNDEXT.DBO_LC_STIBLISTSTATUS    a
 ON          a.INNERCODE = b.INNERCODE
 --AND         a.SECUMARKET = b.SECUMARKET
 AND         a.DT = '%d{yyyyMMdd}'
 LEFT JOIN   (SELECT EXG as JYS,sec_cd_pfx as ZQDMQD 
              FROM   DDW_PROD.T_DDW_CFG_SEC_TRD_CL  
			  WHERE sec_cl_cd IN ('012','013')
			  GROUP BY JYS,ZQDMQD 
			  )                           c
 ON         (b.SECUMARKET = 83 AND c.JYS = 'SH' AND SUBSTR(b.SECUCODE,1,3) = c.ZQDMQD)
            
			
 WHERE       b.DT = '%d{yyyyMMdd}'
 AND         b.SECUMARKET IN (83)
 AND         c.ZQDMQD IS NOT NULL
 GROUP BY ZQDM,SC
 ;


---A 股1 B 股 2 权证 3 债券4 基金5 三板 6 港股7 场外基金8
 ----插入数据-----
 -------插入数据结束
 INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
 (               ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期 
                ,TSRQ          --退市日期                         
                ,CPLB           --产品类别								
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.ZQDM          as ZQDM          --证券代码
                                    ,CASE WHEN t.SC = 83
									      THEN 'SH'
										  ELSE 'SZ'
										  END      as JYS           --交易所
                                    ,t.SSRQ        as SSRQ          --上市日期 
                                    ,t.TSRQ        as TSRQ          --退市日期   
                                    ,1             as CPLB           --产品类别		                             
 FROM 		 EDW_PROD.T_EDW_T04_TSZQDM_AG_TEMP 		t ;
 
  INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
 (               ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期 
                ,TSRQ          --退市日期                         
                ,CPLB           --产品类别								
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.ZQDM          as ZQDM          --证券代码
                                    ,CASE WHEN t.SC = 83
									      THEN 'SH'
										  ELSE 'SZ'
										  END      as JYS           --交易所
                                    ,t.SSRQ        as SSRQ          --上市日期 
                                    ,t.TSRQ        as TSRQ          --退市日期   
                                    ,9             as CPLB           --产品类别		                             
 FROM 		 EDW_PROD.T_EDW_T04_TSZQDM_KC_TEMP 		t ;
 ---
  INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
 (               ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期 
                ,TSRQ          --退市日期                         
                ,CPLB           --产品类别								
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     '601313'          as ZQDM          --证券代码
                                    ,CASE WHEN t.SC = 83
									      THEN 'SH'
										  ELSE 'SZ'
										  END      as JYS           --交易所
                                    ,t.SSRQ        as SSRQ          --上市日期 
                                    ,t.TSRQ        as TSRQ          --退市日期   
                                    ,1             as CPLB           --产品类别		                             
 FROM 		 EDW_PROD.T_EDW_T04_TSZQDM_AG_TEMP 		t 
 WHERE t.ZQDM = '601360';
 -----
  INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
 (               ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期 
                ,TSRQ          --退市日期                         
                ,CPLB           --产品类别								
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.ZQDM          as ZQDM          --证券代码
                                    ,CASE WHEN t.SC = 83
									      THEN 'HB'
										  ELSE 'SB'
										  END      as JYS           --交易所
                                    ,t.SSRQ        as SSRQ          --上市日期 
                                    ,t.TSRQ        as TSRQ          --退市日期   
                                    ,2             as CPLB           --产品类别		                             
 FROM 		 EDW_PROD.T_EDW_T04_TSZQDM_BG_TEMP 		t
 ;
 -----
     INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
 (               ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期 
                ,TSRQ          --退市日期                         
                ,CPLB           --产品类别								
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.ZQDM          as ZQDM          --证券代码
                                    ,t.SC           as JYS           --交易所
                                    ,t.SSRQ        as SSRQ          --上市日期 
                                    ,t.TSRQ        as TSRQ          --退市日期   
                                    ,3             as CPLB           --产品类别		                             
 FROM 		 EDW_PROD.T_EDW_T04_TSZQDM_QZ_TEMP 		t
 ;
 ------
 INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
 (               ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期 
                ,TSRQ          --退市日期                         
                ,CPLB           --产品类别								
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.ZQDM          as ZQDM          --证券代码
                                    ,CASE WHEN t.SC = 83
									      THEN 'SH'
										  ELSE 'SZ'
										  END      as JYS           --交易所
                                    ,t.SSRQ        as SSRQ          --上市日期 
                                    ,t.TSRQ        as TSRQ          --退市日期   
                                    ,4             as CPLB           --产品类别		                             
 FROM 		 EDW_PROD.T_EDW_T04_TSZQDM_ZQ_TEMP 		t
 ;
----
  INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
 (               ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期 
                ,TSRQ          --退市日期                         
                ,CPLB           --产品类别								
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.ZQDM          as ZQDM          --证券代码
                                    ,t.SC          as JYS           --交易所
                                    ,t.SSRQ        as SSRQ          --上市日期 
                                    ,t.TSRQ        as TSRQ          --退市日期   
                                    ,5             as CPLB           --产品类别		                             
 FROM 		 EDW_PROD.T_EDW_T04_TSZQDM_JJ_TEMP 		t
 ;
 -----
   INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
 (               ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期 
                ,TSRQ          --退市日期                         
                ,CPLB           --产品类别								
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.ZQDM          as ZQDM          --证券代码
                                    ,t.SC            as JYS           --交易所
                                    ,t.SSRQ          as SSRQ          --上市日期 
                                    ,t.TSRQ          as TSRQ          --退市日期   
                                    ,6               as CPLB           --产品类别		                             
 FROM 		 EDW_PROD.T_EDW_T04_TSZQDM_SB_TEMP 		t
 ;
 
  INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
 (               ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期 
                ,TSRQ          --退市日期                         
                ,CPLB           --产品类别								
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.ZQDM          as ZQDM          --证券代码
                                    ,t.SC             as JYS           --交易所
                                    ,MIN(t.SSRQ)          as SSRQ          --上市日期 
                                    ,MAX(t.TSRQ)          as TSRQ          --退市日期   
                                    ,7               as CPLB           --产品类别		                             
 FROM 		 EDW_PROD.T_EDW_T04_TSZQDM_GB_TEMP 		t
 GROUP BY ZQDM,SC
 ;

    INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
 (               ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期 
                ,TSRQ          --退市日期                         
                ,CPLB           --产品类别								
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT                        
                                     t.ZQDM          as ZQDM          --证券代码
                                    ,'CWJJ'          as JYS           --交易所
                                    ,MIN(t.SSRQ)          as SSRQ          --上市日期 
                                    ,MAX(t.TSRQ)          as TSRQ          --退市日期   
                                    ,8               as CPLB           --产品类别		                             
 FROM 		 EDW_PROD.T_EDW_T04_TSZQDM_CWJJ_TEMP 		t
 GROUP BY ZQDM
 ;
 
--  INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
-- (               ZQDM          --证券代码
--				,JYS           --交易所
--			    ,SSRQ          --上市日期 
--                ,TSRQ          --退市日期                         
--                ,CPLB           --产品类别								
-- ) 
-- PARTITION( bus_date = %d{yyyyMMdd})values('139319','SZ',10000000,99999999,4) ;
--   INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
-- (               ZQDM          --证券代码
--				,JYS           --交易所
--			    ,SSRQ          --上市日期 
--                ,TSRQ          --退市日期                         
--                ,CPLB           --产品类别								
-- ) 
-- PARTITION( bus_date = %d{yyyyMMdd})values('139320','SZ',10000000,99999999,4) ;

DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_430662_TEMP1;
CREATE TABLE EDW_PROD.T_EDW_T04_TSZQDM_430662_TEMP1
AS
SELECT * FROM EDW_PROD.T_EDW_T04_TSZQDM WHERE 1 = 2
;

INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM_430662_TEMP1(ZQDM,JYS,SSRQ,TSRQ,CPLB,BUS_DATE)
VALUES('430662' AS ZQDM,'TA' AS JYS,19000101 AS SSRQ,99991231 AS TSRQ,6 AS CPLB,%d{yyyyMMdd} AS BUS_DATE)
;

INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM_430662_TEMP1(ZQDM,JYS,SSRQ,TSRQ,CPLB,BUS_DATE)
SELECT ZQDM,JYS,SSRQ,TSRQ,CPLB,BUS_DATE
FROM EDW_PROD.T_EDW_T04_TSZQDM
WHERE ZQDM = '430662' AND BUS_DATE = %d{yyyyMMdd}
;

DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_430662_TEMP2;
CREATE TABLE EDW_PROD.T_EDW_T04_TSZQDM_430662_TEMP2
AS
SELECT T1.ZQDM,T1.JYS,T1.SSRQ,T1.TSRQ,T1.CPLB,T2.CNT,T1.BUS_DATE
FROM EDW_PROD.T_EDW_T04_TSZQDM_430662_TEMP1 T1
CROSS JOIN
(
 SELECT COUNT(*) AS CNT FROM EDW_PROD.T_EDW_T04_TSZQDM_430662_TEMP1
) T2
;

INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
(                ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期 
                ,TSRQ          --退市日期                         
                ,CPLB          --产品类别								
)
PARTITION( bus_date = %d{yyyyMMdd})
SELECT           ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期 
                ,TSRQ          --退市日期                         
                ,CPLB          --产品类别
FROM EDW_PROD.T_EDW_T04_TSZQDM_430662_TEMP2
WHERE CNT = 1
;

----手工增加000022代码
INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
(                ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期
                ,TSRQ          --退市日期
                ,CPLB          --产品类别
                ,BUS_DATE
)
VALUES
(
 '000022'
,'SZ'
,20160101
,20190821
,1
,%d{yyyyMMdd}
)
;

----手工增加000043代码 by 20191216
INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
(                ZQDM          --证券代码
				,JYS           --交易所
			    ,SSRQ          --上市日期
                ,TSRQ          --退市日期
                ,CPLB          --产品类别
                ,BUS_DATE
)
VALUES
(
 '000043'
,'SZ'
,19940928
,99999999
,1
,%d{yyyyMMdd}
)
;
--
------手工增加400080代码 by 20200525
--INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
--(                ZQDM          --证券代码
--				,JYS           --交易所
--			    ,SSRQ          --上市日期
--                ,TSRQ          --退市日期
--                ,CPLB          --产品类别
--                ,BUS_DATE
--)
--VALUES
--(
-- '400080'
--,'TA'
--,20200522
--,99999999
--,6
--,%d{yyyyMMdd}
--)
--;
--
----手工增加400076代码 by 20200610
--INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
--(                ZQDM          --证券代码
--				,JYS           --交易所
--			    ,SSRQ          --上市日期
--                ,TSRQ          --退市日期
--                ,CPLB          --产品类别
--                ,BUS_DATE
--)
--VALUES
--(
-- '400076'
--,'TA'
--,20140101
--,99999999
--,6
--,%d{yyyyMMdd}
--)
--;

----手工增加400078代码 by 20200619
--INSERT INTO EDW_PROD.T_EDW_T04_TSZQDM
--(                ZQDM          --证券代码
--				,JYS           --交易所
--			    ,SSRQ          --上市日期
--                ,TSRQ          --退市日期
--                ,CPLB          --产品类别
--                ,BUS_DATE
--)
--VALUES
--(
-- '400078'
--,'TA'
--,20200619
--,99999999
--,6
--,%d{yyyyMMdd}
--)
--;


 ----删除临时表----
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_JJ_TEMP;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_ZQ_TEMP;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_GB_TEMP;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_SB_TEMP;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_BG_TEMP;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_AG_TEMP;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_QZ_TEMP;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_CWJJ_TEMP;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_430662_TEMP1;
 DROP TABLE IF EXISTS EDW_PROD.T_EDW_T04_TSZQDM_430662_TEMP2;
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TSZQDM',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
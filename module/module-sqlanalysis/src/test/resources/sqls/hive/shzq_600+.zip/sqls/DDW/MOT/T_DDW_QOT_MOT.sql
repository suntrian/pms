--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:监控行情表                                                                       */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-05-08                                                                        */ 
  
  ---ERR_CGY(0:系统和聚源的当天行情不一样1:系统的行情涨幅度超过11% 2:聚源的行情涨幅度超过11%) 
  ---115003代码已经退市了 
  ---基金净值表中的代码:371041,536068,370003,1A0017,328004,246021为私募基金取系统行情
  ----基金净值表中的代码:020022基金代码在聚源的INERCODE改变,系统行情没有错取系统
  ----基金净值表中的代码:040032 
  --与聚源的行情对比
  ---删除当天的数据
  ALTER TABLE DDW_PROD.T_DDW_QOT_MOT DROP IF EXISTS PARTITION   (BUS_DATE = %d{yyyyMMdd});



 INSERT INTO DDW_PROD.T_DDW_QOT_MOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所                             
								  ,TRD_MKT           --交易市场
                                  ,ERR_CGY           --错误类别								  
 ) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT      t.CD
             ,t.EXG
			 ,t.TRD_MKT
			 ,0
 FROM        DDW_PROD.T_DDW_PUB_QOT       t
 LEFT JOIN   DDW_PROD.T_DDW_PUB_JW_QOT    a1
 ON          t.TRD_MKT = a1.TRD_MKT
 AND         t.CD = a1.CD 
 AND         t.BUS_DATE = a1.BUS_DATE
 WHERE       t.DATA_SRC = 1
 AND         t.TRD_MKT = 2
 AND         SUBSTR(t.CD,1,2) NOT IN ('A3','95')
 AND         t.CD NOT IN ('371041','536068','370003','1A0017','328004'
                          ,'246021','020022','040032')
 AND         a1.CD IS  NOT  NULL
 AND         (abs(t.newst_prc-a1.newst_prc)*1.0000/t.newst_prc > 0.1
 OR           (abs(t.newst_prc-a1.newst_prc) > 0 AND t.newst_prc = 0 ))
 AND         t.BUS_DATE = %d{yyyyMMdd}
 AND         EXISTS (SELECT 1 FROM EDW_PROD.T_EDW_T02_TOF_JJFE b
                     WHERE    t.CD = b.JJDM
					 AND      t.BUS_DATE = b.BUS_DATE
                     )
 ;
 --与聚源的行情对比
 INSERT INTO DDW_PROD.T_DDW_QOT_MOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所                             
								  ,TRD_MKT           --交易市场
                                  ,ERR_CGY           --错误类别								  
 ) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT      t.CD
             ,t.EXG
			 ,t.TRD_MKT
			 ,0
 FROM        DDW_PROD.T_DDW_PUB_QOT       t
 LEFT JOIN   DDW_PROD.T_DDW_PUB_QOT    a1
 ON          ((a1.TRD_MKT IN (1,5,6) AND t.TRD_MKT in (1))
            OR (a1.TRD_MKT IN (4) AND t.TRD_MKT in (3))
			)
 AND         t.CD = a1.CD
 AND         t.EXG = a1.EXG 
 AND         t.BUS_DATE = a1.BUS_DATE
 WHERE       t.DATA_SRC = 1
 AND         t.TRD_MKT < > 2
 AND         t.CD NOT IN ('000000')
 AND         SUBSTR(t.CD,1,3)< > '299'
 AND         t.BUS_DATE = %d{yyyyMMdd}
 AND         a1.CD IS NOT NULL
 AND         (abs(t.newst_prc-a1.newst_prc)*1.0000/t.newst_prc > 0.1 
 OR           (abs(t.newst_prc-a1.newst_prc) > 0 AND t.newst_prc = 0 ))
 ;
 ---系统行情与昨天做对比
 INSERT INTO DDW_PROD.T_DDW_QOT_MOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所                             
								  ,TRD_MKT           --交易市场
                                  ,ERR_CGY           --错误类别								  
 ) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT      t.CD
             ,t.EXG
			 ,t.TRD_MKT
			 ,1
 FROM        DDW_PROD.T_DDW_PUB_QOT       t
 LEFT JOIN  (SELECT CD,EXG,TRD_MKT,newst_prc
             FROM  DDW_PROD.T_DDW_PUB_QOT a
			 WHERE EXISTS (SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE b
			               WHERE a.BUS_DATE = b.LST_TRD_D
						   AND   b.TRD_DT = %d{yyyyMMdd}
						   AND   b.BUS_DATE = %d{yyyyMMdd}
			              )
			 )       a1
 ON          t.CD = a1.CD
 AND         t.EXG = a1.EXG
 AND         t.TRD_MKT = a1.TRD_MKT
 WHERE       t.DATA_SRC = 1
 AND         t.CD NOT IN ('000000')
 AND         SUBSTR(t.CD,1,3)< > '299'
 AND         t.BUS_DATE = %d{yyyyMMdd}
 AND         (t.newst_prc > 1.11* a1.newst_prc OR t.newst_prc < 0.89* a1.newst_prc)
 AND         t.EXG NOT IN ('TA','TU')
 AND         t.TRD_MKT  < > 3 

 ;
 
 
 ---聚源行情与昨天对比
  INSERT INTO DDW_PROD.T_DDW_QOT_MOT
 (
                                   CD                --代码 
                                  ,EXG               --交易所                             
								  ,TRD_MKT           --交易市场
                                  ,ERR_CGY           --错误类别								  
 ) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT      t.CD
             ,t.EXG
			 ,t.TRD_MKT
			 ,2
 FROM        DDW_PROD.T_DDW_PUB_QOT       t
 LEFT JOIN  (SELECT CD,EXG,TRD_MKT,newst_prc
             FROM  DDW_PROD.T_DDW_PUB_QOT a
			 WHERE EXISTS (SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE b
			               WHERE a.BUS_DATE = b.LST_TRD_D
						   AND   b.TRD_DT = %d{yyyyMMdd}
						   AND   b.BUS_DATE = %d{yyyyMMdd}
			              )
			 )       a1
 ON          t.CD = a1.CD
 AND         t.EXG = a1.EXG
 AND         t.TRD_MKT = a1.TRD_MKT
 WHERE       t.DATA_SRC = 2
 AND         t.CD NOT IN ('000000')
 AND         SUBSTR(t.CD,1,3)< > '299'
 AND         t.BUS_DATE = %d{yyyyMMdd}
 AND         (t.newst_prc > 1.11* a1.newst_prc OR t.newst_prc < 0.89* a1.newst_prc)
 AND         t.EXG NOT IN ('TA','TU')

 ;
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
-------  DROP TABLE IF EXISTS DDW_PROD.T_DDW_QOT_MOT_TEMP;
-------  CREATE TABLE DDW_PROD.T_DDW_QOT_MOT_TEMP as 
-------  SELECT          a.TRD_MKT
-------                 ,a.CD
-------				 ,a.newst_prc
-------				 ,a.EXG
-------				 ,a.bus_date
-------  FROM       DDW_PROD.T_DDW_PUB_QOT  a
-------  LEFT JOIN  EDW_PROD.T_EDW_T04_TSZQDM  b
-------  ON         a.CD = b.ZQDM
-------  AND        a.EXG = b.JYS
-------  AND        a.TRD_MKT IN (1,2,4,5,6)
-------  WHERE      (a.BUS_DATE BETWEEN  b.SSRQ AND b.TSRQ OR b.ZQDM IS NULL)
-------  AND         a.CD NOT LIKE '%J'
-------  AND         a.BUS_DATE = %d{yyyyMMdd}
-------  UNION ALL 
------- SELECT  a.TRD_MKT,SUBSTR(a.CD,1,6) as CD,a.newst_prc,a.EXG,a.bus_date
------- FROM       DDW_PROD.T_DDW_PUB_QOT  a
------- LEFT JOIN  (SELECT  a.ZQDM,a.JYS,a.CPLB,a.SSRQ as SSRQ,b.SSRQ as TSRQ
-------            FROM      EDW_PROD.T_EDW_T04_TSZQDM a
-------			LEFT JOIN EDW_PROD.T_EDW_T04_TSZQDM  b
-------			ON    SUBSTR(a.ZQDM,1,6) = b.ZQDM   
-------			AND   b.ZQDM NOT LIKE '%J'
-------			AND   a.JYS = b.JYS
-------			AND   a.CPLB = b.CPLB
-------			AND   a.BUS_DATE = b.BUS_DATE
-------			WHERE a.ZQDM  LIKE '%J' AND a.BUS_DATE = %d{yyyyMMdd}
-------             )			b
------- ON         a.CD = b.ZQDM
------- AND        a.EXG = b.JYS
------- AND        a.TRD_MKT IN (1,2,5,6)
------- WHERE      a.BUS_DATE > =   b.SSRQ 
------- AND        a.BUS_DATE < b.TSRQ 
------- AND         a.CD  LIKE '%J' 
------- AND        a.BUS_DATE = %d{yyyyMMdd};	
------- 
------- INSERT OVERWRITE DDW_PROD.T_DDW_QOT_MOT
------- (
-------                                   CD                --代码 
-------                                  ,EXG               --交易所                             
-------								  ,TRD_MKT           --交易市场
-------                                  ,FLAG              --标志								  
-------) 
------- partition(bus_date = %d{yyyyMMdd})
------- SELECT 
-------                    t.CD                     as CD                --代码 
-------                    ,t.EXG                   as EXG               --交易所                  
-------					,t.TRD_MKT               as TRD_MKT           --交易市场                
-------                    ,CASE WHEN a1.CD IS NOT NULL AND t.newst_prc between 0.9*1.000*a1.newst_prc AND 1.1*1.000*a1.newst_prc
-------					      THEN 0
-------					      WHEN t.CD = '000000'
-------                          THEN 0						  
-------                          WHEN a1.CD IS NULL AND t.EXG IN ('TA','TU')
-------                          THEN 0
-------						  WHEN a1.CD IS NULL AND t.EXG = 'SH' AND SUBSTR(t.CD,1,3) = '360'
-------						  THEN 0
-------                          WHEN a1.CD IS NULL
-------                          THEN 1
-------                          ELSE 2
-------                          END 						  as FLAG   
-------                   	
------- FROM        DDW_PROD.T_DDW_PUB_QOT       t
------- LEFT JOIN  ( SELECT   TRD_MKT
-------                       ,CD
-------					   ,CASE WHEN TRD_MKT IN (1,5,6)
-------                     		 THEN ROUND(NVL(newst_prc,0),3)
-------							 ELSE ROUND(NVL(newst_prc,0),4)
-------							 END  as newst_prc
-------					   ,EXG
-------					   ,bus_date
-------             FROM   DDW_PROD.T_DDW_QOT_MOT_TEMP   ) a1
------- ON        ((t.EXG IN ('SH','SZ','TA','TU','HB','SB','HK','SK') AND t.EXG = a1.EXG)          
-------			OR (t.EXG NOT IN ('SH','SZ','TA','TU','HB','SB','HK','SK') AND a1.EXG ='CWJJ')
-------			)
------- AND      t.CD = a1.CD
------- AND      ((a1.TRD_MKT IN (1,5,6) AND t.TRD_MKT in (1))
-------          OR (a1.TRD_MKT IN (4) AND t.TRD_MKT in (3))
-------		  OR (a1.TRD_MKT IN (2) AND t.TRD_MKT in (2)))
------- AND     t.BUS_DATE = a1.BUS_DATE         
------- WHERE       ((t.EXG = 'SH' AND SUBSTR(t.CD,1,3) NOT IN ('201','202','203','204','205')  )
-------             OR (t.EXG = 'SB' AND SUBSTR(t.CD,1,3) NOT in ('299','238') AND t.CD < > '200770')
-------			 OR  (t.EXG = 'SZ' AND SUBSTR(t.CD,1,3) NOT IN ('131') AND t.CD NOT IN ('000693','150116','150119','164815','115003'))
-------			 OR (t.EXG = 'CWJJ' AND SUBSTR(t.CD,1,1) < > 'A' AND SUBSTR(t.CD,1,1) <>'95' AND t.CD NOT IN ('00954','536068','2460021','328004','1A0017','370003') )
-------			 OR  t.EXG IN ('TA','TU','HB','HK','SK'))
-------		AND t.BUS_DATE = %d{yyyyMMdd}
-------		
------- UNION ALL			 
------- SELECT 
-------                    t.CD                     as CD                --代码 
-------                    ,t.EXG                   as EXG               --交易所                  
-------					,t.TRD_MKT               as TRD_MKT           --交易市场                
-------                    ,CASE WHEN a2.CD IS NULL 
-------					      THEN 0
-------                          WHEN (t.EXG = 'SH' AND SUBSTR(t.CD,1,3) IN ('201','202','203','204','205')) OR (t.EXG = 'SZ' AND SUBSTR(t.CD,1,3) IN ('131'))
-------                          THEN 0
-------                          WHEN t.EXG IN ('TA','TU')	
-------                          THEN 0
-------                          WHEN a3.CD IS NOT NULL
-------                          THEN 0						  
-------						  WHEN a2.CD IS NOT NULL AND t.newst_prc NOT between a2.newst_prc_min AND a2.newst_prc_max
-------						  THEN 3
-------						  ELSE 0 
-------						  END                 as FLAG 
-------                   				  
-------  FROM       DDW_PROD.T_DDW_PUB_QOT   t
-------  LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE  a1
-------  ON         t.BUS_DATE = a1.NAT_DT
-------  AND        a1.BUS_DATE = %d{yyyyMMdd}
-------  LEFT JOIN  (SELECT  CD
-------                      ,EXG
-------                      ,TRD_MKT
-------                      ,DATA_SRC
-------					  ,BUS_DATE
-------					  ,ROUND(0.8*1.000*newst_prc,3) as newst_prc_min
-------					  ,ROUND(1.2*1.000*newst_prc,3) as newst_prc_max
-------              FROM DDW_PROD.T_DDW_PUB_QOT   )   a2
-------  ON          t.CD = a2.CD
-------  AND         t.EXG = a2.EXG
-------  AND         t.TRD_MKT = a2.TRD_MKT
-------  AND         a1.lst_trd_d = a2.BUS_DATE
-------  AND         t.DATA_SRC = a2.DATA_SRC
-------  LEFT JOIN   (SELECT    b.secucode as CD
-------                         ,CASE WHEN b.secumarket = 83
-------						       THEN 'SH'
-------							   ELSE 'SZ'
-------							   END  as EXG
-------						,CASE WHEN CAST(CONCAt(substr(a.earlyrepaydate,1,4),substr(a.earlyrepaydate,6,2),substr(a.earlyrepaydate,9,2) ) as INT) < > c.trd_dt
-------                              THEN CAST(d.trd_dt as INT)
-------                              ELSE CAST(c.trd_dt as INT)
------- 							  END  as BUS_DATE
-------               FROM      fundext.DBO_BOND_INSTALREDEMPPRIN    a
-------			   LEFT JOIN  fundext.DBO_BOND_CODE                 b
-------			   ON         a.INNERCODE = b.INNERCODE
-------			   AND        a.DT = b.DT
-------               LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE		    c
-------               ON         c.BUS_DATE = %d{yyyyMMdd}
-------               AND        CAST(CONCAt(substr(a.earlyrepaydate,1,4),substr(a.earlyrepaydate,6,2),substr(a.earlyrepaydate,9,2) ) as INT) = c.nat_dt	
-------               LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE		    d
-------               ON         d.BUS_DATE = %d{yyyyMMdd}
-------               AND        c.trd_dt = d.lst_trd_d			   
-------			   WHERE     a.DT = '%d{yyyyMMdd}'
-------			   AND       b.secumarket IN (83,90)   
-------              )                a3
-------  ON          t.BUS_DATE = a3.BUS_DATE
-------  AND         t.EXG = a3.EXG
-------  AND         t.CD = a3.CD
-------  WHERE         t.DATA_SRC = 1 AND t.TRD_MKT = 1  AND t.BUS_DATE = %d{yyyyMMdd}
-------  UNION ALL 
-------   SELECT 
-------                    t.CD                     as CD                --代码 
-------                    ,t.EXG                   as EXG               --交易所                  
-------					,t.TRD_MKT               as TRD_MKT           --交易市场                
-------                    ,CASE WHEN a2.CD IS NULL 
-------					      THEN 0                          						  
-------						  WHEN a2.CD IS NOT NULL AND t.newst_prc NOT between a2.newst_prc_min AND a2.newst_prc_max
-------						  THEN 3
-------						  ELSE 0 
-------						  END                 as FLAG 
-------                  					  
-------  FROM       DDW_PROD.T_DDW_PUB_QOT   t
-------  LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE  a1
-------  ON         t.BUS_DATE = a1.NAT_DT
-------  AND        a1.BUS_DATE = 20170601
-------  LEFT JOIN  (SELECT  CD
-------                      ,EXG
-------                      ,TRD_MKT
-------                      ,DATA_SRC
-------					  ,BUS_DATE
-------					  ,ROUND(0.9*1.0000*newst_prc,3) as newst_prc_min
-------					  ,ROUND(1.1*1.0000*newst_prc,3) as newst_prc_max
-------              FROM DDW_PROD.T_DDW_PUB_QOT   )   a2
-------  ON          t.CD = a2.CD
-------  AND         t.EXG = a2.EXG
-------  AND         t.TRD_MKT = a2.TRD_MKT
-------  AND         a1.lst_trd_d = a2.BUS_DATE
-------  AND         t.DATA_SRC = a2.DATA_SRC
-------  WHERE         t.DATA_SRC = 1 AND t.TRD_MKT = 2 AND t.BUS_DATE = %d{yyyyMMdd}
-------  UNION ALL    
-------   SELECT 
-------                    t.CD                     as CD                --代码 
-------                    ,t.EXG                   as EXG               --交易所                  
-------					,t.TRD_MKT               as TRD_MKT           --交易市场                
-------                    ,CASE WHEN a2.CD IS NULL 
-------					      THEN 0 
-------						  WHEN a2.CD IS NOT NULL AND t.newst_prc NOT between a2.newst_prc_mix AND a2.newst_prc_max
-------						  THEN 4
-------						  ELSE 0 
-------						  END                 as FLAG  
-------                  					  
-------  FROM       DDW_PROD.T_DDW_PUB_QOT   t
-------  LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE  a1
-------  ON         t.BUS_DATE = a1.NAT_DT
-------  AND        a1.BUS_DATE = 20170601
-------  LEFT JOIN ( SELECT    CD
-------                       ,EXG
-------					   ,TRD_MKT
-------					   ,ROUND(0.9*1.000*newst_prc,3) as newst_prc_mix
-------					   ,ROUND(1.1*1.000*newst_prc,3) as newst_prc_max
-------                       ,BUS_DATE
-------					   ,DATA_SRC
-------            FROM    DDW_PROD.T_DDW_PUB_QOT)      a2
-------  ON          t.CD = a2.CD
-------  AND         t.EXG = a2.EXG
-------  AND         t.TRD_MKT = a2.TRD_MKT
-------  AND         a1.lst_trd_d = a2.BUS_DATE
-------  AND         t.DATA_SRC = a2.DATA_SRC
-------  WHERE         t.DATA_SRC = 2 AND t.TRD_MKT = 1 AND t.BUS_DATE = %d{yyyyMMdd}
-------    UNION ALL    
-------   SELECT 
-------                    t.CD                     as CD                --代码 
-------                    ,t.EXG                   as EXG               --交易所                  
-------					,t.TRD_MKT               as TRD_MKT           --交易市场                
-------                    ,CASE WHEN a2.CD IS NULL 
-------					      THEN 0 
-------						  WHEN a2.CD IS NOT NULL AND t.newst_prc NOT between a2.newst_prc_mix AND a2.newst_prc_max
-------						  THEN 4
-------						  ELSE 0 
-------						  END                 as FLAG  
-------                  						  
-------  FROM       DDW_PROD.T_DDW_PUB_QOT   t
-------  LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE  a1
-------  ON         t.BUS_DATE = a1.NAT_DT
-------  AND        a1.BUS_DATE = 20170601
-------  LEFT JOIN ( SELECT    CD
-------                       ,EXG
-------					   ,TRD_MKT
-------					   ,ROUND(0.9*1.000*newst_prc,4) as newst_prc_mix
-------					   ,ROUND(1.1*1.000*newst_prc,4) as newst_prc_max
-------                       ,BUS_DATE
-------					   ,DATA_SRC
-------            FROM    DDW_PROD.T_DDW_PUB_QOT)      a2
-------  ON          t.CD = a2.CD
-------  AND         t.EXG = a2.EXG
-------  AND         t.TRD_MKT = a2.TRD_MKT
-------  AND         a1.lst_trd_d = a2.BUS_DATE
-------  AND         t.DATA_SRC = a2.DATA_SRC
-------  WHERE         t.DATA_SRC = 2 AND t.TRD_MKT = 2 AND t.BUS_DATE = %d{yyyyMMdd};			 
-------			 
-------  -----删除临时表
-------  DROP TABLE IF EXISTS DDW_PROD.T_DDW_QOT_MOT_TEMP;
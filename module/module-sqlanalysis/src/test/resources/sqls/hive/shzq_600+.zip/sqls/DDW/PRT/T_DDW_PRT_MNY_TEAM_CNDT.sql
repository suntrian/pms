 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:理财团队情况一览表                                                                         */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-05-14                                                                       */ 

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_MNY_TEAM_CNDT
(
	
          BRH_NAME                   --营业部名称
          ,BELTO_FILIL                --所属分公司
          ,MKT_DIRECTOR_NAME          --市场总监姓名
          ,MNY_MGR_NAME               --理财经理/投资顾问姓名
          ,CUST_MGR_NAME              --客户经理姓名         	   
)		
 PARTITION(BUS_DATE = 20180516 )
 SELECT 
		  a3.brh_shrtnm      as BRH_NAME                   --营业部名称
          ,a3.BELTO_FILIL   as BELTO_FILIL                --所属分公司
          ,GROUP_CONCAT(DECODE(NVL(t.JJRLB,a1.RYLB),'4',NVL(t.JJRXM,a1.RYXM)),',') as MKT_DIRECTOR_NAME          --市场总监姓名
          ,GROUP_CONCAT(CASE WHEN NVL(t.JJRLB,a1.RYLB) = '1'
	                         THEN NVL(t.JJRXM,a1.RYXM)
			                 WHEN NVL(t.JJRLB,a1.RYLB) IN ('2','104')
	                         THEN NVL(t.JJRXM,a1.RYXM)
			                 END,','
					   )     as MNY_MGR_NAME           --理财经理/投资顾问姓名
          ,GROUP_CONCAT(CASE WHEN  NVL(t.JJRLB,a1.RYLB) IN ('3','105','98')
	                         THEN NVL(t.JJRXM,a1.RYXM)
			                 END,','
					   )  as CUST_MGR_NAME              --客户经理姓名     
FROM       EDW_PROD.T_EDW_T01_TJJR t
FULL JOIN  EDW_PROD.T_EDW_T01_TRYXX a1
ON         t.JJRBH = a1.RYBH
AND        t.BUS_DATE = a1.BUS_DATE
LEFT JOIN DDW_PROD.V_PSN_CGY                     a2
ON        NVL(t.JJRLB,a1.RYLB) = a2.PSN_CGY 
LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH              a3
ON            NVL(t.JJRYYB,a1.YYB)	 = a3.BRH_NO
AND           a3.BUS_DATE =  20180516
WHERE      t.BUS_DATE = 20180516
AND        NVL(t.RZRQ,a1.RZRQ) < = 20180516
AND        NVL(NVL(t.LZRQ,99999999),NVL(a1.LZRQ,99999999)) > = 20180516
GROUP BY   BRH_NAME,BELTO_FILIL ;

-----------------加载结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_MNY_TEAM_CNDT',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_MNY_TEAM_CNDT;
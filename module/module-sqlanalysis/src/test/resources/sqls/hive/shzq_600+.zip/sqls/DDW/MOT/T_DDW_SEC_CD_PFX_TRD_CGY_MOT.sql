--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:证券代码区段与交易类别监控  */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-08-11                                                                        */ 
  

 

 
  ----插入数据--
   INSERT OVERWRITE DDW_PROD.T_DDW_SEC_CD_PFX_TRD_CGY_MOT
   
 (
           CD                --代码 
          ,EXG               --交易所
          ,TRD_CGY           --交易类别          
          ,SRC_TABLE         --来源表						  
) 
 partition(bus_date = %d{yyyyMMdd})
  SELECT 
                     t.ZQDM                      as CD                --代码 
                    ,t.JYS                       as EXG               --交易所 
                    ,t.WTLB					     as TRD_CGY
					,'T_EDW_T05_TJGMXLS'	     as SRC_TABLE         --来源表	
       					
  FROM       EDW_PROD.T_EDW_T05_TJGMXLS       t
  LEFT JOIN  DDW_PROD.T_DDW_CFG_SEC           a1
  ON         SUBSTR(t.ZQDM,1,3) = a1.SEC_CD_PFX
  AND        t.JYS = a1.EXG
  AND        t.WTLB = a1.TRD_CGY
  WHERE      a1.EXG IS NULL
  AND        t.BUS_DATE = %d{yyyyMMdd}
  UNION ALL 
  SELECT 
                     t.ZQDM                      as CD                --代码 
                    ,t.JYS                       as EXG               --交易所 
                    ,NULL					     as TRD_CGY
					,'T_EDW_T02_TZQGL'	         as SRC_TABLE         --来源表	
       					
  FROM       EDW_PROD.T_EDW_T02_TZQGL       t
  LEFT JOIN  (SELECT SEC_CD_PFX,EXG FROM DDW_PROD.T_DDW_CFG_SEC
              GROUP BY SEC_CD_PFX,EXG
              )           a1
  ON         SUBSTR(t.ZQDM,1,3) = a1.SEC_CD_PFX
  AND        t.JYS = a1.EXG
  WHERE      a1.EXG IS NULL
  AND        t.BUS_DATE = %d{yyyyMMdd}
  UNION ALL 
  SELECT 
                     t.sec_cd                      as CD                --代码 
                    ,t.exg                       as EXG               --交易所 
                    ,NULL					     as TRD_CGY
					,'T_DDW_F00_AST_SEC_HLD_DTL_HIS'	         as SRC_TABLE         --来源表	
       					
  FROM       DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS       t
  where bus_date = %d{yyyyMMdd}
  AND        EXG = 'SH' AND SEC_CD BETWEEN '751970' AND '751999'
  union all 
 -- AND        EXG = 'SH' AND SEC_CD BETWEEN '751970' AND '751999'
   SELECT 
                     t.ZQDM                      as CD                --代码 
                    ,t.JYS                       as EXG               --交易所 
                    ,NULL					     as TRD_CGY
					,'T_EDW_T02_TZQGL'	         as SRC_TABLE         --来源表	
       					
  FROM       EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW       t
  where bus_date = %d{yyyyMMdd}
   AND        jys = 'SZ' AND zqdm BETWEEN '101650' AND '101699'
  ;
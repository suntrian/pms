 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:佣金定价策略表                                                                      */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                       */
   TRUNCATE TABLE EDW_PROD.T_EDW_T02_TYJDJ_DJCLID; 
----------插入数据开始----------------
---------插入集中交易数据
INSERT INTO EDW_PROD.T_EDW_T02_TYJDJ_DJCLID(
                                     FID                                 --佣金策略编号                             
                                   ,YJDJFS                              --佣金策略类别                             
                                   ,YYB                                 --营业部                                
                                   ,CLMC                                --策略名称                               
                                   ,LJZQ                                --累计周期                               
                                   ,LJJS                                --累计基数                               
                                   ,DJGXFS                              --定价生效方式                             
                                   ,JYSFW                               --交易所范围                              
                                   ,FLLBFW                              --费率类别范围                             
                                   ,WTFSFW                              --委托方式范围                             
                                   ,YJDJ_ZCTJFS                         --佣金定价资产统计方式                         
                                   ,YJDJ_JYLDJFS                        --交易量定价方式                            
                                   ,ZSYJL                               --折算佣金率                              
                                   ,FJFBZ                               --附加费标志                              
                                   ,GHFZKL                              --过户费折扣率                             
                                   ,YJDJJSFS                            --佣金定价计算方式                           
                                   ,YJKBFS                              --佣金捆绑方式                             
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.FID                                 as FID                                 --编号                                  
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.YJDJFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as YJDJFS                              --佣金策略类别                              
                                   ,t.YYB                                 as YYB                                 --营业部                                 
                                   ,t.CLMC                                as CLMC                                --策略名称                                
                                   ,t.LJZQ                                as LJZQ                                --累计周期                                
                                   ,t.LJJS                                as LJJS                                --累计基数                                
                                   ,t.DJGXFS                              as DJGXFS                              --定价生效方式                              
                                   ,t.JYSFW                               as JYSFW                               --交易所范围                               
                                   ,t.FLLBFW                              as FLLBFW                              --费率类别范围                              
                                   ,t.WTFSFW                              as WTFSFW                              --委托方式范围                              
                                   ,CAST(t.ZCJSFS  AS STRING)             as YJDJ_ZCTJFS                         --佣金定价资产统计方式                          
                                   ,CAST(t.JYLJSFS AS STRING )            as YJDJ_JYLDJFS                        --交易量计算方式                             
                                   ,t.ZSYJL                               as ZSYJL                               --折算佣金率                               
                                   ,t.FJFBZ                               as FJFBZ                               --附加费标志                               
                                   ,t.GHFZKL                              as GHFZKL                              --过户费折扣率                              
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.DJJSFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as YJDJJSFS                            --定价结算方式                              
                                   ,t.YJKBFS                              as YJKBFS                              --佣金捆绑方式                              
                                   ,'JZJY'                               as XTBS                                --                                    
 FROM           JZJYCX.SECURITIES_TYJDJ_DJCLID         t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'YJDJFS'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.YJDJFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
 ON             t4.DMLX = 'YJDJJSFS'
 AND            t4.YXT = 'JZJY'
 AND            t4.YDM = CAST(t.DJJSFS AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';

------插入融资融券的数据	
INSERT INTO EDW_PROD.T_EDW_T02_TYJDJ_DJCLID(
                                     FID                                 --佣金策略编号                             
                                   ,YJDJFS                              --佣金策略类别                             
                                   ,YYB                                 --营业部                                
                                   ,CLMC                                --策略名称                               
                                   ,LJZQ                                --累计周期                               
                                   ,LJJS                                --累计基数                               
                                   ,DJGXFS                              --定价生效方式                             
                                   ,JYSFW                               --交易所范围                              
                                   ,FLLBFW                              --费率类别范围                             
                                   ,WTFSFW                              --委托方式范围                             
                                   ,YJDJ_ZCTJFS                         --佣金定价资产统计方式                         
                                   ,YJDJ_JYLDJFS                        --交易量定价方式                            
                                   ,ZSYJL                               --折算佣金率                              
                                   ,FJFBZ                               --附加费标志                              
                                   ,GHFZKL                              --过户费折扣率                             
                                   ,YJDJJSFS                            --佣金定价计算方式                           
                                   ,YJKBFS                              --佣金捆绑方式                             
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.FID                                 as FID                                 --编号                                  
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.YJDJFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as YJDJFS                              --佣金策略类别                              
                                   ,CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                as YYB                                 --营业部                                 
                                   ,t.CLMC                                as CLMC                                --策略名称                                
                                   ,t.LJZQ                                as LJZQ                                --累计周期                                
                                   ,t.LJJS                                as LJJS                                --累计基数                                
                                   ,t.DJGXFS                              as DJGXFS                              --定价生效方式                              
                                   ,t.JYSFW                               as JYSFW                               --交易所范围                               
                                   ,t.FLLBFW                              as FLLBFW                              --费率类别范围                              
                                   ,t.WTFSFW                              as WTFSFW                              --委托方式范围                              
                                   ,CAST(t.ZCJSFS AS STRING )             as YJDJ_ZCTJFS                         --佣金定价资产统计方式                          
                                   ,CAST(t.JYLJSFS AS STRING)             as YJDJ_JYLDJFS                        --交易量计算方式                             
                                   ,t.ZSYJL                               as ZSYJL                               --折算佣金率                               
                                   ,t.FJFBZ                               as FJFBZ                               --附加费标志                               
                                   ,t.GHFZKL                              as GHFZKL                              --过户费折扣率                              
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.DJJSFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as YJDJJSFS                            --定价结算方式                              
                                   ,t.YJKBFS                              as YJKBFS                              --佣金捆绑方式                              
                                   ,'RZRQ'                               as XTBS                                --                                    
FROM           RZRQCX.SECURITIES_TYJDJ_DJCLID         t
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
ON             t1.DMLX = 'YJDJFS'
AND            t1.YXT = 'RZRQ'
AND            t1.YDM = CAST(t.YJDJFS AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
ON             t4.DMLX = 'YJDJJSFS'
AND            t4.YXT = 'RZRQ'
AND            t4.YDM = CAST(t.DJJSFS AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t2
 ON             t2.YXT = 'RZRQ'
 AND            t2.JGDM = CAST(t.YYB AS VARCHAR(20))
WHERE          t.DT = '%d{yyyyMMdd}';
--------插入数据结束-------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TYJDJ_DJCLID',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TYJDJ_DJCLID;
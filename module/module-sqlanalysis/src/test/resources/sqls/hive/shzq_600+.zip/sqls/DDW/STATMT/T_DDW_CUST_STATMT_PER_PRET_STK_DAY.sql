 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:个股盈亏日表                                                         */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */
---A 股1 B 股 2 权证 3 债券4 场内基金5 三板 6 港股7 场外基金 8 金融产品 9 期权 10
 ---删除当天的数据
  ALTER TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ; 
  
-------------------
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP0;
  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP0 as
  SELECT   a.KHH
          ,a.JYS
		  ,a.ZQDM
		  ,SUM(a.CJJE) as CJJE
		  ,b.CXRQ as BUS_DATE 
		  ,a.KHXM
		  ,a.YYB
		  ,a.BZDM
		  ,a.JSZH
		  ,a.XTBS
		  ,a.BUS_DATE as BUS_DATE1
  FROM  (SELECT          a.KHH
                        ,a.JYS
						,a.zqdm
						,a.bus_date
						,a.CJJE
						,a.KHXM
						,a.YYB
						,a.BZDM
						,a.JSZH
						,a.XTBS
                        ,ROUND(CASE WHEN a.JYS = 'SH'
							        THEN a.CJJG
								    ELSE a.CJJE*1.000/a.BCSL
								    END,2
							   )  as PX
          FROM        EDW_PROD.T_EDW_T05_TJGMXLS a
          LEFT JOIN  (SELECT   EXG
		                      ,SEC_CD_PFX
					  FROM DDW_PROD.T_DDW_CFG_SEC 
					  WHERE LENGTH(sec_cd_pfx)  = 3 
					  AND  STK_CGY IN ('A股中小板','基金','股票','创业板','主板A股','AK科创板','RK科创CDR')----- 
			          GROUP BY EXG,SEC_CD_PFX
			          )                                c
          ON        a.JYS = c.EXG
          AND       SUBSTR(a.ZQDM,1,3) = c.SEC_CD_PFX 
          WHERE       a.WTLB = 6
          AND   c.SEC_CD_PFX IS not null
          )                          a
  LEFT JOIN (SELECT   CAST(CONCAt(substr(a.ExDiviDate,1,4),substr(a.ExDiviDate,6,2),substr(a.ExDiviDate,9,2) ) as INT) as CXRQ
		             ,c.lst_trd_d as PXRQ
                     ,b.SECUCODE    as ZQDM
		             ,DECODE(b.secumarket,83,'SH',90,'SZ')  as JYS
		             ,SUM(ROUND(a.CashDiviRMB/10,2))        as PX1
		             ,SUM(ROUND(a.ActualCashDiviRMB/10,2))  as PX2
             FROM    ( SELECT     a.ExDiviDate
					              ,a.INNERCODE
							      ,a.ToAccountDate
								  ,a.DT								
								  ,a.CashDiviRMB
								  ,a.ActualCashDiviRMB
					  FROM    FUNDEXT.DBO_LC_DIVIDEND  a
					  WHERE   a.DT = '%d{yyyyMMdd}'
                      UNION ALL
					  SELECT    DECODE(LENGTH(TRIM(a.exrightdateex)),0,ExRightDate,exrightdateex)  as ExDiviDate
					           ,a.INNERCODE
							   ,DECODE(LENGTH(TRIM(a.ExecuteDateEX)),0,ExecuteDate,ExecuteDateEX)  as ToAccountDate
						       ,a.DT									
							   ,a.DividendRatioBeforeTax as CashDiviRMB
							   ,a.ActualRatioAfterTax    as ActualCashDiviRMB
					   FROM    FUNDEXT.DBO_MF_DIVIDEND  a
					   WHERE   a.DT = '%d{yyyyMMdd}' 
					  )a
            LEFT JOIN FUNDEXT.DBO_SECUMAIN     b
            ON        a.INNERCODE = b.INNERCODE
            AND       a.DT = b.DT
            LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE c
            ON        CAST(CONCAt(substr(a.ToAccountDate,1,4),substr(a.ToAccountDate,6,2),substr(a.ToAccountDate,9,2) ) as INT) = c.TRD_DT
            AND       c.BUS_DATE = %d{yyyyMMdd}
            WHERE     a.CashDiviRMB > 0 
            AND       CAST(CONCAt(substr(a.ExDiviDate,1,4),substr(a.ExDiviDate,6,2),substr(a.ExDiviDate,9,2) ) as INT) > 20140101
            AND       LENGTH(TRIM(a.ExDiviDate)) > 0
            AND       LENGTH(TRIM(a.ToAccountDate)) > 0
            AND       c.TRD_DT = c.NAT_DT
            AND       CAST(CONCAt(substr(a.ExDiviDate,1,4),substr(a.ExDiviDate,6,2),substr(a.ExDiviDate,9,2) ) as INT) < = CAST(CONCAt(substr(a.ExDiviDate,1,4),substr(a.ExDiviDate,6,2),substr(a.ExDiviDate,9,2) ) as INT)
           -- AND       20170711 BETWEEN c.lst_trd_d AND CAST(CONCAt(substr(a.ExDiviDate,1,4),substr(a.ExDiviDate,6,2),substr(a.ExDiviDate,9,2) ) as INT)
            AND       a.DT = '%d{yyyyMMdd}'
			GROUP BY CXRQ,PXRQ,ZQDM,JYS
             )   b
  on  a.BUS_DATE > = b.PXRQ
  AND a.BUS_DATE < b.CXRQ
  AND a.ZQDM = b.ZQDM
  AND  a.JYS = b.JYS
  AND  (a.PX = b.PX1 OR a.PX = b.PX2)
  WHERE b.ZQDM IS NOT NULL --AND (a.BUS_DATE = %d{yyyyMMdd} OR b.CXRQ = %d{yyyyMMdd})
  GROUP BY a.KHH,a.JYS,a.ZQDM,b.CXRQ,a.KHXM,a.YYB,a.BZDM,a.JSZH,a.XTBS,a.BUS_DATE
;  

  DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP10;
  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP10 as
  SELECT   a.KHH
          ,a.JYS
		  ,a.ZQDM
		  ,SUM(CASE WHEN a.BUS_DATE = %d{yyyyMMdd}
                    THEN a.CJJE
                    WHEN a.BUS_DATE1 = %d{yyyyMMdd}	
                    THEN 0 - a.CJJE
				    ELSE 0
                    END
			   )	 as CJJE					  
		  ,a.BZDM
		  ,%d{yyyyMMdd} as BUS_DATE
  FROM  DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP0 a
 WHERE  a.BUS_DATE = %d{yyyyMMdd} OR  a.BUS_DATE1 = %d{yyyyMMdd}
 group by a.khh,a.jys,a.zqdm,a.bzdm,BUS_DATE ;
 
  
  
 -----今天市值
 DROP TABLE IF EXISTS    DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP;
 CREATE TABLE   DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP
 as  SELECT     NVL(a.CUST_NO,f.KHH) as CUST_NO
               ,NVL(a.EXG,f.JYS)     as EXG
			   ,NVL(a.SEC_CD,f.ZQDM) as SEC_CD
			   ,CASE WHEN NVL(a.EXG,f.JYS) IN  ('HK','SK')
			         THEN 'RMB'
					 ELSE NVL(a.CCY_CD,f.BZDM)
					 END    as CCY_CD
			   ,SUM(CASE WHEN NVL(a.EXG,f.JYS) IN ('HK','SK') 
			             AND  b.BZDM IS NOT NULL						
					     THEN (NVL(a.SEC_MKTVAL,0)+NVL(f.CJJE,0))*b.ZHHL						 
						 ELSE (NVL(a.SEC_MKTVAL,0)+NVL(f.CJJE,0))
                         END
				   )                as SEC_MKTVAL     --原币市值
			   ,SUM(CASE WHEN b.BZDM IS NOT NULL
					     THEN (NVL(a.SEC_MKTVAL,0)+NVL(f.CJJE,0))*b.ZHHL
					     ELSE (NVL(a.SEC_MKTVAL,0)+NVL(f.CJJE,0))
					     END
					)               as SEC_MKTVAL_RMB --人民币市值
	 FROM       (SELECT CUST_NO,EXG,SEC_CD,BUS_DATE,SUM(SEC_MKTVAL) as SEC_MKTVAL,CCY_CD 
       	         FROM   DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
                 WHERE BUS_DATE = %d{yyyyMMdd}
				 GROUP BY CUST_NO,EXG,SEC_CD,BUS_DATE,CCY_CD
				 )	 a
     FULL  JOIN DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP10 f
     ON         a.CUST_NO = f.KHH
     AND        a.EXG = f.JYS
     AND        a.SEC_CD = f.ZQDM
     AND        a.BUS_DATE = f.BUS_DATE
	 
	 --FULL  JOIN DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP0 g
     --ON         a.CUST_NO = g.KHH
     --AND        a.EXG = g.JYS
     --AND        a.SEC_CD = g.ZQDM
     --AND        a.BUS_DATE = g.BUS_DATE1
	 --AND        g.BUS_DATE1 = %d{yyyyMMdd} 
	 LEFT JOIN    EDW_PROD.T_EDW_T99_HLZH                   b
	 ON           NVL(a.CCY_CD,f.BZDM) = b.BZDM
	 AND          b.BUS_DATE = %d{yyyyMMdd}
	 WHERE       NVL(a.BUS_DATE,f.BUS_DATE) = %d{yyyyMMdd}
     GROUP BY 	  CUST_NO,EXG,SEC_CD,CCY_CD;
------------昨日的市值
 DROP TABLE IF EXISTS    DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP1;
 CREATE TABLE   DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP1 
 as  SELECT     CUST_NO
               ,EXG
			   ,SEC_CD
			   ,CASE WHEN a.EXG IN  ('HK','SK')
			         THEN 'RMB'
					 ELSE a.CCY_CD
					 END    as CCY_CD
			   ,SUM(CASE WHEN a.EXG IN ('HK','SK') 
			             AND  b.BZDM IS NOT NULL
					     THEN a.SEC_MKTVAL*b.ZHHL
					     ELSE a.SEC_MKTVAL
					     END
				   )                as SEC_MKTVAL     --原币市值
			   ,SUM(CASE WHEN b.BZDM IS NOT NULL
					     THEN a.SEC_MKTVAL*b.ZHHL
					     ELSE a.SEC_MKTVAL
					     END
					)               as SEC_MKTVAL_RMB --人民币市值
	 FROM         DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS    a
	 LEFT JOIN    EDW_PROD.T_EDW_T99_HLZH                   b
	 ON           a.CCY_CD = b.BZDM
	 AND          a.BUS_DATE = b.BUS_DATE
	 WHERE        EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
	                     WHERE  c.BUS_DATE = %d{yyyyMMdd}
						 AND    c.TRD_DT = %d{yyyyMMdd}
						 AND    a.BUS_DATE = c.LST_TRD_D
	                     )
     GROUP BY 	  a.CUST_NO,a.EXG,a.SEC_CD,CCY_CD;
	 ------负债(今天负债)
	 DROP TABLE IF EXISTS    DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP2;
     CREATE TABLE   DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP2 as
	 SELECT  a.CUST_NO
	        ,a.EXG
			,a.SEC_CD
            ,a.CCY_CD			
			,SUM(0-a.CRD_ACCT_GT_MRGNS_PRINP-a.CRD_ACCT_ADDED_GL_INT) as SEC_MKTVAL
			,SUM(CASE WHEN b.BZDM IS NOT NULL
			          THEN (0-a.CRD_ACCT_GT_MRGNS_PRINP-a.CRD_ACCT_ADDED_GL_INT)*b.ZHHL
					  ELSE (0-a.CRD_ACCT_GT_MRGNS_PRINP-a.CRD_ACCT_ADDED_GL_INT)
					  END
				)  as SEC_MKTVAL_RMB
	 FROM   DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS     a
	 LEFT JOIN    EDW_PROD.T_EDW_T99_HLZH                   b
	 ON           a.CCY_CD = b.BZDM
	 AND          a.BUS_DATE = b.BUS_DATE
	 WHERE        a.BUS_DATE = %d{yyyyMMdd}
	 GROUP BY  a.CUST_NO,a.EXG,a.SEC_CD,a.CCY_CD
	 ;
	--------昨天负债
	 DROP TABLE IF EXISTS    DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP3;
     CREATE TABLE   DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP3 as
	 SELECT  a.CUST_NO
	        ,a.EXG
			,a.SEC_CD
            ,a.CCY_CD			
			,SUM(0-a.CRD_ACCT_GT_MRGNS_PRINP) as SEC_MKTVAL
			,SUM(CASE WHEN b.BZDM IS NOT NULL
			          THEN (0-a.CRD_ACCT_GT_MRGNS_PRINP)*b.ZHHL
					  ELSE (0-a.CRD_ACCT_GT_MRGNS_PRINP)
					  END
				)  as SEC_MKTVAL_RMB
	 FROM   DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS     a
	 LEFT JOIN    EDW_PROD.T_EDW_T99_HLZH                   b
	 ON           a.CCY_CD = b.BZDM
	 AND          a.BUS_DATE = b.BUS_DATE
	 WHERE        EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
	                     WHERE  c.BUS_DATE = %d{yyyyMMdd}
						 AND    c.TRD_DT = %d{yyyyMMdd}
						 AND    a.BUS_DATE = c.LST_TRD_D
	                     )
	 GROUP BY  a.CUST_NO,a.EXG,a.SEC_CD,a.CCY_CD
	 ;	 
  ----交易明细临时表
  --当天交割的数据
  DROP TABLE IF EXISTS    DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP4;
  CREATE TABLE   DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP4 as
  SELECT  * FROM 
  (SELECT    CUST_NO
                     ,EXG
					 ,SEC_CD
					 ,CCY_CD
                     ,MTCH_AMT
					 ,INT_AMT
					 ,RCVB_AMT
					 ,S1
					 ,ODR_CGY
					 ,CAST((CASE WHEN EXG IN ('TU','HK','SK','HB','SB') AND ODR_CGY IN (1,2)
					             THEN MTCH_DT
								 WHEN EXG IN ('SH','SZ') AND ODR_CGY IN (42,43)
								 THEN END_DT
						         ELSE BUS_DATE
						         END) as INT)  as BUS_DATE
  FROM    DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
  WHERE   BUS_DATE = %d{yyyyMMdd}
  UNION ALL
  SELECT            KHH  as CUST_NO
			       ,JYS  as EXG
				   ,ZQDM as SEC_CD
				   ,JSBZDM as CCY_CD
				   ,CJJE as MTCH_AMT
			       ,LXJE as INT_AMT
			       ,YSJE as RCVB_AMT
				   ,S1   as S1
				   ,WTLB as ODR_CGY
				   ,CJRQ as BUS_DATE
            FROM EDW_PROD.T_EDW_T05_TDJSQSZL
			WHERE BUS_DATE = %d{yyyyMMdd}
			AND   JSBZ_2 = 0
			AND   JSRQ_2 > %d{yyyyMMdd}
			AND   ((JYS IN ('TU','HK','SK','HB','SB')
			AND WTLB IN (1,2)) OR (JYS IN ('SH','SZ')
			AND WTLB IN (42,43)))
 ) t
 WHERE  t.BUS_DATE = %d{yyyyMMdd} ;			
  
  DROP TABLE IF EXISTS    DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP5;
  CREATE TABLE            DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP5
  as  SELECT              t.CUST_NO
                         ,t.EXG
                         ,t.SEC_CD
						 ,t.CCY_CD						
						 ,SUM(NVL(CASE WHEN a2.CGY = 1 
						       THEN t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA
							   END,0)) as TRD_COST
                         ,SUM(NVL(CASE WHEN a2.CGY = 1 
						                AND a3.BZDM IS NOT NULL
    						            THEN (t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA)*a3.ZHHL
										WHEN  a2.CGY =1
										AND a3.BZDM IS  NULL
										THEN t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA
										ELSE 0
										END,0) 
							  )   as  TRD_COST_RMB
						 ,SUM(NVL(CASE WHEN a2.CGY = 2 
						       THEN t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA
							   END,0)) as TRD_FEE_PAYOUT
                         ,SUM(NVL(CASE WHEN a2.CGY = 2 
						                AND a3.BZDM IS NOT NULL
    						            THEN (t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA)*a3.ZHHL
										WHEN  a2.CGY = 2
										AND a3.BZDM IS  NULL
										THEN t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA
										ELSE 0
										END,0)  
							  )   as  TRD_FEE_PAYOUT_RMB
						  ,SUM(NVL(CASE WHEN a2.CGY = 3 
						       THEN t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA
							   END,0)) as CMSN_PAYOUT
                         ,SUM(NVL(CASE WHEN a2.CGY = 3 
						                AND a3.BZDM IS NOT NULL
    						            THEN (t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA)*a3.ZHHL
										WHEN  a2.CGY = 3
										AND a3.BZDM IS  NULL
										THEN t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA
										ELSE 0
										END,0)  
							  )   as  CMSN_PAYOUT_RMB	  
				          ,SUM(NVL(CASE WHEN a2.CGY = 4 
						       THEN t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA
							   END,0)) as INT_PAYOUT
                          ,SUM(NVL(CASE WHEN a2.CGY = 4 
						                AND a3.BZDM IS NOT NULL
    						            THEN (t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA)*a3.ZHHL
										WHEN  a2.CGY = 4
										AND a3.BZDM IS  NULL
										THEN t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA
										ELSE 0
										END,0)  
							  )   as  INT_PAYOUT_RMB
					      ,SUM(NVL(CASE WHEN a2.CGY NOT IN (1,2,3,4) 
						       THEN t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA
							   END,0)) as OTH_PAYOUT
                          ,SUM(NVL(CASE WHEN a2.CGY NOT IN (1,2,3,4)
						                AND a3.BZDM IS NOT NULL
    						            THEN (t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA)*a3.ZHHL
										WHEN  a2.CGY NOT IN (1,2,3,4)
										AND a3.BZDM IS  NULL
										THEN t.MTCH_AMT*a2.MTCH_AMT_PARA+t.INT_AMT*a2.INT_PARA+t.RCVB_AMT*a2.RCVB_AMT_PARA+t.S1*a2.S1_PARA
										ELSE 0
										END,0)  
							  )   as  OTH_PAYOUT_RMB
                         ,SUM(ROUND(CASE WHEN t.ODR_CGY IN (1,1111,42,57,59,61,63) 
						                 THEN t.MTCH_AMT*1.00000/3
								         ELSE 0
								         END,2) )        as BUYIN_AMT
                     	,SUM(ROUND(CASE WHEN t.ODR_CGY IN (2,12,13,17,2222,43,58,60,62,64,71) 
						           THEN t.MTCH_AMT*1.00000/3
								   ELSE 0
								   END,2) 
							)        as SELL_AMT							   
   FROM       DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP4       t
   LEFT JOIN  (SELECT  EXG
                      ,SEC_CD_PFX
					  ,TRD_CGY 
			   FROM DDW_PROD.T_DDW_CFG_SEC
			   GROUP BY EXG,SEC_CD_PFX,TRD_CGY
			   )                                          a1
   ON         t.SEC_CD = a1.SEC_CD_PFX
   AND        t.EXG = a1.EXG
   AND        t.ODR_CGY = a1.TRD_CGY
   LEFT JOIN  DDW_PROD.T_DDW_CFG_SEC                      a2
   ON         SUBSTR(t.SEC_CD,1,3) = a2.SEC_CD_PFX
   AND        t.EXG = a2.EXG
   AND        t.ODR_CGY = a2.TRD_CGY
   AND        a2.IF_PRFT =1
   LEFT JOIN    EDW_PROD.T_EDW_T99_HLZH                   a3
   ON           t.CCY_CD = a3.BZDM
   AND          t.BUS_DATE = a3.BUS_DATE  
   WHERE      a1.EXG IS  NULL
   AND        a2.EXG IS NOT NULL
   GROUP BY   t.CUST_NO ,t.EXG,t.SEC_CD,t.CCY_CD
   ;




  

-----证券盈亏
INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY
(
                                   CUST_NO                     --客户号
                                  ,EXG                         --交易所   
                                  ,CCY_CD                      --币种代码                                 
                                  ,SEC_CD                      --证券代码
								  ,TRD_COST                    --交易成本
                                  ,TRD_FEE_PAYOUT              --交易费用支出
                                  ,CMSN_PAYOUT                 --佣金支出
                                  ,INT_PAYOUT		           --利息支出
                                  ,OTH_PAYOUT                  --利息支出
                                  ,TOT_PRET   			       --总盈亏
                                  ,TOT_PRET_RMB                --RMB总盈亏
                                  ,BUYIN_AMT                   --买入金额
                                  ,SELL_AMT                    --卖出金额
								  ,NEWST_MKTVAL                --最新市值
								  ,PROD_CGY                    --产品类别
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT 
                COALESCE(t.CUST_NO,a1.CUST_NO,a2.CUST_NO,a3.CUST_NO,a4.CUST_NO)           as CUST_NO                     --客户号            
               ,COALESCE(t.EXG,a1.EXG,a2.EXG,a3.EXG,a4.EXG)                   as EXG                         --交易所   
               ,COALESCE(t.CCY_CD,a1.CCY_CD,a2.CCY_CD,a3.CCY_CD,a4.CCY_CD)             as CCY_CD                      --币种代码     
               ,COALESCE(t.SEC_CD,a1.SEC_CD,a2.SEC_CD,a3.SEC_CD,a4.SEC_CD)            as SEC_CD                      --证券代码
               ,NVL(a4.TRD_COST,0)                  as TRD_COST                    --交易成本
               ,NVL(a4.TRD_FEE_PAYOUT,0)            as TRD_FEE_PAYOUT              --交易费用支出
               ,NVL(a4.CMSN_PAYOUT,0)               as CMSN_PAYOUT                 --佣金支出
               ,NVL(a4.INT_PAYOUT,0)                as INT_PAYOUT		            --利息支出
               ,NVL(a4.OTH_PAYOUT,0)                as OTH_PAYOUT                  --利息支出
               ,ROUND(CASE WHEN a5.CUST_NO IS  NULL 
			         THEN NVL(t.SEC_MKTVAL,0)-NVL(a1.SEC_MKTVAL,0)+NVL(a2.SEC_MKTVAL,0)-NVL(a3.SEC_MKTVAL,0) 
               +NVL(a4.TRD_COST,0)+NVL(a4.TRD_FEE_PAYOUT,0)+NVL(a4.CMSN_PAYOUT,0)
			   +NVL(a4.INT_PAYOUT,0)+NVL(a4.OTH_PAYOUT,0)
 			         ELSE 0
					 END,2)  as TOT_PRET   			        --总盈亏
               ,ROUND(CASE WHEN a5.CUST_NO IS  NULL 
			         THEN NVL(t.SEC_MKTVAL_RMB,0)-NVL(a1.SEC_MKTVAL_RMB,0)+NVL(a2.SEC_MKTVAL_RMB,0)-NVL(a3.SEC_MKTVAL_RMB,0) 
               +NVL(a4.TRD_COST_RMB,0)+NVL(a4.TRD_FEE_PAYOUT_RMB,0)+NVL(a4.CMSN_PAYOUT_RMB,0)
			   +NVL(a4.INT_PAYOUT_RMB,0)+NVL(a4.OTH_PAYOUT_RMB,0)
 			         ELSE 0
					 END,2)                            as TOT_PRET_RMB   			        --总盈亏
               ,NVL(a4.BUYIN_AMT,0)	                as BUYIN_AMT
               ,NVL(a4.SELL_AMT,0)	                as SELL_AMT
               ,ROUND(NVL(t.SEC_MKTVAL,0),2)	    as NEWST_MKTVAL		   
			    ,a6.PROD_CGY       as PROD_CGY                    --产品类别	       as PROD_CGY                    --产品类别			   
    FROM          DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP	    t 
    FULL JOIN     DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP1     a1
	ON            t.CUST_NO = a1.CUST_NO
	AND           t.EXG = a1.EXG
	AND           t.SEC_CD = a1.SEC_CD
	FULL JOIN     DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP2      a2
	ON            COALESCE(t.CUST_NO,a1.CUST_NO) = a2.CUST_NO
	AND           COALESCE(t.EXG,a1.EXG) = a2.EXG
	AND           COALESCE(t.SEC_CD,a1.SEC_CD) = a2.SEC_CD
    FULL JOIN     DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP3      a3
	ON            COALESCE(t.CUST_NO,a1.CUST_NO,a2.CUST_NO) = a3.CUST_NO
	AND           COALESCE(t.EXG,a1.EXG,a2.EXG) = a3.EXG
	AND           COALESCE(t.SEC_CD,a1.SEC_CD,a2.SEC_CD) = a3.SEC_CD
	FULL JOIN     DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP5       a4
	ON            COALESCE(t.CUST_NO,a1.CUST_NO,a2.CUST_NO,a3.CUST_NO) = a4.CUST_NO
	AND           COALESCE(t.EXG,a1.EXG,a2.EXG,a3.EXG) = a4.EXG
	AND           COALESCE(t.SEC_CD,a1.SEC_CD,a2.SEC_CD,a3.SEC_CD) = a4.SEC_CD          
    LEFT JOIN  (SELECT CUST_NO
	                   ,EXG
					   ,SEC_CD
					   ,BUS_DATE
                FROM  DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS  a1
				WHERE BUS_DATE  = %d{yyyyMMdd}
				AND   ODR_CGY IN (29,30)
				GROUP BY CUST_NO,EXG,SEC_CD,BUS_DATE
				)               a5
    ON            COALESCE(t.CUST_NO,a1.CUST_NO,a2.CUST_NO,a3.CUST_NO,a4.CUST_NO) = a5.CUST_NO
	AND           COALESCE(t.EXG,a1.EXG,a2.EXG,a3.EXG,a4.EXG) = a5.EXG
	AND           COALESCE(t.SEC_CD,a1.SEC_CD,a2.SEC_CD,a3.SEC_CD,a4.SEC_CD) = a5.SEC_CD 

    LEFT JOIN  (SELECT  EXG
	                    ,SEC_CD_PFX
						,CASE WHEN  SEC_CL_CD IN ('001','002','003','004','012','013')    --------
			                 THEN  1
					         WHEN SEC_CL_CD IN ('005','063')
					         THEN  2
					         WHEN SEC_CL_CD IN ('006','007','008')
					         THEN  6
					         WHEN SEC_CL_CD IN ('015','016')
					         THEN 7
					         WHEN SEC_CL_CD BETWEEN '017' AND '053'
					         THEN 4
					         WHEN SEC_CL_CD BETWEEN '054' AND '062'
					         THEN 5
					         END as PROD_CGY
				FROM  DDW_PROD.T_DDW_CFG_SEC_TRD_CL
				WHERE SEC_CL_CD NOT IN ('009','010','011','014','013')
				GROUP BY EXG,SEC_CD_PFX,PROD_CGY
				)                   a6
    ON          COALESCE(t.EXG,a1.EXG,a2.EXG,a3.EXG,a4.EXG) = a6.EXG 
	AND         SUBSTR(COALESCE(t.SEC_CD,a1.SEC_CD,a2.SEC_CD,a3.SEC_CD,a4.SEC_CD),1,3) = a6.SEC_CD_PFX        
	WHERE   SUBSTR(COALESCE(t.CUST_NO,a1.CUST_NO,a2.CUST_NO,a3.CUST_NO,a4.CUST_NO),1,1) < > '9'
	AND     COALESCE(t.CUST_NO,a1.CUST_NO,a2.CUST_NO,a3.CUST_NO,a4.CUST_NO) < > '100610335855'  
    AND     a6.SEC_CD_PFX IS NOT NULL	
 ;
   

-----插入金融产品盈亏
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP6;
 CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP6 as 
 SELECT  CUST_NO
        ,PROD_CD
        ,PROD_CGY
		,SUM(PROD_NEWST_MKTVAL) as PROD_NEWST_MKTVAL
 FROM   DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS a
 WHERE EXISTS (SELECT 1 
		 FROM   EDW_PROD.T_EDW_T99_TRD_DATE b
		 WHERE   b.BUS_DATE = %d{yyyyMMdd}
		 AND   b.TRD_DT = %d{yyyyMMdd}
		 AND   a.BUS_DATE = b.LST_TRD_D
		 )
 GROUP BY CUST_NO,PROD_CD,PROD_CGY
 ;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP7;
  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP7
  as SELECT     t.CUST_NO
               ,t.PROD_CD
			   ,t.CCY_CD
			   ,decode(t.PROD_CGY,10,11,t.PROD_CGY) as PROD_CGY
               ,SUM (CASE WHEN a1.CGY = 1 
			         THEN t.CNFM_AMT*a1.cnfm_amt_para+a1.cmsn_fee_para*t.CMSN_FEE+t.INT_AMT*a1.int_amt_para
					 ELSE 0
					 END )  as TRD_COST
			   ,SUM (CASE WHEN a1.CGY = 2
			         THEN t.CNFM_AMT*a1.cnfm_amt_para+a1.cmsn_fee_para*t.CMSN_FEE+t.INT_AMT*a1.int_amt_para
					 ELSE 0
					 END )  as TRD_FEE_PAYOUT
				,SUM (CASE WHEN a1.CGY = 3
			         THEN t.CNFM_AMT*a1.cnfm_amt_para+a1.cmsn_fee_para*t.CMSN_FEE+t.INT_AMT*a1.int_amt_para
					 ELSE 0
					 END )  as INT_PAYOUT 
               ,SUM(CASE WHEN t.prod_biz_cd IN ('122','139','130') 
			           AND  a1.cnfm_amt_para = 1
                     THEN t.CNFM_AMT
                     ELSE 0
                     END)    as BUYIN_AMT
               ,SUM(CASE WHEN t.prod_biz_cd IN ('124','142','150')
                     AND  a1.cnfm_amt_para = 1			   
                     THEN t.CNFM_AMT
                     ELSE 0
                     END)    as SELL_AMT					 
  FROM       DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS       t
  LEFT JOIN  DDW_PROD.T_DDW_CFG_FND            a1
  ON         t.PROD_BIZ_CD = a1.BIZ_CD 	
  WHERE      t.BUS_DATE = %d{yyyyMMdd}
  AND        t.if_pret = 1
  GROUP BY   t.CUST_NO,t.PROD_CD,t.CCY_CD,PROD_CGY
  ; 
  
  ----------
     DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP9;
  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP9
  as SELECT  CASE WHEN t.MTCH_NO = '定期折算'
                  AND  a3.ZQDM IS NOT NULL
                  THEN a3.ZQDM
				  WHEN t.MTCH_NO IN ('基金上折','基金下折')
				  AND  a4.ZQDM IS NOT NULL
                  THEN a4.ZQDM
				  END as JJDM
             ,t.BUS_DATE as BUS_DATE				  
  FROM       DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS       t
  LEFT JOIN  (SELECT ZQDM,JJDM FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS 
              WHERE   BUS_DATE = %d{yyyyMMdd}
			  AND     JJFL = 1
             )                                                                   a3
 ON  	(t.PROD_CD =  a3.ZQDM
 OR      t.PROD_CD =  a3.JJDM)
 LEFT JOIN  (SELECT ZQDM,JJDM FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS 
              WHERE   BUS_DATE = %d{yyyyMMdd}
			  AND     JJFL IN (1,2)
              )                                                              a4
 ON  	(t.PROD_CD =  a4.ZQDM
 OR      t.PROD_CD =  a4.JJDM)
 WHERE   t.BUS_DATE = %d{yyyyMMdd} AND PROD_CGY = 8
 AND    t.MTCH_NO IN ('基金上折','基金下折','定期折算')
 GROUP BY  JJDM,BUS_DATE
 UNION ALL
 SELECT      CASE WHEN t.MTCH_NO = '定期折算'
                  AND  a3.ZQDM IS NOT NULL
                  THEN a3.JJDM
				  WHEN t.MTCH_NO IN ('基金上折','基金下折')
				  AND  a4.ZQDM IS NOT NULL
                  THEN a4.JJDM
				  END as JJDM	
             ,t.BUS_DATE	as BUS_DATE			  
  FROM       DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS       t
  LEFT JOIN  (SELECT ZQDM,JJDM FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS 
              WHERE   BUS_DATE = %d{yyyyMMdd}
			  AND     JJFL = 1
             )                                                                   a3
 ON  	(t.PROD_CD =  a3.ZQDM
 OR      t.PROD_CD =  a3.JJDM)
 LEFT JOIN  (SELECT ZQDM,JJDM FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS 
              WHERE   BUS_DATE = %d{yyyyMMdd}
			  AND     JJFL IN (1,2)
              )                                                              a4
 ON  	(t.PROD_CD =  a4.ZQDM
 OR      t.PROD_CD =  a4.JJDM)
 WHERE   t.BUS_DATE = %d{yyyyMMdd} AND PROD_CGY = 8
 AND     t.MTCH_NO IN ('基金上折','基金下折','定期折算')
 GROUP BY  JJDM,BUS_DATE
  ; 
INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY
(
                                   CUST_NO                     --客户号
                                  ,EXG                         --交易所   
                                  ,CCY_CD                      --币种代码                                 
                                  ,SEC_CD                      --证券代码
								  ,TRD_COST                    --交易成本
                                  ,TRD_FEE_PAYOUT              --交易费用支出
                                  ,CMSN_PAYOUT                 --佣金支出
                                  ,INT_PAYOUT		           --利息支出
                                  ,OTH_PAYOUT                  --利息支出
                                  ,TOT_PRET   			       --总盈亏
                                  ,TOT_PRET_RMB   			   --RMB总盈亏
								  ,BUYIN_AMT                   --买入金额
                                  ,SELL_AMT                    --卖出金额
								  ,NEWST_MKTVAL                --最新市值
                                  ,PROD_CGY                    --产品类别								  
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT 
                NVL(NVL(t.CUST_NO,a1.CUST_NO),a2.CUST_NO)    as CUST_NO                     --客户号            
               ,NULL                                         as EXG                         --交易所   
               ,'RMB'                                        as CCY_CD                      --币种代码     
               ,NVL(NVL(t.PROD_CD,a1.PROD_CD),a2.PROD_CD)    as SEC_CD                      --证券代码
               ,SUM(NVL(a2.TRD_COST,0))                      as TRD_COST                    --交易成本
               ,SUM(NVL(a2.TRD_FEE_PAYOUT,0))                as TRD_FEE_PAYOUT              --交易费用支出
               ,SUM(0)                                       as CMSN_PAYOUT                 --佣金支出
               ,SUM(NVL(a2.INT_PAYOUT,0))                    as INT_PAYOUT		            --利息支出
               ,SUM(0)                                       as OTH_PAYOUT                  --其他支出
               ,SUM (CASE WHEN a3.JJDM IS NOT NULL
			             THEN 0 
						 ELSE (NVL(t.PROD_NEWST_MKTVAL,0)-NVL(a1.PROD_NEWST_MKTVAL,0)+NVL(a2.TRD_COST,0)+NVL(a2.TRD_FEE_PAYOUT,0)+NVL(a2.INT_PAYOUT,0) ) 
			             END)                                 as TOT_PRET   			        --总盈亏
               ,SUM (CASE WHEN a3.JJDM IS NOT NULL
			             THEN 0 
						 ELSE (NVL(t.PROD_NEWST_MKTVAL,0)-NVL(a1.PROD_NEWST_MKTVAL,0)+NVL(a2.TRD_COST,0)+NVL(a2.TRD_FEE_PAYOUT,0)+NVL(a2.INT_PAYOUT,0) ) 
			             END)                                 as TOT_PRET_RMB   			        --总盈亏
               ,SUM(NVL(a2.BUYIN_AMT,0))                     as BUYIN_AMT                   --买入金额
               ,SUM(NVL(a2.SELL_AMT,0))                      as SELL_AMT                    --卖出金额
			   ,SUM(NVL(t.PROD_NEWST_MKTVAL,0))              as NEWST_MKTVAL                --最新市值			   
			   ,NVL(NVL(t.PROD_CGY,a1.PROD_CGY),a2.PROD_CGY) as PROD_CGY                    --产品类别	 
 FROM     (SELECT   CUST_NO
                   ,PROD_CD
				   ,SUM(NVL(PROD_NEWST_MKTVAL,0)) as PROD_NEWST_MKTVAL
				   ,PROD_CGY
           FROM  DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS 
           WHERE BUS_DATE = %d{yyyyMMdd}
		   GROUP BY CUST_NO,PROD_CD,PROD_CGY
          ) t 
 FULL JOIN     DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP6  a1
 ON            t.CUST_NO = a1.CUST_NO
 AND           t.PROD_CD = a1.PROD_CD
 AND           t.PROD_CGY = a1.PROD_CGY
 FULL JOIN     DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP7     a2
 ON            NVL(t.CUST_NO,a1.CUST_NO) = a2.CUST_NO
 AND           NVL(t.PROD_CD,a1.PROD_CD) = a2.PROD_CD
 AND           NVL(t.PROD_CGY,a1.PROD_CGY) = a2.PROD_CGY
  
 LEFT JOIN  DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP9       a3
 ON  	    COALESCE(t.PROD_CD,a1.PROD_CD,a2.PROD_CD) =  a3.JJDM
 GROUP BY      CUST_NO,EXG,CCY_CD,SEC_CD,PROD_CGY ; 
 -------插入期权盈亏
 ---创建临时表
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP8;
  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP8
  as SELECT  a.CUST_NO,a.EXG,a.CCY_CD as CCY_CD,a.WRNT_CTC_CD
             ,SUM(CASE WHEN  a.WRNT_OPN_CP_FLG < > 'E'
				       AND   a.WRNT_BS_DRCT = '1'
					   AND   a.BUS_DATE  = %d{yyyyMMdd}
				       THEN  0-a.MTCH_AMT
				       WHEN  a.WRNT_OPN_CP_FLG < > 'E'
				       AND   a.WRNT_BS_DRCT = '2'
					   AND   a.BUS_DATE  = %d{yyyyMMdd}
				       THEN  a.MTCH_AMT				      
				       WHEN  a.END_DATE = %d{yyyyMMdd}
					   AND   a.WRNT_TP = 'C' 
			           AND   a.WRNT_OPN_CP_FLG = 'E'
				       AND   a.WRNT_BS_DRCT = '1'
					   THEN   0-MTCH_AMT
					   WHEN   a.END_DATE = %d{yyyyMMdd}
						AND   a.WRNT_TP = 'C' 
			            AND   a.WRNT_OPN_CP_FLG = 'E'
				        AND   a.WRNT_BS_DRCT = '2'
						THEN  a.MTCH_AMT
						WHEN  a.END_DATE = %d{yyyyMMdd}
						AND   a.WRNT_TP = 'P' 
			            AND   a.WRNT_OPN_CP_FLG = 'E'
				        AND   a.WRNT_BS_DRCT = '1'
						THEN  a.MTCH_AMT
						WHEN  a.END_DATE = %d{yyyyMMdd}
						 AND  a.WRNT_TP = 'P' 
			             AND  a.WRNT_OPN_CP_FLG = 'E'
				         AND  a.WRNT_BS_DRCT = '2'
						 THEN 0-a.MTCH_AMT
				         ELSE 0
					    END
				         )  as TRD_COST
				,SUM(CAST(CASE WHEN a.END_DATE = %d{yyyyMMdd}
						  AND  a.WRNT_TP = 'C' 
			              AND a.WRNT_OPN_CP_FLG = 'E'
				          AND a.WRNT_BS_DRCT = '1'
						  THEN a.SEC_QTY*b.newst_prc
						  WHEN a.END_DATE = %d{yyyyMMdd}
						  AND  a.WRNT_TP = 'C' 
			              AND a.WRNT_OPN_CP_FLG = 'E'
				          AND a.WRNT_BS_DRCT = '2'
						  THEN 0-a.SEC_QTY*b.newst_prc
						  WHEN a.END_DATE = %d{yyyyMMdd}
						  AND  a.WRNT_TP = 'P' 
			              AND a.WRNT_OPN_CP_FLG = 'E'
				          AND a.WRNT_BS_DRCT = '1'
						  THEN 0-a.SEC_QTY*b.newst_prc
						  WHEN a.END_DATE = %d{yyyyMMdd}
						  AND  a.WRNT_TP = 'P' 
			              AND a.WRNT_OPN_CP_FLG = 'E'
				          AND a.WRNT_BS_DRCT = '2'
						  THEN a.SEC_QTY*b.newst_prc
				          ELSE 0
						  END as DECIMAL(38,2))
				    ) as STK_MKTVAL                
                ,SUM(CASE WHEN a.WRNT_OPN_CP_FLG < > 'E' AND a.BUS_DATE = %d{yyyyMMdd}
                          THEN 0-S1
                          WHEN a.WRNT_OPN_CP_FLG = 'E' AND a.END_DATE = %d{yyyyMMdd}
                          THEN 0-S1
                          ELSE 0
                          END)	as CMSN_PAYOUT
               ,SUM(CASE WHEN a.WRNT_BS_DRCT = '1'
			             THEN a.MTCH_AMT
						 else 0
						 END 
			       )     as BUYIN_AMT
               ,SUM(CASE WHEN a.WRNT_BS_DRCT = '2'
			             THEN a.MTCH_AMT
						 else 0
						 END 
			        )     as SELL_AMT						  
   FROM      DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS  a
   LEFT JOIN DDW_PROD.T_DDW_PUB_QOT                  b
   ON        a.EXG = b.EXG
   AND       a.SEC_CD = b.CD
   AND       a.BUS_DATE = b.BUS_DATE
   WHERE     (a.BUS_DATE = %d{yyyyMMdd} OR a.END_DATE = %d{yyyyMMdd})
   GROUP BY a.CUST_NO,a.EXG,a.CCY_CD,a.WRNT_CTC_CD;
 ----插入数据
 INSERT INTO DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY
(
                                   CUST_NO                     --客户号
                                  ,EXG                         --交易所   
                                  ,CCY_CD                      --币种代码                                 
                                  ,SEC_CD                      --证券代码
								  ,TRD_COST                    --交易成本
                                  ,TRD_FEE_PAYOUT              --交易费用支出
                                  ,CMSN_PAYOUT                 --佣金支出
                                  ,INT_PAYOUT		           --利息支出
                                  ,OTH_PAYOUT                  --利息支出
                                  ,TOT_PRET   			       --总盈亏
                                  ,TOT_PRET_RMB   			   --总盈亏
								   ,BUYIN_AMT                   --买入金额
                                  ,SELL_AMT                    --卖出金额
								  ,NEWST_MKTVAL                --最新市值
                                  ,PROD_CGY                    --产品类别								  
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT 
                NVL(t.CUST_NO,a1.CUST_NO)          as CUST_NO                     --客户号            
               ,NVL(t.EXG,a1.EXG)                  as EXG                         --交易所   
               ,NVL(t.CCY_CD,a1.CCY_CD)            as CCY_CD                      --币种代码     
               ,NVL(t.WRNT_CTC_CD,a1.WRNT_CTC_CD)   as SEC_CD                      --证券代码
               ,SUM(NVL(a1.TRD_COST,0))            as TRD_COST                    --交易成本
               ,SUM(0)                             as TRD_FEE_PAYOUT              --交易费用支出
               ,SUM(NVL(a1.CMSN_PAYOUT,0))         as CMSN_PAYOUT                 --佣金支出
               ,SUM(0)                             as INT_PAYOUT		            --利息支出
               ,SUM(0)                             as OTH_PAYOUT                  --其他支出
               ,SUM(NVL(t.NEWST_MKTVAL,0)
			   +NVL(a1.TRD_COST,0) 
			   +NVL(a1.CMSN_PAYOUT,0)
			   +NVL(a1.STK_MKTVAL,0) )             as TOT_PRET   			        --总盈亏
              ,SUM(NVL(t.NEWST_MKTVAL,0)
			   +NVL(a1.TRD_COST,0) 
			   +NVL(a1.CMSN_PAYOUT,0)
			   +NVL(a1.STK_MKTVAL,0) )             as TOT_PRET_RMB   			        --总盈亏
              ,SUM(NVL(a1.BUYIN_AMT,0))            as BUYIN_AMT                --买入金额
              ,SUM(NVL(a1.SELL_AMT,0))             as SELL_AMT             --卖出金额
			  ,SUM(NVL(t.WRNT_NEWST_MKTVAL,0))      as NEWST_MKTVAL                --最新市值			   
			    ,10                                as PROD_CGY                    --产品类别				 
  
 FROM  ( SELECT NVL(a.CUST_NO,b.CUST_NO) as CUST_NO
               ,NVL(a.EXG,b.EXG)         as EXG
			   ,NVL(a.CCY_CD,b.CCY_CD)   as CCY_CD
			   ,NVL(a.WRNT_CTC_CD,b.WRNT_CTC_CD) as WRNT_CTC_CD
			   ,NVL(a.WRNT_NEWST_MKTVAL,0)-NVL(b.WRNT_NEWST_MKTVAL,0) as NEWST_MKTVAL
			   ,NVL(a.WRNT_NEWST_MKTVAL,0)   as WRNT_NEWST_MKTVAL
         FROM (SELECT     CUST_NO
		                  ,EXG
						  ,CCY_CD
						  ,WRNT_CTC_CD
						  ,SUM(WRNT_NEWST_MKTVAL) as WRNT_NEWST_MKTVAL
                FROM       DDW_PROD.T_DDW_F00_AST_WRNT_HLD_DTL_HIS
                WHERE      BUS_DATE  = %d{yyyyMMdd}
               GROUP BY      CUST_NO,EXG,CCY_CD,WRNT_CTC_CD
              ) a
	   FULL JOIN (SELECT     CUST_NO,EXG,CCY_CD,WRNT_CTC_CD,SUM(WRNT_NEWST_MKTVAL) as WRNT_NEWST_MKTVAL
                  FROM      DDW_PROD.T_DDW_F00_AST_WRNT_HLD_DTL_HIS a
                  WHERE      EXISTS (SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE b
		                     WHERE  b.BUS_DATE = %d{yyyyMMdd}
							 AND    a.BUS_DATE = b.LST_TRD_D
							 AND    b.TRD_DT = %d{yyyyMMdd}
							         )
                GROUP BY      CUST_NO,EXG,CCY_CD,WRNT_CTC_CD
	             )   b
	   ON  a.CUST_NO = b.CUST_NO
	   AND a.EXG = b.EXG
	   AND a.WRNT_CTC_CD = b.WRNT_CTC_CD
	   )      t
 FULL JOIN DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP8 a1
 ON        t.CUST_NO = a1.CUST_NO
 AND       t.EXG = a1.EXG
 AND       t.WRNT_CTC_CD = a1.WRNT_CTC_CD
 WHERE      SUBSTR(NVL(t.CUST_NO,a1.CUST_NO),1,1) <> '9'
 GROUP BY CUST_NO,EXG,CCY_CD,SEC_CD,PROD_CGY;
 ----
 
  ----期权插入完成
  
    
   
   
   ----删除临时表
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP7;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP3;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP2;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP1;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP4;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP5;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP6;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP8;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP10;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP0;
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY_TEMP9;
   
-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_STATMT_PER_PRET_STK_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY;
   
--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:外部机构代码表                                                                       */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  

TRUNCATE TABLE EDW_PROD.T_EDW_T03_TWBJGDM;
------插入数据
---------------- 插入集中交易数据 -----------------------
 INSERT INTO EDW_PROD.T_EDW_T03_TWBJGDM
 (
 								 WBJGDM                              --外部机构代码                             
 								,WBJGMC                              --外部机构名称                             
 								,WBJGQC                              --外部机构全称                             
 								,YWFW                                --业务范围                               
 								,YYBFW                               --营业部范围                              
 								,XTBS                                --系统标识                               
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
 								 t.JGDM                                as WBJGDM                              --机构代码                                
 								,t.JGMC                                as WBJGMC                              --机构名称                                
 								,t.JGQC                                as WBJGQC                              --机构全称                                
 								,t.YWFW                                as YWFW                                --业务范围                                
 								,t.YYBFW                               as YYBFW                               --营业部范围                               
 								,'JZJY'                                as XTBS                                --系统标识                                    
 FROM JZJYCX.ACCOUNT_TWBJGDM t
 WHERE t.DT = '%d{yyyyMMdd}';
 
------插入集中交易数据结束------------------


------插入融资融券数据开始------------------
 INSERT  INTO EDW_PROD.T_EDW_T03_TWBJGDM
 (
                                     WBJGDM                              --外部机构代码                             
                                    ,WBJGMC                              --外部机构名称                             
                                    ,WBJGQC                              --外部机构全称                             
                                    ,YWFW                                --业务范围                               
                                    ,YYBFW                               --营业部范围                              
                                    ,XTBS                                --系统标识                               
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.JGDM                            as WBJGDM                              --机构代码                                
                                    ,t.JGMC                            as WBJGMC                              --机构名称                                
                                    ,t.JGQC                            as WBJGQC                              --机构全称                                
                                    ,t.YWFW                            as YWFW                                --业务范围                                
                                    ,t.YYBFW                           as YYBFW                               --营业部范围                               
                                    ,'RZRQ'                            as XTBS                                --系统标识                                    
 FROM RZRQCX.ACCOUNT_TWBJGDM t
 WHERE t.DT = '%d{yyyyMMdd}';

------插入融资融券数据结束------------------ 

-------------------------------	插入个股期权数据---------------------------------
 INSERT INTO EDW_PROD.T_EDW_T03_TWBJGDM
 (
                                     WBJGDM                             --外部机构代码                             
                                    ,WBJGMC                              --外部机构名称                             
                                    ,WBJGQC                              --外部机构全称                             
                                    ,YWFW                                --业务范围                               
                                    ,YYBFW                               --营业部范围                              
                                    ,XTBS                                --系统标识                               
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.JGDM                                as WBJGDM                              --机构代码                                
                                    ,t.JGMC                                as WBJGMC                              --机构名称                                
                                    ,t.JGQC                                as WBJGQC                              --机构全称                                
                                    ,t.YWFW                                as YWFW                                --业务范围                                
                                    ,t.YYBFW                               as YYBFW                               --营业部范围                               
                                    ,'GGQQ'                                as XTBS                                --                                    
 FROM GGQQCX.ACCOUNT_TWBJGDM t 
 WHERE t.DT = '%d{yyyyMMdd}';
-------------------------------	插入个股期权数据结束-------------------------------
----------------结束插入 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T03_TWBJGDM',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T03_TWBJGDM; 
--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:TA信息表                                                                             */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T03_TOF_TAXX;
------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T03_TOF_TAXX
 (
 								 TADM                                --TA代码                               
 								,TAJGMC                              --TA机构名称                             
 								,TAJGJC                              --TA机构简称                             
 								,XSDM_c                              --销售代码                               
 								,ZHFHFSXG                            --允许修改帐户分红方式                         
 								,TABM                                --基金公司编号                             
 								,SIDMZH                              --允许一个身份证开多个基金账户      
 								,XTBS								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
 								 t.TADM                                as TADM                                --TA代码                                
 								,t.TAJGMC                              as TAJGMC                              --TA机构名称                              
 								,t.TAJGJC                              as TAJGJC                              --TA机构简称                              
 								,t.XSDM                                as XSDM_c                              --销售代码                                
 								,t.ZHFHFSXG                            as ZHFHFSXG                            --允许修改帐户分红方式                          
 								,t.TABM                                as TABM                                --基金公司编号                              
 								,t.SIDMZH                              as SIDMZH                              --允许一个身份证开多个基金账户        
 								,'JZJY'								   
 FROM 		JZJYCX.OFS_TOF_TAXX 			t 
 WHERE		t.DT = '%d{yyyyMMdd}';
-------插入数据结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T03_TOF_TAXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T03_TOF_TAXX; 
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:转融通交易参数表                                                                  */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
   TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZRT_JYCS;
-----插入数据开始---------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZRT_JYCS
(
                                    ZRT_YWLX                            --转融通业务类型                            
                                   ,ZRT_JYLB                            --转融通交易类别                            
                                   ,JYS                                 --交易所                                
                                   ,JYJS                                --交易基数                               
                                   ,SBSLXX                              --最小申报数量                             
                                   ,SBSLSX                              --单笔数量申报上限                           
                                   ,SBSLHZSX                            --累计数量申报上限                           
                                   ,SBJEXX                              --最小申报金额                             
                                   ,SBJESX                              --单笔金额申报上限                           
                                   ,SBJEHZSX                            --累计金额申报上限                           
                                   ,ZQLB                                --证券类别      
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.YWLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZRT_YWLX                            --业务类型                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZRT_JYLB                            --交易类别                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.JYJS                                as JYJS                                --交易基数                                
                                   ,t.SBSLXX                              as SBSLXX                              --最小申报数量                              
                                   ,t.SBSLSX                              as SBSLSX                              --单笔数量申报上限                            
                                   ,t.SBSLHZSX                            as SBSLHZSX                            --累计数量申报上限                            
                                   ,t.SBJEXX                              as SBJEXX                              --最小申报金额                              
                                   ,t.SBJESX                              as SBJESX                              --单笔金额申报上限                            
                                   ,t.SBJEHZSX                            as SBJEHZSX                            --累计金额申报上限                            
                                   ,t.ZQLB                                as ZQLB                                --证券类别   
                                   ,'RZRQ'                                as XTBS								   
 FROM           RZRQCX.ZRT_TZRT_JYCS                       t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING      t1 
 ON             t1.DMLX = 'ZRT_YWLX'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.YWLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING      t2 
 ON             t2.DMLX = 'ZRT_JYLB'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.JYLB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---------插入数据结束----------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZRT_JYCS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

invalidate metadata EDW_PROD.T_EDW_T02_TZRT_JYCS;
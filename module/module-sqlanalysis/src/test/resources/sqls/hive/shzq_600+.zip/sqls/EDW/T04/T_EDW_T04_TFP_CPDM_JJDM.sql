 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:金融产品代码表_基金代码                                                                 */
  --/* 创建人:段智泓                                                                             */
  --/* 创建时间:2018-09-06                                                                 */ 

-------插入数据开始--------------
TRUNCATE TABLE EDW_PROD.T_EDW_T04_TFP_CPDM_JJDM;

INSERT OVERWRITE EDW_PROD.T_EDW_T04_TFP_CPDM_JJDM
(
                       ID          --ID
                      ,CPID        --产品ID
                      ,CPDM        --产品代码
                      ,FXJG        --发行机构
                      ,JGDM        --机构代码
                      ,JJDM        --基金代码
                      ,JJDM_WB     --基金代码外部
                      ,JJMC        --基金名称
                      ,TADM        --TA代码
                      ,TADM_WB     --TA代码_外部
                      ,XTBS        --系统标识
)
PARTITION( bus_date = %d{yyyyMMdd})
SELECT                           
                       ID         AS ID       --ID
                      ,CPID       AS CPID     --产品ID
                      ,CPDM       AS CPDM     --产品代码
                      ,FXJG       AS FXJG     --发行机构
                      ,JGDM       AS JGDM     --机构代码
                      ,JJDM       AS JJDM     --基金代码
                      ,JJDM_WB    AS JJDM_WB  --基金代码外部
                      ,JJMC       AS JJMC     --基金名称
                      ,TADM       AS TADM     --TA代码
                      ,TADM_WB    AS TADM_WB  --TA代码_外部
					  ,'OTC'      AS XTBS
FROM            OTCCX.FPSS_TFP_CPDM_JJDM t
WHERE 	        t.DT = '%d{yyyyMMdd}'
;
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TFP_CPDM_JJDM',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
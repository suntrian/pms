--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:ETF成分股信息表                                                                      */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
  TRUNCATE TABLE EDW_PROD.T_EDW_T04_TETF_CFGXX;
------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TETF_CFGXX
 (
                                     JYS                                 --交易所                                
                                    ,ZQDM                                --证券代码                               
                                    ,JJDM                                --基金代码                               
                                    ,ZQMC                                --证券名称                               
                                    ,GPSL                                --股票数量                               
                                    ,TDBZ                                --替代标志                               
                                    ,YJBL                                --溢价比例                               
                                    ,TDJE                                --替代金额  
                                    ,XTBS								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.JYS                                 as JYS                                 --交易所                                 
                                    ,t.JJDM                                as ZQDM                                --基金代码                                
                                    ,t.ZQDM                                as JJDM                                --证券代码                                
                                    ,t.ZQMC                                as ZQMC                                --证券名称                                
                                    ,t.GPSL                                as GPSL                                --股票数量                                
                                    ,t.TDBZ                                as TDBZ                                --替代标志                                
                                    ,t.YJBL                                as YJBL                                --溢价比例                                
                                    ,t.TDJE                                as TDJE                                --替代金额 
                                    ,'JZJY'								   
 FROM 		JZJYCX.SECURITIES_TETF_CFGXX 		t 
 WHERE		t.DT = '%d{yyyyMMdd}';
-------插入数据结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TETF_CFGXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;


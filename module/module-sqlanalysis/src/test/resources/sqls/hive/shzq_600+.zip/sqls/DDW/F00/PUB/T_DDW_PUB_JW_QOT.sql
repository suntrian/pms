 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:行情表日表                                                                       */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-05-08                                                                        */ 

-- 交易市场(1:场内基金,股票,债券。2:场外基金。3:股票期权行情,4,ETF期权行情,5.上投资基金，6.开放式，ETF基金,7,聚源发行没上市地)---
-----删除今天的数据---
 ALTER TABLE DDW_PROD.T_DDW_PUB_JW_QOT DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ; 
-----
	
	
	
---插入数据--
 INSERT INTO DDW_PROD.T_DDW_PUB_JW_QOT
 (
                                  CD                --代码 
                                 ,EXG               --交易所 
                                 ,NEWST_PRC         --最新价 
                                 ,TRD_MKT           --交易市场								 
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT        DISTINCT
                    a1.secucode                      as CD                --代码 
                    ,'SH'                        as EXG               --交易所
                    ,ROUND(CAST(CASE WHEN t.ClosePrice  = 0
					      THEN t.PrevClosePrice
						  ELSE t.ClosePrice 
						  END as DECIMAL(38,4)),3)      as NEWST_PRC         --最新价                                                                           
                    ,1                               as TRD_MKT           --交易市场
  FROM         FUNDEXT.DBO_LC_STIBDAILYQUOTE t
  LEFT JOIN     FUNDEXT.DBO_SECUMAIN         a1
  ON            t.INNERCODE = a1.INNERCODE
  AND           a1.DT = '%d{yyyyMMdd}'
  AND           a1.secumarket IN (83)
  LEFT JOIN     (SELECT  INNERCODE
                       ,MAX(tradingday) as tradingday
                FROM FUNDEXT.DBO_LC_STIBDAILYQUOTE 
				WHERE LENGTH(TRIM(NVL(tradingday,'')))>0
				AND CONCAt(substr(tradingday,1,4),substr(tradingday,6,2),substr(tradingday,9,2) )  < = '%d{yyyyMMdd}'
				GROUP BY INNERCODE
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.tradingday = a2.tradingday  
  --AND           ((a1.secumarket = 83 AND SUBSTR(a1.SECUCODE,1,3) IN ('501','502','500','505','519','510','511','512','513','518','519') )
  --               OR (a1.secumarket = 90 AND (SUBSTR(a1.SECUCODE,1,3) IN ('150','151','159','184') OR SUBSTR(a1.SECUCODE,1,2) = '16')))
  WHERE         a1.secumarket IN (83)    
  AND           LENGTH(TRIM(NVL(t.tradingday,'')))>0
  AND           a2.INNERCODE IS NOT NULL 
  UNION 
 SELECT        DISTINCT
                    a1.secucode                      as CD                --代码 
                    ,CASE WHEN SUBSTR(a1.secucode,1,3) = '900' AND a1.secumarket = 83
					      THEN 'HB'
						  WHEN SUBSTR(a1.secucode,1,3) IN  ('200','238','299') AND a1.secumarket = 90
					      THEN 'SB'
						  WHEN a1.secumarket = 83
 					      THEN 'SH'
						  ELSE 'SZ'
						  END                        as EXG               --交易所
                    ,ROUND(CAST(CASE WHEN t.ClosePrice  = 0
					      THEN t.PrevClosePrice
						  ELSE t.ClosePrice 
						  END as DECIMAL(38,4)),3)      as NEWST_PRC         --最新价                                                                           
                    ,1                               as TRD_MKT           --交易市场
  FROM          FUNDEXT.DBO_QT_DAILYQUOTE     t
  LEFT JOIN     FUNDEXT.DBO_SECUMAIN         a1
  ON            t.INNERCODE = a1.INNERCODE
  AND           a1.DT = '%d{yyyyMMdd}'
  AND           a1.secumarket IN (83,90)
  LEFT JOIN     (SELECT  INNERCODE
                       ,MAX(tradingday) as tradingday
                FROM FUNDEXT.DBO_QT_DAILYQUOTE 
				WHERE LENGTH(TRIM(NVL(tradingday,'')))>0
				AND CONCAt(substr(tradingday,1,4),substr(tradingday,6,2),substr(tradingday,9,2) )  < = '%d{yyyyMMdd}'
				GROUP BY INNERCODE
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.tradingday = a2.tradingday  
  --AND           ((a1.secumarket = 83 AND SUBSTR(a1.SECUCODE,1,3) IN ('501','502','500','505','519','510','511','512','513','518','519') )
  --               OR (a1.secumarket = 90 AND (SUBSTR(a1.SECUCODE,1,3) IN ('150','151','159','184') OR SUBSTR(a1.SECUCODE,1,2) = '16')))
  WHERE         a1.secumarket IN (83,90)    
  AND           LENGTH(TRIM(NVL(t.tradingday,'')))>0
  AND           a2.INNERCODE IS NOT NULL 
 UNION 
 SELECT        DISTINCT
                    a1.secucodeafter                      as CD                --代码 
                    ,'SH'                       as EXG               --交易所
                    ,ROUND(CAST(CASE WHEN t.ClosePrice  = 0
					      THEN t.PrevClosePrice
						  ELSE t.ClosePrice 
						  END as DECIMAL(38,4)),3)      as NEWST_PRC         --最新价                                                                           
                    ,1                               as TRD_MKT           --交易市场
  FROM          FUNDEXT.DBO_LC_STIBDAILYQUOTE    t
  LEFT JOIN     FUNDEXT.DBO_LC_STIBCODECHANGE       a1
  ON            t.INNERCODE = a1.INNERCODE
  AND             a1.DT = '%d{yyyyMMdd}'
  LEFT JOIN     (SELECT  INNERCODE
                       ,MAX(tradingday) as tradingday
                FROM FUNDEXT.DBO_LC_STIBDAILYQUOTE
				WHERE LENGTH(TRIM(NVL(tradingday,'')))>0
				AND CONCAt(substr(tradingday,1,4),substr(tradingday,6,2),substr(tradingday,9,2) )  < = '%d{yyyyMMdd}'
				GROUP BY INNERCODE
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.tradingday = a2.tradingday
  WHERE          NOT EXISTS   (SELECT 1 FROM  FUNDEXT.DBO_SECUMAIN b WHERE a1.secucodeafter = b.SECUCODE AND a1.DT = b.DT AND  b.secumarket = 83 )  
  AND           LENGTH(TRIM(NVL(t.tradingday,'')))>0
  AND           a2.INNERCODE IS NOT NULL 
union
SELECT        DISTINCT
                    a1.secucode                      as CD                --代码 
                    ,CASE WHEN SUBSTR(a1.secucode,1,3) = '900' AND a1.secumarket = 83
					      THEN 'HB'
						  WHEN SUBSTR(a1.secucode,1,3) IN  ('200','238','299') AND a1.secumarket = 90
					      THEN 'SB'
						  WHEN a1.secumarket = 83
 					      THEN 'SH'
						  ELSE 'SZ'
						  END                        as EXG               --交易所
                    ,ROUND(CAST(CASE WHEN t.ClosePrice  = 0
					      THEN t.PrevClosePrice
						  ELSE t.ClosePrice 
						  END as DECIMAL(38,4)),3)      as NEWST_PRC         --最新价                                                                           
                    ,1                               as TRD_MKT           --交易市场
  FROM          FUNDEXT.DBO_QT_DAILYQUOTE     t
  LEFT JOIN     FUNDEXT.DBO_LC_CODECHANGE       a1
  ON            t.INNERCODE = a1.INNERCODE
  AND             a1.DT = '%d{yyyyMMdd}'
  AND  ((a1.secumarket = 83 AND (SUBSTR(a1.secucode,1,3) IN ('360','600','601','603') OR SUBSTR(a1.secucode,1,4) IN ('5800','5900')))
            OR (a1.secumarket = 90 AND SUBSTR(a1.secucode,1,3) IN ('000','001','002','003','300','030','031','038','140')))   
  LEFT JOIN     (SELECT  INNERCODE
                       ,MAX(tradingday) as tradingday
                FROM FUNDEXT.DBO_QT_DAILYQUOTE 
				WHERE LENGTH(TRIM(NVL(tradingday,'')))>0
				AND CONCAt(substr(tradingday,1,4),substr(tradingday,6,2),substr(tradingday,9,2) )  < = '%d{yyyyMMdd}'
				GROUP BY INNERCODE
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.tradingday = a2.tradingday
  WHERE         a1.secumarket IN (83,90)            
  AND NOT EXISTS   (SELECT 1 FROM  FUNDEXT.DBO_SECUMAIN b WHERE a1.SECUCODE = b.SECUCODE AND a1.DT = b.DT AND a1.secumarket = b.secumarket )  
  AND           LENGTH(TRIM(NVL(t.tradingday,'')))>0
  AND           a2.INNERCODE IS NOT NULL 
 AND  ((a1.secumarket = 83 AND (SUBSTR(a1.secucode,1,3) IN ('360','600','601','603') OR SUBSTR(a1.secucode,1,4) IN ('5800','5900')))
            OR (a1.secumarket = 90 AND SUBSTR(a1.secucode,1,3) IN ('000','001','002','003','300','030','031','038','140')))     
  UNION ALL
  SELECT        DISTINCT
                    a1.secucode                      as CD                --代码 
                    ,'SH'                        as EXG               --交易所
                    ,ROUND(CAST(CASE WHEN t.ClosePrice  = 0
					      THEN t.PrevClosePrice
						  ELSE t.ClosePrice 
						  END as DECIMAL(38,4)),3)      as NEWST_PRC         --最新价                                                                           
                    ,1                               as TRD_MKT           --交易市场
  FROM          FUNDEXT.DBO_LC_STIBDAILYQUOTE     t
  LEFT JOIN     FUNDEXT.DBO_SECUMAIN         a1
  ON            t.INNERCODE = a1.INNERCODE
  AND           a1.DT = '%d{yyyyMMdd}'
  AND           a1.secumarket IN (83,90)
  LEFT JOIN     (SELECT  INNERCODE
                       ,MAX(tradingday) as tradingday
                FROM FUNDEXT.DBO_LC_STIBDAILYQUOTE 
				WHERE LENGTH(TRIM(NVL(tradingday,'')))>0
				AND CONCAt(substr(tradingday,1,4),substr(tradingday,6,2),substr(tradingday,9,2) )  < = '%d{yyyyMMdd}'
				GROUP BY INNERCODE
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.tradingday = a2.tradingday  
  --AND           ((a1.secumarket = 83 AND SUBSTR(a1.SECUCODE,1,3) IN ('501','502','500','505','519','510','511','512','513','518','519') )
  --               OR (a1.secumarket = 90 AND (SUBSTR(a1.SECUCODE,1,3) IN ('150','151','159','184') OR SUBSTR(a1.SECUCODE,1,2) = '16')))
  WHERE         a1.secumarket IN (83)    
  AND           LENGTH(TRIM(NVL(t.tradingday,'')))>0
  AND           a2.INNERCODE IS NOT NULL
  ;
  
-----三板行情----
 INSERT INTO DDW_PROD.T_DDW_PUB_JW_QOT
 (
                                  CD                --代码 
                                 ,EXG               --交易所 
                                 ,NEWST_PRC         --最新价  
                                 ,TRD_MKT           --交易市场								 
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                    a1.secucode                      as CD                --代码 
                    ,CASE WHEN SUBSTR(a1.secucode,1,2) = '42' 
					      THEN 'TU'
						  ELSE 'TA'
						  END                        as EXG               --交易所
                    ,ROUND(CASE WHEN t.ClosePrice  = 0
					      THEN t.PrevClosePrice
						  ELSE t.ClosePrice 
						  END ,3)                    as NEWST_PRC         --最新价                                                                           
                   ,1                                as TRD_MKT           --交易市场
  FROM          FUNDEXT.DBO_NQ_DAILYQUOTE     t
  LEFT JOIN     FUNDEXT.DBO_NQ_SECUMAIN       a1
  ON            t.INNERCODE = a1.INNERCODE
  AND            t.DT = a1.DT 
  LEFT JOIN     (SELECT  INNERCODE
                       ,MAX(tradingday) as tradingday
                FROM FUNDEXT.DBO_NQ_DAILYQUOTE 
				WHERE LENGTH(TRIM(NVL(tradingday,'')))>0
				AND   DT = '%d{yyyyMMdd}'
				AND CONCAt(substr(tradingday,1,4),substr(tradingday,6,2),substr(tradingday,9,2) )  < = '%d{yyyyMMdd}'
				GROUP BY INNERCODE
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.tradingday = a2.tradingday
  WHERE         a1.secumarket = 81 
  AND           t.DT  = '%d{yyyyMMdd}'  
  AND           LENGTH(TRIM(NVL(t.tradingday,'')))>0
  AND           a2.INNERCODE IS NOT NULL  
  UNION  
   SELECT 
                    a1.secucode                      as CD                --代码 
                    ,CASE WHEN SUBSTR(a1.secucode,1,2) = '42' 
					      THEN 'TU'
						  ELSE 'TA'
						  END                        as EXG               --交易所
                    ,ROUND(CASE WHEN t.ClosePrice  = 0
					      THEN t.PrevClosePrice
						  ELSE t.ClosePrice 
						  END ,3)                    as NEWST_PRC         --最新价                                                                           
                   ,1                                as TRD_MKT           --交易市场
  FROM          FUNDEXT.DBO_NQ_DAILYQUOTE     t
  LEFT JOIN     FUNDEXT.DBO_LC_CODECHANGE       a1
  ON            t.INNERCODE = a1.INNERCODE
  AND            t.DT = a1.DT 
  AND           a1.secumarket = 81
  AND           SUBSTR(a1.secucode,1,1) IN ('4','8')
  LEFT JOIN     (SELECT  INNERCODE
                       ,MAX(tradingday) as tradingday
                FROM FUNDEXT.DBO_NQ_DAILYQUOTE 
				WHERE LENGTH(TRIM(NVL(tradingday,'')))>0
				AND   DT = '%d{yyyyMMdd}'
				AND CONCAt(substr(tradingday,1,4),substr(tradingday,6,2),substr(tradingday,9,2) )  < = '%d{yyyyMMdd}'
				GROUP BY INNERCODE
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.tradingday = a2.tradingday
  WHERE         a1.secumarket = 81 
  AND NOT EXISTS   (SELECT 1 FROM  FUNDEXT.DBO_NQ_SECUMAIN b WHERE a1.SECUCODE = b.SECUCODE AND a1.DT = b.DT )
  AND           t.DT  = '%d{yyyyMMdd}'  
  AND           LENGTH(TRIM(NVL(t.tradingday,'')))>0
  AND           a2.INNERCODE IS NOT NULL 
  ;
  ----港股行情--
 INSERT INTO DDW_PROD.T_DDW_PUB_JW_QOT
 (
                                  CD                --代码 
                                 ,EXG               --交易所 
                                 ,NEWST_PRC         --最新价   
                                 ,TRD_MKT           --交易市场								 
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                    a1.secucode                      as CD                --代码 
                    ,'HK'                       as EXG               --交易所
                    ,ROUND(CASE WHEN t.ClosePrice  = 0
					      THEN t.PrevClosePrice
						  ELSE t.ClosePrice 
						  END ,3)                     as NEWST_PRC         --最新价   
                    ,1                                as TRD_MKT           --交易市场						  
  FROM          FUNDEXT.DBO_QT_HKDAILYQUOTE     t
  LEFT JOIN     FUNDEXT.DBO_HK_SECUMAIN       a1
  ON            t.INNERCODE = a1.INNERCODE
  AND           a1.DT = '%d{yyyyMMdd}'
  LEFT JOIN     (SELECT  INNERCODE
                       ,MAX(tradingday) as tradingday
                FROM FUNDEXT.DBO_QT_HKDAILYQUOTE 
				WHERE LENGTH(TRIM(NVL(tradingday,'')))>0
				AND CONCAt(substr(tradingday,1,4),substr(tradingday,6,2),substr(tradingday,9,2) )  < = '%d{yyyyMMdd}'
				GROUP BY INNERCODE
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.tradingday = a2.tradingday
  WHERE         a1.secumarket = 72 
  AND          CONCAt(substr(t.tradingday,1,4),substr(t.tradingday,6,2),substr(t.tradingday,9,2) ) = t.DT
  AND           LENGTH(TRIM(NVL(t.tradingday,'')))>0
  AND           a2.INNERCODE IS NOT NULL 
  AND           SUBSTR(a1.secucode,1,1) = '0' 
  AND         (t.ClosePrice  <> 0 OR t.PrevClosePrice <>0) 
  UNION ALL  
  SELECT 
                    a1.secucode                      as CD                --代码 
                    ,'SK'                       as EXG               --交易所
                    ,ROUND(CASE WHEN t.ClosePrice  = 0
					      THEN t.PrevClosePrice
						  ELSE t.ClosePrice 
						  END ,3)                     as NEWST_PRC         --最新价   
                    ,1                                as TRD_MKT           --交易市场						  
  FROM          FUNDEXT.DBO_QT_HKDAILYQUOTE     t
  LEFT JOIN     FUNDEXT.DBO_HK_SECUMAIN       a1
  ON            t.INNERCODE = a1.INNERCODE
  AND           a1.DT = '%d{yyyyMMdd}'
  LEFT JOIN     (SELECT  INNERCODE
                       ,MAX(tradingday) as tradingday
                FROM FUNDEXT.DBO_QT_HKDAILYQUOTE 
				WHERE LENGTH(TRIM(NVL(tradingday,'')))>0
				AND CONCAt(substr(tradingday,1,4),substr(tradingday,6,2),substr(tradingday,9,2) )  < = '%d{yyyyMMdd}'
				GROUP BY INNERCODE
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.tradingday = a2.tradingday
  WHERE         a1.secumarket = 72 
  AND          CONCAt(substr(t.tradingday,1,4),substr(t.tradingday,6,2),substr(t.tradingday,9,2) ) = t.DT
  AND           LENGTH(TRIM(NVL(t.tradingday,'')))>0
  AND           a2.INNERCODE IS NOT NULL 
  AND           SUBSTR(a1.secucode,1,1) = '0' 
  AND         (t.ClosePrice  <> 0 OR t.PrevClosePrice <>0)   
  ;
  
  ---上证基金通
  INSERT INTO DDW_PROD.T_DDW_PUB_JW_QOT
 (
                                  CD                --代码 
                                 ,EXG               --交易所 
                                 ,NEWST_PRC         --最新价   
                                 ,TRD_MKT           --交易市场								 
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                    a1.SecurityCode                  as CD                --代码 
                    ,'SH'                            as EXG               --交易所
                    ,ROUND(t.unitnv ,3)              as NEWST_PRC         --最新价   
                    ,5                               as TRD_MKT           --交易市场						  
  FROM          FUNDEXT.DBO_MF_NetValue     t
  LEFT JOIN     FUNDEXT.DBO_MF_FundArchives       a1
  ON            t.INNERCODE = a1.INNERCODE
  AND           t.DT = a1.DT
  LEFT JOIN     (SELECT  a.INNERCODE
                        ,b.infopubldate      as infopubldate
					    ,a.enddate             as enddate
                FROM (SELECT INNERCODE
							 ,MAX(enddate) as enddate
                             ,DT
                      FROM	 FUNDEXT.DBO_MF_NetValue
					  WHERE CONCAt(substr(infopubldate,1,4),substr(infopubldate,6,2),substr(infopubldate,9,2) )  < = '%d{yyyyMMdd}'
					  AND    DT = '%d{yyyyMMdd}'
					  AND    LENGTH(TRIM(NVL(infopubldate,'')))>0
					  GROUP BY INNERCODE,DT ) a 
					  LEFT JOIN 
					  (SELECT INNERCODE
				             ,MAX(infopubldate) as infopubldate
							 ,enddate as enddate
                             ,DT
                      FROM	 FUNDEXT.DBO_MF_NetValue
					  WHERE CONCAt(substr(infopubldate,1,4),substr(infopubldate,6,2),substr(infopubldate,9,2) )  < = '%d{yyyyMMdd}'
					  AND    DT = '%d{yyyyMMdd}'
					  AND    LENGTH(TRIM(NVL(infopubldate,'')))>0
					  GROUP BY INNERCODE,enddate,DT
					  )    b
					  ON   a.INNERCODE = b.INNERCODE
					  AND  a.enddate = b.enddate
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.infopubldate = a2.infopubldate
  AND           t.enddate = a2.enddate
  WHERE         t.DT = '%d{yyyyMMdd}'   
  AND           LENGTH(TRIM(NVL(t.infopubldate,'')))>0
  AND           SUBSTR(a1.SecurityCode,1,3) = '519'
  AND           a2.INNERCODE IS NOT NULL
  ;

--插入只有净值的
  INSERT INTO DDW_PROD.T_DDW_PUB_JW_QOT
 (
                                  CD                --代码 
                                 ,EXG               --交易所 
                                 ,NEWST_PRC         --最新价   
                                 ,TRD_MKT           --交易市场								 
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                    a1.SecurityCode                  as CD                --代码 
                    ,CASE WHEN SUBSTR(a1.SecurityCode,1,3) IN ('500','501','502','503','505','506','510','511','512','513','518','515')
  					      THEN 'SH'
						  ELSE 'SZ'
						  END                        as EXG               --交易所
                    ,ROUND(t.unitnv ,3)              as NEWST_PRC         --最新价   
                    ,6                               as TRD_MKT           --交易市场						  
  FROM          FUNDEXT.DBO_MF_NetValue     t
  LEFT JOIN     FUNDEXT.DBO_MF_FundArchives       a1
  ON            t.INNERCODE = a1.INNERCODE
  AND           t.DT = a1.DT
  LEFT JOIN     (SELECT  a.INNERCODE
                        ,b.infopubldate      as infopubldate
					    ,a.enddate             as enddate
                FROM (SELECT INNERCODE
							 ,MAX(enddate) as enddate
                             ,DT
                      FROM	 FUNDEXT.DBO_MF_NetValue
					  WHERE CONCAt(substr(infopubldate,1,4),substr(infopubldate,6,2),substr(infopubldate,9,2) )  < = '%d{yyyyMMdd}'
					  AND    DT = '%d{yyyyMMdd}'
					  AND    LENGTH(TRIM(NVL(infopubldate,'')))>0
					  GROUP BY INNERCODE,DT ) a 
					  LEFT JOIN 
					  (SELECT INNERCODE
				             ,MAX(infopubldate) as infopubldate
							 ,enddate as enddate
                             ,DT
                      FROM	 FUNDEXT.DBO_MF_NetValue
					  WHERE CONCAt(substr(infopubldate,1,4),substr(infopubldate,6,2),substr(infopubldate,9,2) )  < = '%d{yyyyMMdd}'
					  AND    DT = '%d{yyyyMMdd}'
					  AND    LENGTH(TRIM(NVL(infopubldate,'')))>0
					  GROUP BY INNERCODE,enddate,DT
					  )    b
					  ON   a.INNERCODE = b.INNERCODE
					  AND  a.enddate = b.enddate
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.infopubldate = a2.infopubldate
  AND           t.enddate = a2.enddate
  WHERE         t.DT = '%d{yyyyMMdd}'   
  AND           LENGTH(TRIM(NVL(t.infopubldate,'')))>0
  AND           (SUBSTR(a1.SecurityCode,1,3) IN ('500','501','502','505','506','510','511','512','513','518','150','151','159','184','515')
                 OR SUBSTR(a1.SecurityCode,1,2) = '16')
  AND           a2.INNERCODE IS NOT NULL 
  AND           a1.TYPE IN (2,8)  
  UNION ALL
  SELECT 
                    a1.SecurityCode                  as CD                --代码 
                    ,CASE WHEN SUBSTR(a1.SecurityCode,1,3) IN ('500','501','502','503','505','506','510','511','512','513','518','515')
  					      THEN 'SH'
						  ELSE 'SZ'
						  END                        as EXG               --交易所
                    ,ROUND(t.unitnv ,3)              as NEWST_PRC         --最新价   
                    ,6                               as TRD_MKT           --交易市场						  
  FROM          FUNDEXT.DBO_MF_NetValue     t
  LEFT JOIN     FUNDEXT.DBO_MF_FundArchives       a1
  ON            t.INNERCODE = a1.INNERCODE
  AND           t.DT = a1.DT
  LEFT JOIN     (SELECT  a.INNERCODE
                        ,b.infopubldate      as infopubldate
					    ,a.enddate             as enddate
                FROM (SELECT INNERCODE
							 ,MAX(enddate) as enddate
                             ,DT
                      FROM	 FUNDEXT.DBO_MF_NetValue
					  WHERE CONCAt(substr(infopubldate,1,4),substr(infopubldate,6,2),substr(infopubldate,9,2) )  < = '%d{yyyyMMdd}'
					  AND    DT = '%d{yyyyMMdd}'
					  AND    LENGTH(TRIM(NVL(infopubldate,'')))>0
					  GROUP BY INNERCODE,DT ) a 
					  LEFT JOIN 
					  (SELECT INNERCODE
				             ,MAX(infopubldate) as infopubldate
							 ,enddate as enddate
                             ,DT
                      FROM	 FUNDEXT.DBO_MF_NetValue
					  WHERE CONCAt(substr(infopubldate,1,4),substr(infopubldate,6,2),substr(infopubldate,9,2) )  < = '%d{yyyyMMdd}'
					  AND    DT = '%d{yyyyMMdd}'
					  AND    LENGTH(TRIM(NVL(infopubldate,'')))>0
					  GROUP BY INNERCODE,enddate,DT
					  )    b
					  ON   a.INNERCODE = b.INNERCODE
					  AND  a.enddate = b.enddate
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.infopubldate = a2.infopubldate
  AND           t.enddate = a2.enddate
  WHERE         t.DT = '%d{yyyyMMdd}'   
  AND           LENGTH(TRIM(NVL(t.infopubldate,'')))>0
  AND           (SUBSTR(a1.SecurityCode,1,3) IN ('500','501','502','505','506','510','511','512','513','518','150','151','159','184','515')
                 OR SUBSTR(a1.SecurityCode,1,2) = '16')
  AND           a2.INNERCODE IS NOT NULL 
  AND           a1.TYPE NOT IN (2,8)  
  AND   EXISTS   (SELECT 1 FROM fundext.dbo_MF_IssueAndListing e
                  WHERE e.ListedPlace is null
				  AND   e.DT = '%d{yyyyMMdd}'
				  AND   t.INNERCODE = e.INNERCODE
                 )
  
  ;  
  
  ---基金净值--
  INSERT INTO DDW_PROD.T_DDW_PUB_JW_QOT
 (
                                  CD                --代码 
                                 ,EXG               --交易所 
                                 ,NEWST_PRC         --最新价   
                                 ,TRD_MKT           --交易市场								 
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT       t.CD
             ,t.EXG
			 ,t.NEWST_PRC 
			 ,t.TRD_MKT
FROM 
(SELECT 
                    a1.SecurityCode                  as CD                --代码 
                    ,'CWJJ'                          as EXG               --交易所
                    ,ROUND(t.unitnv ,4)              as NEWST_PRC         --最新价   
                    ,2                               as TRD_MKT           --交易市场
                    ,ROW_NUMBER() OVER(PARTITION BY a1.SecurityCode ORDER BY t.infopubldate	 DESC) as NUM				
  FROM          FUNDEXT.DBO_MF_NetValue     t
  LEFT JOIN     FUNDEXT.DBO_MF_FundArchives       a1
  ON            t.INNERCODE = a1.INNERCODE
  AND           t.DT = a1.DT
  LEFT JOIN     (SELECT  a.INNERCODE
                        ,b.infopubldate      as infopubldate
					    ,a.enddate             as enddate
                FROM (SELECT INNERCODE
							 ,MAX(enddate) as enddate
                             ,DT
                      FROM	 FUNDEXT.DBO_MF_NetValue
					  WHERE CONCAt(substr(infopubldate,1,4),substr(infopubldate,6,2),substr(infopubldate,9,2) )  < = '%d{yyyyMMdd}'
					  AND    DT = '%d{yyyyMMdd}'
					  AND    LENGTH(TRIM(NVL(infopubldate,'')))>0
					  GROUP BY INNERCODE,DT ) a 
					  LEFT JOIN 
					  (SELECT INNERCODE
				             ,MAX(infopubldate) as infopubldate
							 ,enddate as enddate
                             ,DT
                      FROM	 FUNDEXT.DBO_MF_NetValue
					  WHERE CONCAt(substr(infopubldate,1,4),substr(infopubldate,6,2),substr(infopubldate,9,2) )  < = '%d{yyyyMMdd}'
					  AND    DT = '%d{yyyyMMdd}'
					  AND    LENGTH(TRIM(NVL(infopubldate,'')))>0
					  GROUP BY INNERCODE,enddate,DT
					  )    b
					  ON   a.INNERCODE = b.INNERCODE
					  AND  a.enddate = b.enddate
				)                       a2
  ON            t.INNERCODE = a2.INNERCODE
  AND           t.infopubldate = a2.infopubldate
  AND           t.enddate = a2.enddate
  WHERE         t.DT = '%d{yyyyMMdd}'   
  AND           LENGTH(TRIM(NVL(t.infopubldate,'')))>0
  AND           a2.INNERCODE IS NOT NULL  
  --AND a1.SecurityCode = '165532'
  ) t WHERE t.NUM = 1
  ;
  ---期权行情--
   
  INSERT INTO DDW_PROD.T_DDW_PUB_JW_QOT
 (
                                  CD                --代码 
                                 ,EXG               --交易所 
                                 ,NEWST_PRC         --最新价   
                                 ,TRD_MKT           --交易市场								 
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT              
                    CAST(t.contractcode as STRING)   as CD                --代码 
                    ,CASE WHEN a1.exchange = 83
					      THEN 'SH'
 						  WHEN a1.exchange = 90
						  THEN 'SZ'
						  END                        as EXG               --交易所
                    ,t.closeprice                    as NEWST_PRC           --最新价   
                    ,CASE WHEN a1.ulatype = 1
 					      THEN 3
						  WHEN a1.ulatype = 2
						  THEN 4
						  END                         as TRD_MKT           --交易市场						  
  FROM          FUNDEXT.DBO_OPT_DAILYQUOTE     t
  LEFT JOIN     (SELECT                a.INNERCODE
                                      ,MAX(a.tradingdate) as tradingdate
                                      ,b.ulatype
                                      ,b.exchange									  
                              FROM      FUNDEXT.DBO_OPT_DAILYQUOTE a
                              LEFT JOIN FUNDEXT.DBO_OPT_OPTIONCONTRACT b
							  ON        a.DT = b.DT
							  AND       a.INNERCODE = b.INNERCODE
							  WHERE     b.INNERCODE IS NOT NULL
							  AND       b.exchange IN (83,90)
							  AND       LENGTH(TRIM(NVL(a.tradingdate,'')))>0
                              AND       a.DT = '%d{yyyyMMdd}'
							  AND        CONCAt(substr(a.tradingdate,1,4),substr(a.tradingdate,6,2),substr(a.tradingdate,9,2) )  < = '%d{yyyyMMdd}'
                              GROUP BY 	a.INNERCODE,b.ulatype,b.exchange						  
                )                 a1
 ON            t.INNERCODE  = a1.INNERCODE
 AND           t.tradingdate = a1.tradingdate 				              				             
  WHERE         t.DT = '%d{yyyyMMdd}'   
  AND           LENGTH(TRIM(NVL(t.tradingdate,'')))>0
  AND           a1.INNERCODE IS NOT NULL
  ;

----------------------插入数据结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_JW_QOT',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_JW_QOT;
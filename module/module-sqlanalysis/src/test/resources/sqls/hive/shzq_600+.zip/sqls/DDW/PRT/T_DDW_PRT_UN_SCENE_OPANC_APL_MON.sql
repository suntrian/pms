 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:非现场开户申请统计月表                                                        */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2018-08-16                                                                        */ 
 


--------------插入数据-------------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_UN_SCENE_OPANC_APL_MON
(                   
            SEQNBR                            --序号	                      
            ,EFF             	              --效率	       		  
            ,UN_SCENE_OPANC_VOL               --非现场开户数	           
            ,UN_SCENE_OPANC_VOL_TOT           --非现场开户总数     
            ,UN_SCENE_OPANC_VOL_RTO           --非现场开户数占比	           
            ,UN_SCENE_OPANC_AVG_DEAL_TM       --非现场开户数平均处理时间	       			 	   	
) 
 partition(YEAR_MON)
 SELECT      t.SEQNBR                         as SEQNBR                                                             --序号	                      
            ,t.EFF                            as EFF             	                                                --效率	       		  
            ,t.UN_SCENE_OPANC_VOL             as UN_SCENE_OPANC_VOL                                                 --非现场开户数	           
            ,a1.UN_SCENE_OPANC_VOL_TOT        as UN_SCENE_OPANC_VOL_TOT                                             --非现场开户总数     
            ,cast(ROUND(t.UN_SCENE_OPANC_VOL*1.0000/a1.UN_SCENE_OPANC_VOL_TOT,4) as DECIMAL(38,4)) as UN_SCENE_OPANC_VOL_RTO          --非现场开户数占比	           
            ,cast(a2.UN_SCENE_OPANC_AVG_DEAL_TM as DECIMAL(38,2))       as UN_SCENE_OPANC_AVG_DEAL_TM       --非现场开户数平均处理时间
            ,t.YEAR_MON                         as YEAR_MON
FROM 
 (SELECT   CAST(SUBSTR(CAST (SQRQ AS STRING),1,6) as INT) as YEAR_MON
         ,CASE WHEN unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) < = 180
                AND  a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
				THEN 1
                WHEN unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) > 180
				AND  unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) < = 300
                AND  a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
				THEN 2
				WHEN unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) > 300
				AND  unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) < = 600
                AND  a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
				THEN 3
				WHEN unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) > 600
				AND  unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) < = 1200
                AND  a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
				THEN 4
				WHEN unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) > 1200
				AND  unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) < = 1800
                AND  a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
 			    THEN 5
				WHEN unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) > 1800
				AND  a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
                THEN 6
				WHEN a.SQRQ < CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
                THEN 7
				END  as SEQNBR	
           ,CASE WHEN unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) < = 180
                AND  a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
				THEN '<=3分钟'
                WHEN unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) > 180
				AND  unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) < = 300
                AND  a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
				THEN '3-5分钟'
				WHEN unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) > 300
				AND  unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) < = 600
                AND  a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
				THEN '5-10分钟'
				WHEN unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) > 600
				AND  unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) < = 1200
                AND  a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
				THEN '10-20分钟'
				WHEN unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) > 1200
				AND  unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) < = 1800
                AND  a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
 			    THEN '20-30分钟'
				WHEN unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)) > 1800
				AND  a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
                THEN '30分钟以上'
				WHEN a.SQRQ < CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
                THEN '第二天完成'
				END  as EFF
            ,count(1) as UN_SCENE_OPANC_VOL				
  FROM  EDW_PROD.T_EDW_T02_LCFXCKH a
  LEFT JOIN (SELECT YWQQID,MIN(CONCAT(SUBSTR(CAST(SQRQ as STRING),1,4),'-',SUBSTR(CAST(SQRQ as STRING),5,2),'-',SUBSTR(CAST(SQRQ as STRING),7,2),' ',SQSJ)) as SHSJ FROM  EDW_PROD.T_EDW_T05_TYWQQCL
             GROUP BY YWQQID
           ) b
  ON   a.YWQQID = b.YWQQID
  WHERE SUBSTR(CAST (a.SQRQ AS STRING),1,6) > =  '201801'
  AND   LENGTH(TRIM(a.GTKHH)) > 0
  AND   a.BUS_DATE = %d{yyyyMMdd}--
--AND   a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
--AND  unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ))< = 180
 GROUP BY YEAR_MON,EFF,SEQNBR
 )  t
LEFT JOIN (SELECT CAST(SUBSTR(CAST (SQRQ AS STRING),1,6) as INT) as YEAR_MON
                 ,COUNT(1) as UN_SCENE_OPANC_VOL_TOT   
           FROM  EDW_PROD.T_EDW_T02_LCFXCKH
           WHERE SUBSTR(CAST (SQRQ AS STRING),1,6) > =  '201801'
           AND   LENGTH(TRIM(GTKHH)) > 0
		   AND   BUS_DATE = %d{yyyyMMdd}
           GROUP BY YEAR_MON
		   ) a1
ON  t.YEAR_MON = a1.YEAR_MON
LEFT JOIN (SELECT  CAST(SUBSTR(CAST (SQRQ AS STRING),1,6) as INT) as YEAR_MON
                  ,ROUND(avg((unix_timestamp(b.SHSJ)-unix_timestamp(CONCAT(SUBSTR(CAST(a.SQRQ as STRING),1,4),'-',SUBSTR(CAST(a.SQRQ as STRING),5,2),'-',SUBSTR(CAST(a.SQRQ as STRING),7,2),' ',a.SQSJ)))*1.000/60),2) as UN_SCENE_OPANC_AVG_DEAL_TM    --非现场开户数(<=3处理)
           FROM   EDW_PROD.T_EDW_T02_LCFXCKH a
           LEFT JOIN (SELECT YWQQID
		                    ,MIN(CONCAT(SUBSTR(CAST(SQRQ as STRING),1,4),'-',SUBSTR(CAST(SQRQ as STRING),5,2),'-',SUBSTR(CAST(SQRQ as STRING),7,2),' ',SQSJ)) as SHSJ FROM  EDW_PROD.T_EDW_T05_TYWQQCL
                     GROUP BY YWQQID
                     ) b
          ON   a.YWQQID = b.YWQQID
         WHERE     SUBSTR(CAST (a.SQRQ AS STRING),1,6) > =  '201801'
          AND      LENGTH(TRIM(a.GTKHH)) > 0
          AND      a.SQRQ = CAST(CONCAT(SUBSTR(b.SHSJ,1,4),SUBSTR(b.SHSJ,6,2),SUBSTR(b.SHSJ,9,2)) as INT)
		  AND   BUS_DATE = %d{yyyyMMdd}
          GROUP BY YEAR_MON
		 )       a2
ON  t.YEAR_MON = a2.YEAR_MON	
--WHERE t.BUS_DATE = 	  %d{yyyyMMdd}
 ;
 
-----------------------------加载结束--------------------
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_UN_SCENE_OPANC_APL_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ; 
     invalidate metadata DDW_PROD.T_DDW_PRT_UN_SCENE_OPANC_APL_MON ;
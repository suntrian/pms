------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:营业部客户数指标月表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2018-04-20                                                                        */
---客户类别字典 0 个人 1 机构 2 产品 3 总计---实际机构 = 机构+产品

-----期初
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON_TEMP as
SELECT  t.BRH_NO       as BRH_NO               --营业部编码             
       ,t.CUST_CGY     as CUST_CGY             --客户类别
       ,SUM(CASE WHEN t.CUST_STAT < > '3'
			            THEN 1
					    ELSE 0
					    END
			)          as STRT_CUST_VOL          --期初客户数
      ,SUM(CASE WHEN t.CUST_STAT < > '3'
			    AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
				THEN 1
				ELSE 0
				END
		  )            as STRT_QLFD_CUST_VOL     --期初合格客户数
	  ,SUM(CASE WHEN t.T3BOD_OPNAC_DT IS NOT NULL
			    AND  t.IF_T3BOD < > 3
				THEN 1
				ELSE 0
				END
		  )            as STRT_T3BOD_CUST_VOL    --期初三板客户数
             
	  ,SUM(CASE WHEN t.HK_OPNAC_DT IS NOT NULL
			    AND  t.IF_HK < > 3
				THEN 1
				ELSE 0
				END
		  )            as STRT_HK_CUST_VOL       --期初沪港通客户数	
      ,SUM(CASE WHEN t.SK_OPNAC_DT IS NOT NULL
			    AND  t.IF_SK < > 3
				THEN 1
				ELSE 0
				END
		  )            as STRT_SK_CUST_VOL       --期初深港通客户数
      ,SUM(CASE WHEN t.H_K_OPNAC_DT IS NOT NULL
			    AND  t.IF_H_K < > 3
				THEN 1
				ELSE 0
				END
		  )            as STRT_H_K_CUST_VOL     --期初港股通客户数
      ,SUM(CASE WHEN t.REPO_MRGNC_OPNAC_DT IS NOT NULL
			    AND  t.IF_REPO_MRGNC < > 3
				THEN 1
				ELSE 0
				END
		  )           as STRT_REPO_MRGNC_CUST_VOL --期初回购融资客户数	
      ,SUM(CASE WHEN t.REPO_MRGNS_OPNAC_DT IS NOT NULL
			    AND  t.IF_REPO_MRGNS < > 3
				THEN 1
				ELSE 0
				END
		  )           as STRT_REPO_MRGNS_CUST_VOL --期初回购融券客户数		
      ,SUM(CASE WHEN t.NEW_T3BOD_OPNAC_DT IS NOT NULL
			    AND  t.IF_NEW_T3BOD < > 3
				THEN 1
				ELSE 0
				END
		  )           as STRT_NEW_T3BOD_CUST_VOL  --期初新三板客户数
      ,SUM(CASE WHEN t.CRD_OPNAC_DT IS NOT NULL
			    AND  t.IF_CRD_CNCLACT < > 3
				THEN 1
				ELSE 0
				END
		  )            as STRT_CRD_CUST_VOL       --期初信用客户数		
      ,SUM(CASE WHEN t.WRNT_OPNAC_DT IS NOT NULL
			    AND  t.IF_WRNT_CNCLACT < > 3
				THEN 1
				ELSE 0
				END
		  )            as STRT_WRNT_CUST_VOL      --期初期权客户数
       ,SUM(CASE WHEN t.GEM_OPNAC_DT IS NOT NULL
			     AND  t.IF_GEM < > 3
				 THEN 1
				 ELSE 0
				 END
			)          as STRT_GEM_CUST_VOL       --期初创业板客户数
        ,SUM(CASE WHEN t.DLSTG_OPNAC_DT IS NOT NULL
			      AND  t.IF_DLSTG < > 3
				  THEN 1
				  ELSE 0
				  END
			)          as STRT_DLSTG_CUST_VOL          --期初退市整理客户数
       ,SUM(CASE WHEN t.BOND_QLFD_IVSM_OPNAC_DT IS NOT NULL
			     AND  t.IF_BOND_QLFD_IVSM < > 3
				 THEN 1
				 ELSE 0
				 END
			)          as STRT_BOND_QLFD_IVSM_CUST_VOL --期初债券合格投资客户数
       ,SUM(CASE WHEN t.QOT_REPO_OPNAC_DT IS NOT NULL
			     AND  t.IF_QOT_REPO < > 3
				 THEN 1
				 ELSE 0
				 END
		    )         as STRT_QOT_REPO_CUST_VOL        --期初报价回购客户数	
       ,SUM(CASE WHEN t.PROMS_RPHS_OPNAC_DT IS NOT NULL
			     AND  t.IF_PROMS_RPHS < > 3
				 THEN 1
				 ELSE 0
				 END
		   )          as STRT_PROMS_RPHS_CUST_VOL     --期初约定购回客户数
       ,SUM(CASE WHEN t.PLG_REPO_OPNAC_DT IS NOT NULL
			     AND  t.IF_PLG_REPO < > 3
				 THEN 1
				 ELSE 0
				 END
			)         as STRT_STK_PLG_CUST_VOL       --期初股票质押客户数	
       ,SUM(CASE WHEN t.STK_PLG_OPNAC_DT IS NOT NULL
			     AND  t.IF_STK_PLG < > 3
				 THEN 1
				 ELSE 0
				 END
			)         as STRT_MIN_LOAN_CUST_VOL           --期初小微贷质押客户数
       ,SUM(CASE WHEN t.STR_FND_OPNAC_DT IS NOT NULL
			     AND  t.IF_STR_FND < > 3
				 THEN 1
				 ELSE 0
				 END
			)         as STRT_STR_FND_CUST_VOL           --期初分级基金客户数	
       ,SUM(CASE WHEN t.STIB_OPNAC_DT IS NOT NULL
			     AND  t.IF_STIB < > 3
				 THEN 1
				 ELSE 0
				 END
			)   as STRT_STIB_CUST_VOL              --期初科创板客户数	
       ,SUM(CASE WHEN t.LMT_NEW_T3BOD_OPNAC_DT IS NOT NULL
			     AND  t.IF_LMT_NEW_T3BOD < > 3
				 THEN 1
				 ELSE 0
				 END
			)    as STRT_LMT_NEW_T3BOD_CUST_VOL    --期初新三板(受限制)客户数	
       ,SUM(CASE WHEN t.CASH_PROD_OPNAC_DT IS NOT NULL
			     AND  t.IF_CASH_PROD < > 3
				 THEN 1
				 ELSE 0
				 END
			)    as STRT_CASH_PROD_CUST_VOL        --期初现金添利客户数  
FROM          DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
WHERE         t.BUS_DATE IN (SELECT MAX(TRD_DT) as MON_START 
                             FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                 WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                 AND BUS_DATE = %d{yyyyMMdd}
							)
AND           t.OPNAC_DT < = (SELECT MAX(TRD_DT) as MON_START 
                             FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                 WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                 AND BUS_DATE = %d{yyyyMMdd}
							)
GROUP BY       BRH_NO                         
              ,CUST_CGY			    
;


-------------------		  
-----期末
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON_TEMP1 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON_TEMP1 as
SELECT  t.BRH_NO       as BRH_NO               --营业部编码             
       ,t.CUST_CGY     as CUST_CGY             --客户类别
       ,SUM(CASE WHEN t.CUST_STAT < > '3'
			            THEN 1
					    ELSE 0
					    END
			)          as FNL_CUST_VOL          --期末客户数
      ,SUM(CASE WHEN t.CUST_STAT < > '3'
			    AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
				THEN 1
				ELSE 0
				END
		  )            as FNL_QLFD_CUST_VOL     --期末合格客户数
	  ,SUM(CASE WHEN t.T3BOD_OPNAC_DT IS NOT NULL
			    AND  t.IF_T3BOD < > 3
				THEN 1
				ELSE 0
				END
		  )            as FNL_T3BOD_CUST_VOL    --期末三板客户数
             
	  ,SUM(CASE WHEN t.HK_OPNAC_DT IS NOT NULL
			    AND  t.IF_HK < > 3
				THEN 1
				ELSE 0
				END
		  )            as FNL_HK_CUST_VOL       --期末沪港通客户数	
      ,SUM(CASE WHEN t.SK_OPNAC_DT IS NOT NULL
			    AND  t.IF_SK < > 3
				THEN 1
				ELSE 0
				END
		  )            as FNL_SK_CUST_VOL       --期末深港通客户数
      ,SUM(CASE WHEN t.H_K_OPNAC_DT IS NOT NULL
			    AND  t.IF_H_K < > 3
				THEN 1
				ELSE 0
				END
		  )            as FNL_H_K_CUST_VOL     --期末港股通客户数
      ,SUM(CASE WHEN t.REPO_MRGNC_OPNAC_DT IS NOT NULL
			    AND  t.IF_REPO_MRGNC < > 3
				THEN 1
				ELSE 0
				END
		  )           as FNL_REPO_MRGNC_CUST_VOL --期末回购融资客户数	
      ,SUM(CASE WHEN t.REPO_MRGNS_OPNAC_DT IS NOT NULL
			    AND  t.IF_REPO_MRGNS < > 3
				THEN 1
				ELSE 0
				END
		  )           as FNL_REPO_MRGNS_CUST_VOL --期末回购融券客户数		
      ,SUM(CASE WHEN t.NEW_T3BOD_OPNAC_DT IS NOT NULL
			    AND  t.IF_NEW_T3BOD < > 3
				THEN 1
				ELSE 0
				END
		  )           as FNL_NEW_T3BOD_CUST_VOL  --期末新三板客户数
      ,SUM(CASE WHEN t.CRD_OPNAC_DT IS NOT NULL
			    AND  t.IF_CRD_CNCLACT < > 3
				THEN 1
				ELSE 0
				END
		  )            as FNL_CRD_CUST_VOL       --期末信用客户数		
      ,SUM(CASE WHEN t.WRNT_OPNAC_DT IS NOT NULL
			    AND  t.IF_WRNT_CNCLACT < > 3
				THEN 1
				ELSE 0
				END
		  )            as FNL_WRNT_CUST_VOL      --期末期权客户数
       ,SUM(CASE WHEN t.GEM_OPNAC_DT IS NOT NULL
			     AND  t.IF_GEM < > 3
				 THEN 1
				 ELSE 0
				 END
			)          as FNL_GEM_CUST_VOL       --期末创业板客户数
        ,SUM(CASE WHEN t.DLSTG_OPNAC_DT IS NOT NULL
			      AND  t.IF_DLSTG < > 3
				  THEN 1
				  ELSE 0
				  END
			)          as FNL_DLSTG_CUST_VOL          --期末退市整理客户数
       ,SUM(CASE WHEN t.BOND_QLFD_IVSM_OPNAC_DT IS NOT NULL
			     AND  t.IF_BOND_QLFD_IVSM < > 3
				 THEN 1
				 ELSE 0
				 END
			)          as FNL_BOND_QLFD_IVSM_CUST_VOL --期末债券合格投资客户数
       ,SUM(CASE WHEN t.QOT_REPO_OPNAC_DT IS NOT NULL
			     AND  t.IF_QOT_REPO < > 3
				 THEN 1
				 ELSE 0
				 END
		    )         as FNL_QOT_REPO_CUST_VOL        --期末报价回购客户数	
       ,SUM(CASE WHEN t.PROMS_RPHS_OPNAC_DT IS NOT NULL
			     AND  t.IF_PROMS_RPHS < > 3
				 THEN 1
				 ELSE 0
				 END
		   )          as FNL_PROMS_RPHS_CUST_VOL     --期末约定购回客户数
       ,SUM(CASE WHEN t.PLG_REPO_OPNAC_DT IS NOT NULL
			     AND  t.IF_PLG_REPO < > 3
				 THEN 1
				 ELSE 0
				 END
			)         as FNL_STK_PLG_CUST_VOL       --期末股票质押客户数	
       ,SUM(CASE WHEN t.STK_PLG_OPNAC_DT IS NOT NULL
			     AND  t.IF_STK_PLG < > 3
				 THEN 1
				 ELSE 0
				 END
			)         as FNL_MIN_LOAN_CUST_VOL           --期末小微贷质押客户数
       ,SUM(CASE WHEN t.STR_FND_OPNAC_DT IS NOT NULL
			     AND  t.IF_STR_FND < > 3
				 THEN 1
				 ELSE 0
				 END
			)         as FNL_STR_FND_CUST_VOL           --期末分级基金客户数	
       ,SUM(CASE WHEN t.STIB_OPNAC_DT IS NOT NULL
			     AND  t.IF_STIB < > 3
				 THEN 1
				 ELSE 0
				 END
			)   as FNL_STIB_CUST_VOL              --期末科创板客户数	
       ,SUM(CASE WHEN t.LMT_NEW_T3BOD_OPNAC_DT IS NOT NULL
			     AND  t.IF_LMT_NEW_T3BOD < > 3
				 THEN 1
				 ELSE 0
				 END
			)    as FNL_LMT_NEW_T3BOD_CUST_VOL    --期末新三板(受限制)客户数	
       ,SUM(CASE WHEN t.CASH_PROD_OPNAC_DT IS NOT NULL
			     AND  t.IF_CASH_PROD < > 3
				 THEN 1
				 ELSE 0
				 END
			)    as FNL_CASH_PROD_CUST_VOL        --期末现金添利客户数   
			  ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)			            
						THEN 1
					    ELSE 0
					    END
				  )                           as OPANC_VOL                     --开户数
			  ,SUM(CASE WHEN t.CUST_STAT = '3'
			            AND SUBSTR(CAST(NVL(t.CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)  
						THEN 1
					    ELSE 0
					    END
				  )                           as CNCLACT_VOL                    --销户数			 
			  ,SUM(CASE WHEN t.CUST_STAT = '3'
			            AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
						AND  SUBSTR(CAST(NVL(t.CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
						THEN 1
					    ELSE 0
					    END
				  )                           as CNCLACT_QLFD_CUST_VOL          --销户合格客户数
			  ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)  
			            AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
						THEN 1
					    ELSE 0
					    END
				  )                           as OPNAC_QLFD_CUST_VOL             --开户合格客户数
             
			
           	 ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.T3BOD_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 	           
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_T3BOD_CUST_VOL                --当月开通三板客户数
             
			 ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.HK_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 	          
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_HK_CUST_VOL                     --当月开通沪港通客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.SK_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 	          
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_SK_CUST_VOL                     --当月开通深港通客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.H_K_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 		           
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_H_K_CUST_VOL                     --当月开通港股通客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.REPO_MRGNC_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_REPO_MRGNC_CUST_VOL               --当月开通回购融资客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.REPO_MRGNS_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_REPO_MRGNS_CUST_VOL               --当月开通回购融券客户数	
            
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.NEW_T3BOD_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_NEW_T3BOD_CUST_VOL                --当月开通新三板客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.CRD_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPNAC_CRD_CUST_VOL                      --当月开户信用客户数		
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.WRNT_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPNAC_WRNT_CUST_VOL                      --当月开户期权客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.GEM_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_GEM_CUST_VOL                      --当月开通创业板客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.DLSTG_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_DLSTG_CUST_VOL                      --当月开通退市整理客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.BOND_QLFD_IVSM_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_BOND_QLFD_IVSM_CUST_VOL                      --当月开通债券合格投资客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.QOT_REPO_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_QOT_REPO_CUST_VOL                            --当月开通报价回购客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.PROMS_RPHS_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_PROMS_RPHS_CUST_VOL                          --当月开通约定购回客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.PLG_REPO_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_STK_PLG_CUST_VOL                          --当月开通股票质押客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.STK_PLG_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_MIN_LOAN_CUST_VOL                          --当月开通小微贷质押客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.STR_FND_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_STR_FND_CUST_VOL                          --当月开通分级基金客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.STIB_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_STIB_CUST_VOL                          --当月开通科创板客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.LMT_NEW_T3BOD_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_LMT_NEW_T3BOD_CUST_VOL                          --当月开通新三板(受限制)客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.CASH_PROD_OPNAC_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as OPN_CASH_PROD_CUST_VOL                          --当月开通现金添利客户数				  
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.T3BOD_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)           
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_T3BOD_CUST_VOL                --当月关闭三板客户数
             
			 ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.HK_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)  		          
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_HK_CUST_VOL                     --当月关闭沪港通客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.SK_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 		          
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_SK_CUST_VOL                     --当月关闭深港通客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.H_K_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 	           
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_H_K_CUST_VOL                     --当月关闭港股通客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.REPO_MRGNC_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_REPO_MRGNC_CUST_VOL               --当月关闭回购融资客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.REPO_MRGNS_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_REPO_MRGNS_CUST_VOL               --当月关闭回购融券客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.NEW_T3BOD_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_NEW_T3BOD_CUST_VOL                --当月关闭新三板客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.CRD_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as CNCLACT_CRD_CUST_VOL                      --当月销户信用客户数		
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.WRNT_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as CNCLACT_WRNT_CUST_VOL                      --当月销户期权客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.GEM_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_GEM_CUST_VOL                      --当月关闭创业板客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.DLSTG_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_DLSTG_CUST_VOL                      --当月关闭退市整理客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.BOND_QLFD_IVSM_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)  
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_BOND_QLFD_IVSM_CUST_VOL                      --当月关闭债券合格投资客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.QOT_REPO_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)  
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_QOT_REPO_CUST_VOL                            --当月关闭报价回购客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.PROMS_RPHS_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_PROMS_RPHS_CUST_VOL                          --当月关闭约定购回客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.PLG_REPO_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)  
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_STK_PLG_CUST_VOL                          --当月关闭股票质押客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.STK_PLG_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_MIN_LOAN_CUST_VOL                          --当月关闭小微贷质押客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.STR_FND_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_STR_FND_CUST_VOL                          --当月关闭分级基金客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.STIB_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_STIB_CUST_VOL                          --当月关闭科创板客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.LMT_NEW_T3BOD_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_LMT_NEW_T3BOD_CUST_VOL                          --当月关闭新三板(受限制)客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.CASH_PROD_CNCLACT_DT,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
					   THEN 1
					   ELSE 0
					   END
				  )                           as CLS_CASH_PROD_CUST_VOL                          --当月关闭现金添利客户数
            		  ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)			            
					AND  SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)	 
						 THEN 1
					     ELSE 0
					     END
				  )                           as GT_OPANC_VOL                     --本年累计开户数
			  ,SUM(CASE WHEN t.CUST_STAT = '3'
			            AND SUBSTR(CAST(NVL(t.CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)  
						AND  SUBSTR(CAST(NVL(t.CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6) 
						THEN 1
					    ELSE 0
					    END
				  )                           as GT_CNCLACT_VOL                    --本年累计销户数			 
			  ,SUM(CASE WHEN t.CUST_STAT = '3'
			            AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
						AND  SUBSTR(CAST(NVL(t.CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
						AND  SUBSTR(CAST(NVL(t.CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
						THEN 1
					    ELSE 0
					    END
				  )                           as GT_CNCLACT_QLFD_CUST_VOL          --本年累计销户合格客户数
			  ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)  
			            AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
						AND  SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
						THEN 1
					    ELSE 0
					    END
				  )                           as GT_OPNAC_QLFD_CUST_VOL             --本年累计开户合格客户数
             
			
           	 ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.T3BOD_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 	           
					   AND  SUBSTR(CAST(NVL(t.T3BOD_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_T3BOD_CUST_VOL                --本年累计开通三板客户数
             
			 ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.HK_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 	          
					   AND  SUBSTR(CAST(NVL(t.HK_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_HK_CUST_VOL                     --本年累计开通沪港通客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.SK_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 	          
					   AND  SUBSTR(CAST(NVL(t.SK_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_SK_CUST_VOL                     --本年累计开通深港通客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.H_K_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 		           
					   AND SUBSTR(CAST(NVL(t.H_K_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_H_K_CUST_VOL                     --本年累计开通港股通客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.REPO_MRGNC_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.REPO_MRGNC_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_REPO_MRGNC_CUST_VOL               --本年累计开通回购融资客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.REPO_MRGNS_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.REPO_MRGNS_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_REPO_MRGNS_CUST_VOL               --本年累计开通回购融券客户数	
            
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.NEW_T3BOD_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.NEW_T3BOD_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_NEW_T3BOD_CUST_VOL                --本年累计开通新三板客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.CRD_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.CRD_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPNAC_CRD_CUST_VOL                      --本年累计开户信用客户数		
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.WRNT_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.WRNT_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPNAC_WRNT_CUST_VOL                      --本年累计开户期权客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.GEM_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.GEM_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_GEM_CUST_VOL                      --本年累计开通创业板客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.DLSTG_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.DLSTG_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_DLSTG_CUST_VOL                      --本年累计开通退市整理客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.BOND_QLFD_IVSM_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.BOND_QLFD_IVSM_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_BOND_QLFD_IVSM_CUST_VOL                      --本年累计开通债券合格投资客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.QOT_REPO_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.QOT_REPO_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_QOT_REPO_CUST_VOL                            --本年累计开通报价回购客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.PROMS_RPHS_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.PROMS_RPHS_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_PROMS_RPHS_CUST_VOL                          --本年累计开通约定购回客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.PLG_REPO_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.PLG_REPO_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_STK_PLG_CUST_VOL                          --本年累计开通股票质押客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.STK_PLG_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.STK_PLG_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_MIN_LOAN_CUST_VOL                          --本年累计开通小微贷质押客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.STR_FND_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
					   AND  SUBSTR(CAST(NVL(t.STR_FND_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_STR_FND_CUST_VOL                          --本年累计开通分级基金客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.STIB_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.STIB_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_STIB_CUST_VOL                          --本年累计开通科创板客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.LMT_NEW_T3BOD_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.LMT_NEW_T3BOD_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_LMT_NEW_T3BOD_CUST_VOL                          --本年累计开通新三板(受限制)客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.CASH_PROD_OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.CASH_PROD_OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_OPN_CASH_PROD_CUST_VOL                          --本年累计开通现金添利客户数				  
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.T3BOD_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)           
					   AND  SUBSTR(CAST(NVL(t.T3BOD_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_T3BOD_CUST_VOL                --本年累计关闭三板客户数
             
			 ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.HK_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)  		          
					   AND  SUBSTR(CAST(NVL(t.HK_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_HK_CUST_VOL                     --本年累计关闭沪港通客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.SK_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 		          
					   AND  SUBSTR(CAST(NVL(t.SK_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_SK_CUST_VOL                     --本年累计关闭深港通客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.H_K_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 	           
					   AND  SUBSTR(CAST(NVL(t.H_K_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_H_K_CUST_VOL                     --本年累计关闭港股通客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.REPO_MRGNC_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.REPO_MRGNC_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_REPO_MRGNC_CUST_VOL               --本年累计关闭回购融资客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.REPO_MRGNS_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.REPO_MRGNS_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_REPO_MRGNS_CUST_VOL               --本年累计关闭回购融券客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.NEW_T3BOD_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.NEW_T3BOD_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_NEW_T3BOD_CUST_VOL                --本年累计关闭新三板客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.CRD_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.CRD_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CNCLACT_CRD_CUST_VOL                      --本年累计销户信用客户数		
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.WRNT_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.WRNT_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CNCLACT_WRNT_CUST_VOL                      --本年累计销户期权客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.GEM_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
					   AND  SUBSTR(CAST(NVL(t.GEM_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_GEM_CUST_VOL                      --本年累计关闭创业板客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.DLSTG_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.DLSTG_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_DLSTG_CUST_VOL                      --本年累计关闭退市整理客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.BOND_QLFD_IVSM_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)  
					   AND  SUBSTR(CAST(NVL(t.BOND_QLFD_IVSM_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_BOND_QLFD_IVSM_CUST_VOL                      --本年累计关闭债券合格投资客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.QOT_REPO_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)  
					   AND  SUBSTR(CAST(NVL(t.QOT_REPO_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_QOT_REPO_CUST_VOL                            --本年累计关闭报价回购客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.PROMS_RPHS_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.PROMS_RPHS_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_PROMS_RPHS_CUST_VOL                          --本年累计关闭约定购回客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.PLG_REPO_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)  
					   AND  SUBSTR(CAST(NVL(t.PLG_REPO_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_STK_PLG_CUST_VOL                          --本年累计关闭股票质押客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.STK_PLG_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.STK_PLG_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_MIN_LOAN_CUST_VOL                          --本年累计关闭小微贷质押客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.STR_FND_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.STR_FND_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_STR_FND_CUST_VOL                          --本年累计关闭分级基金客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.STIB_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.STIB_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_STIB_CUST_VOL                          --本年累计关闭科创板客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.LMT_NEW_T3BOD_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.LMT_NEW_T3BOD_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_LMT_NEW_T3BOD_CUST_VOL                          --本年累计关闭新三板(受限制)客户数	
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.CASH_PROD_CNCLACT_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
					   AND  SUBSTR(CAST(NVL(t.CASH_PROD_CNCLACT_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
					   END
				  )                           as GT_CLS_CASH_PROD_CUST_VOL                          --本年累计关闭现金添利客户数
             ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.FSTTM_DT_AST_1000,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
                       AND  SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)			 					   					   
					   THEN 1
					   ELSE 0
		  			   END
				  )   as TADDED_VLD_CUST_VOL --新增有效客户数
			  ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.FSTTM_DT_AST_1000,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
                        AND  SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)			 					   			   
						AND SUBSTR(CAST(NVL(t.FSTTM_DT_AST_1000,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
						THEN 1
					    ELSE 0
		  			    END
				  )   as GT_TADDED_VLD_CUST_VOL --累计新增有效客户数
			  
			,SUM(CASE WHEN SUBSTR(CAST(NVL(t.FSTTM_DT_AST_1000,99999999) as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
                       AND SUBSTR(CAST(NVL(t.FSTTM_DT_AST_0,99999999) as STRING),1,4) >= SUBSTR('%d{yyyyMMdd}',1,4)
					   AND  SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,4)> = '2016'			 					   
					   AND  SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,4)<  SUBSTR('%d{yyyyMMdd}',1,4)
					   THEN 1
					   ELSE 0
		  			   END
				  )   as STOCK_ACTVT_CUST_VOL --存量激活客户数
			  ,SUM(CASE WHEN SUBSTR(CAST(NVL(t.FSTTM_DT_AST_1000,99999999) as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)
                       AND  SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,4)> = '2016'			 					   
					   AND  SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,4)<  SUBSTR('%d{yyyyMMdd}',1,4)		 					   
					   AND SUBSTR(CAST(NVL(t.FSTTM_DT_AST_0,99999999) as STRING),1,4) > = SUBSTR('%d{yyyyMMdd}',1,4)
					   AND SUBSTR(CAST(NVL(t.FSTTM_DT_AST_1000,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
					   THEN 1
					   ELSE 0
		  			   END
				  )   as GT_STOCK_ACTVT_CUST_VOL --存量累计激活客户数
FROM          DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
WHERE         t.BUS_DATE = %d{yyyyMMdd}
AND           SUBSTR(CAST(NVL(t.OPNAC_DT,99999999) as STRING),1,6) < = SUBSTR('%d{yyyyMMdd}',1,6)
GROUP BY       BRH_NO                         
              ,CUST_CGY			    
;
INSERT OVERWRITE DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON
(
  BELTO_FILIL_CDG                 --分公司编码
, BELTO_FILIL                     --分公司名称
, BRH_NO                          --营业部编码
, BRH_FULLNM                      --营业部名称
, CUST_CGY                        --客户类别
, STRT_CUST_VOL                   --期初客户数
, STRT_QLFD_CUST_VOL              --期初合格客户数
, STRT_T3BOD_CUST_VOL             --期初三板客户数
, STRT_HK_CUST_VOL                --期初沪港通客户数	
, STRT_SK_CUST_VOL                --期初深港通客户数
, STRT_H_K_CUST_VOL               --期初港股通客户数
, STRT_REPO_MRGNC_CUST_VOL        --期初回购融资客户数	
, STRT_REPO_MRGNS_CUST_VOL        --期初回购融券客户数		
, STRT_NEW_T3BOD_CUST_VOL         --期初新三板客户数
, STRT_CRD_CUST_VOL               --期初信用客户数		
, STRT_WRNT_CUST_VOL              --期初期权客户数
, STRT_GEM_CUST_VOL               --期初创业板客户数
, STRT_DLSTG_CUST_VOL             --期初退市整理客户数
, STRT_BOND_QLFD_IVSM_CUST_VOL    --期初债券合格投资客户数
, STRT_QOT_REPO_CUST_VOL          --期初报价回购客户数	
, STRT_PROMS_RPHS_CUST_VOL        --期初约定购回客户数
, STRT_STK_PLG_CUST_VOL           --期初股票质押客户数	
, STRT_MIN_LOAN_CUST_VOL          --期初小微贷质押客户数
, STRT_STR_FND_CUST_VOL           --期初分级基金客户数	
, STRT_STIB_CUST_VOL              --期初科创板客户数	
, STRT_LMT_NEW_T3BOD_CUST_VOL     --期初新三板(受限制)客户数	
, STRT_CASH_PROD_CUST_VOL         --期初现金添利客户数
, FNL_CUST_VOL                    --期末客户数
, FNL_QLFD_CUST_VOL               --期末合格客户数
, FNL_T3BOD_CUST_VOL              --期末三板客户数
, FNL_HK_CUST_VOL                 --期末沪港通客户数	
, FNL_SK_CUST_VOL                 --期末深港通客户数
, FNL_H_K_CUST_VOL                --期末港股通客户数
, FNL_REPO_MRGNC_CUST_VOL         --期末回购融资客户数	
, FNL_REPO_MRGNS_CUST_VOL         --期末回购融券客户数		
, FNL_NEW_T3BOD_CUST_VOL          --期末新三板客户数
, FNL_CRD_CUST_VOL                --期末信用客户数		
, FNL_WRNT_CUST_VOL               --期末期权客户数
, FNL_GEM_CUST_VOL                --期末创业板客户数
, FNL_DLSTG_CUST_VOL              --期末退市整理客户数
, FNL_BOND_QLFD_IVSM_CUST_VOL     --期末债券合格投资客户数
, FNL_QOT_REPO_CUST_VOL           --期末报价回购客户数	
, FNL_PROMS_RPHS_CUST_VOL         --期末约定购回客户数
, FNL_STK_PLG_CUST_VOL            --期末股票质押客户数	
, FNL_MIN_LOAN_CUST_VOL           --期末小微贷质押客户数
, FNL_STR_FND_CUST_VOL            --期末分级基金客户数	
, FNL_STIB_CUST_VOL               --期末科创板客户数	
, FNL_LMT_NEW_T3BOD_CUST_VOL      --期末新三板(受限制)客户数	
, FNL_CASH_PROD_CUST_VOL          --期末现金添利客户数
, OPANC_VOL                       --当月开户数
, CNCLACT_VOL                     --当月销户数			
, CNCLACT_QLFD_CUST_VOL           --当月销户合格客户数
, OPNAC_QLFD_CUST_VOL             --当月开户合格客户数
, OPN_T3BOD_CUST_VOL              --当月开通三板客户数
, OPN_HK_CUST_VOL                 --当月开通沪港通客户数	
, OPN_SK_CUST_VOL                 --当月开通深港通客户数
, OPN_H_K_CUST_VOL                --当月开通港股通客户数
, OPN_REPO_MRGNC_CUST_VOL         --当月开通回购融资客户数	
, OPN_REPO_MRGNS_CUST_VOL         --当月开通回购融券客户数	
, OPN_NEW_T3BOD_CUST_VOL          --当月开通新三板客户数
, OPNAC_CRD_CUST_VOL              --当月开户信用客户数		
, OPNAC_WRNT_CUST_VOL             --当月开户期权客户数
, OPN_GEM_CUST_VOL                --当月开通创业板客户数
, OPN_DLSTG_CUST_VOL              --当月开通退市整理客户数
, OPN_BOND_QLFD_IVSM_CUST_VOL     --当月开通债券合格投资客户数
, OPN_QOT_REPO_CUST_VOL           --当月开通报价回购客户数	
, OPN_PROMS_RPHS_CUST_VOL         --当月开通约定购回客户数
, OPN_STK_PLG_CUST_VOL            --当月开通股票质押客户数	
, OPN_MIN_LOAN_CUST_VOL           --当月开通小微贷质押客户数
, OPN_STR_FND_CUST_VOL            --当月开通分级基金客户数	
, OPN_STIB_CUST_VOL               --当月开通科创板客户数	
	
, OPN_CASH_PROD_CUST_VOL          --当月开通现金添利客户数				
, CLS_T3BOD_CUST_VOL              --当月关闭三板客户数
, CLS_HK_CUST_VOL                 --当月关闭沪港通客户数	
, CLS_SK_CUST_VOL                 --当月关闭深港通客户数
, CLS_H_K_CUST_VOL                --当月关闭港股通客户数
, CLS_REPO_MRGNC_CUST_VOL         --当月关闭回购融资客户数	
, CLS_REPO_MRGNS_CUST_VOL         --当月关闭回购融券客户数	
, CLS_NEW_T3BOD_CUST_VOL          --当月关闭新三板客户数
, CNCLACT_CRD_CUST_VOL            --当月销户信用客户数		
, CNCLACT_WRNT_CUST_VOL           --当月销户期权客户数
, CLS_GEM_CUST_VOL                --当月关闭创业板客户数
, CLS_DLSTG_CUST_VOL              --当月关闭退市整理客户数
, CLS_BOND_QLFD_IVSM_CUST_VOL     --当月关闭债券合格投资客户数
, CLS_QOT_REPO_CUST_VOL           --当月关闭报价回购客户数	
, CLS_PROMS_RPHS_CUST_VOL         --当月关闭约定购回客户数
, CLS_STK_PLG_CUST_VOL            --当月关闭股票质押客户数	
, CLS_MIN_LOAN_CUST_VOL           --当月关闭小微贷质押客户数
, CLS_STR_FND_CUST_VOL            --当月关闭分级基金客户数	
, CLS_STIB_CUST_VOL               --当月关闭科创板客户数	
	
, CLS_CASH_PROD_CUST_VOL          --当月关闭现金添利客户数
, GT_OPANC_VOL                    --本年累计开户数
, GT_CNCLACT_VOL                  --本年累计销户数			
, GT_CNCLACT_QLFD_CUST_VOL        --本年累计销户合格客户数
, GT_OPNAC_QLFD_CUST_VOL          --本年累计开户合格客户数
, GT_OPN_T3BOD_CUST_VOL           --本年累计开通三板客户数
, GT_OPN_HK_CUST_VOL              --本年累计开通沪港通客户数	
, GT_OPN_SK_CUST_VOL              --本年累计开通深港通客户数
, GT_OPN_H_K_CUST_VOL             --本年累计开通港股通客户数
, GT_OPN_REPO_MRGNC_CUST_VOL      --本年累计开通回购融资客户数	
, GT_OPN_REPO_MRGNS_CUST_VOL      --本年累计开通回购融券客户数	
, GT_OPN_NEW_T3BOD_CUST_VOL       --本年累计开通新三板客户数
, GT_OPNAC_CRD_CUST_VOL           --本年累计开户信用客户数		
, GT_OPNAC_WRNT_CUST_VOL          --本年累计开户期权客户数
, GT_OPN_GEM_CUST_VOL             --本年累计开通创业板客户数
, GT_OPN_DLSTG_CUST_VOL           --本年累计开通退市整理客户数
, GT_OPN_BOND_QLFD_IVSM_CUST_VOL  --本年累计开通债券合格投资客户数
, GT_OPN_QOT_REPO_CUST_VOL        --本年累计开通报价回购客户数	
, GT_OPN_PROMS_RPHS_CUST_VOL      --本年累计开通约定购回客户数
, GT_OPN_STK_PLG_CUST_VOL         --本年累计开通股票质押客户数	
, GT_OPN_MIN_LOAN_CUST_VOL        --本年累计开通小微贷质押客户数
, GT_OPN_STR_FND_CUST_VOL         --本年累计开通分级基金客户数	
, GT_OPN_STIB_CUST_VOL            --本年累计开通科创板客户数	
	
, GT_OPN_CASH_PROD_CUST_VOL       --本年累计开通现金添利客户数				
, GT_CLS_T3BOD_CUST_VOL           --本年累计关闭三板客户数
, GT_CLS_HK_CUST_VOL              --本年累计关闭沪港通客户数	
, GT_CLS_SK_CUST_VOL              --本年累计关闭深港通客户数
, GT_CLS_H_K_CUST_VOL             --本年累计关闭港股通客户数
, GT_CLS_REPO_MRGNC_CUST_VOL      --本年累计关闭回购融资客户数	
, GT_CLS_REPO_MRGNS_CUST_VOL      --本年累计关闭回购融券客户数	
, GT_CLS_NEW_T3BOD_CUST_VOL       --本年累计关闭新三板客户数
, GT_CNCLACT_CRD_CUST_VOL         --本年累计销户信用客户数		
, GT_CNCLACT_WRNT_CUST_VOL        --本年累计销户期权客户数
, GT_CLS_GEM_CUST_VOL             --本年累计关闭创业板客户数
, GT_CLS_DLSTG_CUST_VOL           --本年累计关闭退市整理客户数
, GT_CLS_BOND_QLFD_IVSM_CUST_VOL  --本年累计关闭债券合格投资客户数
, GT_CLS_QOT_REPO_CUST_VOL        --本年累计关闭报价回购客户数	
, GT_CLS_PROMS_RPHS_CUST_VOL      --本年累计关闭约定购回客户数
, GT_CLS_STK_PLG_CUST_VOL         --本年累计关闭股票质押客户数	
, GT_CLS_MIN_LOAN_CUST_VOL        --本年累计关闭小微贷质押客户数
, GT_CLS_STR_FND_CUST_VOL         --本年累计关闭分级基金客户数	
, GT_CLS_STIB_CUST_VOL            --本年累计关闭科创板客户数	
	
, GT_CLS_CASH_PROD_CUST_VOL       --本年累计关闭现金添利客户数
, TADDED_VLD_CUST_VOL             --新增有效客户数
, GT_TADDED_VLD_CUST_VOL          --累计新增有效客户数
, STOCK_ACTVT_CUST_VOL            --存量激活客户数
, GT_STOCK_ACTVT_CUST_VOL         --存量累计激活客户数
, ETL_DT                          --加载日期               
 ) PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
SELECT      t.BELTO_FILIL_CDG                --分公司编码
          , t.BELTO_FILIL                    --分公司名称
          , t.BRH_NO                         --营业部编码
          , t.BRH_FULLNM                     --营业部名称
          , t.CUST_CGY                       --客户类别
          , NVL(a1.STRT_CUST_VOL,0)                   --期初客户数
          , NVL(a1.STRT_QLFD_CUST_VOL,0)              --期初合格客户数
          , NVL(a1.STRT_T3BOD_CUST_VOL,0)             --期初三板客户数
          , NVL(a1.STRT_HK_CUST_VOL,0)                --期初沪港通客户数	
          , NVL(a1.STRT_SK_CUST_VOL,0)                --期初深港通客户数
          , NVL(a1.STRT_H_K_CUST_VOL,0)               --期初港股通客户数
          , NVL(a1.STRT_REPO_MRGNC_CUST_VOL,0)        --期初回购融资客户数	
          , NVL(a1.STRT_REPO_MRGNS_CUST_VOL,0)        --期初回购融券客户数		
          , NVL(a1.STRT_NEW_T3BOD_CUST_VOL,0)         --期初新三板客户数
          , NVL(a1.STRT_CRD_CUST_VOL,0)               --期初信用客户数		
          , NVL(a1.STRT_WRNT_CUST_VOL,0)              --期初期权客户数
          , NVL(a1.STRT_GEM_CUST_VOL,0)               --期初创业板客户数
          , NVL(a1.STRT_DLSTG_CUST_VOL,0)             --期初退市整理客户数
          , NVL(a1.STRT_BOND_QLFD_IVSM_CUST_VOL,0)    --期初债券合格投资客户数
          , NVL(a1.STRT_QOT_REPO_CUST_VOL,0)          --期初报价回购客户数	
          , NVL(a1.STRT_PROMS_RPHS_CUST_VOL,0)        --期初约定购回客户数
          , NVL(a1.STRT_STK_PLG_CUST_VOL,0)           --期初股票质押客户数	
          , NVL(a1.STRT_MIN_LOAN_CUST_VOL,0)          --期初小微贷质押客户数
          , NVL(a1.STRT_STR_FND_CUST_VOL,0)           --期初分级基金客户数	
          , NVL(a1.STRT_STIB_CUST_VOL,0)              --期初科创板客户数	
          , NVL(a1.STRT_LMT_NEW_T3BOD_CUST_VOL,0)     --期初新三板(受限制)客户数	
          , NVL(a1.STRT_CASH_PROD_CUST_VOL,0)         --期初现金添利客户数
          , NVL(a2.FNL_CUST_VOL,0)                    --期末客户数
          , NVL(a2.FNL_QLFD_CUST_VOL,0)               --期末合格客户数
          , NVL(a2.FNL_T3BOD_CUST_VOL,0)              --期末三板客户数
          , NVL(a2.FNL_HK_CUST_VOL,0)                 --期末沪港通客户数	
          , NVL(a2.FNL_SK_CUST_VOL,0)                 --期末深港通客户数
          , NVL(a2.FNL_H_K_CUST_VOL,0)                --期末港股通客户数
          , NVL(a2.FNL_REPO_MRGNC_CUST_VOL,0)         --期末回购融资客户数	
          , NVL(a2.FNL_REPO_MRGNS_CUST_VOL,0)         --期末回购融券客户数		
          , NVL(a2.FNL_NEW_T3BOD_CUST_VOL,0)          --期末新三板客户数
          , NVL(a2.FNL_CRD_CUST_VOL,0)                --期末信用客户数		
          , NVL(a2.FNL_WRNT_CUST_VOL,0)               --期末期权客户数
          , NVL(a2.FNL_GEM_CUST_VOL,0)                --期末创业板客户数
          , NVL(a2.FNL_DLSTG_CUST_VOL,0)              --期末退市整理客户数
          , NVL(a2.FNL_BOND_QLFD_IVSM_CUST_VOL,0)     --期末债券合格投资客户数
          , NVL(a2.FNL_QOT_REPO_CUST_VOL,0)           --期末报价回购客户数	
          , NVL(a2.FNL_PROMS_RPHS_CUST_VOL,0)         --期末约定购回客户数
          , NVL(a2.FNL_STK_PLG_CUST_VOL,0)            --期末股票质押客户数	
          , NVL(a2.FNL_MIN_LOAN_CUST_VOL,0)           --期末小微贷质押客户数
          , NVL(a2.FNL_STR_FND_CUST_VOL,0)            --期末分级基金客户数	
          , NVL(a2.FNL_STIB_CUST_VOL,0)               --期末科创板客户数	
          , NVL(a2.FNL_LMT_NEW_T3BOD_CUST_VOL,0)      --期末新三板(受限制)客户数	
          , NVL(a2.FNL_CASH_PROD_CUST_VOL,0)          --期末现金添利客户数
          , NVL(a2.OPANC_VOL,0)                       --当月开户数
          , NVL(a2.CNCLACT_VOL,0)                     --当月销户数			
          , NVL(a2.CNCLACT_QLFD_CUST_VOL,0)           --当月销户合格客户数
          , NVL(a2.OPNAC_QLFD_CUST_VOL,0)             --当月开户合格客户数
          , NVL(a2.OPN_T3BOD_CUST_VOL,0)              --当月开通三板客户数
          , NVL(a2.OPN_HK_CUST_VOL,0)                 --当月开通沪港通客户数	
          , NVL(a2.OPN_SK_CUST_VOL,0)                 --当月开通深港通客户数
          , NVL(a2.OPN_H_K_CUST_VOL,0)                --当月开通港股通客户数
          , NVL(a2.OPN_REPO_MRGNC_CUST_VOL,0)         --当月开通回购融资客户数	
          , NVL(a2.OPN_REPO_MRGNS_CUST_VOL,0)         --当月开通回购融券客户数	
          , NVL(a2.OPN_NEW_T3BOD_CUST_VOL,0)          --当月开通新三板客户数
          , NVL(a2.OPNAC_CRD_CUST_VOL,0)              --当月开户信用客户数		
          , NVL(a2.OPNAC_WRNT_CUST_VOL,0)             --当月开户期权客户数
          , NVL(a2.OPN_GEM_CUST_VOL,0)                --当月开通创业板客户数
          , NVL(a2.OPN_DLSTG_CUST_VOL,0)              --当月开通退市整理客户数
          , NVL(a2.OPN_BOND_QLFD_IVSM_CUST_VOL,0)     --当月开通债券合格投资客户数
          , NVL(a2.OPN_QOT_REPO_CUST_VOL,0)           --当月开通报价回购客户数	
          , NVL(a2.OPN_PROMS_RPHS_CUST_VOL,0)         --当月开通约定购回客户数
          , NVL(a2.OPN_STK_PLG_CUST_VOL,0)            --当月开通股票质押客户数	
          , NVL(a2.OPN_MIN_LOAN_CUST_VOL,0)           --当月开通小微贷质押客户数
          , NVL(a2.OPN_STR_FND_CUST_VOL,0)            --当月开通分级基金客户数	
          , NVL(a2.OPN_STIB_CUST_VOL,0)               --当月开通科创板客户数	
         	
          , NVL(a2.OPN_CASH_PROD_CUST_VOL,0)          --当月开通现金添利客户数				
          , NVL(a2.CLS_T3BOD_CUST_VOL,0)              --当月关闭三板客户数
          , NVL(a2.CLS_HK_CUST_VOL,0)                 --当月关闭沪港通客户数	
          , NVL(a2.CLS_SK_CUST_VOL,0)                 --当月关闭深港通客户数
          , NVL(a2.CLS_H_K_CUST_VOL,0)                --当月关闭港股通客户数
          , NVL(a2.CLS_REPO_MRGNC_CUST_VOL,0)         --当月关闭回购融资客户数	
          , NVL(a2.CLS_REPO_MRGNS_CUST_VOL,0)         --当月关闭回购融券客户数	
          , NVL(a2.CLS_NEW_T3BOD_CUST_VOL,0)          --当月关闭新三板客户数
          , NVL(a2.CNCLACT_CRD_CUST_VOL,0)            --当月销户信用客户数		
          , NVL(a2.CNCLACT_WRNT_CUST_VOL,0)           --当月销户期权客户数
          , NVL(a2.CLS_GEM_CUST_VOL,0)                --当月关闭创业板客户数
          , NVL(a2.CLS_DLSTG_CUST_VOL,0)              --当月关闭退市整理客户数
          , NVL(a2.CLS_BOND_QLFD_IVSM_CUST_VOL,0)     --当月关闭债券合格投资客户数
          , NVL(a2.CLS_QOT_REPO_CUST_VOL,0)           --当月关闭报价回购客户数	
          , NVL(a2.CLS_PROMS_RPHS_CUST_VOL,0)         --当月关闭约定购回客户数
          , NVL(a2.CLS_STK_PLG_CUST_VOL,0)            --当月关闭股票质押客户数	
          , NVL(a2.CLS_MIN_LOAN_CUST_VOL,0)           --当月关闭小微贷质押客户数
          , NVL(a2.CLS_STR_FND_CUST_VOL,0)            --当月关闭分级基金客户数	
          , NVL(a2.CLS_STIB_CUST_VOL,0)               --当月关闭科创板客户数	
         	
          , NVL(a2.CLS_CASH_PROD_CUST_VOL,0)          --当月关闭现金添利客户数
          , NVL(a2.GT_OPANC_VOL,0)                    --本年累计开户数
          , NVL(a2.GT_CNCLACT_VOL,0)                  --本年累计销户数			
          , NVL(a2.GT_CNCLACT_QLFD_CUST_VOL,0)        --本年累计销户合格客户数
          , NVL(a2.GT_OPNAC_QLFD_CUST_VOL,0)          --本年累计开户合格客户数
          , NVL(a2.GT_OPN_T3BOD_CUST_VOL,0)           --本年累计开通三板客户数
          , NVL(a2.GT_OPN_HK_CUST_VOL,0)              --本年累计开通沪港通客户数	
          , NVL(a2.GT_OPN_SK_CUST_VOL,0)              --本年累计开通深港通客户数
          , NVL(a2.GT_OPN_H_K_CUST_VOL,0)             --本年累计开通港股通客户数
          , NVL(a2.GT_OPN_REPO_MRGNC_CUST_VOL,0)      --本年累计开通回购融资客户数	
          , NVL(a2.GT_OPN_REPO_MRGNS_CUST_VOL,0)      --本年累计开通回购融券客户数	
          , NVL(a2.GT_OPN_NEW_T3BOD_CUST_VOL,0)       --本年累计开通新三板客户数
          , NVL(a2.GT_OPNAC_CRD_CUST_VOL,0)           --本年累计开户信用客户数		
          , NVL(a2.GT_OPNAC_WRNT_CUST_VOL,0)          --本年累计开户期权客户数
          , NVL(a2.GT_OPN_GEM_CUST_VOL,0)             --本年累计开通创业板客户数
          , NVL(a2.GT_OPN_DLSTG_CUST_VOL,0)           --本年累计开通退市整理客户数
          , NVL(a2.GT_OPN_BOND_QLFD_IVSM_CUST_VOL,0)  --本年累计开通债券合格投资客户数
          , NVL(a2.GT_OPN_QOT_REPO_CUST_VOL,0)        --本年累计开通报价回购客户数	
          , NVL(a2.GT_OPN_PROMS_RPHS_CUST_VOL,0)      --本年累计开通约定购回客户数
          , NVL(a2.GT_OPN_STK_PLG_CUST_VOL,0)         --本年累计开通股票质押客户数	
          , NVL(a2.GT_OPN_MIN_LOAN_CUST_VOL,0)        --本年累计开通小微贷质押客户数
          , NVL(a2.GT_OPN_STR_FND_CUST_VOL,0)         --本年累计开通分级基金客户数	
          , NVL(a2.GT_OPN_STIB_CUST_VOL,0)            --本年累计开通科创板客户数	
         	
          , NVL(a2.GT_OPN_CASH_PROD_CUST_VOL,0)       --本年累计开通现金添利客户数				
          , NVL(a2.GT_CLS_T3BOD_CUST_VOL,0)           --本年累计关闭三板客户数
          , NVL(a2.GT_CLS_HK_CUST_VOL,0)              --本年累计关闭沪港通客户数	
          , NVL(a2.GT_CLS_SK_CUST_VOL,0)              --本年累计关闭深港通客户数
          , NVL(a2.GT_CLS_H_K_CUST_VOL,0)             --本年累计关闭港股通客户数
          , NVL(a2.GT_CLS_REPO_MRGNC_CUST_VOL,0)      --本年累计关闭回购融资客户数	
          , NVL(a2.GT_CLS_REPO_MRGNS_CUST_VOL,0)      --本年累计关闭回购融券客户数	
          , NVL(a2.GT_CLS_NEW_T3BOD_CUST_VOL,0)       --本年累计关闭新三板客户数
          , NVL(a2.GT_CNCLACT_CRD_CUST_VOL,0)         --本年累计销户信用客户数		
          , NVL(a2.GT_CNCLACT_WRNT_CUST_VOL,0)        --本年累计销户期权客户数
          , NVL(a2.GT_CLS_GEM_CUST_VOL,0)             --本年累计关闭创业板客户数
          , NVL(a2.GT_CLS_DLSTG_CUST_VOL,0)           --本年累计关闭退市整理客户数
          , NVL(a2.GT_CLS_BOND_QLFD_IVSM_CUST_VOL,0)  --本年累计关闭债券合格投资客户数
          , NVL(a2.GT_CLS_QOT_REPO_CUST_VOL,0)        --本年累计关闭报价回购客户数	
          , NVL(a2.GT_CLS_PROMS_RPHS_CUST_VOL,0)      --本年累计关闭约定购回客户数
          , NVL(a2.GT_CLS_STK_PLG_CUST_VOL,0)         --本年累计关闭股票质押客户数	
          , NVL(a2.GT_CLS_MIN_LOAN_CUST_VOL,0)        --本年累计关闭小微贷质押客户数
          , NVL(a2.GT_CLS_STR_FND_CUST_VOL,0)         --本年累计关闭分级基金客户数	
          , NVL(a2.GT_CLS_STIB_CUST_VOL,0)            --本年累计关闭科创板客户数	
          	
          , NVL(a2.GT_CLS_CASH_PROD_CUST_VOL,0)       --本年累计关闭现金添利客户数
          , NVL(a2.TADDED_VLD_CUST_VOL,0)             --新增有效客户数
          , NVL(a2.GT_TADDED_VLD_CUST_VOL,0)          --累计新增有效客户数
          , NVL(a2.STOCK_ACTVT_CUST_VOL,0)            --存量激活客户数
          , NVL(a2.GT_STOCK_ACTVT_CUST_VOL,0)         --存量累计激活客户数
          , %d{yyyyMMdd}                         --加载日期  
FROM   (SELECT *,'0' as CUST_CGY 
        FROM  DDW_PROD.T_DDW_INR_ORG_BRH
        WHERE BUS_DATE = %d{yyyyMMdd}
       )		t
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON_TEMP a1
ON        t.BRH_NO = a1.BRH_NO
AND       t.CUST_CGY = a1.CUST_CGY
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON_TEMP1 a2
ON        t.BRH_NO = a2.BRH_NO
AND       t.CUST_CGY = a2.CUST_CGY
UNION ALL
SELECT      t.BELTO_FILIL_CDG                --分公司编码
          , t.BELTO_FILIL                    --分公司名称
          , t.BRH_NO                         --营业部编码
          , t.BRH_FULLNM                     --营业部名称
          , t.CUST_CGY                       --客户类别
          , NVL(a1.STRT_CUST_VOL,0)                   --期初客户数
          , NVL(a1.STRT_QLFD_CUST_VOL,0)              --期初合格客户数
          , NVL(a1.STRT_T3BOD_CUST_VOL,0)             --期初三板客户数
          , NVL(a1.STRT_HK_CUST_VOL,0)                --期初沪港通客户数	
          , NVL(a1.STRT_SK_CUST_VOL,0)                --期初深港通客户数
          , NVL(a1.STRT_H_K_CUST_VOL,0)               --期初港股通客户数
          , NVL(a1.STRT_REPO_MRGNC_CUST_VOL,0)        --期初回购融资客户数	
          , NVL(a1.STRT_REPO_MRGNS_CUST_VOL,0)        --期初回购融券客户数		
          , NVL(a1.STRT_NEW_T3BOD_CUST_VOL,0)         --期初新三板客户数
          , NVL(a1.STRT_CRD_CUST_VOL,0)               --期初信用客户数		
          , NVL(a1.STRT_WRNT_CUST_VOL,0)              --期初期权客户数
          , NVL(a1.STRT_GEM_CUST_VOL,0)               --期初创业板客户数
          , NVL(a1.STRT_DLSTG_CUST_VOL,0)             --期初退市整理客户数
          , NVL(a1.STRT_BOND_QLFD_IVSM_CUST_VOL,0)    --期初债券合格投资客户数
          , NVL(a1.STRT_QOT_REPO_CUST_VOL,0)          --期初报价回购客户数	
          , NVL(a1.STRT_PROMS_RPHS_CUST_VOL,0)        --期初约定购回客户数
          , NVL(a1.STRT_STK_PLG_CUST_VOL,0)           --期初股票质押客户数	
          , NVL(a1.STRT_MIN_LOAN_CUST_VOL,0)          --期初小微贷质押客户数
          , NVL(a1.STRT_STR_FND_CUST_VOL,0)           --期初分级基金客户数	
          , NVL(a1.STRT_STIB_CUST_VOL,0)              --期初科创板客户数	
          , NVL(a1.STRT_LMT_NEW_T3BOD_CUST_VOL,0)     --期初新三板(受限制)客户数	
          , NVL(a1.STRT_CASH_PROD_CUST_VOL,0)         --期初现金添利客户数
          , NVL(a2.FNL_CUST_VOL,0)                    --期末客户数
          , NVL(a2.FNL_QLFD_CUST_VOL,0)               --期末合格客户数
          , NVL(a2.FNL_T3BOD_CUST_VOL,0)              --期末三板客户数
          , NVL(a2.FNL_HK_CUST_VOL,0)                 --期末沪港通客户数	
          , NVL(a2.FNL_SK_CUST_VOL,0)                 --期末深港通客户数
          , NVL(a2.FNL_H_K_CUST_VOL,0)                --期末港股通客户数
          , NVL(a2.FNL_REPO_MRGNC_CUST_VOL,0)         --期末回购融资客户数	
          , NVL(a2.FNL_REPO_MRGNS_CUST_VOL,0)         --期末回购融券客户数		
          , NVL(a2.FNL_NEW_T3BOD_CUST_VOL,0)          --期末新三板客户数
          , NVL(a2.FNL_CRD_CUST_VOL,0)                --期末信用客户数		
          , NVL(a2.FNL_WRNT_CUST_VOL,0)               --期末期权客户数
          , NVL(a2.FNL_GEM_CUST_VOL,0)                --期末创业板客户数
          , NVL(a2.FNL_DLSTG_CUST_VOL,0)              --期末退市整理客户数
          , NVL(a2.FNL_BOND_QLFD_IVSM_CUST_VOL,0)     --期末债券合格投资客户数
          , NVL(a2.FNL_QOT_REPO_CUST_VOL,0)           --期末报价回购客户数	
          , NVL(a2.FNL_PROMS_RPHS_CUST_VOL,0)         --期末约定购回客户数
          , NVL(a2.FNL_STK_PLG_CUST_VOL,0)            --期末股票质押客户数	
          , NVL(a2.FNL_MIN_LOAN_CUST_VOL,0)           --期末小微贷质押客户数
          , NVL(a2.FNL_STR_FND_CUST_VOL,0)            --期末分级基金客户数	
          , NVL(a2.FNL_STIB_CUST_VOL,0)               --期末科创板客户数	
          , NVL(a2.FNL_LMT_NEW_T3BOD_CUST_VOL,0)      --期末新三板(受限制)客户数	
          , NVL(a2.FNL_CASH_PROD_CUST_VOL,0)          --期末现金添利客户数
          , NVL(a2.OPANC_VOL,0)                       --当月开户数
          , NVL(a2.CNCLACT_VOL,0)                     --当月销户数			
          , NVL(a2.CNCLACT_QLFD_CUST_VOL,0)           --当月销户合格客户数
          , NVL(a2.OPNAC_QLFD_CUST_VOL,0)             --当月开户合格客户数
          , NVL(a2.OPN_T3BOD_CUST_VOL,0)              --当月开通三板客户数
          , NVL(a2.OPN_HK_CUST_VOL,0)                 --当月开通沪港通客户数	
          , NVL(a2.OPN_SK_CUST_VOL,0)                 --当月开通深港通客户数
          , NVL(a2.OPN_H_K_CUST_VOL,0)                --当月开通港股通客户数
          , NVL(a2.OPN_REPO_MRGNC_CUST_VOL,0)         --当月开通回购融资客户数	
          , NVL(a2.OPN_REPO_MRGNS_CUST_VOL,0)         --当月开通回购融券客户数	
          , NVL(a2.OPN_NEW_T3BOD_CUST_VOL,0)          --当月开通新三板客户数
          , NVL(a2.OPNAC_CRD_CUST_VOL,0)              --当月开户信用客户数		
          , NVL(a2.OPNAC_WRNT_CUST_VOL,0)             --当月开户期权客户数
          , NVL(a2.OPN_GEM_CUST_VOL,0)                --当月开通创业板客户数
          , NVL(a2.OPN_DLSTG_CUST_VOL,0)              --当月开通退市整理客户数
          , NVL(a2.OPN_BOND_QLFD_IVSM_CUST_VOL,0)     --当月开通债券合格投资客户数
          , NVL(a2.OPN_QOT_REPO_CUST_VOL,0)           --当月开通报价回购客户数	
          , NVL(a2.OPN_PROMS_RPHS_CUST_VOL,0)         --当月开通约定购回客户数
          , NVL(a2.OPN_STK_PLG_CUST_VOL,0)            --当月开通股票质押客户数	
          , NVL(a2.OPN_MIN_LOAN_CUST_VOL,0)           --当月开通小微贷质押客户数
          , NVL(a2.OPN_STR_FND_CUST_VOL,0)            --当月开通分级基金客户数	
          , NVL(a2.OPN_STIB_CUST_VOL,0)               --当月开通科创板客户数	
         	
          , NVL(a2.OPN_CASH_PROD_CUST_VOL,0)          --当月开通现金添利客户数				
          , NVL(a2.CLS_T3BOD_CUST_VOL,0)              --当月关闭三板客户数
          , NVL(a2.CLS_HK_CUST_VOL,0)                 --当月关闭沪港通客户数	
          , NVL(a2.CLS_SK_CUST_VOL,0)                 --当月关闭深港通客户数
          , NVL(a2.CLS_H_K_CUST_VOL,0)                --当月关闭港股通客户数
          , NVL(a2.CLS_REPO_MRGNC_CUST_VOL,0)         --当月关闭回购融资客户数	
          , NVL(a2.CLS_REPO_MRGNS_CUST_VOL,0)         --当月关闭回购融券客户数	
          , NVL(a2.CLS_NEW_T3BOD_CUST_VOL,0)          --当月关闭新三板客户数
          , NVL(a2.CNCLACT_CRD_CUST_VOL,0)            --当月销户信用客户数		
          , NVL(a2.CNCLACT_WRNT_CUST_VOL,0)           --当月销户期权客户数
          , NVL(a2.CLS_GEM_CUST_VOL,0)                --当月关闭创业板客户数
          , NVL(a2.CLS_DLSTG_CUST_VOL,0)              --当月关闭退市整理客户数
          , NVL(a2.CLS_BOND_QLFD_IVSM_CUST_VOL,0)     --当月关闭债券合格投资客户数
          , NVL(a2.CLS_QOT_REPO_CUST_VOL,0)           --当月关闭报价回购客户数	
          , NVL(a2.CLS_PROMS_RPHS_CUST_VOL,0)         --当月关闭约定购回客户数
          , NVL(a2.CLS_STK_PLG_CUST_VOL,0)            --当月关闭股票质押客户数	
          , NVL(a2.CLS_MIN_LOAN_CUST_VOL,0)           --当月关闭小微贷质押客户数
          , NVL(a2.CLS_STR_FND_CUST_VOL,0)            --当月关闭分级基金客户数	
          , NVL(a2.CLS_STIB_CUST_VOL,0)               --当月关闭科创板客户数	
    	
          , NVL(a2.CLS_CASH_PROD_CUST_VOL,0)          --当月关闭现金添利客户数
          , NVL(a2.GT_OPANC_VOL,0)                    --本年累计开户数
          , NVL(a2.GT_CNCLACT_VOL,0)                  --本年累计销户数			
          , NVL(a2.GT_CNCLACT_QLFD_CUST_VOL,0)        --本年累计销户合格客户数
          , NVL(a2.GT_OPNAC_QLFD_CUST_VOL,0)          --本年累计开户合格客户数
          , NVL(a2.GT_OPN_T3BOD_CUST_VOL,0)           --本年累计开通三板客户数
          , NVL(a2.GT_OPN_HK_CUST_VOL,0)              --本年累计开通沪港通客户数	
          , NVL(a2.GT_OPN_SK_CUST_VOL,0)              --本年累计开通深港通客户数
          , NVL(a2.GT_OPN_H_K_CUST_VOL,0)             --本年累计开通港股通客户数
          , NVL(a2.GT_OPN_REPO_MRGNC_CUST_VOL,0)      --本年累计开通回购融资客户数	
          , NVL(a2.GT_OPN_REPO_MRGNS_CUST_VOL,0)      --本年累计开通回购融券客户数	
          , NVL(a2.GT_OPN_NEW_T3BOD_CUST_VOL,0)       --本年累计开通新三板客户数
          , NVL(a2.GT_OPNAC_CRD_CUST_VOL,0)           --本年累计开户信用客户数		
          , NVL(a2.GT_OPNAC_WRNT_CUST_VOL,0)          --本年累计开户期权客户数
          , NVL(a2.GT_OPN_GEM_CUST_VOL,0)             --本年累计开通创业板客户数
          , NVL(a2.GT_OPN_DLSTG_CUST_VOL,0)           --本年累计开通退市整理客户数
          , NVL(a2.GT_OPN_BOND_QLFD_IVSM_CUST_VOL,0)  --本年累计开通债券合格投资客户数
          , NVL(a2.GT_OPN_QOT_REPO_CUST_VOL,0)        --本年累计开通报价回购客户数	
          , NVL(a2.GT_OPN_PROMS_RPHS_CUST_VOL,0)      --本年累计开通约定购回客户数
          , NVL(a2.GT_OPN_STK_PLG_CUST_VOL,0)         --本年累计开通股票质押客户数	
          , NVL(a2.GT_OPN_MIN_LOAN_CUST_VOL,0)        --本年累计开通小微贷质押客户数
          , NVL(a2.GT_OPN_STR_FND_CUST_VOL,0)         --本年累计开通分级基金客户数	
          , NVL(a2.GT_OPN_STIB_CUST_VOL,0)            --本年累计开通科创板客户数	
    	
          , NVL(a2.GT_OPN_CASH_PROD_CUST_VOL,0)       --本年累计开通现金添利客户数				
          , NVL(a2.GT_CLS_T3BOD_CUST_VOL,0)           --本年累计关闭三板客户数
          , NVL(a2.GT_CLS_HK_CUST_VOL,0)              --本年累计关闭沪港通客户数	
          , NVL(a2.GT_CLS_SK_CUST_VOL,0)              --本年累计关闭深港通客户数
          , NVL(a2.GT_CLS_H_K_CUST_VOL,0)             --本年累计关闭港股通客户数
          , NVL(a2.GT_CLS_REPO_MRGNC_CUST_VOL,0)      --本年累计关闭回购融资客户数	
          , NVL(a2.GT_CLS_REPO_MRGNS_CUST_VOL,0)      --本年累计关闭回购融券客户数	
          , NVL(a2.GT_CLS_NEW_T3BOD_CUST_VOL,0)       --本年累计关闭新三板客户数
          , NVL(a2.GT_CNCLACT_CRD_CUST_VOL,0)         --本年累计销户信用客户数		
          , NVL(a2.GT_CNCLACT_WRNT_CUST_VOL,0)        --本年累计销户期权客户数
          , NVL(a2.GT_CLS_GEM_CUST_VOL,0)             --本年累计关闭创业板客户数
          , NVL(a2.GT_CLS_DLSTG_CUST_VOL,0)           --本年累计关闭退市整理客户数
          , NVL(a2.GT_CLS_BOND_QLFD_IVSM_CUST_VOL,0)  --本年累计关闭债券合格投资客户数
          , NVL(a2.GT_CLS_QOT_REPO_CUST_VOL,0)        --本年累计关闭报价回购客户数	
          , NVL(a2.GT_CLS_PROMS_RPHS_CUST_VOL,0)      --本年累计关闭约定购回客户数
          , NVL(a2.GT_CLS_STK_PLG_CUST_VOL,0)         --本年累计关闭股票质押客户数	
          , NVL(a2.GT_CLS_MIN_LOAN_CUST_VOL,0)        --本年累计关闭小微贷质押客户数
          , NVL(a2.GT_CLS_STR_FND_CUST_VOL,0)         --本年累计关闭分级基金客户数	
          , NVL(a2.GT_CLS_STIB_CUST_VOL,0)            --本年累计关闭科创板客户数	
         	
          , NVL(a2.GT_CLS_CASH_PROD_CUST_VOL,0)       --本年累计关闭现金添利客户数
          , NVL(a2.TADDED_VLD_CUST_VOL,0)             --新增有效客户数
          , NVL(a2.GT_TADDED_VLD_CUST_VOL,0)          --累计新增有效客户数
          , NVL(a2.STOCK_ACTVT_CUST_VOL,0)            --存量激活客户数
          , NVL(a2.GT_STOCK_ACTVT_CUST_VOL,0)         --存量累计激活客户数
          , %d{yyyyMMdd}                         --加载日期  
FROM   (SELECT *,'1' as CUST_CGY 
        FROM  DDW_PROD.T_DDW_INR_ORG_BRH
        WHERE BUS_DATE = %d{yyyyMMdd}
       )		t
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON_TEMP a1
ON        t.BRH_NO = a1.BRH_NO
AND       t.CUST_CGY = a1.CUST_CGY
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON_TEMP1 a2
ON        t.BRH_NO = a2.BRH_NO
AND       t.CUST_CGY = a2.CUST_CGY
UNION ALL
SELECT      t.BELTO_FILIL_CDG                --分公司编码
          , t.BELTO_FILIL                    --分公司名称
          , t.BRH_NO                         --营业部编码
          , t.BRH_FULLNM                     --营业部名称
          , t.CUST_CGY                       --客户类别
          , NVL(a1.STRT_CUST_VOL,0)                   --期初客户数
          , NVL(a1.STRT_QLFD_CUST_VOL,0)              --期初合格客户数
          , NVL(a1.STRT_T3BOD_CUST_VOL,0)             --期初三板客户数
          , NVL(a1.STRT_HK_CUST_VOL,0)                --期初沪港通客户数	
          , NVL(a1.STRT_SK_CUST_VOL,0)                --期初深港通客户数
          , NVL(a1.STRT_H_K_CUST_VOL,0)               --期初港股通客户数
          , NVL(a1.STRT_REPO_MRGNC_CUST_VOL,0)        --期初回购融资客户数	
          , NVL(a1.STRT_REPO_MRGNS_CUST_VOL,0)        --期初回购融券客户数		
          , NVL(a1.STRT_NEW_T3BOD_CUST_VOL,0)         --期初新三板客户数
          , NVL(a1.STRT_CRD_CUST_VOL,0)               --期初信用客户数		
          , NVL(a1.STRT_WRNT_CUST_VOL,0)              --期初期权客户数
          , NVL(a1.STRT_GEM_CUST_VOL,0)               --期初创业板客户数
          , NVL(a1.STRT_DLSTG_CUST_VOL,0)             --期初退市整理客户数
          , NVL(a1.STRT_BOND_QLFD_IVSM_CUST_VOL,0)    --期初债券合格投资客户数
          , NVL(a1.STRT_QOT_REPO_CUST_VOL,0)          --期初报价回购客户数	
          , NVL(a1.STRT_PROMS_RPHS_CUST_VOL,0)        --期初约定购回客户数
          , NVL(a1.STRT_STK_PLG_CUST_VOL,0)           --期初股票质押客户数	
          , NVL(a1.STRT_MIN_LOAN_CUST_VOL,0)          --期初小微贷质押客户数
          , NVL(a1.STRT_STR_FND_CUST_VOL,0)           --期初分级基金客户数	
          , NVL(a1.STRT_STIB_CUST_VOL,0)              --期初科创板客户数	
          , NVL(a1.STRT_LMT_NEW_T3BOD_CUST_VOL,0)     --期初新三板(受限制)客户数	
          , NVL(a1.STRT_CASH_PROD_CUST_VOL,0)         --期初现金添利客户数
          , NVL(a2.FNL_CUST_VOL,0)                    --期末客户数
          , NVL(a2.FNL_QLFD_CUST_VOL,0)               --期末合格客户数
          , NVL(a2.FNL_T3BOD_CUST_VOL,0)              --期末三板客户数
          , NVL(a2.FNL_HK_CUST_VOL,0)                 --期末沪港通客户数	
          , NVL(a2.FNL_SK_CUST_VOL,0)                 --期末深港通客户数
          , NVL(a2.FNL_H_K_CUST_VOL,0)                --期末港股通客户数
          , NVL(a2.FNL_REPO_MRGNC_CUST_VOL,0)         --期末回购融资客户数	
          , NVL(a2.FNL_REPO_MRGNS_CUST_VOL,0)         --期末回购融券客户数		
          , NVL(a2.FNL_NEW_T3BOD_CUST_VOL,0)          --期末新三板客户数
          , NVL(a2.FNL_CRD_CUST_VOL,0)                --期末信用客户数		
          , NVL(a2.FNL_WRNT_CUST_VOL,0)               --期末期权客户数
          , NVL(a2.FNL_GEM_CUST_VOL,0)                --期末创业板客户数
          , NVL(a2.FNL_DLSTG_CUST_VOL,0)              --期末退市整理客户数
          , NVL(a2.FNL_BOND_QLFD_IVSM_CUST_VOL,0)     --期末债券合格投资客户数
          , NVL(a2.FNL_QOT_REPO_CUST_VOL,0)           --期末报价回购客户数	
          , NVL(a2.FNL_PROMS_RPHS_CUST_VOL,0)         --期末约定购回客户数
          , NVL(a2.FNL_STK_PLG_CUST_VOL,0)            --期末股票质押客户数	
          , NVL(a2.FNL_MIN_LOAN_CUST_VOL,0)           --期末小微贷质押客户数
          , NVL(a2.FNL_STR_FND_CUST_VOL,0)            --期末分级基金客户数	
          , NVL(a2.FNL_STIB_CUST_VOL,0)               --期末科创板客户数	
          , NVL(a2.FNL_LMT_NEW_T3BOD_CUST_VOL,0)      --期末新三板(受限制)客户数	
          , NVL(a2.FNL_CASH_PROD_CUST_VOL,0)          --期末现金添利客户数
          , NVL(a2.OPANC_VOL,0)                       --当月开户数
          , NVL(a2.CNCLACT_VOL,0)                     --当月销户数			
          , NVL(a2.CNCLACT_QLFD_CUST_VOL,0)           --当月销户合格客户数
          , NVL(a2.OPNAC_QLFD_CUST_VOL,0)             --当月开户合格客户数
          , NVL(a2.OPN_T3BOD_CUST_VOL,0)              --当月开通三板客户数
          , NVL(a2.OPN_HK_CUST_VOL,0)                 --当月开通沪港通客户数	
          , NVL(a2.OPN_SK_CUST_VOL,0)                 --当月开通深港通客户数
          , NVL(a2.OPN_H_K_CUST_VOL,0)                --当月开通港股通客户数
          , NVL(a2.OPN_REPO_MRGNC_CUST_VOL,0)         --当月开通回购融资客户数	
          , NVL(a2.OPN_REPO_MRGNS_CUST_VOL,0)         --当月开通回购融券客户数	
          , NVL(a2.OPN_NEW_T3BOD_CUST_VOL,0)          --当月开通新三板客户数
          , NVL(a2.OPNAC_CRD_CUST_VOL,0)              --当月开户信用客户数		
          , NVL(a2.OPNAC_WRNT_CUST_VOL,0)             --当月开户期权客户数
          , NVL(a2.OPN_GEM_CUST_VOL,0)                --当月开通创业板客户数
          , NVL(a2.OPN_DLSTG_CUST_VOL,0)              --当月开通退市整理客户数
          , NVL(a2.OPN_BOND_QLFD_IVSM_CUST_VOL,0)     --当月开通债券合格投资客户数
          , NVL(a2.OPN_QOT_REPO_CUST_VOL,0)           --当月开通报价回购客户数	
          , NVL(a2.OPN_PROMS_RPHS_CUST_VOL,0)         --当月开通约定购回客户数
          , NVL(a2.OPN_STK_PLG_CUST_VOL,0)            --当月开通股票质押客户数	
          , NVL(a2.OPN_MIN_LOAN_CUST_VOL,0)           --当月开通小微贷质押客户数
          , NVL(a2.OPN_STR_FND_CUST_VOL,0)            --当月开通分级基金客户数	
          , NVL(a2.OPN_STIB_CUST_VOL,0)               --当月开通科创板客户数	
         	
          , NVL(a2.OPN_CASH_PROD_CUST_VOL,0)          --当月开通现金添利客户数				
          , NVL(a2.CLS_T3BOD_CUST_VOL,0)              --当月关闭三板客户数
          , NVL(a2.CLS_HK_CUST_VOL,0)                 --当月关闭沪港通客户数	
          , NVL(a2.CLS_SK_CUST_VOL,0)                 --当月关闭深港通客户数
          , NVL(a2.CLS_H_K_CUST_VOL,0)                --当月关闭港股通客户数
          , NVL(a2.CLS_REPO_MRGNC_CUST_VOL,0)         --当月关闭回购融资客户数	
          , NVL(a2.CLS_REPO_MRGNS_CUST_VOL,0)         --当月关闭回购融券客户数	
          , NVL(a2.CLS_NEW_T3BOD_CUST_VOL,0)          --当月关闭新三板客户数
          , NVL(a2.CNCLACT_CRD_CUST_VOL,0)            --当月销户信用客户数		
          , NVL(a2.CNCLACT_WRNT_CUST_VOL,0)           --当月销户期权客户数
          , NVL(a2.CLS_GEM_CUST_VOL,0)                --当月关闭创业板客户数
          , NVL(a2.CLS_DLSTG_CUST_VOL,0)              --当月关闭退市整理客户数
          , NVL(a2.CLS_BOND_QLFD_IVSM_CUST_VOL,0)     --当月关闭债券合格投资客户数
          , NVL(a2.CLS_QOT_REPO_CUST_VOL,0)           --当月关闭报价回购客户数	
          , NVL(a2.CLS_PROMS_RPHS_CUST_VOL,0)         --当月关闭约定购回客户数
          , NVL(a2.CLS_STK_PLG_CUST_VOL,0)            --当月关闭股票质押客户数	
          , NVL(a2.CLS_MIN_LOAN_CUST_VOL,0)           --当月关闭小微贷质押客户数
          , NVL(a2.CLS_STR_FND_CUST_VOL,0)            --当月关闭分级基金客户数	
          , NVL(a2.CLS_STIB_CUST_VOL,0)               --当月关闭科创板客户数	
       	
          , NVL(a2.CLS_CASH_PROD_CUST_VOL,0)          --当月关闭现金添利客户数
          , NVL(a2.GT_OPANC_VOL,0)                    --本年累计开户数
          , NVL(a2.GT_CNCLACT_VOL,0)                  --本年累计销户数			
          , NVL(a2.GT_CNCLACT_QLFD_CUST_VOL,0)        --本年累计销户合格客户数
          , NVL(a2.GT_OPNAC_QLFD_CUST_VOL,0)          --本年累计开户合格客户数
          , NVL(a2.GT_OPN_T3BOD_CUST_VOL,0)           --本年累计开通三板客户数
          , NVL(a2.GT_OPN_HK_CUST_VOL,0)              --本年累计开通沪港通客户数	
          , NVL(a2.GT_OPN_SK_CUST_VOL,0)              --本年累计开通深港通客户数
          , NVL(a2.GT_OPN_H_K_CUST_VOL,0)             --本年累计开通港股通客户数
          , NVL(a2.GT_OPN_REPO_MRGNC_CUST_VOL,0)      --本年累计开通回购融资客户数	
          , NVL(a2.GT_OPN_REPO_MRGNS_CUST_VOL,0)      --本年累计开通回购融券客户数	
          , NVL(a2.GT_OPN_NEW_T3BOD_CUST_VOL,0)       --本年累计开通新三板客户数
          , NVL(a2.GT_OPNAC_CRD_CUST_VOL,0)           --本年累计开户信用客户数		
          , NVL(a2.GT_OPNAC_WRNT_CUST_VOL,0)          --本年累计开户期权客户数
          , NVL(a2.GT_OPN_GEM_CUST_VOL,0)             --本年累计开通创业板客户数
          , NVL(a2.GT_OPN_DLSTG_CUST_VOL,0)           --本年累计开通退市整理客户数
          , NVL(a2.GT_OPN_BOND_QLFD_IVSM_CUST_VOL,0)  --本年累计开通债券合格投资客户数
          , NVL(a2.GT_OPN_QOT_REPO_CUST_VOL,0)        --本年累计开通报价回购客户数	
          , NVL(a2.GT_OPN_PROMS_RPHS_CUST_VOL,0)      --本年累计开通约定购回客户数
          , NVL(a2.GT_OPN_STK_PLG_CUST_VOL,0)         --本年累计开通股票质押客户数	
          , NVL(a2.GT_OPN_MIN_LOAN_CUST_VOL,0)        --本年累计开通小微贷质押客户数
          , NVL(a2.GT_OPN_STR_FND_CUST_VOL,0)         --本年累计开通分级基金客户数	
          , NVL(a2.GT_OPN_STIB_CUST_VOL,0)            --本年累计开通科创板客户数	
	
          , NVL(a2.GT_OPN_CASH_PROD_CUST_VOL,0)       --本年累计开通现金添利客户数				
          , NVL(a2.GT_CLS_T3BOD_CUST_VOL,0)           --本年累计关闭三板客户数
          , NVL(a2.GT_CLS_HK_CUST_VOL,0)              --本年累计关闭沪港通客户数	
          , NVL(a2.GT_CLS_SK_CUST_VOL,0)              --本年累计关闭深港通客户数
          , NVL(a2.GT_CLS_H_K_CUST_VOL,0)             --本年累计关闭港股通客户数
          , NVL(a2.GT_CLS_REPO_MRGNC_CUST_VOL,0)      --本年累计关闭回购融资客户数	
          , NVL(a2.GT_CLS_REPO_MRGNS_CUST_VOL,0)      --本年累计关闭回购融券客户数	
          , NVL(a2.GT_CLS_NEW_T3BOD_CUST_VOL,0)       --本年累计关闭新三板客户数
          , NVL(a2.GT_CNCLACT_CRD_CUST_VOL,0)         --本年累计销户信用客户数		
          , NVL(a2.GT_CNCLACT_WRNT_CUST_VOL,0)        --本年累计销户期权客户数
          , NVL(a2.GT_CLS_GEM_CUST_VOL,0)             --本年累计关闭创业板客户数
          , NVL(a2.GT_CLS_DLSTG_CUST_VOL,0)           --本年累计关闭退市整理客户数
          , NVL(a2.GT_CLS_BOND_QLFD_IVSM_CUST_VOL,0)  --本年累计关闭债券合格投资客户数
          , NVL(a2.GT_CLS_QOT_REPO_CUST_VOL,0)        --本年累计关闭报价回购客户数	
          , NVL(a2.GT_CLS_PROMS_RPHS_CUST_VOL,0)      --本年累计关闭约定购回客户数
          , NVL(a2.GT_CLS_STK_PLG_CUST_VOL,0)         --本年累计关闭股票质押客户数	
          , NVL(a2.GT_CLS_MIN_LOAN_CUST_VOL,0)        --本年累计关闭小微贷质押客户数
          , NVL(a2.GT_CLS_STR_FND_CUST_VOL,0)         --本年累计关闭分级基金客户数	
          , NVL(a2.GT_CLS_STIB_CUST_VOL,0)            --本年累计关闭科创板客户数	
	
          , NVL(a2.GT_CLS_CASH_PROD_CUST_VOL,0)       --本年累计关闭现金添利客户数
          , NVL(a2.TADDED_VLD_CUST_VOL,0)             --新增有效客户数
          , NVL(a2.GT_TADDED_VLD_CUST_VOL,0)          --累计新增有效客户数
          , NVL(a2.STOCK_ACTVT_CUST_VOL,0)            --存量激活客户数
          , NVL(a2.GT_STOCK_ACTVT_CUST_VOL,0)         --存量累计激活客户数
          , %d{yyyyMMdd}                         --加载日期  
FROM   (SELECT *,'2' as CUST_CGY 
        FROM  DDW_PROD.T_DDW_INR_ORG_BRH
        WHERE BUS_DATE = %d{yyyyMMdd}
       )		t
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON_TEMP a1
ON        t.BRH_NO = a1.BRH_NO
AND       t.CUST_CGY = a1.CUST_CGY
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON_TEMP1 a2
ON        t.BRH_NO = a2.BRH_NO
AND       t.CUST_CGY = a2.CUST_CGY ;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON_TEMP ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON_TEMP1 ; 
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_CUST_VOL_IDX_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
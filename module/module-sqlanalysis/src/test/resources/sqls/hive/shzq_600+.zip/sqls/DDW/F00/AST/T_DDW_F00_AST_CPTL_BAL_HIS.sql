 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:资金余额历史表                                                                      */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */ 
  
----创建账户存管银行的信息
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS_TEMP1 ;
  CREATE TABLE DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS_TEMP1 
  as select distinct * from (SELECT    KHH
               ,GTZJZH
			   ,YHZH
			   ,BZDM
			   ,YHDM,ZH_YHZHGXZT 
     FROM     EDW_PROD.T_EDW_T02_TYZZZDY a
     WHERE    EXISTS(SELECT 1 FROM (SELECT KHH,BUS_DATE,MAX(YHZH) as YHZH
                                    FROM     EDW_PROD.T_EDW_T02_TYZZZDY
							        WHERE    BZDM = 'HKD'
							        AND      BUS_DATE = %d{yyyyMMdd}
							        GROUP BY KHH,BUS_DATE
                                    ) b
                    WHERE a.khh = b.khh
				    AND   a.yhzh = b.yhzh
                    )
     AND        a.BZDM = 'HKD'
     AND        a.BUS_DATE = %d{yyyyMMdd}
     UNION ALL
     SELECT      KHH
	            ,GTZJZH
				,YHZH
				,BZDM
				,YHDM
				,ZH_YHZHGXZT 
     FROM     EDW_PROD.T_EDW_T02_TYZZZDY a
     WHERE    EXISTS(SELECT 1 FROM (SELECT KHH,BUS_DATE,MIN(YHZH) as YHZH
                                    FROM EDW_PROD.T_EDW_T02_TYZZZDY
							        WHERE BZDM = 'USD'
							        AND   BUS_DATE = %d{yyyyMMdd}
							        GROUP BY KHH,BUS_DATE
                                   ) b
                     WHERE a.khh = b.khh
				     AND   a.yhzh = b.yhzh
                   )
     AND     a.BZDM = 'USD'
     AND     a.BUS_DATE = %d{yyyyMMdd}
	 UNION ALL
	 SELECT  KHH
	         ,GTZJZH
			 ,YHZH
			 ,BZDM
			 ,YHDM
			 ,ZH_YHZHGXZT
	 FROM    EDW_PROD.T_EDW_T02_TCGZHDY  a
	 WHERE   a.BUS_DATE = %d{yyyyMMdd}
	 AND BZDM NOT IN ('HKD','USD')
	 )    t
 ;

 --------------插入数据-------------
 INSERT OVERWRITE DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
 (
                                   CUST_NO                         --客户号       
                                  ,CUST_NAME                       --客户姓名     
                                  ,BRH_NO                          --营业部编号     
                                  ,CCY_CD                          --币种代码
                                  ,CNTR_CPTL_ACCNT                 --柜台资金帐号
                                  ,MAIN_ACCNT_FLG                  --主帐户标志
                                  ,ACCNT_BAL                       --帐户余额
                                  ,FZN_AMT                         --冻结金额
								  ,UNPY_AMT                        --在途资金
                                  ,INT_CDN_NUM                     --利息基数
								  ,BE_CVT                          --待转利息
								  ,PRDCT_INT                       --预计利息
								  ,OVDRFT_CDN_NUM                  --透支基数
								  ,GT_INT                          --累计利息                         
								  ,OPNAC_DT                        --开户日期
								  ,CNCLACT_DT                      --销户日期
								  ,CPTL_ACCNT_STAT                 --资金账户状态
								  ,BANK_CD                         --银行代码
                                  ,BANK_ACTNO                      --银行账号
                                  ,ACCNT_BANK_ACTNO_RLN_STAT       --账户与银行账号之间的状态								  
								  ,SYS_SRC                        --系统来源						
 ) 
 partition(bus_date)
 SELECT                    NVL(a1.KHH,t.KHH)          as CUST_NO                         --客户号       
                          ,t.KHXM                     as CUST_NAME                       --客户姓名     
                          ,t.YYB                      as BRH_NO                          --营业部编号     
                          ,t.BZDM                     as CCY_CD                          --币种代码
                          ,t.GTZJZH                   as CNTR_CPTL_ACCNT                 --柜台资金帐号
                          ,t.ZZHBZ                    as MAIN_ACCNT_FLG                  --主帐户标志
                          ,NVL(t.ZHYE,0)              as ACCNT_BAL                       --帐户余额
                          ,NVL(t.DJJE,0)              as FZN_AMT                         --冻结金额
                          ,NVL(a2.UNPY_AMT,0)         as UNPY_AMT                        --在途资金
                          ,NVL(t.LXJS,0)              as INT_CDN_NUM                     --利息基数
                          ,NVL(t.DZLX,0)              as BE_CVT                          --待转利息
                          ,NVL(t.YJLX,0)              as PRDCT_INT                       --预计利息
                          ,NVL(t.TZJS,0)              as OVDRFT_CDN_NUM                  --透支基数
                          ,NVL(ROUND(t.YJLX+(EDW_PROD.G_DATE_COMPARE_DATE(CAST(a4.NAT_DT AS STRING),'yyyyMMdd',CAST(t.BDRQ as STRING),'yyyyMMdd')+1)*t.ZHYE*a5.CKLL/360,2),0)                      as GT_INT                          --累计利息                   
                          ,t.KHRQ                     as OPNAC_DT                        --开户日期
                          ,t.XHRQ                     as CNCLACT_DT                      --销户日期
                          ,t.ZJZHZT                   as CPTL_ACCNT_STAT                 --资金账户状态
                          ,a3.YHDM                    as BANK_CD                         --银行代码
                          ,a3.YHZH                    as BANK_ACTNO                      --银行账号
                          ,a3.ZH_YHZHGXZT             as ACCNT_BANK_ACTNO_RLN_STAT       --账户与银行账号之间的状态	
                          ,DECODE(t.XTBS,'JZJY','普通账户','GGQQ','期权账户','RZRQ','信用账户')                      as SYS_SRC                        --系统来源
						  ,CAST(a4.NAT_DT AS INT)     as BUS_DATE			
 FROM         (SELECT * FROM   EDW_PROD.T_EDW_T02_TZJZH  WHERE BUS_DATE = %d{yyyyMMdd}) 	     t
 LEFT JOIN      EDW_PROD.T_EDW_T99_TWYZZZH a1
 ON             t.KHH = a1.WYZZKHH
 AND            a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  (SELECT  CUST_NO
                    ,CNTR_CPTL_ACCNT
					,SUM(UNPY_AMT) as UNPY_AMT					
             FROM   DDW_PROD.T_DDW_F00_DIM_UNPY_AMT_HIS
             WHERE  BUS_DATE = %d{yyyyMMdd}			 
			 GROUP BY CUST_NO,CNTR_CPTL_ACCNT
			 )                                           a2
 ON          t.KHH = a2.CUST_NO
 AND         t.GTZJZH = a2.CNTR_CPTL_ACCNT
-- AND         t.BUS_DATE = a2.BUS_DATE
 LEFT JOIN   DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS_TEMP1   a3
 ON          t.KHH = a3.KHH
 AND         t.GTZJZH = a3.GTZJZH
 AND         t.BZDM = a3.BZDM 
 LEFT JOIN   (SELECT BZ,CKLL 
              FROM   JZJYCX.ACCOUNT_TLLMBCS  
			  WHERE DT = '%d{yyyyMMdd}' 
			  AND MBBH = 1     
			  )  a5                             
 ON         t.BZDM = a5.BZ
 LEFT JOIN   EDW_PROD.T_EDW_T99_TRD_DATE               a4
 ON          a4.BUS_DATE = %d{yyyyMMdd}
 AND         t.BUS_DATE = a4.TRD_DT
 --WHERE    BUS_DATE =  %d{yyyyMMdd}								  
 ;
----- 删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS_TEMP1;

-----------------插入数据结束----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_AST_CPTL_BAL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS ;
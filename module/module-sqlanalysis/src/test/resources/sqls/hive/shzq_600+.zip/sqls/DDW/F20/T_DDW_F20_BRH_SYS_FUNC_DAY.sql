------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:系统性能日表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2019-12-11                                                                       */
----分类(1--委托人数委托笔数,2--委托性能,3--转账人数,转账笔数,4--用户规模)
ALTER TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd});
------创建JZJY委托人数,委托笔数临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP as
SELECT    t.BRH_NO
         ,'JZJY' as SYS_SRC
		 --,1      as CL
         ,SUM(CASE WHEN a1.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			)     as ODR_NUM_PHONE --手机委托人数
		 ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_TEL  --电话委托人数
		 ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_ONLN --网上委托人数
		 ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_UNSCE --非现场委托人数
		 ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM       --总委托人数
		 ,SUM(NVL(a1.NUM,0)) as ODR_ITMS_PHONE --手机委托笔数
		 ,SUM(NVL(a2.NUM,0)) as ODR_ITMS_TEL   --电话委托笔数
		 ,SUM(NVL(a3.NUM,0)) as ODR_ITMS_ONLN  --网上委托笔数
		 ,SUM(NVL(a4.NUM,0)) as ODR_ITMS_UNSCE --非现场委托笔数
		 ,SUM(NVL(a5.NUM,0)) as ODR_ITMS       --总委托笔数 
		 ,SUM(NVL(a5.ODR_ITMS_TRD_SH,0))      as ODR_ITMS_TRD_SH --沪市交易笔数
		 ,SUM(NVL(a5.ODR_ITMS_UNTRD_SH,0))    as ODR_ITMS_UNTRD_SH --沪市非交易笔数
         ,SUM(NVL(a5.ODR_ITMS_TRD_SZ,0))      as ODR_ITMS_TRD_SZ --深市交易笔数
         ,SUM(NVL(a5.ODR_ITMS_UNTRD_SZ,0))    as ODR_ITMS_UNTRD_SZ --深市非交易笔数	
         ,SUM(NVL(a5.ODR_ITMS_TRD_HK,0))      as ODR_ITMS_TRD_HK --沪港通交易笔数
         ,SUM(NVL(a5.ODR_ITMS_UNTRD_HK,0))    as ODR_ITMS_UNTRD_HK --沪港通非交易笔数
         ,SUM(NVL(a5.ODR_ITMS_TRD_SK,0))      as ODR_ITMS_TRD_SK --深港通交易笔数
         ,SUM(NVL(a5.ODR_ITMS_UNTRD_SK,0))    as ODR_ITMS_UNTRD_SK --深港通非交易笔数
         ,SUM(NVL(a5.ODR_ITMS_TRD_T3BOD,0))   as ODR_ITMS_TRD_T3BOD --三板交易笔数
         ,SUM(NVL(a5.ODR_ITMS_UNTRD_T3BOD,0)) as ODR_ITMS_UNTRD_T3BOD --三板非交易笔数
		 
		 
		 
		 
FROM   DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
LEFT JOIN (SELECT   KHH       as CUST_NO
                    ,COUNT(1) as NUM     
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   WTFS = 64
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a1
ON         t.CUST_NO = a1.CUST_NO		   
LEFT JOIN (SELECT   KHH       as CUST_NO
                    ,COUNT(1) as NUM     
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   WTFS = 1
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO
                    ,COUNT(1) as NUM     
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   WTFS = 32
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a3
ON         t.CUST_NO = a3.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO
                    ,COUNT(1) as NUM    
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   WTFS IN (1,32,64)
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a4
ON         t.CUST_NO = a4.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO
                    ,COUNT(1) as NUM
                    ,SUM(CASE WHEN JYS IN ('SH','HB')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_TRD_SH --沪市交易笔数
					,SUM(CASE WHEN JYS IN ('SH','HB')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 0
							  WHEN JYS IN ('SH','HB')
							  AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_UNTRD_SH --沪市非交易笔数
					,SUM(CASE WHEN JYS IN ('SZ','SB')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_TRD_SZ --深市交易笔数
					,SUM(CASE WHEN JYS IN ('SZ','SB')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 0
							  WHEN JYS IN ('SZ','SB')
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_UNTRD_SZ --深市非交易笔数	
                    ,SUM(CASE WHEN JYS IN ('HK')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_TRD_HK --沪港通交易笔数
					,SUM(CASE WHEN JYS IN ('HK')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 0
							  WHEN JYS IN ('HK')
							  AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_UNTRD_HK --沪港通非交易笔数
                     ,SUM(CASE WHEN JYS IN ('SK')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_TRD_SK --深港通交易笔数
					,SUM(CASE WHEN JYS IN ('SK')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 0
							  WHEN JYS IN ('SK')
							  AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_UNTRD_SK --深港通非交易笔数	
                   ,SUM(CASE WHEN JYS IN ('TA','TU')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  AND  SBXW = '722400'
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_TRD_T3BOD --三板交易笔数
					,SUM(CASE WHEN JYS IN ('TA','TU')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  AND  SBXW = '722400'
							  THEN 0
							  WHEN JYS IN ('TA','TU')
							  AND  SBRQ = %d{yyyyMMdd}
							  AND  SBXW = '722400'
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_UNTRD_T3BOD --三板非交易笔数						
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a5
ON         t.CUST_NO = a5.CUST_NO
WHERE      t.BUS_DATE = %d{yyyyMMdd}
GROUP BY t.BRH_NO    ;
------创建RZRQ委托人数,委托笔数临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP1 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP1 as
SELECT    t.BRH_NO
         ,'RZRQ' as SYS_SRC
		 --,1      as CL
         ,SUM(CASE WHEN a1.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			)     as ODR_NUM_PHONE --手机委托人数
		 ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_TEL  --电话委托人数
		 ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_ONLN --网上委托人数
		 ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_UNSCE --非现场委托人数
		 ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM       --总委托人数
		 ,SUM(NVL(a1.NUM,0)) as ODR_ITMS_PHONE --手机委托笔数
		 ,SUM(NVL(a2.NUM,0)) as ODR_ITMS_TEL   --电话委托笔数
		 ,SUM(NVL(a3.NUM,0)) as ODR_ITMS_ONLN  --网上委托笔数
		 ,SUM(NVL(a4.NUM,0)) as ODR_ITMS_UNSCE --非现场委托笔数
		 ,SUM(NVL(a5.NUM,0)) as ODR_ITMS       --总委托笔数
		 ,SUM(NVL(a5.ODR_ITMS_TRD_SH,0)) as ODR_ITMS_TRD_SH --沪市交易笔数
		 ,SUM(NVL(a5.ODR_ITMS_UNTRD_SH,0)) as ODR_ITMS_UNTRD_SH --沪市非交易笔数
         ,SUM(NVL(a5.ODR_ITMS_TRD_SZ,0)) as ODR_ITMS_TRD_SZ --深市交易笔数
         ,SUM(NVL(a5.ODR_ITMS_UNTRD_SZ,0)) as ODR_ITMS_UNTRD_SZ --深市非交易笔数	
         ,SUM(NVL(a5.ODR_ITMS_TRD_HK,0)) as ODR_ITMS_TRD_HK --沪港通交易笔数
         ,SUM(NVL(a5.ODR_ITMS_UNTRD_HK,0)) as ODR_ITMS_UNTRD_HK --沪港通非交易笔数
         ,SUM(NVL(a5.ODR_ITMS_TRD_SK,0)) as ODR_ITMS_TRD_SK --深港通交易笔数
         ,SUM(NVL(a5.ODR_ITMS_UNTRD_SK,0)) as ODR_ITMS_UNTRD_SK --深港通非交易笔数
         ,SUM(NVL(a5.ODR_ITMS_TRD_T3BOD,0)) as ODR_ITMS_TRD_T3BOD --三板交易笔数
         ,SUM(NVL(a5.ODR_ITMS_UNTRD_T3BOD,0)) as ODR_ITMS_UNTRD_T3BOD --三板非交易笔数
FROM   DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
LEFT JOIN (SELECT   KHH       as CUST_NO
                    ,COUNT(1) as NUM      
           FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   WTFS = 64
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a1
ON         t.CUST_NO = a1.CUST_NO		   
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM 
		   FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   WTFS = 1
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM 
		   FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   WTFS = 32
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a3
ON         t.CUST_NO = a3.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO    
                    ,COUNT(1) as NUM 
		   FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   WTFS IN (1,32,64)
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a4
ON         t.CUST_NO = a4.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM 
		            ,SUM(CASE WHEN JYS IN ('SH','HB')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_TRD_SH --沪市交易笔数
					,SUM(CASE WHEN JYS IN ('SH','HB')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 0
							  WHEN JYS IN ('SH','HB')
							  AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_UNTRD_SH --沪市非交易笔数
					,SUM(CASE WHEN JYS IN ('SZ','SB')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_TRD_SZ --深市交易笔数
					,SUM(CASE WHEN JYS IN ('SZ','SB')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 0
							  WHEN JYS IN ('SZ','SB')
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_UNTRD_SZ --深市非交易笔数	
                    ,SUM(CASE WHEN JYS IN ('HK')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_TRD_HK --沪港通交易笔数
					,SUM(CASE WHEN JYS IN ('HK')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 0
							  WHEN JYS IN ('HK')
							  AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_UNTRD_HK --沪港通非交易笔数
                     ,SUM(CASE WHEN JYS IN ('SK')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_TRD_SK --深港通交易笔数
					,SUM(CASE WHEN JYS IN ('SK')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  THEN 0
							  WHEN JYS IN ('SK')
							  AND  SBRQ = %d{yyyyMMdd}
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_UNTRD_SK --深港通非交易笔数	
                   ,SUM(CASE WHEN JYS IN ('TA','TU')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  AND  SBXW = '722400'
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_TRD_T3BOD --三板交易笔数
					,SUM(CASE WHEN JYS IN ('TA','TU')
                              AND  SBJG in(2,5,6,7,8,9)
						      AND  WTLB in(1,2,4,5,12,29,30,36,41,42,43,50,55,56,57,58,59,60,61,62,63,64,71,72,78,79,89,90,91,92)
					          AND  SBRQ = %d{yyyyMMdd}
							  AND  SBXW = '722400'
							  THEN 0
							  WHEN JYS IN ('TA','TU')
							  AND  SBRQ = %d{yyyyMMdd}
							  AND  SBXW = '722400'
							  THEN 1
						      ELSE 0
						      END
						) as ODR_ITMS_UNTRD_T3BOD --三板非交易笔数
		   FROM  EDW_PROD.T_EDW_T05_TWTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a5
ON         t.CUST_NO = a5.CUST_NO
WHERE      t.BUS_DATE = %d{yyyyMMdd}
GROUP BY t.BRH_NO    ;
------创建GGQQ委托人数,委托笔数临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP2 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP2 as
SELECT    t.BRH_NO
         ,'GGQQ' as SYS_SRC
		-- ,1      as CL
         ,SUM(CASE WHEN a1.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			)     as ODR_NUM_PHONE --手机委托人数
		 ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_TEL  --电话委托人数
		 ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_ONLN --网上委托人数
		 ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_UNSCE --非现场委托人数
		 ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM       --总委托人数
		 ,SUM(NVL(a1.NUM,0)) as ODR_ITMS_PHONE --手机委托笔数
		 ,SUM(NVL(a2.NUM,0)) as ODR_ITMS_TEL   --电话委托笔数
		 ,SUM(NVL(a3.NUM,0)) as ODR_ITMS_ONLN  --网上委托笔数
		 ,SUM(NVL(a4.NUM,0)) as ODR_ITMS_UNSCE --非现场委托笔数
		 ,SUM(NVL(a5.NUM,0)) as ODR_ITMS       --总委托笔数
FROM   DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM 
		   FROM  EDW_PROD.T_EDW_T05_TSO_WTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   WTFS = 64
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a1
ON         t.CUST_NO = a1.CUST_NO		   
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM 
		   FROM  EDW_PROD.T_EDW_T05_TSO_WTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   WTFS = 1
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM
		   FROM  EDW_PROD.T_EDW_T05_TSO_WTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   WTFS = 32
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a3
ON         t.CUST_NO = a3.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO 
                    ,COUNT(1) as NUM   
           FROM  EDW_PROD.T_EDW_T05_TSO_WTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   WTFS IN (1,32,64)
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a4
ON         t.CUST_NO = a4.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO
                    ,COUNT(1) as NUM     
           FROM  EDW_PROD.T_EDW_T05_TSO_WTLS         
           WHERE BUS_DATE = %d{yyyyMMdd}
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a5
ON         t.CUST_NO = a5.CUST_NO
WHERE      t.BUS_DATE = %d{yyyyMMdd}
GROUP BY t.BRH_NO    ;

------创建JZJY转账人数,转账笔数临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP3 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP3 as
SELECT    t.BRH_NO
         ,'JZJY' as SYS_SRC
		-- ,3      as CL
         ,SUM(CASE WHEN a1.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			)     as ODR_NUM_PHONE --手机委托人数
		 ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_TEL  --电话委托人数
		 ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_ONLN --网上委托人数
		 ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_UNSCE --非现场委托人数
		 ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM       --总委托人数
		 ,SUM(NVL(a1.NUM,0)) as ODR_ITMS_PHONE --手机委托笔数
		 ,SUM(NVL(a2.NUM,0)) as ODR_ITMS_TEL   --电话委托笔数
		 ,SUM(NVL(a3.NUM,0)) as ODR_ITMS_ONLN  --网上委托笔数
		 ,SUM(NVL(a4.NUM,0)) as ODR_ITMS_UNSCE --非现场委托笔数
		 ,SUM(NVL(a5.NUM,0)) as ODR_ITMS       --总委托笔数
FROM   DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM 
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS        
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   SQFS = 64
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a1
ON         t.CUST_NO = a1.CUST_NO		   
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM 
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   SQFS = 1
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   SQFS = 32
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a3
ON         t.CUST_NO = a3.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO 
                    ,COUNT(1) as NUM   
           FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   SQFS IN (1,32,64)
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a4
ON         t.CUST_NO = a4.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO
                    ,COUNT(1) as NUM     
           FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE BUS_DATE = %d{yyyyMMdd}
		   AND   XTBS = 'JZJY'
           GROUP BY  CUST_NO
		   )                                     a5
ON         t.CUST_NO = a5.CUST_NO
WHERE      t.BUS_DATE = %d{yyyyMMdd}
GROUP BY t.BRH_NO    ;		 

------创建RZRQ转账人数,转账笔数临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP4 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP4 as
SELECT    t.BRH_NO
         ,'RZRQ' as SYS_SRC
		 --,3      as CL
         ,SUM(CASE WHEN a1.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			)     as ODR_NUM_PHONE --手机委托人数
		 ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_TEL  --电话委托人数
		 ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_ONLN --网上委托人数
		 ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_UNSCE --非现场委托人数
		 ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM       --总委托人数
		 ,SUM(NVL(a1.NUM,0)) as ODR_ITMS_PHONE --手机委托笔数
		 ,SUM(NVL(a2.NUM,0)) as ODR_ITMS_TEL   --电话委托笔数
		 ,SUM(NVL(a3.NUM,0)) as ODR_ITMS_ONLN  --网上委托笔数
		 ,SUM(NVL(a4.NUM,0)) as ODR_ITMS_UNSCE --非现场委托笔数
		 ,SUM(NVL(a5.NUM,0)) as ODR_ITMS       --总委托笔数
FROM   DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM 
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS        
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   SQFS = 64
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a1
ON         t.CUST_NO = a1.CUST_NO		   
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM 
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   SQFS = 1
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   SQFS = 32
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a3
ON         t.CUST_NO = a3.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO 
                    ,COUNT(1) as NUM   
           FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   SQFS IN (1,32,64)
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a4
ON         t.CUST_NO = a4.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO
                    ,COUNT(1) as NUM     
           FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE BUS_DATE = %d{yyyyMMdd}
		   AND   XTBS = 'RZRQ'
           GROUP BY  CUST_NO
		   )                                     a5
ON         t.CUST_NO = a5.CUST_NO
WHERE      t.BUS_DATE = %d{yyyyMMdd}
GROUP BY t.BRH_NO    ;	
------创建GGQQ转账人数,转账笔数临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP5 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP5 as
SELECT    t.BRH_NO
         ,'GGQQ' as SYS_SRC
		-- ,3      as CL
         ,SUM(CASE WHEN a1.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			)     as ODR_NUM_PHONE --手机委托人数
		 ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_TEL  --电话委托人数
		 ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_ONLN --网上委托人数
		 ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM_UNSCE --非现场委托人数
		 ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
		           THEN 1
			       ELSE 0
			       END
			 )     as ODR_NUM       --总委托人数
		 ,SUM(NVL(a1.NUM,0)) as ODR_ITMS_PHONE --手机委托笔数
		 ,SUM(NVL(a2.NUM,0)) as ODR_ITMS_TEL   --电话委托笔数
		 ,SUM(NVL(a3.NUM,0)) as ODR_ITMS_ONLN  --网上委托笔数
		 ,SUM(NVL(a4.NUM,0)) as ODR_ITMS_UNSCE --非现场委托笔数
		 ,SUM(NVL(a5.NUM,0)) as ODR_ITMS       --总委托笔数
FROM   DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL    t
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM 
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS        
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   SQFS = 64
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a1
ON         t.CUST_NO = a1.CUST_NO		   
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM 
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   SQFS = 1
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a2
ON         t.CUST_NO = a2.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO     
                    ,COUNT(1) as NUM
		   FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   SQFS = 32
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a3
ON         t.CUST_NO = a3.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO 
                    ,COUNT(1) as NUM   
           FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE BUS_DATE = %d{yyyyMMdd}
           AND   SQFS IN (1,32,64)
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a4
ON         t.CUST_NO = a4.CUST_NO
LEFT JOIN (SELECT   KHH       as CUST_NO
                    ,COUNT(1) as NUM     
           FROM  EDW_PROD.T_EDW_T05_TCGJYSQLS 
           WHERE BUS_DATE = %d{yyyyMMdd}
		   AND   XTBS = 'GGQQ'
           GROUP BY  CUST_NO
		   )                                     a5
ON         t.CUST_NO = a5.CUST_NO
WHERE      t.BUS_DATE = %d{yyyyMMdd}
GROUP BY t.BRH_NO    ;

-------委托性能临时表1
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP6 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP6 as 
SELECT   MAX(t.ODR_ITMS)                           as ODR_ITMS_MAX_SS --秒峰值委托笔数
        ,SUM(t.ODR_ITMS)                           as ODR_ITMS_FUNC   --委托笔数(性能)
		,MAX(t.ODR_ITMS_SH)                        as ODR_ITMS_SH_MAX_SS --秒峰值委托笔数(SH)
		,SUM(t.ODR_ITMS_SH)                        as ODR_ITMS_SH_FUNC --委托笔数(SH)(性能)
		,SUM(t.ODR_ITMS_SZ)                        as ODR_ITMS_SZ_FUNC --委托笔数(SZ)(性能)
		,MAX(t.ODR_ITMS_SZ)                        as ODR_ITMS_SZ_MAX_SS --秒峰值委托笔数(SZ)
		,ROUND(SUM(t.ODR_ITMS*1.00000/14400),1)    as ODR_ITMS_AVG_SS --平均每秒委托笔数
		,ROUND(SUM(t.ODR_ITMS_SH*1.00000/14400),1) as ODR_ITMS_AVG_SH_SS --平均每秒委托笔数(SH)
		,ROUND(SUM(t.ODR_ITMS_SZ*1.00000/14400),1) as ODR_ITMS_AVG_SZ_SS --平均每秒委托笔数(SZ)
		,SUM(t.WALL_ODR_ITMS)      as WALL_ODR_ITMS    --当日堵单笔数
		,SUM(t.WALL_ODR_ITMS_SH)   as WALL_ODR_ITMS_SH --当日堵单笔数(SH)
		,SUM(t.WALL_ODR_ITMS_SZ)   as WALL_ODR_ITMS_SZ --当日堵单笔数(SZ)
		,SUM(t.WALL_ODR_ITMS_6S)   as WALL_ODR_ITMS_6S --当日堵单超过6秒笔数
		,SUM(t.WALL_ODR_ITMS_SH_6S)as WALL_ODR_ITMS_SH_6S  --当日堵单超过6秒笔数(SH)
		,SUM(t.WALL_ODR_ITMS_SZ_6S)as WALL_ODR_ITMS_SZ_6S  --当日堵单超过6秒笔数(SZ)
		,MAX(t.WALL_ODR_ITMS)      as WALL_ODR_ITMS_MAX_SS--秒峰值堵单笔数
		,MAX(t.WALL_ODR_ITMS_SH)   as WALL_ODR_ITMS_SH_MAX_SS--秒峰值堵单笔数(SH)
		,MAX(t.WALL_ODR_ITMS_SZ)   as WALL_ODR_ITMS_SZ_MAX_SS--秒峰值堵单笔数(SZ)
		,t.XTBS
		--, 2 as CL
FROM    (SELECT   WTSJ
		         ,COUNT(1) as ODR_ITMS
		         ,XTBS
				 ,SUM(CASE WHEN JYS = 'SH'
				           THEN 1
					       ELSE 0
					       END
					 ) as ODR_ITMS_SH
				 ,SUM(CASE WHEN JYS = 'SZ'
				           THEN 1
					       ELSE 0
					       END
					 ) as ODR_ITMS_SZ
				,SUM(CASE WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 1
				           AND  t.WTSJ BETWEEN '11:29:00' AND '11:30:59'
						   AND  t.SBSJ BETWEEN '12:59:00' AND '13:00:59'
						   AND  JYS IN ('SH','SZ','HK','SB','HB')
						   THEN 0
					       WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 1
						   AND   JYS IN ('SH','SZ','HK','SB','HB')
                           AND   SBJG > 1
                           AND   CXBZ < > 'W'
                           AND   WTLB NOT IN (65,66,73)  
						   THEN 1
						   ELSE 0
					       END 
					 ) as WALL_ODR_ITMS --当日堵单笔数
				,SUM(CASE WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 1
				           AND  t.WTSJ BETWEEN '11:29:00' AND '11:30:59'
						   AND  t.SBSJ BETWEEN '12:59:00' AND '13:00:59'
						   AND   JYS = 'SH'	
						   THEN 0
					       WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 1
						   --AND   JYS IN ('SH','SZ','HK','SB','HB')
                           AND   SBJG > 1
                           AND   CXBZ < > 'W'
                           AND   WTLB NOT IN (65,66,73) 
                           AND   JYS = 'SH'						   
						   THEN 1
						   ELSE 0
					       END 
					 ) as WALL_ODR_ITMS_SH --当日堵单笔数(SH)
				,SUM(CASE WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 1
				           AND  t.WTSJ BETWEEN '11:29:00' AND '11:30:59'
						   AND  t.SBSJ BETWEEN '12:59:00' AND '13:00:59'
						   AND   JYS = 'SZ'	
						   THEN 0
					       WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 1
						   --AND   JYS IN ('SH','SZ','HK','SB','HB')
                           AND   SBJG > 1
                           AND   CXBZ < > 'W'
                           AND   WTLB NOT IN (65,66,73) 
                           AND   JYS = 'SZ'						   
						   THEN 1
						   ELSE 0
					       END 
					 ) as WALL_ODR_ITMS_SZ --当日堵单笔数(SZ)
					 
					 ,SUM(CASE WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 6
				           AND  t.WTSJ BETWEEN '11:29:00' AND '11:30:59'
						   AND  t.SBSJ BETWEEN '12:59:00' AND '13:00:59'
						   AND  JYS IN ('SH','SZ','HK','SB','HB')
						   THEN 0
					       WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 6
						   AND   JYS IN ('SH','SZ','HK','SB','HB')
                           AND   SBJG > 1
                           AND   CXBZ < > 'W'
                           AND   WTLB NOT IN (65,66,73)  
						   THEN 1
						   ELSE 0
					       END 
					 ) as WALL_ODR_ITMS_6S --当日堵单超过6秒笔数
				,SUM(CASE WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 6
				           AND  t.WTSJ BETWEEN '11:29:00' AND '11:30:59'
						   AND  t.SBSJ BETWEEN '12:59:00' AND '13:00:59'
						   AND   JYS = 'SH'	
						   THEN 0
					       WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 6
						  
                           AND   SBJG > 1
                           AND   CXBZ < > 'W'
                           AND   WTLB NOT IN (65,66,73) 
                           AND   JYS = 'SH'						   
						   THEN 1
						   ELSE 0
					       END 
					 ) as WALL_ODR_ITMS_SH_6S --当日堵单超过6秒笔数(SH)
				,SUM(CASE WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 6
				           AND  t.WTSJ BETWEEN '11:29:00' AND '11:30:59'
						   AND  t.SBSJ BETWEEN '12:59:00' AND '13:00:59'
						   AND   JYS = 'SZ'	
						   THEN 0
					       WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 6
                           AND   SBJG > 1
                           AND   CXBZ < > 'W'
                           AND   WTLB NOT IN (65,66,73) 
                           AND   JYS = 'SZ'						   
						   THEN 1
						   ELSE 0
					       END 
					 ) as WALL_ODR_ITMS_SZ_6S --当日堵单超过6秒笔数(SZ)
         FROM   EDW_PROD.T_EDW_T05_TWTLS  t
         WHERE  ((WTSJ > = '09:30:00'
          AND    WTSJ < = '11:30:00')
          OR   ((WTSJ > = '13:00:00'
          AND    WTSJ < = '15:00:00')))
          AND   BUS_DATE = %d{yyyyMMdd}
		  AND   WTRQ = %d{yyyyMMdd} 
		  AND   SBRQ = %d{yyyyMMdd}
		  GROUP BY XTBS,WTSJ
        )           t
GROUP BY t.XTBS ;     


-------委托性能临时表1
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP7 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP7 as 
SELECT   MAX(t.ODR_ITMS)                           as ODR_ITMS_MAX_SS    --秒峰值委托笔数
        ,MAX(t.ODR_ITMS_SH)                        as ODR_ITMS_SH_MAX_SS --秒峰值委托笔数(SH)
		,MAX(t.ODR_ITMS_SZ)                        as ODR_ITMS_SZ_MAX_SS --秒峰值委托笔数(SZ)
		,ROUND(SUM(t.ODR_ITMS*1.00000/14400),1)    as ODR_ITMS_AVG_SS    --平均每秒委托笔数
		,ROUND(SUM(t.ODR_ITMS_SH*1.00000/14400),1) as ODR_ITMS_AVG_SH_SS --平均每秒委托笔数(SH)
		,ROUND(SUM(t.ODR_ITMS_SZ*1.00000/14400),1) as ODR_ITMS_AVG_SZ_SS --平均每秒委托笔数(SZ)
		 ,SUM(t.ODR_ITMS)                           as ODR_ITMS_FUNC   --委托笔数(性能)
		,SUM(t.ODR_ITMS_SH)                        as ODR_ITMS_SH_FUNC --委托笔数(SH)(性能)
		,SUM(t.ODR_ITMS_SZ)                        as ODR_ITMS_SZ_FUNC --委托笔数(SZ)
		
		
		,SUM(t.WALL_ODR_ITMS)      as WALL_ODR_ITMS    --当日堵单笔数
		,SUM(t.WALL_ODR_ITMS_SH)   as WALL_ODR_ITMS_SH --当日堵单笔数(SH)
		,SUM(t.WALL_ODR_ITMS_SZ)   as WALL_ODR_ITMS_SZ --当日堵单笔数(SZ)
		,SUM(t.WALL_ODR_ITMS_6S)   as WALL_ODR_ITMS_6S --当日堵单超过6秒笔数
		,SUM(t.WALL_ODR_ITMS_SH_6S)as WALL_ODR_ITMS_SH_6S  --当日堵单超过6秒笔数(SH)
		,SUM(t.WALL_ODR_ITMS_SZ_6S)as WALL_ODR_ITMS_SZ_6S  --当日堵单超过6秒笔数(SZ)
		,MAX(t.WALL_ODR_ITMS)      as WALL_ODR_ITMS_MAX_SS--秒峰值堵单笔数
		,MAX(t.WALL_ODR_ITMS_SH)   as WALL_ODR_ITMS_SH_MAX_SS--秒峰值堵单笔数(SH)
		,MAX(t.WALL_ODR_ITMS_SZ)   as WALL_ODR_ITMS_SZ_MAX_SS--秒峰值堵单笔数(SZ)
		,t.XTBS
		--, 2 as CL
FROM    (SELECT   WTSJ
		         ,COUNT(1) as ODR_ITMS
		         ,XTBS
				 ,SUM(CASE WHEN JYS = 'SH'
				           THEN 1
					       ELSE 0
					       END
					 ) as ODR_ITMS_SH
				 ,SUM(CASE WHEN JYS = 'SZ'
				           THEN 1
					       ELSE 0
					       END
					 ) as ODR_ITMS_SZ
				,SUM(CASE WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 1
				           AND  t.WTSJ BETWEEN '11:29:00' AND '11:30:59'
						   AND  t.SBSJ BETWEEN '12:59:00' AND '13:00:59'
						   AND  JYS IN ('SH','SZ')
						   THEN 0
					       WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 1
						   AND   JYS IN ('SH','SZ')
                           AND   SBJG > 1
                           AND   CDBZ < > 'W'
                           --AND   WTLB NOT IN (65,66,73)  
						   THEN 1
						   ELSE 0
					       END 
					 ) as WALL_ODR_ITMS --当日堵单笔数
				,SUM(CASE WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 1
				           AND  t.WTSJ BETWEEN '11:29:00' AND '11:30:59'
						   AND  t.SBSJ BETWEEN '12:59:00' AND '13:00:59'
						   AND   JYS = 'SH'	
						   THEN 0
					       WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 1
						   --AND   JYS IN ('SH','SZ','HK','SB','HB')
                           AND   SBJG > 1
                           AND   CDBZ < > 'W'
                           --AND   WTLB NOT IN (65,66,73) 
                           AND   JYS = 'SH'						   
						   THEN 1
						   ELSE 0
					       END 
					 ) as WALL_ODR_ITMS_SH --当日堵单笔数(SH)
				,SUM(CASE WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 1
				           AND  t.WTSJ BETWEEN '11:29:00' AND '11:30:59'
						   AND  t.SBSJ BETWEEN '12:59:00' AND '13:00:59'
						   AND   JYS = 'SZ'	
						   THEN 0
					       WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 1
						   --AND   JYS IN ('SH','SZ','HK','SB','HB')
                           AND   SBJG > 1
                           AND   CDBZ < > 'W'
                           --AND   WTLB NOT IN (65,66,73) 
                           AND   JYS = 'SZ'						   
						   THEN 1
						   ELSE 0
					       END 
					 ) as WALL_ODR_ITMS_SZ --当日堵单笔数(SZ)
					 
					 ,SUM(CASE WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 6
				           AND  t.WTSJ BETWEEN '11:29:00' AND '11:30:59'
						   AND  t.SBSJ BETWEEN '12:59:00' AND '13:00:59'
						   AND  JYS IN ('SH','SZ')
						   THEN 0
					       WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 6
						   AND   JYS IN ('SH','SZ')
                           AND   SBJG > 1
                           AND   CDBZ < > 'W'
                           --AND   WTLB NOT IN (65,66,73)  
						   THEN 1
						   ELSE 0
					       END 
					 ) as WALL_ODR_ITMS_6S --当日堵单超过6秒笔数
				,SUM(CASE WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 6
				           AND  t.WTSJ BETWEEN '11:29:00' AND '11:30:59'
						   AND  t.SBSJ BETWEEN '12:59:00' AND '13:00:59'
						   AND   JYS = 'SH'	
						   THEN 0
					       WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 6
						  
                           AND   SBJG > 1
                           AND   CDBZ < > 'W'
                           --AND   WTLB NOT IN (65,66,73) 
                           AND   JYS = 'SH'						   
						   THEN 1
						   ELSE 0
					       END 
					 ) as WALL_ODR_ITMS_SH_6S --当日堵单超过6秒笔数(SH)
				,SUM(CASE WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 6
				           AND  t.WTSJ BETWEEN '11:29:00' AND '11:30:59'
						   AND  t.SBSJ BETWEEN '12:59:00' AND '13:00:59'
						   AND   JYS = 'SZ'	
						   THEN 0
					       WHEN UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(t.WTRQ as STRING),' ',t.WTSJ),'yyyyMMdd HH:mm:ss') > 6
                           AND   SBJG > 1
                           AND   CDBZ < > 'W'
                           --AND   WTLB NOT IN (65,66,73) 
                           AND   JYS = 'SZ'						   
						   THEN 1
						   ELSE 0
					       END 
					 ) as WALL_ODR_ITMS_SZ_6S --当日堵单超过6秒笔数(SZ)
         FROM   EDW_PROD.T_EDW_T05_TSO_WTLS  t
         WHERE  ((WTSJ > = '09:30:00'
          AND    WTSJ < = '11:30:00')
          OR   ((WTSJ > = '13:00:00'
          AND    WTSJ < = '15:00:00')))
          AND   BUS_DATE = %d{yyyyMMdd}
		  AND   WTRQ = %d{yyyyMMdd} 
		  AND   SBRQ = %d{yyyyMMdd}
		  GROUP BY XTBS,WTSJ
        )           t
GROUP BY t.XTBS ;         
---------用户规模
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP8 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP8 as 
SELECT t.YYB as BRH_NO
      ,SUM(CASE WHEN NVL(t.JZJYKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
			    THEN 1
			    ELSE 0
			    END 
		  ) as QLFD_CSUT_VOL--合格客户总数
	  ,'JZJY' as SYS_SRC
	--  ,4 as CL
	  ,SUM(CASE WHEN NVL(t.JZJYKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  MOD(NVL(t.JZJYKH_WTFSFW,0),2) > 0                
			    THEN 1
			    ELSE 0
			    END 
		  )   as TEL_ODR_OPN_NUM --电话委托开通人数
	  ,SUM(CASE WHEN NVL(t.JZJYKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  MOD(NVL(t.JZJYKH_WTFSFW,0),64) > 31               
			    THEN 1
			    ELSE 0
			    END 
		  )   as ONLINE_ODR_OPN_NUM --网上委托开通人数
	  ,SUM(CASE WHEN NVL(t.JZJYKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  MOD(NVL(t.JZJYKH_WTFSFW,0),128) > 63               
			    THEN 1
			    ELSE 0
			    END 
		  )   as PHONE_ODR_OPN_NUM --手机委托开通人数
	  ,SUM(CASE WHEN NVL(t.JZJYKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  (MOD(NVL(t.JZJYKH_WTFSFW,0),128) > 63 
				OR  MOD(NVL(t.JZJYKH_WTFSFW,0),2) > 0    
                OR  MOD(NVL(t.JZJYKH_WTFSFW,0),64) > 31)				
			    THEN 1
			    ELSE 0
			    END 
		  )   as UNSCE_ODR_OPN_NUM  --非现场委托开通人数
	  ,SUM(CASE WHEN NVL(t.JZJYKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  a1.KHH IS NOT NULL			
			    THEN 1
			    ELSE 0
			    END 
		  )  as T3IP_DEPMGT_CUST_VOL --三方存管客户数
FROM EDW_PROD.T_EDW_T01_TKHXX   t
LEFT JOIN (SELECT KHH FROM EDW_PROD.T_EDW_T02_TCGZHDY 
           WHERE BUS_DATE = %d{yyyyMMdd}
		   AND   XTBS = 'JZJY'
		   GROUP BY KHH
		  ) a1
ON    t.KHH = a1.KHH
INNER JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                     a2
ON             t.YYB = a2.BRH_NO
AND            a2.BUS_DATE = %d{yyyyMMdd}
WHERE t.BUS_DATE = %d{yyyyMMdd}
AND   t.KHH < > '100610335855'
GROUP BY BRH_NO
UNION ALL
SELECT t.YYB as BRH_NO
      ,SUM(CASE WHEN NVL(t.GGQQKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
			    THEN 1
			    ELSE 0
			    END 
		  ) as QLFD_CSUT_VOL--合格客户总数
	  ,'GGQQ' as SYS_SRC
	  --,4 as CL
	  ,SUM(CASE WHEN NVL(t.GGQQKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  MOD(NVL(t.GGQQKH_WTFSFW,0),2) > 0                
			    THEN 1
			    ELSE 0
			    END 
		  )   as TEL_ODR_OPN_NUM --电话委托开通人数
	  ,SUM(CASE WHEN NVL(t.GGQQKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  MOD(NVL(t.GGQQKH_WTFSFW,0),64) > 31               
			    THEN 1
			    ELSE 0
			    END 
		  )   as ONLINE_ODR_OPN_NUM --网上委托开通人数
	  ,SUM(CASE WHEN NVL(t.GGQQKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  MOD(NVL(t.GGQQKH_WTFSFW,0),128) > 63               
			    THEN 1
			    ELSE 0
			    END 
		  )   as PHONE_ODR_OPN_NUM --手机委托开通人数
	  ,SUM(CASE WHEN NVL(t.GGQQKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  (MOD(NVL(t.GGQQKH_WTFSFW,0),128) > 63 
				OR  MOD(NVL(t.GGQQKH_WTFSFW,0),2) > 0    
                OR  MOD(NVL(t.GGQQKH_WTFSFW,0),64) > 31)				
			    THEN 1
			    ELSE 0
			    END 
		  )   as UNSCE_ODR_OPN_NUM  --非现场委托开通人数
	  ,SUM(CASE WHEN NVL(t.GGQQKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  a1.KHH IS NOT NULL			
			    THEN 1
			    ELSE 0
			    END 
		  )  as T3IP_DEPMGT_CUST_VOL --三方存管客户数
FROM EDW_PROD.T_EDW_T01_TKHXX   t
LEFT JOIN (SELECT KHH FROM EDW_PROD.T_EDW_T02_TCGZHDY 
           WHERE BUS_DATE = %d{yyyyMMdd}
		   AND   XTBS = 'GGQQ'
		   GROUP BY KHH
		  ) a1
ON    t.KHH = a1.KHH
INNER JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                     a2
ON             t.YYB = a2.BRH_NO
AND            a2.BUS_DATE = %d{yyyyMMdd}
WHERE t.BUS_DATE = %d{yyyyMMdd}
AND   t.KHH < > '100610335855'
GROUP BY BRH_NO
UNION ALL
SELECT t.YYB as BRH_NO
      ,SUM(CASE WHEN NVL(t.RZRQKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
			    THEN 1
			    ELSE 0
			    END 
		  ) as QLFD_CSUT_VOL--合格客户总数
	  ,'RZRQ' as SYS_SRC
	  --,4 as CL
	  ,SUM(CASE WHEN NVL(t.RZRQKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  MOD(NVL(t.RZRQKH_WTFSFW,0),2) > 0                
			    THEN 1
			    ELSE 0
			    END 
		  )   as TEL_ODR_OPN_NUM --电话委托开通人数
	  ,SUM(CASE WHEN NVL(t.RZRQKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  MOD(NVL(t.RZRQKH_WTFSFW,0),64) > 31               
			    THEN 1
			    ELSE 0
			    END 
		  )   as ONLINE_ODR_OPN_NUM --网上委托开通人数
	  ,SUM(CASE WHEN NVL(t.RZRQKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  MOD(NVL(t.RZRQKH_WTFSFW,0),128) > 63               
			    THEN 1
			    ELSE 0
			    END 
		  )   as PHONE_ODR_OPN_NUM --手机委托开通人数
	  ,SUM(CASE WHEN NVL(t.RZRQKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  (MOD(NVL(t.RZRQKH_WTFSFW,0),128) > 63 
				OR  MOD(NVL(t.RZRQKH_WTFSFW,0),2) > 0    
                OR  MOD(NVL(t.RZRQKH_WTFSFW,0),64) > 31)				
			    THEN 1
			    ELSE 0
			    END 
		  )   as UNSCE_ODR_OPN_NUM  --非现场委托开通人数
	  ,SUM(CASE WHEN NVL(t.RZRQKH_KHZTDM,'4') IN ('0','99')
                AND  t.KHFXJB IN ('0','1','2','8','19')
				AND  a1.KHH IS NOT NULL			
			    THEN 1
			    ELSE 0
			    END 
		  )  as T3IP_DEPMGT_CUST_VOL --三方存管客户数
FROM EDW_PROD.T_EDW_T01_TKHXX   t
LEFT JOIN (SELECT KHH FROM EDW_PROD.T_EDW_T02_TCGZHDY 
           WHERE BUS_DATE = %d{yyyyMMdd}
		   AND   XTBS = 'RZRQ'
		   GROUP BY KHH
		  ) a1
ON    t.KHH = a1.KHH
INNER JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                     a2
ON             t.YYB = a2.BRH_NO
AND            a2.BUS_DATE = %d{yyyyMMdd}
WHERE t.BUS_DATE = %d{yyyyMMdd}
AND   t.KHH < > '100610335855'
GROUP BY BRH_NO
 ;
------插入JZJY
INSERT  INTO DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY
(
  BELTO_FILIL_CDG       --分公司编码
, BELTO_FILIL           --分公司名称
, BRH_NO                --营业部编码
, BRH_FULLNM            --营业部名称
, SYS_SRC               --系统来源
, ODR_NUM_PHONE         --手机委托人数
, ODR_NUM_TEL           --电话委托人数
, ODR_NUM_ONLN          --网上委托人数
, ODR_NUM_UNSCE         --非现场委托人数
, ODR_NUM               --总委托人数
, ODR_ITMS_PHONE        --手机委托笔数
, ODR_ITMS_TEL          --电话委托笔数
, ODR_ITMS_ONLN         --网上委托笔数
, ODR_ITMS_UNSCE        --非现场委托笔数
, ODR_ITMS              --总委托笔数 
, ODR_ITMS_TRD_SH       --沪市交易笔数
, ODR_ITMS_UNTRD_SH     --沪市非交易笔数
, ODR_ITMS_TRD_SZ       --深市交易笔数
, ODR_ITMS_UNTRD_SZ     --深市非交易笔数	
, ODR_ITMS_TRD_HK       --沪港通交易笔数
, ODR_ITMS_UNTRD_HK     --沪港通非交易笔数
, ODR_ITMS_TRD_SK       --深港通交易笔数
, ODR_ITMS_UNTRD_SK     --深港通非交易笔数
, ODR_ITMS_TRD_T3BOD    --三板交易笔数
, ODR_ITMS_UNTRD_T3BOD  --三板非交易笔数
, TFR_ODR_NUM_PHONE     --转账手机委托人数
, TFR_ODR_NUM_TEL       --转账电话委托人数
, TFR_ODR_NUM_ONLN      --转账网上委托人数
, TFR_ODR_NUM_UNSCE     --转账非现场委托人数
, TFR_ODR_NUM           --转账总委托人数
, TFR_ODR_ITMS_PHONE    --转账手机委托笔数
, TFR_ODR_ITMS_TEL      --转账电话委托笔数
, TFR_ODR_ITMS_ONLN     --转账网上委托笔数
, TFR_ODR_ITMS_UNSCE    --转账非现场委托笔数
, TFR_ODR_ITMS          --转账总委托笔数
, ODR_ITMS_MAX_SS          --秒峰值委托笔数
, ODR_ITMS_AVG_SS       --平均每秒委托笔数
, WALL_ODR_ITMS         --当日堵单笔数
, WALL_ODR_ITMS_MAX_SS     --秒峰值堵单笔数
, ODR_ITMS_SH_MAX_SS       --秒峰值委托笔数(SH)
, ODR_ITMS_AVG_SH_SS    --平均每秒委托笔数(SH)
, WALL_ODR_ITMS_SH      --当日堵单笔数(SH)
, WALL_ODR_ITMS_SH_6S   --堵单时间超过6秒笔数（SH)
, WALL_ODR_ITMS_SH_MAX_SS  --秒峰值堵单笔数(SH)
, ODR_ITMS_SZ_MAX_SS       --秒峰值委托笔数(SZ)
, ODR_ITMS_AVG_SZ_SS    --平均每秒委托笔数(SZ)
, WALL_ODR_ITMS_SZ      --当日堵单笔数(SZ)
, WALL_ODR_ITMS_SZ_6S   --堵单时间超过6秒笔数（SZ)
, WALL_ODR_ITMS_SZ_MAX_SS  --秒峰值堵单笔数(SZ)
, WALL_ODR_ITMS_6S      --堵单时间超过6秒笔数
,ODR_ITMS_FUNC        --委托笔数(性能)
,ODR_ITMS_SH_FUNC     --委托笔数(SH)(性能)
,ODR_ITMS_SZ_FUNC     --委托笔数(SZ)(性能)
, QLFD_CSUT_VOL         --合格客户总数
, TEL_ODR_OPN_NUM       --电话委托开通人数
, ONLINE_ODR_OPN_NUM    --网上委托开通人数
, PHONE_ODR_OPN_NUM     --手机委托开通人数
, UNSCE_ODR_OPN_NUM     --非现场委托开通人数
, T3IP_DEPMGT_CUST_VOL  --三方存管客户数                              
)PARTITION( bus_date = %d{yyyyMMdd})
SELECT      t.BELTO_FILIL_CDG       --分公司编码
          , t.BELTO_FILIL           --分公司名称
          , t.BRH_NO                --营业部编码
          , t.BRH_FULLNM            --营业部名称
          , 'JZJY'               --系统来源
          , NVL(a1.ODR_NUM_PHONE,0)         --手机委托人数
          , NVL(a1.ODR_NUM_TEL,0)           --电话委托人数
          , NVL(a1.ODR_NUM_ONLN,0)          --网上委托人数
          , NVL(a1.ODR_NUM_UNSCE,0)         --非现场委托人数
          , NVL(a1.ODR_NUM,0)               --总委托人数
          , NVL(a1.ODR_ITMS_PHONE,0)        --手机委托笔数
          , NVL(a1.ODR_ITMS_TEL,0)          --电话委托笔数
          , NVL(a1.ODR_ITMS_ONLN,0)         --网上委托笔数
          , NVL(a1.ODR_ITMS_UNSCE,0)        --非现场委托笔数
          , NVL(a1.ODR_ITMS,0)              --总委托笔数 
          , NVL(a1.ODR_ITMS_TRD_SH,0)       --沪市交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_SH,0)     --沪市非交易笔数
          , NVL(a1.ODR_ITMS_TRD_SZ,0)       --深市交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_SZ,0)     --深市非交易笔数	
          , NVL(a1.ODR_ITMS_TRD_HK,0)       --沪港通交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_HK,0)     --沪港通非交易笔数
          , NVL(a1.ODR_ITMS_TRD_SK,0)       --深港通交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_SK,0)     --深港通非交易笔数
          , NVL(a1.ODR_ITMS_TRD_T3BOD,0)    --三板交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_T3BOD,0)  --三板非交易笔数
		  , NVL(a2.ODR_NUM_PHONE,0)         as TFR_ODR_NUM_PHONE     --转账手机委托人数
          , NVL(a2.ODR_NUM_TEL,0)           as TFR_ODR_NUM_TEL       --转账电话委托人数
          , NVL(a2.ODR_NUM_ONLN,0)          as TFR_ODR_NUM_ONLN      --转账网上委托人数
          , NVL(a2.ODR_NUM_UNSCE,0)         as TFR_ODR_NUM_UNSCE     --转账非现场委托人数
          , NVL(a2.ODR_NUM,0)               as TFR_ODR_NUM           --转账总委托人数
          , NVL(a2.ODR_ITMS_PHONE,0)        as TFR_ODR_ITMS_PHONE    --转账手机委托笔数
          , NVL(a2.ODR_ITMS_TEL,0)          as TFR_ODR_ITMS_TEL      --转账电话委托笔数
          , NVL(a2.ODR_ITMS_ONLN,0)         as TFR_ODR_ITMS_ONLN     --转账网上委托笔数
          , NVL(a2.ODR_ITMS_UNSCE,0)        as TFR_ODR_ITMS_UNSCE    --转账非现场委托笔数
          , NVL(a2.ODR_ITMS,0)              as TFR_ODR_ITMS          --转账总委托笔数
          , NULL                            as ODR_ITMS_MAX_SS          --秒峰值委托笔数
          , NULL                            as ODR_ITMS_AVG_SS       --平均每秒委托笔数
          , NULL                            as WALL_ODR_ITMS         --当日堵单笔数
          , NULL                            as WALL_ODR_ITMS_MAX_SS     --秒峰值堵单笔数
          , NULL                            as ODR_ITMS_SH_MAX_SS       --秒峰值委托笔数(SH)
          , NULL                            as ODR_ITMS_AVG_SH_SS    --平均每秒委托笔数(SH)
          , NULL                            as WALL_ODR_ITMS_SH      --当日堵单笔数(SH)
          , NULL                            as WALL_ODR_ITMS_SH_6S   --堵单时间超过6秒笔数（SH)
          , NULL                            as WALL_ODR_ITMS_SH_MAX_SS  --秒峰值堵单笔数(SH)
          , NULL                            as ODR_ITMS_SZ_MAX_SS       --秒峰值委托笔数(SZ)
          , NULL                            as ODR_ITMS_AVG_SZ_SS    --平均每秒委托笔数(SZ)
          , NULL                            as WALL_ODR_ITMS_SZ      --当日堵单笔数(SZ)
          , NULL                            as WALL_ODR_ITMS_SZ_6S   --堵单时间超过6秒笔数（SZ)
          , NULL                            as WALL_ODR_ITMS_SZ_MAX_SS  --秒峰值堵单笔数(SZ)
		  , NULL                            as WALL_ODR_ITMS_6S      --堵单时间超过6秒笔数
          , NULL                            as ODR_ITMS_FUNC        --委托笔数(性能)
          , NULL                            as ODR_ITMS_SH_FUNC     --委托笔数(SH)(性能)
          , NULL                            as ODR_ITMS_SZ_FUNC     --委托笔数(SZ)(性能)
		  
		  , NVL(a3.QLFD_CSUT_VOL,0)         --合格客户总数
          , NVL(a3.TEL_ODR_OPN_NUM,0)       --电话委托开通人数
          , NVL(a3.ONLINE_ODR_OPN_NUM,0)    --网上委托开通人数
          , NVL(a3.PHONE_ODR_OPN_NUM,0)     --手机委托开通人数
          , NVL(a3.UNSCE_ODR_OPN_NUM,0)     --非现场委托开通人数
          , NVL(a3.T3IP_DEPMGT_CUST_VOL,0)  --三方存管客户数
FROM      DDW_PROD.T_DDW_INR_ORG_BRH                   t
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP     a1
ON        t.BRH_NO = a1.BRH_NO
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP3     a2
ON        t.BRH_NO = a2.BRH_NO
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP8     a3
ON        t.BRH_NO = a3.BRH_NO
AND       a3.SYS_SRC = 'JZJY'
WHERE t.BUS_DATE = %d{yyyyMMdd} ;
-----插入GGQQ
INSERT  INTO DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY
(
  BELTO_FILIL_CDG       --分公司编码
, BELTO_FILIL           --分公司名称
, BRH_NO                --营业部编码
, BRH_FULLNM            --营业部名称
, SYS_SRC               --系统来源
, ODR_NUM_PHONE         --手机委托人数
, ODR_NUM_TEL           --电话委托人数
, ODR_NUM_ONLN          --网上委托人数
, ODR_NUM_UNSCE         --非现场委托人数
, ODR_NUM               --总委托人数
, ODR_ITMS_PHONE        --手机委托笔数
, ODR_ITMS_TEL          --电话委托笔数
, ODR_ITMS_ONLN         --网上委托笔数
, ODR_ITMS_UNSCE        --非现场委托笔数
, ODR_ITMS              --总委托笔数 
, ODR_ITMS_TRD_SH       --沪市交易笔数
, ODR_ITMS_UNTRD_SH     --沪市非交易笔数
, ODR_ITMS_TRD_SZ       --深市交易笔数
, ODR_ITMS_UNTRD_SZ     --深市非交易笔数	
, ODR_ITMS_TRD_HK       --沪港通交易笔数
, ODR_ITMS_UNTRD_HK     --沪港通非交易笔数
, ODR_ITMS_TRD_SK       --深港通交易笔数
, ODR_ITMS_UNTRD_SK     --深港通非交易笔数
, ODR_ITMS_TRD_T3BOD    --三板交易笔数
, ODR_ITMS_UNTRD_T3BOD  --三板非交易笔数
, TFR_ODR_NUM_PHONE     --转账手机委托人数
, TFR_ODR_NUM_TEL       --转账电话委托人数
, TFR_ODR_NUM_ONLN      --转账网上委托人数
, TFR_ODR_NUM_UNSCE     --转账非现场委托人数
, TFR_ODR_NUM           --转账总委托人数
, TFR_ODR_ITMS_PHONE    --转账手机委托笔数
, TFR_ODR_ITMS_TEL      --转账电话委托笔数
, TFR_ODR_ITMS_ONLN     --转账网上委托笔数
, TFR_ODR_ITMS_UNSCE    --转账非现场委托笔数
, TFR_ODR_ITMS          --转账总委托笔数
, ODR_ITMS_MAX_SS          --秒峰值委托笔数
, ODR_ITMS_AVG_SS       --平均每秒委托笔数
, WALL_ODR_ITMS         --当日堵单笔数
, WALL_ODR_ITMS_MAX_SS     --秒峰值堵单笔数
, ODR_ITMS_SH_MAX_SS       --秒峰值委托笔数(SH)
, ODR_ITMS_AVG_SH_SS    --平均每秒委托笔数(SH)
, WALL_ODR_ITMS_SH      --当日堵单笔数(SH)
, WALL_ODR_ITMS_SH_6S   --堵单时间超过6秒笔数（SH)
, WALL_ODR_ITMS_SH_MAX_SS  --秒峰值堵单笔数(SH)
, ODR_ITMS_SZ_MAX_SS       --秒峰值委托笔数(SZ)
, ODR_ITMS_AVG_SZ_SS    --平均每秒委托笔数(SZ)
, WALL_ODR_ITMS_SZ      --当日堵单笔数(SZ)
, WALL_ODR_ITMS_SZ_6S   --堵单时间超过6秒笔数（SZ)
, WALL_ODR_ITMS_SZ_MAX_SS  --秒峰值堵单笔数(SZ)
, WALL_ODR_ITMS_6S      --堵单时间超过6秒笔数
,ODR_ITMS_FUNC        --委托笔数(性能)
,ODR_ITMS_SH_FUNC     --委托笔数(SH)(性能)
,ODR_ITMS_SZ_FUNC     --委托笔数(SZ)(性能)
, QLFD_CSUT_VOL         --合格客户总数
, TEL_ODR_OPN_NUM       --电话委托开通人数
, ONLINE_ODR_OPN_NUM    --网上委托开通人数
, PHONE_ODR_OPN_NUM     --手机委托开通人数
, UNSCE_ODR_OPN_NUM     --非现场委托开通人数
, T3IP_DEPMGT_CUST_VOL  --三方存管客户数                              
)PARTITION( bus_date = %d{yyyyMMdd})
SELECT      t.BELTO_FILIL_CDG       --分公司编码
          , t.BELTO_FILIL           --分公司名称
          , t.BRH_NO                --营业部编码
          , t.BRH_FULLNM            --营业部名称
          , 'GGQQ'               --系统来源
          , NVL(a1.ODR_NUM_PHONE,0)         --手机委托人数
          , NVL(a1.ODR_NUM_TEL,0)           --电话委托人数
          , NVL(a1.ODR_NUM_ONLN,0)          --网上委托人数
          , NVL(a1.ODR_NUM_UNSCE,0)         --非现场委托人数
          , NVL(a1.ODR_NUM,0)               --总委托人数
          , NVL(a1.ODR_ITMS_PHONE,0)        --手机委托笔数
          , NVL(a1.ODR_ITMS_TEL,0)          --电话委托笔数
          , NVL(a1.ODR_ITMS_ONLN,0)         --网上委托笔数
          , NVL(a1.ODR_ITMS_UNSCE,0)        --非现场委托笔数
          , NVL(a1.ODR_ITMS,0)              --总委托笔数 
          , NULL  --沪市交易笔数
          , NULL  --沪市非交易笔数
          , NULL  --深市交易笔数
          , NULL  --深市非交易笔数	
          , NULL  --沪港通交易笔数
          , NULL  --沪港通非交易笔数
          , NULL  --深港通交易笔数
          , NULL  --深港通非交易笔数
          , NULL  --三板交易笔数
          , NULL  --三板非交易笔数
		  , NVL(a2.ODR_NUM_PHONE,0)         as TFR_ODR_NUM_PHONE     --转账手机委托人数
          , NVL(a2.ODR_NUM_TEL,0)           as TFR_ODR_NUM_TEL       --转账电话委托人数
          , NVL(a2.ODR_NUM_ONLN,0)          as TFR_ODR_NUM_ONLN      --转账网上委托人数
          , NVL(a2.ODR_NUM_UNSCE,0)         as TFR_ODR_NUM_UNSCE     --转账非现场委托人数
          , NVL(a2.ODR_NUM,0)               as TFR_ODR_NUM           --转账总委托人数
          , NVL(a2.ODR_ITMS_PHONE,0)        as TFR_ODR_ITMS_PHONE    --转账手机委托笔数
          , NVL(a2.ODR_ITMS_TEL,0)          as TFR_ODR_ITMS_TEL      --转账电话委托笔数
          , NVL(a2.ODR_ITMS_ONLN,0)         as TFR_ODR_ITMS_ONLN     --转账网上委托笔数
          , NVL(a2.ODR_ITMS_UNSCE,0)        as TFR_ODR_ITMS_UNSCE    --转账非现场委托笔数
          , NVL(a2.ODR_ITMS,0)              as TFR_ODR_ITMS          --转账总委托笔数
          , NULL                            as ODR_ITMS_MAX_SS          --秒峰值委托笔数
          , NULL                            as ODR_ITMS_AVG_SS       --平均每秒委托笔数
          , NULL                            as WALL_ODR_ITMS         --当日堵单笔数
          , NULL                            as WALL_ODR_ITMS_MAX_SS     --秒峰值堵单笔数
          , NULL                            as ODR_ITMS_SH_MAX_SS       --秒峰值委托笔数(SH)
          , NULL                            as ODR_ITMS_AVG_SH_SS    --平均每秒委托笔数(SH)
          , NULL                            as WALL_ODR_ITMS_SH      --当日堵单笔数(SH)
          , NULL                            as WALL_ODR_ITMS_SH_6S   --堵单时间超过6秒笔数（SH)
          , NULL                            as WALL_ODR_ITMS_SH_MAX_SS  --秒峰值堵单笔数(SH)
          , NULL                            as ODR_ITMS_SZ_MAX_SS       --秒峰值委托笔数(SZ)
          , NULL                            as ODR_ITMS_AVG_SZ_SS    --平均每秒委托笔数(SZ)
          , NULL                            as WALL_ODR_ITMS_SZ      --当日堵单笔数(SZ)
          , NULL                            as WALL_ODR_ITMS_SZ_6S   --堵单时间超过6秒笔数（SZ)
          , NULL                            as WALL_ODR_ITMS_SZ_MAX_SS  --秒峰值堵单笔数(SZ)
		  , NULL                            as WALL_ODR_ITMS_6S      --堵单时间超过6秒笔数
          , NULL                            as ODR_ITMS_FUNC        --委托笔数(性能)
		  , NULL                            as ODR_ITMS_SH_FUNC     --委托笔数(SH)(性能)
		  , NULL                            as ODR_ITMS_SZ_FUNC     --委托笔数(SZ)(性能)
		  
		  , NVL(a3.QLFD_CSUT_VOL,0)         --合格客户总数
          , NVL(a3.TEL_ODR_OPN_NUM,0)       --电话委托开通人数
          , NVL(a3.ONLINE_ODR_OPN_NUM,0)    --网上委托开通人数
          , NVL(a3.PHONE_ODR_OPN_NUM,0)     --手机委托开通人数
          , NVL(a3.UNSCE_ODR_OPN_NUM,0)     --非现场委托开通人数
          , NVL(a3.T3IP_DEPMGT_CUST_VOL,0)  --三方存管客户数
FROM      DDW_PROD.T_DDW_INR_ORG_BRH                   t
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP2     a1
ON        t.BRH_NO = a1.BRH_NO
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP5     a2
ON        t.BRH_NO = a2.BRH_NO
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP8     a3
ON        t.BRH_NO = a3.BRH_NO
AND       a3.SYS_SRC = 'GGQQ'
WHERE t.BUS_DATE = %d{yyyyMMdd} ;

-----插入RZRQ
INSERT  INTO DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY
(
  BELTO_FILIL_CDG       --分公司编码
, BELTO_FILIL           --分公司名称
, BRH_NO                --营业部编码
, BRH_FULLNM            --营业部名称
, SYS_SRC               --系统来源
, ODR_NUM_PHONE         --手机委托人数
, ODR_NUM_TEL           --电话委托人数
, ODR_NUM_ONLN          --网上委托人数
, ODR_NUM_UNSCE         --非现场委托人数
, ODR_NUM               --总委托人数
, ODR_ITMS_PHONE        --手机委托笔数
, ODR_ITMS_TEL          --电话委托笔数
, ODR_ITMS_ONLN         --网上委托笔数
, ODR_ITMS_UNSCE        --非现场委托笔数
, ODR_ITMS              --总委托笔数 
, ODR_ITMS_TRD_SH       --沪市交易笔数
, ODR_ITMS_UNTRD_SH     --沪市非交易笔数
, ODR_ITMS_TRD_SZ       --深市交易笔数
, ODR_ITMS_UNTRD_SZ     --深市非交易笔数	
, ODR_ITMS_TRD_HK       --沪港通交易笔数
, ODR_ITMS_UNTRD_HK     --沪港通非交易笔数
, ODR_ITMS_TRD_SK       --深港通交易笔数
, ODR_ITMS_UNTRD_SK     --深港通非交易笔数
, ODR_ITMS_TRD_T3BOD    --三板交易笔数
, ODR_ITMS_UNTRD_T3BOD  --三板非交易笔数
, TFR_ODR_NUM_PHONE     --转账手机委托人数
, TFR_ODR_NUM_TEL       --转账电话委托人数
, TFR_ODR_NUM_ONLN      --转账网上委托人数
, TFR_ODR_NUM_UNSCE     --转账非现场委托人数
, TFR_ODR_NUM           --转账总委托人数
, TFR_ODR_ITMS_PHONE    --转账手机委托笔数
, TFR_ODR_ITMS_TEL      --转账电话委托笔数
, TFR_ODR_ITMS_ONLN     --转账网上委托笔数
, TFR_ODR_ITMS_UNSCE    --转账非现场委托笔数
, TFR_ODR_ITMS          --转账总委托笔数
, ODR_ITMS_MAX_SS          --秒峰值委托笔数
, ODR_ITMS_AVG_SS       --平均每秒委托笔数
, WALL_ODR_ITMS         --当日堵单笔数
, WALL_ODR_ITMS_MAX_SS     --秒峰值堵单笔数
, ODR_ITMS_SH_MAX_SS       --秒峰值委托笔数(SH)
, ODR_ITMS_AVG_SH_SS    --平均每秒委托笔数(SH)
, WALL_ODR_ITMS_SH      --当日堵单笔数(SH)
, WALL_ODR_ITMS_SH_6S   --堵单时间超过6秒笔数（SH)
, WALL_ODR_ITMS_SH_MAX_SS  --秒峰值堵单笔数(SH)
, ODR_ITMS_SZ_MAX_SS       --秒峰值委托笔数(SZ)
, ODR_ITMS_AVG_SZ_SS    --平均每秒委托笔数(SZ)
, WALL_ODR_ITMS_SZ      --当日堵单笔数(SZ)
, WALL_ODR_ITMS_SZ_6S   --堵单时间超过6秒笔数（SZ)
, WALL_ODR_ITMS_SZ_MAX_SS  --秒峰值堵单笔数(SZ)
, WALL_ODR_ITMS_6S      --堵单时间超过6秒笔数
,ODR_ITMS_FUNC        --委托笔数(性能)
,ODR_ITMS_SH_FUNC     --委托笔数(SH)(性能)
,ODR_ITMS_SZ_FUNC     --委托笔数(SZ)(性能)
, QLFD_CSUT_VOL         --合格客户总数
, TEL_ODR_OPN_NUM       --电话委托开通人数
, ONLINE_ODR_OPN_NUM    --网上委托开通人数
, PHONE_ODR_OPN_NUM     --手机委托开通人数
, UNSCE_ODR_OPN_NUM     --非现场委托开通人数
, T3IP_DEPMGT_CUST_VOL  --三方存管客户数                              
)PARTITION( bus_date = %d{yyyyMMdd})
SELECT      t.BELTO_FILIL_CDG       --分公司编码
          , t.BELTO_FILIL           --分公司名称
          , t.BRH_NO                --营业部编码
          , t.BRH_FULLNM            --营业部名称
          , 'RZRQ'               --系统来源
          , NVL(a1.ODR_NUM_PHONE,0)         --手机委托人数
          , NVL(a1.ODR_NUM_TEL,0)           --电话委托人数
          , NVL(a1.ODR_NUM_ONLN,0)          --网上委托人数
          , NVL(a1.ODR_NUM_UNSCE,0)         --非现场委托人数
          , NVL(a1.ODR_NUM,0)               --总委托人数
          , NVL(a1.ODR_ITMS_PHONE,0)        --手机委托笔数
          , NVL(a1.ODR_ITMS_TEL,0)          --电话委托笔数
          , NVL(a1.ODR_ITMS_ONLN,0)         --网上委托笔数
          , NVL(a1.ODR_ITMS_UNSCE,0)        --非现场委托笔数
          , NVL(a1.ODR_ITMS,0)              --总委托笔数 
          , NVL(a1.ODR_ITMS_TRD_SH,0)       --沪市交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_SH,0)     --沪市非交易笔数
          , NVL(a1.ODR_ITMS_TRD_SZ,0)       --深市交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_SZ,0)     --深市非交易笔数	
          , NVL(a1.ODR_ITMS_TRD_HK,0)       --沪港通交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_HK,0)     --沪港通非交易笔数
          , NVL(a1.ODR_ITMS_TRD_SK,0)       --深港通交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_SK,0)     --深港通非交易笔数
          , NVL(a1.ODR_ITMS_TRD_T3BOD,0)    --三板交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_T3BOD,0)  --三板非交易笔数
		  , NVL(a2.ODR_NUM_PHONE,0)         as TFR_ODR_NUM_PHONE     --转账手机委托人数
          , NVL(a2.ODR_NUM_TEL,0)           as TFR_ODR_NUM_TEL       --转账电话委托人数
          , NVL(a2.ODR_NUM_ONLN,0)          as TFR_ODR_NUM_ONLN      --转账网上委托人数
          , NVL(a2.ODR_NUM_UNSCE,0)         as TFR_ODR_NUM_UNSCE     --转账非现场委托人数
          , NVL(a2.ODR_NUM,0)               as TFR_ODR_NUM           --转账总委托人数
          , NVL(a2.ODR_ITMS_PHONE,0)        as TFR_ODR_ITMS_PHONE    --转账手机委托笔数
          , NVL(a2.ODR_ITMS_TEL,0)          as TFR_ODR_ITMS_TEL      --转账电话委托笔数
          , NVL(a2.ODR_ITMS_ONLN,0)         as TFR_ODR_ITMS_ONLN     --转账网上委托笔数
          , NVL(a2.ODR_ITMS_UNSCE,0)        as TFR_ODR_ITMS_UNSCE    --转账非现场委托笔数
          , NVL(a2.ODR_ITMS,0)              as TFR_ODR_ITMS          --转账总委托笔数
          , NULL                            as ODR_ITMS_MAX_SS          --秒峰值委托笔数
          , NULL                            as ODR_ITMS_AVG_SS       --平均每秒委托笔数
          , NULL                            as WALL_ODR_ITMS         --当日堵单笔数
          , NULL                            as WALL_ODR_ITMS_MAX_SS     --秒峰值堵单笔数
          , NULL                            as ODR_ITMS_SH_MAX_SS       --秒峰值委托笔数(SH)
          , NULL                            as ODR_ITMS_AVG_SH_SS    --平均每秒委托笔数(SH)
          , NULL                            as WALL_ODR_ITMS_SH      --当日堵单笔数(SH)
          , NULL                            as WALL_ODR_ITMS_SH_6S   --堵单时间超过6秒笔数（SH)
          , NULL                            as WALL_ODR_ITMS_SH_MAX_SS  --秒峰值堵单笔数(SH)
          , NULL                            as ODR_ITMS_SZ_MAX_SS       --秒峰值委托笔数(SZ)
          , NULL                            as ODR_ITMS_AVG_SZ_SS    --平均每秒委托笔数(SZ)
          , NULL                            as WALL_ODR_ITMS_SZ      --当日堵单笔数(SZ)
          , NULL                            as WALL_ODR_ITMS_SZ_6S   --堵单时间超过6秒笔数（SZ)
          , NULL                            as WALL_ODR_ITMS_SZ_MAX_SS  --秒峰值堵单笔数(SZ)
		  , NULL                            as WALL_ODR_ITMS_6S      --堵单时间超过6秒笔数
          , NULL                            as ODR_ITMS_FUNC        --委托笔数(性能)
		  , NULL                            as ODR_ITMS_SH_FUNC     --委托笔数(SH)(性能)
		  , NULL                            as ODR_ITMS_SZ_FUNC     --委托笔数(SZ)(性能)
		  , NVL(a3.QLFD_CSUT_VOL,0)         --合格客户总数
          , NVL(a3.TEL_ODR_OPN_NUM,0)       --电话委托开通人数
          , NVL(a3.ONLINE_ODR_OPN_NUM,0)    --网上委托开通人数
          , NVL(a3.PHONE_ODR_OPN_NUM,0)     --手机委托开通人数
          , NVL(a3.UNSCE_ODR_OPN_NUM,0)     --非现场委托开通人数
          , NVL(a3.T3IP_DEPMGT_CUST_VOL,0)  --三方存管客户数
FROM      DDW_PROD.T_DDW_INR_ORG_BRH                   t
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP1     a1
ON        t.BRH_NO = a1.BRH_NO
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP4     a2
ON        t.BRH_NO = a2.BRH_NO
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP8     a3
ON        t.BRH_NO = a3.BRH_NO
AND       a3.SYS_SRC = 'RZRQ'
WHERE t.BUS_DATE = %d{yyyyMMdd} ;

INSERT  INTO DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY
(
  BELTO_FILIL_CDG       --分公司编码
, BELTO_FILIL           --分公司名称
, BRH_NO                --营业部编码
, BRH_FULLNM            --营业部名称
, SYS_SRC               --系统来源
, ODR_NUM_PHONE         --手机委托人数
, ODR_NUM_TEL           --电话委托人数
, ODR_NUM_ONLN          --网上委托人数
, ODR_NUM_UNSCE         --非现场委托人数
, ODR_NUM               --总委托人数
, ODR_ITMS_PHONE        --手机委托笔数
, ODR_ITMS_TEL          --电话委托笔数
, ODR_ITMS_ONLN         --网上委托笔数
, ODR_ITMS_UNSCE        --非现场委托笔数
, ODR_ITMS              --总委托笔数 
, ODR_ITMS_TRD_SH       --沪市交易笔数
, ODR_ITMS_UNTRD_SH     --沪市非交易笔数
, ODR_ITMS_TRD_SZ       --深市交易笔数
, ODR_ITMS_UNTRD_SZ     --深市非交易笔数	
, ODR_ITMS_TRD_HK       --沪港通交易笔数
, ODR_ITMS_UNTRD_HK     --沪港通非交易笔数
, ODR_ITMS_TRD_SK       --深港通交易笔数
, ODR_ITMS_UNTRD_SK     --深港通非交易笔数
, ODR_ITMS_TRD_T3BOD    --三板交易笔数
, ODR_ITMS_UNTRD_T3BOD  --三板非交易笔数
, TFR_ODR_NUM_PHONE     --转账手机委托人数
, TFR_ODR_NUM_TEL       --转账电话委托人数
, TFR_ODR_NUM_ONLN      --转账网上委托人数
, TFR_ODR_NUM_UNSCE     --转账非现场委托人数
, TFR_ODR_NUM           --转账总委托人数
, TFR_ODR_ITMS_PHONE    --转账手机委托笔数
, TFR_ODR_ITMS_TEL      --转账电话委托笔数
, TFR_ODR_ITMS_ONLN     --转账网上委托笔数
, TFR_ODR_ITMS_UNSCE    --转账非现场委托笔数
, TFR_ODR_ITMS          --转账总委托笔数
, ODR_ITMS_MAX_SS          --秒峰值委托笔数
, ODR_ITMS_AVG_SS       --平均每秒委托笔数
, WALL_ODR_ITMS         --当日堵单笔数
, WALL_ODR_ITMS_MAX_SS     --秒峰值堵单笔数
, ODR_ITMS_SH_MAX_SS       --秒峰值委托笔数(SH)
, ODR_ITMS_AVG_SH_SS    --平均每秒委托笔数(SH)
, WALL_ODR_ITMS_SH      --当日堵单笔数(SH)
, WALL_ODR_ITMS_SH_6S   --堵单时间超过6秒笔数（SH)
, WALL_ODR_ITMS_SH_MAX_SS  --秒峰值堵单笔数(SH)
, ODR_ITMS_SZ_MAX_SS       --秒峰值委托笔数(SZ)
, ODR_ITMS_AVG_SZ_SS    --平均每秒委托笔数(SZ)
, WALL_ODR_ITMS_SZ      --当日堵单笔数(SZ)
, WALL_ODR_ITMS_SZ_6S   --堵单时间超过6秒笔数（SZ)
, WALL_ODR_ITMS_SZ_MAX_SS  --秒峰值堵单笔数(SZ)
, WALL_ODR_ITMS_6S      --堵单时间超过6秒笔数
,ODR_ITMS_FUNC        --委托笔数(性能)
,ODR_ITMS_SH_FUNC     --委托笔数(SH)(性能)
,ODR_ITMS_SZ_FUNC     --委托笔数(SZ)(性能)
, QLFD_CSUT_VOL         --合格客户总数
, TEL_ODR_OPN_NUM       --电话委托开通人数
, ONLINE_ODR_OPN_NUM    --网上委托开通人数
, PHONE_ODR_OPN_NUM     --手机委托开通人数
, UNSCE_ODR_OPN_NUM     --非现场委托开通人数
, T3IP_DEPMGT_CUST_VOL  --三方存管客户数                              
)PARTITION( bus_date = %d{yyyyMMdd})
SELECT      '0001'               --分公司编码
          , '上海证券'           --分公司名称
          , NULL                 --营业部编码
          , NULL                 --营业部名称
          , 'JZJY'               --系统来源
          , NVL(a1.ODR_NUM_PHONE,0)         --手机委托人数
          , NVL(a1.ODR_NUM_TEL,0)           --电话委托人数
          , NVL(a1.ODR_NUM_ONLN,0)          --网上委托人数
          , NVL(a1.ODR_NUM_UNSCE,0)         --非现场委托人数
          , NVL(a1.ODR_NUM,0)               --总委托人数
          , NVL(a1.ODR_ITMS_PHONE,0)        --手机委托笔数
          , NVL(a1.ODR_ITMS_TEL,0)          --电话委托笔数
          , NVL(a1.ODR_ITMS_ONLN,0)         --网上委托笔数
          , NVL(a1.ODR_ITMS_UNSCE,0)        --非现场委托笔数
          , NVL(a1.ODR_ITMS,0)              --总委托笔数 
          , NVL(a1.ODR_ITMS_TRD_SH,0)       --沪市交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_SH,0)     --沪市非交易笔数
          , NVL(a1.ODR_ITMS_TRD_SZ,0)       --深市交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_SZ,0)     --深市非交易笔数	
          , NVL(a1.ODR_ITMS_TRD_HK,0)       --沪港通交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_HK,0)     --沪港通非交易笔数
          , NVL(a1.ODR_ITMS_TRD_SK,0)       --深港通交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_SK,0)     --深港通非交易笔数
          , NVL(a1.ODR_ITMS_TRD_T3BOD,0)    --三板交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_T3BOD,0)  --三板非交易笔数
		  , NVL(a2.ODR_NUM_PHONE,0)         as TFR_ODR_NUM_PHONE     --转账手机委托人数
          , NVL(a2.ODR_NUM_TEL,0)           as TFR_ODR_NUM_TEL       --转账电话委托人数
          , NVL(a2.ODR_NUM_ONLN,0)          as TFR_ODR_NUM_ONLN      --转账网上委托人数
          , NVL(a2.ODR_NUM_UNSCE,0)         as TFR_ODR_NUM_UNSCE     --转账非现场委托人数
          , NVL(a2.ODR_NUM,0)               as TFR_ODR_NUM           --转账总委托人数
          , NVL(a2.ODR_ITMS_PHONE,0)        as TFR_ODR_ITMS_PHONE    --转账手机委托笔数
          , NVL(a2.ODR_ITMS_TEL,0)          as TFR_ODR_ITMS_TEL      --转账电话委托笔数
          , NVL(a2.ODR_ITMS_ONLN,0)         as TFR_ODR_ITMS_ONLN     --转账网上委托笔数
          , NVL(a2.ODR_ITMS_UNSCE,0)        as TFR_ODR_ITMS_UNSCE    --转账非现场委托笔数
          , NVL(a2.ODR_ITMS,0)              as TFR_ODR_ITMS          --转账总委托笔数
          , NVL(a4.ODR_ITMS_MAX_SS,0)          as ODR_ITMS_MAX_SS          --秒峰值委托笔数
          , CAST(NVL(a4.ODR_ITMS_AVG_SS,0) as DECIMAL(38,1))       as ODR_ITMS_AVG_SS       --平均每秒委托笔数
          , NVL(a4.WALL_ODR_ITMS,0)         as WALL_ODR_ITMS         --当日堵单笔数
          , NVL(a4.WALL_ODR_ITMS_MAX_SS,0)     as WALL_ODR_ITMS_MAX_SS     --秒峰值堵单笔数
          , NVL(a4.ODR_ITMS_SH_MAX_SS,0)       as ODR_ITMS_SH_MAX_SS       --秒峰值委托笔数(SH)
          , CAST(NVL(a4.ODR_ITMS_AVG_SH_SS,0)as DECIMAL(38,1))    as ODR_ITMS_AVG_SH_SS    --平均每秒委托笔数(SH)
          , NVL(a4.WALL_ODR_ITMS_SH,0)      as WALL_ODR_ITMS_SH      --当日堵单笔数(SH)
          , NVL(a4.WALL_ODR_ITMS_SH_6S,0)   as WALL_ODR_ITMS_SH_6S   --堵单时间超过6秒笔数（SH)
          , NVL(a4.WALL_ODR_ITMS_SH_MAX_SS,0)  as WALL_ODR_ITMS_SH_MAX_SS  --秒峰值堵单笔数(SH)
          , NVL(a4.ODR_ITMS_SZ_MAX_SS,0)       as ODR_ITMS_SZ_MAX_SS       --秒峰值委托笔数(SZ)
          , CAST(NVL(a4.ODR_ITMS_AVG_SZ_SS,0)as DECIMAL(38,1))    as ODR_ITMS_AVG_SZ_SS    --平均每秒委托笔数(SZ)
          , NVL(a4.WALL_ODR_ITMS_SZ,0)      as WALL_ODR_ITMS_SZ      --当日堵单笔数(SZ)
          , NVL(a4.WALL_ODR_ITMS_SZ_6S,0)   as WALL_ODR_ITMS_SZ_6S   --堵单时间超过6秒笔数（SZ)
          , NVL(a4.WALL_ODR_ITMS_SZ_MAX_SS,0)  as WALL_ODR_ITMS_SZ_MAX_SS  --秒峰值堵单笔数(SZ)
		  , NVL(a4.WALL_ODR_ITMS_6S,0)      as WALL_ODR_ITMS_6S      --堵单时间超过6秒笔数
          , NVL(a4.ODR_ITMS_FUNC,0)    as ODR_ITMS_FUNC        --委托笔数(性能)
		  , NVL(a4.ODR_ITMS_SH_FUNC,0) as ODR_ITMS_SH_FUNC     --委托笔数(SH)(性能)
		  , NVL(a4.ODR_ITMS_SZ_FUNC,0) as ODR_ITMS_SZ_FUNC     --委托笔数(SZ)(性能)
		  , NVL(a3.QLFD_CSUT_VOL,0)         --合格客户总数
          , NVL(a3.TEL_ODR_OPN_NUM,0)       --电话委托开通人数
          , NVL(a3.ONLINE_ODR_OPN_NUM,0)    --网上委托开通人数
          , NVL(a3.PHONE_ODR_OPN_NUM,0)     --手机委托开通人数
          , NVL(a3.UNSCE_ODR_OPN_NUM,0)     --非现场委托开通人数
          , NVL(a3.T3IP_DEPMGT_CUST_VOL,0)  --三方存管客户数
FROM (SELECT 1 as ID
             ,SUM(ODR_NUM_PHONE)        as  ODR_NUM_PHONE        
             ,SUM(ODR_NUM_TEL)          as  ODR_NUM_TEL    
             ,SUM(ODR_NUM_ONLN)         as  ODR_NUM_ONLN    
             ,SUM(ODR_NUM_UNSCE)        as  ODR_NUM_UNSCE   
             ,SUM(ODR_NUM)              as  ODR_NUM    
             ,SUM(ODR_ITMS_PHONE)       as  ODR_ITMS_PHONE  
			 ,SUM(ODR_ITMS_TEL)         as  ODR_ITMS_TEL    
             ,SUM(ODR_ITMS_ONLN)        as  ODR_ITMS_ONLN   
             ,SUM(ODR_ITMS_UNSCE)       as  ODR_ITMS_UNSCE  
             ,SUM(ODR_ITMS)             as  ODR_ITMS    
             ,SUM(ODR_ITMS_TRD_SH)      as  ODR_ITMS_TRD_SH       
             ,SUM(ODR_ITMS_UNTRD_SH)    as  ODR_ITMS_UNTRD_SH     
             ,SUM(ODR_ITMS_TRD_SZ)      as  ODR_ITMS_TRD_SZ       
             ,SUM(ODR_ITMS_UNTRD_SZ)    as  ODR_ITMS_UNTRD_SZ     
             ,SUM(ODR_ITMS_TRD_HK)      as  ODR_ITMS_TRD_HK       
             ,SUM(ODR_ITMS_UNTRD_HK)    as  ODR_ITMS_UNTRD_HK     
             ,SUM(ODR_ITMS_TRD_SK)      as  ODR_ITMS_TRD_SK       
             ,SUM(ODR_ITMS_UNTRD_SK)    as  ODR_ITMS_UNTRD_SK     
             ,SUM(ODR_ITMS_TRD_T3BOD)   as  ODR_ITMS_TRD_T3BOD    
			 ,SUM(ODR_ITMS_UNTRD_T3BOD) as  ODR_ITMS_UNTRD_T3BOD  
      FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP
     )     a1
LEFT JOIN (SELECT 1 as ID
                 ,SUM(ODR_NUM_PHONE)  as  ODR_NUM_PHONE     
                 ,SUM(ODR_NUM_TEL)    as  ODR_NUM_TEL    
                 ,SUM(ODR_NUM_ONLN)   as  ODR_NUM_ONLN    
                 ,SUM(ODR_NUM_UNSCE)  as  ODR_NUM_UNSCE    
                 ,SUM(ODR_NUM)        as  ODR_NUM    
                 ,SUM(ODR_ITMS_PHONE) as  ODR_ITMS_PHONE    
			     ,SUM(ODR_ITMS_TEL)   as  ODR_ITMS_TEL    
                 ,SUM(ODR_ITMS_ONLN)  as  ODR_ITMS_ONLN    
                 ,SUM(ODR_ITMS_UNSCE) as  ODR_ITMS_UNSCE    
                 ,SUM(ODR_ITMS)       as  ODR_ITMS    
          FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP3
        )      a2
ON        a1.ID = a2.ID
LEFT JOIN (SELECT 1 as ID
                 ,SUM(QLFD_CSUT_VOL)          as QLFD_CSUT_VOL      
                 ,SUM(TEL_ODR_OPN_NUM)        as TEL_ODR_OPN_NUM
                 ,SUM(ONLINE_ODR_OPN_NUM)     as ONLINE_ODR_OPN_NUM
                 ,SUM(PHONE_ODR_OPN_NUM)      as PHONE_ODR_OPN_NUM
                 ,SUM(UNSCE_ODR_OPN_NUM)      as UNSCE_ODR_OPN_NUM
                 ,SUM(T3IP_DEPMGT_CUST_VOL)   as T3IP_DEPMGT_CUST_VOL     
          FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP8
		  WHERE SYS_SRC = 'JZJY'
         )      a3
ON        a1.ID = a3.ID
LEFT JOIN (SELECT 1 as ID,* FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP6 WHERE XTBS = 'JZJY') a4
ON        a1.ID = a4.ID
--LEFT JOIN (SELECT 1 as ID,* FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP7 WHERE XTBS = 'JZJY') a5
--ON        a1.ID = a5.ID
 ;
 
INSERT  INTO DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY
(
  BELTO_FILIL_CDG       --分公司编码
, BELTO_FILIL           --分公司名称
, BRH_NO                --营业部编码
, BRH_FULLNM            --营业部名称
, SYS_SRC               --系统来源
, ODR_NUM_PHONE         --手机委托人数
, ODR_NUM_TEL           --电话委托人数
, ODR_NUM_ONLN          --网上委托人数
, ODR_NUM_UNSCE         --非现场委托人数
, ODR_NUM               --总委托人数
, ODR_ITMS_PHONE        --手机委托笔数
, ODR_ITMS_TEL          --电话委托笔数
, ODR_ITMS_ONLN         --网上委托笔数
, ODR_ITMS_UNSCE        --非现场委托笔数
, ODR_ITMS              --总委托笔数 
, ODR_ITMS_TRD_SH       --沪市交易笔数
, ODR_ITMS_UNTRD_SH     --沪市非交易笔数
, ODR_ITMS_TRD_SZ       --深市交易笔数
, ODR_ITMS_UNTRD_SZ     --深市非交易笔数	
, ODR_ITMS_TRD_HK       --沪港通交易笔数
, ODR_ITMS_UNTRD_HK     --沪港通非交易笔数
, ODR_ITMS_TRD_SK       --深港通交易笔数
, ODR_ITMS_UNTRD_SK     --深港通非交易笔数
, ODR_ITMS_TRD_T3BOD    --三板交易笔数
, ODR_ITMS_UNTRD_T3BOD  --三板非交易笔数
, TFR_ODR_NUM_PHONE     --转账手机委托人数
, TFR_ODR_NUM_TEL       --转账电话委托人数
, TFR_ODR_NUM_ONLN      --转账网上委托人数
, TFR_ODR_NUM_UNSCE     --转账非现场委托人数
, TFR_ODR_NUM           --转账总委托人数
, TFR_ODR_ITMS_PHONE    --转账手机委托笔数
, TFR_ODR_ITMS_TEL      --转账电话委托笔数
, TFR_ODR_ITMS_ONLN     --转账网上委托笔数
, TFR_ODR_ITMS_UNSCE    --转账非现场委托笔数
, TFR_ODR_ITMS          --转账总委托笔数
, ODR_ITMS_MAX_SS          --秒峰值委托笔数
, ODR_ITMS_AVG_SS       --平均每秒委托笔数
, WALL_ODR_ITMS         --当日堵单笔数
, WALL_ODR_ITMS_MAX_SS     --秒峰值堵单笔数
, ODR_ITMS_SH_MAX_SS       --秒峰值委托笔数(SH)
, ODR_ITMS_AVG_SH_SS    --平均每秒委托笔数(SH)
, WALL_ODR_ITMS_SH      --当日堵单笔数(SH)
, WALL_ODR_ITMS_SH_6S   --堵单时间超过6秒笔数（SH)
, WALL_ODR_ITMS_SH_MAX_SS  --秒峰值堵单笔数(SH)
, ODR_ITMS_SZ_MAX_SS       --秒峰值委托笔数(SZ)
, ODR_ITMS_AVG_SZ_SS    --平均每秒委托笔数(SZ)
, WALL_ODR_ITMS_SZ      --当日堵单笔数(SZ)
, WALL_ODR_ITMS_SZ_6S   --堵单时间超过6秒笔数（SZ)
, WALL_ODR_ITMS_SZ_MAX_SS  --秒峰值堵单笔数(SZ)
, WALL_ODR_ITMS_6S      --堵单时间超过6秒笔数
,ODR_ITMS_FUNC        --委托笔数(性能)
,ODR_ITMS_SH_FUNC     --委托笔数(SH)(性能)
,ODR_ITMS_SZ_FUNC     --委托笔数(SZ)(性能)
, QLFD_CSUT_VOL         --合格客户总数
, TEL_ODR_OPN_NUM       --电话委托开通人数
, ONLINE_ODR_OPN_NUM    --网上委托开通人数
, PHONE_ODR_OPN_NUM     --手机委托开通人数
, UNSCE_ODR_OPN_NUM     --非现场委托开通人数
, T3IP_DEPMGT_CUST_VOL  --三方存管客户数                              
)PARTITION( bus_date = %d{yyyyMMdd})
SELECT      '0001'               --分公司编码
          , '上海证券'           --分公司名称
          , NULL                 --营业部编码
          , NULL                 --营业部名称
          , 'RZRQ'               --系统来源
          , NVL(a1.ODR_NUM_PHONE,0)         --手机委托人数
          , NVL(a1.ODR_NUM_TEL,0)           --电话委托人数
          , NVL(a1.ODR_NUM_ONLN,0)          --网上委托人数
          , NVL(a1.ODR_NUM_UNSCE,0)         --非现场委托人数
          , NVL(a1.ODR_NUM,0)               --总委托人数
          , NVL(a1.ODR_ITMS_PHONE,0)        --手机委托笔数
          , NVL(a1.ODR_ITMS_TEL,0)          --电话委托笔数
          , NVL(a1.ODR_ITMS_ONLN,0)         --网上委托笔数
          , NVL(a1.ODR_ITMS_UNSCE,0)        --非现场委托笔数
          , NVL(a1.ODR_ITMS,0)              --总委托笔数 
          , NVL(a1.ODR_ITMS_TRD_SH,0)       --沪市交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_SH,0)     --沪市非交易笔数
          , NVL(a1.ODR_ITMS_TRD_SZ,0)       --深市交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_SZ,0)     --深市非交易笔数	
          , NVL(a1.ODR_ITMS_TRD_HK,0)       --沪港通交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_HK,0)     --沪港通非交易笔数
          , NVL(a1.ODR_ITMS_TRD_SK,0)       --深港通交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_SK,0)     --深港通非交易笔数
          , NVL(a1.ODR_ITMS_TRD_T3BOD,0)    --三板交易笔数
          , NVL(a1.ODR_ITMS_UNTRD_T3BOD,0)  --三板非交易笔数
		  , NVL(a2.ODR_NUM_PHONE,0)         as TFR_ODR_NUM_PHONE     --转账手机委托人数
          , NVL(a2.ODR_NUM_TEL,0)           as TFR_ODR_NUM_TEL       --转账电话委托人数
          , NVL(a2.ODR_NUM_ONLN,0)          as TFR_ODR_NUM_ONLN      --转账网上委托人数
          , NVL(a2.ODR_NUM_UNSCE,0)         as TFR_ODR_NUM_UNSCE     --转账非现场委托人数
          , NVL(a2.ODR_NUM,0)               as TFR_ODR_NUM           --转账总委托人数
          , NVL(a2.ODR_ITMS_PHONE,0)        as TFR_ODR_ITMS_PHONE    --转账手机委托笔数
          , NVL(a2.ODR_ITMS_TEL,0)          as TFR_ODR_ITMS_TEL      --转账电话委托笔数
          , NVL(a2.ODR_ITMS_ONLN,0)         as TFR_ODR_ITMS_ONLN     --转账网上委托笔数
          , NVL(a2.ODR_ITMS_UNSCE,0)        as TFR_ODR_ITMS_UNSCE    --转账非现场委托笔数
          , NVL(a2.ODR_ITMS,0)              as TFR_ODR_ITMS          --转账总委托笔数
          , NVL(a4.ODR_ITMS_MAX_SS,0)          as ODR_ITMS_MAX_SS          --秒峰值委托笔数
          , CAST(NVL(a4.ODR_ITMS_AVG_SS,0) as DECIMAL(38,1))       as ODR_ITMS_AVG_SS       --平均每秒委托笔数
          , NVL(a4.WALL_ODR_ITMS,0)         as WALL_ODR_ITMS         --当日堵单笔数
          , NVL(a4.WALL_ODR_ITMS_MAX_SS,0)     as WALL_ODR_ITMS_MAX_SS     --秒峰值堵单笔数
          , NVL(a4.ODR_ITMS_SH_MAX_SS,0)       as ODR_ITMS_SH_MAX_SS       --秒峰值委托笔数(SH)
          , CAST(NVL(a4.ODR_ITMS_AVG_SH_SS,0)as DECIMAL(38,1))    as ODR_ITMS_AVG_SH_SS    --平均每秒委托笔数(SH)
          , NVL(a4.WALL_ODR_ITMS_SH,0)      as WALL_ODR_ITMS_SH      --当日堵单笔数(SH)
          , NVL(a4.WALL_ODR_ITMS_SH_6S,0)   as WALL_ODR_ITMS_SH_6S   --堵单时间超过6秒笔数（SH)
          , NVL(a4.WALL_ODR_ITMS_SH_MAX_SS,0)  as WALL_ODR_ITMS_SH_MAX_SS  --秒峰值堵单笔数(SH)
          , NVL(a4.ODR_ITMS_SZ_MAX_SS,0)       as ODR_ITMS_SZ_MAX_SS       --秒峰值委托笔数(SZ)
          , CAST(NVL(a4.ODR_ITMS_AVG_SZ_SS,0)as DECIMAL(38,1))    as ODR_ITMS_AVG_SZ_SS    --平均每秒委托笔数(SZ)
          , NVL(a4.WALL_ODR_ITMS_SZ,0)      as WALL_ODR_ITMS_SZ      --当日堵单笔数(SZ)
          , NVL(a4.WALL_ODR_ITMS_SZ_6S,0)   as WALL_ODR_ITMS_SZ_6S   --堵单时间超过6秒笔数（SZ)
          , NVL(a4.WALL_ODR_ITMS_SZ_MAX_SS,0)  as WALL_ODR_ITMS_SZ_MAX_SS  --秒峰值堵单笔数(SZ)
		  , NVL(a4.WALL_ODR_ITMS_6S,0)      as WALL_ODR_ITMS_6S      --堵单时间超过6秒笔数
          , NVL(a4.ODR_ITMS_FUNC,0)    as ODR_ITMS_FUNC        --委托笔数(性能)
		  , NVL(a4.ODR_ITMS_SH_FUNC,0) as ODR_ITMS_SH_FUNC     --委托笔数(SH)(性能)
		  , NVL(a4.ODR_ITMS_SZ_FUNC,0) as ODR_ITMS_SZ_FUNC     --委托笔数(SZ)(性能)
		  , NVL(a3.QLFD_CSUT_VOL,0)         --合格客户总数
          , NVL(a3.TEL_ODR_OPN_NUM,0)       --电话委托开通人数
          , NVL(a3.ONLINE_ODR_OPN_NUM,0)    --网上委托开通人数
          , NVL(a3.PHONE_ODR_OPN_NUM,0)     --手机委托开通人数
          , NVL(a3.UNSCE_ODR_OPN_NUM,0)     --非现场委托开通人数
          , NVL(a3.T3IP_DEPMGT_CUST_VOL,0)  --三方存管客户数
FROM (SELECT 1 as ID
             ,SUM(ODR_NUM_PHONE)        as  ODR_NUM_PHONE        
             ,SUM(ODR_NUM_TEL)          as  ODR_NUM_TEL    
             ,SUM(ODR_NUM_ONLN)         as  ODR_NUM_ONLN    
             ,SUM(ODR_NUM_UNSCE)        as  ODR_NUM_UNSCE   
             ,SUM(ODR_NUM)              as  ODR_NUM    
             ,SUM(ODR_ITMS_PHONE)       as  ODR_ITMS_PHONE  
			 ,SUM(ODR_ITMS_TEL)         as  ODR_ITMS_TEL    
             ,SUM(ODR_ITMS_ONLN)        as  ODR_ITMS_ONLN   
             ,SUM(ODR_ITMS_UNSCE)       as  ODR_ITMS_UNSCE  
             ,SUM(ODR_ITMS)             as  ODR_ITMS    
             ,SUM(ODR_ITMS_TRD_SH)      as  ODR_ITMS_TRD_SH       
             ,SUM(ODR_ITMS_UNTRD_SH)    as  ODR_ITMS_UNTRD_SH     
             ,SUM(ODR_ITMS_TRD_SZ)      as  ODR_ITMS_TRD_SZ       
             ,SUM(ODR_ITMS_UNTRD_SZ)    as  ODR_ITMS_UNTRD_SZ     
             ,SUM(ODR_ITMS_TRD_HK)      as  ODR_ITMS_TRD_HK       
             ,SUM(ODR_ITMS_UNTRD_HK)    as  ODR_ITMS_UNTRD_HK     
             ,SUM(ODR_ITMS_TRD_SK)      as  ODR_ITMS_TRD_SK       
             ,SUM(ODR_ITMS_UNTRD_SK)    as  ODR_ITMS_UNTRD_SK     
             ,SUM(ODR_ITMS_TRD_T3BOD)   as  ODR_ITMS_TRD_T3BOD    
			 ,SUM(ODR_ITMS_UNTRD_T3BOD) as  ODR_ITMS_UNTRD_T3BOD  
      FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP1
     )     a1
LEFT JOIN (SELECT 1 as ID
                 ,SUM(ODR_NUM_PHONE)  as  ODR_NUM_PHONE     
                 ,SUM(ODR_NUM_TEL)    as  ODR_NUM_TEL    
                 ,SUM(ODR_NUM_ONLN)   as  ODR_NUM_ONLN    
                 ,SUM(ODR_NUM_UNSCE)  as  ODR_NUM_UNSCE    
                 ,SUM(ODR_NUM)        as  ODR_NUM    
                 ,SUM(ODR_ITMS_PHONE) as  ODR_ITMS_PHONE    
			     ,SUM(ODR_ITMS_TEL)   as  ODR_ITMS_TEL    
                 ,SUM(ODR_ITMS_ONLN)  as  ODR_ITMS_ONLN    
                 ,SUM(ODR_ITMS_UNSCE) as  ODR_ITMS_UNSCE    
                 ,SUM(ODR_ITMS)       as  ODR_ITMS    
          FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP4
        )      a2
ON        a1.ID = a2.ID
LEFT JOIN (SELECT 1 as ID
                 ,SUM(QLFD_CSUT_VOL)          as QLFD_CSUT_VOL      
                 ,SUM(TEL_ODR_OPN_NUM)        as TEL_ODR_OPN_NUM
                 ,SUM(ONLINE_ODR_OPN_NUM)     as ONLINE_ODR_OPN_NUM
                 ,SUM(PHONE_ODR_OPN_NUM)      as PHONE_ODR_OPN_NUM
                 ,SUM(UNSCE_ODR_OPN_NUM)      as UNSCE_ODR_OPN_NUM
                 ,SUM(T3IP_DEPMGT_CUST_VOL)   as T3IP_DEPMGT_CUST_VOL     
          FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP8
		  WHERE SYS_SRC = 'RZRQ'
         )      a3
ON        a1.ID = a3.ID
LEFT JOIN (SELECT 1 as ID,* FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP6 WHERE XTBS = 'RZRQ') a4
ON        a1.ID = a4.ID
--LEFT JOIN (SELECT 1 as ID,* FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP7 WHERE XTBS = 'RZRQ') a5
--ON        a1.ID = a5.ID
 ;
 
 INSERT  INTO DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY
(
  BELTO_FILIL_CDG       --分公司编码
, BELTO_FILIL           --分公司名称
, BRH_NO                --营业部编码
, BRH_FULLNM            --营业部名称
, SYS_SRC               --系统来源
, ODR_NUM_PHONE         --手机委托人数
, ODR_NUM_TEL           --电话委托人数
, ODR_NUM_ONLN          --网上委托人数
, ODR_NUM_UNSCE         --非现场委托人数
, ODR_NUM               --总委托人数
, ODR_ITMS_PHONE        --手机委托笔数
, ODR_ITMS_TEL          --电话委托笔数
, ODR_ITMS_ONLN         --网上委托笔数
, ODR_ITMS_UNSCE        --非现场委托笔数
, ODR_ITMS              --总委托笔数 
, ODR_ITMS_TRD_SH       --沪市交易笔数
, ODR_ITMS_UNTRD_SH     --沪市非交易笔数
, ODR_ITMS_TRD_SZ       --深市交易笔数
, ODR_ITMS_UNTRD_SZ     --深市非交易笔数	
, ODR_ITMS_TRD_HK       --沪港通交易笔数
, ODR_ITMS_UNTRD_HK     --沪港通非交易笔数
, ODR_ITMS_TRD_SK       --深港通交易笔数
, ODR_ITMS_UNTRD_SK     --深港通非交易笔数
, ODR_ITMS_TRD_T3BOD    --三板交易笔数
, ODR_ITMS_UNTRD_T3BOD  --三板非交易笔数
, TFR_ODR_NUM_PHONE     --转账手机委托人数
, TFR_ODR_NUM_TEL       --转账电话委托人数
, TFR_ODR_NUM_ONLN      --转账网上委托人数
, TFR_ODR_NUM_UNSCE     --转账非现场委托人数
, TFR_ODR_NUM           --转账总委托人数
, TFR_ODR_ITMS_PHONE    --转账手机委托笔数
, TFR_ODR_ITMS_TEL      --转账电话委托笔数
, TFR_ODR_ITMS_ONLN     --转账网上委托笔数
, TFR_ODR_ITMS_UNSCE    --转账非现场委托笔数
, TFR_ODR_ITMS          --转账总委托笔数
, ODR_ITMS_MAX_SS          --秒峰值委托笔数
, ODR_ITMS_AVG_SS       --平均每秒委托笔数
, WALL_ODR_ITMS         --当日堵单笔数
, WALL_ODR_ITMS_MAX_SS     --秒峰值堵单笔数
, ODR_ITMS_SH_MAX_SS       --秒峰值委托笔数(SH)
, ODR_ITMS_AVG_SH_SS    --平均每秒委托笔数(SH)
, WALL_ODR_ITMS_SH      --当日堵单笔数(SH)
, WALL_ODR_ITMS_SH_6S   --堵单时间超过6秒笔数（SH)
, WALL_ODR_ITMS_SH_MAX_SS  --秒峰值堵单笔数(SH)
, ODR_ITMS_SZ_MAX_SS       --秒峰值委托笔数(SZ)
, ODR_ITMS_AVG_SZ_SS    --平均每秒委托笔数(SZ)
, WALL_ODR_ITMS_SZ      --当日堵单笔数(SZ)
, WALL_ODR_ITMS_SZ_6S   --堵单时间超过6秒笔数（SZ)
, WALL_ODR_ITMS_SZ_MAX_SS  --秒峰值堵单笔数(SZ)
, WALL_ODR_ITMS_6S      --堵单时间超过6秒笔数
,ODR_ITMS_FUNC        --委托笔数(性能)
,ODR_ITMS_SH_FUNC     --委托笔数(SH)(性能)
,ODR_ITMS_SZ_FUNC     --委托笔数(SZ)(性能)
, QLFD_CSUT_VOL         --合格客户总数
, TEL_ODR_OPN_NUM       --电话委托开通人数
, ONLINE_ODR_OPN_NUM    --网上委托开通人数
, PHONE_ODR_OPN_NUM     --手机委托开通人数
, UNSCE_ODR_OPN_NUM     --非现场委托开通人数
, T3IP_DEPMGT_CUST_VOL  --三方存管客户数                              
)PARTITION( bus_date = %d{yyyyMMdd})
SELECT      '0001'               --分公司编码
          , '上海证券'           --分公司名称
          , NULL                 --营业部编码
          , NULL                 --营业部名称
          , 'GGQQ'               --系统来源
          , NVL(a1.ODR_NUM_PHONE,0)         --手机委托人数
          , NVL(a1.ODR_NUM_TEL,0)           --电话委托人数
          , NVL(a1.ODR_NUM_ONLN,0)          --网上委托人数
          , NVL(a1.ODR_NUM_UNSCE,0)         --非现场委托人数
          , NVL(a1.ODR_NUM,0)               --总委托人数
          , NVL(a1.ODR_ITMS_PHONE,0)        --手机委托笔数
          , NVL(a1.ODR_ITMS_TEL,0)          --电话委托笔数
          , NVL(a1.ODR_ITMS_ONLN,0)         --网上委托笔数
          , NVL(a1.ODR_ITMS_UNSCE,0)        --非现场委托笔数
          , NVL(a1.ODR_ITMS,0)              --总委托笔数 
          , NULL  --沪市交易笔数
          , NULL  --沪市非交易笔数
          , NULL  --深市交易笔数
          , NULL  --深市非交易笔数	
          , NULL  --沪港通交易笔数
          , NULL  --沪港通非交易笔数
          , NULL  --深港通交易笔数
          , NULL  --深港通非交易笔数
          , NULL  --三板交易笔数
          , NULL  --三板非交易笔数
		  , NVL(a2.ODR_NUM_PHONE,0)         as TFR_ODR_NUM_PHONE     --转账手机委托人数
          , NVL(a2.ODR_NUM_TEL,0)           as TFR_ODR_NUM_TEL       --转账电话委托人数
          , NVL(a2.ODR_NUM_ONLN,0)          as TFR_ODR_NUM_ONLN      --转账网上委托人数
          , NVL(a2.ODR_NUM_UNSCE,0)         as TFR_ODR_NUM_UNSCE     --转账非现场委托人数
          , NVL(a2.ODR_NUM,0)               as TFR_ODR_NUM           --转账总委托人数
          , NVL(a2.ODR_ITMS_PHONE,0)        as TFR_ODR_ITMS_PHONE    --转账手机委托笔数
          , NVL(a2.ODR_ITMS_TEL,0)          as TFR_ODR_ITMS_TEL      --转账电话委托笔数
          , NVL(a2.ODR_ITMS_ONLN,0)         as TFR_ODR_ITMS_ONLN     --转账网上委托笔数
          , NVL(a2.ODR_ITMS_UNSCE,0)        as TFR_ODR_ITMS_UNSCE    --转账非现场委托笔数
          , NVL(a2.ODR_ITMS,0)              as TFR_ODR_ITMS          --转账总委托笔数
          , NVL(a4.ODR_ITMS_MAX_SS,0)           as ODR_ITMS_MAX_SS          --秒峰值委托笔数
          , CAST(NVL(a4.ODR_ITMS_AVG_SS,0) as DECIMAL(38,1))        as ODR_ITMS_AVG_SS       --平均每秒委托笔数
          , NVL(a4.WALL_ODR_ITMS,0)          as WALL_ODR_ITMS         --当日堵单笔数
          , NVL(a4.WALL_ODR_ITMS_MAX_SS,0)      as WALL_ODR_ITMS_MAX_SS     --秒峰值堵单笔数
          , NVL(a4.ODR_ITMS_SH_MAX_SS,0)        as ODR_ITMS_SH_MAX_SS       --秒峰值委托笔数(SH)
          , CAST(NVL(a4.ODR_ITMS_AVG_SH_SS,0)as DECIMAL(38,1))     as ODR_ITMS_AVG_SH_SS    --平均每秒委托笔数(SH)
          , NVL(a4.WALL_ODR_ITMS_SH,0)       as WALL_ODR_ITMS_SH      --当日堵单笔数(SH)
          , NVL(a4.WALL_ODR_ITMS_SH_6S,0)    as WALL_ODR_ITMS_SH_6S   --堵单时间超过6秒笔数（SH)
          , NVL(a4.WALL_ODR_ITMS_SH_MAX_SS,0)   as WALL_ODR_ITMS_SH_MAX_SS  --秒峰值堵单笔数(SH)
          , NVL(a4.ODR_ITMS_SZ_MAX_SS,0)        as ODR_ITMS_SZ_MAX_SS       --秒峰值委托笔数(SZ)
          , CAST(NVL(a4.ODR_ITMS_AVG_SZ_SS,0)as DECIMAL(38,1))     as ODR_ITMS_AVG_SZ_SS    --平均每秒委托笔数(SZ)
          , NVL(a4.WALL_ODR_ITMS_SZ,0)       as WALL_ODR_ITMS_SZ      --当日堵单笔数(SZ)
          , NVL(a4.WALL_ODR_ITMS_SZ_6S,0)    as WALL_ODR_ITMS_SZ_6S   --堵单时间超过6秒笔数（SZ)
          , NVL(a4.WALL_ODR_ITMS_SZ_MAX_SS,0)   as WALL_ODR_ITMS_SZ_MAX_SS  --秒峰值堵单笔数(SZ)
		  , NVL(a4.WALL_ODR_ITMS_6S,0)       as WALL_ODR_ITMS_6S      --堵单时间超过6秒笔数
          , NVL(a4.ODR_ITMS_FUNC,0)    as ODR_ITMS_FUNC        --委托笔数(性能)
		  , NVL(a4.ODR_ITMS_SH_FUNC,0) as ODR_ITMS_SH_FUNC     --委托笔数(SH)(性能)
		  , NVL(a4.ODR_ITMS_SZ_FUNC,0) as ODR_ITMS_SZ_FUNC     --委托笔数(SZ)(性能)
		  , NVL(a3.QLFD_CSUT_VOL,0)         --合格客户总数
          , NVL(a3.TEL_ODR_OPN_NUM,0)       --电话委托开通人数
          , NVL(a3.ONLINE_ODR_OPN_NUM,0)    --网上委托开通人数
          , NVL(a3.PHONE_ODR_OPN_NUM,0)     --手机委托开通人数
          , NVL(a3.UNSCE_ODR_OPN_NUM,0)     --非现场委托开通人数
          , NVL(a3.T3IP_DEPMGT_CUST_VOL,0)  --三方存管客户数
FROM (SELECT 1 as ID
             ,SUM(ODR_NUM_PHONE)        as  ODR_NUM_PHONE        
             ,SUM(ODR_NUM_TEL)          as  ODR_NUM_TEL    
             ,SUM(ODR_NUM_ONLN)         as  ODR_NUM_ONLN    
             ,SUM(ODR_NUM_UNSCE)        as  ODR_NUM_UNSCE   
             ,SUM(ODR_NUM)              as  ODR_NUM    
             ,SUM(ODR_ITMS_PHONE)       as  ODR_ITMS_PHONE  
			 ,SUM(ODR_ITMS_TEL)         as  ODR_ITMS_TEL    
             ,SUM(ODR_ITMS_ONLN)        as  ODR_ITMS_ONLN   
             ,SUM(ODR_ITMS_UNSCE)       as  ODR_ITMS_UNSCE  
             ,SUM(ODR_ITMS)             as  ODR_ITMS      
      FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP2
     )     a1
LEFT JOIN (SELECT 1 as ID
                 ,SUM(ODR_NUM_PHONE)  as  ODR_NUM_PHONE     
                 ,SUM(ODR_NUM_TEL)    as  ODR_NUM_TEL    
                 ,SUM(ODR_NUM_ONLN)   as  ODR_NUM_ONLN    
                 ,SUM(ODR_NUM_UNSCE)  as  ODR_NUM_UNSCE    
                 ,SUM(ODR_NUM)        as  ODR_NUM    
                 ,SUM(ODR_ITMS_PHONE) as  ODR_ITMS_PHONE    
			     ,SUM(ODR_ITMS_TEL)   as  ODR_ITMS_TEL    
                 ,SUM(ODR_ITMS_ONLN)  as  ODR_ITMS_ONLN    
                 ,SUM(ODR_ITMS_UNSCE) as  ODR_ITMS_UNSCE    
                 ,SUM(ODR_ITMS)       as  ODR_ITMS    
          FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP5
        )      a2
ON        a1.ID = a2.ID
LEFT JOIN (SELECT 1 as ID
                 ,SUM(QLFD_CSUT_VOL)          as QLFD_CSUT_VOL      
                 ,SUM(TEL_ODR_OPN_NUM)        as TEL_ODR_OPN_NUM
                 ,SUM(ONLINE_ODR_OPN_NUM)     as ONLINE_ODR_OPN_NUM
                 ,SUM(PHONE_ODR_OPN_NUM)      as PHONE_ODR_OPN_NUM
                 ,SUM(UNSCE_ODR_OPN_NUM)      as UNSCE_ODR_OPN_NUM
                 ,SUM(T3IP_DEPMGT_CUST_VOL)   as T3IP_DEPMGT_CUST_VOL     
          FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP8
		  WHERE SYS_SRC = 'GGQQ'
         )      a3
ON        a1.ID = a3.ID
LEFT JOIN (SELECT 1 as ID,* FROM DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP7 WHERE XTBS = 'GGQQ') a4
ON        a1.ID = a4.ID
 ;
---------------- 插入数据结束 -----------------------
----
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP1 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP2 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP3 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP4 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP5 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP6 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP7 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY_TEMP8 ;
-----
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_SYS_FUNC_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
INVALIDATE METADATA DDW_PROD.T_DDW_F20_BRH_SYS_FUNC_DAY;
 
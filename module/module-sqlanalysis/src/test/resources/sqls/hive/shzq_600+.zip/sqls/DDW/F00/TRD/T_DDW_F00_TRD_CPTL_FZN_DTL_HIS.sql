 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:资金冻结明细历史表                                                                   */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-12-02                                                                        */ 
  



--------------插入数据-------------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_TRD_CPTL_FZN_DTL_HIS
(
                                    EVNT_SEQNBR               --事件序号 
                                   ,BRH_NO                    --营业部编码
                                   ,BRH_NAME                  --营业部名称
                                   ,OCC_BRH_NO                --发生营业部
                                   ,DT                        --日期
                                   ,OCC_TM                    --发生时间
                                   ,CCY_CD                    --币种代码								   
                                   ,CUST_NO                   --客户号  
                                   ,CUST_NAME                 --客户姓名 
								   ,CNTR_CPTL_ACCNT           --柜台资金帐号
								   ,CPTL_FZN_CGY              --资金冻结类别
								   ,OCC_AMT                   --发生金额
                                   ,ABST                      --摘要   
                                   ,OPRT_TELR                 --操作柜员 
                                   ,RECHK_TELR                --复核柜员 
                                   ,OPRT_MOD                  --操作方式 
                                   ,SYS_SRC                   --账户类别                                 
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT                 t.SEQNO               as EVNT_SEQNBR               --事件序号 
                        ,t.YYB                as BRH_NO                    --营业部编码
                        ,NVL(a1.BRH_SHRTNM,a5.FILIL_DEPT_SHRTNM)     as BRH_NAME                  --营业部名称
                        ,t.FSYYB              as OCC_BRH_NO                --发生营业部
                        ,t.RQ                 as DT                        --日期
                        ,t.FSSJ               as OCC_TM                    --发生时间
                        ,t.BZDM               as CCY_CD                    --币种代码		
                        ,t.KHH                as CUST_NO                   --客户号  
                        ,t.KHXM               as CUST_NAME                 --客户姓名 
                        ,t.GTZJZH             as CNTR_CPTL_ACCNT           --柜台资金帐号
                        ,t.ZJDJLB             as CPTL_FZN_CGY              --资金冻结类别
                        ,t.FSJE               as OCC_AMT                   --发生金额
                        ,t.ZY                 as ABST                      --摘要   
                        ,a2.XM                as OPRT_TELR                 --操作柜员 
                        ,CASE WHEN t.FHGY IS NULL
                              THEN NULL
                              ELSE a3.XM
                              END            as RECHK_TELR                --复核柜员 
                        ,CASE WHEN a4.BRH_NO IS NOT NULL
                              THEN '临柜'
                              ELSE '其他'
							  END            as OPRT_MOD                  --操作方式 
                        ,DECODE(t.XTBS,'JZJY','普通账户','GGQQ','期权账户','RZRQ','信用账户')            as SYS_SRC                   --账户类别       
 FROM          EDW_PROD.T_EDW_T05_TZJDJMXLS              t                                 
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                a1
 ON            t.YYB = a1.BRH_NO
 AND           a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a5
 ON            t.YYB = a5.FILIL_DEPT_CDG
 AND           a5.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     EDW_PROD.T_EDW_T01_TGYXX                  a2
 ON            t.LOGINID = a2.LOGINID        
 AND           t.XTBS = a2.XTBS
 AND           a2.BUS_DATE = %d{yyyyMMdd} 
 LEFT JOIN     EDW_PROD.T_EDW_T01_TGYXX                  a3
 ON            t.FHGY = a3.LOGINID        
 AND           t.XTBS = a3.XTBS 
 AND           a3.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN    DDW_PROD.T_DDW_INR_ORG_BRH                a4
 ON            t.FSYYB = a4.BRH_NO
 AND           a4.BUS_DATE = %d{yyyyMMdd} 
 WHERE         t.bus_date = %d{yyyyMMdd}         
 ; 
  
 ------结束-----------------
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_TRD_CPTL_FZN_DTL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_F00_TRD_CPTL_FZN_DTL_HIS ;
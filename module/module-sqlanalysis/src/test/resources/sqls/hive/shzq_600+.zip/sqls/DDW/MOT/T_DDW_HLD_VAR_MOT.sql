--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:监控持仓变化                                                                      */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */


 
 
-------今天的持仓
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_HLD_VAR_MOT_TEMP_%d{yyyyMMdd};
 CREATE TABLE DDW_PROD.T_DDW_HLD_VAR_MOT_TEMP_%d{yyyyMMdd} as
 SELECT        CUST_NO
              ,EXG
			  ,SEC_CD
			  ,sec_qty as sec_qty
 FROM   DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS 
 WHERE  BUS_DATE = %d{yyyyMMdd}
 AND    CUST_NO < > '999999999999'
 AND    SUBSTR(SHRHLD_NO,1,2) < > 'C9' 
 UNION ALL
 SELECT        KHH                 as CUST_NO
              ,JYS                 as EXG
              ,ZQDM                as SEC_CD
			  ,0-(RQSL-HQSL)         as sec_qty
 FROM         EDW_PROD.T_EDW_T05_TXY_FZXXLS
 WHERE        BUS_DATE = %d{yyyyMMdd}
 AND          JYLB = 64;
 
 -----
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_HLD_VAR_MOT_TEMP1_%d{yyyyMMdd};
 CREATE TABLE DDW_PROD.T_DDW_HLD_VAR_MOT_TEMP1_%d{yyyyMMdd} as
 SELECT        CUST_NO
              ,EXG
			  ,SEC_CD
			  ,sec_qty as sec_qty
 FROM   DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS  a
 WHERE  EXISTS (SELECT 1 
			    FROM EDW_PROD.T_EDW_T99_TRD_DATE b
				WHERE b.BUS_DATE = %d{yyyyMMdd}
				AND   b.TRD_DT = %d{yyyyMMdd}
				AND   a.BUS_DATE = b.LST_TRD_D
				)
 AND    CUST_NO < > '999999999999'
 AND    SUBSTR(SHRHLD_NO,1,2) < > 'C9'
 UNION ALL
 SELECT        KHH                 as CUST_NO
              ,JYS                 as EXG
              ,ZQDM                as SEC_CD
			  ,0-(RQSL-HQSL)         as sec_qty
 FROM         EDW_PROD.T_EDW_T05_TXY_FZXXLS a
 WHERE  EXISTS (SELECT 1 
			    FROM EDW_PROD.T_EDW_T99_TRD_DATE b
				WHERE b.BUS_DATE = %d{yyyyMMdd}
				AND   b.TRD_DT = %d{yyyyMMdd}
				AND   a.BUS_DATE = b.LST_TRD_D
				)
 AND          JYLB = 64;
 
 
 ---------------------证券数量比较
  INSERT OVERWRITE DDW_PROD.T_DDW_HLD_VAR_MOT
 (
           CUST_NO             --客户号
          ,EXG                 --交易所
          ,CD                  --代码      
		  ,SRC_TABLE           --来源表
          ,HLD_UP_DAY          --上个交易日持仓
          ,HLD_DAY	           --今天持仓																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
 SELECT   NVL(t.CUST_NO,a1.CUST_NO)          as CUST_NO             --客户号
          ,NVL(t.EXG,a1.EXG)             
		  as EXG                 --交易所
		  ,NVL(t.SEC_CD,a1.SEC_CD)           as CD                  --代码
		  ,'T_DDW_F00_AST_SEC_HLD_DTL_HIS'  as SRC_TABLE           --来源表
		  ,NVL(a1.HLD_UP_DAY,0)              as HLD_UP_DAY          --上个交易日持仓
		  ,NVL(t.HLD_DAY,0)                  as HLD_DAY	           --今天持仓
 FROM (SELECT  CUST_NO
              ,EXG
			  ,SEC_CD
			  ,SUM(sec_qty) as HLD_DAY
       FROM   DDW_PROD.T_DDW_HLD_VAR_MOT_TEMP_%d{yyyyMMdd} 
	   GROUP BY CUST_NO,EXG,SEC_CD
		)        t
 FULL JOIN (SELECT  CUST_NO
                    ,EXG
			        ,SEC_CD
			        ,SUM(sec_qty) as HLD_UP_DAY
             FROM    DDW_PROD.T_DDW_HLD_VAR_MOT_TEMP1_%d{yyyyMMdd} a	        
           GROUP BY CUST_NO,EXG,SEC_CD   	
		   )            a1
 ON       t.CUST_NO = a1.CUST_NO
 AND      t.EXG = a1.EXG
 AND      t.SEC_CD = a1.SEC_CD
 LEFT JOIN (SELECT CUST_NO
                   ,EXG
				   ,SEC_CD
				   ,SUM(ADD_HLD) as ADD_HLD
           FROM 
           (SELECT  KHH    as CUST_NO
                   ,JYS    as EXG
				   ,ZQDM   as SEC_CD
				   ,CASE WHEN wtlb IN (1,42,57,59,61,63,16,5,80,83,3,1111,4444,6666,8888,9,15,78) OR (WTLB = 18 AND CJBH IN ('定期折算','基金上折','基金下折','红利份额','基金自身折算')) OR (WTLB = 30 AND SUBSTR(ZQLB,1,1) IN('A','C')) OR (WTLB = 29 AND SUBSTR(ZQLB,1,1) NOT IN('A','C'))
				         THEN 0-CJSL
						 WHEN WTLB IN (2,12,13,17,35,36,43,58,60,62,64,71,81,2222,5555,7777,9999,7,10,79) OR (WTLB = 19 AND CJBH IN ('定期折算','基金上折','基金下折','基金自身折算')) OR (WTLB = 29 AND SUBSTR(ZQLB,1,1) IN('A','C')) OR (WTLB = 30 AND SUBSTR(ZQLB,1,1) NOT IN('A','C'))
						 THEN CJSL
						 ELSE 0
						 END  as ADD_HLD
            FROM   EDW_PROD.T_EDW_T05_TJGMXLS_XZB_NEW
            WHERE    CAST((CASE WHEN JYS IN ('TU','HK','SK','HB','SB') AND WTLB IN (1,2)
				              THEN CJRQ
						      WHEN JYS IN ('SH','SZ') AND WTLB IN (42,43)
						      THEN JSRQ
						      ELSE BUS_DATE
						      END) as INT) = %d{yyyyMMdd}
			AND    KHH < > '999999999999'
			AND    SUBSTR(GDH,1,2) < > 'C9'
			UNION ALL
			SELECT  KHH  as CUST_NO
			       ,JYS  as EXG
				   ,ZQDM as SEC_CD
				   ,CASE WHEN wtlb IN (1,42) 
				         THEN 0-CJSL
						 WHEN WTLB IN (2,43)
						 THEN CJSL
						 ELSE 0
						 END as ADD_HLD				  
              FROM EDW_PROD.T_EDW_T05_TDJSQSZL
			  WHERE CJRQ = %d{yyyyMMdd}
			  AND   KHH < > '999999999999' 
			  AND   SUBSTR(GDH,1,2) < > 'C9'
			  AND   BUS_DATE = %d{yyyyMMdd}
			  AND   JSBZ_2 = 0
			  AND   JSRQ_2 > %d{yyyyMMdd}
			  AND   ((JYS IN ('TU','HK','SK','HB','SB')
			 AND WTLB IN (1,2)) OR (JYS IN ('SH','SZ')
			 AND WTLB IN (42,43)))
			)    t
			GROUP BY t.CUST_NO,t.EXG,t.SEC_CD
            )  a2
 ON    NVL(t.CUST_NO,a1.CUST_NO) = a2.CUST_NO
 AND   NVL(t.EXG,a1.EXG) = a2.EXG
 AND   NVL(t.SEC_CD,a1.SEC_CD) = a2.SEC_CD
 WHERE NVL(t.HLD_DAY,0)+NVL(a2.ADD_HLD,0) < > NVL(a1.HLD_UP_DAY,0)
 UNION ALL
 SELECT   NVL(t.CUST_NO,a1.CUST_NO)          as CUST_NO             --客户号
          ,NULL                              as EXG                 --交易所
		  ,NVL(t.PROD_CD,a1.PROD_CD)         as CD                  --代码
		  ,'T_DDW_F00_AST_PROD_HLD_DTL_HIS'  as SRC_TABLE           --来源表
		  ,NVL(a1.HLD_UP_DAY,0)              as HLD_UP_DAY          --上个交易日持仓
		  ,NVL(t.HLD_DAY,0)                  as HLD_DAY	           --今天持仓
 FROM (SELECT  CUST_NO
              ,PROD_CD
			  ,SUM(PROD_SHR_QTY) as HLD_DAY
       FROM   DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS
	   WHERE  BUS_DATE = %d{yyyyMMdd}
       GROUP BY CUST_NO,PROD_CD	   	
		)        t
 FULL JOIN (SELECT  CUST_NO
                   ,PROD_CD
			       ,SUM(PROD_SHR_QTY) as HLD_UP_DAY
            FROM   DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS a
	        WHERE  EXISTS (SELECT 1 
			               FROM EDW_PROD.T_EDW_T99_TRD_DATE b
						   WHERE b.BUS_DATE = %d{yyyyMMdd}
						   AND   b.TRD_DT = %d{yyyyMMdd}
						   AND   a.BUS_DATE = b.LST_TRD_D
						   )
           GROUP BY CUST_NO,PROD_CD	   	
		   )            a1
 ON       t.CUST_NO = a1.CUST_NO
 AND      t.PROD_CD = a1.PROD_CD
 LEFT JOIN (			
			SELECT  CUST_NO
                   ,PROD_CD
				   ,SUM(CASE WHEN PROD_BIZ_CD IN ('130','139','5555','6666','8888','122','143')
				         OR (PROD_BIZ_CD = '144'
   						     AND MTCH_NO IN ('定期折算','基金上折','基金自身折算','基金下折'))
				         THEN 0-CNFM_SHR
						 WHEN PROD_BIZ_CD IN ('124','142','7777','9999','150')
						 OR (PROD_BIZ_CD = '145'
   						     AND MTCH_NO IN ('定期折算','基金上折','基金自身折算','基金下折'))
						 THEN CNFM_SHR
						 ELSE 0
						 END) as ADD_HLD
            FROM   DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS
			WHERE  BUS_DATE = %d{yyyyMMdd}
			GROUP BY CUST_NO,PROD_CD 
            )  a2
 ON    NVL(t.CUST_NO,a1.CUST_NO) = a2.CUST_NO
 AND   NVL(t.PROD_CD,a1.PROD_CD) = a2.PROD_CD
 WHERE NVL(t.HLD_DAY,0)+NVL(a2.ADD_HLD,0) < > NVL(a1.HLD_UP_DAY,0)
 ;
 
 
 
 -----
 --删除临时表
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_HLD_VAR_MOT_TEMP_%d{yyyyMMdd};
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_HLD_VAR_MOT_TEMP1_%d{yyyyMMdd};
   
   

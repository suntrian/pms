 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360机构客户信息表                                                                      */
  --/* 创建人:程骏                                                                               */
  --/* 创建时间:2017-10-18                                                                        */ 
  
  /* T_DDW_F01_CUST_INFO	替换为	T_DDW_F00_CUST_CUST_INFO */
  /* T_DDW_F01_ORG_CUST_INFO	替换为	T_DDW_F00_CUST_ORG_CUST_INFO */
  
---------------- 插入集中交易数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_ORG_CUST_INFO
  (
	 CUST_NO					   --客户号              
	,CUST_NAME                     --姓名                
	,CTF_CGY                       --证件类别            
	,CTF_NO                        --证件号码            
	,CTF_EXPR_DT                   --证件截止日期        
	,BRH_NAME                      --所属营业部          
	,CUST_CGY                      --客户类别            
	,ORDI_ACCNT_ODR_MOD_SCP        --普通账户委托方式范围
	,CUST_STAT                     --客户状态            
	,OPNAC_DT                      --开户日期            
	,OPNAC_MOD                     --开户方式            
	,RSK_BEAR_ABLTY                --风险承受能力        
	,CUST_RSK_LVL                  --风险级别            
	,M_LAUND_RSK_LVL               --洗钱等级            
	,CTCT_TEL                      --联系电话            
	,PHONE                         --手机                
	,CTCT_ADDR                     --联系地址            
	,CTF_ADDR                      --证件地址            
	,CTRL_ATTR                     --控制属性            
	,CPTL_ATTR                     --资本属性            
	,STOWN_ATTR                    --国有属性            
	,LSTD_ATTR                     --上市属性            
	,LGLPSN_CGY                    --法人类别            
	,LGLPSN_BHAF_NAME              --法人代表姓名        
	,LGLPSN_CTF_NO                 --法人证件号码        
	,LGLPSN_CTF_EXPR_DT            --法人证件截止日期    
	,CUST_TP                       --客户类型            
                              
 ) PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT      t.CUST_NO                    as CUST_NO					   --客户号              
	        ,t.CUST_NAME                 as CUST_NAME                     --姓名                
	        ,a1.CTF_CGY_CD_NAME          as CTF_CGY                       --证件类别            
	        ,t.CTF_NO                    as CTF_NO                        --证件号码            
	        ,CAST(t.CTF_EXPR_DT AS DECIMAL(16,0))              as CTF_EXPR_DT                   --证件截止日期        
	        ,t.BRH_NAME                  as BRH_NAME                      --所属营业部          
	        ,a2.CUST_CGY_NAME            as CUST_CGY                      --客户类别            
	        ,T.ORDI_ODR_MOD_SCP    as ORDI_ACCNT_ODR_MOD_SCP        --普通账户委托方式范围
	        ,a3.CUST_STAT_NAME           as CUST_STAT                     --客户状态            
	        ,T.ORDI_OPNAC_DT                  as OPNAC_DT                      --开户日期            
	        ,a4.OPNAC_MOD_NAME           as OPNAC_MOD                     --开户方式            
	        ,a5.RSK_BEAR_ABLTY_NAME      as RSK_BEAR_ABLTY                --风险承受能力        
	        ,a6.NOTE                     as CUST_RSK_LVL                  --风险级别            
	        ,t.M_LAUND_RSK_LVL           as M_LAUND_RSK_LVL               --洗钱等级            
	        ,t.CTCT_TEL                  as CTCT_TEL                      --联系电话            
	        ,t.PHONE                     as PHONE                         --手机                
	        ,t.CTCT_ADDR                 as CTCT_ADDR                     --联系地址            
	        ,t.CTF_ADDR                  as CTF_ADDR                      --证件地址            
	        ,t.CTRL_ATTR                 as CTRL_ATTR                     --控制属性            
	        ,a8.CPTL_ATTR_CD_NAME        as CPTL_ATTR                     --资本属性            
	        ,a9.STOWN_ATTR_CD_NAME       as STOWN_ATTR                    --国有属性            
	        ,a10.LSTD_ATTR_CD_NAME       as LSTD_ATTR                     --上市属性            
	        ,a11.LGLPSN_CGY_CD_NAME      as LGLPSN_CGY                    --法人类别            
	        ,a7.LGLPSN_BHAF_NAME         as LGLPSN_BHAF_NAME              --法人代表姓名        
	        ,NULL                        as LGLPSN_CTF_NO                 --法人证件号码        
	        ,NULL                        as LGLPSN_CTF_EXPR_DT            --法人证件截止日期    
	        ,NULL                        as CUST_TP                       --客户类型            
 FROM          DDW_PROD.T_DDW_F00_CUST_CUST_INFO   t
 LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_ORG_CUST_INFO a7
 ON 		   t.CUST_NO = a7.CUST_NO 
 AND           t.BUS_DATE = a7.BUS_DATE
 LEFT JOIN     DDW_PROD.V_CTF_CGY_CD         a1
 ON            t.CTF_CGY_CD = a1.CTF_CGY_CD
 LEFT JOIN     DDW_PROD.V_CUST_CGY           a2
 ON            t.CUST_CGY = a2.CUST_CGY
 LEFT JOIN     DDW_PROD.V_CUST_STAT          a3 
 ON            T.ORDI_CUST_STAT =  a3.CUST_STAT
 LEFT JOIN     DDW_PROD.V_OPNAC_MOD          a4
 ON            t.OPNAC_MOD =  a4.OPNAC_MOD
 LEFT JOIN     DDW_PROD.V_RSK_BEAR_ABLTY     a5
 ON            t.RSK_BEAR_ABLTY = a5.RSK_BEAR_ABLTY
 LEFT JOIN     YGTCX.CIF_TXTDM                a6
 ON            t.CUST_RSK_LVL = CAST(a6.IBM as STRING)
 AND           a6.FLDM = 'GT_KHFXJB' 
 AND           t.bus_date = cast(a6.dt as int)
 LEFT JOIN     DDW_PROD.V_CPTL_ATTR_CD         a8
 ON            a7.CPTL_ATTR_CD = a8.CPTL_ATTR_CD
 LEFT JOIN     DDW_PROD.V_STOWN_ATTR_CD        a9
 ON            a7. stown_attr_cd = a9.stown_attr_cd		
 LEFT JOIN     DDW_PROD.V_LSTD_ATTR_CD         a10
 ON            a7.LSTD_ATTR_CD = a10.LSTD_ATTR_CD
 LEFT JOIN     DDW_PROD.V_LGLPSN_CGY_CD        a11
 ON            a7.LSTD_ATTR_CD = a11.LGLPSN_CGY_CD
 WHERE         t.CUST_CGY = '1' 
 AND           t.BUS_DATE = %d{yyyyMMdd}
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_ORG_CUST_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_ORG_CUST_INFO;
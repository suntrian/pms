------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:股东账户信息表                                                                       */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 



--------------插入数据-------------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO
(
                                     CUST_NO                                  --客户号       
                                    ,SHRHLD_NO                                --股东号       
                                    ,CUST_NAME                                --客户姓名      
                                    ,BRH_NO                                   --营业部编号     
                                    ,BRH_NAME                                 --营业部名称                              									
                                    ,SHRHLD_OPNAC_DT                          --股东开户日期    
                                    ,CTF_CGY_CD                               --证件类别代码    
                                    ,CTF_NO                                   --证件编号                                                                                  
                                    ,IMAGE_TP                                 --影像类型                               
                                    ,EXG                                      --交易所                                              
                                    ,CCY_CD                                   --币种代码      
                                    ,SHRHLD_NAME                              --股东名称      
                                    ,SHRHLD_STAT                              --股东状态      
                                    ,SHRHLD_ACCNT_CGY                         --股东账户类别    
                                    ,SHRHLD_CGY                               --股东类别      
                                    ,SHRHLD_ACCNT_RPT_LVL_CD                  --股东帐户申报级别代码
                                    ,CNCLACT_DT                               --销户日期      
                                    ,FSTTM_TRD_DT                             --首次交易日期    
                                    ,SHRHLD_MAIN_ACCNT_FLG                    --股东主账户标志   
                                    ,SHRHLD_ASGN_ATTR                         --股东指定属性    
                                    ,SHRHLD_CTRL_ATTR                         --股东控制属性    
                                    ,SHRHLD_ASGN_SEAT                         --股东指定席位    
                                    ,RPT_SHRHLD_NO                            --报盘股东号     
                                    ,USE_INFO_FLG                             --使用信息标志    
                                    ,BIZ_SYS                                  --业务系统      
                                    ,BIZ_ACTNO                                --业务账号      
                                    ,CUST_GROUP                               --客户群组      
                                    ,TRD_CPT_SETL_TP                          --交易资金结算类型  
                                    ,SETL_ORG                                 --结算机构      
                                    ,SETL_ACCNT                               --结算帐户      
                                    ,ACCNT_MGMT_ORG                           --帐户管理机构    
                                    ,TRD_SCP                                  --交易范围      
                                    ,SVC_PRJ                                  --服务项目      
                                    ,ACCNT_MKTVAL                             --帐户市值      
                                    ,THS_CO_FSTTM_TRD_DT                      --本公司的首次交易日期
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT                            
                                   t.KHH                                                        as CUST_NO                                   --客户号                                                                 
                                   ,t.GDH                                                        as SHRHLD_NO                                --股东号                                                                  
                                   ,a1.KHXM                                                      as CUST_NAME                                --客户姓名                                                                 
                                   ,t.YYB                                                        as BRH_NO                                   --营业部编号                                                                                                     
                                   ,NVL(a2.BRH_SHRTNM,a4.FILIL_DEPT_SHRTNM)                                                      as BRH_NAME                                 --营业部名称                                  								   
                                   ,t.KHRQ                                                       as SHRHLD_OPNAC_DT                          --股东开户日期                                                               
                                   ,t.ZJLBDM                                                     as CTF_CGY_CD                               --证件类别代码                                                               
                                   ,t.ZJBH                                                       as CTF_NO                                   --证件编号                                                                                                                                
                                   ,CASE WHEN a3.YWXTKHH IS NOT NULL
       								     THEN '有'
										 ELSE '无'
										 END                                                     as IMAGE_TP                                 --影像类型                                                                                                                               
                                   ,t.JYS                                                        as EXG                                      --交易所                                                                                                                                                                                                                           
                                   ,t.BZDM                                                       as CCY_CD                                   --币种代码                                                                 
                                   ,t.GDMC                                                       as SHRHLD_NAME                              --股东名称                                                                 
                                   ,t.GDZT                                                       as SHRHLD_STAT                              --股东状态                                                     
                                   ,t.GDZHLB                             					     as SHRHLD_ACCNT_CGY                         --股东账户类别                                            
                                   ,t.GDLB                                                       as SHRHLD_CGY                               --股东类别                                                              
                                   ,t.GDSBJBDM                                                   as SHRHLD_ACCNT_RPT_LVL_CD                  --股东帐户申报级别代码                
                                   ,t.XHRQ                                                       as CNCLACT_DT                               --销户日期                      
                                   ,t.SCJYRQ                                                     as FSTTM_TRD_DT                             --首次交易日期                    
                                   ,CAST(t.GDZZHBZ AS DECIMAL(38,0))                             as SHRHLD_MAIN_ACCNT_FLG                    --股东主账户标志                   
                                   ,t.GDZDSX                                                     as SHRHLD_ASGN_ATTR                         --股东指定属性                    
                                   ,t.GDKZSX                                                     as SHRHLD_CTRL_ATTR                         --股东控制属性                    
                                   ,t.GDZDXW                                                     as SHRHLD_ASGN_SEAT                         --股东指定席位                    
                                   ,t.BPGDH                                                      as RPT_SHRHLD_NO                            --报盘股东号                     
                                   ,t.SYXXBZ                                                     as USE_INFO_FLG                             --使用信息标志                    
                                   ,t.YWXT                                                       as BIZ_SYS                                  --业务系统                      
                                   ,t.YWZH                                                       as BIZ_ACTNO                                --业务账号                      
                                   ,t.KHQZ                                                       as CUST_GROUP                               --客户群组                      
                                   ,t.ZJJSLX                                                     as TRD_CPT_SETL_TP                          --交易资金结算类型                  
                                   ,t.JSJG                                                       as SETL_ORG                                 --结算机构                      
                                   ,t.JSZH                                                       as SETL_ACCNT                               --结算帐户                      
                                   ,t.ZHGLJG                                                     as ACCNT_MGMT_ORG                           --帐户管理机构                    
                                   ,t.JYFW                                                       as TRD_SCP                                  --交易范围                      
                                   ,t.FWXM                                                       as SVC_PRJ                                  --服务项目                      
                                   ,t.ZHSZ                                                       as ACCNT_MKTVAL                             --帐户市值                      
                                   ,CAST(t.BGSSCJYRQ AS DECIMAL(38,0))                           as THS_CO_FSTTM_TRD_DT                      --本公司的首次交易日期                                                           
																							 
  FROM          EDW_PROD.T_EDW_T02_TGDH                                 t
  LEFT JOIN     EDW_PROD.T_EDW_T01_TKHXX                                a1
  ON            t.KHH = a1.KHH
  AND           t.BUS_DATE = a1.BUS_DATE
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH    a2
 ON             t.YYB = a2.BRH_NO   
 AND           a2.BUS_DATE = %d{yyyyMMdd} 
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a4
 ON            t.YYB = a4.FILIL_DEPT_CDG
 AND           a4.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN    (
                SELECT  YWXTKHH,DT
                FROM YGTCX.EIMAGE_TDA_KHJBDA 
				WHERE YXLX IN (9,10) 
                AND   DT = '%d{yyyyMMdd}' 
                GROUP BY YWXTKHH,DT
			   )                                                        a3 
  ON           t.KHH = a3.YWXTKHH
  AND          t.BUS_DATE = CAST(a3.DT as INT)
  WHERE        t.BUS_DATE = %d{yyyyMMdd} 
  ;
		
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_SHRHLD_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

 invalidate metadata DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO ;

------------------结束所有程序---------------



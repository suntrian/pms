 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:转融通资格证券                                                                     */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZRT_ZGZQ; 
--------插入数据开始-----
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZRT_ZGZQ
(
                                    JYS                                 --交易所                                
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZSL                                 --折算率                                
                                   ,ZRT_TJBZ                            --转融通标的券提交标志                         
                                   ,JYRQ                                --交易日期                               
                                   ,XGRQ                                --修改日期 
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.ZSL                                 as ZSL                                 --折算率                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.TJBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZRT_TJBZ                            --提交标志                                
                                   ,t.JYRQ                                as JYRQ                                --交易日期                                
                                   ,t.XGRQ                                as XGRQ                                --修改日期   
                                   ,'RZRQ'                                as XTBS								   
 FROM           RZRQCX.ZRT_TZRT_ZGZQ                        t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING      t1 
 ON             t1.DMLX = 'ZRT_TJBZ'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.TJBZ AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---------插入数据结束----------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZRT_ZGZQ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

invalidate metadata EDW_PROD.T_EDW_T02_TZRT_ZGZQ;
-- /* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:季度持有1000万以上证券市值个人客户统计报表                                          */
 -- /* 创建人:OYJ                                                                                   */
  --/* 创建时间:2019-08-27                                                                          */  

------插入数据
----临时表,日期处理，取每个季度末的交易日等信息
DROP TABLE IF EXISTS DDW_PROD.TRD_DATE_TEMP;
CREATE TABLE DDW_PROD.TRD_DATE_TEMP
AS
 SELECT
  NAT_DT
 ,TRD_DT
 ,YR
 ,QUA
 ,CASE WHEN QUA = 1 THEN CONCAT(CAST(YR AS STRING),'0101')
       WHEN QUA = 2 THEN CONCAT(CAST(YR AS STRING),'0401')
       WHEN QUA = 3 THEN CONCAT(CAST(YR AS STRING),'0701')
       WHEN QUA = 4 THEN CONCAT(CAST(YR AS STRING),'1001')
  END AS QUA_STAR_DT
 ,CASE WHEN QUA = 1 THEN CONCAT(CAST(YR AS STRING),'0331')
       WHEN QUA = 2 THEN CONCAT(CAST(YR AS STRING),'0630')
       WHEN QUA = 3 THEN CONCAT(CAST(YR AS STRING),'0930')
       WHEN QUA = 4 THEN CONCAT(CAST(YR AS STRING),'1231')
  END AS QUA_END_DT
 FROM EDW_PROD.T_EDW_T99_TRD_DATE
 WHERE SUBSTR(NVL(CAST(NAT_DT AS STRING),''),5,4) IN ('0331','0630','0930','1231')
 AND TRD_DT = %d{yyyyMMdd}
;

----插入当日数据，如不是季度末则无数据
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_IDV_CUST_SEC_MKTVAL_QUA_STATS
(
        BRH_NO                     -- 1. 营业部编号
       ,BRH_NAME                   -- 2. 营业部名称
       ,CUST_NO                    -- 3. 客户号
       ,CUST_NAME                  -- 4. 客户名称
       ,OPN_DT                     -- 5. 开户日期
       ,PHONE_NO                   -- 6. 手机号
       ,RSK_LVL                    -- 7. 风险级别
       ,CUST_CGY                   -- 8. 客户类别
       ,ORDI_MKTVAL_SEC_RMD        -- 9. 证券市值
       ,YR                         --10. 年份
       ,QUA                        --11. 季度
       ,NAT_DT                     --12. 自然日
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT
 T1.YYB AS BRH_NO
,NVL(T5.BRH_FULLNM,'') AS BRH_NAME
,T1.KHH AS CUST_NO
,T1.KHMC AS CUST_NAME
,T1.KHRQ AS OPN_DT
,T1.SJ AS PHONE_NO
,CASE WHEN T4.SXZ = '0' THEN '合格帐户'
      WHEN T4.SXZ = '1' THEN '资料合规个人'
      WHEN T4.SXZ = '2' THEN '资料合规机构'
      WHEN T4.SXZ = '8' THEN '一般资料不合格'
      WHEN T4.SXZ = '19' THEN '纯B股帐户'
 END AS RSK_LVL
,CASE WHEN T1.KHLB = 0 THEN '个人' WHEN T1.KHLB = 1 THEN '机构' END AS CUST_CGY
,MAX(T3.ORDI_MKTVAL_SEC_RMD) AS ORDI_MKTVAL_SEC_RMD
,T2.YR AS YR
,T2.QUA AS QUA
,T2.NAT_DT AS NAT_DT
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.TRD_DATE_TEMP T2
ON T1.DT = CAST (T2.TRD_DT AS STRING)
INNER JOIN 
(
 SELECT CUST_NO,SUM(ORDI_MKTVAL_SEC_RMD) AS ORDI_MKTVAL_SEC_RMD,BUS_DATE
   FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
 WHERE BUS_DATE > CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'0101') AS INT)
 AND ORDI_MKTVAL_SEC_RMD >= 10000000
 GROUP BY CUST_NO,BUS_DATE
) T3
ON T1.KHH = T3.CUST_NO
AND T3.BUS_DATE >= CAST(T2.QUA_STAR_DT AS INT)
AND T3.BUS_DATE <= CAST(T2.QUA_END_DT AS INT)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
LEFT JOIN DDW_PROD.T_DDW_INR_ORG_BRH T5
ON T5.BRH_NO = CAST(T1.YYB AS STRING)
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
GROUP BY 1,2,3,4,5,6,7,8,10,11,12
;

-------插入数据结束

DROP TABLE IF EXISTS DDW_PROD.TRD_DATE_TEMP;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_IDV_CUST_SEC_MKTVAL_QUA_STATS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

INVALIDATE METADATA DDW_PROD.T_DDW_PRT_IDV_CUST_SEC_MKTVAL_QUA_STATS;

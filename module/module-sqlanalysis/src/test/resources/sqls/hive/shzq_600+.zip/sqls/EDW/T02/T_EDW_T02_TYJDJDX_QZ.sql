 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:佣金定价对象群组表                                                                */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                       */

TRUNCATE TABLE EDW_PROD.T_EDW_T02_TYJDJDX_QZ; 
----------插入数据开始----------------
---------插入集中交易数据
INSERT  INTO EDW_PROD.T_EDW_T02_TYJDJDX_QZ
(
                                     YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,SHBZ                                --审核标志                               
                                   ,FID                                 --佣金策略编号                             
                                   ,YJDJFS                              --佣金策略类别                             
                                   ,DJRQ                                --登记日期                               
                                   ,JSRQ                                --结算日期                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.SHBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as SHBZ                                --审核标志                                
                                   ,t.FID                                 as FID                                 --ID号                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.YJDJFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as YJDJFS                              --佣金定价方式                              
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.JSRQ                                as JSRQ                                --结算日期                                
                                   ,'JZJY'                               as XTBS                                --                                    
 FROM           JZJYCX.SECURITIES_TYJDJDX_QZ           t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'YJDJFS'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.YJDJFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'SHBZ'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.SHBZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING     t3
 ON             t3.YXT = 'JZJY'
 AND            t3.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';		

-------插入融资融券的数据
INSERT  INTO EDW_PROD.T_EDW_T02_TYJDJDX_QZ
(
                                     YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,SHBZ                                --审核标志                               
                                   ,FID                                 --佣金策略编号                             
                                   ,YJDJFS                              --佣金策略类别                             
                                   ,DJRQ                                --登记日期                               
                                   ,JSRQ                                --结算日期                               
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CAST(COALESCE(t3.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.SHBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as SHBZ                                --审核标志                                
                                   ,t.FID                                 as FID                                 --ID号                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.YJDJFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as YJDJFS                              --佣金定价方式                              
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.JSRQ                                as JSRQ                                --结算日期                                
                                   ,'RZRQ'                               as XTBS                                --                                    
 FROM           RZRQCX.SECURITIES_TYJDJDX_QZ           t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'YJDJFS'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.YJDJFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'SHBZ'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.SHBZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING     t3
 ON             t3.YXT = 'RZRQ'
 AND            t3.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';	
----------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TYJDJDX_QZ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TYJDJDX_QZ;
 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:两网退市表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-04-23                                                                        */ 
 

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_TWO_NET_DLSTG
(
								    BRH_NO                            --营业部编号  
                                   ,BRH_NAME                          --营业部名称  
                                   ,OPN_DT                            --开户日期
								   ,CUST_NO                           --客户号 
								   ,CUST_NAME                         --客户姓名    
								   ,CTF_NO                           --证件号码    	
								   ,RSK_BEAR_ABLTY                   --风险承受能力
                                   ,OPRT_MOD                         --操作方式								   
)		
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
								 t.BRH_NO			  		 AS BRH_NO                            --营业部编号  
								,t.BRH_NAME                  AS BRH_NAME                          --营业部名称  
								,t.APL_DT                    AS OPN_DT                            --开户日期
								,t.CUST_NO                   AS CUST_NO                           --客户号 
								,a1.CUST_NAME                AS CUST_NAME                         --客户姓名    
								,t.CTF_NO                    AS CTF_NO                           --证件号码    	
								,b3.RSK_BEAR_ABLTY_NAME      AS RSK_BEAR_ABLTY                   --风险承受能力	
								,t.OPRT_MOD                  AS OPRT_MOD                         --操作方式
  FROM  		DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_RQM_HIS 	t
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a1
  ON            t.CUST_NO = a1.CUST_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_RSK_BEAR_ABLTY                    b3
  ON            a1.RSK_BEAR_ABLTY = b3.RSK_BEAR_ABLTY       
  WHERE 		t.bus_date = %d{yyyyMMdd}
  AND           t.BIZ_CD IN ('20247') 
  AND           t.OPRT_MOD IN ('临柜','掌厅')
  ;

 
-----------------------------加载结束--------------------
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_TWO_NET_DLSTG',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_TWO_NET_DLSTG; 
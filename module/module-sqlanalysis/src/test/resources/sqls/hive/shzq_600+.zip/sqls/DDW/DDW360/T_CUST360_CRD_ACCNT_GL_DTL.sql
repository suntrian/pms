 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360信用账户负债明细表                                                          */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-10-27                                                                       */ 
  


---------------- 插入数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_CRD_ACCNT_GL_DTL
 (
	 CUST_NO                       --客户号   
	,CUST_NAME                     --客户姓名 
	,TRD_CGY                       --交易类别
	,EXG                           --交易所
	,SHRHLD_NO                     --股东号
	,SEC_CD                        --证券代码
	,SEC_NAME                      --证券名称
	,SEC_CGY                       --证券类别
	,MRGNS_QTY                     --融券数量
	,MRGNS_AMT                     --融券金额
	,GL_PRINP                      --负债本金
	,RTN_TCK                       --还券数量
	,RTN_TCK_AMT                   --还券金额
	,RTN_MNY_AMT                   --还款本金
	,INT_TOT                       --利息总计
	,RTN_INT                       --归还利息 
 )PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT      t.KHH                               as CUST_NO                       --客户号          
            ,t.KHXM                              as CUST_NAME                     --客户姓名   
            ,DECODE(t.JYLB,61,'融资',64,'融券')  as TRD_CGY                       --交易类别
            ,a1.EXG_NAME                         as EXG                           --交易所
            ,t.GDH                               as SHRHLD_NO                     --股东号
            ,t.ZQDM                              as SEC_CD                        --证券代码
            ,t.ZQMC                              as SEC_NAME                      --证券名称
            ,a3.ZQLBMC                           as SEC_CGY                       --证券类别
            ,t.RQSL                              as MRGNS_QTY                     --融券数量
            ,t.RQJE                              as MRGNS_AMT                     --融券金额
            ,t.FZBJ                              as GL_PRINP                      --负债本金
            ,t.HQSL                              as RTN_TCK                       --还券数量
            ,NVL(ROUND((a5.NEWST_PRC+a5.NEWST_INT*a5.NETPRC_TRD_FLG)*a5.TRD_UNIT*t.HQSL,2),0)                          as RTN_TCK_AMT                   --还券金额
            ,t.HKJE-GHLX                         as RTN_MNY_AMT                   --还款本金
            ,t.YJLX+t.FDLX+t.FXYJLX              as INT_TOT                       --利息总计
            ,t.GHLX                              as RTN_INT                       --归还利息  
 FROM         EDW_PROD.T_EDW_T05_TXY_FZXXLS         t
 LEFT JOIN    DDW_PROD.V_EXG                       a1
 ON           t.JYS = a1.EXG
 LEFT JOIN    EDW_PROD.T_EDW_T99_TZQLB             a3
 ON           t.ZQLB = a3.ZQLB 
 AND          a3.XTBS = 'JZJY' 
 AND          t.bus_date = a3.BUS_DATE
 LEFT JOIN    DDW_PROD.T_DDW_PUB_QOT               a5
 ON           t.JYS = a5.EXG
 AND          t.ZQDM = a5.CD
 AND          a5.trd_mkt = 1
 AND          t.bus_date = a5.BUS_DATE   
 WHERE        t.BUS_DATE = %d{yyyyMMdd}
 
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_CRD_ACCNT_GL_DTL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_CRD_ACCNT_GL_DTL; 
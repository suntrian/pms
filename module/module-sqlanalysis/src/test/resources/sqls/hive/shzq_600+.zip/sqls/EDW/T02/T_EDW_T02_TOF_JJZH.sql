 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:基金账户表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
    TRUNCATE TABLE EDW_PROD.T_EDW_T02_TOF_JJZH;    
-------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TOF_JJZH
(
                                    KHH                                 --客户号                                
                                   ,TADM                                --TA代码                               
                                   ,JJZH                                --基金帐号                               
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,JSZH                                --结算帐号                               
                                   ,BZDM                                --币种代码                               
                                   ,KHRQ                                --开户日期                               
                                   ,JYMM                                --交易密码                               
                                   ,DZDLB                               --对帐单类别                              
                                   ,OF_FHFS                             --基金分红方式                             
                                   ,OF_ZHSX                             --基金帐户控制属性                           
                                   ,OF_JJZHZT                           --基金基金帐户状态                           
                                   ,OF_ZHLB                             --基金账户类别                             
                                   ,KHXM                                --基金帐户姓名                             
                                   ,OF_GRZJLB                           --基金个人证件类别                           
                                   ,ZJBH                                --基金帐户证件编号                           
                                   ,ZHDJRQ                              --基金帐户冻结日期                           
                                   ,JBRXM                               --经办人姓名                              
                                   ,JBR_OF_GRZJLB                       --经办人基金证件类别                          
                                   ,JBRZJBH                             --经办人证件编号                            
                                   ,FRXM                                --法人姓名                               
                                   ,FR_OF_GRZJLB                        --法人基金证件类别                           
                                   ,FRZJBH                              --法人证件编号                             
                                   ,JYZH                                --交易帐号                               
                                   ,YZBM                                --邮政编码                               
                                   ,DZ                                  --地址                                 
                                   ,DH                                  --电话                                 
                                   ,CZ                                  --传真                                 
                                   ,JJZHKPZH                            --基金帐户卡凭证号                           
                                   ,JJZHKDYBZ                           --基金帐户卡打印标志                          
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,BDKHBZ                              --本机构开户标志                            
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,GDH                                 --对应股东帐号                             
                                   ,ZCFZ                                --资产分组   
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.TADM                                as TADM                                --TA代码                                
                                   ,t.JJZH                                as JJZH                                --基金帐号                                
                                   ,t.JSLX                                as ZJJSLX                              --结算类型                                
                                   ,t.JSJG                                as JSJG                                --结算机构                                
                                   ,t.JSZH                                as JSZH                                --结算帐号                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.KHRQ                                as KHRQ                                --开户日期                                
                                   ,t.JYMM                                as JYMM                                --交易密码                                
                                   ,t.DZDLB                               as DZDLB                               --对帐单类别                               
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.FHFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as OF_FHFS                             --分红方式                                
                                   ,t.ZHSX                                as OF_ZHSX                             --基金帐户属性                              
                                   ,t.ZHZT                                as OF_JJZHZT                           --基金帐户状态                              
                                   ,t.ZHLB                                as OF_ZHLB                             --基金帐户类别                              
                                   ,t.KHXM                                as KHXM                                --基金帐户姓名                              
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as OF_GRZJLB                           --基金帐户证件类别                            
                                   ,t.ZJBH                                as ZJBH                                --基金帐户证件编号                            
                                   ,t.ZHDJRQ                              as ZHDJRQ                              --基金帐户冻结日期                            
                                   ,t.JBRXM                               as JBRXM                               --经办人姓名                               
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JBRZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as JBR_OF_GRZJLB                       --经办人证件类别                             
                                   ,t.JBRZJBH                             as JBRZJBH                             --经办人证件编号                             
                                   ,t.FRXM                                as FRXM                                --法人姓名                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.FRZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as FR_OF_GRZJLB                        --法人证件类别                              
                                   ,t.FRZJBH                              as FRZJBH                              --法人证件编号                              
                                   ,t.JYZH                                as JYZH                                --交易帐号                                
                                   ,t.YZBM                                as YZBM                                --邮政编码                                
                                   ,t.DZ                                  as DZ                                  --地址                                  
                                   ,t.DH                                  as DH                                  --电话                                  
                                   ,t.CZ                                  as CZ                                  --传真                                  
                                   ,t.JJZHKPZH                            as JJZHKPZH                            --基金帐户卡凭证号                            
                                   ,t.JJZHKDYBZ                           as JJZHKDYBZ                           --基金帐户卡打印标志                           
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.BDKHBZ                              as BDKHBZ                              --本机构开户标志                             
                                   ,CAST(COALESCE(t6.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.GDH                                 as GDH                                 --对应股东帐号                              
                                   ,t.ZCFZ                                as ZCFZ                                --资产分组     
                                   ,'JZJY'	                              as XTBS							   
 FROM           JZJYCX.DATACENTER_TOF_JJZH             t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'OF_FHFS'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.FHFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'OF_GRZJLB'
 AND            t3.YXT = 'JZJY'
 AND            t3.YDM = CAST(t.ZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
 ON             t4.DMLX = 'OF_GRZJLB'
 AND            t4.YXT = 'JZJY'
 AND            t4.YDM = CAST(t.JBRZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t5 
 ON             t5.DMLX = 'OF_GRZJLB'
 AND            t5.YXT = 'JZJY'
 AND            t5.YDM = CAST(t.FRZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t6
 ON             t6.YXT = 'JZJY'
 AND            t6.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
-------插入数据结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TOF_JJZH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

  invalidate metadata EDW_PROD.T_EDW_T02_TOF_JJZH;
 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:创业板5天开通信息表                                                                       */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30               */ 

  
  
  TRUNCATE TABLE DDW_PROD.T_DDW_PRT_GEM_5_DAYS_OPN_INFO;  
--删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_GEM_5_DAYS_OPN_INFO_TEMP;
CREATE TABLE DDW_PROD.T_DDW_PRT_GEM_5_DAYS_OPN_INFO_TEMP
 as
 SELECT  SUM(TRD_VOL_GEM) AS GEM_MTCH_AMT
        ,SUM(S1_INCM_GEM) AS GEM_CMSN
		,CUST_NO 
 FROM   DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
 WHERE (BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}) 
 GROUP BY CUST_NO
 ;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_GEM_5_DAYS_OPN_INFO_TEMP1;
CREATE TABLE DDW_PROD.T_DDW_PRT_GEM_5_DAYS_OPN_INFO_TEMP1
AS 
SELECT 
                                    t.SQRQ                  as APL_DT                              --申请日期                                                
                                   ,t.SQSJ                  as APL_TM                              --申请时间                                                
                                   ,t.KHH                   as CUST_NO                             --客户号                                                 
                                   ,t.KHMC                  as CUST_NAME                           --客户姓名                                                                                     
                                   ,t.YYB                   as BRH_NO                              --营业部编号                                               
                                   ,NVL(a4.BRH_SHRTNM,a5.filil_dept_shrtnm)                 as BRH_NAME                            --营业部名称                                               
                                   ,CAST(NVL(CAST(a1.OCC_BRH_NO as DECIMAL(12,0)),a2.ORGID) AS STRING) as OCC_BRH_NO                          --发生营业部                                               
                                   ,t.ZJLBDM                as CTF_CGY_CD                          --证件类别代码                                              
                                   ,t.ZJBH                  as CTF_NO                              --证件编号                                                
                                   ,t.JYQX                  as TRD__PRVL                           --交易权限                                                
                                   ,t.SQGY                  as APL_TELR                            --申请柜员 
                                   ,t.SQYY                  as APL_RSN	                           --申请原因								   
                                   ,t.SBRQ                  as RPT_DT                              --申报日期                                                
                                   ,t.HBJG                  as PBAK_RSLT                           --回报结果                                                
                                   ,t.YWXT                  as BIZ_SYS                             --业务系统                                                
                                   ,t.YWZH                  as BIZ_ACTNO                           --业务账号                                                
                                   ,t.KHZC                  as CUST_AST                            --客户资产   
                                   ,CASE WHEN t.sqgy=9057
                                         THEN '掌厅'
										 WHEN a3.BRH_SHRTNM IS NOT NULL
                                         THEN '临柜'
                                         ELSE '其他'									 
                                         END	            as OPRT_MOD	                            --操作方式									 
                                  ,t.BUS_DATE        
  FROM          EDW_PROD.T_EDW_T02_TJYQXSQ                t
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CIF_SRC_BIZ_RQM_HIS                  a1
  ON            t.YWQQID = a1.BIZ_RQM_ID
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                a4
  ON            t.YYB = a4.BRH_NO
  AND           a4.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT                 a5
  ON            t.YYB = a5.FILIL_DEPT_CDG
  AND           a5.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     EDW_PROD.T_EDW_T02_TUSER                  a2
  ON            t.SQGY = a2.TUSER_ID
  AND           a2.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                     a3
  ON            CAST(a2.ORGID AS STRING) = a3.BRH_NO   
  AND           a3.BUS_DATE = %d{yyyyMMdd}
  WHERE         t.BUS_DATE = %d{yyyyMMdd} ;

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_GEM_5_DAYS_OPN_INFO
(
				BRH_NO	                     --营业部编号
               ,BRH_NAME	                 --营业部名称
               ,HAND_BRH_NO  	             --办理营业部
               ,APL_DT	                     --申请日期
               ,OPN_MOD	                     --开通方式
               ,CUST_NO	                     --客户号
               ,CUST_NAME    	             --客户姓名
               ,RSK_BEAR_ABLTY 	             --风险承受能力
               ,CTCT_PSN_NAME	             --联系人姓名
               ,GEM_MTCH_AMT	             --创业板成交量
               ,GEM_CMSN	                 --创业板佣金
               ,ABST	                     --摘要
			   ,CL                           --分类
			   ,PRVL_OPN_DT_AGE              --权限开通日期年龄
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
						 t.BRH_NO           		AS  BRH_NO	                     --营业部编号       
						,t.BRH_NAME         		AS  BRH_NAME	                 --营业部名称       
						,t.OCC_BRH_NO       		AS  HAND_BRH_NO  	             --办理营业部       
						,t.APL_DT           		AS  APL_DT	                     --申请日期        
						,t.OPRT_MOD         		AS  OPN_MOD	                     --开通方式        
						,t.CUST_NO          		AS  CUST_NO	                     --客户号         
						,t.CUST_NAME        		AS  CUST_NAME    	             --客户姓名        
						,b1.RSK_BEAR_ABLTY_NAME   	AS  RSK_BEAR_ABLTY 	             --风险承受能力      
						,a2.CTCT_PSN_NAME           AS  CTCT_PSN_NAME	             --联系人姓名       
						,NVL(a5.GEM_MTCH_AMT,0)    		AS  GEM_MTCH_AMT	             --创业板成交量      
						,NVL(a5.GEM_CMSN,0)	    	    AS  GEM_CMSN	                 --创业板佣金       
					    ,a1.ABST                    AS  ABST	                     --摘要  
                        ,CASE WHEN t.APL_RSN = '5' AND a2.RSK_BEAR_ABLTY = '1'
						      THEN '五天_保守'
							  WHEN t.APL_RSN = '5' AND a2.RSK_BEAR_ABLTY <> '1'
							  THEN '五天'
							  ELSE '保守'
							  END                   AS CL                           --分类
						,CAST(CASE WHEN NVL(a2.BRTH_YM,99999999) <>99999999 
							  THEN ROUND(EDW_PROD.G_DATE_COMPARE_DATE(CAST(t.APL_DT AS STRING),'yyyyMMdd',CAST(a2.BRTH_YM AS STRING),'yyyyMMdd')/365,0)
							  ELSE NULL 
							  END AS DECIMAL(38,0)) 		            AS PRVL_OPN_DT_AGE               --权限开通日期年龄				
  FROM  		    DDW_PROD.T_DDW_PRT_GEM_5_DAYS_OPN_INFO_TEMP1              	t
  LEFT JOIN     (SELECT CUST_NO,MAX(ABST) AS ABST,DT 
                 FROM   DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS 
                 WHERE  BIZ_SBJ IN ('21251','20251')
                 AND    ABST LIKE  '%创业板%'
                 AND    (ABST like '%即%' or ABST like '%两%')
                 GROUP BY CUST_NO,DT) 	    	            		a1
  ON            t.CUST_NO = a1.CUST_NO 		
  AND           t.APL_DT = a1.DT		
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO              			a2
  ON            t.CUST_NO = a2.CUST_NO 		
  AND           a2.bus_date  = 	%d{yyyyMMdd}	
 
  LEFT JOIN     (SELECT DISTINCT KHH FROM EDW_PROD.T_EDW_T99_TKHSDX WHERE CPDJ = 1 AND SDXLBDM = 'JJFXCSNL' AND BUS_DATE = %d{yyyyMMdd}) a4
  ON            t.CUST_NO = a4.KHH  
  LEFT JOIN     DDW_PROD.T_DDW_PRT_GEM_5_DAYS_OPN_INFO_TEMP			a5
  ON			t.CUST_NO = a5.CUST_NO
  LEFT JOIN     DDW_PROD.V_RSK_BEAR_ABLTY                          	b1
  ON            a2.RSK_BEAR_ABLTY = b1.RSK_BEAR_ABLTY
  WHERE		   t.TRD__PRVL = 7
  AND           (t.APL_RSN = '5' OR a4.KHH IS NOT NULL)
  AND           CAST(t.APL_DT AS STRING)> =  CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-3,0,0),1,4),'0101')
 
  ;




  
  -----------------------------加载结束--------------------
  
  --删除临时表
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_GEM_5_DAYS_OPN_INFO_TEMP;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_GEM_5_DAYS_OPN_INFO_TEMP1;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_GEM_5_DAYS_OPN_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
     invalidate metadata DDW_PROD.T_DDW_PRT_GEM_5_DAYS_OPN_INFO; 
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:历史在途资金维表                                                                   */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-06-19                                                                       */ 
 -----删除今天的数据---
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_DIM_UNPY_AMT_HIS_TEMP ;
  CREATE TABLE DDW_PROD.T_DDW_F00_DIM_UNPY_AMT_HIS_TEMP as
  SELECT   a.KHH
          ,a.JYS
		  ,a.ZQDM
		  ,SUM(a.CJJE) as CJJE
		  ,c.TRD_DT as BUS_DATE 
		  ,a.KHXM
		  ,a.YYB
		  ,a.BZDM
		  ,a.JSZH
		  ,a.XTBS
  FROM  (SELECT          a.KHH
                        ,a.JYS
						,a.zqdm
						,a.bus_date
						,a.CJJE
						,a.KHXM
						,a.YYB
						,a.BZDM
						,a.JSZH
						,a.XTBS
                        ,ROUND(CASE WHEN a.JYS = 'SH'
							        THEN a.CJJG
								    ELSE a.CJJE*1.000/a.BCSL
								    END,2
							   )  as PX
          FROM        EDW_PROD.T_EDW_T05_TJGMXLS a
          LEFT JOIN  (SELECT   EXG
		                      ,SEC_CD_PFX
					  FROM DDW_PROD.T_DDW_CFG_SEC 
					  WHERE LENGTH(sec_cd_pfx)  = 3 
					  AND  STK_CGY IN ('A股中小板','基金','股票','创业板','主板A股') 
			          GROUP BY EXG,SEC_CD_PFX
			          )                                c
          ON        a.JYS = c.EXG
          AND       SUBSTR(a.ZQDM,1,3) = c.SEC_CD_PFX 
          WHERE       a.WTLB = 6
          AND   c.SEC_CD_PFX IS not null
          )                          a
  LEFT JOIN (SELECT   CAST(CONCAt(substr(a.ExDiviDate,1,4),substr(a.ExDiviDate,6,2),substr(a.ExDiviDate,9,2) ) as INT) as CXRQ
		             ,c.lst_trd_d as PXRQ
                     ,b.SECUCODE    as ZQDM
		             ,DECODE(b.secumarket,83,'SH',90,'SZ')  as JYS
		             ,SUM(ROUND(a.CashDiviRMB/10,2))        as PX1
		             ,SUM(ROUND(a.ActualCashDiviRMB/10,2))  as PX2
             FROM    ( SELECT     a.ExDiviDate
					              ,a.INNERCODE
							      ,a.ToAccountDate
								  ,a.DT								
								  ,a.CashDiviRMB
								  ,a.ActualCashDiviRMB
					  FROM    FUNDEXT.DBO_LC_DIVIDEND  a
					  WHERE   a.DT = '%d{yyyyMMdd}'
                      UNION ALL
					  SELECT    DECODE(LENGTH(TRIM(NVL(a.exrightdateex,''))),0,ExRightDate,exrightdateex)  as ExDiviDate
					           ,a.INNERCODE
							   ,DECODE(LENGTH(TRIM(NVL(a.ExecuteDateEX,''))),0,ExecuteDate,ExecuteDateEX)  as ToAccountDate
						       ,a.DT									
							   ,a.DividendRatioBeforeTax as CashDiviRMB
							   ,a.ActualRatioAfterTax    as ActualCashDiviRMB
					   FROM    FUNDEXT.DBO_MF_DIVIDEND  a
					   WHERE   a.DT = '%d{yyyyMMdd}' 
					  )a
            LEFT JOIN FUNDEXT.DBO_SECUMAIN     b
            ON        a.INNERCODE = b.INNERCODE
            AND       a.DT = b.DT
            LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE c
            ON        CAST(CONCAt(substr(a.ToAccountDate,1,4),substr(a.ToAccountDate,6,2),substr(a.ToAccountDate,9,2) ) as INT) = c.TRD_DT
            AND       c.BUS_DATE = %d{yyyyMMdd}
            WHERE     a.CashDiviRMB > 0 
            AND       CAST(CONCAt(substr(a.ExDiviDate,1,4),substr(a.ExDiviDate,6,2),substr(a.ExDiviDate,9,2) ) as INT) > 20140101
            AND       LENGTH(TRIM(NVL(a.ExDiviDate,''))) > 0
            AND       LENGTH(TRIM(NVL(a.ToAccountDate,''))) > 0
            AND       c.TRD_DT = c.NAT_DT
            AND       CAST(CONCAt(substr(a.ExDiviDate,1,4),substr(a.ExDiviDate,6,2),substr(a.ExDiviDate,9,2) ) as INT) < = CAST(CONCAt(substr(a.ExDiviDate,1,4),substr(a.ExDiviDate,6,2),substr(a.ExDiviDate,9,2) ) as INT)
           -- AND       20170711 BETWEEN c.lst_trd_d AND CAST(CONCAt(substr(a.ExDiviDate,1,4),substr(a.ExDiviDate,6,2),substr(a.ExDiviDate,9,2) ) as INT)
            AND       a.DT = '%d{yyyyMMdd}'
			GROUP BY CXRQ,PXRQ,ZQDM,JYS
             )   b
  on  a.BUS_DATE > = b.PXRQ
  AND a.BUS_DATE < b.CXRQ
  AND a.ZQDM = b.ZQDM
  AND  a.JYS = b.JYS
  AND  (a.PX = b.PX1 OR a.PX = b.PX2)
  LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE c
  ON        c.TRD_DT > = NVL(b.PXRQ,99999999)
  AND       c.TRD_DT < NVL(b.CXRQ,00000000)
  AND        c.BUS_DATE = %d{yyyyMMdd}
  WHERE b.ZQDM IS NOT NULL 
  AND c.TRD_DT = c.NAT_DT
  GROUP BY a.KHH,a.JYS,a.ZQDM,c.TRD_DT,a.KHXM,a.YYB,a.BZDM,a.JSZH,a.XTBS
;
 ---插入当天的申购认购的在途资金YWDM(120,122)
 INSERT OVERWRITE DDW_PROD.T_DDW_F00_DIM_UNPY_AMT_HIS
 (
                                   CUST_NO              --客户号       
                                  ,CUST_NAME            --客户姓名         
                                  ,CCY_CD               --币种代码
                                  ,CNTR_CPTL_ACCNT      --柜台资金帐号
								  ,UNPY_AMT             --在途资金
								  ,UNPY_SRC1            --在途来源1
								  ,UNPY_SRC2            --在途来源2
								  ,SYS_SRC              --账户来源							
 ) 
 partition(bus_date = %d{yyyyMMdd} )
    SELECT                t.KHH                   as CUST_NO             --客户号
                         ,t.KHXM                  as CUST_NAME           --客户姓名
                         --,t.YYB                   as BRH_NO              --营业部编号
                         ,t.BZDM                  as CCY_CD              --币种代码	
                         ,t.JSZH                  as CNTR_CPTL_ACCNT     --柜台资金帐号
                         ,t.QRJE                  as UNPY_AMT            --在途资金
                         ,t.TADM                  as UNPY_SRC1           --在途来源1
                         ,t.JJDM                  as UNPY_SRC2           --在途来源2                         
                         ,'普通帐户'	          as ACCNCT_SRC          --帐户来源                        						 
  FROM          EDW_PROD.T_EDW_T05_TOF_DJS              t
  WHERE         t.YWDM IN ('120','122','139')
  AND           t.BUS_DATE = %d{yyyyMMdd}  
  AND           t.JSBZ = 0 
 UNION ALL
 SELECT                   t.KHH                   as CUST_NO             --客户号
                         ,t.KHXM                  as CUST_NAME           --客户姓名
                        -- ,t.YYB                   as BRH_NO              --营业部编号
                         ,t.JSBZDM                as CCY_CD              --币种代码	
                         ,t.JSZH                  as CNTR_CPTL_ACCNT     --柜台资金帐号                         
						 ,t.QRJE                  as UNPY_AMT            --在途资金
                         ,t.TADM                  as UNPY_SRC1           --在途来源1
                         ,t.JJDM                  as UNPY_SRC2           --在途来源2                         
                         ,'普通帐户'	          as ACCNCT_SRC          --帐户来源 122 124                        						 
  FROM          EDW_PROD.T_EDW_T05_TOF_JJJGLS_XZB              t
 WHERE          ((t.YWDM IN ('124','142','150','600') AND t.QRFE > 0) OR (t.YWDM = '143' AND t.QRJE > 0 AND t.QRFE = 0)) --插入赎回,强制赎回,基金清盘，手续返回等业务代码的在途资金('124','142','143','150','600')
 AND            t.QRRQ < = %d{yyyyMMdd}
 AND            t.loginid > '%d{yyyyMMdd}'
-- AND            t.QRFE > 0  
 UNION ALL
   SELECT                 t.KHH                    as CUST_NO             --客户号
                         ,t.KHXM                  as CUST_NAME           --客户姓名
                        -- ,t.YYB                   as BRH_NO              --营业部编号
                         ,t.BZDM                  as CCY_CD              --币种代码	
                         ,t.JSZH                  as CNTR_CPTL_ACCNT     --柜台资金帐号
                         ,t.WTJE                  as UNPY_AMT            --在途资金
                         ,NULL                    as UNPY_SRC1           --在途来源1
                         ,t.CPDM                  as UNPY_SRC2           --在途来源2                       
                         ,'普通帐户'     	      as ACCNCT_SRC          --帐户来源						 
  FROM          EDW_PROD.T_EDW_T05_TJRCP_YH_JGLS              t
  LEFT JOIN   (SELECT KHH,CPDM,QRRQ FROM EDW_PROD.T_EDW_T05_TJRCP_YH_JGLS 
               WHERE   JRCP_YWDM = '130'
			   group by KHH,CPDM,QRRQ
			   )              a2
  ON          t.KHH = a2.KHH
  AND         t.CPDM = a2.CPDM
  WHERE       t.JRCP_YWDM = '120'
  AND         %d{yyyyMMdd} > = t.QRRQ
  AND         %d{yyyyMMdd} < NVL(a2.QRRQ,99999999)
  AND           t.QRJE > 0
   UNION ALL
   SELECT                 t.KHH                   as CUST_NO             --客户号
                         ,t.KHXM                  as CUST_NAME           --客户姓名
                         ,t.JSBZDM                as CCY_CD              --币种代码	
                         ,t.JSZH                  as CNTR_CPTL_ACCNT     --柜台资金帐号
                         ,CASE WHEN t.WTLB IN (1,42)
   						       THEN 0-t.CJJE
							   WHEN t.WTLB IN (2,43)
							   THEN t.CJJE
							   ELSE 0
							   END                as UNPY_AMT            --在途资金
                         ,t.JYS                    as UNPY_SRC1           --在途来源1
                         ,t.ZQDM                  as UNPY_SRC2           --在途来源2
                         ,'普通帐户'	          as ACCNCT_SRC          --帐户来源					 
  FROM          EDW_PROD.T_EDW_T05_TDJSQSZL              t
  WHERE         ((t.JYS IN ('HB','SB','HK','SK','TU') AND t.WTLB IN (1,2)) OR 
                 t.JYS IN ('SH','SZ') AND t.WTLB IN (42,43))
  AND           t.BUS_DATE = %d{yyyyMMdd}
  AND           t.JSBZ_2 = 0 
  AND           JSRQ_2 > %d{yyyyMMdd}
  AND           %d{yyyyMMdd} > = t.CJRQ
  UNION ALL
    SELECT                t.KHH                   as CUST_NO             --客户号
                         ,t.KHXM                  as CUST_NAME           --客户姓名
                         ,t.BZDM                as CCY_CD              --币种代码	
                         ,t.JSZH                  as CNTR_CPTL_ACCNT     --柜台资金帐号
                         ,CASE WHEN t.JYLB = 61
   						       THEN LEAST(NVL(ROUND((a2.NEWST_PRC+a2.NEWST_INT*a2.NETPRC_TRD_FLG)*a2.TRD_UNIT*(a3.ZQSL),2),0),(t.FZBJ-t.HKJE+t.GHLX))
							   WHEN t.JYLB = 64
							   THEN 0-NVL(ROUND((a2.NEWST_PRC+a2.NEWST_INT*a2.NETPRC_TRD_FLG)*a2.TRD_UNIT*(t.RQSL-t.HQSL),2),0)
							   ELSE 0
							   END                as UNPY_AMT            --在途资金
                         ,t.JYS                    as UNPY_SRC1           --在途来源1
                         ,t.ZQDM                  as UNPY_SRC2           --在途来源2
                         ,'信用帐户'	          as ACCNCT_SRC          --帐户来源		
  
  FROM          EDW_PROD.T_EDW_T05_TXY_FZXXLS           t
  LEFT JOIN     (SELECT a.KHH,a.ZQDM,a.JYS,SUM(a.ZQSL) as ZQSL 
                 FROM   EDW_PROD.T_EDW_T02_TZQGL   a
                 WHERE  EXISTS (SELECT 1 FROM   (SELECT    a.JYS,a.ZQDM,b.TRD_DT as TSRQ
                        				        FROM      (SELECT     a.JYS,a.ZQDM,LEAST(a.SSRQ,NVL(b.SSRQ,99999999)) as SSRQ,GREATEST(a.TSRQ,NVL(b.TSRQ,00000000)) as TSRQ
                                                           FROM       EDW_PROD.T_EDW_T04_TSZQDM a
			                                               LEFT JOIN  (SELECT * FROM EDW_PROD.T_EDW_T04_TSZQDM
			                                                            WHERE CPLB = 5
				                                                         AND   ZQDM LIKE '%J'
				                                                       ) b
				                                           ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
				                                           AND          a.JYS = b.JYS
				                                           AND          a.BUS_DATE = b.BUS_DATE 
				                                           where        a.CPLB IN (1,2,3,4,5,6,7) 
					                                       AND          a.BUS_DATE = %d{yyyyMMdd}
					                                       AND          a.ZQDM NOT LIKE '%J') a
				                                LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE b
										        ON         a.TSRQ = b.NAT_DT
										        AND        b.BUS_DATE = %d{yyyyMMdd}
										        )   b
						        WHERE  a.BUS_DATE = NVL(b.TSRQ,99999999)
								AND    a.ZQDM = b.ZQDM
								AND    a.JYS = b.JYS	 )
                 GROUP BY a.KHH,a.ZQDM,a.JYS
                )                                        a3
  ON            t.JYS = a3.JYS
  AND           t.ZQDM = a3.ZQDM
  LEFT JOIN    (SELECT a.EXG,a.CD,a.newst_prc,a.trd_unit,a.newst_int,a.netprc_trd_flg,a.BUS_DATE 
                FROM   DDW_PROD.T_DDW_PUB_QOT  a
				WHERE  EXISTS (SELECT 1 FROM   (SELECT    a.JYS,a.ZQDM,b.TRD_DT as TSRQ
                        				        FROM      (SELECT     a.JYS,a.ZQDM,LEAST(a.SSRQ,NVL(b.SSRQ,99999999)) as SSRQ,GREATEST(a.TSRQ,NVL(b.TSRQ,00000000)) as TSRQ
                                                           FROM       EDW_PROD.T_EDW_T04_TSZQDM a
			                                               LEFT JOIN  (SELECT * FROM EDW_PROD.T_EDW_T04_TSZQDM
			                                                            WHERE CPLB = 5
				                                                         AND   ZQDM LIKE '%J'
				                                                       ) b
				                                           ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
				                                           AND          a.JYS = b.JYS
				                                           AND          a.BUS_DATE = b.BUS_DATE 
				                                           where        a.CPLB IN (1,2,3,4,5,6,7) 
					                                       AND          a.BUS_DATE = %d{yyyyMMdd}
					                                       AND          a.ZQDM NOT LIKE '%J') a
				                                LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE b
										        ON         a.TSRQ = b.NAT_DT
										        AND        b.BUS_DATE = %d{yyyyMMdd}
										        )   b
						        WHERE  a.BUS_DATE = NVL(b.TSRQ,99999999)
								AND    a.CD = b.ZQDM
								AND    a.EXG = b.JYS															
				                )								
				AND     a.trd_mkt = 1
				AND     a.BUS_DATE < %d{yyyyMMdd}
				)                                        a2
  ON           t.ZQDM = a2.CD
  AND          t.JYS = a2.EXG 
  LEFT JOIN  ( SELECT     a.JYS,a.ZQDM,LEAST(a.SSRQ,NVL(b.SSRQ,99999999)) as SSRQ,GREATEST(a.TSRQ,NVL(b.TSRQ,00000000)) as TSRQ
                FROM       EDW_PROD.T_EDW_T04_TSZQDM a
			   LEFT JOIN  (SELECT * FROM EDW_PROD.T_EDW_T04_TSZQDM
			   WHERE CPLB = 5
			   AND   ZQDM LIKE '%J'
				           ) b
			   ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
			   AND          a.JYS = b.JYS
			   AND          a.BUS_DATE = b.BUS_DATE 
			   where        a.CPLB IN (1,2,3,4,5,6,7) 
			   AND         a.BUS_DATE = %d{yyyyMMdd}
			   AND          a.ZQDM NOT LIKE '%J') a4
  ON t.JYS = a4.JYS
  AND  t.zqdm = a4.ZQDM 				                               
  WHERE        t.BUS_DATE  = %d{yyyyMMdd}
  AND          t.BUS_DATE > a4.TSRQ
  UNION ALL
   SELECT                t.KHH                    as CUST_NO             --客户号
                         ,t.KHXM                  as CUST_NAME           --客户姓名
                         ,t.BZDM                  as CCY_CD              --币种代码	
                         ,t.JSZH                  as CNTR_CPTL_ACCNT     --柜台资金帐号
                         ,0-t.CJJE                as UNPY_AMT            --在途资金
                         ,t.JYS                   as UNPY_SRC1           --在途来源1
                         ,t.ZQDM                  as UNPY_SRC2           --在途来源2
                         ,CASE WHEN t.XTBS = 'JZJY'
 						       THEN '普通帐户'
							   ELSE '信用帐户'
							   END                as ACCNCT_SRC          --帐户来源
  FROM          DDW_PROD.T_DDW_F00_DIM_UNPY_AMT_HIS_TEMP            t
  WHERE         t.BUS_DATE = %d{yyyyMMdd}
  ;
  
  --删除临时表
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_DIM_UNPY_AMT_HIS_TEMP ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_DIM_UNPY_AMT_HIS_TEMP ;
  
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_DIM_UNPY_AMT_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_DIM_UNPY_AMT_HIS ;
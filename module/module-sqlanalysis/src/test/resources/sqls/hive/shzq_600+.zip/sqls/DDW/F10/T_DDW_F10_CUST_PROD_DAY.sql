------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户产品日表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2019-05-15                                                                        */ 
  
  
-----创建临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_PROD_DAY_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_F10_CUST_PROD_DAY_TEMP AS
 SELECT  NVL(a.CUST_NO,b.CUST_NO)              as CUST_NO
        ,NVL(a.PROD_CD,b.PROD_CD)              as PROD_CD
		,NVL(a.DATA_SRC,b.DATA_SRC)            as DATA_SRC
		,NVL(a.BUS_DATE,b.BUS_DATE)            as BUS_DATE
		,NVL(a.HLD_QTY,0)                      as HLD_QTY
		,NVL(a.HLD_AMT,0)                      as HLD_AMT
		,NVL(b.BUYIN_QTY,0)                    as BUYIN_QTY
		,NVL(b.SELL_QTY,0)                     as SELL_QTY
		,NVL(b.PRCH_QTY,0)                     as PRCH_QTY
		,NVL(b.SCRP_QTY,0)                     as SCRP_QTY
		,NVL(b.RDMPT_QTY,0)                    as RDMPT_QTY
		,NVL(b.BUYIN_AMT,0)                    as BUYIN_AMT
		,NVL(b.SELL_AMT,0)                     as SELL_AMT
		,NVL(b.PRCH_AMT,0)                     as PRCH_AMT
		,NVL(b.SCRP_AMT,0)                     as SCRP_AMT
		,NVL(b.RDMPT_AMT,0)                    as RDMPT_AMT
		,NVL(b.BNS_AMT,0)                      as BNS_AMT
		,NVL(b.S1_CSMN_FEE,0)                  as S1_CSMN_FEE	
        ,NVL(b.BUYIN_S1,0)                     as BUYIN_S1
        ,NVL(b.SELL_S1,0) 		               as SELL_S1
        ,NVL(b.PRCH_S1_CSMN_FEE,0) 		       as PRCH_S1_CSMN_FEE
        ,NVL(b.SCRP_S1_CSMN_FEE,0)             as SCRP_S1_CSMN_FEE
        ,NVL(b.RDMPT_S1_CSMN_FEE,0)            as RDMPT_S1_CSMN_FEE
		
 FROM (SELECT CUST_NO
              ,SEC_CD                                             as PROD_CD
		      ,SUM(SEC_QTY)                                       as HLD_QTY
		      ,SUM(SEC_MKTVAL)                                    as HLD_AMT
		      ,DECODE(SYS_SRC,'普通账户','JZJY','RZRQ')           as DATA_SRC
		      ,BUS_DATE
       FROM  DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
       WHERE (SEC_CGY LIKE 'J%' OR (SUBSTR(SEC_CD,1,3) = '205' AND SEC_CGY LIKE 'H%')) 
       AND   BUS_DATE = %d{yyyyMMdd}
       GROUP BY CUST_NO,PROD_CD,DATA_SRC,BUS_DATE
       )                 a
  FULL JOIN (SELECT  CUST_NO
                    ,SEC_CD                                                               as PROD_CD
					,SUM(DECODE(ODR_CGY,1,MTCH_QTY,61,MTCH_QTY,63,MTCH_QTY,4,MTCH_QTY,5,MTCH_QTY,0))                                    as BUYIN_QTY
					,SUM(DECODE(ODR_CGY,2,MTCH_QTY,62,MTCH_QTY,64,MTCH_QTY,0))                                    as SELL_QTY
					,SUM(DECODE(ODR_CGY,29,0,42,MTCH_QTY,1111,MTCH_QTY,0))         as PRCH_QTY
					,SUM(DECODE(ODR_CGY,83,MTCH_QTY,0))                                   as SCRP_QTY
					,SUM(DECODE(ODR_CGY,30,0,43,MTCH_QTY,2222,MTCH_QTY,0))         as RDMPT_QTY
					,SUM(DECODE(ODR_CGY,1,MTCH_AMT,61,MTCH_AMT,63,MTCH_AMT,4,MTCH_AMT,5,MTCH_AMT,0))                                    as BUYIN_AMT
					,SUM(DECODE(ODR_CGY,2,MTCH_AMT,62,MTCH_AMT,64,MTCH_AMT,0))                                    as SELL_AMT
					,SUM(DECODE(ODR_CGY,29,0,42,MTCH_AMT,1111,MTCH_AMT,0))         as PRCH_AMT
					,SUM(DECODE(ODR_CGY,83,MTCH_AMT,0))                                   as SCRP_AMT
					,SUM(DECODE(ODR_CGY,30,0,43,MTCH_AMT,2222,MTCH_AMT,0))         as RDMPT_AMT
					,SUM(DECODE(ODR_CGY,6,MTCH_AMT,0))                                    as BNS_AMT
                    ,SUM(S1-S11-S12)                                                      as S1_CSMN_FEE
					,SUM(DECODE(ODR_CGY,1,S1-S11-S12,61,S1-S11-S12,63,S1-S11-S12,4,S1-S11-S12,5,S1-S11-S12,0))                                  as BUYIN_S1
					,SUM(DECODE(ODR_CGY,2,S1-S11-S12,62,S1-S11-S12,64,S1-S11-S12,0))                                  as SELL_S1
					,SUM(DECODE(ODR_CGY,29,S1-S11-S12,42,S1-S11-S12,1111,S1-S11-S12,0))   as PRCH_S1_CSMN_FEE
					,SUM(DECODE(ODR_CGY,83,S1-S11-S12,0))                                 as SCRP_S1_CSMN_FEE
					,SUM(DECODE(ODR_CGY,30,S1-S11-S12,43,S1-S11-S12,2222,S1-S11-S12,0))   as RDMPT_S1_CSMN_FEE
					
					
					
					
					,DECODE(SYS_SRC,'普通账户','JZJY','RZRQ')                       as DATA_SRC
					,BUS_DATE
             FROM  DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
			 WHERE BUS_DATE = %d{yyyyMMdd}
			 AND   (SEC_CGY LIKE 'J%' OR (SUBSTR(SEC_CD,1,3) = '205' AND SEC_CGY LIKE 'H%'))
			 AND   ODR_CGY IN (1,2,29,30,83,61,62,63,64,6,1111,2222,42,43,4,5)
			 GROUP BY CUST_NO,PROD_CD,BUS_DATE,DATA_SRC
			 )                   b
ON  a.CUST_NO = b.CUST_NO
AND a.PROD_CD = b.PROD_CD
AND a.DATA_SRC = b.DATA_SRC  ;




 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_PROD_DAY_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_CUST_PROD_DAY_TEMP1 AS
 SELECT  NVL(a.CUST_NO,b.CUST_NO)              as CUST_NO
        ,NVL(a.PROD_CD,b.PROD_CD)              as PROD_CD
		,NVL(a.DATA_SRC,b.DATA_SRC)            as DATA_SRC
		,NVL(a.BUS_DATE,b.BUS_DATE)            as BUS_DATE
		,NVL(a.HLD_QTY,0)                      as HLD_QTY
		,NVL(a.HLD_AMT,0)                      as HLD_AMT		
		,NVL(b.PRCH_QTY,0)                     as PRCH_QTY
		,NVL(b.SCRP_QTY,0)                     as SCRP_QTY
		,NVL(b.RDMPT_QTY,0)                    as RDMPT_QTY
		,NVL(b.FIXINV_QTY,0)                   as FIXINV_QTY
		,NVL(b.PRCH_AMT,0)                     as PRCH_AMT
		,NVL(b.SCRP_AMT,0)                     as SCRP_AMT
		,NVL(b.RDMPT_AMT,0)                    as RDMPT_AMT
		,NVL(b.FIXINV_AMT,0)                   as FIXINV_AMT
		,NVL(b.S1_CSMN_FEE,0)                  as S1_CSMN_FEE
		,NVL(b.PRCH_S1_CSMN_FEE,0)             as PRCH_S1_CSMN_FEE
		,NVL(b.SCRP_S1_CSMN_FEE,0)             as SCRP_S1_CSMN_FEE
		,NVL(b.RDMPT_S1_CSMN_FEE,0)            as RDMPT_S1_CSMN_FEE
		,NVL(b.FIXINV_S1_CSMN_FEE,0)           as FIXINV_S1_CSMN_FEE
        ,NVL(b.BNS_AMT,0)	                   as BNS_AMT	
 FROM (SELECT  CUST_NO
              ,PROD_CD                                             as PROD_CD
		      ,SUM(PROD_SHR_QTY)                                   as HLD_QTY
		      ,SUM(PROD_NEWST_MKTVAL)                              as HLD_AMT
		      ,DECODE(PROD_CGY,8,'OFS',9,'JRCP',11,'OTC')          as DATA_SRC
		      ,BUS_DATE
       FROM  DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS
       WHERE   BUS_DATE = %d{yyyyMMdd}
	   AND   CUST_NO < > '100610335855'
       GROUP BY CUST_NO,PROD_CD,DATA_SRC,BUS_DATE
       )                 a
  FULL JOIN (SELECT  CUST_NO
                    ,PROD_CD                                                                       as PROD_CD
					,SUM(DECODE(PROD_BIZ_CD,'122',CNFM_SHR,0))                                     as PRCH_QTY
					,SUM(DECODE(PROD_BIZ_CD,'130',CNFM_SHR,0))                                     as SCRP_QTY
					,SUM(DECODE(PROD_BIZ_CD,'124',CNFM_SHR,'150',CNFM_SHR,'142',CNFM_SHR,0))       as RDMPT_QTY
					,SUM(DECODE(PROD_BIZ_CD,'139',CNFM_SHR,0))                                     as FIXINV_QTY
					,SUM(DECODE(PROD_BIZ_CD,'122',CNFM_AMT,0))                                     as PRCH_AMT
					,SUM(DECODE(PROD_BIZ_CD,'130',CNFM_AMT,0))                                     as SCRP_AMT
					,SUM(DECODE(PROD_BIZ_CD,'124',CNFM_AMT,'150',CNFM_AMT,'142',CNFM_AMT,0))       as RDMPT_AMT
					,SUM(DECODE(PROD_BIZ_CD,'139',CNFM_AMT,0))                                     as FIXINV_AMT
					,SUM(DECODE(PROD_BIZ_CD,'600',0-CNFM_AMT,CMSN_FEE))                            as S1_CSMN_FEE					
					,SUM(DECODE(PROD_BIZ_CD,'122',CMSN_FEE,0))                                     as PRCH_S1_CSMN_FEE
					,SUM(DECODE(PROD_BIZ_CD,'130',CMSN_FEE,'600',0-CNFM_AMT,0))                    as SCRP_S1_CSMN_FEE
					,SUM(DECODE(PROD_BIZ_CD,'124',CMSN_FEE,'150',CMSN_FEE,'142',CMSN_FEE,0))       as RDMPT_S1_CSMN_FEE
					,SUM(DECODE(PROD_BIZ_CD,'139',CMSN_FEE,0))                                     as FIXINV_S1_CSMN_FEE					
                    ,SUM(DECODE(PROD_BIZ_CD,'143',CNFM_AMT,0))                                     as BNS_AMT					
					,DECODE(PROD_CGY,8,'OFS',9,'JRCP',11,'OTC')                                    as DATA_SRC
					,BUS_DATE
             FROM  DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS
			 WHERE BUS_DATE = %d{yyyyMMdd}
			 AND   CUST_NO < > '100610335855'
			 AND   PROD_BIZ_CD IN ('130','122','124','142','150','143','600','139')
			 GROUP BY CUST_NO,PROD_CD,BUS_DATE,DATA_SRC
			 )                   b
ON  a.CUST_NO = b.CUST_NO
AND a.PROD_CD = b.PROD_CD
AND a.DATA_SRC = b.DATA_SRC  ;
------插入数据
  INSERT OVERWRITE DDW_PROD.T_DDW_F10_CUST_PROD_DAY
(               CUST_NO                 --客户号                
              , PROD_CD                 --产品代码
              , PROD_CL_CD              --产品分类代码
              , PROD_CL_NAME            --产品分类名称
              , DATA_SRC                --数据来源
              , BUYIN_AMT               --买入金额
              , SELL_AMT                --卖入金额
              , SCRP_AMT                --认购金额
              , PRCH_AMT                --申购金额
              , FIXINV_AMT              --定投金额
              , RDMPT_AMT               --赎回金额
              , BUYIN_QTY               --买入数量
              , SELL_QTY                --卖入数量
              , SCRP_QTY                --认购数量
              , PRCH_QTY                --申购数量
              , FIXINV_QTY              --定投数量
              , RDMPT_QTY               --赎回数量
              , BNS_AMT                 --红利金额
              , BUYIN_S1                --买入佣金
              , SELL_S1                 --卖出佣金
              , SCRP_S1_CSMN_FEE        --认购佣金及手续费收入
              , PRCH_S1_CSMN_FEE        --申购佣金及手续费收入
              , FIXINV_S1_CSMN_FEE      --定投佣金及手续费收入
              , RDMPT_S1_CSMN_FEE       --赎回佣金及手续费收入
			  , S1_CSMN_FEE             --佣金及手续费收入			  
              , HLD_AMT                 --持仓金额
              , HLD_QTY                 --持仓数量
              , MAIN_SALE_FLG           --重点销售标志
              , IF_TRD_DATE             --是否交易日				
 ) PARTITION(BUS_DATE )
 SELECT          
                t.CUST_NO                 --客户号                
              , t.PROD_CD                 --产品代码
              , CASE WHEN t.DATA_SRC = 'OTC'
			         THEN '100000'
					 WHEN t.PROD_CD LIKE '205%'
					 THEN '110000'
					 WHEN t.PROD_CD = '500501'
					 THEN '010600'
					 ELSE a2.PROD_CL_CD
					 END --产品分类代码			 
              , CASE WHEN t.DATA_SRC = 'OTC'
			         THEN '固收收益凭证'
					 WHEN t.PROD_CD LIKE '205%'
					 THEN '报价回购'
					 WHEN t.PROD_CD = '500501'
					 THEN '其它'
					 ELSE a2.PROD_CL_DSC
					 END       --产品分类名称
              , t.DATA_SRC                --数据来源
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.BUYIN_AMT
					 ELSE 0
					 END as BUYIN_AMT               --买入金额
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.SELL_AMT
					 ELSE 0
					 END    as SELL_AMT                --卖入金额
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.SCRP_AMT
					 ELSE 0
					 END  as SCRP_AMT                --认购金额
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.PRCH_AMT
					 ELSE 0
					 END as PRCH_AMT                --申购金额
              , 0 as FIXINV_AMT              --定投金额
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.RDMPT_AMT
					 ELSE 0
					 END as RDMPT_AMT               --赎回金额
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.BUYIN_QTY
					 ELSE 0
					 END as BUYIN_QTY               --买入数量
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.SELL_QTY 
					 ELSE 0
					 END as SELL_QTY                --卖入数量
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.SCRP_QTY
					 ELSE 0
					 END as SCRP_QTY                --认购数量
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.PRCH_QTY
					 ELSE 0
					 END as PRCH_QTY                --申购数量
              , 0 as FIXINV_QTY              --定投数量
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.RDMPT_QTY
					 ELSE 0
					 END as RDMPT_QTY               --赎回数量
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.BNS_AMT
					 ELSE 0
					 END as BNS_AMT                 --红利金额
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.BUYIN_S1
					 ELSE 0
					 END as BUYIN_S1                --买入佣金
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.SELL_S1
					 ELSE 0
					 END as SELL_S1                 --卖出佣金
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.SCRP_S1_CSMN_FEE
					 ELSE 0
					 END as SCRP_S1_CSMN_FEE        --认购佣金及手续费收入
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.PRCH_S1_CSMN_FEE
					 ELSE 0
					 END as PRCH_S1_CSMN_FEE        --申购佣金及手续费收入
              , 0 as FIXINV_S1_CSMN_FEE      --定投佣金及手续费收入
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.RDMPT_S1_CSMN_FEE 
					 ELSE 0
					 END as RDMPT_S1_CSMN_FEE       --赎回佣金及手续费收入



			 , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.S1_CSMN_FEE
					 ELSE 0
					 END as S1_CSMN_FEE             --佣金及手续费收入
              , t.HLD_AMT                 --持仓金额
              , t.HLD_QTY                 --持仓数量
              , CASE WHEN (%d{yyyyMMdd} BETWEEN NVL(a2.PROD_SALE_STRT_DT,0) AND   NVL(a2.PROD_SALE_END_DT,0)
                     OR %d{yyyyMMdd} BETWEEN NVL(a2.PROD_SUST_MKT_START_DT,0) AND   NVL(a2.PROD_SUST_MKT_END_DT,0))
					 AND  a2.IF_KEY_SALES = '1'
					 AND  LENGTH(TRIM(NVL(a2.IF_KEY_SALES,''))) > 0
					 THEN '1'
					 ELSE '0'
					 END as MAIN_SALE_FLG           --重点销售标志
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN '是'
					 ELSE '否'
					 END as IF_TRD_DATE             --是否交易日
              , CAST(a1.NAT_DT  as INT)            as BUS_DATE			  
 FROM       DDW_PROD.T_DDW_F10_CUST_PROD_DAY_TEMP               t 	
 LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE                         a1
 ON         t.BUS_DATE = a1.TRD_DT
 AND        a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR             a2
 ON         t.PROD_CD = a2.PROD_CD
 AND        a2.BUS_DATE = %d{yyyyMMdd}

 WHERE  t.CUST_NO NOT IN ( '100610335855','105810000001','999999999999')
 UNION ALL
 SELECT          
                t.CUST_NO                 --客户号                
              , t.PROD_CD                 --产品代码
              , CASE WHEN t.DATA_SRC = 'OTC'
			         THEN '100000'
					 WHEN t.PROD_CD LIKE '205%'
					 THEN '110000'
					 ELSE a2.PROD_CL_CD
					 END --产品分类代码			 
              , CASE WHEN t.DATA_SRC = 'OTC'
			         THEN '固收收益凭证'
					 WHEN t.PROD_CD LIKE '205%'
					 THEN '报价回购'
					 ELSE a2.PROD_CL_DSC
					 END       --产品分类名称
              , t.DATA_SRC                --数据来源
              , 0 as BUYIN_AMT              --买入金额
              , 0 as SELL_AMT                --卖入金额
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.SCRP_AMT
					 ELSE 0
					 END  as SCRP_AMT                --认购金额
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.PRCH_AMT
					 ELSE 0
					 END as PRCH_AMT                --申购金额
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.FIXINV_AMT
					 ELSE 0
					 END as FIXINV_AMT              --定投金额
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.RDMPT_AMT
					 ELSE 0
					 END as RDMPT_AMT               --赎回金额
              , 0 as BUYIN_QTY               --买入数量
              , 0 as SELL_QTY                --卖入数量
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.SCRP_QTY
					 ELSE 0
					 END as SCRP_QTY                --认购数量
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.PRCH_QTY
					 ELSE 0
					 END as PRCH_QTY                --申购数量
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.FIXINV_QTY
					 ELSE 0
					 END as FIXINV_QTY              --定投数量
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.RDMPT_QTY
					 ELSE 0
					 END as RDMPT_QTY               --赎回数量
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.BNS_AMT
					 ELSE 0
					 END as BNS_AMT                 --红利金额
			  , 0 as BUYIN_S1                --买入佣金
              , 0 as SELL_S1                 --卖出佣金
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.SCRP_S1_CSMN_FEE 
					 ELSE 0
					 END as SCRP_S1_CSMN_FEE        --认购佣金及手续费收入
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.PRCH_S1_CSMN_FEE 
					 ELSE 0
					 END as PRCH_S1_CSMN_FEE        --申购佣金及手续费收入
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.FIXINV_S1_CSMN_FEE 
					 ELSE 0
					 END as FIXINV_S1_CSMN_FEE      --定投佣金及手续费收入
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.RDMPT_S1_CSMN_FEE 
					 ELSE 0
					 END as RDMPT_S1_CSMN_FEE       --赎回佣金及手续费收入		 
              
			  , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN t.S1_CSMN_FEE
					 ELSE 0
					 END as S1_CSMN_FEE             --佣金及手续费收入
              , t.HLD_AMT                 --持仓金额
              , t.HLD_QTY                 --持仓数量
              , CASE WHEN (%d{yyyyMMdd} BETWEEN NVL(a2.PROD_SALE_STRT_DT,0) AND   NVL(a2.PROD_SALE_END_DT,0)
                     OR %d{yyyyMMdd} BETWEEN NVL(a2.PROD_SUST_MKT_START_DT,0) AND   NVL(a2.PROD_SUST_MKT_END_DT,0))
					 AND  a2.IF_KEY_SALES = '1'
					 AND  LENGTH(TRIM(NVL(a2.IF_KEY_SALES,''))) > 0
					 THEN '1'
					 ELSE '0'
					 END as MAIN_SALE_FLG           --重点销售标志
              , CASE WHEN t.BUS_DATE = a1.NAT_DT
			         THEN '是'
					 ELSE '否'
					 END               as IF_TRD_DATE             --是否交易日
              , CAST(a1.NAT_DT  as INT)            as BUS_DATE			  
 FROM       DDW_PROD.T_DDW_F10_CUST_PROD_DAY_TEMP1               t 	
 LEFT JOIN  EDW_PROD.T_EDW_T99_TRD_DATE                         a1
 ON         t.BUS_DATE = a1.TRD_DT
 AND        a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN  DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR             a2
 ON         t.PROD_CD = a2.PROD_CD
 AND        a2.BUS_DATE = %d{yyyyMMdd}
 WHERE  t.CUST_NO NOT IN ( '100610335855','105810000001','999999999999')
 ;
 
-- ------删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_PROD_DAY_TEMP ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_PROD_DAY_TEMP1 ;
-- 
-------------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_CUST_PROD_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F10_CUST_PROD_DAY;
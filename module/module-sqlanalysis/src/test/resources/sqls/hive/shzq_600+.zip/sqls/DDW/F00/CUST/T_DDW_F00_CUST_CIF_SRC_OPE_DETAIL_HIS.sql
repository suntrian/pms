--/* ***************************************** SQL Begin *****************************************  */
  --/* 脚本功能:CIF系统操作明细历史表                                                               */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2016-11-30                                                                        */ 
  

-------------删除临时表-------------------
DROP TABLE IF EXISTS DDW_PROD.TEMP1_T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS;
DROP TABLE IF EXISTS DDW_PROD.TEMP2_T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS;
------------删除临时表结束-----------------

----创建临时表2---------------------------------	  
 CREATE TABLE DDW_PROD.TEMP1_T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS AS
       SELECT t.RQ,t.KHH,t.ZY,t.LY
		FROM 
        (SELECT  RQ,KHH,FSSJ,ZY,'JZJY' AS LY , ROW_NUMBER() OVER(PARTITION BY KHH ORDER BY RQ DESC, FSSJ DESC) AS NUM		
		FROM     EDW_PROD.T_EDW_T05_TYWXTCZMX
		
		WHERE    XTBS = 'JZJY' AND ywkm = '30599' AND zy like('%佣金%')  and zy like('%对象复核%') 
        UNION ALL
		SELECT   RQ,KHH,FSSJ,ZY,'RZRQ' AS LY ,ROW_NUMBER() OVER(PARTITION BY KHH ORDER BY RQ DESC, FSSJ DESC) AS NUM		
		FROM     EDW_PROD.T_EDW_T05_TYWXTCZMX
	    
		WHERE    XTBS = 'RZRQ' AND ywkm = '30599' AND zy like('%佣金%')  and zy like('%对象复核%') 
		)        t
		WHERE t.NUM = 1
	  ;


---------------------------------创建临时表3 二代证验证-----------------

CREATE TABLE  DDW_PROD.TEMP2_T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS  AS
  SELECT t1.khh,t1.rq, 1 as bz 
  FROM (
         SELECT t.khh,t.rq as RQ
         FROM (
	             SELECT  khh,rq 
                 FROM   EDW_PROD.T_EDW_T05_TYGTXTCZMX
                 WHERE  YWKM = '20090' OR  zy like '%二代证验证%'
                 UNION ALL
                 SELECT     a1.khh,a2.sqrq as rq
                 FROM       (SELECT yyb,zjbh,khh FROM  EDW_PROD.T_EDW_T01_TKHXX where bus_date = %d{yyyyMMdd})     a1
                 INNER JOIN (SELECT zjbh,yyb,sqrq FROM EDW_PROD.T_EDW_T02_TGMSFCXSQ WHERE CLJG = 1)                a2
                 ON           a1.yyb = a2.yyb
                 AND          a1.zjbh = a2.zjbh
              ) t
       GROUP BY t.khh,t.rq
      )   t1
	  ;

-------------------创建临时表3-------------------------
--------------插入数据-------------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS
(                                 
                                    JOUR_NO                                  --流水号
								   ,OPST_JOUR_NO			                 --对方流水号
                                   ,CUST_NO                                   --客户号                
                                   ,CUST_NAME                                 --客户姓名               
                                   ,CPTL_ACTNO                                 --资金账户
								   ,BRH_NO                                    --营业部编号              
                                   ,BRH_NAME                                  --营业部名称                            
                                   ,OPNAC_DT                                  --开户日期                                                                                                                                                        
                                   ,CTRL_ATTR                                 --控制属性               
                                   ,IMAGE_TP                                  --影像类型                                                                                                                                                                                           
                                   ,OCC_BRH_NO                                --发生营业部              
                                   ,BIZ_SBJ                                   --业务科目
                                   ,BIZ_SBJ_NAME                              --业务科目名称								   
                                   ,BIZ_SYS                                   --业务系统                                                     
                                   ,DT                                        --日期 
                                   ,TM                                        --发生时间								   
                                   ,ABST                                      --摘要                 
                                   ,CMSN_SETUP_DT                             --佣金设置日期
                                   ,CMSN_SETUP_ABST   				          --佣金设置摘要
                                   ,SECOND_CARD_VRFCTN                        --二代证验证 
                                   ,OPRT_TELR                                 --操作柜员
                                   ,OPRT_MOD                                  --操作方式
                                   ,PRVL_OPEN_AGE                             --权限开通年龄								   
                                   ,RPRG_DEPT                                 --隶属部门	
                                   ,OPRT_SITE                                  --操作站点
								   ,BIZ_RQM_ID                                --业务请求主键
                                   ,BIZ_RQM_DEAL_ID                           --业务请求处理主键
                                   ,SPNS_CNL	                              --发起渠道							   
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT                             t.ID                            as JOUR_NO                                  --流水号
								   ,t.DFLSH                         as OPST_JOUR_NO			                 --对方流水号
                                   ,t.KHH                            as CUST_NO                                   --客户号                                                        
                                   ,t.KHJC                           as CUST_NAME                                 --客户姓名                                                       
                                  ,t.ZJZH                          as CPTL_ACTNO                                 --资金账户
								  ,t.YYB                            as BRH_NO                                    --营业部编号                                                      
                                   ,NVL(a1.BRH_SHRTNM,a12.FILIL_DEPT_SHRTNM)                          as BRH_NAME                                  --营业部名称                                                                                           
                                   ,a2.JZJYKH_KHRQ                   as OPNAC_DT                                  --开户日期                                                                                                                           
                                   ,a4.KZSX                          as CTRL_ATTR                                 --控制属性                                                       
                                   ,CASE WHEN a5.YWQQID IS NOT NULL
								         THEN '有' 
										 ELSE '无' 
										 END                         as IMAGE_TP                                  --影像类型 
                                   ,t.FSYYB                          as OCC_BRH_NO                                --发生营业部								   
                                   ,t.YWKM                           as BIZ_SBJ                                   --业务科目
                                   ,a6.YWKMMC                        as BIZ_SBJ_NAME                              --业务科目名称								   
                                   ,t.YWXT                           as BIZ_SYS                                   --业务系统                                                                                 
                                   ,t.RQ                             as DT                                        --日期 
                                   ,t.FSSJ                           as TM		                                  --发生时间						   
                                   ,t.ZY                             as ABST                                      --摘要                                                         
                                   ,a7.RQ                            as CMSN_SETUP_DT                             --佣金设置日期                                         
                                   ,a7.ZY                            as  CMSN_SETUP_ABST   				          --佣金设置摘要                                          
                                   ,CASE WHEN a8.BZ = 1 
								         THEN '已验证' 
								         ELSE '未验证' 
										 END                         as  SECOND_CARD_VRFCTN                       --二代证验证  
                                   ,CASE WHEN t.CZGY = 8888
								         THEN '反洗钱系统'
										 ELSE a10.NAME  
										 END                         as  OPRT_TELR                                --操作柜员	
                                   ,CASE WHEN a3.BRH_NO IS NOT NULL	
                                         THEN '临柜'
                                         WHEN t.CZGY = 9057 
                                         THEN '掌厅'
                                         WHEN t.czgy= 9292
										 THEN '指E通'
										 ELSE a9.NAME
                                         END                         as OPRT_MOD                                  --操作方式
								   ,CAST(CASE WHEN t.RQ <>0 AND a11.CSRQ <> 999999999 
								         THEN ROUND(EDW_PROD.G_DATE_COMPARE_DATE(CAST(t.RQ AS STRING),'yyyyMMdd',CAST(a11.CSRQ AS STRING),'yyyyMMdd')/365,0)
										 ELSE NULL 
										 END as DECIMAL(38,0))                        as PRVL_OPEN_AGE                            --开通权限年龄
                                   ,CAST(a9.ORGID AS STRING)         as RPRG_DEPT                                 --隶属部门	
                                   ,t.CZZD                           as OPRT_SITE                                  --操作站点
								   ,t.YWQQID	                     as BIZ_RQM_ID                                --业务请求主键
                                   ,t.YWQQCLID	                     as BIZ_RQM_DEAL_ID                           --业务请求处理主键
								   ,t.FQQD                           as SPNS_CNL	                              --发起渠道
  FROM          EDW_PROD.T_EDW_T05_TYGTXTCZMX             t
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                                                   a1
  ON            t.YYB = a1.BRH_NO   
  AND           a1.BUS_DATE = %d{yyyyMMdd} 
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a12
  ON            t.YYB = a12.FILIL_DEPT_CDG
  AND           a12.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     EDW_PROD.T_EDW_T01_TKHXX                  a2 
  ON            t.KHH = a2.KHH  
  AND           t.bus_date = a2.bus_date
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                    a3
  ON            t.FSYYB = a3.BRH_NO 
  AND           a3.BUS_DATE = %d{yyyyMMdd}  
  LEFT JOIN     EDW_PROD.T_EDW_T99_TKHYWSX                a4
  ON            t.KHH = a4.KHH
  AND           a4.bus_date = %d{yyyyMMdd}
  LEFT JOIN     (SELECT DISTINCT YWQQID,DT,YXLX FROM YGTCX.CIF_TYWQQ_IMAGE WHERE YXLX IN (9,10) )                   a5
  ON           t.YWQQID = a5.YWQQID
  AND          CAST(a5.dt as INT) = %d{yyyyMMdd}
  LEFT JOIN    EDW_PROD.T_EDW_T99_TYGTYWKM                a6
  ON           t.YWKM = a6.YWKM
  AND          a6.bus_date = %d{yyyyMMdd}
  LEFT JOIN    DDW_PROD.TEMP1_T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS                   a7
  ON           t.KHH = a7.KHH
  AND          a7.LY = 'JZJY'
  LEFT JOIN    DDW_PROD.TEMP2_T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS                    a8
  ON           t.KHH = a8.KHH 
  AND          t.RQ  = a8.RQ
  LEFT JOIN    EDW_PROD.T_EDW_T02_TUSER                     a9
  ON           t.CZGY = a9.TUSER_ID
  AND          a9.bus_date = %d{yyyyMMdd}
  LEFT JOIN    EDW_PROD.T_EDW_T02_TUSER                    a10
  ON           t.CZGY = a10.TUSER_ID
  AND          a10.bus_date = %d{yyyyMMdd}
  LEFT JOIN    EDW_PROD.T_EDW_T01_TGRKHXX                a11
  ON           t.KHH = a11.KHH
  AND           t.RQ = a11.BUS_DATE
  WHERE        t.bus_date = %d{yyyyMMdd}
;  
---------------- 插入数据结束 -----------------------


-------------删除临时表-------------------
DROP TABLE IF EXISTS DDW_PROD.TEMP1_T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS;
DROP TABLE IF EXISTS DDW_PROD.TEMP2_T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS;
------------删除临时表结束-----------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
------------------结束所有程序---------------
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS ;
 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360普通账户和信用账户持仓明细表                                                         */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-10-27                                                                       */ 
  /* T_DDW_F02_SEC_HLD_DTL	替换为	T_DDW_F00_AST_SEC_HLD_DTL_HIS */
  /* T_DDW_F04_QOT	替换为	T_DDW_PUB_QOT */


---------------- 插入数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_ORDI_CRD_ACCNT_HLD_DTL
 (
	 CUST_NO                 --客户号       
	,CUST_NAME               --客户姓名  
	,BRH_NAME                --营业部    
	,EXG                     --交易所
	,SHRHLD_NO               --股东号
	,SEC_CD                  --证券代码
	,SEC_NAME                --证券名称
	,SEC_CGY                 --证券类别
	,CCY                     --币种
	,SEC_QTY                 --持仓数量
	,FZN_QTY                 --冻结数量
	,SEC_NEWST_MKTVAL        --持仓市值
	,NEWST_PRC               --收盘价
	,ACCNT_CGY               --账户类别
 )PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT      t.CUST_NO             as CUST_NO                 --客户号     
            ,t.CUST_NAME           as CUST_NAME               --客户姓名 
            ,a1.JGMC               as BRH_NAME                --营业部   
            ,a2.EXG_NAME           as EXG                     --交易所
            ,t.SHRHLD_NO           as SHRHLD_NO               --股东号
            ,t.SEC_CD              as SEC_CD                  --证券代码
            ,t.SEC_NAME            as SEC_NAME                --证券名称
            ,a3.ZQLBMC             as SEC_CGY                 --证券类别
            ,a4.CCY_CD_NAME        as CCY                     --币种
            ,t.SEC_QTY             as SEC_QTY                 --持仓数量
            ,t.FZN_QTY             as FZN_QTY                 --冻结数量
            ,t.SEC_MKTVAL    as SEC_NEWST_MKTVAL        --持仓市值
            ,a5.NEWST_PRC          as NEWST_PRC               --收盘价
            ,t.SYS_SRC           as ACCNT_CGY               --账户类别
 FROM         DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS         t
 LEFT JOIN    EDW_PROD.T_EDW_T03_TJGGL               a1
 ON           t.BRH_NO = a1.JGDM
 AND          t.BUS_DATE = a1.BUS_DATE
 LEFT JOIN    DDW_PROD.V_EXG                         a2
 ON           t.EXG = a2.EXG
 LEFT JOIN    EDW_PROD.T_EDW_T99_TZQLB               a3
 ON           t.SEC_CGY = a3.ZQLB 
 AND          a3.XTBS = 'JZJY'
 AND          t.EXG = a3.JYS 
 AND          t.bus_date = a3.BUS_DATE
 LEFT JOIN    DDW_PROD.V_CCY_CD                     a4
 ON           t.CCY_CD = a4.CCY_CD
 LEFT JOIN    DDW_PROD.T_DDW_PUB_QOT               a5
 ON           t.EXG = a5.EXG
 AND          t.SEC_CD = a5.CD
 AND          a5.trd_mkt = 1
 AND          t.bus_date = a5.BUS_DATE   
 WHERE        t.BUS_DATE = %d{yyyyMMdd}
 
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_ORDI_CRD_ACCNT_HLD_DTL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_ORDI_CRD_ACCNT_HLD_DTL;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:金融产品产品账户表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TJRCP_CPZH; 
------插入数据开始---------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TJRCP_CPZH
(
                                    KHH                                 --客户号                                
                                   ,FXJG                                --发行机构                               
                                   ,CPZH                                --结算帐号                               
                                   ,JSZH                                --产品帐号                               
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,LCZH                                --理财帐号                               
                                   ,JRCP_FXDJ                           --金融产品客户风险评级                         
                                   ,FXPCRQ                              --风险评测日期                             
                                   ,BZDM                                --币种代码                               
                                   ,KHRQ                                --开户日期                               
                                   ,ZHMM                                --账户密码                               
                                   ,JRCP_ZHSX                           --金融产品帐户属性                           
                                   ,JRCP_ZHZT                           --金融产品帐户状态                           
                                   ,ZJZHLB                              --资金帐户类别                             
                                   ,KHXM                                --客户姓名                               
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,XBDM                                --性别代码                               
                                   ,YZBM                                --邮政编码                               
                                   ,DZ                                  --地址                                 
                                   ,MOBILE                              --手机                                 
                                   ,DH                                  --电话                                 
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,ZCFZ                                --资产分组   
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.FXJG                                as FXJG                                --发行机构                                
                                   ,t.CPZH                                as CPZH                                --产品帐号                                
                                   ,t.JSZH                                as JSZH                                --结算帐号                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZJJSLX                              --结算类型                                
                                   ,t.JSJG                                as JSJG                                --结算机构                                
                                   ,t.LCZH                                as LCZH                                --理财帐号                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.FXDJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as JRCP_FXDJ                           --客户风险评级                              
                                   ,t.FXPCRQ                              as FXPCRQ                              --风险评测日期                              
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as BZDM                                --币种                                  
                                   ,t.KHRQ                                as KHRQ                                --开户日期                                
                                   ,t.ZHMM                                as ZHMM                                --账户密码                                
                                   ,t.ZHSX                                as JRCP_ZHSX                           --帐户属性                                
                                   ,t.ZHZT                                as JRCP_ZHZT                           --帐户状态                                
                                   ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJZHLB                              --帐户类别                                
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.XB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as XBDM                                --性别                                  
                                   ,t.YZBM                                as YZBM                                --邮政编码                                
                                   ,t.DZ                                  as DZ                                  --地址                                  
                                   ,t.MOBILE                              as MOBILE                              --手机                                  
                                   ,t.DH                                  as DH                                  --电话                                  
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,CAST(COALESCE(t7.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.ZCFZ                                as ZCFZ                                --资产分组   
                                   ,'JZJY'                                as XTBS								   
 FROM           JZJYCX.DATACENTER_TJRCP_CPZH           t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'ZJJSLX'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.JSLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'JRCP_FXDJ'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.FXDJ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'BZDM'
 AND            t3.YXT = 'JZJY'
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
 ON             t4.DMLX = 'ZJLBDM'
 AND            t4.YXT = 'JZJY'
 AND            t4.YDM = CAST(t.ZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t5 
 ON             t5.DMLX = 'ZJZHLB'
 AND            t5.YXT = 'JZJY'
 AND            t5.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t6 
 ON             t6.DMLX = 'XBDM'
 AND            t6.YXT = 'JZJY'
 AND            t6.YDM = CAST(t.XB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t7
 ON             t7.YXT = 'JZJY'
 AND            t7.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
----------插入数据结束--------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TJRCP_CPZH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TJRCP_CPZH; 

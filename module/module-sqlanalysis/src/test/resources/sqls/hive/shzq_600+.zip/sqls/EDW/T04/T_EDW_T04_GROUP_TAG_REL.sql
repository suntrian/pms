------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:组合标签信息表                                                                    */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

 
 --清除数据
 TRUNCATE TABLE EDW_PROD.T_EDW_T04_GROUP_TAG_REL;
 
 ------插入数据
INSERT INTO EDW_PROD.T_EDW_T04_GROUP_TAG_REL
(
                 GROUP_ID          --组合id
				,RISK_PREFER       --风险偏好id
				,FLUIDITY_PREFER   --流动性偏好id
				,UPDATE_TIME       --更新时间
				,STATUS            --状态(备用)
 ) partition(BUS_DATE = %d{yyyyMMdd})
 SELECT     
                 GROUP_ID          --组合id
				,RISK_PREFER       --风险偏好id
				,FLUIDITY_PREFER   --流动性偏好id
				,UPDATE_TIME       --更新时间
				,STATUS            --状态(备用)
FROM       jjlc.GROUP_TAG_REL
;
 
 ----删除临时表
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_GROUP_TAG_REL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;





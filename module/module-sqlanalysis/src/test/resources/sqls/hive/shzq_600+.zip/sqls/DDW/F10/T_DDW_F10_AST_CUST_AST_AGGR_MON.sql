------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户资产汇总月表                                                                    */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

----------创建期初的临时表 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP	;
 CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP as
  SELECT  CUST_NO                                --客户号                          
         ,a.MKTVAL_HA                                          as STRT_MKTVAL_HA                         --期初市值_沪A主板
         ,a.MKTVAL_SA                                          as STRT_MKTVAL_SA                         --期初市值_深A主板
         ,a.MKTVAL_SMS                                         as STRT_MKTVAL_SMS                        --期初市值_中小板
         ,a.MKTVAL_GEM                                         as STRT_MKTVAL_GEM                        --期初市值_创业板		 
         ,a.ORDI_MKTVAL_HB_USD                                 as STRT_MKTVAL_HB_USD                     --期初市值_沪B_美元
		 ,a.ORDI_MKTVAL_SB_HKD                                 as STRT_MKTVAL_SB_HKD                     --期初市值_深B_港币
         ,a.ORDI_MKTVAL_HK                                     as STRT_MKTVAL_HK                         --期初市值_沪港通
		 ,a.ORDI_MKTVAL_SK                                     as STRT_MKTVAL_SK                         --期初市值_深港通
         ,a.ORDI_MKTVAL_TA                                     as STRT_MKTVAL_TA                         --期初市值_三板A股
		 ,a.ORDI_MKTVAL_TU_USD                                 as STRT_MKTVAL_TU_USD                     --期初市值_三板B股_美元
         ,a.ORDI_MKTVAL_REPO                                   as STRT_MKTVAL_REPO                       --期初市值_回购
         ,a.ORDI_MKTVAL_EXG_FND + a.CRD_MKTVAL_EXG_FND         as STRT_MKTVAL_EXG_FND                    --期初市值_场内基金	      		 
		 ,a.ORDI_MKTVAL_CLS_FND + a.CRD_MKTVAL_CLS_FND         as STRT_MKTVAL_CLS_FND                    --期初市值_封闭式基金
         ,a.ORDI_MKTVAL_ETF_FND + a.CRD_MKTVAL_ETF_FND         as STRT_MKTVAL_ETF_FND                    --期初市值_ETF		
         ,a.ORDI_MKTVAL_OPN_FND + a.CRD_MKTVAL_OPN_FND         as STRT_MKTVAL_OPN_FND                    --期初市值_开放式
         ,a.ORDI_MKTVAL_LOF_FND + a.CRD_MKTVAL_LOF_FND         as STRT_MKTVAL_LOF_FND                    --期初市值_LOF	
	     ,a.ORDI_MKTVAL_FOF_FND + a.CRD_MKTVAL_FOF_FND         as STRT_MKTVAL_FOF_FND                    --期初市值_FOF	
         ,a.ORDI_MKTVAL_BOND+a.CRD_MKTVAL_BOND                 as STRT_MKTVAL_BOND                       --期初市值_债券	
         ,a.AGN_FND_MKTVAL                                     as STRT_AGN_FND_MKTVAL                    --期初代销基金市值
         ,a.GS_PROD_MKTVAL                                     as STRT_GS_PROD_MKTVAL                    --期初公司产品市值
         ,a.GJ_PROD_MKTVAL                                     as STRT_GJ_PROD_MKTVAL                    --期初国君产品市值        		 	
         ,a.BANK_PROD_MKTVAL                                   as STRT_BANK_PROD_MKTVAL                  --期初银行产品市值	 
         ,a.OTC_PROD_MKTVAL                                    as STRT_OTC_PROD_MKTVAL                   --期初OTC产品市值    		 
		 ,a.WRNT_RGHT_HLD_MKTVAL                               as STRT_WRNT_RGHT_HLD_MKTVAL              --期初期权账户权利仓市值	
         ,a.WRNT_DUTY_HLD_MKTVAL                               as STRT_WRNT_DUTY_HLD_MKTVAL              --期初期权账户义务仓市值
		 ,a.ORDI_MKTVAL_SEC_USD                                as STRT_ORDI_MKTVAL_SEC_USD               --期初普通账户证券市值_美元	
		 ,a.ORDI_MKTVAL_SEC_HKD                                as STRT_ORDI_MKTVAL_SEC_HKD               --期初普通账户证券市值_港币	
         ,a.ORDI_MKTVAL_SEC_RMD                                as STRT_ORDI_MKTVAL_SEC_RMD               --期初普通账户证券市值_人民币		
         ,a.ORDI_MKTVAL_PROD                                   as STRT_ORDI_MKTVAL_PROD                  --期初普通账户产品市值			 
         ,a.ORDI_SEC_MKTVAL                                    as STRT_ORDI_SEC_MKTVAL                   --期初普通账户证券市值(折算人民币)
         ,a.ORDI_MKTVAL                                        as STRT_ORDI_MKTVAL                       --期初普通账户市值 
         ,a.ORDI_UN_CIR_MKTVAL                                 as STRT_ORDI_UN_CIR_MKTVAL                --期初普通账户非流通市值(折算人民币)       
		 ,a.CRD_SEC_MKTVAL                                     as STRT_CRD_SEC_MKTVAL                    --期初信用账户证券市值
         ,a.WRNT_MKTVAL                                        as STRT_WRNT_MKTVAL                       --期初期权账户市值(权利仓市值-义务仓市值)		
		 ,a.WRNT_CNTS                                          as STRT_WRNT_CNTS                         --期初期权账户张数	
         ,a.TOT_MKTVAL                                         as STRT_TOT_MKTVAL                        --期初总市值		
         ,a.ORDI_CPTL_USD                                      as STRT_ORDI_CPTL_USD                     --期初普通账户资金_美元	
         ,a.ORDI_CPTL_HKD                                      as STRT_ORDI_CPTL_HKD                     --期初普通账户资金_港币	
		 ,a.ORDI_CPTL_RMB                                      as STRT_ORDI_CPTL_RMB                     --期初普通账户资金_人民币		
		 ,a.ORDI_CPTL                                          as STRT_ORDI_CPTL                         --期初普通账户资金(折算人民币)		
		 ,a.CRD_CPTL                                           as STRT_CRD_CPTL                          --期初信用账户资金
		 ,a.WRNT_CPTL                                          as STRT_WRNT_CPTL                         --期初期权账户资金	
		 ,a.TOT_UNPY_CPTL                                      as STRT_TOT_UNPY_CPTL                     --期初总的在途资金		
         ,a.TOT_CPTL                                           as STRT_TOT_CPTL                          --期初总资金		 
		 ,a.ORDI_GL                                            as STRT_ORDI_GL                           --期初普通账户负债
         ,a.CRD_GL                                             as STRT_CRD_GL                            --期初信用账户负债 		 
         ,a.TOTGL                                              as STRT_TOTGL                             --期初总负债	 
		 ,a.ORDI_AST                                           as STRT_ORDI_AST                          --期初普通资产	  
		 ,a.ORDI_NET_AST                                       as STRT_ORDI_NET_AST                      --期初普通净资产
		 ,a.CRD_AST                                            as STRT_CRD_AST                           --期初信用资产	 
		 ,a.WRNT_AST                                           as STRT_WRNT_AST                          --期初期权资产
		 ,a.TOT_AST                                            as STRT_TOT_AST                           --期初总资产
		 ,a.NET_TOT_AST                                        as STRT_NET_TOT_AST                       --期初净总资产
		 ,a.EXG_NET_TOT_AST                                    as STRT_EXG_NET_TOT_AST                   --期初场内净总资产  
         ,a.ORDI_MKTVAL_NEW_TA                                 as STRT_ORDI_MKTVAL_NEW_TA                --期初普通账户市值_新三板A股
         ,a.STK_PLG_AMT                                        as STRT_STK_PLG_AMT                       --期初股票质押余额
         ,a.MIN_STK_PLG_AMT                                    as STRT_MIN_STK_PLG_AMT                   --期初小微贷余额		 
	     ,a.ORDI_MKTVAL_EXG_FND_SH     as STRT_ORDI_MKTVAL_EXG_FND_SH                 --期初普通账户市值_场内基金_沪市
         ,a.ORDI_MKTVAL_EXG_FND_SZ     as STRT_ORDI_MKTVAL_EXG_FND_SZ                 --期初普通账户市值_场内基金_深市
         ,a.CRD_MKTVAL_EXG_FND_SH      as STRT_CRD_MKTVAL_EXG_FND_SH                  --期初信用账户市值_场内基金_沪市
         ,a.CRD_MKTVAL_EXG_FND_SZ      as STRT_CRD_MKTVAL_EXG_FND_SZ                  --期初信用账户市值_场内基金_深市
         ,a.ORDI_MKTVAL_BOND_SH        as STRT_ORDI_MKTVAL_BOND_SH                    --期初普通账户市值_债券_沪市
         ,a.ORDI_MKTVAL_BOND_SZ        as STRT_ORDI_MKTVAL_BOND_SZ                    --期初普通账户市值_债券_深市
         ,a.CRD_MKTVAL_BOND_SH         as STRT_CRD_MKTVAL_BOND_SH                     --期初信用账户市值_债券_沪市
         ,a.CRD_MKTVAL_BOND_SZ         as STRT_CRD_MKTVAL_BOND_SZ                     --期初信用账户市值_债券_深市
         ,a.ORDI_UN_CIR_MKTVAL_SH      as STRT_ORDI_UN_CIR_MKTVAL_SH                  --期初普通账户沪市非流通市值(折算人民币)
         ,a.ORDI_UN_CIR_MKTVAL_SZ      as STRT_ORDI_UN_CIR_MKTVAL_SZ                  --期初普通账户深市非流通市值(折算人民币)
         ,a.ORDI_MKTVAL_AK_STIB        as STRT_ORDI_MKTVAL_AK_STIB                    --期初普通账户市值_AK科创板
         ,a.ORDI_MKTVAL_RK_STIB        as STRT_ORDI_MKTVAL_RK_STIB                    --期初普通账户市值_RK科创CDR
         ,a.CRD_MKTVAL_AK_STIB         as STRT_CRD_MKTVAL_AK_STIB                     --期初信用账户市值_AK科创板
         ,a.CRD_MKTVAL_RK_STIB         as STRT_CRD_MKTVAL_RK_STIB                     --期初信用账户市值_RK科创CDR
         ,a.WRNT_RGHT_HLD_MKTVAL_SH    as STRT_WRNT_RGHT_HLD_MKTVAL_SH               --期初期权账户权利仓市值(SH)
         ,a.WRNT_DUTY_HLD_MKTVAL_SH    as STRT_WRNT_DUTY_HLD_MKTVAL_SH               --期初期权账户义务仓市值(SH)      
         ,a.WRNT_MKTVAL_SH             as STRT_WRNT_MKTVAL_SH                        --期初期权账户市值(权利仓市值-义务仓市值)(SH)	
         ,a.WRNT_CNTS_SH               as STRT_WRNT_CNTS_SH                          --期初期权张数(SH)
         ,a.WRNT_RGHT_HLD_MKTVAL_SZ    as STRT_WRNT_RGHT_HLD_MKTVAL_SZ               --期初期权账户权利仓市值(SZ)
         ,a.WRNT_DUTY_HLD_MKTVAL_SZ    as STRT_WRNT_DUTY_HLD_MKTVAL_SZ               --期初期权账户义务仓市值(SZ)      
         ,a.WRNT_MKTVAL_SZ             as STRT_WRNT_MKTVAL_SZ                        --期初期权账户市值(权利仓市值-义务仓市值)(SZ)	
         ,a.WRNT_CNTS_SZ               as STRT_WRNT_CNTS_SZ                          --期初期权张数(SZ)
	  FROM        DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    a
	  WHERE  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                                    FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                       WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                       AND BUS_DATE = %d{yyyyMMdd}
				                   )  b
                     WHERE  a.BUS_DATE = b.MON_START
				      )
	  AND  SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) 
       ;	   
----------创建期末的临时表 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP1	;
 CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP1 as
  SELECT  CUST_NO                                --客户号                          
         ,a.MKTVAL_HA                                          as FNL_MKTVAL_HA                         --期末市值_沪A主板
         ,a.MKTVAL_SA                                          as FNL_MKTVAL_SA                         --期末市值_深A主板
         ,a.MKTVAL_SMS                                         as FNL_MKTVAL_SMS                        --期末市值_中小板
         ,a.MKTVAL_GEM                                         as FNL_MKTVAL_GEM                        --期末市值_创业板		 
         ,a.ORDI_MKTVAL_HB_USD                                 as FNL_MKTVAL_HB_USD                     --期末市值_沪B_美元
		 ,a.ORDI_MKTVAL_SB_HKD                                 as FNL_MKTVAL_SB_HKD                     --期末市值_深B_港币
         ,a.ORDI_MKTVAL_HK                                     as FNL_MKTVAL_HK                         --期末市值_沪港通
		 ,a.ORDI_MKTVAL_SK                                     as FNL_MKTVAL_SK                         --期末市值_深港通
         ,a.ORDI_MKTVAL_TA                                     as FNL_MKTVAL_TA                         --期末市值_三板A股
		 ,a.ORDI_MKTVAL_TU_USD                                 as FNL_MKTVAL_TU_USD                     --期末市值_三板B股_美元
         ,a.ORDI_MKTVAL_REPO                                   as FNL_MKTVAL_REPO                       --期末市值_回购
         ,a.ORDI_MKTVAL_EXG_FND + a.CRD_MKTVAL_EXG_FND         as FNL_MKTVAL_EXG_FND                    --期末市值_场内基金	      		 
		 ,a.ORDI_MKTVAL_CLS_FND + a.CRD_MKTVAL_CLS_FND         as FNL_MKTVAL_CLS_FND                    --期末市值_封闭式基金
         ,a.ORDI_MKTVAL_ETF_FND + a.CRD_MKTVAL_ETF_FND         as FNL_MKTVAL_ETF_FND                    --期末市值_ETF		
         ,a.ORDI_MKTVAL_OPN_FND + a.CRD_MKTVAL_OPN_FND         as FNL_MKTVAL_OPN_FND                    --期末市值_开放式
         ,a.ORDI_MKTVAL_LOF_FND + a.CRD_MKTVAL_LOF_FND         as FNL_MKTVAL_LOF_FND                    --期末市值_LOF	
	     ,a.ORDI_MKTVAL_FOF_FND + a.CRD_MKTVAL_FOF_FND         as FNL_MKTVAL_FOF_FND                    --期末市值_FOF	
         ,a.ORDI_MKTVAL_BOND+a.CRD_MKTVAL_BOND                 as FNL_MKTVAL_BOND                       --期末市值_债券	
         ,a.AGN_FND_MKTVAL                                     as FNL_AGN_FND_MKTVAL                    --期末代销基金市值
         ,a.GS_PROD_MKTVAL                                     as FNL_GS_PROD_MKTVAL                    --期末公司产品市值
         ,a.GJ_PROD_MKTVAL                                     as FNL_GJ_PROD_MKTVAL                    --期末国君产品市值        		 	
         ,a.BANK_PROD_MKTVAL                                   as FNL_BANK_PROD_MKTVAL                  --期末银行产品市值	 
         ,a.OTC_PROD_MKTVAL                                    as FNL_OTC_PROD_MKTVAL                   --期末OTC产品市值    		 
		 ,a.WRNT_RGHT_HLD_MKTVAL                               as FNL_WRNT_RGHT_HLD_MKTVAL              --期末期权账户权利仓市值	
         ,a.WRNT_DUTY_HLD_MKTVAL                               as FNL_WRNT_DUTY_HLD_MKTVAL              --期末期权账户义务仓市值
		 ,a.ORDI_MKTVAL_SEC_USD                                as FNL_ORDI_MKTVAL_SEC_USD               --期末普通账户证券市值_美元	
		 ,a.ORDI_MKTVAL_SEC_HKD                                as FNL_ORDI_MKTVAL_SEC_HKD               --期末普通账户证券市值_港币	
         ,a.ORDI_MKTVAL_SEC_RMD                                as FNL_ORDI_MKTVAL_SEC_RMD               --期末普通账户证券市值_人民币		
         ,a.ORDI_MKTVAL_PROD                                   as FNL_ORDI_MKTVAL_PROD                  --期末普通账户产品市值			 
         ,a.ORDI_SEC_MKTVAL                                    as FNL_ORDI_SEC_MKTVAL                   --期末普通账户证券市值(折算人民币)
         ,a.ORDI_MKTVAL                                        as FNL_ORDI_MKTVAL                       --期末普通账户市值 
         ,a.ORDI_UN_CIR_MKTVAL                                 as FNL_ORDI_UN_CIR_MKTVAL                --期末普通账户非流通市值(折算人民币)       
		 ,a.CRD_SEC_MKTVAL                                     as FNL_CRD_SEC_MKTVAL                    --期末信用账户证券市值
         ,a.WRNT_MKTVAL                                        as FNL_WRNT_MKTVAL                       --期末期权账户市值(权利仓市值-义务仓市值)		
		 ,a.WRNT_CNTS                                          as FNL_WRNT_CNTS                         --期末期权账户张数	
         ,a.TOT_MKTVAL                                         as FNL_TOT_MKTVAL                        --期末总市值		
         ,a.ORDI_CPTL_USD                                      as FNL_ORDI_CPTL_USD                     --期末普通账户资金_美元	
         ,a.ORDI_CPTL_HKD                                      as FNL_ORDI_CPTL_HKD                     --期末普通账户资金_港币	
		 ,a.ORDI_CPTL_RMB                                      as FNL_ORDI_CPTL_RMB                     --期末普通账户资金_人民币		
		 ,a.ORDI_CPTL                                          as FNL_ORDI_CPTL                         --期末普通账户资金(折算人民币)		
		 ,a.CRD_CPTL                                           as FNL_CRD_CPTL                          --期末信用账户资金
		 ,a.WRNT_CPTL                                          as FNL_WRNT_CPTL                         --期末期权账户资金	
		 ,a.TOT_UNPY_CPTL                                      as FNL_TOT_UNPY_CPTL                     --期末总的在途资金		
         ,a.TOT_CPTL                                           as FNL_TOT_CPTL                          --期末总资金		 
		 ,a.ORDI_GL                                            as FNL_ORDI_GL                           --期末普通账户负债
         ,a.CRD_GL                                             as FNL_CRD_GL                            --期末信用账户负债 		 
         ,a.TOTGL                                              as FNL_TOTGL                             --期末总负债	 
		 ,a.ORDI_AST                                           as FNL_ORDI_AST                          --期末普通资产	  
		 ,a.ORDI_NET_AST                                       as FNL_ORDI_NET_AST                      --期末普通净资产
		 ,a.CRD_AST                                            as FNL_CRD_AST                           --期末信用资产	 
		 ,a.WRNT_AST                                           as FNL_WRNT_AST                          --期末期权资产
		 ,a.TOT_AST                                            as FNL_TOT_AST                           --期末总资产
		 ,a.NET_TOT_AST                                        as FNL_NET_TOT_AST                       --期末净总资产
		 ,a.EXG_NET_TOT_AST                                    as FNL_EXG_NET_TOT_AST                   --期末场内净总资产    	   	   
	     ,a.ORDI_MKTVAL_NEW_TA                                 as FNL_ORDI_MKTVAL_NEW_TA                --期末普通账户市值_新三板A股
         ,a.STK_PLG_AMT                                        as FNL_STK_PLG_AMT                       --期末股票质押余额
         ,a.MIN_STK_PLG_AMT                                    as FNL_MIN_STK_PLG_AMT                   --期末小微贷余额
 	     ,a.ORDI_MKTVAL_EXG_FND_SH                             as FNL_ORDI_MKTVAL_EXG_FND_SH                 --期末普通账户市值_场内基金_沪市
         ,a.ORDI_MKTVAL_EXG_FND_SZ                             as FNL_ORDI_MKTVAL_EXG_FND_SZ                 --期末普通账户市值_场内基金_深市
         ,a.CRD_MKTVAL_EXG_FND_SH                              as FNL_CRD_MKTVAL_EXG_FND_SH                  --期末信用账户市值_场内基金_沪市
         ,a.CRD_MKTVAL_EXG_FND_SZ                              as FNL_CRD_MKTVAL_EXG_FND_SZ                  --期末信用账户市值_场内基金_深市
         ,a.ORDI_MKTVAL_BOND_SH                                as FNL_ORDI_MKTVAL_BOND_SH                    --期末普通账户市值_债券_沪市
         ,a.ORDI_MKTVAL_BOND_SZ                                as FNL_ORDI_MKTVAL_BOND_SZ                    --期末普通账户市值_债券_深市
         ,a.CRD_MKTVAL_BOND_SH                                 as FNL_CRD_MKTVAL_BOND_SH                     --期末信用账户市值_债券_沪市
         ,a.CRD_MKTVAL_BOND_SZ                                 as FNL_CRD_MKTVAL_BOND_SZ                     --期末信用账户市值_债券_深市
         ,a.ORDI_UN_CIR_MKTVAL_SH                              as FNL_ORDI_UN_CIR_MKTVAL_SH                  --期末普通账户沪市非流通市值(折算人民币)
         ,a.ORDI_UN_CIR_MKTVAL_SZ                              as FNL_ORDI_UN_CIR_MKTVAL_SZ                  --期末普通账户深市非流通市值(折算人民币)
         ,a.ORDI_MKTVAL_AK_STIB                                as FNL_ORDI_MKTVAL_AK_STIB                    --期末普通账户市值_AK科创板
         ,a.ORDI_MKTVAL_RK_STIB                                as FNL_ORDI_MKTVAL_RK_STIB                    --期末普通账户市值_RK科创CDR
         ,a.CRD_MKTVAL_AK_STIB                                 as FNL_CRD_MKTVAL_AK_STIB                     --期末信用账户市值_AK科创板
         ,a.CRD_MKTVAL_RK_STIB                                 as FNL_CRD_MKTVAL_RK_STIB                     --期末信用账户市值_RK科创CDR
		 ,a.WRNT_RGHT_HLD_MKTVAL_SH                            as FNL_WRNT_RGHT_HLD_MKTVAL_SH               --期末期权账户权利仓市值(SH)
         ,a.WRNT_DUTY_HLD_MKTVAL_SH                            as FNL_WRNT_DUTY_HLD_MKTVAL_SH               --期末期权账户义务仓市值(SH)      
         ,a.WRNT_MKTVAL_SH                                     as FNL_WRNT_MKTVAL_SH                        --期末期权账户市值(权利仓市值-义务仓市值)(SH)	
         ,a.WRNT_CNTS_SH                                       as FNL_WRNT_CNTS_SH                          --期末期权张数(SH)
         ,a.WRNT_RGHT_HLD_MKTVAL_SZ                            as FNL_WRNT_RGHT_HLD_MKTVAL_SZ               --期末期权账户权利仓市值(SZ)
         ,a.WRNT_DUTY_HLD_MKTVAL_SZ                            as FNL_WRNT_DUTY_HLD_MKTVAL_SZ               --期末期权账户义务仓市值(SZ)      
         ,a.WRNT_MKTVAL_SZ                                     as FNL_WRNT_MKTVAL_SZ                        --期末期权账户市值(权利仓市值-义务仓市值)(SZ)	
         ,a.WRNT_CNTS_SZ                                       as FNL_WRNT_CNTS_SZ                          --期末期权张数(SZ)
	  FROM        DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    a
	   WHERE       a.BUS_DATE = %d{yyyyMMdd}
       ;	
-----------------------创建期月的临时表 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP2	;
 CREATE TABLE     DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP2 as
 SELECT   CUST_NO
          ,SUM(ORDI_DEPIN_AMT_USD)                     as ORDI_DEPIN_AMT_USD               --普通账户存入金额_美元
          ,SUM(ORDI_DEPIN_AMT_HKD)                     as ORDI_DEPIN_AMT_HKD               --普通账户存入金额_港币
          ,SUM(ORDI_DEPIN_AMT_RMB)                     as ORDI_DEPIN_AMT_RMB               --普通账户存入金额_人民币
          ,SUM(ORDI_TFR_IN_AMT)                        as ORDI_TFR_IN_AMT                  --普通账户转入金额(折算人民币)
          ,SUM(ORDI_WTHDR_AMT_USD)                     as ORDI_WTHDR_AMT_USD               --普通账户取出金额_美元
          ,SUM(ORDI_WTHDR_AMT_HKD)                     as ORDI_WTHDR_AMT_HKD               --普通账户取出金额_港币
          ,SUM(ORDI_WTHDR_AMT_RMB)                     as ORDI_WTHDR_AMT_RMB               --普通账户取出金额_人民币
          ,SUM(ORDI_TFR_OUT_AMT)                       as ORDI_TFR_OUT_AMT                 --普通账户转出金额(折算人民币)
          ,SUM(CRD_DEPIN_AMT)                          as CRD_DEPIN_AMT                    --信用账户存入金额
          ,SUM(CRD_TFR_IN_AMT)                         as CRD_TFR_IN_AMT                   --信用账户转入金额
          ,SUM(CRD_WTHDR_AMT)                          as CRD_WTHDR_AMT                    --信用账户取出金额
          ,SUM(CRD_TFR_OUT_AMT)                        as CRD_TFR_OUT_AMT                  --信用账户转出金额
          ,SUM(WRNT_DEPIN_AMT)                         as WRNT_DEPIN_AMT                   --期权账户存入金额
          ,SUM(WRNT_TFR_IN_AMT)                        as WRNT_TFR_IN_AMT                  --期权账户转入金额
          ,SUM(WRNT_WTHDR_AMT)                         as WRNT_WTHDR_AMT                   --期权账户取出金额
          ,SUM(WRNT_TFR_OUT_AMT)                       as WRNT_TFR_OUT_AMT                 --期权账户转出金额
          ,SUM(TFR_IN_AMT)                             as TFR_IN_AMT                       --转入资金
          ,SUM(TFR_OUT_AMT)                            as TFR_OUT_AMT                      --转出资金
          ,SUM(ORDI_NET_TFR_IN_AMT)                    as ORDI_NET_TFR_IN_AMT              --普通账户净转入资金
          ,SUM(CRD_NET_TFR_IN_AMT)                     as CRD_NET_TFR_IN_AMT               --信用账户净转入资金
          ,SUM(WRNT_NET_TFR_IN_AMT)                    as WRNT_NET_TFR_IN_AMT              --期权账户净转入资金
          ,SUM(NET_TFR_IN_AMT)                         as NET_TFR_IN_AMT                   --净转入资金
          ,SUM(ORDI_ASGN_TFR_IN_MKTVAL_RMB)            as ORDI_ASGN_TFR_IN_MKTVAL_RMB      --普通账户指定转入市值_人民币
          ,SUM(ORDI_ASGN_TFR_IN_MKTVAL_USD)            as ORDI_ASGN_TFR_IN_MKTVAL_USD      --普通账户指定转入市值_美元
          ,SUM(ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB)        as ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB  --普通账户转托管转入市值_人民币
          ,SUM(ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD)        as ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD  --普通账户转托管转入市值_港币
          ,SUM(CRD_ASGN_TFR_IN_MKTVAL)                 as CRD_ASGN_TFR_IN_MKTVAL           --信用账户指定转入市值		
          ,SUM(CRD_TFR_CSTD_TFR_IN_MKTVAL)             as CRD_TFR_CSTD_TFR_IN_MKTVAL       --信用账户转托管转入市值
          ,SUM(ORDI_ASGN_TFR_OUT_MKTVAL_RMB)           as ORDI_ASGN_TFR_OUT_MKTVAL_RMB     --普通账户撤指定转出市值_人民币
          ,SUM(ORDI_ASGN_TFR_OUT_MKTVAL_USD)           as ORDI_ASGN_TFR_OUT_MKTVAL_USD     --普通账户撤指定转出市值_美元
          ,SUM(ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB)       as ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB --普通账户转托管转出市值_人民币
          ,SUM(ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD)       as ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD --普通账户转托管转出市值_港币
          ,SUM(CRD_ASGN_TFR_OUT_MKTVAL)                as CRD_ASGN_TFR_OUT_MKTVAL          --信用账户指定转出市值		
          ,SUM(CRD_TFR_CSTD_TFR_OUT_MKTVAL)            as CRD_TFR_CSTD_TFR_OUT_MKTVAL      --信用账户转托管转出市值
          ,SUM(ORDI_TFR_IN_MKTVAL)                     as ORDI_TFR_IN_MKTVAL               --普通账户转入市值
          ,SUM(ORDI_TFR_OUT_MKTVAL)                    as ORDI_TFR_OUT_MKTVAL              --普通账户转出市值
          ,SUM(CRD_TFR_IN_MKTVAL)                      as CRD_TFR_IN_MKTVAL                --信用账户转入市值
          ,SUM(CRD_TFR_OUT_MKTVAL)                     as CRD_TFR_OUT_MKTVAL               --信用账户转出市值
          ,SUM(TFR_IN_MKTVAL)                          as TFR_IN_MKTVAL                    --转入市值
          ,SUM(TFR_OUT_MKTVAL)                         as TFR_OUT_MKTVAL                   --转出市值
          ,SUM(ORDI_NET_TFR_IN_MKTVAL)                 as ORDI_NET_TFR_IN_MKTVAL           --普通账户净转入市值
          ,SUM(CRD_NET_TFR_IN_MKTVAL)                  as CRD_NET_TFR_IN_MKTVAL            --信用账户净转入市值
          ,SUM(NET_TFR_IN_MKTVAL)                      as NET_TFR_IN_MKTVAL                --净转入市值		        
          ,SUM(ORDI_PRFT)                              as ORDI_PRFT                        --普通盈亏
          ,SUM(CRD_PRFT)                               as CRD_PRFT                         --信用盈亏
          ,SUM(WRNT_PRFT)                              as WRNT_PRFT                        --期权盈亏
          ,SUM(TOT_PRFT)                               as TOT_PRFT                         --总盈亏
		  ,AVG(ORDI_CPTL+ORDI_UNPY_CPTL)               as AVGDLY_ORDI_CPTL                 --日均普通账户资金
		  ,AVG(CRD_CPTL+CRD_UNPY_CPTL)                 as AVGDLY_CRD_CPTL                  --日均信用账户资金
		  ,AVG(WRNT_CPTL+WRNT_UNPY_CPTL)               as AVGDLY_WRNT_CPTL                 --日均期权账户资金
		  ,AVG(TOT_CPTL+TOT_UNPY_CPTL)                 as AVGDLY_TOT_CPTL                  --日均总资金		  
		  ,MAX(ORDI_CPTL+ORDI_UNPY_CPTL)               as MAX_ORDI_CPTL                    --当月普通账户最大资金
		  ,MAX(CRD_CPTL+CRD_UNPY_CPTL)                 as MAX_CRD_CPTL                     --当月信用账户最大资金
		  ,MAX(WRNT_CPTL+WRNT_UNPY_CPTL)               as MAX_WRNT_CPTL                    --当月期权账户最大资金
		  ,MAX(TOT_CPTL+TOT_UNPY_CPTL)                 as MAX_TOT_CPTL                     --当月最大总资金
		  ,MIN(ORDI_CPTL+ORDI_UNPY_CPTL)               as MIN_ORDI_CPTL                    --当月普通账户最小资金
		  ,MIN(CRD_CPTL+CRD_UNPY_CPTL)                 as MIN_CRD_CPTL                     --当月信用账户最小资金
		  ,MIN(WRNT_CPTL+WRNT_UNPY_CPTL)               as MIN_WRNT_CPTL                    --当月期权账户最小资金
		  ,MIN(TOT_CPTL+TOT_UNPY_CPTL)                 as MIN_TOT_CPTL                     --当月最小总资金		  
		  ,AVG(ORDI_MKTVAL)                            as AVGDLY_ORDI_MKTVAL                 --日均普通账户市值
		  ,AVG(CRD_SEC_MKTVAL )                        as AVGDLY_CRD_MKTVAL                  --日均信用账户市值
		  ,AVG(WRNT_MKTVAL)                            as AVGDLY_WRNT_MKTVAL                 --日均期权账户市值
		  ,AVG(TOT_MKTVAL)                             as AVGDLY_TOT_MKTVAL                  --日均总市值		  
		  ,MAX(ORDI_MKTVAL)                            as MAX_ORDI_MKTVAL                    --当月普通账户最大市值
		  ,MAX(CRD_SEC_MKTVAL )                        as MAX_CRD_MKTVAL                     --当月信用账户最大市值
		  ,MAX(WRNT_MKTVAL)                            as MAX_WRNT_MKTVAL                    --当月期权账户最大市值
		  ,MAX(TOT_MKTVAL)                             as MAX_TOT_MKTVAL                     --当月最大总市值	
		  ,MIN(ORDI_MKTVAL)                            as MIN_ORDI_MKTVAL                    --当月普通账户最小市值
		  ,MIN(CRD_SEC_MKTVAL )                        as MIN_CRD_MKTVAL                     --当月信用账户最小市值
		  ,MIN(WRNT_MKTVAL)                            as MIN_WRNT_MKTVAL                    --当月期权账户最小市值
		  ,MIN(TOT_MKTVAL)                             as MIN_TOT_MKTVAL                     --当月最小总市值          		  		  
		  ,AVG(ORDI_GL)                                as AVGDLY_ORDI_GL                     --日均普通账户负债
		  ,AVG(CRD_GL )                                as AVGDLY_CRD_GL                      --日均信用账户负债
		  ,AVG(TOTGL)                                  as AVGDLY_TOTGL                       --日均总负债
		  ,MAX(ORDI_GL)                                as MAX_ORDI_GL                        --当月普通账户最大负债
		  ,MAX(CRD_GL )                                as MAX_CRD_GL                         --当月信用账户最大负债
		  ,MAX(TOTGL)                                  as MAX_TOTGL                          --当月最大总负债
		  ,MIN(ORDI_GL)                                as MIN_ORDI_GL                        --当月普通账户最小负债
		  ,MIN(CRD_GL )                                as MIN_CRD_GL                         --当月信用账户最小负债
		  ,MIN(TOTGL)                                  as MIN_TOTGL                          --当月最小总负债
		  ,AVG(ORDI_AST)                               as AVGDLY_ORDI_AST                    --日均普通账户资产
		  ,AVG(CRD_AST)                                as AVGDLY_CRD_AST                     --日均信用账户资产
		  ,AVG(WRNT_AST)                               as AVGDLY_WRNT_AST                    --日均期权账户资产
		  ,AVG(TOT_AST)                                as AVGDLY_TOT_AST                     --日均总资产
		  ,MAX(ORDI_AST)                               as MAX_ORDI_AST                       --当月普通账户最大资产
		  ,MAX(CRD_AST)                                as MAX_CRD_AST                        --当月信用账户最大资产
		  ,MAX(WRNT_AST)                               as MAX_WRNT_AST                       --当月期权账户最大资产
		  ,MAX(TOT_AST)                                as MAX_TOT_AST                        --当月最大总资产
		  ,MIN(ORDI_AST)                               as MIN_ORDI_AST                       --当月普通账户最小资产
		  ,MIN(CRD_AST)                                as MIN_CRD_AST                        --当月信用账户最小资产
		  ,MIN(WRNT_AST)                               as MIN_WRNT_AST                       --当月期权账户最小资产
		  ,MIN(TOT_AST)                                as MIN_TOT_AST                        --当月最小总资产		  
		  ,AVG(ORDI_NET_AST)                           as AVGDLY_ORDI_NET_AST                --日均普通账户净资产
		  ,AVG(CRD_NET_AST)                            as AVGDLY_CRD_NET_AST                 --日均信用账户净资产
		  ,AVG(WRNT_AST)                               as AVGDLY_WRNT_NET_AST                --日均期权账户净资产
		  ,AVG(NET_TOT_AST)                            as AVGDLY_TOT_NET_AST                 --日均总净资产
		  ,MAX(ORDI_NET_AST)                           as MAX_ORDI_NET_AST                   --当月普通账户最大净资产
		  ,MAX(CRD_NET_AST)                            as MAX_CRD_NET_AST                    --当月信用账户最大净资产
		  ,MAX(WRNT_AST)                               as MAX_WRNT_NET_AST                   --当月期权账户最大净资产
		  ,MAX(NET_TOT_AST)                            as MAX_TOT_NET_AST                    --当月最大总净资产
		  ,MIN(ORDI_NET_AST)                           as MIN_ORDI_NET_AST                   --当月普通账户最小净资产
		  ,MIN(CRD_NET_AST)                            as MIN_CRD_NET_AST                    --当月信用账户最小净资产
		  ,MIN(WRNT_AST)                               as MIN_WRNT_NET_AST                   --当月期权账户最小净资产
		  ,MIN(NET_TOT_AST)                            as MIN_TOT_NET_AST                    --当月最小总净资产		  
		  ,AVG(EXG_NET_TOT_AST)                        as AVGDLY_EXG_NET_TOT_AST             --日均场内总净资产		  
		  ,MAX(EXG_NET_TOT_AST)                        as MAX_EXG_NET_TOT_AST                --当月场内最大总净资产
		  ,MIN(EXG_NET_TOT_AST)                        as MIN_EXG_NET_TOT_AST                --当月场内最小总净资产
		  ,SUM(STK_PLG_ADD_INT)                        as STK_PLG_ADD_INT                    --股票质押新增利息
          ,SUM(STK_PLG_ADD_TRD_AMT)                    as STK_PLG_ADD_TRD_AMT                --股票质押初始交易量
          ,SUM(MIN_STK_PLG_ADD_INT)                    as MIN_STK_PLG_ADD_INT                --小微贷新增利息
		  ,SUM(MIN_STK_PLG_ADD_TRD_AMT)                as MIN_STK_PLG_ADD_TRD_AMT            --小微贷初始交易量
		  
   FROM        DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY    
   WHERE       SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
   GROUP BY    CUST_NO
       ;	
 
--------创建临时表3
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP3;
 CREATE TABLE  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP3 as
 SELECT    t.CUST_NO
           ,AVG(t.ORDI_CPTL+t.ORDI_UNPY_CPTL)       as AVGDLY_ORDI_CPTL1 
		   ,AVG(t.CRD_CPTL+t.CRD_UNPY_CPTL)         as AVGDLY_CRD_CPTL1  
		   ,AVG(t.WRNT_CPTL+t.WRNT_UNPY_CPTL)       as AVGDLY_WRNT_CPTL1 
		   ,AVG(t.TOT_CPTL+t.TOT_UNPY_CPTL)         as AVGDLY_CPTL1  
           ,AVG(t.STK_PLG_AMT)                      as AVGDLY_STK_PLG_AMT 
           ,AVG(t.MIN_STK_PLG_AMT)		            as AVGDLY_MIN_STK_PLG_AMT
 FROM        DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY   t
 LEFT  JOIN  EDW_PROD.T_EDW_T99_TRD_DATE                a1
 ON          t.BUS_DATE = a1.TRD_DT
 AND         a1.BUS_DATE = %d{yyyyMMdd}
 WHERE       t.BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
 GROUP BY    t.CUST_NO  ;
 
 ------插入数据
  INSERT OVERWRITE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON
(        CUST_NO                                   --客户号                 
        ,BRH_NO                                    --营业部编号                         
        ,CUST_CGY		                           --客户类别
        ,STRT_MKTVAL_HA                            --期初市值_沪A主板
        ,STRT_MKTVAL_SA                            --期初市值_深A主板
        ,STRT_MKTVAL_SMS                           --期初市值_中小板
        ,STRT_MKTVAL_GEM                           --期初市值_创业板		 
        ,STRT_MKTVAL_HB_USD                        --期初市值_沪B_美元
        ,STRT_MKTVAL_SB_HKD                        --期初市值_深B_港币
        ,STRT_MKTVAL_HK                            --期初市值_沪港通
        ,STRT_MKTVAL_SK                            --期初市值_深港通
        ,STRT_MKTVAL_TA                            --期初市值_三板A股
        ,STRT_MKTVAL_TU_USD                        --期初市值_三板B股_美元
        ,STRT_MKTVAL_REPO                          --期初市值_回购
        ,STRT_MKTVAL_EXG_FND                       --期初市值_场内基金	      		 
        ,STRT_MKTVAL_CLS_FND                       --期初市值_封闭式基金
        ,STRT_MKTVAL_ETF_FND                       --期初市值_ETF		
        ,STRT_MKTVAL_OPN_FND                       --期初市值_开放式
        ,STRT_MKTVAL_LOF_FND                       --期初市值_LOF	
        ,STRT_MKTVAL_FOF_FND                       --期初市值_FOF	
        ,STRT_MKTVAL_BOND                          --期初市值_债券	
        ,STRT_AGN_FND_MKTVAL                       --期初代销基金市值
        ,STRT_GS_PROD_MKTVAL                       --期初公司产品市值
        ,STRT_GJ_PROD_MKTVAL                       --期初国君产品市值        		 	
        ,STRT_BANK_PROD_MKTVAL                     --期初银行产品市值	 
        ,STRT_OTC_PROD_MKTVAL                      --期初OTC产品市值    		 
        ,STRT_WRNT_RGHT_HLD_MKTVAL                 --期初期权账户权利仓市值	
        ,STRT_WRNT_DUTY_HLD_MKTVAL                 --期初期权账户义务仓市值
        ,STRT_ORDI_MKTVAL_SEC_USD                  --期初普通账户证券市值_美元	
        ,STRT_ORDI_MKTVAL_SEC_HKD                  --期初普通账户证券市值_港币	
        ,STRT_ORDI_MKTVAL_SEC_RMD                  --期初普通账户证券市值_人民币		
        ,STRT_ORDI_MKTVAL_PROD                     --期初普通账户产品市值			 
        ,STRT_ORDI_SEC_MKTVAL                      --期初普通账户证券市值(折算人民币)
        ,STRT_ORDI_MKTVAL                          --期初普通账户市值 
        ,STRT_ORDI_UN_CIR_MKTVAL                   --期初普通账户非流通市值(折算人民币) 
        ,STRT_CRD_SEC_MKTVAL                       --期初信用账户证券市值
        ,STRT_WRNT_MKTVAL                          --期初期权账户市值(权利仓市值-义务仓市
        ,STRT_WRNT_CNTS                            --期初期权账户张数	
        ,STRT_TOT_MKTVAL                           --期初总市值		
        ,STRT_ORDI_CPTL_USD                        --期初普通账户资金_美元	
        ,STRT_ORDI_CPTL_HKD                        --期初普通账户资金_港币	
        ,STRT_ORDI_CPTL_RMB                        --期初普通账户资金_人民币		
        ,STRT_ORDI_CPTL                            --期初普通账户资金(折算人民币)		
        ,STRT_CRD_CPTL                             --期初信用账户资金
        ,STRT_WRNT_CPTL                            --期初期权账户资金	
        ,STRT_TOT_UNPY_CPTL                        --期初总的在途资金		
        ,STRT_TOT_CPTL                             --期初总资金		 
        ,STRT_ORDI_GL                              --期初普通账户负债
        ,STRT_CRD_GL                               --期初信用账户负债 		 
        ,STRT_TOTGL                                --期初总负债	 
        ,STRT_ORDI_AST                             --期初普通资产	  
        ,STRT_ORDI_NET_AST                         --期初普通净资产
        ,STRT_CRD_AST                              --期初信用资产	 
        ,STRT_WRNT_AST                             --期初期权资产
        ,STRT_TOT_AST                              --期初总资产
        ,STRT_NET_TOT_AST                          --期初净总资产
        ,STRT_EXG_NET_TOT_AST                      --期初场内净总资产  
        ,FNL_MKTVAL_HA                             --期末市值_沪A主板  	   	   
        ,FNL_MKTVAL_SA                             --期末市值_深A主板
        ,FNL_MKTVAL_SMS                            --期末市值_中小板
        ,FNL_MKTVAL_GEM                            --期末市值_创业板		 
        ,FNL_MKTVAL_HB_USD                         --期末市值_沪B_美元
        ,FNL_MKTVAL_SB_HKD                         --期末市值_深B_港币
        ,FNL_MKTVAL_HK                             --期末市值_沪港通
        ,FNL_MKTVAL_SK                             --期末市值_深港通
        ,FNL_MKTVAL_TA                             --期末市值_三板A股
        ,FNL_MKTVAL_TU_USD                         --期末市值_三板B股_美元
        ,FNL_MKTVAL_REPO                           --期末市值_回购
        ,FNL_MKTVAL_EXG_FND                        --期末市值_场内基金	      		 
        ,FNL_MKTVAL_CLS_FND                        --期末市值_封闭式基金
        ,FNL_MKTVAL_ETF_FND                        --期末市值_ETF		
        ,FNL_MKTVAL_OPN_FND                        --期末市值_开放式
        ,FNL_MKTVAL_LOF_FND                        --期末市值_LOF	
        ,FNL_MKTVAL_FOF_FND                        --期末市值_FOF	
        ,FNL_MKTVAL_BOND                           --期末市值_债券	
        ,FNL_AGN_FND_MKTVAL                        --期末代销基金市值
        ,FNL_GS_PROD_MKTVAL                        --期末公司产品市值
        ,FNL_GJ_PROD_MKTVAL                        --期末国君产品市值        		 	
        ,FNL_BANK_PROD_MKTVAL                      --期末银行产品市值	 
        ,FNL_OTC_PROD_MKTVAL                       --期末OTC产品市值    		 
        ,FNL_WRNT_RGHT_HLD_MKTVAL                  --期末期权账户权利仓市值	
        ,FNL_WRNT_DUTY_HLD_MKTVAL                  --期末期权账户义务仓市值
        ,FNL_ORDI_MKTVAL_SEC_USD                   --期末普通账户证券市值_美元	
        ,FNL_ORDI_MKTVAL_SEC_HKD                   --期末普通账户证券市值_港币	
        ,FNL_ORDI_MKTVAL_SEC_RMD                   --期末普通账户证券市值_人民币		
        ,FNL_ORDI_MKTVAL_PROD                      --期末普通账户产品市值			 
        ,FNL_ORDI_SEC_MKTVAL                       --期末普通账户证券市值(折算人民币)
        ,FNL_ORDI_MKTVAL                           --期末普通账户市值 
        ,FNL_ORDI_UN_CIR_MKTVAL                    --期末普通账户非流通市值(折算人民币)       
        ,FNL_CRD_SEC_MKTVAL                        --期末信用账户证券市值
        ,FNL_WRNT_MKTVAL                           --期末期权账户市值(权利仓市值-义务仓市值)		
        ,FNL_WRNT_CNTS                             --期末期权账户张数	
        ,FNL_TOT_MKTVAL                            --期末总市值		
        ,FNL_ORDI_CPTL_USD                         --期末普通账户资金_美元	
        ,FNL_ORDI_CPTL_HKD                         --期末普通账户资金_港币	
        ,FNL_ORDI_CPTL_RMB                         --期末普通账户资金_人民币		
        ,FNL_ORDI_CPTL                             --期末普通账户资金(折算人民币)		
        ,FNL_CRD_CPTL                              --期末信用账户资金
        ,FNL_WRNT_CPTL                             --期末期权账户资金	
        ,FNL_TOT_UNPY_CPTL                         --期末总的在途资金		
        ,FNL_TOT_CPTL                              --期末总资金		 
        ,FNL_ORDI_GL                               --期末普通账户负债
        ,FNL_CRD_GL                                --期末信用账户负债 		 
        ,FNL_TOTGL                                 --期末总负债	 
        ,FNL_ORDI_AST                              --期末普通资产	  
        ,FNL_ORDI_NET_AST                          --期末普通净资产
        ,FNL_CRD_AST                               --期末信用资产	 
        ,FNL_WRNT_AST                              --期末期权资产
        ,FNL_TOT_AST                               --期末总资产
        ,FNL_NET_TOT_AST                           --期末净总资产
        ,FNL_EXG_NET_TOT_AST                       --期末场内净总资产
        ,ORDI_DEPIN_AMT_USD                        --普通账户存入金额_美元    	   	   
        ,ORDI_DEPIN_AMT_HKD                        --普通账户存入金额_港币
        ,ORDI_DEPIN_AMT_RMB                        --普通账户存入金额_人民币
        ,ORDI_TFR_IN_AMT                           --普通账户转入金额(折算人民币)
        ,ORDI_WTHDR_AMT_USD                        --普通账户取出金额_美元
        ,ORDI_WTHDR_AMT_HKD                        --普通账户取出金额_港币
        ,ORDI_WTHDR_AMT_RMB                        --普通账户取出金额_人民币
        ,ORDI_TFR_OUT_AMT                          --普通账户转出金额(折算人民币)
        ,CRD_DEPIN_AMT                             --信用账户存入金额
        ,CRD_TFR_IN_AMT                            --信用账户转入金额
        ,CRD_WTHDR_AMT                             --信用账户取出金额
        ,CRD_TFR_OUT_AMT                           --信用账户转出金额
        ,WRNT_DEPIN_AMT                            --期权账户存入金额
        ,WRNT_TFR_IN_AMT                           --期权账户转入金额
        ,WRNT_WTHDR_AMT                            --期权账户取出金额
        ,WRNT_TFR_OUT_AMT                          --期权账户转出金额
        ,TFR_IN_AMT                                --转入资金
        ,TFR_OUT_AMT                               --转出资金
        ,ORDI_NET_TFR_IN_AMT                       --普通账户净转入资金
        ,CRD_NET_TFR_IN_AMT                        --信用账户净转入资金
        ,WRNT_NET_TFR_IN_AMT                       --期权账户净转入资金
        ,NET_TFR_IN_AMT                            --净转入资金
        ,ORDI_ASGN_TFR_IN_MKTVAL_RMB               --普通账户指定转入市值_人民币
        ,ORDI_ASGN_TFR_IN_MKTVAL_USD               --普通账户指定转入市值_美元
        ,ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB           --普通账户转托管转入市值_人民币
        ,ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD           --普通账户转托管转入市值_港币
        ,CRD_ASGN_TFR_IN_MKTVAL                    --信用账户指定转入市值		
        ,CRD_TFR_CSTD_TFR_IN_MKTVAL                --信用账户转托管转入市值
        ,ORDI_ASGN_TFR_OUT_MKTVAL_RMB              --普通账户撤指定转出市值_人民币
        ,ORDI_ASGN_TFR_OUT_MKTVAL_USD              --普通账户撤指定转出市值_美元
        ,ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB          --普通账户转托管转出市值_人民币
        ,ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD          --普通账户转托管转出市值_港币
        ,CRD_ASGN_TFR_OUT_MKTVAL                   --信用账户指定转出市值		
        ,CRD_TFR_CSTD_TFR_OUT_MKTVAL               --信用账户转托管转出市值
        ,ORDI_TFR_IN_MKTVAL                        --普通账户转入市值
        ,ORDI_TFR_OUT_MKTVAL                       --普通账户转出市值
        ,CRD_TFR_IN_MKTVAL                         --信用账户转入市值
        ,CRD_TFR_OUT_MKTVAL                        --信用账户转出市值
        ,TFR_IN_MKTVAL                             --转入市值
        ,TFR_OUT_MKTVAL                            --转出市值
        ,ORDI_NET_TFR_IN_MKTVAL                    --普通账户净转入市值
        ,CRD_NET_TFR_IN_MKTVAL                     --信用账户净转入市值
        ,NET_TFR_IN_MKTVAL                         --净转入市值		        
        ,ORDI_PRFT                                 --普通盈亏
        ,CRD_PRFT                                  --信用盈亏
        ,WRNT_PRFT                                 --期权盈亏
        ,TOT_PRFT                                  --总盈亏
        ,AVGDLY_ORDI_CPTL                          --日均普通账户资金
        ,AVGDLY_CRD_CPTL                           --日均信用账户资金
        ,AVGDLY_WRNT_CPTL                          --日均期权账户资金
        ,AVGDLY_TOT_CPTL                           --日均总资金		  
        ,MAX_ORDI_CPTL                             --当月普通账户最大资金
        ,MAX_CRD_CPTL                              --当月信用账户最大资金
        ,MAX_WRNT_CPTL                             --当月期权账户最大资金
        ,MAX_TOT_CPTL                              --当月最大总资金
        ,MIN_ORDI_CPTL                             --当月普通账户最小资金
        ,MIN_CRD_CPTL                              --当月信用账户最小资金
        ,MIN_WRNT_CPTL                             --当月期权账户最小资金
        ,MIN_TOT_CPTL                              --当月最小总资金		  
        ,AVGDLY_ORDI_MKTVAL                        --日均普通账户市值
        ,AVGDLY_CRD_MKTVAL                         --日均信用账户市值
        ,AVGDLY_WRNT_MKTVAL                        --日均期权账户市值
        ,AVGDLY_TOT_MKTVAL                         --日均总市值		  
        ,MAX_ORDI_MKTVAL                           --当月普通账户最大市值
        ,MAX_CRD_MKTVAL                            --当月信用账户最大市值
        ,MAX_WRNT_MKTVAL                           --当月期权账户最大市值
        ,MAX_TOT_MKTVAL                            --当月最大总市值	
        ,MIN_ORDI_MKTVAL                           --当月普通账户最小市值
        ,MIN_CRD_MKTVAL                            --当月信用账户最小市值
        ,MIN_WRNT_MKTVAL                           --当月期权账户最小市值
        ,MIN_TOT_MKTVAL                            --当月最小总市值          	
        ,AVGDLY_ORDI_GL                            --日均普通账户负债
        ,AVGDLY_CRD_GL                             --日均信用账户负债
        ,AVGDLY_TOTGL                              --日均总负债
        ,MAX_ORDI_GL                               --当月普通账户最大负债
        ,MAX_CRD_GL                                --当月信用账户最大负债
        ,MAX_TOTGL                                 --当月最大总负债
        ,MIN_ORDI_GL                               --当月普通账户最小负债
        ,MIN_CRD_GL                                --当月信用账户最小负债
        ,MIN_TOTGL                                 --当月最小总负债
        ,AVGDLY_ORDI_AST                           --日均普通账户资产
        ,AVGDLY_CRD_AST                            --日均信用账户资产
        ,AVGDLY_WRNT_AST                           --日均期权账户资产
        ,AVGDLY_TOT_AST                            --日均总资产
        ,MAX_ORDI_AST                              --当月普通账户最大资产
        ,MAX_CRD_AST                               --当月信用账户最大资产
        ,MAX_WRNT_AST                              --当月期权账户最大资产
        ,MAX_TOT_AST                               --当月最大总资产
        ,MIN_ORDI_AST                              --当月普通账户最小资产
        ,MIN_CRD_AST                               --当月信用账户最小资产
        ,MIN_WRNT_AST                              --当月期权账户最小资产
        ,MIN_TOT_AST                               --当月最小总资产		  
        ,AVGDLY_ORDI_NET_AST                       --日均普通账户净资产
        ,AVGDLY_CRD_NET_AST                        --日均信用账户净资产
        ,AVGDLY_WRNT_NET_AST                       --日均期权账户净资产
        ,AVGDLY_TOT_NET_AST                        --日均总净资产
        ,MAX_ORDI_NET_AST                          --当月普通账户最大净资产
        ,MAX_CRD_NET_AST                           --当月信用账户最大净资产
        ,MAX_WRNT_NET_AST                          --当月期权账户最大净资产
        ,MAX_TOT_NET_AST                           --当月最大总净资产
        ,MIN_ORDI_NET_AST                          --当月普通账户最小净资产
        ,MIN_CRD_NET_AST                           --当月信用账户最小净资产
        ,MIN_WRNT_NET_AST                          --当月期权账户最小净资产
        ,MIN_TOT_NET_AST                           --当月最小总净资产		  
        ,AVGDLY_EXG_NET_TOT_AST                    --日均场内总净资产		  
        ,MAX_EXG_NET_TOT_AST                       --当月场内最大总净资产
        ,MIN_EXG_NET_TOT_AST                       --当月场内最小总净资产
        ,AVGDLY_ORDI_CPTL1                         --自然日日均普通账户资金
        ,AVGDLY_CRD_CPTL1                          --自然日日均信用账户资金
        ,AVGDLY_WRNT_CPTL1                         --自然日日均期权账户资金
        ,AVGDLY_CPTL1                              --自然日日均资金
        ,ETL_DT	
        ,STRT_ORDI_MKTVAL_NEW_TA                   --期初普通账户市值_新三板A股
        ,STRT_STK_PLG_AMT                          --期初股票质押余额 
        ,STRT_MIN_STK_PLG_AMT                      --期初小微贷余额	
        ,FNL_ORDI_MKTVAL_NEW_TA                    --期末普通账户市值_新三板A股
        ,FNL_STK_PLG_AMT                           --期末股票质押余额
        ,FNL_MIN_STK_PLG_AMT                       --期末小微贷余额
        ,STK_PLG_ADD_INT                           --股票质押新增利息
        ,STK_PLG_ADD_TRD_AMT                       --股票质押初始交易量
        ,MIN_STK_PLG_ADD_INT                       --小微贷新增利息
        ,MIN_STK_PLG_ADD_TRD_AMT                   --小微贷初始交易量	
        ,AVGDLY_STK_PLG_AMT                        --自然日日均股票质押余额
        ,AVGDLY_MIN_STK_PLG_AMT                    --自然日日均小微贷余额
        , STRT_ORDI_MKTVAL_EXG_FND_SH                          --期初普通账户市值_场内基金_沪市
       , STRT_ORDI_MKTVAL_EXG_FND_SZ                          --期初普通账户市值_场内基金_深市
       , STRT_CRD_MKTVAL_EXG_FND_SH                           --期初信用账户市值_场内基金_沪市
       , STRT_CRD_MKTVAL_EXG_FND_SZ                           --期初信用账户市值_场内基金_深市
       , STRT_ORDI_MKTVAL_BOND_SH                             --期初普通账户市值_债券_沪市
       , STRT_ORDI_MKTVAL_BOND_SZ                             --期初普通账户市值_债券_深市
       , STRT_CRD_MKTVAL_BOND_SH                              --期初信用账户市值_债券_沪市
       , STRT_CRD_MKTVAL_BOND_SZ                              --期初信用账户市值_债券_深市
       , STRT_ORDI_UN_CIR_MKTVAL_SH                           --期初普通账户沪市非流通市值(折算人民币)
       , STRT_ORDI_UN_CIR_MKTVAL_SZ                           --期初普通账户深市非流通市值(折算人民币)
       , STRT_ORDI_MKTVAL_AK_STIB                             --期初普通账户市值_AK科创板
       , STRT_ORDI_MKTVAL_RK_STIB                             --期初普通账户市值_RK科创CDR
       , STRT_CRD_MKTVAL_AK_STIB                              --期初信用账户市值_AK科创板
       , STRT_CRD_MKTVAL_RK_STIB                              --期初信用账户市值_RK科创CDR
       , FNL_ORDI_MKTVAL_EXG_FND_SH                          --期末普通账户市值_场内基金_沪市
       , FNL_ORDI_MKTVAL_EXG_FND_SZ                          --期末普通账户市值_场内基金_深市
       , FNL_CRD_MKTVAL_EXG_FND_SH                           --期末信用账户市值_场内基金_沪市
       , FNL_CRD_MKTVAL_EXG_FND_SZ                           --期末信用账户市值_场内基金_深市
       , FNL_ORDI_MKTVAL_BOND_SH                             --期末普通账户市值_债券_沪市
       , FNL_ORDI_MKTVAL_BOND_SZ                             --期末普通账户市值_债券_深市
       , FNL_CRD_MKTVAL_BOND_SH                              --期末信用账户市值_债券_沪市
       , FNL_CRD_MKTVAL_BOND_SZ                              --期末信用账户市值_债券_深市
       , FNL_ORDI_UN_CIR_MKTVAL_SH                           --期末普通账户沪市非流通市值(折算人民币)
       , FNL_ORDI_UN_CIR_MKTVAL_SZ                           --期末普通账户深市非流通市值(折算人民币)
       , FNL_ORDI_MKTVAL_AK_STIB                             --期末普通账户市值_AK科创板
       , FNL_ORDI_MKTVAL_RK_STIB                             --期末普通账户市值_RK科创CDR
       , FNL_CRD_MKTVAL_AK_STIB                              --期末信用账户市值_AK科创板
       , FNL_CRD_MKTVAL_RK_STIB                              --期末信用账户市值_RK科创CDR
       ,STRT_WRNT_RGHT_HLD_MKTVAL_SH                         --期初期权账户权利仓市值(SH)
       ,STRT_WRNT_DUTY_HLD_MKTVAL_SH                         --期初期权账户义务仓市值(SH)      
       ,STRT_WRNT_MKTVAL_SH                                  --期初期权账户市值(权利仓市值-义务仓市值)(SH)	
       ,STRT_WRNT_CNTS_SH                                    --期初期权张数(SH)
       ,STRT_WRNT_RGHT_HLD_MKTVAL_SZ                         --期初期权账户权利仓市值(SZ)
       ,STRT_WRNT_DUTY_HLD_MKTVAL_SZ                         --期初期权账户义务仓市值(SZ)      
       ,STRT_WRNT_MKTVAL_SZ                                  --期初期权账户市值(权利仓市值-义务仓市值)(SZ)	
       ,STRT_WRNT_CNTS_SZ                                    --期初期权张数(SZ)
       ,FNL_WRNT_RGHT_HLD_MKTVAL_SH                          --期末期权账户权利仓市值(SH)
       ,FNL_WRNT_DUTY_HLD_MKTVAL_SH                          --期末期权账户义务仓市值(SH)      
       ,FNL_WRNT_MKTVAL_SH                                   --期末期权账户市值(权利仓市值-义务仓市值)(SH)	
       ,FNL_WRNT_CNTS_SH                                     --期末期权张数(SH)
       ,FNL_WRNT_RGHT_HLD_MKTVAL_SZ                          --期末期权账户权利仓市值(SZ)
       ,FNL_WRNT_DUTY_HLD_MKTVAL_SZ                          --期末期权账户义务仓市值(SZ)      
       ,FNL_WRNT_MKTVAL_SZ                                   --期末期权账户市值(权利仓市值-义务仓市值)(SZ)	
       ,FNL_WRNT_CNTS_SZ                                     --期末期权张数(SZ)	   
        ) partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT  t.CUST_NO                                  --客户号                 
        ,t.BRH_NO                                     --营业部编号                         
        ,t.CUST_CGY		                            --客户类别
        ,NVL(a1.STRT_MKTVAL_HA,0)                            --期初市值_沪A主板
        ,NVL(a1.STRT_MKTVAL_SA,0)                            --期初市值_深A主板
        ,NVL(a1.STRT_MKTVAL_SMS,0)                           --期初市值_中小板
        ,NVL(a1.STRT_MKTVAL_GEM,0)                           --期初市值_创业板		 
        ,NVL(a1.STRT_MKTVAL_HB_USD,0)                        --期初市值_沪B_美元
        ,NVL(a1.STRT_MKTVAL_SB_HKD,0)                        --期初市值_深B_港币
        ,NVL(a1.STRT_MKTVAL_HK,0)                            --期初市值_沪港通
        ,NVL(a1.STRT_MKTVAL_SK,0)                            --期初市值_深港通
        ,NVL(a1.STRT_MKTVAL_TA,0)                            --期初市值_三板A股
        ,NVL(a1.STRT_MKTVAL_TU_USD,0)                        --期初市值_三板B股_美元
        ,NVL(a1.STRT_MKTVAL_REPO,0)                          --期初市值_回购
        ,NVL(a1.STRT_MKTVAL_EXG_FND,0)                       --期初市值_场内基金	      		 
        ,NVL(a1.STRT_MKTVAL_CLS_FND,0)                       --期初市值_封闭式基金
        ,NVL(a1.STRT_MKTVAL_ETF_FND,0)                       --期初市值_ETF		
        ,NVL(a1.STRT_MKTVAL_OPN_FND,0)                       --期初市值_开放式
        ,NVL(a1.STRT_MKTVAL_LOF_FND,0)                       --期初市值_LOF	
        ,NVL(a1.STRT_MKTVAL_FOF_FND,0)                       --期初市值_FOF	
        ,NVL(a1.STRT_MKTVAL_BOND,0)                          --期初市值_债券	
        ,NVL(a1.STRT_AGN_FND_MKTVAL,0)                       --期初代销基金市值
        ,NVL(a1.STRT_GS_PROD_MKTVAL,0)                       --期初公司产品市值
        ,NVL(a1.STRT_GJ_PROD_MKTVAL,0)                       --期初国君产品市值        		 	
        ,NVL(a1.STRT_BANK_PROD_MKTVAL,0)                     --期初银行产品市值	 
        ,NVL(a1.STRT_OTC_PROD_MKTVAL,0)                      --期初OTC产品市值    		 
        ,NVL(a1.STRT_WRNT_RGHT_HLD_MKTVAL,0)                 --期初期权账户权利仓市值	
        ,NVL(a1.STRT_WRNT_DUTY_HLD_MKTVAL,0)                 --期初期权账户义务仓市值
        ,NVL(a1.STRT_ORDI_MKTVAL_SEC_USD,0)                  --期初普通账户证券市值_美元	
        ,NVL(a1.STRT_ORDI_MKTVAL_SEC_HKD,0)                  --期初普通账户证券市值_港币	
        ,NVL(a1.STRT_ORDI_MKTVAL_SEC_RMD,0)                  --期初普通账户证券市值_人民币		
        ,NVL(a1.STRT_ORDI_MKTVAL_PROD,0)                     --期初普通账户产品市值			 
        ,NVL(a1.STRT_ORDI_SEC_MKTVAL,0)                      --期初普通账户证券市值(折算人民币)
        ,NVL(a1.STRT_ORDI_MKTVAL,0)                          --期初普通账户市值 
        ,NVL(a1.STRT_ORDI_UN_CIR_MKTVAL,0)                   --期初普通账户非流通市值(折算人民币) 
        ,NVL(a1.STRT_CRD_SEC_MKTVAL,0)                       --期初信用账户证券市值
        ,NVL(a1.STRT_WRNT_MKTVAL,0)                          --期初期权账户市值(权利仓市值-义务仓市
        ,NVL(a1.STRT_WRNT_CNTS,0)                            --期初期权账户张数	
        ,NVL(a1.STRT_TOT_MKTVAL,0)                           --期初总市值		
        ,NVL(a1.STRT_ORDI_CPTL_USD,0)                        --期初普通账户资金_美元	
        ,NVL(a1.STRT_ORDI_CPTL_HKD,0)                        --期初普通账户资金_港币	
        ,NVL(a1.STRT_ORDI_CPTL_RMB,0)                        --期初普通账户资金_人民币		
        ,NVL(a1.STRT_ORDI_CPTL,0)                            --期初普通账户资金(折算人民币)		
        ,NVL(a1.STRT_CRD_CPTL,0)                             --期初信用账户资金
        ,NVL(a1.STRT_WRNT_CPTL,0)                            --期初期权账户资金	
        ,NVL(a1.STRT_TOT_UNPY_CPTL,0)                        --期初总的在途资金		
        ,NVL(a1.STRT_TOT_CPTL,0)                             --期初总资金		 
        ,NVL(a1.STRT_ORDI_GL,0)                              --期初普通账户负债
        ,NVL(a1.STRT_CRD_GL,0)                               --期初信用账户负债 		 
        ,NVL(a1.STRT_TOTGL,0)                                --期初总负债	 
        ,NVL(a1.STRT_ORDI_AST,0)                             --期初普通资产	  
        ,NVL(a1.STRT_ORDI_NET_AST,0)                         --期初普通净资产
        ,NVL(a1.STRT_CRD_AST,0)                              --期初信用资产	 
        ,NVL(a1.STRT_WRNT_AST,0)                             --期初期权资产
        ,NVL(a1.STRT_TOT_AST,0)                              --期初总资产
        ,NVL(a1.STRT_NET_TOT_AST,0)                          --期初净总资产
        ,NVL(a1.STRT_EXG_NET_TOT_AST,0)                      --期初场内净总资产  
        ,NVL(a2.FNL_MKTVAL_HA,0)                             --期末市值_沪A主板  	   	   
        ,NVL(a2.FNL_MKTVAL_SA,0)                             --期末市值_深A主板
        ,NVL(a2.FNL_MKTVAL_SMS,0)                            --期末市值_中小板
        ,NVL(a2.FNL_MKTVAL_GEM,0)                            --期末市值_创业板		 
        ,NVL(a2.FNL_MKTVAL_HB_USD,0)                         --期末市值_沪B_美元
        ,NVL(a2.FNL_MKTVAL_SB_HKD,0)                         --期末市值_深B_港币
        ,NVL(a2.FNL_MKTVAL_HK,0)                             --期末市值_沪港通
        ,NVL(a2.FNL_MKTVAL_SK,0)                             --期末市值_深港通
        ,NVL(a2.FNL_MKTVAL_TA,0)                             --期末市值_三板A股
        ,NVL(a2.FNL_MKTVAL_TU_USD,0)                         --期末市值_三板B股_美元
        ,NVL(a2.FNL_MKTVAL_REPO,0)                           --期末市值_回购
        ,NVL(a2.FNL_MKTVAL_EXG_FND,0)                        --期末市值_场内基金	      		 
        ,NVL(a2.FNL_MKTVAL_CLS_FND,0)                        --期末市值_封闭式基金
        ,NVL(a2.FNL_MKTVAL_ETF_FND,0)                        --期末市值_ETF		
        ,NVL(a2.FNL_MKTVAL_OPN_FND,0)                        --期末市值_开放式
        ,NVL(a2.FNL_MKTVAL_LOF_FND,0)                        --期末市值_LOF	
        ,NVL(a2.FNL_MKTVAL_FOF_FND,0)                        --期末市值_FOF	
        ,NVL(a2.FNL_MKTVAL_BOND,0)                           --期末市值_债券	
        ,NVL(a2.FNL_AGN_FND_MKTVAL,0)                        --期末代销基金市值
        ,NVL(a2.FNL_GS_PROD_MKTVAL,0)                        --期末公司产品市值
        ,NVL(a2.FNL_GJ_PROD_MKTVAL,0)                        --期末国君产品市值        		 	
        ,NVL(a2.FNL_BANK_PROD_MKTVAL,0)                      --期末银行产品市值	 
        ,NVL(a2.FNL_OTC_PROD_MKTVAL,0)                       --期末OTC产品市值    		 
        ,NVL(a2.FNL_WRNT_RGHT_HLD_MKTVAL,0)                  --期末期权账户权利仓市值	
        ,NVL(a2.FNL_WRNT_DUTY_HLD_MKTVAL,0)                  --期末期权账户义务仓市值
        ,NVL(a2.FNL_ORDI_MKTVAL_SEC_USD,0)                   --期末普通账户证券市值_美元	
        ,NVL(a2.FNL_ORDI_MKTVAL_SEC_HKD,0)                   --期末普通账户证券市值_港币	
        ,NVL(a2.FNL_ORDI_MKTVAL_SEC_RMD,0)                   --期末普通账户证券市值_人民币		
        ,NVL(a2.FNL_ORDI_MKTVAL_PROD,0)                      --期末普通账户产品市值			 
        ,NVL(a2.FNL_ORDI_SEC_MKTVAL,0)                       --期末普通账户证券市值(折算人民币)
        ,NVL(a2.FNL_ORDI_MKTVAL,0)                           --期末普通账户市值 
        ,NVL(a2.FNL_ORDI_UN_CIR_MKTVAL,0)                    --期末普通账户非流通市值(折算人民币)       
        ,NVL(a2.FNL_CRD_SEC_MKTVAL,0)                        --期末信用账户证券市值
        ,NVL(a2.FNL_WRNT_MKTVAL,0)                           --期末期权账户市值(权利仓市值-义务仓市值)		
        ,NVL(a2.FNL_WRNT_CNTS,0)                             --期末期权账户张数	
        ,NVL(a2.FNL_TOT_MKTVAL,0)                            --期末总市值		
        ,NVL(a2.FNL_ORDI_CPTL_USD,0)                         --期末普通账户资金_美元	
        ,NVL(a2.FNL_ORDI_CPTL_HKD,0)                         --期末普通账户资金_港币	
        ,NVL(a2.FNL_ORDI_CPTL_RMB,0)                         --期末普通账户资金_人民币		
        ,NVL(a2.FNL_ORDI_CPTL,0)                             --期末普通账户资金(折算人民币)		
        ,NVL(a2.FNL_CRD_CPTL,0)                              --期末信用账户资金
        ,NVL(a2.FNL_WRNT_CPTL,0)                             --期末期权账户资金	
        ,NVL(a2.FNL_TOT_UNPY_CPTL,0)                         --期末总的在途资金		
        ,NVL(a2.FNL_TOT_CPTL,0)                              --期末总资金		 
        ,NVL(a2.FNL_ORDI_GL,0)                               --期末普通账户负债
        ,NVL(a2.FNL_CRD_GL,0)                                --期末信用账户负债 		 
        ,NVL(a2.FNL_TOTGL,0)                                 --期末总负债	 
        ,NVL(a2.FNL_ORDI_AST,0)                              --期末普通资产	  
        ,NVL(a2.FNL_ORDI_NET_AST,0)                          --期末普通净资产
        ,NVL(a2.FNL_CRD_AST,0)                               --期末信用资产	 
        ,NVL(a2.FNL_WRNT_AST,0)                              --期末期权资产
        ,NVL(a2.FNL_TOT_AST,0)                               --期末总资产
        ,NVL(a2.FNL_NET_TOT_AST,0)                           --期末净总资产
        ,NVL(a2.FNL_EXG_NET_TOT_AST,0)                       --期末场内净总资产
        ,NVL(a3.ORDI_DEPIN_AMT_USD,0)                        --普通账户存入金额_美元    	   	   
        ,NVL(a3.ORDI_DEPIN_AMT_HKD,0)                        --普通账户存入金额_港币
        ,NVL(a3.ORDI_DEPIN_AMT_RMB,0)                        --普通账户存入金额_人民币
        ,NVL(a3.ORDI_TFR_IN_AMT,0)                           --普通账户转入金额(折算人民币)
        ,NVL(a3.ORDI_WTHDR_AMT_USD,0)                        --普通账户取出金额_美元
        ,NVL(a3.ORDI_WTHDR_AMT_HKD,0)                        --普通账户取出金额_港币
        ,NVL(a3.ORDI_WTHDR_AMT_RMB,0)                        --普通账户取出金额_人民币
        ,NVL(a3.ORDI_TFR_OUT_AMT,0)                          --普通账户转出金额(折算人民币)
        ,NVL(a3.CRD_DEPIN_AMT,0)                             --信用账户存入金额
        ,NVL(a3.CRD_TFR_IN_AMT,0)                            --信用账户转入金额
        ,NVL(a3.CRD_WTHDR_AMT,0)                             --信用账户取出金额
        ,NVL(a3.CRD_TFR_OUT_AMT,0)                           --信用账户转出金额
        ,NVL(a3.WRNT_DEPIN_AMT,0)                            --期权账户存入金额
        ,NVL(a3.WRNT_TFR_IN_AMT,0)                           --期权账户转入金额
        ,NVL(a3.WRNT_WTHDR_AMT,0)                            --期权账户取出金额
        ,NVL(a3.WRNT_TFR_OUT_AMT,0)                          --期权账户转出金额
        ,NVL(a3.TFR_IN_AMT,0)                                --转入资金
        ,NVL(a3.TFR_OUT_AMT,0)                               --转出资金
        ,NVL(a3.ORDI_NET_TFR_IN_AMT,0)                       --普通账户净转入资金
        ,NVL(a3.CRD_NET_TFR_IN_AMT,0)                        --信用账户净转入资金
        ,NVL(a3.WRNT_NET_TFR_IN_AMT,0)                       --期权账户净转入资金
        ,NVL(a3.NET_TFR_IN_AMT,0)                            --净转入资金
        ,NVL(a3.ORDI_ASGN_TFR_IN_MKTVAL_RMB,0)               --普通账户指定转入市值_人民币
        ,NVL(a3.ORDI_ASGN_TFR_IN_MKTVAL_USD,0)               --普通账户指定转入市值_美元
        ,NVL(a3.ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB,0)           --普通账户转托管转入市值_人民币
        ,NVL(a3.ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD,0)           --普通账户转托管转入市值_港币
        ,NVL(a3.CRD_ASGN_TFR_IN_MKTVAL,0)                    --信用账户指定转入市值		
        ,NVL(a3.CRD_TFR_CSTD_TFR_IN_MKTVAL,0)                --信用账户转托管转入市值
        ,NVL(a3.ORDI_ASGN_TFR_OUT_MKTVAL_RMB,0)              --普通账户撤指定转出市值_人民币
        ,NVL(a3.ORDI_ASGN_TFR_OUT_MKTVAL_USD,0)              --普通账户撤指定转出市值_美元
        ,NVL(a3.ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB,0)          --普通账户转托管转出市值_人民币
        ,NVL(a3.ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD,0)          --普通账户转托管转出市值_港币
        ,NVL(a3.CRD_ASGN_TFR_OUT_MKTVAL,0)                   --信用账户指定转出市值		
        ,NVL(a3.CRD_TFR_CSTD_TFR_OUT_MKTVAL,0)               --信用账户转托管转出市值
        ,NVL(a3.ORDI_TFR_IN_MKTVAL,0)                        --普通账户转入市值
        ,NVL(a3.ORDI_TFR_OUT_MKTVAL,0)                       --普通账户转出市值
        ,NVL(a3.CRD_TFR_IN_MKTVAL,0)                         --信用账户转入市值
        ,NVL(a3.CRD_TFR_OUT_MKTVAL,0)                        --信用账户转出市值
        ,NVL(a3.TFR_IN_MKTVAL,0)                             --转入市值
        ,NVL(a3.TFR_OUT_MKTVAL,0)                            --转出市值
        ,NVL(a3.ORDI_NET_TFR_IN_MKTVAL,0)                    --普通账户净转入市值
        ,NVL(a3.CRD_NET_TFR_IN_MKTVAL,0)                     --信用账户净转入市值
        ,NVL(a3.NET_TFR_IN_MKTVAL,0)                         --净转入市值		        
        ,NVL(a3.ORDI_PRFT,0)                                 --普通盈亏
        ,NVL(a3.CRD_PRFT,0)                                  --信用盈亏
        ,NVL(a3.WRNT_PRFT,0)                                 --期权盈亏
        ,NVL(a3.TOT_PRFT,0)                                  --总盈亏
        ,NVL(a3.AVGDLY_ORDI_CPTL,0)                          --日均普通账户资金
        ,NVL(a3.AVGDLY_CRD_CPTL,0)                           --日均信用账户资金
        ,NVL(a3.AVGDLY_WRNT_CPTL,0)                          --日均期权账户资金
        ,NVL(a3.AVGDLY_TOT_CPTL,0)                           --日均总资金		  
        ,NVL(a3.MAX_ORDI_CPTL,0)                             --当月普通账户最大资金
        ,NVL(a3.MAX_CRD_CPTL,0)                              --当月信用账户最大资金
        ,NVL(a3.MAX_WRNT_CPTL,0)                             --当月期权账户最大资金
        ,NVL(a3.MAX_TOT_CPTL,0)                              --当月最大总资金
        ,NVL(a3.MIN_ORDI_CPTL,0)                             --当月普通账户最小资金
        ,NVL(a3.MIN_CRD_CPTL,0)                              --当月信用账户最小资金
        ,NVL(a3.MIN_WRNT_CPTL,0)                             --当月期权账户最小资金
        ,NVL(a3.MIN_TOT_CPTL,0)                              --当月最小总资金		  
        ,NVL(a3.AVGDLY_ORDI_MKTVAL,0)                        --日均普通账户市值
        ,NVL(a3.AVGDLY_CRD_MKTVAL,0)                         --日均信用账户市值
        ,NVL(a3.AVGDLY_WRNT_MKTVAL,0)                        --日均期权账户市值
        ,NVL(a3.AVGDLY_TOT_MKTVAL,0)                         --日均总市值		  
        ,NVL(a3.MAX_ORDI_MKTVAL,0)                           --当月普通账户最大市值
        ,NVL(a3.MAX_CRD_MKTVAL,0)                            --当月信用账户最大市值
        ,NVL(a3.MAX_WRNT_MKTVAL,0)                           --当月期权账户最大市值
        ,NVL(a3.MAX_TOT_MKTVAL,0)                            --当月最大总市值	
        ,NVL(a3.MIN_ORDI_MKTVAL,0)                           --当月普通账户最小市值
        ,NVL(a3.MIN_CRD_MKTVAL,0)                            --当月信用账户最小市值
        ,NVL(a3.MIN_WRNT_MKTVAL,0)                           --当月期权账户最小市值
        ,NVL(a3.MIN_TOT_MKTVAL,0)                            --当月最小总市值          	
        ,NVL(a3.AVGDLY_ORDI_GL,0)                            --日均普通账户负债
        ,NVL(a3.AVGDLY_CRD_GL,0)                             --日均信用账户负债
        ,NVL(a3.AVGDLY_TOTGL,0)                              --日均总负债
        ,NVL(a3.MAX_ORDI_GL,0)                               --当月普通账户最大负债
        ,NVL(a3.MAX_CRD_GL,0)                                --当月信用账户最大负债
        ,NVL(a3.MAX_TOTGL,0)                                 --当月最大总负债
        ,NVL(a3.MIN_ORDI_GL,0)                               --当月普通账户最小负债
        ,NVL(a3.MIN_CRD_GL,0)                                --当月信用账户最小负债
        ,NVL(a3.MIN_TOTGL,0)                                 --当月最小总负债
        ,NVL(a3.AVGDLY_ORDI_AST,0)                           --日均普通账户资产
        ,NVL(a3.AVGDLY_CRD_AST,0)                            --日均信用账户资产
        ,NVL(a3.AVGDLY_WRNT_AST,0)                           --日均期权账户资产
        ,NVL(a3.AVGDLY_TOT_AST,0)                            --日均总资产
        ,NVL(a3.MAX_ORDI_AST,0)                              --当月普通账户最大资产
        ,NVL(a3.MAX_CRD_AST,0)                               --当月信用账户最大资产
        ,NVL(a3.MAX_WRNT_AST,0)                              --当月期权账户最大资产
        ,NVL(a3.MAX_TOT_AST,0)                               --当月最大总资产
        ,NVL(a3.MIN_ORDI_AST,0)                              --当月普通账户最小资产
        ,NVL(a3.MIN_CRD_AST,0)                               --当月信用账户最小资产
        ,NVL(a3.MIN_WRNT_AST,0)                              --当月期权账户最小资产
        ,NVL(a3.MIN_TOT_AST,0)                               --当月最小总资产		  
        ,NVL(a3.AVGDLY_ORDI_NET_AST,0)                       --日均普通账户净资产
        ,NVL(a3.AVGDLY_CRD_NET_AST,0)                        --日均信用账户净资产
        ,NVL(a3.AVGDLY_WRNT_NET_AST,0)                       --日均期权账户净资产
        ,NVL(a3.AVGDLY_TOT_NET_AST,0)                        --日均总净资产
        ,NVL(a3.MAX_ORDI_NET_AST,0)                          --当月普通账户最大净资产
        ,NVL(a3.MAX_CRD_NET_AST,0)                           --当月信用账户最大净资产
        ,NVL(a3.MAX_WRNT_NET_AST,0)                          --当月期权账户最大净资产
        ,NVL(a3.MAX_TOT_NET_AST,0)                           --当月最大总净资产
        ,NVL(a3.MIN_ORDI_NET_AST,0)                          --当月普通账户最小净资产
        ,NVL(a3.MIN_CRD_NET_AST,0)                           --当月信用账户最小净资产
        ,NVL(a3.MIN_WRNT_NET_AST,0)                          --当月期权账户最小净资产
        ,NVL(a3.MIN_TOT_NET_AST,0)                           --当月最小总净资产		  
        ,NVL(a3.AVGDLY_EXG_NET_TOT_AST,0)                    --日均场内总净资产		  
        ,NVL(a3.MAX_EXG_NET_TOT_AST,0)                       --当月场内最大总净资产
        ,NVL(a3.MIN_EXG_NET_TOT_AST,0)                       --当月场内最小总净资产
        ,NVL(a4.AVGDLY_ORDI_CPTL1,0)                         --自然日日均普通账户资金
        ,NVL(a4.AVGDLY_CRD_CPTL1,0)                          --自然日日均信用账户资金
        ,NVL(a4.AVGDLY_WRNT_CPTL1,0)                         --自然日日均期权账户资金
        ,NVL(a4.AVGDLY_CPTL1,0)                              --自然日日均资金
        ,%d{yyyyMMdd}              as ETL_DT
        ,NVL(a1.STRT_ORDI_MKTVAL_NEW_TA,0)                   --期初普通账户市值_新三板A股
        ,NVL(a1.STRT_STK_PLG_AMT,0)                          --期初股票质押余额 		
        ,NVL(a1.STRT_MIN_STK_PLG_AMT,0)                      --期初小微贷余额			
        ,NVL(a2.FNL_ORDI_MKTVAL_NEW_TA,0)                    --期末普通账户市值_新三板A股		
        ,NVL(a2.FNL_STK_PLG_AMT,0)                           --期末股票质押余额		
        ,NVL(a2.FNL_MIN_STK_PLG_AMT,0)                       --期末小微贷余额		
        ,NVL(a3.STK_PLG_ADD_INT,0)                           --股票质押新增利息		
        ,NVL(a3.STK_PLG_ADD_TRD_AMT,0)                       --股票质押初始交易量		
        ,NVL(a3.MIN_STK_PLG_ADD_INT,0)                       --小微贷新增利息
        ,NVL(a3.MIN_STK_PLG_ADD_TRD_AMT,0)                   --小微贷初始交易量	
        ,NVL(a4.AVGDLY_STK_PLG_AMT,0)                        --自然日日均股票质押余额
        ,NVL(a4.AVGDLY_MIN_STK_PLG_AMT,0)                    --自然日日均小微贷余额		
        ,NVL(a1.STRT_ORDI_MKTVAL_EXG_FND_SH,0)                --期初普通账户市值_场内基金_沪市
        ,NVL(a1.STRT_ORDI_MKTVAL_EXG_FND_SZ,0)                --期初普通账户市值_场内基金_深市
        ,NVL(a1.STRT_CRD_MKTVAL_EXG_FND_SH,0)                 --期初信用账户市值_场内基金_沪市
        ,NVL(a1.STRT_CRD_MKTVAL_EXG_FND_SZ,0)                 --期初信用账户市值_场内基金_深市
        ,NVL(a1.STRT_ORDI_MKTVAL_BOND_SH,0)                   --期初普通账户市值_债券_沪市
        ,NVL(a1.STRT_ORDI_MKTVAL_BOND_SZ,0)                   --期初普通账户市值_债券_深市
        ,NVL(a1.STRT_CRD_MKTVAL_BOND_SH,0)                    --期初信用账户市值_债券_沪市
        ,NVL(a1.STRT_CRD_MKTVAL_BOND_SZ,0)                    --期初信用账户市值_债券_深市
        ,NVL(a1.STRT_ORDI_UN_CIR_MKTVAL_SH,0)                 --期初普通账户沪市非流通市值(折算人民币)
        ,NVL(a1.STRT_ORDI_UN_CIR_MKTVAL_SZ,0)                 --期初普通账户深市非流通市值(折算人民币)
        ,NVL(a1.STRT_ORDI_MKTVAL_AK_STIB,0)                   --期初普通账户市值_AK科创板
        ,NVL(a1.STRT_ORDI_MKTVAL_RK_STIB,0)                   --期初普通账户市值_RK科创CDR
        ,NVL(a1.STRT_CRD_MKTVAL_AK_STIB,0)                    --期初信用账户市值_AK科创板
        ,NVL(a1.STRT_CRD_MKTVAL_RK_STIB,0)                    --期初信用账户市值_RK科创CDR
        ,NVL(a2.FNL_ORDI_MKTVAL_EXG_FND_SH,0)                 --期末普通账户市值_场内基金_沪市
        ,NVL(a2.FNL_ORDI_MKTVAL_EXG_FND_SZ,0)                            --期末普通账户市值_场内基金_深市
        ,NVL(a2.FNL_CRD_MKTVAL_EXG_FND_SH,0)                             --期末信用账户市值_场内基金_沪市
        ,NVL(a2.FNL_CRD_MKTVAL_EXG_FND_SZ,0)                             --期末信用账户市值_场内基金_深市
        ,NVL(a2.FNL_ORDI_MKTVAL_BOND_SH,0)                               --期末普通账户市值_债券_沪市
        ,NVL(a2.FNL_ORDI_MKTVAL_BOND_SZ,0)                               --期末普通账户市值_债券_深市
        ,NVL(a2.FNL_CRD_MKTVAL_BOND_SH,0)                                --期末信用账户市值_债券_沪市
        ,NVL(a2.FNL_CRD_MKTVAL_BOND_SZ,0)                                --期末信用账户市值_债券_深市
        ,NVL(a2.FNL_ORDI_UN_CIR_MKTVAL_SH,0)                             --期末普通账户沪市非流通市值(折算人民币)
        ,NVL(a2.FNL_ORDI_UN_CIR_MKTVAL_SZ,0)                             --期末普通账户深市非流通市值(折算人民币)
        ,NVL(a2.FNL_ORDI_MKTVAL_AK_STIB,0)                               --期末普通账户市值_AK科创板
        ,NVL(a2.FNL_ORDI_MKTVAL_RK_STIB,0)                               --期末普通账户市值_RK科创CDR
        ,NVL(a2.FNL_CRD_MKTVAL_AK_STIB,0)                                --期末信用账户市值_AK科创板
        ,NVL(a2.FNL_CRD_MKTVAL_RK_STIB,0)                                --期末信用账户市值_RK科创CDR  
   		,NVL(a1.STRT_WRNT_RGHT_HLD_MKTVAL_SH,0)                         --期初期权账户权利仓市值(SH)
        ,NVL(a1.STRT_WRNT_DUTY_HLD_MKTVAL_SH,0)                         --期初期权账户义务仓市值(SH)      
        ,NVL(a1.STRT_WRNT_MKTVAL_SH,0)                                  --期初期权账户市值(权利仓市值-义务仓市值)(SH)	
        ,NVL(a1.STRT_WRNT_CNTS_SH,0)                                    --期初期权张数(SH)
        ,NVL(a1.STRT_WRNT_RGHT_HLD_MKTVAL_SZ,0)                         --期初期权账户权利仓市值(SZ)
        ,NVL(a1.STRT_WRNT_DUTY_HLD_MKTVAL_SZ,0)                         --期初期权账户义务仓市值(SZ)      
        ,NVL(a1.STRT_WRNT_MKTVAL_SZ,0)                                  --期初期权账户市值(权利仓市值-义务仓市值)(SZ)	
        ,NVL(a1.STRT_WRNT_CNTS_SZ,0)                                    --期初期权张数(SZ)
        ,NVL(a2.FNL_WRNT_RGHT_HLD_MKTVAL_SH,0)                          --期末期权账户权利仓市值(SH)
        ,NVL(a2.FNL_WRNT_DUTY_HLD_MKTVAL_SH,0)                          --期末期权账户义务仓市值(SH)      
        ,NVL(a2.FNL_WRNT_MKTVAL_SH,0)                                   --期末期权账户市值(权利仓市值-义务仓市值)(SH)	
        ,NVL(a2.FNL_WRNT_CNTS_SH,0)                                     --期末期权张数(SH)
        ,NVL(a2.FNL_WRNT_RGHT_HLD_MKTVAL_SZ,0)                          --期末期权账户权利仓市值(SZ)
        ,NVL(a2.FNL_WRNT_DUTY_HLD_MKTVAL_SZ,0)                          --期末期权账户义务仓市值(SZ)      
        ,NVL(a2.FNL_WRNT_MKTVAL_SZ,0)                                   --期末期权账户市值(权利仓市值-义务仓市值)(SZ)	
        ,NVL(a2.FNL_WRNT_CNTS_SZ,0)                                     --期末期权张数(SZ)
    FROM (SELECT CUST_NO,BRH_NO,CUST_CGY 
          FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO 
   	   WHERE BUS_DATE = %d{yyyyMMdd}
   	   )                                        t
    LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP   a1
 ON        t.CUST_NO = a1.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP1   a2
 ON        t.CUST_NO = a2.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP2   a3
 ON        t.CUST_NO = a3.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP3   a4
 ON        t.CUST_NO = a4.CUST_NO
 WHERE  COALESCE(a1.CUST_NO,a2.CUST_NO,a3.CUST_NO,a4.CUST_NO) IS NOT NULL ;
 
 ----删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP  ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP1 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP2 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON_TEMP3 ;
 
-----------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_AST_CUST_AST_AGGR_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_MON;
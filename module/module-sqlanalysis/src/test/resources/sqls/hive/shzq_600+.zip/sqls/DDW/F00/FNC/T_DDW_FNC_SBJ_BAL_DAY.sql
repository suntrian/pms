 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:财务科目余额日表                                                         */
  --/* 创建人:程骏                                                                              */
  --/* 创建时间:2017-08-28                                                                        */
  

TRUNCATE TABLE DDW_PROD.T_DDW_FNC_SBJ_BAL_DAY ;
--------------插入数据-------------
INSERT overwrite DDW_PROD.T_DDW_FNC_SBJ_BAL_DAY
( 
	BAL_ID			--余额主键
	,FNC_SBJ_ID		--科目主键
	,CCY_CD			--币种代码
	,ORG_CD			--机构代码
	,FNC_SBJ_CD		--财务科目编码
	,ACTBOOK_CD		--账簿编码
	,IOC_LND_AMT	--原币贷发生额
	,IOC_BROW_AMT	--原币借发生额
	,LC_LND_AMT		--本币贷发生额
	,LC_BROW_AMT	--本币借发生额
	,YEAR_MON			--年月
	,ACG_CNTT_CODE   --核算内容编码
	,ACG_CNTT_NAME   --核算内容名称
) 
 partition(BUS_DATE = %d{yyyyMMdd})
  SELECT 
	t.PK_BALANCE 
	,t.PK_ACCSUBJ
	,t.PK_CURRTYPE
	,t.PK_GLORGBOOK
	,a2.SUBJCODE
	,a1.GLORGBOOKCODE
	,t.CREDITAMOUNT
	,t.DEBITAMOUNT
	,t.LOCALCREDITAMOUNT
	,t.LOCALDEBITAMOUNT
	--,CONCAT(t.YEAR,t.period)
	,cast(CONCAT(t.YEAR,t.period) as int)
	,a3.valuecode
	,a3.valuename
 FROM         EDW_PROD.T_EDW_T06_GL_BALANCE      t
 LEFT JOIN    EDW_PROD.T_EDW_T06_BD_GLORGBOOK    a1 
 ON           t.PK_GLORGBOOK = a1.PK_GLORGBOOK
 AND          t.BUS_DATE = a1.BUS_DATE
 LEFT JOIN    EDW_PROD.T_EDW_T06_BD_ACCSUBJ a2 
 ON           t.PK_ACCSUBJ = a2.PK_ACCSUBJ
 AND          t.BUS_DATE = a2.BUS_DATE
 LEFT JOIN    EDW_PROD.T_EDW_T06_GL_FREEVALUE a3
 ON           t.ASSID = a3.freevalueid 
 AND          a3.assindex = 0
 AND          t.BUS_DATE = a3.BUS_DATE	
 WHERE        t.DR = 0 
 AND          t.BUS_DATE  = %d{yyyyMMdd}
 ;
 --AND           CONCAT(t.YEAR,t.period)  = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6);


--------------插入数据结束--------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_FNC_SBJ_BAL_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_FNC_SBJ_BAL_DAY;
 /* ***************************************** SQL Begin ***************************************** */
 /* 脚本功能:员工营业部指标月表                                                         */
 /* 创建人:黄勇华                                                                                 */
 /* 创建时间:2019-03-26                                                                         */
ALTER TABLE DDW_PROD.T_DDW_F20_STFF_BRH_NO_IDX_MON DROP IF EXISTS PARTITION   (YEAR_MON = CAST(SUBSTR('20190326',1,6) as INT));
 
 
				 
   INSERT OVERWRITE DDW_PROD.T_DDW_F20_STFF_BRH_NO_IDX_MON
   ( BELTO_FILIL_CDG      --分公司编码
   , BELTO_FILIL          --分公司名称
   , BRH_NO               --营业部编码
   , BRH_FULLNM           --营业部名称	
   , CUST_RLN_TYPE        --客户关系类型
   , IDX_CDG              --指标编码
   , IDX_NAME             --指标名称
   , IDX_VAL              --指标值    
   )PARTITION( YEAR_MON )
   SELECT  BELTO_FILIL_CDG      --分公司编码
         , BELTO_FILIL          --分公司名称
         , BRH_NO               --营业部编码
         , BRH_FULLNM           --营业部名称	 
         , CUST_RLN_TYPE        --客户关系类型
         , IDX_CDG              --指标编码
         , IDX_NAME             --指标名称
         , SUM(IDX_VAL)              --指标值 
		 ,YEAR_MON
   FROM DDW_PROD.T_DDW_F10_STFF_IDX_MON
   GROUP BY   BELTO_FILIL_CDG 
            , BELTO_FILIL     
            , BRH_NO          
            , BRH_FULLNM      
            , CUST_RLN_TYPE   
            , IDX_CDG         
            , IDX_NAME  
,YEAR_MON ;
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_STFF_BRH_NO_IDX_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F20_STFF_BRH_NO_IDX_MON;			
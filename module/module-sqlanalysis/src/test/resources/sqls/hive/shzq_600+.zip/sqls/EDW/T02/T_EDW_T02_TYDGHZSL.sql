 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:约定回购折算率表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
   TRUNCATE TABLE EDW_PROD.T_EDW_T02_TYDGHZSL;
-------插入数据开始---------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TYDGHZSL
(
                                    JYS                                 --交易所                                
                                   ,ZQFL                                --证券分类                               
                                   ,TS                                  --天数                                 
                                   ,ZQLBMC                              --证券类别名称                             
                                   ,ZSL                                 --折算率                                
                                   ,FDLL                                --浮动利率                               
                                   ,RQ                                  --日期  
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.ZQFL                                as ZQFL                                --证券分类                                
                                   ,t.TS                                  as TS                                  --天数                                  
                                   ,t.ZQLBMC                              as ZQLBMC                              --证券类别名称                              
                                   ,t.ZSL                                 as ZSL                                 --折算率                                 
                                   ,t.FDLL                                as FDLL                                --浮动利率                                
                                   ,t.RQ                                  as RQ                                  --日期 
                                   ,'JZJY'                                as XTBS								   
 FROM        JZJYCX.SECURITIES_TYDGHZSL t
 WHERE       t.DT = '%d{yyyyMMdd}';
-----插入数据结束----------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TYDGHZSL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TYDGHZSL;
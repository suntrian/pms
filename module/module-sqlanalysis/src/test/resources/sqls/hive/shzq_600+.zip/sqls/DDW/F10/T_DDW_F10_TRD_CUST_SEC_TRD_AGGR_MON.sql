------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户证券交易汇总月表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
  

 

------插入数据
  INSERT OVERWRITE DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_MON
(
                 CUST_NO                          --客户号                 
                ,BRH_NO                           --营业部编号         
                ,EXG                              --交易所
                ,CUST_CGY				          --客户类别
                ,ASTK_BUYIN_MTCH_AMT              --A股买入成交金额
                ,ASTK_SELL_MTCH_AMT               --A股卖出成交金额
                ,ASTK_MTCH_AMT                    --A股成交金额
                ,BSTK_BUYIN_MTCH_AMT_RMB          --B股买入成交金额
                ,BSTK_SELL_MTCH_AMT_RMB           --B股卖出成交金额
                ,BSTK_MTCH_AMT_RMB                --B股成交金额
                ,BSTK_BUYIN_MTCH_AMT_USD          --B股美元买入成交金额
                ,BSTK_SELL_MTCH_AMT_USD           --B股美元卖出成交金额
                ,BSTK_MTCH_AMT_USD                --B股美元成交金额
                ,BSTK_BUYIN_MTCH_AMT_HKD          --B股港币买入成交金额
                ,BSTK_SELL_MTCH_AMT_HKD           --B股港币卖出成交金额
                ,BSTK_MTCH_AMT_HKD                --B股港币成交金额
                ,GEM_BUYIN_MTCH_AMT               --创业板买入成交金额
                ,GEM_SELL_MTCH_AMT                --创业板卖出成交金额
                ,GEM_MTCH_AMT                     --创业板成交金额
                ,OLD_T3BOD_BUYIN_MTCH_AMT         --老三板买入成交金额
                ,OLD_T3BOD_SELL_MTCH_AMT          --老三板卖出成交金额
                ,OLD_T3BOD_MTCH_AMT               --老三板成交金额
                ,OLD_T3BOD_BUYIN_MTCH_AMT_USD     --老三板美元买入成交金额
                ,OLD_T3BOD_SELL_MTCH_AMT_USD      --老三板美元卖出成交金额
                ,OLD_T3BOD_MTCH_AMT_USD           --老三板美元成交金额
                ,NEW_T3BOD_BUYIN_MTCH_AMT         --新三板买入成交金额
                ,NEW_T3BOD_SELL_MTCH_AMT          --新三板卖出成交金额
                ,NEW_T3BOD_MTCH_AMT               --新三板成交金额
                ,QOT_REPO_MRGNS_AMT               --报价回购融券金额
                ,ORDI_REPO_MRGNS_AMT              --普通回购融券金额
                ,ORDI_REPO_MRGNC_AMT              --普通回购融资金额
                ,HK_STK_BUYIN_MTCH_AMT            --港股买入成交金额
                ,HK_STK_SELL_MTCH_AMT             --港股卖出成交金额
                ,HK_STK_MTCH_AMT                  --港股成交金额
                ,BOND_BUYIN_MTCH_AMT              --债券买入成交金额
                ,BOND_SELL_MTCH_AMT               --债券卖出成交金额
                ,BOND_MTCH_AMT                    --债券成交金额
                ,EXG_FND_SCRP_MTCH_AMT            --场内基金认购成交金额				
                ,EXG_FND_BUYIN_MTCH_AMT           --场内基金买入成交金额
                ,EXG_FND_SELL_MTCH_AMT            --场内基金卖出成交金额
                ,EXG_FND_MTCH_AMT                 --场内基金成交金额
				,ASTK_BUYIN_MTCH_QTY              --A股买入成交数量
                ,ASTK_SELL_MTCH_QTY               --A股卖出成交数量
                ,ASTK_MTCH_QTY                    --A股成交数量
                ,BSTK_BUYIN_MTCH_QTY              --B股买入成交数量
                ,BSTK_SELL_MTCH_QTY               --B股卖出成交数量
                ,BSTK_MTCH_QTY                    --B股成交数量	
                ,GEM_BUYIN_MTCH_QTY               --创业板买入成交数量
                ,GEM_SELL_MTCH_QTY                --创业板卖出成交数量
                ,GEM_MTCH_QTY                     --创业板成交数量
                ,OLD_T3BOD_BUYIN_MTCH_QTY         --老三板买入成交数量
                ,OLD_T3BOD_SELL_MTCH_QTY          --老三板卖出成交数量
                ,OLD_T3BOD_MTCH_QTY               --老三板成交数量		
                ,NEW_T3BOD_BUYIN_MTCH_QTY         --新三板买入成交数量
                ,NEW_T3BOD_SELL_MTCH_QTY          --新三板卖出成交数量
                ,NEW_T3BOD_MTCH_QTY               --新三板成交数量
                ,QOT_REPO_MRGNS_MTCH_QTY          --报价回购融券成交数量
                ,ORDI_REPO_MRGNS_MTCH_QTY         --普通回购融券成交数量
                ,ORDI_REPO_MRGNC_MTCH_QTY         --普通回购融资成交数量
                ,HK_STK_BUYIN_MTCH_QTY            --港股买入成交数量
                ,HK_STK_SELL_MTCH_QTY             --港股卖出成交数量
                ,HK_STK_MTCH_QTY                  --港股成交数量
                ,BOND_BUYIN_MTCH_QTY              --债券买入成交数量
                ,BOND_SELL_MTCH_QTY               --债券卖出成交数量
                ,BOND_MTCH_QTY                    --债券成交数量
				,EXG_FND_SCRP_MTCH_QTY            --场内基金认购成交数量
                ,EXG_FND_BUYIN_MTCH_QTY           --场内基金买入成交数量
                ,EXG_FND_SELL_MTCH_QTY            --场内基金卖出成交数量
                ,EXG_FND_MTCH_QTY                 --场内基金成交数量                             
			    ,ASTK_BUYIN_S1                    --A股买入毛佣金
                ,ASTK_SELL_S1                     --A股卖出毛佣金
                ,ASTK_S1                          --A股毛佣金
                ,BSTK_BUYIN_S1_RMB                --B股买入毛佣金
                ,BSTK_SELL_S1_RMB                 --B股卖出毛佣金
                ,BSTK_S1_RMB                      --B股毛佣金
                ,BSTK_BUYIN_S1_USD                --B股美元买入毛佣金
                ,BSTK_SELL_S1_USD                 --B股美元卖出毛佣金
                ,BSTK_S1_USD                      --B股美元毛佣金
                ,BSTK_BUYIN_S1_HKD                --B股港币买入毛佣金
                ,BSTK_SELL_S1_HKD                 --B股港币卖出毛佣金
                ,BSTK_S1_HKD                      --B股港币毛佣金
                ,GEM_BUYIN_S1                     --创业板买入毛佣金
                ,GEM_SELL_S1                      --创业板卖出毛佣金
                ,GEM_S1                           --创业板毛佣金
                ,OLD_T3BOD_BUYIN_S1               --老三板买入毛佣金
                ,OLD_T3BOD_SELL_S1                --老三板卖出毛佣金
                ,OLD_T3BOD_S1                     --老三板毛佣金
                ,OLD_T3BOD_BUYIN_S1_USD           --老三板美元买入毛佣金
                ,OLD_T3BOD_SELL_S1_USD            --老三板美元卖出毛佣金
                ,OLD_T3BOD_S1_USD                 --老三板美元毛佣金
                ,NEW_T3BOD_BUYIN_S1               --新三板买入毛佣金
                ,NEW_T3BOD_SELL_S1                --新三板卖出毛佣金
                ,NEW_T3BOD_S1                     --新三板毛佣金
                ,QOT_REPO_MRGNS_S1                --报价回购融券毛佣金
                ,ORDI_REPO_MRGNS_S1               --普通回购融券毛佣金
                ,ORDI_REPO_MRGNC_S1               --普通回购融资毛佣金
                ,HK_STK_BUYIN_S1                  --港股买入毛佣金
                ,HK_STK_SELL_S1                   --港股卖出毛佣金
                ,HK_STK_S1                        --港股毛佣金
                ,BOND_BUYIN_S1                    --债券买入毛佣金
                ,BOND_SELL_S1                     --债券卖出毛佣金
                ,BOND_S1                          --债券毛佣金
                ,EXG_FND_BUYIN_S1                 --场内基金买入毛佣金
                ,EXG_FND_SELL_S1                  --场内基金卖出毛佣金
                ,EXG_FND_S1                       --场内基金毛佣金
                ,ASTK_BUYIN_NET_S1                --A股买入净佣金
                ,ASTK_SELL_NET_S1                 --A股卖出净佣金
                ,ASTK_NET_S1                      --A股净佣金
                ,BSTK_BUYIN_NET_S1_RMB            --B股买入净佣金
                ,BSTK_SELL_NET_S1_RMB             --B股卖出净佣金
                ,BSTK_NET_S1_RMB                  --B股净佣金
                ,BSTK_BUYIN_NET_S1_USD            --B股美元买入净佣金
                ,BSTK_SELL_NET_S1_USD             --B股美元卖出净佣金
                ,BSTK_NET_S1_USD                  --B股美元净佣金
                ,BSTK_BUYIN_NET_S1_HKD            --B股港币买入净佣金
                ,BSTK_SELL_NET_S1_HKD             --B股港币卖出净佣金
                ,BSTK_NET_S1_HKD                  --B股港币净佣金
                ,GEM_BUYIN_NET_S1                 --创业板买入净佣金
                ,GEM_SELL_NET_S1                  --创业板卖出净佣金
                ,GEM_NET_S1                       --创业板净佣金
                ,OLD_T3BOD_BUYIN_NET_S1           --老三板买入净佣金
                ,OLD_T3BOD_SELL_NET_S1            --老三板卖出净佣金
                ,OLD_T3BOD_NET_S1                 --老三板净佣金
                ,OLD_T3BOD_BUYIN_NET_S1_USD       --老三板美元买入净佣金
                ,OLD_T3BOD_SELL_NET_S1_USD        --老三板美元卖出净佣金
                ,OLD_T3BOD_NET_S1_USD             --老三板美元净佣金
                ,NEW_T3BOD_BUYIN_NET_S1           --新三板买入净佣金
                ,NEW_T3BOD_SELL_NET_S1            --新三板卖出净佣金
                ,NEW_T3BOD_NET_S1                 --新三板净佣金
                ,QOT_REPO_MRGNS_NET_S1            --报价回购融券净佣金
                ,ORDI_REPO_MRGNS_NET_S1           --普通回购融券净佣金
                ,ORDI_REPO_MRGNC_NET_S1           --普通回购融额净佣金
                ,HK_STK_BUYIN_NET_S1              --港股买入净佣金
                ,HK_STK_SELL_NET_S1               --港股卖出净佣金
                ,HK_STK_NET_S1                    --港股净佣金
                ,BOND_BUYIN_NET_S1                --债券买入净佣金
                ,BOND_SELL_NET_S1                 --债券卖出净佣金
                ,BOND_NET_S1                      --债券净佣金
                ,EXG_FND_BUYIN_NET_S1             --场内基金买入净佣金
                ,EXG_FND_SELL_NET_S1              --场内基金卖出净佣金
                ,EXG_FND_NET_S1                   --场内基金净佣金               
			    ,ASTK_BUYIN_MTCH_ITMS             --A股买入成交笔数
                ,ASTK_SELL_MTCH_ITMS              --A股卖出成交笔数
                ,ASTK_MTCH_ITMS                   --A股成交笔数
                ,BSTK_BUYIN_MTCH_ITMS         --B股买入成交笔数
                ,BSTK_SELL_MTCH_ITMS          --B股卖出成交笔数
                ,BSTK_MTCH_ITMS               --B股成交笔数	
                ,GEM_BUYIN_MTCH_ITMS              --创业板买入成交笔数
                ,GEM_SELL_MTCH_ITMS               --创业板卖出成交笔数
                ,GEM_MTCH_ITMS                    --创业板成交笔数
                ,OLD_T3BOD_BUYIN_MTCH_ITMS        --老三板买入成交笔数
                ,OLD_T3BOD_SELL_MTCH_ITMS         --老三板卖出成交笔数
                ,OLD_T3BOD_MTCH_ITMS              --老三板成交笔数		
                ,NEW_T3BOD_BUYIN_MTCH_ITMS        --新三板买入成交笔数
                ,NEW_T3BOD_SELL_MTCH_ITMS         --新三板卖出成交笔数
                ,NEW_T3BOD_MTCH_ITMS              --新三板成交笔数
                ,QOT_REPO_MRGNS_MTCH_ITMS         --报价回购融券成交笔数
                ,ORDI_REPO_MRGNS_MTCH_ITMS        --普通回购融券成交笔数
                ,ORDI_REPO_MRGNC_MTCH_ITMS        --普通回购融资成交笔数
                ,HK_STK_BUYIN_MTCH_ITMS           --港股买入成交笔数
                ,HK_STK_SELL_MTCH_ITMS            --港股卖出成交笔数
                ,HK_STK_MTCH_ITMS                 --港股成交笔数
                ,BOND_BUYIN_MTCH_ITMS             --债券买入成交笔数
                ,BOND_SELL_MTCH_ITMS              --债券卖出成交笔数
                ,BOND_MTCH_ITMS                   --债券成交笔数
				,EXG_FND_SCRP_MTCH_ITMS           --场内基金认购成交笔数
                ,EXG_FND_BUYIN_MTCH_ITMS          --场内基金买入成交笔数
                ,EXG_FND_SELL_MTCH_ITMS           --场内基金卖出成交笔数
                ,EXG_FND_MTCH_ITMS                --场内基金成交笔数
				,SEC_TFR_IN_MKTVAL                --证券转入市值  
                ,SEC_TFR_OUT_MKTVAL               --证券转入市值 
                ,SEC_NET_TFR_IN_MKTVAL            --证券净转入市值 	
                ,ACCNT_CGY	                      --账户类别	
                ,ETL_DT		                      --加载日期		
 ) partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT          CUST_NO                            as CUST_NO                         --客户号                 
                ,BRH_NO                             as BRH_NO                          --营业部编号         
                ,EXG                                as EXG                             --交易所
                ,CUST_CGY				            as CUST_CGY				         --客户类别
                ,SUM(ASTK_BUYIN_MTCH_AMT)           as ASTK_BUYIN_MTCH_AMT             --A股买入成交金额
                ,SUM(ASTK_SELL_MTCH_AMT)            as ASTK_SELL_MTCH_AMT              --A股卖出成交金额
                ,SUM(ASTK_MTCH_AMT)                 as ASTK_MTCH_AMT                   --A股成交金额
                ,SUM(BSTK_BUYIN_MTCH_AMT_RMB)       as BSTK_BUYIN_MTCH_AMT_RMB         --B股买入成交金额
                ,SUM(BSTK_SELL_MTCH_AMT_RMB)        as BSTK_SELL_MTCH_AMT_RMB          --B股卖出成交金额
                ,SUM(BSTK_MTCH_AMT_RMB)             as BSTK_MTCH_AMT_RMB               --B股成交金额
                ,SUM(BSTK_BUYIN_MTCH_AMT_USD)       as BSTK_BUYIN_MTCH_AMT_USD         --B股美元买入成交金额
                ,SUM(BSTK_SELL_MTCH_AMT_USD)        as BSTK_SELL_MTCH_AMT_USD          --B股美元卖出成交金额
                ,SUM(BSTK_MTCH_AMT_USD)             as BSTK_MTCH_AMT_USD               --B股美元成交金额
                ,SUM(BSTK_BUYIN_MTCH_AMT_HKD)       as BSTK_BUYIN_MTCH_AMT_HKD         --B股港币买入成交金额
                ,SUM(BSTK_SELL_MTCH_AMT_HKD)        as BSTK_SELL_MTCH_AMT_HKD          --B股港币卖出成交金额
                ,SUM(BSTK_MTCH_AMT_HKD)             as BSTK_MTCH_AMT_HKD               --B股港币成交金额
                ,SUM(GEM_BUYIN_MTCH_AMT)            as GEM_BUYIN_MTCH_AMT              --创业板买入成交金额
                ,SUM(GEM_SELL_MTCH_AMT)             as GEM_SELL_MTCH_AMT               --创业板卖出成交金额
                ,SUM(GEM_MTCH_AMT)                  as GEM_MTCH_AMT                    --创业板成交金额
                ,SUM(OLD_T3BOD_BUYIN_MTCH_AMT)      as OLD_T3BOD_BUYIN_MTCH_AMT        --老三板买入成交金额
                ,SUM(OLD_T3BOD_SELL_MTCH_AMT)       as OLD_T3BOD_SELL_MTCH_AMT         --老三板卖出成交金额
                ,SUM(OLD_T3BOD_MTCH_AMT)            as OLD_T3BOD_MTCH_AMT              --老三板成交金额
                ,SUM(OLD_T3BOD_BUYIN_MTCH_AMT_USD)  as OLD_T3BOD_BUYIN_MTCH_AMT_USD    --老三板美元买入成交金额
                ,SUM(OLD_T3BOD_SELL_MTCH_AMT_USD)   as OLD_T3BOD_SELL_MTCH_AMT_USD     --老三板美元卖出成交金额
                ,SUM(OLD_T3BOD_MTCH_AMT_USD)        as OLD_T3BOD_MTCH_AMT_USD          --老三板美元成交金额
                ,SUM(NEW_T3BOD_BUYIN_MTCH_AMT)      as NEW_T3BOD_BUYIN_MTCH_AMT        --新三板买入成交金额
                ,SUM(NEW_T3BOD_SELL_MTCH_AMT)       as NEW_T3BOD_SELL_MTCH_AMT         --新三板卖出成交金额
                ,SUM(NEW_T3BOD_MTCH_AMT)            as NEW_T3BOD_MTCH_AMT              --新三板成交金额
                ,SUM(QOT_REPO_MRGNS_AMT)            as QOT_REPO_MRGNS_AMT              --报价回购融券金额
                ,SUM(ORDI_REPO_MRGNS_AMT)           as ORDI_REPO_MRGNS_AMT             --普通回购融券金额
                ,SUM(ORDI_REPO_MRGNC_AMT)           as ORDI_REPO_MRGNC_AMT             --普通回购融资金额
                ,SUM(HK_STK_BUYIN_MTCH_AMT)         as HK_STK_BUYIN_MTCH_AMT           --港股买入成交金额
                ,SUM(HK_STK_SELL_MTCH_AMT)          as HK_STK_SELL_MTCH_AMT            --港股卖出成交金额
                ,SUM(HK_STK_MTCH_AMT)               as HK_STK_MTCH_AMT                 --港股成交金额
                ,SUM(BOND_BUYIN_MTCH_AMT)           as BOND_BUYIN_MTCH_AMT             --债券买入成交金额
                ,SUM(BOND_SELL_MTCH_AMT)            as BOND_SELL_MTCH_AMT              --债券卖出成交金额
                ,SUM(BOND_MTCH_AMT)                 as BOND_MTCH_AMT                   --债券成交金额 
                ,SUM(EXG_FND_SCRP_MTCH_AMT)         as EXG_FND_SCRP_MTCH_AMT           --场内基金认购成交金额				
                ,SUM(EXG_FND_BUYIN_MTCH_AMT)        as EXG_FND_BUYIN_MTCH_AMT          --场内基金买入成交金额
                ,SUM(EXG_FND_SELL_MTCH_AMT)         as EXG_FND_SELL_MTCH_AMT           --场内基金卖出成交金额
                ,SUM(EXG_FND_MTCH_AMT)              as EXG_FND_MTCH_AMT                --场内基金成交金额
				,SUM(ASTK_BUYIN_MTCH_QTY)           as ASTK_BUYIN_MTCH_QTY             --A股买入成交数量
                ,SUM(ASTK_SELL_MTCH_QTY)            as ASTK_SELL_MTCH_QTY              --A股卖出成交数量
                ,SUM(ASTK_MTCH_QTY)                 as ASTK_MTCH_QTY                   --A股成交数量
                ,SUM(BSTK_BUYIN_MTCH_QTY)           as BSTK_BUYIN_MTCH_QTY             --B股买入成交数量
                ,SUM(BSTK_SELL_MTCH_QTY)            as BSTK_SELL_MTCH_QTY              --B股卖出成交数量
                ,SUM(BSTK_MTCH_QTY)                 as BSTK_MTCH_QTY                   --B股成交数量	
                ,SUM(GEM_BUYIN_MTCH_QTY)            as GEM_BUYIN_MTCH_QTY              --创业板买入成交数量
                ,SUM(GEM_SELL_MTCH_QTY)             as GEM_SELL_MTCH_QTY               --创业板卖出成交数量
                ,SUM(GEM_MTCH_QTY)                  as GEM_MTCH_QTY                    --创业板成交数量
                ,SUM(OLD_T3BOD_BUYIN_MTCH_QTY)      as OLD_T3BOD_BUYIN_MTCH_QTY        --老三板买入成交数量
                ,SUM(OLD_T3BOD_SELL_MTCH_QTY)       as OLD_T3BOD_SELL_MTCH_QTY         --老三板卖出成交数量
                ,SUM(OLD_T3BOD_MTCH_QTY)            as OLD_T3BOD_MTCH_QTY              --老三板成交数量		
                ,SUM(NEW_T3BOD_BUYIN_MTCH_QTY)      as NEW_T3BOD_BUYIN_MTCH_QTY        --新三板买入成交数量
                ,SUM(NEW_T3BOD_SELL_MTCH_QTY)       as NEW_T3BOD_SELL_MTCH_QTY         --新三板卖出成交数量
                ,SUM(NEW_T3BOD_MTCH_QTY)            as NEW_T3BOD_MTCH_QTY              --新三板成交数量
                ,SUM(QOT_REPO_MRGNS_MTCH_QTY)       as QOT_REPO_MRGNS_MTCH_QTY         --报价回购融券成交数量
                ,SUM(ORDI_REPO_MRGNS_MTCH_QTY)      as ORDI_REPO_MRGNS_MTCH_QTY        --普通回购融券成交数量
                ,SUM(ORDI_REPO_MRGNC_MTCH_QTY)      as ORDI_REPO_MRGNC_MTCH_QTY        --普通回购融资成交数量
                ,SUM(HK_STK_BUYIN_MTCH_QTY)         as HK_STK_BUYIN_MTCH_QTY           --港股买入成交数量
                ,SUM(HK_STK_SELL_MTCH_QTY)          as HK_STK_SELL_MTCH_QTY            --港股卖出成交数量
                ,SUM(HK_STK_MTCH_QTY)               as HK_STK_MTCH_QTY                 --港股成交数量
                ,SUM(BOND_BUYIN_MTCH_QTY)           as BOND_BUYIN_MTCH_QTY             --债券买入成交数量
                ,SUM(BOND_SELL_MTCH_QTY)            as BOND_SELL_MTCH_QTY              --债券卖出成交数量
                ,SUM(BOND_MTCH_QTY)                 as BOND_MTCH_QTY                   --债券成交数量
				,SUM(EXG_FND_SCRP_MTCH_QTY)         as EXG_FND_SCRP_MTCH_QTY           --场内基金认购成交数量
                ,SUM(EXG_FND_BUYIN_MTCH_QTY)        as EXG_FND_BUYIN_MTCH_QTY          --场内基金买入成交数量
                ,SUM(EXG_FND_SELL_MTCH_QTY)         as EXG_FND_SELL_MTCH_QTY           --场内基金卖出成交数量
                ,SUM(EXG_FND_MTCH_QTY)              as EXG_FND_MTCH_QTY                --场内基金成交数量                             
			    ,SUM(ASTK_BUYIN_S1)                 as ASTK_BUYIN_S1                   --A股买入毛佣金
                ,SUM(ASTK_SELL_S1)                  as ASTK_SELL_S1                    --A股卖出毛佣金
                ,SUM(ASTK_S1)                       as ASTK_S1                         --A股毛佣金
                ,SUM(BSTK_BUYIN_S1_RMB)             as BSTK_BUYIN_S1_RMB               --B股买入毛佣金
                ,SUM(BSTK_SELL_S1_RMB)              as BSTK_SELL_S1_RMB                --B股卖出毛佣金
                ,SUM(BSTK_S1_RMB)                   as BSTK_S1_RMB                     --B股毛佣金
                ,SUM(BSTK_BUYIN_S1_USD)             as BSTK_BUYIN_S1_USD               --B股美元买入毛佣金
                ,SUM(BSTK_SELL_S1_USD)              as BSTK_SELL_S1_USD                --B股美元卖出毛佣金
                ,SUM(BSTK_S1_USD)                   as BSTK_S1_USD                     --B股美元毛佣金
                ,SUM(BSTK_BUYIN_S1_HKD)             as BSTK_BUYIN_S1_HKD               --B股港币买入毛佣金
                ,SUM(BSTK_SELL_S1_HKD)              as BSTK_SELL_S1_HKD                --B股港币卖出毛佣金
                ,SUM(BSTK_S1_HKD)                   as BSTK_S1_HKD                     --B股港币毛佣金
                ,SUM(GEM_BUYIN_S1)                  as GEM_BUYIN_S1                    --创业板买入毛佣金
                ,SUM(GEM_SELL_S1)                   as GEM_SELL_S1                     --创业板卖出毛佣金
                ,SUM(GEM_S1)                        as GEM_S1                          --创业板毛佣金
                ,SUM(OLD_T3BOD_BUYIN_S1)            as OLD_T3BOD_BUYIN_S1              --老三板买入毛佣金
                ,SUM(OLD_T3BOD_SELL_S1)             as OLD_T3BOD_SELL_S1               --老三板卖出毛佣金
                ,SUM(OLD_T3BOD_S1)                  as OLD_T3BOD_S1                    --老三板毛佣金
                ,SUM(OLD_T3BOD_BUYIN_S1_USD)        as OLD_T3BOD_BUYIN_S1_USD          --老三板美元买入毛佣金
                ,SUM(OLD_T3BOD_SELL_S1_USD)         as OLD_T3BOD_SELL_S1_USD           --老三板美元卖出毛佣金
                ,SUM(OLD_T3BOD_S1_USD)              as OLD_T3BOD_S1_USD                --老三板美元毛佣金
                ,SUM(NEW_T3BOD_BUYIN_S1)            as NEW_T3BOD_BUYIN_S1              --新三板买入毛佣金
                ,SUM(NEW_T3BOD_SELL_S1)             as NEW_T3BOD_SELL_S1               --新三板卖出毛佣金
                ,SUM(NEW_T3BOD_S1)                  as NEW_T3BOD_S1                    --新三板毛佣金
                ,SUM(QOT_REPO_MRGNS_S1)             as QOT_REPO_MRGNS_S1               --报价回购融券毛佣金
                ,SUM(ORDI_REPO_MRGNS_S1)            as ORDI_REPO_MRGNS_S1              --普通回购融券毛佣金
                ,SUM(ORDI_REPO_MRGNC_S1)            as ORDI_REPO_MRGNC_S1              --普通回购融资毛佣金
                ,SUM(HK_STK_BUYIN_S1)               as HK_STK_BUYIN_S1                 --港股买入毛佣金
                ,SUM(HK_STK_SELL_S1)                as HK_STK_SELL_S1                  --港股卖出毛佣金
                ,SUM(HK_STK_S1)                     as HK_STK_S1                       --港股毛佣金
                ,SUM(BOND_BUYIN_S1)                 as BOND_BUYIN_S1                   --债券买入毛佣金
                ,SUM(BOND_SELL_S1)                  as BOND_SELL_S1                    --债券卖出毛佣金
                ,SUM(BOND_S1)                       as BOND_S1                         --债券毛佣金
                ,SUM(EXG_FND_BUYIN_S1)              as EXG_FND_BUYIN_S1                --场内基金买入毛佣金
                ,SUM(EXG_FND_SELL_S1)               as EXG_FND_SELL_S1                 --场内基金卖出毛佣金
                ,SUM(EXG_FND_S1)                    as EXG_FND_S1                      --场内基金毛佣金
                ,SUM(ASTK_BUYIN_NET_S1)             as ASTK_BUYIN_NET_S1               --A股买入净佣金
                ,SUM(ASTK_SELL_NET_S1)              as ASTK_SELL_NET_S1                --A股卖出净佣金
                ,SUM(ASTK_NET_S1)                   as ASTK_NET_S1                     --A股净佣金
                ,SUM(BSTK_BUYIN_NET_S1_RMB)         as BSTK_BUYIN_NET_S1_RMB           --B股买入净佣金
                ,SUM(BSTK_SELL_NET_S1_RMB)          as BSTK_SELL_NET_S1_RMB            --B股卖出净佣金
                ,SUM(BSTK_NET_S1_RMB)               as BSTK_NET_S1_RMB                 --B股净佣金
                ,SUM(BSTK_BUYIN_NET_S1_USD)         as BSTK_BUYIN_NET_S1_USD           --B股美元买入净佣金
                ,SUM(BSTK_SELL_NET_S1_USD)          as BSTK_SELL_NET_S1_USD            --B股美元卖出净佣金
                ,SUM(BSTK_NET_S1_USD)               as BSTK_NET_S1_USD                 --B股美元净佣金
                ,SUM(BSTK_BUYIN_NET_S1_HKD)         as BSTK_BUYIN_NET_S1_HKD           --B股港币买入净佣金
                ,SUM(BSTK_SELL_NET_S1_HKD)          as BSTK_SELL_NET_S1_HKD            --B股港币卖出净佣金
                ,SUM(BSTK_NET_S1_HKD)               as BSTK_NET_S1_HKD                 --B股港币净佣金
                ,SUM(GEM_BUYIN_NET_S1)              as GEM_BUYIN_NET_S1                --创业板买入净佣金
                ,SUM(GEM_SELL_NET_S1)               as GEM_SELL_NET_S1                 --创业板卖出净佣金
                ,SUM(GEM_NET_S1)                    as GEM_NET_S1                      --创业板净佣金
                ,SUM(OLD_T3BOD_BUYIN_NET_S1)        as OLD_T3BOD_BUYIN_NET_S1          --老三板买入净佣金
                ,SUM(OLD_T3BOD_SELL_NET_S1)         as OLD_T3BOD_SELL_NET_S1           --老三板卖出净佣金
                ,SUM(OLD_T3BOD_NET_S1)              as OLD_T3BOD_NET_S1                --老三板净佣金
                ,SUM(OLD_T3BOD_BUYIN_NET_S1_USD)    as OLD_T3BOD_BUYIN_NET_S1_USD      --老三板美元买入净佣金
                ,SUM(OLD_T3BOD_SELL_NET_S1_USD)     as OLD_T3BOD_SELL_NET_S1_USD       --老三板美元卖出净佣金
                ,SUM(OLD_T3BOD_NET_S1_USD)          as OLD_T3BOD_NET_S1_USD            --老三板美元净佣金
                ,SUM(NEW_T3BOD_BUYIN_NET_S1)        as NEW_T3BOD_BUYIN_NET_S1          --新三板买入净佣金
                ,SUM(NEW_T3BOD_SELL_NET_S1)         as NEW_T3BOD_SELL_NET_S1           --新三板卖出净佣金
                ,SUM(NEW_T3BOD_NET_S1)              as NEW_T3BOD_NET_S1                --新三板净佣金
                ,SUM(QOT_REPO_MRGNS_NET_S1)         as QOT_REPO_MRGNS_NET_S1           --报价回购融券净佣金
                ,SUM(ORDI_REPO_MRGNS_NET_S1)        as ORDI_REPO_MRGNS_NET_S1          --普通回购融券净佣金
                ,SUM(ORDI_REPO_MRGNC_NET_S1)        as ORDI_REPO_MRGNC_NET_S1          --普通回购融额净佣金
                ,SUM(HK_STK_BUYIN_NET_S1)           as HK_STK_BUYIN_NET_S1             --港股买入净佣金
                ,SUM(HK_STK_SELL_NET_S1)            as HK_STK_SELL_NET_S1              --港股卖出净佣金
                ,SUM(HK_STK_NET_S1)                 as HK_STK_NET_S1                   --港股净佣金
                ,SUM(BOND_BUYIN_NET_S1)             as BOND_BUYIN_NET_S1               --债券买入净佣金
                ,SUM(BOND_SELL_NET_S1)              as BOND_SELL_NET_S1                --债券卖出净佣金
                ,SUM(BOND_NET_S1)                   as BOND_NET_S1                     --债券净佣金
                ,SUM(EXG_FND_BUYIN_NET_S1)          as EXG_FND_BUYIN_NET_S1            --场内基金买入净佣金
                ,SUM(EXG_FND_SELL_NET_S1)           as EXG_FND_SELL_NET_S1             --场内基金卖出净佣金
                ,SUM(EXG_FND_NET_S1)                as EXG_FND_NET_S1                  --场内基金净佣金               
			    ,SUM(ASTK_BUYIN_MTCH_ITMS)          as ASTK_BUYIN_MTCH_ITMS            --A股买入成交笔数
                ,SUM(ASTK_SELL_MTCH_ITMS)           as ASTK_SELL_MTCH_ITMS             --A股卖出成交笔数
                ,SUM(ASTK_MTCH_ITMS)                as ASTK_MTCH_ITMS                  --A股成交笔数
                ,SUM(BSTK_BUYIN_MTCH_ITMS)          as BSTK_BUYIN_MTCH_ITMS        --B股买入成交笔数
                ,SUM(BSTK_SELL_MTCH_ITMS)           as BSTK_SELL_MTCH_ITMS         --B股卖出成交笔数
                ,SUM(BSTK_MTCH_ITMS)                as BSTK_MTCH_ITMS              --B股成交笔数	
                ,SUM(GEM_BUYIN_MTCH_ITMS)           as GEM_BUYIN_MTCH_ITMS             --创业板买入成交笔数
                ,SUM(GEM_SELL_MTCH_ITMS)            as GEM_SELL_MTCH_ITMS              --创业板卖出成交笔数
                ,SUM(GEM_MTCH_ITMS)                 as GEM_MTCH_ITMS                   --创业板成交笔数
                ,SUM(OLD_T3BOD_BUYIN_MTCH_ITMS)     as OLD_T3BOD_BUYIN_MTCH_ITMS       --老三板买入成交笔数
                ,SUM(OLD_T3BOD_SELL_MTCH_ITMS)      as OLD_T3BOD_SELL_MTCH_ITMS        --老三板卖出成交笔数
                ,SUM(OLD_T3BOD_MTCH_ITMS)           as OLD_T3BOD_MTCH_ITMS             --老三板成交笔数		
                ,SUM(NEW_T3BOD_BUYIN_MTCH_ITMS)     as NEW_T3BOD_BUYIN_MTCH_ITMS       --新三板买入成交笔数
                ,SUM(NEW_T3BOD_SELL_MTCH_ITMS)      as NEW_T3BOD_SELL_MTCH_ITMS        --新三板卖出成交笔数
                ,SUM(NEW_T3BOD_MTCH_ITMS)           as NEW_T3BOD_MTCH_ITMS             --新三板成交笔数
                ,SUM(QOT_REPO_MRGNS_MTCH_ITMS)      as QOT_REPO_MRGNS_MTCH_ITMS        --报价回购融券成交笔数
                ,SUM(ORDI_REPO_MRGNS_MTCH_ITMS)     as ORDI_REPO_MRGNS_MTCH_ITMS       --普通回购融券成交笔数
                ,SUM(ORDI_REPO_MRGNC_MTCH_ITMS)     as ORDI_REPO_MRGNC_MTCH_ITMS       --普通回购融资成交笔数
                ,SUM(HK_STK_BUYIN_MTCH_ITMS)        as HK_STK_BUYIN_MTCH_ITMS          --港股买入成交笔数
                ,SUM(HK_STK_SELL_MTCH_ITMS)         as HK_STK_SELL_MTCH_ITMS           --港股卖出成交笔数
                ,SUM(HK_STK_MTCH_ITMS)              as HK_STK_MTCH_ITMS                --港股成交笔数
                ,SUM(BOND_BUYIN_MTCH_ITMS)          as BOND_BUYIN_MTCH_ITMS            --债券买入成交笔数
                ,SUM(BOND_SELL_MTCH_ITMS)           as BOND_SELL_MTCH_ITMS             --债券卖出成交笔数
                ,SUM(BOND_MTCH_ITMS)                as BOND_MTCH_ITMS                  --债券成交笔数
				,SUM(EXG_FND_SCRP_MTCH_ITMS)        as EXG_FND_SCRP_MTCH_ITMS          --场内基金认购成交笔数
                ,SUM(EXG_FND_BUYIN_MTCH_ITMS)       as EXG_FND_BUYIN_MTCH_ITMS         --场内基金买入成交笔数
                ,SUM(EXG_FND_SELL_MTCH_ITMS)        as EXG_FND_SELL_MTCH_ITMS          --场内基金卖出成交笔数
                ,SUM(EXG_FND_MTCH_ITMS)             as EXG_FND_MTCH_ITMS               --场内基金成交笔数
                ,SUM(SEC_TFR_IN_MKTVAL)             as SEC_TFR_IN_MKTVAL               --证券转入市值  
                ,SUM(SEC_TFR_OUT_MKTVAL)            as SEC_TFR_OUT_MKTVAL              --证券转入市值 
                ,SUM(SEC_NET_TFR_IN_MKTVAL)         as SEC_NET_TFR_IN_MKTVAL           --证券净转入市值 	
                ,ACCNT_CGY	                        as ACCNT_CGY                       --账户类别				
                ,%d{yyyyMMdd}                       as ETL_DT
 FROM           DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY   t
 WHERE          t.BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT) AND %d{yyyyMMdd}
 GROUP BY       CUST_NO,CUST_CGY,EXG,BRH_NO,ETL_DT,ACCNT_CGY
 ;
 
-----------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_MON;
--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:机构类别定义表                                                                       */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T03_TJGLB;
------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T03_TJGLB
 (
                                     JGLB                                --机构类别                               
                                    ,JGLBMC                              --机构类别说明                             
                                    ,SJJGFW                              --上级机构范围                             
                                    ,JGSXFW                              --机构属性范围                             
                                    ,LSKH                                --是否有隶属客户                            
                                    ,LSJJR                               --是否有隶属经纪人                           
                                    ,JGDMQZ                              --机构代码前缀                             
                                    ,KHQXKZFS                            --客户权限控制方式                           
                                    ,YHQXKZFS                            --用户权限控制方式                           
                                    ,CSQXKZFS                            --参数权限控制方式                           
                                    ,KHFLKZFS                            --客户分类控制方式                           
                                    ,KHQZDY                              --客户群组定义           
                                    ,XTBS								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.JGLB                                as JGLB                                --机构类别                                
                                    ,t.JGLBMC                              as JGLBMC                              --机构类别说明                              
                                    ,t.SJJGFW                              as SJJGFW                              --上级机构范围                              
                                    ,t.JGSXFW                              as JGSXFW                              --机构属性范围                              
                                    ,t.LSKH                                as LSKH                                --是否有隶属客户                             
                                    ,t.LSJJR                               as LSJJR                               --是否有隶属经纪人                            
                                    ,t.JGDMQZ                              as JGDMQZ                              --机构代码前缀                              
                                    ,t.KHQXKZFS                            as KHQXKZFS                            --客户权限控制方式                            
                                    ,t.YHQXKZFS                            as YHQXKZFS                            --用户权限控制方式                            
                                    ,t.CSQXKZFS                            as CSQXKZFS                            --参数权限控制方式                            
                                    ,t.KHFLKZFS                            as KHFLKZFS                            --客户分类控制方式                            
                                    ,t.KHQZDY                              as KHQZDY                              --客户群组定义 
                                    ,'JZJY'								   
 FROM 		JZJYCX.ABOSS_TJGLB				t 
 WHERE 		t.DT = '%d{yyyyMMdd}';
-------插入数据结束
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T03_TJGLB',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T03_TJGLB; 
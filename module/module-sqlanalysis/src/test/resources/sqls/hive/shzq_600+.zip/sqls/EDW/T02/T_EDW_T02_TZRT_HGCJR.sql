 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:转融通合格出借人表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZRT_HGCJR;
-------插入数据开始-----
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZRT_HGCJR(
                                    ZRT_JSJG                            --转融通结算机构                            
                                   ,FSDX                                --发送对象                               
                                   ,JYS                                 --交易所                                
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --股东代码                               
                                   ,YYB                                 --客户姓名                               
                                   ,GDH                                 --营业部                                
                                   ,XWH                                 --交易单元                               
                                   ,JYRQ                                --交易日期     
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.JSJG                                as ZRT_JSJG                            --结算机构                                
                                   ,t.FSDX                                as FSDX                                --发送对象                                
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.GDH                                 as KHXM                                --股东代码                                
                                   ,t.KHXM                                as YYB                                 --客户姓名                                
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as GDH                                 --营业部                                 
                                   ,t.XWH                                 as XWH                                 --交易单元                                
                                   ,t.JYRQ                                as JYRQ                                --交易日期  
                                   ,'RZRQ'                                as XTBS								   
 FROM      		RZRQCX.ZRT_TZRT_HGCJR t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'RZRQ'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
------插入数据结束------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZRT_HGCJR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

invalidate metadata EDW_PROD.T_EDW_T02_TZRT_HGCJR;
 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360个人客户信息表                                                                      */
  --/* 创建人:程骏                                                                               */
  --/* 创建时间:2017-10-18                                                                        */ 
  /* T_DDW_F01_CUST_INFO	替换为	T_DDW_F00_CUST_CUST_INFO */
/* T_DDW_F01_IDV_CUST_INFO  替换为 T_EDW_T01_TGRKHXX */

DROP TABLE IF EXISTS DDW_PROD.T_CUST360_IDV_CUST_INFO_TEMP;
CREATE TABLE DDW_PROD.T_CUST360_IDV_CUST_INFO_TEMP
AS SELECT    KHH                                                                                                                                                                as CUST_NO				  			--客户号
	      ,CSRQ                                                                                                                                                               as BRTH_DT			  				--出生日期
	      ,XBDM                                                                                                                                                               as GNDR_CD			  				--性别代码
	      ,XLDM                                                                                                                                                               as EDU_CD				  				--学历代码
	      ,ZYDM                                                                                                                                                               as OCP_CD				  				--职业代码
	      ,MZDM                                                                                                                                                               as NATN_CD		      				--民族代码
	      ,JG                                                                                                                                                                 as NTV_PLC			  				--籍贯
	      ,HYZKDM                                                                                                                                                             as MARG_STAT_CD		  				--婚姻状况代码
	      ,GZDW                                                                                                                                                               as WORK_UNIT			  				--工作单位
	      ,JTDZ                                                                                                                                                               as HOM_ADDR			  				--家庭地址
	      ,JTYB                                                                                                                                                               as HOM_PSTCD			  				--家庭邮编
	      ,JTDH                                                                                                                                                               as HOM_TEL			  				--家庭电话
	      ,GZDWDZ                                                                                                                                                             as WORK_ADDR			  				--单位地址
	      ,GZDWYB                                                                                                                                                             as WORK_PSTCD			  				--单位邮编
	      ,GZDWDH                                                                                                                                                             as WORK_TEL			  				--单位电话
          ,CASE WHEN t.CSRQ > 0
			  THEN CAST(ROUND(cast(EDW_PROD.G_DATE_COMPARE_DATE(CAST(BUS_DATE AS STRING),'yyyyMMdd',CAST(T.CSRQ AS STRING),'yyyyMMdd') as int)/360,0) as DECIMAL(38,0))               
	      	  END as AGE  
          ,BUS_DATE			  
 FROM     EDW_PROD.T_EDW_T01_TGRKHXX t
 WHERE BUS_DATE = %d{yyyyMMdd};



---------------- 插入集中交易数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_IDV_CUST_INFO
 (
	            CUST_NO               		--客户号              
	           ,CUST_NAME                   --姓名                
	           ,GNDR                        --性别                
	           ,AGE                         --年龄                
	           ,CTF_CGY                     --证件类别            
	           ,CTF_NO                      --证件号码            
	           ,CTF_EXPR_DT                 --证件截止日期        
	           ,BRH_NAME                    --所属营业部          
	           ,CUST_CGY                    --客户类别            
	           ,BRTH_DT                     --出生日期            
	           ,ORDI_ACCNT_ODR_MOD_SCP      --普通账户委托方式范围
	           ,CUST_STAT                   --客户状态            
	           ,OPNAC_DT                    --开户日期            
	           ,OPNAC_MOD                   --开户方式            
	           ,RSK_BEAR_ABLTY              --风险承受能力        
	           ,CUST_RSK_LVL                --风险级别            
	           ,M_LAUND_RSK_LVL             --洗钱等级            
	           ,CTCT_TEL                    --联系电话            
	           ,PHONE                       --手机                
	           ,CTCT_ADDR                   --联系地址            
	           ,CTF_ADDR                    --证件地址            
	           ,OCP                         --职业                
	           ,EDU                         --学历                
	           ,CTRL_ATTR                   --控制属性            
	           ,WORK_UNIT                   --工作单位            
	           ,HOM_ADDR                    --家庭地址            
	           ,HOM_PSTCD                   --家庭邮编            
	           ,HOM_TEL                     --家庭电话            
	           ,WORK_ADDR                   --单位地址            
	           ,WORK_PSTCD                  --单位邮编            
	           ,WORK_TEL                    --单位电话            
	           ,NATN                        --民族                
	           ,NTV_PLC                     --籍贯                
	           ,MARG_STAT                   --婚姻状况                               
 ) PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT   t.CUST_NO                            as CUST_NO               		--客户号              
	     ,t.CUST_NAME                          as CUST_NAME                   --姓名                
	     ,a1.GNDR_CD_NAME                      as GNDR                        --性别                
	     ,a2.AGE                               as AGE                         --年龄                
	     ,a3.CTF_CGY_CD_NAME                   as CTF_CGY                     --证件类别            
	     ,t.CTF_NO                             as CTF_NO                      --证件号码            
	     ,cast(t.CTF_EXPR_DT  as DECIMAL(8,0))  as CTF_EXPR_DT                 --证件截止日期        
	     ,t.BRH_NAME                           as BRH_NAME                    --所属营业部          
	     ,a4.CUST_CGY_NAME                     as CUST_CGY                    --客户类别            
	     ,a2.BRTH_DT                           as BRTH_DT                     --出生日期            
	     ,T.ORDI_ODR_MOD_SCP             as ORDI_ACCNT_ODR_MOD_SCP      --普通账户委托方式范围
	     ,a5.CUST_STAT_NAME                    as CUST_STAT                   --客户状态            
	     ,T.ORDI_OPNAC_DT                           as OPNAC_DT                    --开户日期            
	     ,a6.OPNAC_MOD_NAME                    as OPNAC_MOD                   --开户方式            
	     ,a7.RSK_BEAR_ABLTY_NAME               as RSK_BEAR_ABLTY              --风险承受能力        
	     ,a8.NOTE                              as CUST_RSK_LVL                --风险级别            
	     ,t.M_LAUND_RSK_LVL                    as M_LAUND_RSK_LVL             --洗钱等级            
	     ,t.CTCT_TEL                           as CTCT_TEL                    --联系电话            
	     ,t.PHONE                              as PHONE                       --手机                
	     ,t.CTCT_ADDR                          as CTCT_ADDR                   --联系地址            
	     ,t.CTF_ADDR                           as CTF_ADDR                    --证件地址            
	     ,a9.OCP_CD_NAME                       as OCP                         --职业                
	     ,a10.EDU_CD_NAME                      as EDU                         --学历                
	     ,t.CTRL_ATTR                          as CTRL_ATTR                   --控制属性            
	     ,a2.WORK_UNIT                         as WORK_UNIT                   --工作单位            
	     ,a2.HOM_ADDR                          as HOM_ADDR                    --家庭地址            
	     ,a2.HOM_PSTCD                         as HOM_PSTCD                   --家庭邮编            
	     ,a2.HOM_TEL                           as HOM_TEL                     --家庭电话            
	     ,a2.WORK_ADDR                         as WORK_ADDR                   --单位地址            
	     ,a2.WORK_PSTCD                        as WORK_PSTCD                  --单位邮编            
	     ,a2.WORK_TEL                          as WORK_TEL                    --单位电话            
	     ,a12.NATN_CD_NAME                     as NATN                        --民族                
	     ,a2.NTV_PLC                           as NTV_PLC                     --籍贯                
	     ,a11.MARG_STAT_CD_NAME                as MARG_STAT                   --婚姻状况             
 FROM         DDW_PROD.T_DDW_F00_CUST_CUST_INFO       t
 LEFT JOIN    DDW_PROD.V_GNDR_CD        a1
 ON           t.GNDR_CD = a1.GNDR_CD
 LEFT JOIN    DDW_PROD.T_CUST360_IDV_CUST_INFO_TEMP   a2
 ON           t.CUST_NO  = a2.CUST_NO 
 AND          t.BUS_DATE = a2.BUS_DATE
 LEFT JOIN    DDW_PROD.V_CTF_CGY_CD              a3
 ON           t.CTF_CGY_CD = a3.CTF_CGY_CD
 LEFT JOIN    DDW_PROD.V_CUST_CGY                a4
 ON           t.CUST_CGY = a4.CUST_CGY
 LEFT JOIN    DDW_PROD.V_CUST_STAT               a5
 ON           t.ORDI_CUST_STAT =  a5.CUST_STAT
 LEFT JOIN    DDW_PROD.V_OPNAC_MOD               a6
 ON           t.OPNAC_MOD =  a6.OPNAC_MOD
 LEFT JOIN    DDW_PROD.V_RSK_BEAR_ABLTY          a7
 ON           t.rsk_bear_ablty = a7.RSK_BEAR_ABLTY
 LEFT JOIN    YGTCX.CIF_TXTDM                     a8
 ON           t.CUST_RSK_LVL = CAST(a8.IBM as STRING)
 AND          a8.FLDM = 'GT_KHFXJB' 
 AND          t.BUS_DATE = CAST(a8.DT AS INT)
 LEFT JOIN    DDW_PROD.V_OCP_CD                   a9 
 ON           t.OCP_CD = a9.OCP_CD
 LEFT JOIN    DDW_PROD.V_EDU_CD                   a10
 ON           t.EDU_CD = a10.EDU_CD
 LEFT JOIN    DDW_PROD.V_MARG_STAT_CD             a11
 ON           a2.MARG_STAT_CD = a11.MARG_STAT_CD
 LEFT JOIN    DDW_PROD.V_NATN_CD                  a12
 ON           a2.NATN_CD = a12.NATN_CD
 WHERE        t.CUST_CGY = '0'
 AND          t.BUS_DATE = %d{yyyyMMdd}
 ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_CUST360_IDV_CUST_INFO_TEMP;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_IDV_CUST_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_IDV_CUST_INFO;
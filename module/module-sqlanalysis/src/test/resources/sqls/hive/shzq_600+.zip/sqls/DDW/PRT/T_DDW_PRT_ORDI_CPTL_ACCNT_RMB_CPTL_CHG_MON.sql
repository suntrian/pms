 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:资金账户报表_普通账户_人民币资金变动月表                                                                   */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-11-14                                                                        */ 

------创建临时表1  
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP as
 SELECT   a.CUST_NO
         ,a.CNTR_CPTL_ACCNT
		 ,SUM(a.ACCNT_BAL) as ACCNT_BAL
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE   a.CPTL_ACCNT_STAT < > '3'
 AND     a.BUS_DATE = %d{yyyyMMdd}
 AND     a.CCY_CD = 'RMB'
 AND     a.SYS_SRC = '普通账户' 
 AND     EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
                 WHERE b.CUST_RSK_LVL IN ('0','1','2','8','19') 
				 AND b.BRH_NO NOT IN('4444','8003','8002','0017','099300000001','099000000001')
				 AND b.CUST_NO NOT IN ('100610335855')
				 AND b.BUS_DATE = %d{yyyyMMdd}
				 AND a.CUST_NO = b.CUST_NO
                )
 GROUP BY a.CUST_NO
         ,a.CNTR_CPTL_ACCNT
		 ;

----
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP1 as
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)   as YEAR_MON
         ,SUM(a.ACCNT_BAL)   as ACCNT_BAL
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP b
                 WHERE a.CNTR_CPTL_ACCNT = b.CNTR_CPTL_ACCNT
				 AND a.CUST_NO = b.CUST_NO
                )
 AND     a.CCY_CD = 'RMB'
 AND     a.SYS_SRC = '普通账户'
 AND  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                             FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                 WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                 AND BUS_DATE = %d{yyyyMMdd}
				            )  c
                     WHERE  a.BUS_DATE = c.MON_START
			 )	
 GROUP BY YEAR_MON ;		 

---
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP2 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP2 as 
 SELECT  CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)   as YEAR_MON
         ,SUM(a.ORDI_MKTVAL_SEC_RMD+a.ORDI_MKTVAL_PROD)  as FNL_MKTVAL_RMB
		 ,SUM(0-ORDI_GL)                as FNL_GL_RMB
 FROM  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY     a
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP b
                 WHERE  a.CUST_NO = b.CUST_NO
                )
 AND a.BUS_DATE = %d{yyyyMMdd}
 GROUP BY YEAR_MON ;
 
 -----
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP3 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP3 as 
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON
         ,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) = '101'
                   THEN a.SRJE-a.FCJE
				   ELSE 0
				   END 
              )                              as DEPIN_CPTL  --存入资金
		  ,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) = '102'
                   THEN a.SRJE-a.FCJE
				   ELSE 0
				   END 
              )                              as WTHDR_CPTL  --存入资金
		 ,SUM(CASE WHEN a.YWKM IN ('13001','13011','13015')	
                   AND  c.ZQDM IS NULL		 
                   THEN a.SRJE-a.FCJE
				   WHEN SUBSTR(a.YWKM,1,3) = '140'
				   AND  a.ZJLY IN ('SH','SZ')
		           AND  c.ZQDM IS NULL
                   THEN a.SRJE-a.FCJE
				   ELSE 0
				   END 
              )                              as BUYIN_SEC_CPTL  --买入证券资金
		 ,SUM(CASE WHEN a.YWKM IN ('13101','13115')	
                   AND  c.ZQDM IS NULL		 
                   THEN a.SRJE-a.FCJE
				   WHEN SUBSTR(a.YWKM,1,3) = '141'
		           AND  c.ZQDM IS NULL
				   AND  a.ZJLY IN ('SH','SZ')
                   THEN a.SRJE-a.FCJE
				   ELSE 0
				   END 
              )                              as SELL_SEC_CPTL  --卖出证券资金
		,SUM(CASE WHEN a.YWKM IN ('13031','13032','13131')		           
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as PRCH_CPTL  --申购资金
		,SUM(CASE WHEN a.YWKM IN ('13021','13022','13121','13122')		           
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as REPO_CPTL  --回购资金
	   ,SUM(CASE WHEN a.YWKM IN ('13023','13024','13025','13123','13124','13125')		           
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as QOT_REPO_CPTL  --报价回购资金
	    ,SUM(CASE WHEN a.YWKM IN ('13026','13027','13126','13127')		           
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as PROMS_RPHS_CPTL  --约定购回资金
		 ,SUM(CASE WHEN a.YWKM IN ('13028','13029','13128','13129')		           
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as STK_PLG_REPO_CPTL  --股票质押回购资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'	
                  AND  a.ZJLY = 'SH'
                  AND a.XGPZ = '511990'			  
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as TRD_CPTL_511990  --华宝添益(511990)交易资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'	
                  AND  a.ZJLY = 'SH'
                  AND a.XGPZ = '511880'			  
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as TRD_CPTL_511880  --银华日利(511880)交易资金 
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'	
                  AND  a.ZJLY = 'SH'
                  AND a.XGPZ = '519888'			  
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as TRD_CPTL_519888  --添富快线(519888)交易资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'	                 
                   AND a.XGPZ = 'A30003'			  
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as TRD_CPTL_A30003  --现金添利资金交易资金	
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'	                 
                   AND a.XGPZ < > 'A30003'
                   AND SUBSTR(a.XGPZ,1,1) = 'A'				   
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as CO_PROD_TRD_CPTL  --公司理财（除现金添利）交易资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'	                                  
                   AND SUBSTR(a.XGPZ,1,2) = '95'				   
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as GJ_CO_PROD_TRD_CPTL  --国君产品交易资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'
		          AND  c.ZQDM IS NOT NULL
				  AND  a.XGPZ NOT IN ('519888','511880','511990')
                  THEN a.SRJE-a.FCJE				   
				  ELSE 0
				  END 
              )                          as OTH_EXG_CCY_FND_TRD_CPTL --其他场内货币基金交易资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) IN ('140','141')		
                   AND d.JJDM IS NOT NULL
                   AND SUBSTR(a.XGPZ,1,1) < > 'A'
                   AND SUBSTR(a.XGPZ,1,2) < > '95'				   
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as OPN_FND_TRD_CPTL  --开放式基金交易资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) IN ('140','141')		
                   AND e.CPDM IS NOT NULL			   
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as BANK_PORD_TRD_CPTL  --银行产品交易资金
			  
 FROM   EDW_PROD.T_EDW_T05_TZJMXLS  a
 LEFT JOIN (SELECT SecurityCode as ZQDM
                  ,CASE WHEN  SUBSTR(SecurityCode,1,3) IN ('500','501','502','505','510','511','512','513','518','519','515')
				        THEN 'SH'
						ELSE 'SZ'
						END as JYS
            FROM fundext.dbo_MF_FundArchives 
            WHERE fundtypecode = 1109  
			AND SUBSTR(SecurityCode,1,3) IN ('500','501','502','505','510','511','512','513','518','519','150','159','160','161','162','163','164','165','166','167','168','169','184','515')
			AND DT = '%d{yyyyMMdd}'	
            UNION 	
            SELECT exapplyingcode as ZQDM
                  ,CASE WHEN  SUBSTR(SecurityCode,1,3) IN ('500','501','502','505','510','511','512','513','518','519','515')
				        THEN 'SH'
						ELSE 'SZ'
						END as JYS
            FROM fundext.dbo_MF_FundArchives 
            WHERE fundtypecode = 1109  
			AND SUBSTR(SecurityCode,1,3) IN ('500','501','502','505','510','511','512','513','518','519','150','159','160','161','162','163','164','165','166','167','168','169','184','515')
			AND DT = '%d{yyyyMMdd}'	
			AND LENGTH(TRIM(exapplyingcode)) > 0
			
			)  c
 ON       a.ZJLY = c.JYS
 AND      a.XGPZ = c.ZQDM
 LEFT JOIN EDW_PROD.T_EDW_T04_TOF_JJXX d
 ON       a.XGPZ = d.JJDM
 AND      d.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN EDW_PROD.T_EDW_T99_TJRCP_CPDM e
 ON       a.XGPZ = e.CPDM
 AND      e.BUS_DATE = %d{yyyyMMdd}
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP b
                 WHERE a.GTZJZH = b.CNTR_CPTL_ACCNT
				 AND a.KHH = b.CUST_NO
                )
AND    a.XTBS = 'JZJY'
AND   SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) ;		



DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP4 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP4 as
 SELECT   a.CUST_NO
         ,a.CNTR_CPTL_ACCNT
		 ,SUM(a.ACCNT_BAL) as ACCNT_BAL
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE   a.CPTL_ACCNT_STAT < > '3'
 AND     a.BUS_DATE = %d{yyyyMMdd}
 AND     a.CCY_CD = 'RMB'
 AND     a.SYS_SRC = '普通账户' 
 AND     EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO b
                 WHERE b.CUST_RSK_LVL IN ('0','1','2','8','19') 
				 AND b.BRH_NO NOT IN('4444','8003','8002','0017','099300000001','099000000001')
				 AND b.CUST_NO NOT IN ('100610335855')
				 AND b.BUS_DATE = %d{yyyyMMdd}
				 AND a.CUST_NO = b.CUST_NO
				 AND SUBSTR(CASt(b.ORDI_OPNAC_DT as STRING),1,6) =  SUBSTR('%d{yyyyMMdd}',1,6)
                )
 GROUP BY a.CUST_NO
         ,a.CNTR_CPTL_ACCNT
		 ;

----
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP5 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP5 as
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)   as YEAR_MON
         ,SUM(a.ACCNT_BAL)   as ACCNT_BAL
 FROM    DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS    a
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP4 b
                 WHERE a.CNTR_CPTL_ACCNT = b.CNTR_CPTL_ACCNT
				 AND a.CUST_NO = b.CUST_NO
                )
 AND     a.CCY_CD = 'RMB'
 AND     a.SYS_SRC = '普通账户'
 AND  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                             FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                 WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                 AND BUS_DATE = %d{yyyyMMdd}
				            )  c
                     WHERE  a.BUS_DATE = c.MON_START
			 )	
 GROUP BY YEAR_MON ;		 

---
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP6 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP6 as 
 SELECT  CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT)   as YEAR_MON
         ,SUM(a.ORDI_MKTVAL_SEC_RMD+a.ORDI_MKTVAL_PROD)  as FNL_MKTVAL_RMB
		 ,SUM(0-ORDI_GL)                as FNL_GL_RMB
 FROM  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY     a
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP4 b
                 WHERE  a.CUST_NO = b.CUST_NO
                )
 AND  a.BUS_DATE = %d{yyyyMMdd}
 GROUP BY YEAR_MON ;
 
 -----
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP7 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP7 as 
 SELECT   CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON
         ,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) = '101'
                   THEN a.SRJE-a.FCJE
				   ELSE 0
				   END 
              )                              as DEPIN_CPTL  --存入资金
		  ,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) = '102'
                   THEN a.SRJE-a.FCJE
				   ELSE 0
				   END 
              )                              as WTHDR_CPTL  --存入资金
		 ,SUM(CASE WHEN a.YWKM IN ('13001','13011','13015')	
                    AND  c.ZQDM IS NULL		 
                   THEN a.SRJE-a.FCJE
				   WHEN SUBSTR(a.YWKM,1,3) = '140'
				   AND  a.ZJLY IN ('SH','SZ')
		           AND  c.ZQDM IS NULL
                   THEN a.SRJE-a.FCJE
				   ELSE 0
				   END 
              )                              as BUYIN_SEC_CPTL  --买入证券资金
		 ,SUM(CASE WHEN a.YWKM IN ('13101','13115')
                   AND  c.ZQDM IS NULL		 
                   THEN a.SRJE-a.FCJE
				   WHEN SUBSTR(a.YWKM,1,3) = '141'
		           AND  c.ZQDM IS NULL
				   AND  a.ZJLY IN ('SH','SZ')
                   THEN a.SRJE-a.FCJE
				   ELSE 0
				   END 
              )                              as SELL_SEC_CPTL  --卖出证券资金
		,SUM(CASE WHEN a.YWKM IN ('13031','13032','13131')		           
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as PRCH_CPTL  --申购资金
		,SUM(CASE WHEN a.YWKM IN ('13021','13022','13121','13122')		           
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as REPO_CPTL  --回购资金
	   ,SUM(CASE WHEN a.YWKM IN ('13023','13024','13025','13123','13124','13125')		           
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as QOT_REPO_CPTL  --报价回购资金
	    ,SUM(CASE WHEN a.YWKM IN ('13026','13027','13126','13127')		           
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as PROMS_RPHS_CPTL  --约定购回资金
		 ,SUM(CASE WHEN a.YWKM IN ('13028','13029','13128','13129')		           
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as STK_PLG_REPO_CPTL  --股票质押回购资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'	
                  AND  a.ZJLY = 'SH'
                  AND a.XGPZ = '511990'			  
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as TRD_CPTL_511990  --华宝添益(511990)交易资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'	
                  AND  a.ZJLY = 'SH'
                  AND a.XGPZ = '511880'			  
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as TRD_CPTL_511880  --银华日利(511880)交易资金 
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'	
                  AND  a.ZJLY = 'SH'
                  AND a.XGPZ = '519888'			  
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as TRD_CPTL_519888  --添富快线(519888)交易资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'	                 
                   AND a.XGPZ = 'A30003'			  
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as TRD_CPTL_A30003  --现金添利资金交易资金	
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'	                 
                   AND a.XGPZ < > 'A30003'
                   AND SUBSTR(a.XGPZ,1,1) = 'A'				   
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as CO_PROD_TRD_CPTL  --公司理财（除现金添利）交易资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'	                                  
                   AND SUBSTR(a.XGPZ,1,2) = '95'				   
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as GJ_CO_PROD_TRD_CPTL  --国君产品交易资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) < > '142'
		          AND  c.ZQDM IS NOT NULL
				  AND  a.XGPZ NOT IN ('519888','511880','511990')
                  THEN a.SRJE-a.FCJE				   
				  ELSE 0
				  END 
              )                          as OTH_EXG_CCY_FND_TRD_CPTL --其他场内货币基金交易资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) IN ('140','141')		
                   AND d.JJDM IS NOT NULL
                   AND SUBSTR(a.XGPZ,1,1) < > 'A'
                   AND SUBSTR(a.XGPZ,1,2) < > '95'				   
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as OPN_FND_TRD_CPTL  --开放式基金交易资金
		,SUM(CASE WHEN SUBSTR(a.YWKM,1,3) IN ('140','141')		
                   AND e.CPDM IS NOT NULL			   
                   THEN a.SRJE-a.FCJE				  
				   ELSE 0
				   END 
              )                              as BANK_PORD_TRD_CPTL  --银行产品交易资金
			  
 FROM   EDW_PROD.T_EDW_T05_TZJMXLS  a
 LEFT JOIN (SELECT SecurityCode as ZQDM
                  ,CASE WHEN  SUBSTR(SecurityCode,1,3) IN ('500','501','502','505','510','511','512','513','518','519')
				        THEN 'SH'
						ELSE 'SZ'
						END as JYS
            FROM fundext.dbo_MF_FundArchives 
            WHERE fundtypecode = 1109  
			AND SUBSTR(SecurityCode,1,3) IN ('500','501','502','505','510','511','512','513','518','519','150','159','160','161','162','163','164','165','166','167','168','169','184','515')
			AND DT = '%d{yyyyMMdd}'	
            UNION 	
            SELECT exapplyingcode as ZQDM
                  ,CASE WHEN  SUBSTR(SecurityCode,1,3) IN ('500','501','502','505','510','511','512','513','518','519','515')
				        THEN 'SH'
						ELSE 'SZ'
						END as JYS
            FROM fundext.dbo_MF_FundArchives 
            WHERE fundtypecode = 1109  
			AND SUBSTR(SecurityCode,1,3) IN ('500','501','502','505','510','511','512','513','518','519','150','159','160','161','162','163','164','165','166','167','168','169','184','515')
			AND DT = '%d{yyyyMMdd}'	
			AND LENGTH(TRIM(exapplyingcode)) > 0
			
			)  c
 ON       a.ZJLY = c.JYS
 AND      a.XGPZ = c.ZQDM
 LEFT JOIN EDW_PROD.T_EDW_T04_TOF_JJXX d
 ON       a.XGPZ = d.JJDM
 AND      d.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN EDW_PROD.T_EDW_T99_TJRCP_CPDM e
 ON       a.XGPZ = e.CPDM
 AND      e.BUS_DATE = %d{yyyyMMdd}
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP4 b
                 WHERE a.GTZJZH = b.CNTR_CPTL_ACCNT
				 AND a.KHH = b.CUST_NO
                )
AND    a.XTBS = 'JZJY'
AND   SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) ;			

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON
(                CPTL_ACCNT_ACTA                --资金帐户数(RMB)
                ,STRT_CPTL_BAL                   --期初资金余额(RMB)  
                ,FNL_CPTL_BAL                    --期末资金余额(RMB)    
                ,FNL_MKTVAL                     --期末市值(RMB)      
                ,FNL_GL                         --期末负债(RMB)    
                ,DEPIN_CPTL                     --本月资金存
                ,WTHDR_CPTL                     --本月资金取    
                ,BUYIN_SEC_CPTL                 --买入证券资金(剔除场内货币基金)
                ,SELL_SEC_CPTL                  --卖出证券资金(剔除场内货币基金)								   
                ,PRCH_CPTL                      --申购资金
				,REPO_CPTL                      --回购资金
				,QOT_REPO_CPTL                  --报价回购资金
				,PROMS_RPHS_CPTL                --约定购回资金
				,STK_PLG_REPO_CPTL              --股票质押回购资金
				,TRD_CPTL_511990                --华宝添益(511990)交易资金
				,TRD_CPTL_511880                --银华日利(511880)交易资金 
				,TRD_CPTL_519888                --添富快线(519888)交易资金
				,TRD_CPTL_A30003                --现金添利资金交易资金	
				,CO_PROD_TRD_CPTL               --公司理财（除现金添利）交易资金
				,GJ_CO_PROD_TRD_CPTL            --国君产品交易资金
				,OTH_EXG_CCY_FND_TRD_CPTL       --其他场内货币基金交易资金
				,OPN_FND_TRD_CPTL               --开放式基金交易资金
				,BANK_PORD_TRD_CPTL             --银行产品交易资金
				,OTH_CHG_CPTL                   --其他变动资金
				,DATA_SRC                       --数据来源     		   
) 
 PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
SELECT           t.CPTL_ACCNT_ACTA                   as CPTL_ACCNT_ACTA      --资金帐户数(RMB)
                ,NVL(a1.ACCNT_BAL,0)                 as STRT_CPTL_BAL         --期初资金余额(RMB)  
                ,t.FNL_CPTL_BAL                       as FNL_CPTL_BAL          --期末资金余额(RMB)    
                ,NVL(a2.FNL_MKTVAL_RMB,0)            as FNL_MKTVAL           --期末市值(RMB)      
                ,NVL(a2.FNL_GL_RMB,0)                as FNL_GL_RMB           --期末负债(RMB)    
                ,NVL(a3.DEPIN_CPTL,0)                as DEPIN_CPTL                     --本月资金存
                ,NVL(a3.WTHDR_CPTL,0)                as WTHDR_CPTL                     --本月资金取    
                ,NVL(a3.BUYIN_SEC_CPTL,0)            as BUYIN_SEC_CPTL                 --买入证券资金(剔除场内货币基金)
                ,NVL(a3.SELL_SEC_CPTL,0)             as SELL_SEC_CPTL                  --卖出证券资金(剔除场内货币基金)								   
                ,NVL(a3.PRCH_CPTL,0)                 as PRCH_CPTL                      --申购资金
				,NVL(a3.REPO_CPTL,0)                 as REPO_CPTL                      --回购资金
				,NVL(a3.QOT_REPO_CPTL,0)             as QOT_REPO_CPTL                  --报价回购资金
				,NVL(a3.PROMS_RPHS_CPTL,0)           as PROMS_RPHS_CPTL                --约定购回资金
				,NVL(a3.STK_PLG_REPO_CPTL,0)         as STK_PLG_REPO_CPTL              --股票质押回购资金
				,NVL(a3.TRD_CPTL_511990,0)           as TRD_CPTL_511990                --华宝添益(511990)交易资金
				,NVL(a3.TRD_CPTL_511880,0)           as TRD_CPTL_511880                --银华日利(511880)交易资金 
				,NVL(a3.TRD_CPTL_519888,0)           as TRD_CPTL_519888                --添富快线(519888)交易资金
				,NVL(a3.TRD_CPTL_A30003,0)           as TRD_CPTL_A30003                --现金添利资金交易资金	
				,NVL(a3.CO_PROD_TRD_CPTL,0)          as CO_PROD_TRD_CPTL               --公司理财（除现金添利）交易资金
				,NVL(a3.GJ_CO_PROD_TRD_CPTL,0)       as GJ_CO_PROD_TRD_CPTL            --国君产品交易资金
				,NVL(a3.OTH_EXG_CCY_FND_TRD_CPTL,0)  as OTH_EXG_CCY_FND_TRD_CPTL       --其他场内货币基金交易资金
				,NVL(a3.OPN_FND_TRD_CPTL,0)          as OPN_FND_TRD_CPTL               --开放式基金交易资金
				,NVL(a3.BANK_PORD_TRD_CPTL,0)        as BANK_PORD_TRD_CPTL             --银行产品交易资金
				,t.FNL_CPTL_BAL-NVL(a1.ACCNT_BAL,0)-(NVL(a3.DEPIN_CPTL,0)+NVL(a3.WTHDR_CPTL,0)+NVL(a3.BUYIN_SEC_CPTL,0)+NVL(a3.SELL_SEC_CPTL,0)+NVL(a3.PRCH_CPTL,0)+NVL(a3.REPO_CPTL,0)
                 +NVL(a3.QOT_REPO_CPTL,0)+NVL(a3.PROMS_RPHS_CPTL,0)+NVL(a3.STK_PLG_REPO_CPTL,0)
                 +NVL(a3.TRD_CPTL_511990,0)+NVL(a3.TRD_CPTL_511880,0)+NVL(a3.TRD_CPTL_519888,0)+NVL(a3.TRD_CPTL_A30003,0)+NVL(a3.CO_PROD_TRD_CPTL,0)+NVL(a3.GJ_CO_PROD_TRD_CPTL,0)+NVL(a3.OTH_EXG_CCY_FND_TRD_CPTL,0)+NVL(a3.OPN_FND_TRD_CPTL,0)+NVL(a3.BANK_PORD_TRD_CPTL,0))
                                                     as OTH_CHG_CPTL                   --其他变动资金
				,'所有合格客户'                      as DATA_SRC                       --数据来源  
 FROM (SELECT CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON
            ,SUM(CASE WHEN SUBSTR(CNTR_CPTL_ACCNT,1,4) < > '4444'
       			      THEN 1
				      ELSE 0
				      END
				) as CPTL_ACCNT_ACTA
            ,SUM(ACCNT_BAL) as FNL_CPTL_BAL			
       FROM  DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP
	   GROUP BY YEAR_MON
	  )                           t    
 LEFT JOIN DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP1 a1
 ON       t.YEAR_MON = a1.YEAR_MON
 LEFT JOIN  DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP2 a2
 ON       t.YEAR_MON = a2.YEAR_MON
 LEFT JOIN  DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP3 a3
 ON       t.YEAR_MON = a3.YEAR_MON
 UNION ALL
 SELECT           t.CPTL_ACCNT_ACTA                   as CPTL_ACCNT_ACTA      --资金帐户数(RMB)
                ,NVL(a1.ACCNT_BAL,0)                 as STRT_CPTL_BAL         --期初资金余额(RMB)  
                ,t.FNL_CPTL_BAL                       as FNL_CPTL_BAL          --期末资金余额(RMB)    
                ,NVL(a2.FNL_MKTVAL_RMB,0)            as FNL_MKTVAL           --期末市值(RMB)      
                ,NVL(a2.FNL_GL_RMB,0)                as FNL_GL_RMB           --期末负债(RMB)    
                ,NVL(a3.DEPIN_CPTL,0)                as DEPIN_CPTL                     --本月资金存
                ,NVL(a3.WTHDR_CPTL,0)                as WTHDR_CPTL                     --本月资金取    
                ,NVL(a3.BUYIN_SEC_CPTL,0)            as BUYIN_SEC_CPTL                 --买入证券资金(剔除场内货币基金)
                ,NVL(a3.SELL_SEC_CPTL,0)             as SELL_SEC_CPTL                  --卖出证券资金(剔除场内货币基金)								   
                ,NVL(a3.PRCH_CPTL,0)                 as PRCH_CPTL                      --申购资金
				,NVL(a3.REPO_CPTL,0)                 as REPO_CPTL                      --回购资金
				,NVL(a3.QOT_REPO_CPTL,0)             as QOT_REPO_CPTL                  --报价回购资金
				,NVL(a3.PROMS_RPHS_CPTL,0)           as PROMS_RPHS_CPTL                --约定购回资金
				,NVL(a3.STK_PLG_REPO_CPTL,0)         as STK_PLG_REPO_CPTL              --股票质押回购资金
				,NVL(a3.TRD_CPTL_511990,0)           as TRD_CPTL_511990                --华宝添益(511990)交易资金
				,NVL(a3.TRD_CPTL_511880,0)           as TRD_CPTL_511880                --银华日利(511880)交易资金 
				,NVL(a3.TRD_CPTL_519888,0)           as TRD_CPTL_519888                --添富快线(519888)交易资金
				,NVL(a3.TRD_CPTL_A30003,0)           as TRD_CPTL_A30003                --现金添利资金交易资金	
				,NVL(a3.CO_PROD_TRD_CPTL,0)          as CO_PROD_TRD_CPTL               --公司理财（除现金添利）交易资金
				,NVL(a3.GJ_CO_PROD_TRD_CPTL,0)       as GJ_CO_PROD_TRD_CPTL            --国君产品交易资金
				,NVL(a3.OTH_EXG_CCY_FND_TRD_CPTL,0)  as OTH_EXG_CCY_FND_TRD_CPTL       --其他场内货币基金交易资金
				,NVL(a3.OPN_FND_TRD_CPTL,0)          as OPN_FND_TRD_CPTL               --开放式基金交易资金
				,NVL(a3.BANK_PORD_TRD_CPTL,0)        as BANK_PORD_TRD_CPTL             --银行产品交易资金
				,t.FNL_CPTL_BAL-NVL(a1.ACCNT_BAL,0)-(NVL(a3.DEPIN_CPTL,0)+NVL(a3.WTHDR_CPTL,0)+NVL(a3.BUYIN_SEC_CPTL,0)+NVL(a3.SELL_SEC_CPTL,0)+NVL(a3.PRCH_CPTL,0)+NVL(a3.REPO_CPTL,0)
                 +NVL(a3.QOT_REPO_CPTL,0)+NVL(a3.PROMS_RPHS_CPTL,0)+NVL(a3.STK_PLG_REPO_CPTL,0)
                 +NVL(a3.TRD_CPTL_511990,0)+NVL(a3.TRD_CPTL_511880,0)+NVL(a3.TRD_CPTL_519888,0)+NVL(a3.TRD_CPTL_A30003,0)+NVL(a3.CO_PROD_TRD_CPTL,0)+NVL(a3.GJ_CO_PROD_TRD_CPTL,0)+NVL(a3.OTH_EXG_CCY_FND_TRD_CPTL,0)+NVL(a3.OPN_FND_TRD_CPTL,0)+NVL(a3.BANK_PORD_TRD_CPTL,0))
                                                     as OTH_CHG_CPTL                   --其他变动资金
				,'当月新开客户'                      as DATA_SRC                       --数据来源  
 FROM (SELECT CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON
            ,SUM(CASE WHEN SUBSTR(CNTR_CPTL_ACCNT,1,4) < > '4444'
       			      THEN 1
				      ELSE 0
				      END
				) as CPTL_ACCNT_ACTA
            ,SUM(ACCNT_BAL) as FNL_CPTL_BAL			
       FROM  DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP4
	   GROUP BY YEAR_MON
	  )                           t    
 LEFT JOIN DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP5 a1
 ON       t.YEAR_MON = a1.YEAR_MON
 LEFT JOIN  DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP6 a2
 ON       t.YEAR_MON = a2.YEAR_MON
 LEFT JOIN  DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP7 a3
 ON       t.YEAR_MON = a3.YEAR_MON
 ;
 ----
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP1 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP2 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP3 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP4 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP5 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP6 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP7 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON_TEMP8 ;
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_ORDI_CPTL_ACCNT_RMB_CPTL_CHG_MON;
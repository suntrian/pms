--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:客户标签行为数据表                                                              */
--/* 创建人:常静静                                                                             */
--/* 创建时间:2018-08-31                                                                        */ 

----证券持仓历史表(近一年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_SEC_HLD_STK_TMP;
CREATE TABLE DDW_PROD.T_DDW_SEC_HLD_STK_TMP
AS
  SELECT
         T1.CUST_NO
		,T1.SEC_CD
		,T1.CCY_CD
		,T1.SEC_QTY
		,T1.SEC_MKTVAL
		,T1.SYS_SRC
		,T1.BUS_DATE
    FROM 
        (
          SELECT CUST_NO,EXG,SEC_CGY,SEC_CD,CCY_CD,SEC_QTY,SEC_MKTVAL,SYS_SRC,BUS_DATE
          FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
          WHERE SEC_QTY > 0 AND BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
        ) T1
    INNER JOIN 
        (
          SELECT DISTINCT EXG,SEC_CD_PFX,SEC_CGY_PFX FROM DDW_PROD.T_DDW_CFG_SEC_TRD_CL
          WHERE SEC_CL_CD IN ('001','002','003','004','005','006','007','008','012','013','015','016','063')
        ) T2
          ON T1.EXG = T2.EXG 
         AND SUBSTR(T1.SEC_CD,1,3) = T2.SEC_CD_PFX
         AND (SUBSTR(T1.SEC_CGY,1,1) = T2.SEC_CGY_PFX OR SUBSTR(T1.SEC_CGY,1,3) = T2.SEC_CGY_PFX)
;

----证券交易历史表(近一年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_SEC_TRD_STK_TMP;
CREATE TABLE DDW_PROD.T_DDW_SEC_TRD_STK_TMP
AS
  SELECT
         T1.CUST_NO
		,T1.EXG
        ,T1.SYS_SRC
		,T1.CCY_CD
		,NVL(T3.ZHHL,1) AS EXG_RATE
		,T2.BS_DRCT
		,T1.ODR_MOD
		,T1.SEC_CD
		,T1.MTCH_QTY
		,T1.MTCH_AMT
		,T1.MTCH_AMT * NVL(T3.ZHHL,1) AS MTCH_AMT_RMB
		,T1.BUS_DATE
  FROM 
       (
         SELECT CUST_NO,EXG,SYS_SRC,CCY_CD,SEC_CGY,ODR_CGY,ODR_MOD,SEC_CD,MTCH_QTY,MTCH_AMT,BUS_DATE
         FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
         WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
       ) T1
  INNER JOIN DDW_PROD.T_DDW_CFG_SEC_TRD_CL T2
   ON T1.EXG = T2.EXG AND SUBSTR(T1.SEC_CD,1,3) = T2.SEC_CD_PFX
  AND (SUBSTR(T1.SEC_CGY,1,1) = T2.SEC_CGY_PFX OR SUBSTR(T1.SEC_CGY,1,3) = T2.SEC_CGY_PFX)
  AND T1.ODR_CGY = T2.TRD_CGY
  AND T2.SEC_CL_CD IN ('001','002','003','004','005','006','007','008','012','013','015','016','063')
  LEFT JOIN EDW_PROD.T_EDW_T99_HLZH T3
   ON T1.CCY_CD = T3.BZDM
  AND T1.BUS_DATE = T3.BUS_DATE
;

----客户持股临时表(近一年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP1;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP1
AS
  SELECT
         T1.CUST_NO
        ,T1.HLD_QTY_WTHAYR                                                  --近一年持股只数
        ,NVL(T2.HLD_DYS_WTHAYR,0) AS HLD_DYS_WTHAYR                         --近一年持股天数
        ,NVL(T3.HLD_QTY,0) AS HLD_QTY                                         --持股只数
  FROM
  (
    SELECT
           T1.CUST_NO
          ,COUNT(DISTINCT T1.SEC_CD) AS HLD_QTY_WTHAYR
    FROM DDW_PROD.T_DDW_SEC_HLD_STK_TMP T1
    GROUP BY T1.CUST_NO
  ) T1
  LEFT JOIN
  (
    SELECT
           T1.CUST_NO
          ,COUNT(DISTINCT T1.BUS_DATE) AS HLD_DYS_WTHAYR
    FROM DDW_PROD.T_DDW_SEC_HLD_STK_TMP T1
    GROUP BY T1.CUST_NO
  ) T2
  ON T1.CUST_NO = T2.CUST_NO
  LEFT JOIN
  (
    SELECT
           T1.CUST_NO
          ,COUNT(DISTINCT T1.SEC_CD) AS HLD_QTY
    FROM DDW_PROD.T_DDW_SEC_HLD_STK_TMP T1
    WHERE T1.BUS_DATE = %d{yyyyMMdd}
    GROUP BY T1.CUST_NO
  ) T3
  ON T1.CUST_NO = T3.CUST_NO
;

----计算客户周转率临时表(近一年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP2;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP2
AS
  SELECT
         NVL(T1.CUST_NO,T2.CUST_NO) AS CUST_NO
        ,NVL(T1.AVG_AST,0) AS AVG_AST_WTHAYR                                         --近一年日均资产(不包含质押回购)
  	    ,NVL(T2.MTCH_AMT_RMB,0) AS MTCH_AMT_RMB_WTHAYR                               --近一年成交金额
  FROM 
  (
    SELECT
           T1.CUST_NO
          ,AVG(NVL(T1.TOL_AST,0) - NVL(T2.ORDI_ACCT_GL_PRINP,0)) AS AVG_AST
		--,AVG(NVL(T1.TOL_AST,0) + NVL(T1.TURN_OUT_MKTVAL,0) + NVL(T1.TURN_OUT_AMT,0) - NVL(T2.ORDI_ACCT_GL_PRINP,0)) AS AVG_AST
    FROM 
         (
           SELECT CUST_NO,TOL_AST,BUS_DATE
           FROM DDW_PROD.T_DDW_CUST_STATMT_DAY
           WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
         ) T1
    LEFT JOIN 
    (
      SELECT CUST_NO,BUS_DATE,SUM(ORDI_ACCT_GL_PRINP) AS ORDI_ACCT_GL_PRINP
      FROM DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS
      WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
      AND SEC_CGY NOT LIKE 'H%'
      GROUP BY CUST_NO,BUS_DATE
    ) T2
    ON T1.BUS_DATE = T2.BUS_DATE
    AND T1.CUST_NO = T2.CUST_NO
    GROUP BY T1.CUST_NO
  ) T1
  FULL JOIN
  (
    SELECT CUST_NO,SUM(MTCH_AMT_RMB) AS MTCH_AMT_RMB
      FROM DDW_PROD.T_DDW_SEC_TRD_STK_TMP
  	GROUP BY CUST_NO
  ) T2
  ON T1.CUST_NO = T2.CUST_NO
;

----计算客户盈利能力临时表(近一年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP3;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP3
AS
  SELECT
       T1.CUST_NO
  	  ,T1.NET_INCM_AVG_WTHAYR                                                                                             --近一年日均收益率
  	  ,T2.NEWST_PRC_CURR                                                                                                  --当前大盘点数
  	  ,T3.NEWST_PRC_LASTRY                                                                                                --上年同期大盘点数
  	  ,T1.NET_INCM_AVG_WTHAYR - ((T2.NEWST_PRC_CURR - T3.NEWST_PRC_LASTRY) / T3.NEWST_PRC_LASTRY) AS EXCD_YLD_RATE        --超额收益率
  FROM
  (
    SELECT
           CUST_NO
          ,SUM(TOL_YLD) / AVG(TOL_AST - TOL_GL) AS NET_INCM_AVG_WTHAYR                           --近一年日均收益率
		--,AVG(NET_INCM) AS NET_INCM_AVG_WTHAYR                                                  --近一年日均收益率
    FROM DDW_PROD.T_DDW_CUST_STATMT_DAY T1
    WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
    GROUP BY CUST_NO
  ) T1
  CROSS JOIN
  (
    SELECT NEWST_PRC AS NEWST_PRC_CURR
    FROM DDW_PROD.T_DDW_STATMT_IDXQOT_DAY
    WHERE BUS_DATE = %d{yyyyMMdd}
    AND EXG = 'SH'
  ) T2
  CROSS JOIN
  (
    SELECT DISTINCT T1.NEWST_PRC AS NEWST_PRC_LASTRY                                                
    FROM DDW_PROD.T_DDW_STATMT_IDXQOT_DAY t1
    INNER JOIN EDW_PROD.T_EDW_T99_TRD_DATE T2
    ON T1.BUS_DATE = T2.TRD_DT
    AND T2.NAT_DT = CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT)
    AND T2.BUS_DATE = %d{yyyyMMdd}
    WHERE T1.EXG = 'SH'
  ) T3
;


DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_1;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_1
AS
SELECT
 A.CUST_NO
,SUM(CAST(CASE WHEN C.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059') AND C.BS_DRCT IN (1,2)
			   THEN A.MTCH_AMT
          ELSE 0 END AS DECIMAL(38,2))) AS TRD_VOL_CNJJ
,SUM(CAST(CASE WHEN C.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059') AND C.BS_DRCT IN (1,2) AND D.SECURITYCODE IS NOT NULL
			   THEN A.MTCH_AMT
          ELSE 0 END AS DECIMAL(38,2))) AS TRD_VOL_HBJJ
,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('056') AND A.ODR_CGY IN (1111,2222,42,43,83) AND D.SECURITYCODE IS NULL
               THEN a.MTCH_AMT
    ELSE 0 END AS DECIMAL(38,2))) AS TRD_VOL_LOF_RSS
,SUM(CAST(CASE WHEN c.SEC_CL_CD IN ('057','061') AND A.ODR_CGY IN (1111,2222,42,43,83) AND D.SECURITYCODE IS NULL
               THEN a.MTCH_AMT
         ELSE 0 END AS DECIMAL(38,2))) AS TRD_VOL_ETF_RSS
FROM 
     (
       SELECT CUST_NO,SEC_CD,EXG,SEC_CGY,ODR_CGY,MTCH_AMT
       FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
       WHERE MTCH_AMT > 0 AND BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01'),'yyyyMMdd','yyyyMMdd',-2,0,0) AS INT) AND %d{yyyyMMdd}
     ) A
LEFT JOIN FUNDEXT.DBO_MF_FUNDARCHIVES D
ON D.SECURITYCODE = A.SEC_CD
AND D.DT = '%d{yyyyMMdd}'
AND D.FUNDTYPECODE = 1109
LEFT JOIN DDW_PROD.T_DDW_CFG_SEC_TRD_CL C
ON A.EXG = C.EXG
AND SUBSTR(A.SEC_CD,1,3) = C.SEC_CD_PFX
AND (SUBSTR(A.SEC_CGY,1,1) = C.SEC_CGY_PFX OR SUBSTR(A.SEC_CGY,1,3) = C.SEC_CGY_PFX)
AND A.ODR_CGY = C.TRD_CGY
GROUP BY A.CUST_NO
;


DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_2;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_2
AS
  SELECT CUST_NO
        , CAST(SUM(TRD_VOL_HA) + SUM(TRD_VOL_SA) + SUM(TRD_VOL_SMS) + SUM(TRD_VOL_GEM)+ SUM(ORDI_TRD_VOL_TA) + SUM(ORDI_TRD_VOL_TU_RMB)
		 + SUM(ORDI_TRD_VOL_HB_RMB) + SUM(ORDI_TRD_VOL_SB_RMB) + SUM(ORDI_TRD_VOL_HK) + SUM(ORDI_TRD_VOL_SK)
		 + SUM(WRNT_TRD_VOL) + SUM(TRD_VOL_AK) + SUM(TRD_VOL_RK) AS DECIMAL(38,2))
		AS STK_FUND_TRD_QTY                                                                     --近两年股基交易量
		, CAST(SUM(ORDI_TRD_VOL_REPO) AS DECIMAL(38,2)) AS QOT_REPO_TRD_QTY                     --近两年报价回购交易量
  FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01'),'yyyyMMdd','yyyyMMdd',-2,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
;


DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_3;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_3
AS
  SELECT CUST_NO
        ,CAST(SUM(PROD_SCRP_AMT) + SUM(PROD_PRCH_AMT) + SUM(PROD_FIXINV_AMT) + SUM(PROD_RDMPT_AMT) 
		 + SUM(ORDI_TRD_VOL_BOND) + SUM(CRD_TRD_VOL_BOND) AS DECIMAL(38,2)) AS PROD_TRD_QTY        --近两年产品交易量
  FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01'),'yyyyMMdd','yyyyMMdd',-2,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
;


----客户股票交易临时表(近两年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4
AS
  SELECT T.CUST_NO
        ,CEIL(T.STK_FUND_TRD_QTY + NVL(T1.TRD_VOL_CNJJ,0) - NVL(T1.TRD_VOL_HBJJ,0) - NVL(T1.TRD_VOL_ETF_RSS,0) - NVL(T1.TRD_VOL_LOF_RSS,0)) AS STK_FUND_TRD_QTY        --近两年股基交易量
		,CEIL(T.QOT_REPO_TRD_QTY) AS QOT_REPO_TRD_QTY                                                                                                                  --近两年报价回购交易量
  FROM DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_2 T
  LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_1 T1
  ON T.CUST_NO = T1.CUST_NO
;


----客户产品交易临时表(近两年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP5;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP5
AS
  SELECT T.CUST_NO
        ,CEIL(T.PROD_TRD_QTY + NVL(T1.TRD_VOL_HBJJ,0) + NVL(T1.TRD_VOL_ETF_RSS,0) + NVL(T1.TRD_VOL_LOF_RSS,0))AS PROD_TRD_QTY                --近两年产品交易量
  FROM DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_3 T
  LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_1 T1
  ON T.CUST_NO = T1.CUST_NO
;


DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_1;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_1
AS
SELECT
 A.CUST_NO
,A.BUS_DATE
,SUM(CASE WHEN C.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
          THEN A.SEC_MKTVAL
     ELSE 0 END) AS MKTVAL_EXG_FND                                                                                                                      --场内基金市值
,SUM(CAST(CASE WHEN C.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059') AND D.SECURITYCODE IS NOT NULL
			   THEN A.SEC_MKTVAL
          ELSE 0 END AS DECIMAL(38,2))) AS MKTVAL_HBJJ                                                                                                  --货币基金市值
,SUM(CASE WHEN C.SEC_CL_CD IN ('056') AND D.SECURITYCODE IS NULL THEN A.SEC_MKTVAL ELSE 0 END) AS MKTVAL_LOF_FND                                        --LOF市值
,SUM(CASE WHEN C.SEC_CL_CD IN ('056') AND D.SECURITYCODE IS NULL AND E.JJDM IS NOT NULL THEN A.SEC_MKTVAL ELSE 0 END) AS MKTVAL_LOF_ZJJ                 --LOF中分级基金子基金市值
FROM
     (
       SELECT CUST_NO,BUS_DATE,SEC_CD,EXG,SEC_CGY,SEC_MKTVAL
       FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
       WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01'),'yyyyMMdd','yyyyMMdd',-2,0,0) AS INT) AND %d{yyyyMMdd}
     ) A
LEFT JOIN FUNDEXT.DBO_MF_FUNDARCHIVES D
ON D.SECURITYCODE = A.SEC_CD
AND D.DT = '%d{yyyyMMdd}'
AND D.FUNDTYPECODE = 1109
LEFT JOIN (SELECT DISTINCT EXG,SEC_CD_PFX,SEC_CGY_PFX,SEC_CL_CD FROM DDW_PROD.T_DDW_CFG_SEC_TRD_CL) C
ON A.EXG = C.EXG
AND SUBSTR(A.SEC_CD,1,3) = C.SEC_CD_PFX
AND (SUBSTR(A.SEC_CGY,1,1) = C.SEC_CGY_PFX OR SUBSTR(A.SEC_CGY,1,3) = C.SEC_CGY_PFX)
LEFT JOIN EDW_PROD.T_EDW_T04_TFXJJDM_LS E
ON A.BUS_DATE = E.BUS_DATE
AND A.SEC_CD = E.JJDM
GROUP BY A.CUST_NO,A.BUS_DATE
;


DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_2;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_2
AS
SELECT
         CUST_NO
		,BUS_DATE
		,SUM( MKTVAL_HA + MKTVAL_SA + MKTVAL_SMS + MKTVAL_GEM + ORDI_MKTVAL_TA + ORDI_MKTVAL_TU_USD + ORDI_MKTVAL_HB_USD + ORDI_MKTVAL_SB_HKD
              + ORDI_MKTVAL_HK + ORDI_MKTVAL_SK + WRNT_RGHT_HLD_MKTVAL + WRNT_DUTY_HLD_MKTVAL
		    ) AS SEC_MKTVAL                                                                                                             --近两年证券市值峰值
FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01'),'yyyyMMdd','yyyyMMdd',-2,0,0) AS INT) AND %d{yyyyMMdd}
AND MKTVAL_HA + MKTVAL_SA + MKTVAL_SMS + MKTVAL_GEM + ORDI_MKTVAL_TA + ORDI_MKTVAL_TU_USD + ORDI_MKTVAL_HB_USD + ORDI_MKTVAL_SB_HKD + ORDI_MKTVAL_HK + ORDI_MKTVAL_SK + WRNT_RGHT_HLD_MKTVAL + WRNT_DUTY_HLD_MKTVAL > 0
GROUP BY CUST_NO,BUS_DATE
;


DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_3;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_3
AS
SELECT
         CUST_NO
		,BUS_DATE
		,SUM(ORDI_MKTVAL_PROD + ORDI_MKTVAL_BOND + CRD_MKTVAL_BOND + ORDI_MKTVAL_REPO) AS PROD_MKTVAL                                  --近两年产品市值峰值
FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01'),'yyyyMMdd','yyyyMMdd',-2,0,0) AS INT) AND %d{yyyyMMdd}
AND ORDI_MKTVAL_PROD + ORDI_MKTVAL_BOND + CRD_MKTVAL_BOND + ORDI_MKTVAL_REPO > 0
GROUP BY CUST_NO,BUS_DATE
;


----客户产品持仓临时表(近两年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6
AS
SELECT NVL(T.CUST_NO,T1.CUST_NO) AS CUST_NO,MAX(NVL(T.PROD_MKTVAL,0) + NVL(T1.PROD_MKTVAL1,0)) AS PROD_MKTVAL                             --近两年产品市值峰值
FROM DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_3 T
FULL JOIN
(
SELECT CUST_NO,BUS_DATE,(MKTVAL_HBJJ + MKTVAL_LOF_FND - MKTVAL_LOF_ZJJ) AS PROD_MKTVAL1
FROM DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_1
WHERE MKTVAL_HBJJ + MKTVAL_LOF_FND - MKTVAL_LOF_ZJJ > 0
) T1
ON T.CUST_NO = T1.CUST_NO
AND T.BUS_DATE = T1.BUS_DATE
GROUP BY NVL(T.CUST_NO,T1.CUST_NO)
;


----客户股票持仓临时表(近两年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP7;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP7
AS
SELECT NVL(T.CUST_NO,T1.CUST_NO) AS CUST_NO,MAX(NVL(T.SEC_MKTVAL,0) + NVL(T1.SEC_MKTVAL1,0)) AS SEC_MKTVAL                             --近两年证券市值峰值
FROM DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_2 T
FULL JOIN
(
SELECT CUST_NO,BUS_DATE,(MKTVAL_EXG_FND - MKTVAL_HBJJ - MKTVAL_LOF_FND + MKTVAL_LOF_ZJJ) AS SEC_MKTVAL1
FROM DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_1
WHERE MKTVAL_EXG_FND - MKTVAL_HBJJ - MKTVAL_LOF_FND + MKTVAL_LOF_ZJJ > 0
) T1
ON T.CUST_NO = T1.CUST_NO
AND T.BUS_DATE = T1.BUS_DATE
GROUP BY NVL(T.CUST_NO,T1.CUST_NO)
;


----客户股票市场交易临时表(近一年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP8;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP8
AS
  SELECT
         T1.CUST_NO
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('001','002') THEN T1.MTCH_QTY ELSE 0 END) AS A_MTCH_QTY_WTHAYR                       --近一年A股交易数量
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('001','002') THEN T1.MTCH_AMT * NVL(T3.ZHHL,1) ELSE 0 END) AS A_MTCH_AMT_WTHAYR      --近一年A股交易金额
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('005','063') THEN T1.MTCH_QTY ELSE 0 END) AS B_MTCH_QTY_WTHAYR                       --近一年B股交易数量
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('005','063') THEN T1.MTCH_AMT * NVL(T3.ZHHL,1) ELSE 0 END) AS B_MTCH_AMT_WTHAYR      --近一年B股交易金额
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('008') THEN T1.MTCH_QTY ELSE 0 END) AS NEW_T3BOD_MTCH_QTY_WTHAYR                     --近一年新三板交易数量
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('008') THEN T1.MTCH_AMT * NVL(T3.ZHHL,1) ELSE 0 END) AS NEW_T3BOD_MTCH_AMT_WTHAYR    --近一年新三板交易金额
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('004') THEN T1.MTCH_QTY ELSE 0 END) AS GEM_MTCH_QTY_WTHAYR                           --近一年创业板交易数量
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('004') THEN T1.MTCH_AMT * NVL(T3.ZHHL,1) ELSE 0 END) AS GEM_MTCH_AMT_WTHAYR          --近一年创业板交易金额
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('003') THEN T1.MTCH_QTY ELSE 0 END) AS SME_MTCH_QTY_WTHAYR                           --近一年中小板交易数量
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('003') THEN T1.MTCH_AMT * NVL(T3.ZHHL,1) ELSE 0 END) AS SME_MTCH_AMT_WTHAYR          --近一年中小板交易金额
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('015','016') THEN T1.MTCH_QTY ELSE 0 END) AS HSK_MTCH_QTY_WTHAYR                     --近一年港股通交易数量
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('015','016') THEN T1.MTCH_AMT * NVL(T3.ZHHL,1) ELSE 0 END) AS HSK_MTCH_AMT_WTHAYR    --近一年港股通交易金额
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('012','013') THEN T1.MTCH_QTY ELSE 0 END) AS KCB_MTCH_QTY_WTHAYR                     --近一年科创板交易数量
		,SUM( CASE WHEN T2.SEC_CL_CD IN ('012','013') THEN T1.MTCH_AMT * NVL(T3.ZHHL,1) ELSE 0 END) AS KCB_MTCH_AMT_WTHAYR    --近一年科创板交易金额
    FROM 
         (
           SELECT CUST_NO,EXG,SEC_CD,SEC_CGY,CCY_CD,MTCH_QTY,MTCH_AMT,BUS_DATE
           FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
           WHERE MTCH_QTY > 0 AND SEC_NAME NOT LIKE '%ST%'
           AND BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
         ) T1
  INNER JOIN 
            (
              SELECT DISTINCT EXG,SEC_CD_PFX,SEC_CGY_PFX,SEC_CL_CD FROM DDW_PROD.T_DDW_CFG_SEC_TRD_CL
			   WHERE SEC_CL_CD IN ('001','002','003','004','005','006','007','008','012','013','015','016','063')
            ) T2
          ON T1.EXG = T2.EXG 
         AND SUBSTR(T1.SEC_CD,1,3) = T2.SEC_CD_PFX
         AND (SUBSTR(T1.SEC_CGY,1,1) = T2.SEC_CGY_PFX OR SUBSTR(T1.SEC_CGY,1,3) = T2.SEC_CGY_PFX)
  LEFT JOIN EDW_PROD.T_EDW_T99_HLZH T3
         ON T1.CCY_CD = T3.BZDM
		AND T1.BUS_DATE = T3.BUS_DATE
	GROUP BY T1.CUST_NO
;


----客户ST股票市场交易临时表(近一年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP9;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP9
AS
  SELECT
         T1.CUST_NO
		,SUM(T1.MTCH_QTY) AS ST_MTCH_QTY_WTHAYR                        --近一年ST板块交易数量
		,SUM(T1.MTCH_AMT * NVL(T3.ZHHL,1)) AS ST_MTCH_AMT_WTHAYR       --近一年ST板块交易金额
    FROM 
         (
           SELECT CUST_NO,EXG,SEC_CD,SEC_CGY,CCY_CD,MTCH_QTY,MTCH_AMT,BUS_DATE
           FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
           WHERE MTCH_QTY > 0 AND SEC_NAME LIKE '%ST%'
           AND BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
         ) T1
  INNER JOIN 
            (
              SELECT DISTINCT EXG,SEC_CD_PFX,SEC_CGY_PFX FROM DDW_PROD.T_DDW_CFG_SEC_TRD_CL
			   WHERE SEC_CL_CD IN ('001','002','003','004','005','006','007','008','012','013','015','016','063')
            ) T2
          ON T1.EXG = T2.EXG 
         AND SUBSTR(T1.SEC_CD,1,3) = T2.SEC_CD_PFX
         AND (SUBSTR(T1.SEC_CGY,1,1) = T2.SEC_CGY_PFX OR SUBSTR(T1.SEC_CGY,1,3) = T2.SEC_CGY_PFX)
  LEFT JOIN EDW_PROD.T_EDW_T99_HLZH T3
         ON T1.CCY_CD = T3.BZDM
		AND T1.BUS_DATE = T3.BUS_DATE
  GROUP BY T1.CUST_NO
;


----计算客户操作偏好临时表(近一年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP10;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP10
AS
  SELECT
       CUST_NO
  	  ,SUM(CASE WHEN SEC_HLD_DYS <= 7 THEN 1 ELSE 0 END) AS HLD_QTY_SHRTM_WTHAYR                              --近一年短线持股只数
  	  ,SUM(CASE WHEN SEC_HLD_DYS > 7 AND SEC_HLD_DYS <= 180 THEN 1 ELSE 0 END) AS HLD_QTY_MIDTM_WTHAYR        --近一年中长线持股只数
  	  ,SUM(CASE WHEN SEC_HLD_DYS > 180 THEN 1 ELSE 0 END) AS HLD_QTY_LONTM_WTHAYR                             --近一年长线持股只数
  FROM
  (
    SELECT
         T1.CUST_NO
  		,T1.SEC_CD
  		,COUNT(DISTINCT T1.BUS_DATE) AS SEC_HLD_DYS    --证券持股天数
      FROM 
           (
             SELECT CUST_NO,SEC_CD,EXG,SEC_CGY,BUS_DATE
             FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
             WHERE SEC_QTY > 0 AND BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
           ) T1
    INNER JOIN 
              (
                SELECT DISTINCT EXG,SEC_CD_PFX,SEC_CGY_PFX FROM DDW_PROD.T_DDW_CFG_SEC_TRD_CL
  			   WHERE SEC_CL_CD IN ('001','002','003','004','005','006','007','008','012','013','015','016','063')
              ) T2
            ON T1.EXG = T2.EXG 
           AND SUBSTR(T1.SEC_CD,1,3) = T2.SEC_CD_PFX
           AND (SUBSTR(T1.SEC_CGY,1,1) = T2.SEC_CGY_PFX OR SUBSTR(T1.SEC_CGY,1,3) = T2.SEC_CGY_PFX)
    GROUP BY T1.CUST_NO,T1.SEC_CD
  ) T
GROUP BY CUST_NO
;


----客户资产市值临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP11;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP11
AS
  SELECT 
         CUST_NO
  		,ORDI_MKTVAL AS ORDI_ACCNT_MKTVAL           --普通账户市值
  		,CRD_SEC_MKTVAL AS CRD_ACCNT_MKTVAL         --信用账户市值
  		,WRNT_MKTVAL AS WRNT_ACCNT_MKTVAL           --期权账户市值
  		,ORDI_GL AS ORDI_ACCNT_GL                   --普通账户负债
  		,CRD_GL AS CRD_ACCNT_GL                     --信用账户负债
  		,0 AS WRNT_ACCNT_GL                         --期权账户负债
  	    ,ORDI_NET_AST AS ORDI_ACCNT_AST             --普通账户资产
  		,CRD_NET_AST AS CRD_ACCNT_AST               --信用账户资产
  		,WRNT_AST AS WRNT_ACCNT_AST                 --期权账户资产
        ,TOTGL AS TOT_GL                            --总负债
        ,TOT_MKTVAL                                 --总市值
  		,NET_TOT_AST AS TOT_AST                      --净总资产	
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
;


----计算客户佣金率临时表(近一年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP12;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP12
AS
   SELECT 
         CUST_NO                                                         --客户号
        ,SUM(TRD_VOL_ASTK)                                       AS ASTK_MTCH_AMT                                    --A股成交金额
        ,SUM(TRD_VOL_BSTK)                                       AS BSTK_MTCH_AMT_RMB                                 --B股成交金额
        ,SUM(TRD_VOL_GEM)                                        AS GEM_MTCH_AMT                                       --创业板成交金额
        ,SUM(ORDI_TRD_VOL_TA+ORDI_TRD_VOL_TU_RMB-NEW_TA_TRD_VOL) AS OLD_T3BOD_MTCH_AMT                                 --老三板成交金额
        ,SUM(NEW_TA_TRD_VOL)                                     AS NEW_T3BOD_MTCH_AMT                                 --新三板成交金额
        ,SUM(TRD_VOL_HK_STK)                                     AS HK_STK_MTCH_AMT                                    --港股成交金额
        ,SUM(TRD_VOL_EXG_FND)                                    AS EXG_FND_MTCH_AMT                                   --场内基金成交金额
        ,SUM(ORDI_TRD_VOL_BOND+CRD_TRD_VOL_BOND)                 AS BOND_MTCH_AMT                                      --债券成交金额
        ,SUM(NET_S1_ASTK)                                                   AS ASTK_NET_S1                             --A股净佣金
        ,SUM(NET_S1_BSTK)                                                   AS BSTK_NET_S1_RMB                         --B股净佣金
        ,SUM(NET_S1_INCM_GEM)                                               AS GEM_NET_S1                              --创业板净佣金
        ,SUM(ORDI_NET_S1_INCM_TA+ORDI_NET_S1_INCM_HB_RMB-NEW_TA_TRD_NET_S1) AS OLD_T3BOD_NET_S1                        --老三板净佣金
        ,SUM(NEW_TA_TRD_NET_S1)                                             AS NEW_T3BOD_NET_S1                        --新三板净佣金
        ,SUM(NET_S1_HK_STK)                                                 AS HK_STK_NET_S1                           --港股净佣金
        ,SUM(NET_S1_EXG_FND)                                                AS EXG_FND_NET_S1                          --场内基金净佣金
        ,SUM(ORDI_NET_S1_INCM_BOND+CRD_NET_S1_INCM_BOND)                    AS BOND_NET_S1                              --债券净佣金
  FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP14;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP14 AS
SELECT CUST_NO
        ,SUM(CASE WHEN SEC_CGY LIKE 'H4%'
		          AND  ODR_CGY = 5
				  THEN MTCH_AMT
				  ELSE 0
				  END 
		    ) AS QOT_REPO_MRGNS_AMT                   --报价回购融券金额
        ,SUM(CASE WHEN SEC_CGY NOT LIKE 'H4%'
		          AND  ODR_CGY = 5
				  THEN MTCH_AMT
				  ELSE 0
				  END 
		    ) AS ORDI_REPO_MRGNS_AMT                 --普通回购融券金额
        ,SUM(CASE WHEN SEC_CGY NOT LIKE 'H4%'
		          AND  ODR_CGY = 4
				  THEN MTCH_AMT
				  ELSE 0
				  END 
		    ) AS ORDI_REPO_MRGNC_AMT                 --普通回购融资金额
	    ,SUM(CASE WHEN SEC_CGY LIKE 'H4%'
		          AND  ODR_CGY = 5
				  THEN MTCH_AMT
				  ELSE 0
				  END 
		    ) AS QOT_REPO_MRGNS_NET_S1             --报价回购融券净佣金
        ,SUM(CASE WHEN SEC_CGY NOT LIKE 'H4%'
		          AND  ODR_CGY = 5
				  THEN MTCH_AMT
				  ELSE 0
				  END 
		    ) AS ORDI_REPO_MRGNS_NET_S1           --普通回购融券净佣金
        ,SUM(CASE WHEN SEC_CGY NOT LIKE 'H4%'
		          AND  ODR_CGY = 4
				  THEN MTCH_AMT
				  ELSE 0
				  END 
		    ) AS ORDI_REPO_MRGNC_NET_S1           --普通回购融额净佣金
FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
AND   SEC_CGY LIKE 'H%'
GROUP BY CUST_NO
;

----客户配售权益临时表(近一年)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP13;
CREATE TABLE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP13
AS
  SELECT
         CUST_NO
		,SUM(CO_MKTVAL) AS INR_MKTVAL
		,SUM(PLCG_ETMT_MKTVAL) AS EXTN_MKTVAL
  FROM RPT_DB.T_PRT_PLCG_ETMT_CMP_KUDU
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
; 
--------插入数据开始------
INSERT OVERWRITE DDW_PROD.T_DDW_LM_CUST_BEHV_DATA
(
					    CUST_NO               		    			--客户号
					   ,AMT_BAL                   					--资金余额
					   ,HLD_QTY_WTHAYR                   			--近一年持股只数
                       ,HLD_DYS_WTHAYR                   			--近一年持股天数
                       ,HLD_QTY                          			--持股只数
                       ,AVG_AST_WTHAYR                          	--近一年日均资产(不包含质押回购)
                       ,MTCH_AMT_RMB_WTHAYR                     	--近一年成交金额
                       ,NET_INCM_AVG_WTHAYR              			--近一年日均收益率
                       ,NEWST_PRC_CURR                   			--当前大盘点数
                       ,NEWST_PRC_LASTRY                 			--上年同期大盘点数
                       ,EXCD_YLD_RATE      				 			--超额收益率
                       ,QOT_REPO_TRD_QTY             				--近两年报价回购交易数量
                       ,STK_FUND_TRD_QTY      						--近两年股基交易数量
                       ,PROD_TRD_QTY               					--近两年产品交易数量
                       ,PROD_MKTVAL       							--近两年产品持仓峰值
                       ,SEC_MKTVAL               					--近两年证券持仓峰值
                       ,A_MTCH_QTY_WTHAYR                       	--近一年A股交易数量
                       ,A_MTCH_AMT_WTHAYR      						--近一年A股交易金额
                       ,B_MTCH_QTY_WTHAYR                       	--近一年B股交易数量
                       ,B_MTCH_AMT_WTHAYR      						--近一年B股交易金额
                       ,NEW_T3BOD_MTCH_QTY_WTHAYR                   --近一年新三板交易数量
                       ,NEW_T3BOD_MTCH_AMT_WTHAYR    				--近一年新三板交易金额
                       ,GEM_MTCH_QTY_WTHAYR                         --近一年创业板交易数量
                       ,GEM_MTCH_AMT_WTHAYR          				--近一年创业板交易金额
                       ,SME_MTCH_QTY_WTHAYR                         --近一年中小板交易数量
                       ,SME_MTCH_AMT_WTHAYR          				--近一年中小板交易金额
                       ,HSK_MTCH_QTY_WTHAYR                     	--近一年港股通交易数量
                       ,HSK_MTCH_AMT_WTHAYR    						--近一年港股通交易金额
                       ,ST_MTCH_QTY_WTHAYR                        	--近一年ST板块交易数量
                       ,ST_MTCH_AMT_WTHAYR       					--近一年ST板块交易金额
                       ,HLD_QTY_SHRTM_WTHAYR                       	--近一年短线持股只数
                       ,HLD_QTY_MIDTM_WTHAYR        				--近一年中长线持股只数
                       ,HLD_QTY_LONTM_WTHAYR                       	--近一年长线持股只
                       ,ORDI_ACCNT_MKTVAL            				--普通账户市值
                       ,CRD_ACCNT_MKTVAL             				--信用账户市值
                       ,WRNT_ACCNT_MKTVAL            				--期权账户市值
                       ,ORDI_ACCNT_GL                				--普通账户负债
                       ,CRD_ACCNT_GL                 				--信用账户负债
                       ,WRNT_ACCNT_GL                				--期权账户负债
                       ,ORDI_ACCNT_AST               				--普通账户资产
                       ,CRD_ACCNT_AST                				--信用账户资产
                       ,WRNT_ACCNT_AST               				--期权账户资产
                       ,TOT_GL                       				--总负债
                       ,TOT_MKTVAL                  				--总市值
                       ,TOT_AST                      				--净总资产
                       ,ASTK_MTCH_AMT                       		--A股成交金额
                       ,BSTK_MTCH_AMT_RMB                   		--B股成交金额
                       ,GEM_MTCH_AMT                        		--创业板成交金额
                       ,OLD_T3BOD_MTCH_AMT                  		--老三板成交金额
                       ,NEW_T3BOD_MTCH_AMT                  		--新三板成交金额
                       ,HK_STK_MTCH_AMT                     		--港股成交金额
                       ,EXG_FND_MTCH_AMT                    		--场内基金成交金额
                       ,BOND_MTCH_AMT                       		--债券成交金额
                       ,QOT_REPO_MRGNS_AMT                  		--报价回购融券金额
                       ,ORDI_REPO_MRGNS_AMT                 		--普通回购融券金额
                       ,ORDI_REPO_MRGNC_AMT                 		--普通回购融资金额
                       ,ASTK_NET_S1                         		--A股净佣金
                       ,BSTK_NET_S1_RMB                     		--B股净佣金
                       ,GEM_NET_S1                          		--创业板净佣金
                       ,OLD_T3BOD_NET_S1                    		--老三板净佣金
                       ,NEW_T3BOD_NET_S1                    		--新三板净佣金
                       ,HK_STK_NET_S1                       		--港股净佣金
                       ,EXG_FND_NET_S1                      		--场内基金净佣金
                       ,BOND_NET_S1                         		--债券净佣金
                       ,QOT_REPO_MRGNS_NET_S1             			--报价回购融券净佣金
                       ,ORDI_REPO_MRGNS_NET_S1           			--普通回购融券净佣金
                       ,ORDI_REPO_MRGNC_NET_S1           			--普通回购融额净佣金
                       ,INR_MKTVAL
                       ,EXTN_MKTVAL
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                        T.CUST_NO									                    --客户号
                       ,T.AMT_BAL				                    					--资金余额
                       ,NVL(T1.HLD_QTY_WTHAYR,0) AS HLD_QTY_WTHAYR                   	--近一年持股只数
                       ,NVL(T1.HLD_DYS_WTHAYR,0) AS HLD_DYS_WTHAYR                   	--近一年持股天数
                       ,NVL(T1.HLD_QTY,0) AS HLD_QTY                          			--持股只数
                       ,NVL(T2.AVG_AST_WTHAYR,0) AS AVG_AST_WTHAYR                    	--近一年日均资产(不包含质押回购)
                       ,NVL(T2.MTCH_AMT_RMB_WTHAYR,0) AS MTCH_AMT_RMB_WTHAYR            --近一年成交金额
                       ,NVL(T3.NET_INCM_AVG_WTHAYR,0) AS NET_INCM_AVG_WTHAYR            --近一年日均收益率
                       ,NVL(T3.NEWST_PRC_CURR,0) AS NEWST_PRC_CURR                   	--当前大盘点数
                       ,NVL(T3.NEWST_PRC_LASTRY,0) AS NEWST_PRC_LASTRY                 	--上年同期大盘点数
                       ,NVL(T3.EXCD_YLD_RATE,0) AS EXCD_YLD_RATE      				 	--超额收益率
                       ,NVL(T4.QOT_REPO_TRD_QTY,0) AS QOT_REPO_TRD_QTY             		--近两年报价回购交易数量
                       ,NVL(T4.STK_FUND_TRD_QTY,0) AS STK_FUND_TRD_QTY      			--近两年股基交易数量
                       ,NVL(CAST(T5.PROD_TRD_QTY AS DECIMAL(38,0)),0) AS PROD_TRD_QTY   --近两年产品交易数量
                       ,NVL(T6.PROD_MKTVAL,0) AS PROD_MKTVAL       						--近两年产品持仓峰值
                       ,NVL(T7.SEC_MKTVAL,0) AS SEC_MKTVAL               				--近两年证券持仓峰值
                       ,NVL(T8.A_MTCH_QTY_WTHAYR,0) AS A_MTCH_QTY_WTHAYR                --近一年A股交易数量
                       ,NVL(T8.A_MTCH_AMT_WTHAYR,0) AS A_MTCH_AMT_WTHAYR      			--近一年A股交易金额
                       ,NVL(T8.B_MTCH_QTY_WTHAYR,0) AS B_MTCH_QTY_WTHAYR                --近一年B股交易数量
                       ,NVL(T8.B_MTCH_AMT_WTHAYR,0) AS B_MTCH_AMT_WTHAYR      			--近一年B股交易金额
                       ,NVL(T8.NEW_T3BOD_MTCH_QTY_WTHAYR,0) AS NEW_T3BOD_MTCH_QTY_WTHAY --近一年新三板交易数量
                       ,NVL(T8.NEW_T3BOD_MTCH_AMT_WTHAYR,0) AS NEW_T3BOD_MTCH_AMT_WTHAY --近一年新三板交易金额
                       ,NVL(T8.GEM_MTCH_QTY_WTHAYR,0) AS GEM_MTCH_QTY_WTHAYR            --近一年创业板交易数量
                       ,NVL(T8.GEM_MTCH_AMT_WTHAYR,0) AS GEM_MTCH_AMT_WTHAYR          	--近一年创业板交易金额
                       ,NVL(T8.SME_MTCH_QTY_WTHAYR,0) AS SME_MTCH_QTY_WTHAYR            --近一年中小板交易数量
                       ,NVL(T8.SME_MTCH_AMT_WTHAYR,0) AS SME_MTCH_AMT_WTHAYR          	--近一年中小板交易金额
                       ,NVL(T8.HSK_MTCH_QTY_WTHAYR,0) AS HSK_MTCH_QTY_WTHAYR            --近一年港股通交易数量
                       ,NVL(T8.HSK_MTCH_AMT_WTHAYR,0) AS HSK_MTCH_AMT_WTHAYR    		--近一年港股通交易金额
                       ,NVL(T9.ST_MTCH_QTY_WTHAYR,0) AS ST_MTCH_QTY_WTHAYR              --近一年ST板块交易数量
                       ,NVL(T9.ST_MTCH_AMT_WTHAYR,0) AS ST_MTCH_AMT_WTHAYR       		--近一年ST板块交易金额
                       ,NVL(T10.HLD_QTY_SHRTM_WTHAYR,0) AS HLD_QTY_SHRTM_WTHAYR         --近一年短线持股只数
                       ,NVL(T10.HLD_QTY_MIDTM_WTHAYR,0) AS HLD_QTY_MIDTM_WTHAYR        	--近一年中长线持股只数
                       ,NVL(T10.HLD_QTY_LONTM_WTHAYR,0) AS HLD_QTY_LONTM_WTHAYR         --近一年长线持股只
                       ,NVL(T11.ORDI_ACCNT_MKTVAL,0) AS ORDI_ACCNT_MKTVAL            	--普通账户市值
                       ,NVL(T11.CRD_ACCNT_MKTVAL,0) AS CRD_ACCNT_MKTVAL             	--信用账户市值
                       ,NVL(T11.WRNT_ACCNT_MKTVAL,0) AS WRNT_ACCNT_MKTVAL            	--期权账户市值
                       ,NVL(T11.ORDI_ACCNT_GL,0) AS ORDI_ACCNT_GL                		--普通账户负债
                       ,NVL(T11.CRD_ACCNT_GL,0) AS CRD_ACCNT_GL                 		--信用账户负债
                       ,NVL(T11.WRNT_ACCNT_GL,0) AS WRNT_ACCNT_GL                		--期权账户负债
                       ,NVL(T11.ORDI_ACCNT_AST,0) AS ORDI_ACCNT_AST               		--普通账户资产
                       ,NVL(T11.CRD_ACCNT_AST,0) AS CRD_ACCNT_AST                		--信用账户资产
                       ,NVL(T11.WRNT_ACCNT_AST,0) AS WRNT_ACCNT_AST               		--期权账户资产
                       ,NVL(T11.TOT_GL,0) AS TOT_GL                       				--总负债
                       ,NVL(T11.TOT_MKTVAL ,0) AS TOT_MKTVAL                 			--总市值
                       ,NVL(T11.TOT_AST,0) AS TOT_AST                      				--净总资产
                       ,NVL(T12.ASTK_MTCH_AMT,0) AS ASTK_MTCH_AMT                       --A股成交金额
                       ,NVL(T12.BSTK_MTCH_AMT_RMB,0) AS BSTK_MTCH_AMT_RMB               --B股成交金额
                       ,NVL(T12.GEM_MTCH_AMT,0) AS GEM_MTCH_AMT                        	--创业板成交金额
                       ,NVL(T12.OLD_T3BOD_MTCH_AMT,0) AS OLD_T3BOD_MTCH_AMT             --老三板成交金额
                       ,NVL(T12.NEW_T3BOD_MTCH_AMT,0) AS NEW_T3BOD_MTCH_AMT             --新三板成交金额
                       ,NVL(T12.HK_STK_MTCH_AMT,0) AS HK_STK_MTCH_AMT                   --港股成交金额
                       ,NVL(T12.EXG_FND_MTCH_AMT,0) AS EXG_FND_MTCH_AMT                 --场内基金成交金额
                       ,NVL(T12.BOND_MTCH_AMT,0) AS BOND_MTCH_AMT                       --债券成交金额
                       ,NVL(T14.QOT_REPO_MRGNS_AMT,0) AS QOT_REPO_MRGNS_AMT             --报价回购融券金额
                       ,NVL(T14.ORDI_REPO_MRGNS_AMT,0) AS ORDI_REPO_MRGNS_AMT           --普通回购融券金额
                       ,NVL(T14.ORDI_REPO_MRGNC_AMT,0) AS ORDI_REPO_MRGNC_AMT           --普通回购融资金额
                       ,NVL(T12.ASTK_NET_S1,0) AS ASTK_NET_S1                         	--A股净佣金
                       ,NVL(T12.BSTK_NET_S1_RMB,0) AS BSTK_NET_S1_RMB                   --B股净佣金
                       ,NVL(T12.GEM_NET_S1,0) AS GEM_NET_S1                          	--创业板净佣金
                       ,NVL(T12.OLD_T3BOD_NET_S1,0) AS OLD_T3BOD_NET_S1                 --老三板净佣金
                       ,NVL(T12.NEW_T3BOD_NET_S1,0) AS NEW_T3BOD_NET_S1                 --新三板净佣金
                       ,NVL(T12.HK_STK_NET_S1,0) AS HK_STK_NET_S1                       --港股净佣金
                       ,NVL(T8.KCB_MTCH_QTY_WTHAYR,0) AS EXG_FND_NET_S1                 --场内基金净佣金 -> 近一年科创板交易数量
                       ,NVL(T8.KCB_MTCH_AMT_WTHAYR,0) AS BOND_NET_S1                    --债券净佣金     -> 近一年科创板交易金额
                       ,NVL(T14.QOT_REPO_MRGNS_NET_S1,0) AS QOT_REPO_MRGNS_NET_S1       --报价回购融券净佣金
                       ,NVL(T14.ORDI_REPO_MRGNS_NET_S1,0) AS ORDI_REPO_MRGNS_NET_S1     --普通回购融券净佣金
                       ,NVL(T14.ORDI_REPO_MRGNC_NET_S1,0) AS ORDI_REPO_MRGNC_NET_S1     --普通回购融额净佣金
                       ,NVL(T13.INR_MKTVAL,0)  AS INR_MKTVAL
                       ,NVL(T13.EXTN_MKTVAL,0) AS EXTN_MKTVAL
FROM DDW_PROD.T_DDW_CUST_STATMT_DAY T
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP1 T1
ON T.CUST_NO = T1.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP2 T2
ON T.CUST_NO = T2.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP3 T3
ON T.CUST_NO = T3.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4 T4
ON T.CUST_NO = T4.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP5 T5
ON T.CUST_NO = T5.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6 T6
ON T.CUST_NO = T6.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP7 T7
ON T.CUST_NO = T7.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP8 T8
ON T.CUST_NO = T8.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP9 T9
ON T.CUST_NO = T9.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP10 T10
ON T.CUST_NO = T10.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP11 T11
ON T.CUST_NO = T11.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP12 T12
ON T.CUST_NO = T12.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP13 T13
ON T.CUST_NO = T13.CUST_NO
LEFT JOIN DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP14 T14
ON T.CUST_NO = T14.CUST_NO
WHERE T.BUS_DATE = %d{yyyyMMdd}
;
-------插入数据结束

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_LM_CUST_BEHV_DATA',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
invalidate metadata DDW_PROD.T_DDW_LM_CUST_BEHV_DATA;

-----删除临时表--
DROP TABLE IF EXISTS DDW_PROD.T_DDW_SEC_HLD_STK_TMP;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_SEC_TRD_STK_TMP;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP1;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP2;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP3;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP5;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP7;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP8;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP9;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP10;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP11;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP12;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP13;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_1;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_2;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP4_3;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_1;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_2;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP6_3;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_CUST_BEHV_DATA_TMP14;

 ----/* ***************************************** SQL Begin *****************************************  */
  ----/* 脚本功能:客户属性标签                                                                         */
  ----/* 创建人:黄勇华                                                                               */
  ----/* 创建时间:2019-04-16                                                                       */ 

--创建临时表  
--创建临时表  
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP;
 CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP as
 SELECT  CUST_NO,MIN(BUS_DATE) as BUS_DATE
 FROM 
 (SELECT CUST_NO,NET_TOT_AST , BUS_DATE 
 FROM   DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
 WHERE  NET_TOT_AST > =  1000
 AND    BUS_DATE BETWEEN 20170101 AND %d{yyyyMMdd}
 UNION ALL
 SELECT KHH as CUST_NO, ZZC as NET_TOT_AST,RQ as BUS_DATE FROM NEWCRM.DSC_STAT_T_STAT_KHZC_R 
 WHERE RQ BETWEEN 20160101 AND 20161231
 AND  ZZC > = 1000
 ) t 
 GROUP BY CUST_NO ; 
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP1;
 CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP1 as
 SELECT  CUST_NO,MIN(BUS_DATE) as BUS_DATE
 FROM 
 (SELECT CUST_NO,NET_TOT_AST , BUS_DATE 
 FROM   DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
 WHERE  NET_TOT_AST >  0
 AND    BUS_DATE BETWEEN 20170101 AND %d{yyyyMMdd}
 UNION ALL
 SELECT KHH as CUST_NO, ZZC as NET_TOT_AST,RQ as BUS_DATE FROM NEWCRM.DSC_STAT_T_STAT_KHZC_R 
 WHERE RQ BETWEEN 20160101 AND 20161231
 AND  ZZC > 0
 ) t 
 GROUP BY CUST_NO ;  
 
 
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP2;
 CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP2 as
 SELECT          CUST_NO
               ,MIN(CASE WHEN EXG IN ('HK','SK')
			             AND   OPN_PRVL = 1 
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )     as H_K_OPNAC_DT                   --港股通开户日期
			   ,MAX(CASE WHEN EXG IN ('HK','SK')
			             AND   OPN_PRVL = 1 
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )     as H_K_CNCLACT_DT                  --港股通销户日期
				,MAX(CASE WHEN EXG IN ('HK','SK')
			              AND   OPN_PRVL = 1 
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )    as IF_H_K                        --是否销户港股通
				,MIN(CASE WHEN EXG IN ('HK')
			             AND   OPN_PRVL = 1 
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )   as HK_OPNAC_DT                   --沪港通开户日期
				,MAX(CASE WHEN EXG IN ('HK')
			             AND   OPN_PRVL = 1 
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as HK_CNCLACT_DT                 --沪港通销户日期
				,MAX(CASE WHEN EXG IN ('HK')
			              AND   OPN_PRVL = 1 
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   ) as IF_HK                         --是否销户沪港通 
				,MIN(CASE WHEN EXG IN ('SK')
			             AND   OPN_PRVL = 1 
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )     as SK_OPNAC_DT                   --深港通开户日期
				,MAX(CASE WHEN EXG IN ('SK')
			             AND   OPN_PRVL = 1 
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )    as SK_CNCLACT_DT                 --深港通销户日期
				,MAX(CASE WHEN EXG IN ('SK')
			              AND   OPN_PRVL = 1 
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )  as IF_SK                         --是否销户深港通 							  
                             
               ,MIN(CASE WHEN EXG IN ('TA','TU')
			             AND   OPN_PRVL = 1 
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as T3BOD_OPNAC_DT                --三板开通日期
				,MAX(CASE WHEN EXG IN ('TA','TU')
			             AND   OPN_PRVL = 1 
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as T3BOD_CNCLACT_DT              --三板销户日期
				,MAX(CASE WHEN EXG IN ('TA','TU')
			              AND   OPN_PRVL = 1 
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_T3BOD                      --是否销户三板
				
				
				
				,MIN(CASE WHEN  OPN_PRVL = 2 
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as REPO_MRGNC_OPNAC_DT           --回购融资开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 2
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as REPO_MRGNC_CNCLACT_DT         --回购融资销户日期
				,MAX(CASE WHEN OPN_PRVL = 2
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_REPO_MRGNC                 --是否销户回购融资   
				   
				

				,MIN(CASE WHEN  OPN_PRVL = 3
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as REPO_MRGNS_OPNAC_DT           --回购融券开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 3
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as REPO_MRGNS_CNCLACT_DT         --回购融券销户日期
				,MAX(CASE WHEN OPN_PRVL = 3
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_REPO_MRGNS                 --是否销户回购融券
				   
				
				

               ,MIN(CASE WHEN  OPN_PRVL = 7
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as GEM_OPNAC_DT                  --创业板开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 7
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as GEM_CNCLACT_DT                --创业板销户日期
				,MAX(CASE WHEN OPN_PRVL = 7
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_GEM                        --是否销户创业板
			
			
			,MIN(CASE WHEN  OPN_PRVL = 10
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as DLSTG_OPNAC_DT                --退市整理开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 10
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as DLSTG_CNCLACT_DT              --退市整理销户日期
				,MAX(CASE WHEN OPN_PRVL = 10
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_DLSTG                      --是否销户退市整理
				   
				   ,MIN(CASE WHEN  OPN_PRVL = 12
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as BOND_QLFD_IVSM_OPNAC_DT       --债券合格投资开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 12
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as BOND_QLFD_IVSM_CNCLACT_DT     --债券合格投资销户日期
				,MAX(CASE WHEN OPN_PRVL = 12
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_BOND_QLFD_IVSM             --是否销户债券合格投资
                              
                
				,MIN(CASE WHEN  OPN_PRVL = 101
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as QOT_REPO_OPNAC_DT             --报价回购开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 101
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as QOT_REPO_CNCLACT_DT           --报价回购销户日期
				,MAX(CASE WHEN OPN_PRVL = 101
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_QOT_REPO                   --是否销户报价回购            
               	,MIN(CASE WHEN  OPN_PRVL = 102
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as PROMS_RPHS_OPNAC_DT           --约定购回开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 102
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as PROMS_RPHS_CNCLACT_DT         --约定购回销户日期
				,MAX(CASE WHEN OPN_PRVL = 102
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_PROMS_RPHS                 --是否销户约定购回 
                ,MIN(CASE WHEN  OPN_PRVL = 106
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as PLG_REPO_OPNAC_DT             --质押回购开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 106
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as PLG_REPO_CNCLACT_DT           --质押回购销户日期
				,MAX(CASE WHEN OPN_PRVL = 106
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_PLG_REPO                   --是否销户质押回购
				   
		       ,MIN(CASE WHEN  OPN_PRVL = 110
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as STK_PLG_OPNAC_DT              --股票质押开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 110
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as STK_PLG_CNCLACT_DT            --股票质押销户日期
				,MAX(CASE WHEN OPN_PRVL = 110
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_STK_PLG                    --是否销户股票质押
               ,MIN(CASE WHEN  OPN_PRVL = 117
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as STR_FND_OPNAC_DT              --分级基金开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 117
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as STR_FND_CNCLACT_DT            --分级基金销户日期
				,MAX(CASE WHEN OPN_PRVL = 117
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_STR_FND                    --是否销户分级基金         
               ,MIN(CASE WHEN  OPN_PRVL = 20
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as STIB_OPNAC_DT                 --科创板开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 20
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as STIB_CNCLACT_DT               --科创销户日期
				,MAX(CASE WHEN OPN_PRVL = 20
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_STIB                       --是否销户科创板   
               ,MIN(CASE WHEN  OPN_PRVL IN (6,21,22)
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as NEW_T3BOD_OPNAC_DT            --新三板开通日期
				
				,MAX(CASE WHEN OPN_PRVL IN (6,21,22)
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as NEW_T3BOD_CNCLACT_DT          --新三板销户日期
				,MAX(CASE WHEN OPN_PRVL IN (6,21,22)
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_NEW_T3BOD                  --是否销户新三板
				
				,MIN(CASE WHEN  OPN_PRVL IN (6)
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as NEW_T3BOD_OPNAC_DT_1            --新三板开通日期(一类)
				
				,MAX(CASE WHEN OPN_PRVL IN (6)
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as NEW_T3BOD_CNCLACT_DT_1          --新三板销户日期(一类)
				,MAX(CASE WHEN OPN_PRVL IN (6)
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_NEW_T3BOD_1                  --是否销户新三板(一类)
				
				,MIN(CASE WHEN  OPN_PRVL IN (21)
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as NEW_T3BOD_OPNAC_DT_2            --新三板开通日期(二类)
				
				,MAX(CASE WHEN OPN_PRVL IN (21)
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as NEW_T3BOD_CNCLACT_DT_2          --新三板销户日期(二类)
				,MAX(CASE WHEN OPN_PRVL IN (21)
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_NEW_T3BOD_2                  --是否销户新三板(二类)
				,MIN(CASE WHEN  OPN_PRVL IN (22)
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as NEW_T3BOD_OPNAC_DT_3            --新三板开通日期(三类)
				
				,MAX(CASE WHEN OPN_PRVL IN (22)
					     THEN  CHG_DT
					     ELSE 0
					     END
				   )  as NEW_T3BOD_CNCLACT_DT_3          --新三板销户日期(三类)
				,MAX(CASE WHEN OPN_PRVL IN (22)
					      THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_NEW_T3BOD_3                  --是否销户新三板(三类)

			  ,MIN(CASE WHEN  OPN_PRVL = 23
			           
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as RGST_GEM_OPNAC_DT                  --注册创业板开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 23
					     
						 THEN  CHG_DT
					     ELSE 0
					     END
				   )  as RGST_GEM_CNCLACT_DT                --注册创业板销户日期
				,MAX(CASE WHEN OPN_PRVL = 23
					      
						  THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_RGST_GEM                        --是否销户注册创业板 
                            
                          
 FROM                              
(
SELECT CUST_NO
      ,EXG
      ,OPN_PRVL
	  ,MIN(OPN_DT) as OPN_DT
	  ,MAX(CHG_DT) as CHG_DT
	  ,MIN(CASE WHEN BUS_DATE > = OPN_DT 
	            AND  BUS_DATE < CHG_DT
	         THEN 0
			 ELSE 1
			 END
		  )  as IF_CNCLACT
FROM  DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
WHERE BUS_DATE = %d{yyyyMMdd}
GROUP BY CUST_NO
         ,EXG
         ,OPN_PRVL
)   t
GROUP BY t.CUST_NO ;

  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP3;
 CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP3 as
 SELECT MIN(CJRQ) as CRD_FSTTM_TRD_DT ,KHH as CUST_NO 
 FROM RZRQCX.DATACENTER_TJGMXLS
 WHERE WTLB IN (61,64)
 AND   CJRQ < = %d{yyyyMMdd}
 GROUP BY CUST_NO ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP4;
 CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP4 as
 SELECT MIN(CASE WHEN WTLB= 53
                 AND WTFS = 8
			     THEN CJRQ
			     ELSE 99999999
			     END
			) as PLG_REPO_FSTTM_TRD_DT --质押回购首次交易日期(股票质押)
	    ,MIN(CASE WHEN WTLB= 53
                 AND WTFS < > 8
			     THEN CJRQ
			     ELSE 99999999
			     END
			) as STK_PLG_FSTTM_TRD_DT	--股票质押首次交易日期(小微贷)
			
		,KHH as CUST_NO 
 FROM JZJYCX.SECURITIES_TZYHG
 WHERE WTLB = 53
 AND   DT = '%d{yyyyMMdd}'
 GROUP BY CUST_NO ;
 
 
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP5;
 CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP5 as
 SELECT  CUST_NO,10000000 as LMT_NEW_T3BOD_OPNAC_DT,99999999 as LMT_NEW_T3BOD_CNCLACT_DT,0 as IF_LMT_NEW_T3BOD
 FROM DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO 
 WHERE    BUS_DATE = %d{yyyyMMdd} 
 AND 	    SHRHLD_STAT <> '3' 
 AND      EXG = 'TA' 
 AND     CUST_NO IN (SELECT YWXTKHH FROM YGTCX.EIMAGE_TDA_KHJBDA WHERE DT = '%d{yyyyMMdd}' AND YXLX IN (385,386))
 AND     CUST_NO NOT IN (SELECT CUST_NO 
                         FROM   DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL 
						 WHERE  BUS_DATE = %d{yyyyMMdd} 
	                      AND OPN_PRVL IN (6,21,22)
	                      AND %d{yyyyMMdd} BETWEEN OPN_DT AND CHG_DT
                         )
 AND     CUST_NO NOT IN (SELECT CUST_NO 
                         FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL 
						 WHERE BUS_DATE = %d{yyyyMMdd} 
	                     AND OPN_PRVL = 1
						 AND  EXG IN ('TA','TU')
	                     AND %d{yyyyMMdd} BETWEEN OPN_DT AND CHG_DT
                         )
 GROUP BY CUST_NO,LMT_NEW_T3BOD_OPNAC_DT,LMT_NEW_T3BOD_CNCLACT_DT,IF_LMT_NEW_T3BOD
 UNION ALL
 SELECT  CUST_NO,10000000 as LMT_NEW_T3BOD_OPNAC_DT,99999999 as LMT_NEW_T3BOD_CNCLACT_DT,0 as IF_LMT_NEW_T3BOD  
 FROM DDW_PROD.T_DDW_F00_CUST_SHRHLD_INFO 
 WHERE    BUS_DATE = %d{yyyyMMdd} 
 AND 	    SHRHLD_STAT <> '3' 
 AND      EXG = 'TA' 
 AND     CUST_NO NOT IN (SELECT YWXTKHH FROM YGTCX.EIMAGE_TDA_KHJBDA WHERE DT = '%d{yyyyMMdd}' AND YXLX IN (385,386))
 AND     CUST_NO NOT IN (SELECT CUST_NO 
                         FROM   DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL 
						 WHERE  BUS_DATE = %d{yyyyMMdd} 
	                      AND OPN_PRVL IN (6,21,22) 
	                      AND %d{yyyyMMdd} BETWEEN OPN_DT AND CHG_DT
                         )
 
 AND  SHRHLD_NO IN (SELECT GDH  FROM JZJYCX.SECURITIES_TBJZR_GDMC WHERE DT = '%d{yyyyMMdd}' AND SUBSTR(ZQDM,1,2) IN ('43','83','87'))
 GROUP BY CUST_NO,LMT_NEW_T3BOD_OPNAC_DT,LMT_NEW_T3BOD_CNCLACT_DT,IF_LMT_NEW_T3BOD ;
							   
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP6;
CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP6 as
SELECT t.KHH as CUST_NO
       ,MAX(CASE WHEN JYS ='SH'
	             THEN KHRQ
			     ELSE 0
			     END
           )    as 	SH_WRNT_OPNAC_DT                 --沪市期权开户日期
	  ,MIN(CASE WHEN JYS ='SH'
	            THEN XHRQ
			    ELSE 99999999
			    END
           )    as 	SH_WRNT_CNCLACT_DT               --沪市期权销户日期
      ,MIN(CASE WHEN JYS = 'SH'
	            AND  XHRQ = 99999999
			    THEN 0
			    ELSE 3
			    END
		  )     as IF_SH_WRNT_CNCLACT               --是否销户沪市期权账户
	  ,MAX(CASE WHEN JYS ='SZ'
	             THEN KHRQ
			     ELSE 0
			     END
           )    as 	SZ_WRNT_OPNAC_DT                 --深市期权开户日期
	  ,MIN(CASE WHEN JYS ='SZ'
	            THEN XHRQ
			    ELSE 99999999
			    END
           )    as 	SZ_WRNT_CNCLACT_DT               --深市期权销户日期
      ,MIN(CASE WHEN JYS = 'SZ'
	            AND  XHRQ = 99999999
			    THEN 0
			    ELSE 3
			    END
		  )    as IF_SZ_WRNT_CNCLACT               --是否销户深市期权账户
	
	

FROM (SELECT  KHH
             ,JYS
	         ,MIN(KHRQ) as KHRQ
	         ,MAX(CASE WHEN GDZT = '3'
	                   THEN XHRQ
			           ELSE 99999999
			           END
		         ) as XHRQ
      FROM  EDW_PROD.T_EDW_T02_THYZH
      WHERE BUS_DATE = %d{yyyyMMdd}
      GROUP BY JYS,KHH
     )   t
GROUP BY CUST_NO ;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP7;
CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP7 as
SELECT      t.CUST_NO
            ,MIN(CASE WHEN  OPN_PRVL = 7
			           AND  ACCNT_CGY = '普通账户'
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as ORDI_GEM_OPNAC_DT                  --普通账户创业板开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 7
					     AND  ACCNT_CGY = '普通账户'
						 THEN  CHG_DT
					     ELSE 0
					     END
				   )  as ORDI_GEM_CNCLACT_DT                --普通账户创业板销户日期
				,MAX(CASE WHEN OPN_PRVL = 7
					      AND  ACCNT_CGY = '普通账户'
						  THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_ORDI_GEM                        --是否销户普通账户创业板
			,MIN(CASE WHEN  OPN_PRVL = 7
			           AND  ACCNT_CGY = '信用账户'
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as CRD_GEM_OPNAC_DT                  --信用账户创业板开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 7
					     AND  ACCNT_CGY = '信用账户'
						 THEN  CHG_DT
					     ELSE 0
					     END
				   )  as CRD_GEM_CNCLACT_DT                --信用账户创业板销户日期
				,MAX(CASE WHEN OPN_PRVL = 7
					      AND  ACCNT_CGY = '信用账户'
						  THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_CRD_GEM                        --是否销户信用账户创业板
				 
				 ,MIN(CASE WHEN  OPN_PRVL = 20
					     AND  ACCNT_CGY = '普通账户'
						 THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as ORDI_STIB_OPNAC_DT                 --普通账户科创板开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 20
					     AND  ACCNT_CGY = '普通账户'
						 THEN  CHG_DT
					     ELSE 0
					     END
				   )  as ORDI_STIB_CNCLACT_DT               --普通账户科创销户日期
				,MAX(CASE WHEN OPN_PRVL = 20
					      AND  ACCNT_CGY = '普通账户'
						  THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_ORDI_STIB                       --是否销户普通账户科创板 
				   
				 ,MIN(CASE WHEN  OPN_PRVL = 20
					     AND  ACCNT_CGY = '信用账户'
						 THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as CRD_STIB_OPNAC_DT                 --信用账户科创板开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 20
					     AND  ACCNT_CGY = '信用账户'
						 THEN  CHG_DT
					     ELSE 0
					     END
				   )  as CRD_STIB_CNCLACT_DT               --信用账户科创销户日期
				,MAX(CASE WHEN OPN_PRVL = 20
					      AND  ACCNT_CGY = '信用账户'
						  THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_CRD_STIB                       --是否销户信用账户科创板 
				 ,MIN(CASE WHEN  OPN_PRVL = 23
			           AND  ACCNT_CGY = '普通账户'
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as ORDI_RGST_GEM_OPNAC_DT                  --普通账户注册创业板开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 23
					     AND  ACCNT_CGY = '普通账户'
						 THEN  CHG_DT
					     ELSE 0
					     END
				   )  as ORDI_RGST_GEM_CNCLACT_DT                --普通账户注册创业板销户日期
				,MAX(CASE WHEN OPN_PRVL = 23
					      AND  ACCNT_CGY = '普通账户'
						  THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_ORDI_RGST_GEM                        --是否销户普通账户注册创业板
			,MIN(CASE WHEN  OPN_PRVL = 23
			           AND  ACCNT_CGY = '信用账户'
					     THEN  OPN_DT
					     ELSE 99999999
					     END
				   )  as CRD_RGST_GEM_OPNAC_DT                  --信用账户注册创业板开通日期
				
				,MAX(CASE WHEN OPN_PRVL = 23
					     AND  ACCNT_CGY = '信用账户'
						 THEN  CHG_DT
					     ELSE 0
					     END
				   )  as CRD_RGST_GEM_CNCLACT_DT                --信用账户注册创业板销户日期
				,MAX(CASE WHEN OPN_PRVL = 23
					      AND  ACCNT_CGY = '信用账户'
						  THEN  IF_CNCLACT
					      ELSE 0
					      END
				   )   as IF_CRD_RGST_GEM                        --是否销户信用账户注册创业板
 FROM                              
(
SELECT CUST_NO
      ,EXG
      ,OPN_PRVL
	  ,MIN(OPN_DT) as OPN_DT
	  ,MAX(CHG_DT) as CHG_DT
	  ,MIN(CASE WHEN BUS_DATE > = OPN_DT 
	            AND  BUS_DATE < CHG_DT
	         THEN 0
			 ELSE 1
			 END
		  )  as IF_CNCLACT
	  ,CASE WHEN EXG = 'SH' 
	        AND SHRHLD_NO LIKE 'E%'
			THEN '信用账户'
			WHEN EXG = 'SZ' 
	        AND SHRHLD_NO LIKE '06%'
			THEN '信用账户'
			ELSE '普通账户'
			END  as ACCNT_CGY
FROM  DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
WHERE BUS_DATE = %d{yyyyMMdd}
GROUP BY CUST_NO
         ,EXG
         ,OPN_PRVL
		 ,ACCNT_CGY
)   t
GROUP BY t.CUST_NO ;
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL
(
  CUST_NO                       --客户号
, CUST_NAME                     --客户姓名  
, BRH_NO                        --营业部编号       
, BRH_NAME                      --营业部名称       
, CUST_STAR                     --客户星级
, CUST_RLN                      --客户关系
, BROK_RLN_PSN_NO               --经纪关系人员编号
, BROK_RLN_PSN_NAME             --经纪关系人员姓名
, BROK_RLN_PSN_BRH_NO           --经纪关系人员营业部
, SVC_RLN_PSN_NO                --服务关系人员编号
, SVC_RLN_PSN_NAME              --服务关系人员姓名
, SVC_RLN_PSN_BRH_NO            --服务关系人员营业部
, SVC_RLN_PSN_CGY               --服务关系人员类别
, FSTTM_DT_AST_1000             --首次资产达到1000的日期
, FSTTM_DT_AST_0                --首次有资产日期
, VLD_DT                        --有效日期
, CUST_CGY                      --客户类别
, BRTH_YM                       --出生年月
, AGE                           --年龄
, EDU_CD                        --学历代码
, OCP_CD                        --职业代码
, GNDR_CD                       --性别代码
, CUST_RSK_LVL                  --客户风险级别
, CTF_CGY                       --证件类别
, CTF_NO                        --证件编号
, PHONE                         --手机
, CTCT_TEL                      --联系电话
, CITY_CD                         --国家代码
, OPNAC_DT                      --开户日期
, CNCLACT_DT                    --销户日期
, CUST_STAT                     --客户状态
, CRD_OPNAC_DT                  --融资融券开户日期
, CRD_CNCLACT_DT                --融资融券开户日期
, IF_CRD_CNCLACT                --是否销户融资融券
, WRNT_OPNAC_DT                 --期权开户日期
, WRNT_CNCLACT_DT               --期权销户日期
, IF_WRNT_CNCLACT               --是否销户期权账户
, H_K_OPNAC_DT                  --港股通开户日期
, H_K_CNCLACT_DT                --港股通销户日期
, IF_H_K                        --是否销户港股通
, HK_OPNAC_DT                   --沪港通开户日期
, HK_CNCLACT_DT                 --沪港通销户日期
, IF_HK                         --是否销户沪港通 
, SK_OPNAC_DT                   --深港通开户日期
, SK_CNCLACT_DT                 --深港通销户日期
, IF_SK                         --是否销户深港通 							  
, NEW_T3BOD_OPNAC_DT            --新三板开通日期
, NEW_T3BOD_CNCLACT_DT          --新三板销户日期
, IF_NEW_T3BOD                  --是否销户新三板
, T3BOD_OPNAC_DT                --三板开通日期
, T3BOD_CNCLACT_DT              --三板销户日期
, IF_T3BOD                      --是否销户三板
, REPO_MRGNC_OPNAC_DT           --回购融资开通日期
, REPO_MRGNC_CNCLACT_DT         --回购融资销户日期
, IF_REPO_MRGNC                 --是否销户回购融资
, REPO_MRGNS_OPNAC_DT           --回购融券开通日期
, REPO_MRGNS_CNCLACT_DT         --回购融券销户日期
, IF_REPO_MRGNS                 --是否销户回购融券

, GEM_OPNAC_DT                  --创业板开通日期
, GEM_CNCLACT_DT                --创业板销户日期
, IF_GEM                        --是否销户创业板
, DLSTG_OPNAC_DT                --退市整理开通日期
, DLSTG_CNCLACT_DT              --退市整理销户日期
, IF_DLSTG                      --是否销户退市整理
, BOND_QLFD_IVSM_OPNAC_DT       --债券合格投资开通日期
, BOND_QLFD_IVSM_CNCLACT_DT     --债券合格投资销户日期
, IF_BOND_QLFD_IVSM             --是否销户债券合格投资
, QOT_REPO_OPNAC_DT             --报价回购开通日期
, QOT_REPO_CNCLACT_DT           --报价回购销户日期
, IF_QOT_REPO                   --是否销户报价回购
, PROMS_RPHS_OPNAC_DT           --约定购回开通日期
, PROMS_RPHS_CNCLACT_DT         --约定购回销户日期
, IF_PROMS_RPHS                 --是否销户约定购回
, PLG_REPO_OPNAC_DT             --质押回购开通日期(股票质押)
, PLG_REPO_CNCLACT_DT           --质押回购销户日期(股票质押)
, IF_PLG_REPO                   --是否销户质押回购(股票质押)
, STK_PLG_OPNAC_DT              --股票质押开通日期(小微贷)
, STK_PLG_CNCLACT_DT            --股票质押销户日期(小微贷)
, IF_STK_PLG                    --是否销户股票质押(小微贷)
, STR_FND_OPNAC_DT              --分级基金开通日期
, STR_FND_CNCLACT_DT            --分级基金销户日期
, IF_STR_FND                    --是否销户分级基金
, STIB_OPNAC_DT                 --科创板开通日期
, STIB_CNCLACT_DT               --科创板开通日期
, IF_STIB                       --是否销户科创板
, IB_CUST_FLG                   --IB客户标志 
, CRD_FSTTM_TRD_DT              --信用账户首次交易日期
, PLG_REPO_FSTTM_TRD_DT         --质押回购首次交易日期(股票质押)
, STK_PLG_FSTTM_TRD_DT	        --股票质押首次交易日期(小微贷) 
, LMT_NEW_T3BOD_OPNAC_DT        --新三板开通日期(受限制)
, LMT_NEW_T3BOD_CNCLACT_DT      --新三板销户日期(受限制)
, IF_LMT_NEW_T3BOD              --是否销户新三板(受限制)
, CASH_PROD_OPNAC_DT            --现金添利开通日期
, CASH_PROD_CNCLACT_DT          --现金添利销户日期
, IF_CASH_PROD                  --是否销户现金添利
, CASH_PROD_FSTTM_TRD_DT        --现金添利首次交易日期
, SH_WRNT_OPNAC_DT                 --沪市期权开户日期
, SH_WRNT_CNCLACT_DT               --沪市期权销户日期
, IF_SH_WRNT_CNCLACT               --是否销户沪市期权账户
, SZ_WRNT_OPNAC_DT                 --深市期权开户日期
, SZ_WRNT_CNCLACT_DT               --深市期权销户日期
, IF_SZ_WRNT_CNCLACT               --是否销户深市期权账户
, NEW_T3BOD_OPNAC_DT_1            --新三板开通日期(一类)
, NEW_T3BOD_CNCLACT_DT_1          --新三板销户日期(一类)
, IF_NEW_T3BOD_1                  --是否销户新三板(一类)
, NEW_T3BOD_OPNAC_DT_2            --新三板开通日期(二类)
, NEW_T3BOD_CNCLACT_DT_2          --新三板销户日期(二类)
, IF_NEW_T3BOD_2                  --是否销户新三板(二类)
, NEW_T3BOD_OPNAC_DT_3            --新三板开通日期(三类)
, NEW_T3BOD_CNCLACT_DT_3          --新三板销户日期(三类)
, IF_NEW_T3BOD_3                  --是否销户新三板(三类)
, RSK_BEAR_ABLTY                  --风险承受能力
, RGST_GEM_OPNAC_DT                  --注册创业板开通日期
, RGST_GEM_CNCLACT_DT                --注册创业板销户日期
, IF_RGST_GEM                        --是否销户注册创业板 
, ORDI_RGST_GEM_OPNAC_DT             --普通账户注册创业板开通日期
, ORDI_RGST_GEM_CNCLACT_DT           --普通账户注册创业板销户日期
, IF_ORDI_RGST_GEM                   --是否销户普通账户注册创业板
, CRD_RGST_GEM_OPNAC_DT              --信用账户注册创业板开通日期
, CRD_RGST_GEM_CNCLACT_DT            --信用账户注册创业板销户日期
, IF_CRD_RGST_GEM                    --是否销户信用账户注册创业板
, ORDI_GEM_OPNAC_DT                  --普通账户创业板开通日期
, ORDI_GEM_CNCLACT_DT                --普通账户创业板销户日期
, IF_ORDI_GEM                        --是否销户普通账户创业板
, CRD_GEM_OPNAC_DT                   --信用账户创业板开通日期
, CRD_GEM_CNCLACT_DT                 --信用账户创业板销户日期
, IF_CRD_GEM                         --是否销户信用账户创业板
, ORDI_STIB_OPNAC_DT                 --普通账户科创板开通日期
, ORDI_STIB_CNCLACT_DT               --普通账户科创销户日期
, IF_ORDI_STIB                       --是否销户普通账户科创板 
, CRD_STIB_OPNAC_DT                 --信用账户科创板开通日期
, CRD_STIB_CNCLACT_DT               --信用账户科创销户日期
, IF_CRD_STIB                       --是否销户信用账户科创板 
) 
 PARTITION(BUS_DATE  = %d{yyyyMMdd})
 SELECT                         t.CUST_NO          as CUST_NO              --客户号  
                              , t.CUST_NAME        as CUST_NAME            --客户姓名 
                              , t.BRH_NO           as BRH_NO               --营业部编号       
                              , t.BRH_NAME         as BRH_NAME             --营业部名称       
                              , a3.BIZ_DESC        as CUST_STAR            --客户星级
                              , CASE WHEN a4.CUST_NO IS NOT NULL
							         THEN a4.BRK_CGY_NAME
									 WHEN a4.CUST_NO IS  NULL
									 AND  a5.CUST_NO IS NOT NULL
									 AND  a5.SVC_RLN_TP = '4'
									 THEN '强服务关系'
									 WHEN a4.CUST_NO IS  NULL
									 AND  a5.CUST_NO IS  NULL
									 AND  a16.CUST_NO IS NOT NULL
									 AND  a16.SVC_RLN_TP = '5'
									 THEN '弱服务关系'
									 END           as CUST_RLN             --客户关系
                              , a4.PSN_NO          as BROK_RLN_PSN_NO      --经纪关系人员编号
							  , a4.PSN_NAME        as BROK_RLN_PSN_NAME    --经纪关系人员姓名
							  , a4.PSN_BELTO_BRH   as BROK_RLN_PSN_BRH_NO     --经纪关系人员营业部
                              , CASE WHEN a5.CUST_NO IS NOT NULL
							         THEN a5.PSN_NO
                                     WHEN a5.CUST_NO IS NULL
									 AND  a16.CUST_NO IS NOT NULL
									 AND  NVL(a4.PSN_NO,'X') < > NVL(a16.PSN_NO,'X')
									 THEN a16.PSN_NO
									 END  as SVC_RLN_PSN_NO       --服务关系人员编号
							  , CASE WHEN a5.CUST_NO IS NOT NULL
							         THEN a5.PSN_NAME
                                     WHEN a5.CUST_NO IS NULL
									 AND  a16.CUST_NO IS NOT NULL
									 AND  NVL(a4.PSN_NO,'X') < > NVL(a16.PSN_NO,'X')
									 THEN a16.PSN_NAME
									 END         as SVC_RLN_PSN_NAME     --服务关系人员姓名
							  , CASE WHEN a5.CUST_NO IS NOT NULL
							         THEN a5.PSN_BELTO_BRH
                                     WHEN a5.CUST_NO IS NULL
									 AND  a16.CUST_NO IS NOT NULL
									 AND  NVL(a4.PSN_NO,'X') < > NVL(a16.PSN_NO,'X')
									 THEN a16.PSN_BELTO_BRH
									 END  as SVC_RLN_PSN_BRH_NO       --服务关系人员营业部
							  , CASE WHEN a5.CUST_NO IS NOT NULL
							         THEN a5.BRK_CGY_NAME
                                     WHEN a5.CUST_NO IS NULL
									 AND  a16.CUST_NO IS NOT NULL
									 AND  NVL(a4.PSN_NO,'X') < > NVL(a16.PSN_NO,'X')
									 THEN a16.BRK_CGY_NAME
									 END    as SVC_RLN_PSN_CGY      --服务关系人员类别
							  , CASE WHEN t.OPNAC_DT > = 20160101
                                     THEN a6.BUS_DATE
                                     END   as FSTTM_DT_AST_1000	--首次资产达到1000的日期								 
							  
                              , CASE WHEN t.OPNAC_DT > = 20160101
                                     THEN a7.BUS_DATE
                                     END  as FSTTM_DT_AST_0                --首次有资产日期
                              , CASE WHEN t.OPNAC_DT > = 20160101
							         AND  a6.BUS_DATE IS NOT NULL
 							         AND  SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) = SUBSTR(CAST(a6.BUS_DATE as STRING),1,4)
									 THEN a6.BUS_DATE
									 WHEN t.OPNAC_DT > = 20160101
									 AND  a6.BUS_DATE IS NOT NULL
									 AND  a7.BUS_DATE IS NOT NULL
									 AND  SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) <> SUBSTR(CAST(a6.BUS_DATE as STRING),1,4)
									 AND  SUBSTR(CAST(a7.BUS_DATE as STRING),1,4) = SUBSTR(CAST(a6.BUS_DATE as STRING),1,4)
									 THEN a6.BUS_DATE
                                     END           as VLD_DT                        --有效日期
                              , CASE WHEN NVL(a11.PROD_CGY,0) = 1
							         THEN '2'
									 ELSE t.CUST_CGY
									 END     as CUST_CGY--客户类别     
                              , t.BRTH_YM                       --出生年月
                              , t.AGE                           --年龄
                              , t.EDU_CD                        --学历代码
                              , t.OCP_CD                        --职业代码
                              , t.GNDR_CD                       --性别代码							  
							  , t.CUST_RSK_LVL                  --客户风险级别
                              , t.CTF_CGY_CD                       --证件类别
                              , t.CTF_NO                        --证件编号
                              , t.PHONE                         --手机
                              , t.CTCT_TEL                      --联系电话
							  , t.CITY_CD                         --国家代码
							  , t.OPNAC_DT                      --开户日期
                              
 							 , CASE WHEN t.CUST_STAT < > '3'
							         THEN 99999999
									 ELSE t.CNCLACT_DT
									 END                       --销户日期
                              , t.CUST_STAT                     --客户状态
                              , a8.OPNAC_DT       as CRD_OPNAC_DT                  --融资融券开户日期
							  , CASE WHEN a8.OPNAC_DT IS NULL
							         THEN NULL
							         WHEN NVL(a8.CPTL_ACCNT_STAT,'0') < > '3' 
							         THEN 99999999
									 ELSE a8.CNCLACT_DT
									 END as CRD_CNCLACT_DT                --融资融券销户日期
							  , CASE WHEN a8.CPTL_ACCNT_STAT IS NULL
							         THEN NULL
							         WHEN NVL(a8.CPTL_ACCNT_STAT,'0') < > '3'
							         THEN 0
									 WHEN a8.CNCLACT_DT = 99999999
									 THEN 0
									 WHEN a8.CPTL_ACCNT_STAT IS NOT NULL
							         THEN 3
									 END IF_CRD_CNCLACT--是否销户融资融券
                              , a9.OPNAC_DT      as WRNT_OPNAC_DT                 --期权开户日期
						      , CASE WHEN a9.OPNAC_DT IS NULL
							         THEN NULL
							         WHEN NVL(a9.CPTL_ACCNT_STAT,'0') < > '3' 
							         THEN 99999999
									 ELSE a9.CNCLACT_DT
									 END     as WRNT_CNCLACT_DT               --期权销户日期
							  , CASE WHEN a9.CPTL_ACCNT_STAT IS NULL
							         THEN NULL
							         WHEN NVL(a9.CPTL_ACCNT_STAT,'0') < > '3'
							         THEN 0
									 WHEN a9.CNCLACT_DT = 99999999
									 THEN 0
									 WHEN a9.CPTL_ACCNT_STAT IS NOT NULL
							         THEN 3
									 END  as  IF_WRNT_CNCLACT               --是否销户期权账户
							  , DECODE(a10.H_K_OPNAC_DT,99999999,NULL,a10.H_K_OPNAC_DT) as H_K_OPNAC_DT                  --港股通开户日期
							  , DECODE(a10.H_K_CNCLACT_DT,0,NULL,a10.H_K_CNCLACT_DT)    as H_K_CNCLACT_DT                --港股通销户日期
							  , CASE WHEN a10.H_K_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.H_K_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_H_K = 0
									 THEN  0
									 WHEN a10.H_K_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                   as IF_H_K                        --是否销户港股通
							  , DECODE(a10.HK_OPNAC_DT,99999999,NULL,a10.HK_OPNAC_DT)   as HK_OPNAC_DT                   --沪港通开户日期
							  , DECODE(a10.HK_CNCLACT_DT,0,NULL,a10.HK_CNCLACT_DT)     as HK_CNCLACT_DT                 --沪港通销户日期
							  , CASE WHEN a10.HK_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.HK_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_HK = 0
									 THEN  0
									 WHEN a10.HK_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END  as IF_HK                         --是否销户沪港通 
							  , DECODE(a10.SK_OPNAC_DT,99999999,NULL,a10.SK_OPNAC_DT)   as SK_OPNAC_DT                   --深港通开户日期
							  , DECODE(a10.SK_CNCLACT_DT,0,NULL,a10.SK_CNCLACT_DT)      as SK_CNCLACT_DT                 --深港通销户日期
							  , CASE WHEN a10.SK_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.SK_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_SK = 0
									 THEN  0
									 WHEN a10.SK_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END    as IF_SK                         --是否销户深港通 							  
                              , DECODE(a10.NEW_T3BOD_OPNAC_DT,99999999,NULL,a10.NEW_T3BOD_OPNAC_DT)           as NEW_T3BOD_OPNAC_DT            --新三板开通日期
							  , DECODE(a10.NEW_T3BOD_CNCLACT_DT,0,NULL,a10.NEW_T3BOD_CNCLACT_DT)              as NEW_T3BOD_CNCLACT_DT          --新三板销户日期
							  ,CASE WHEN a10.NEW_T3BOD_CNCLACT_DT = 99999999
							         AND  a10.IF_NEW_T3BOD = 1
									 THEN 0
							         WHEN a10.NEW_T3BOD_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.NEW_T3BOD_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_NEW_T3BOD = 0
									 THEN  0
									 WHEN a10.NEW_T3BOD_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                                                as IF_NEW_T3BOD                  --是否销户新三板
                              , DECODE(a10.T3BOD_OPNAC_DT,99999999,NULL,a10.T3BOD_OPNAC_DT) as T3BOD_OPNAC_DT                --三板开通日期
							  , DECODE(a10.T3BOD_CNCLACT_DT,0,NULL,a10.T3BOD_CNCLACT_DT)    as T3BOD_CNCLACT_DT              --三板销户日期
							  , CASE WHEN a10.T3BOD_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.T3BOD_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_T3BOD = 0
									 THEN  0
									 WHEN a10.T3BOD_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                    as IF_T3BOD                      --是否销户三板
                              , DECODE(a10.REPO_MRGNC_OPNAC_DT,99999999,NULL,a10.REPO_MRGNC_OPNAC_DT) REPO_MRGNC_OPNAC_DT           --回购融资开通日期
							  , DECODE(a10.REPO_MRGNC_CNCLACT_DT,0,NULL,a10.REPO_MRGNC_CNCLACT_DT)    REPO_MRGNC_CNCLACT_DT         --回购融资销户日期
							  , CASE WHEN a10.REPO_MRGNC_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.REPO_MRGNC_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_REPO_MRGNC = 0
									 THEN  0
									 WHEN a10.REPO_MRGNC_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                 as IF_REPO_MRGNC                 --是否销户回购融资
							  , DECODE(a10.REPO_MRGNS_OPNAC_DT,99999999,NULL,a10.REPO_MRGNS_OPNAC_DT) REPO_MRGNS_OPNAC_DT           --回购融券开通日期
							  , DECODE(a10.REPO_MRGNS_CNCLACT_DT,0,NULL,a10.REPO_MRGNS_CNCLACT_DT)    REPO_MRGNS_CNCLACT_DT         --回购融券销户日期
                              , CASE WHEN a10.REPO_MRGNS_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.REPO_MRGNS_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_REPO_MRGNS = 0
									 THEN  0
									 WHEN a10.REPO_MRGNS_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                 as IF_REPO_MRGNS                 --是否销户回购融券
							
                              , DECODE(a10.GEM_OPNAC_DT,99999999,NULL,a10.GEM_OPNAC_DT) GEM_OPNAC_DT                  --创业板开通日期
							  , DECODE(a10.GEM_CNCLACT_DT,0,NULL,a10.GEM_CNCLACT_DT)    GEM_CNCLACT_DT                --创业板销户日期
							  , CASE WHEN a10.GEM_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.GEM_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_GEM = 0
									 THEN  0
									 WHEN a10.GEM_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                  as IF_GEM                        --是否销户创业板
                              , DECODE(a10.DLSTG_OPNAC_DT,99999999,NULL,a10.DLSTG_OPNAC_DT) DLSTG_OPNAC_DT                --退市整理开通日期
							  , DECODE(a10.DLSTG_CNCLACT_DT,0,NULL,a10.DLSTG_CNCLACT_DT)    DLSTG_CNCLACT_DT              --退市整理销户日期
							  , CASE WHEN a10.DLSTG_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.DLSTG_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_DLSTG = 0
									 THEN  0
									 WHEN a10.DLSTG_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END            as IF_DLSTG                      --是否销户退市整理
                              , DECODE(a10.BOND_QLFD_IVSM_OPNAC_DT,99999999,NULL,a10.BOND_QLFD_IVSM_OPNAC_DT) BOND_QLFD_IVSM_OPNAC_DT       --债券合格投资开通日期
							  , DECODE(a10.BOND_QLFD_IVSM_CNCLACT_DT,0,NULL,a10.BOND_QLFD_IVSM_CNCLACT_DT)    BOND_QLFD_IVSM_CNCLACT_DT     --债券合格投资销户日期
							  , CASE WHEN a10.BOND_QLFD_IVSM_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.BOND_QLFD_IVSM_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_BOND_QLFD_IVSM = 0
									 THEN  0
									 WHEN a10.BOND_QLFD_IVSM_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                 IF_BOND_QLFD_IVSM             --是否销户债券合格投资
                              , DECODE(a10.QOT_REPO_OPNAC_DT,99999999,NULL,a10.QOT_REPO_OPNAC_DT) QOT_REPO_OPNAC_DT             --报价回购开通日期
							  , DECODE(a10.QOT_REPO_CNCLACT_DT,0,NULL,a10.QOT_REPO_CNCLACT_DT)    QOT_REPO_CNCLACT_DT           --报价回购销户日期
							  , CASE WHEN a10.QOT_REPO_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.QOT_REPO_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_QOT_REPO = 0
									 THEN  0
									 WHEN a10.QOT_REPO_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                  IF_QOT_REPO                   --是否销户报价回购
							  , DECODE(a10.PROMS_RPHS_OPNAC_DT,99999999,NULL,a10.PROMS_RPHS_OPNAC_DT) PROMS_RPHS_OPNAC_DT           --约定购回开通日期
							  , DECODE(a10.PROMS_RPHS_CNCLACT_DT,0,NULL,a10.PROMS_RPHS_CNCLACT_DT)    PROMS_RPHS_CNCLACT_DT         --约定购回销户日期
                              , CASE WHEN a10.PROMS_RPHS_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.PROMS_RPHS_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_PROMS_RPHS = 0
									 THEN  0
									 WHEN a10.PROMS_RPHS_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                     IF_PROMS_RPHS                 --是否销户约定购回
                              , DECODE(a10.PLG_REPO_OPNAC_DT,99999999,NULL,a10.PLG_REPO_OPNAC_DT) PLG_REPO_OPNAC_DT             --质押回购开通日期
							  , DECODE(a10.PLG_REPO_CNCLACT_DT,0,NULL,a10.PLG_REPO_CNCLACT_DT)    PLG_REPO_CNCLACT_DT           --质押回购销户日期
							  , CASE WHEN a10.PLG_REPO_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.PLG_REPO_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_PLG_REPO = 0
									 THEN  0
									 WHEN a10.PLG_REPO_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                   IF_PLG_REPO                   --是否销户质押回购
                              , DECODE(a10.STK_PLG_OPNAC_DT,99999999,NULL,a10.STK_PLG_OPNAC_DT) STK_PLG_OPNAC_DT              --股票质押开通日期
							  , DECODE(a10.STK_PLG_CNCLACT_DT,0,NULL,a10.STK_PLG_CNCLACT_DT)    STK_PLG_CNCLACT_DT            --股票质押销户日期
							  , CASE WHEN a10.STK_PLG_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.STK_PLG_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_STK_PLG = 0
									 THEN  0
									 WHEN a10.STK_PLG_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END               IF_STK_PLG                    --是否销户股票质押
                              , DECODE(a10.STR_FND_OPNAC_DT,99999999,NULL,a10.STR_FND_OPNAC_DT) STR_FND_OPNAC_DT              --分级基金开通日期
							  , DECODE(a10.STR_FND_CNCLACT_DT,0,NULL,a10.STR_FND_CNCLACT_DT)    STR_FND_CNCLACT_DT            --分级基金销户日期
							  , CASE WHEN a10.STR_FND_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.STR_FND_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_STR_FND = 0
									 THEN  0
									 WHEN a10.STR_FND_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                    IF_STR_FND                    --是否销户分级基金
                              , DECODE(a10.STIB_OPNAC_DT,99999999,NULL,a10.STIB_OPNAC_DT) STIB_OPNAC_DT                 --科创板开通日期
							  , DECODE(a10.STIB_CNCLACT_DT,0,NULL,a10.STIB_CNCLACT_DT)    STIB_CNCLACT_DT               --科创板开通日期
							  , CASE WHEN a10.STIB_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.STIB_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_STIB = 0
									 THEN  0
									 WHEN a10.STIB_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                     IF_STIB                       --是否销户科创板
                              , CASE WHEN NVL(a11.PROD_CGY,0) = 1
 							         THEN '1'
									 ELSE '0'
									 END as IB_CUST_FLG                    --IB客户标志 
							  , a12.CRD_FSTTM_TRD_DT              --信用账户首次交易日期
                              , DECODE(a13.PLG_REPO_FSTTM_TRD_DT,99999999,NULL,a13.PLG_REPO_FSTTM_TRD_DT)         --质押回购首次交易日期(股票质押)
                              , DECODE(a13.STK_PLG_FSTTM_TRD_DT,99999999,NULL,a13.STK_PLG_FSTTM_TRD_DT) 	        --股票质押首次交易日期(小微贷)  
                              , a14.LMT_NEW_T3BOD_OPNAC_DT         --新三板开通日期(受限制)
                              , a14.LMT_NEW_T3BOD_CNCLACT_DT       --新三板销户日期(受限制)
                              , DECODE(a14.LMT_NEW_T3BOD_CNCLACT_DT,99999999,0,a14.IF_LMT_NEW_T3BOD)               --是否销户新三板(受限制)
                              , a15.CASH_PROD_OPNAC_DT             --现金添利开通日期
                              , a15.CASH_PROD_CNCLACT_DT           --现金添利销户日期
                              , CASE WHEN a15.CASH_PROD_OPNAC_DT  IS NOT NULL
							         AND a15.CASH_PROD_CNCLACT_DT = 99999999
									 THEN 0 
									 WHEN a15.CASH_PROD_OPNAC_DT  IS NOT NULL
							         AND a15.CASH_PROD_CNCLACT_DT < > 99999999
									 THEN 3 									
									 ELSE NULL
									 END   as IF_CASH_PROD                   --是否销户现金添利
                              , DECODE(a15.CASH_PROD_FSTTM_TRD_DT,99999999,NULL,a15.CASH_PROD_FSTTM_TRD_DT)         ----现金添利首次交易日期
                              ,CASE WHEN a17.SH_WRNT_OPNAC_DT IS NOT NULL
 							        AND  a17.SH_WRNT_OPNAC_DT > 0
									THEN a17.SH_WRNT_OPNAC_DT
									ELSE NULL
									END as SH_WRNT_OPNAC_DT--沪市期权开户日期
                              ,CASE WHEN a17.SH_WRNT_OPNAC_DT IS NOT NULL
 							        AND  a17.SH_WRNT_OPNAC_DT > 0
									THEN a17.SH_WRNT_CNCLACT_DT
									ELSE NULL
									END   as SH_WRNT_CNCLACT_DT               --沪市期权销户日期
							 ,CASE  WHEN a17.SH_WRNT_CNCLACT_DT = 99999999
							        THEN 0
							        WHEN a17.SH_WRNT_OPNAC_DT IS NOT NULL
 							        AND  a17.SH_WRNT_OPNAC_DT > 0
									THEN a17.IF_SH_WRNT_CNCLACT
									ELSE NULL
									END as IF_SH_WRNT_CNCLACT               --是否销户沪市期权账户
							,CASE WHEN a17.SZ_WRNT_OPNAC_DT IS NOT NULL
 							      AND  a17.SZ_WRNT_OPNAC_DT > 0
							      THEN a17.SZ_WRNT_OPNAC_DT
								  ELSE NULL
								  END as SZ_WRNT_OPNAC_DT--深市期权开户日期
                            ,CASE WHEN a17.SZ_WRNT_OPNAC_DT IS NOT NULL
 							      AND  a17.SZ_WRNT_OPNAC_DT > 0
							      THEN a17.SZ_WRNT_CNCLACT_DT
								  ELSE NULL
								  END   as SZ_WRNT_CNCLACT_DT               --深市期权销户日期
							,CASE WHEN a17.SH_WRNT_CNCLACT_DT = 99999999
							      THEN 0
							      WHEN a17.SZ_WRNT_OPNAC_DT IS NOT NULL
 							      AND  a17.SZ_WRNT_OPNAC_DT > 0
								  THEN a17.IF_SH_WRNT_CNCLACT
								  ELSE NULL
								  END as IF_SZ_WRNT_CNCLACT               --是否销户深市期权账户
                              , DECODE(a10.NEW_T3BOD_OPNAC_DT_1,99999999,NULL,a10.NEW_T3BOD_OPNAC_DT_1)           as NEW_T3BOD_OPNAC_DT_1            --新三板开通日期
							  , DECODE(a10.NEW_T3BOD_CNCLACT_DT_1,0,NULL,a10.NEW_T3BOD_CNCLACT_DT_1)              as NEW_T3BOD_CNCLACT_DT_1          --新三板销户日期
							  , CASE WHEN a10.NEW_T3BOD_OPNAC_DT_1 = 99999999
							         THEN NULL
									 WHEN a10.NEW_T3BOD_OPNAC_DT_1 IS NULL
									 THEN NULL
									 WHEN a10.IF_NEW_T3BOD_1 = 0
									 THEN  0
									 WHEN a10.NEW_T3BOD_CNCLACT_DT_1 = 99999999
									 THEN  0
									 ELSE 3
									 END                                                 as IF_NEW_T3BOD_1                  --是否销户新三板	
                             , DECODE(a10.NEW_T3BOD_OPNAC_DT_2,99999999,NULL,a10.NEW_T3BOD_OPNAC_DT_2)           as NEW_T3BOD_OPNAC_DT_2            --新三板开通日期
							  , DECODE(a10.NEW_T3BOD_CNCLACT_DT_2,0,NULL,a10.NEW_T3BOD_CNCLACT_DT_2)              as NEW_T3BOD_CNCLACT_DT_2          --新三板销户日期
							  , CASE WHEN a10.NEW_T3BOD_OPNAC_DT_2 = 99999999
							         THEN NULL
									 WHEN a10.NEW_T3BOD_OPNAC_DT_2 IS NULL
									 THEN NULL
									 WHEN a10.IF_NEW_T3BOD_2 = 0
									 THEN  0
									 WHEN a10.NEW_T3BOD_CNCLACT_DT_2 = 99999999
									 THEN  0
									 ELSE 3
									 END                                                 as IF_NEW_T3BOD_2                  --是否销户新三板
                             , DECODE(a10.NEW_T3BOD_OPNAC_DT_3,99999999,NULL,a10.NEW_T3BOD_OPNAC_DT_3)           as NEW_T3BOD_OPNAC_DT_3            --新三板开通日期
							  , DECODE(a10.NEW_T3BOD_CNCLACT_DT_3,0,NULL,a10.NEW_T3BOD_CNCLACT_DT_3)              as NEW_T3BOD_CNCLACT_DT_3          --新三板销户日期
							  , CASE WHEN a10.NEW_T3BOD_OPNAC_DT_3 = 99999999
							         THEN NULL
									 WHEN a10.NEW_T3BOD_OPNAC_DT_3 IS NULL
									 THEN NULL
									 WHEN a10.IF_NEW_T3BOD_3 = 0
									 THEN  0
									 WHEN a10.NEW_T3BOD_CNCLACT_DT_3 = 99999999
									 THEN  0
									 ELSE 3
									 END                                                 as IF_NEW_T3BOD_3                  --是否销户新三板										 
                            ,t.RSK_BEAR_ABLTY                  --风险承受能力
                              , DECODE(a10.RGST_GEM_OPNAC_DT,99999999,NULL,a10.RGST_GEM_OPNAC_DT) as RGST_GEM_OPNAC_DT                --注册创业板开通日期
							  , DECODE(a10.RGST_GEM_CNCLACT_DT,0,NULL,a10.RGST_GEM_CNCLACT_DT)    as RGST_GEM_CNCLACT_DT              --注册创业板销户日期
							  , CASE WHEN a10.RGST_GEM_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a10.RGST_GEM_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a10.IF_RGST_GEM = 0
									 THEN  0
									 WHEN a10.RGST_GEM_CNCLACT_DT = 99999999
									 THEN  0
									 ELSE 3
									 END                    as IF_RGST_GEM                      --是否销户注册创业板
                              , DECODE(a18.ORDI_RGST_GEM_OPNAC_DT,99999999,NULL,a18.ORDI_RGST_GEM_OPNAC_DT) as ORDI_RGST_GEM_OPNAC_DT                --普通账户注册创业板开通日期
							  , DECODE(a18.ORDI_RGST_GEM_CNCLACT_DT,0,NULL,a18.ORDI_RGST_GEM_CNCLACT_DT)    as ORDI_RGST_GEM_CNCLACT_DT              --普通账户注册创业板销户日期
							  , CASE WHEN a18.ORDI_RGST_GEM_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a18.ORDI_RGST_GEM_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a18.IF_ORDI_RGST_GEM = 0
									 THEN  0
									 WHEN a18.ORDI_RGST_GEM_CNCLACT_DT = 99999999
									 THEN  0
									 ELSE 3
									 END                    as IF_ORDI_RGST_GEM                      --是否销户普通账户注册创业板
                              , DECODE(a18.CRD_RGST_GEM_OPNAC_DT,99999999,NULL,a18.CRD_RGST_GEM_OPNAC_DT) as CRD_RGST_GEM_OPNAC_DT                --信用账户注册创业板开通日期
							  , DECODE(a18.CRD_RGST_GEM_CNCLACT_DT,0,NULL,a18.CRD_RGST_GEM_CNCLACT_DT)    as CRD_RGST_GEM_CNCLACT_DT              --信用账户注册创业板销户日期
							  , CASE WHEN a18.CRD_RGST_GEM_OPNAC_DT = 99999999
							         THEN NULL
									 WHEN a18.CRD_RGST_GEM_OPNAC_DT IS NULL
									 THEN NULL
									 WHEN a18.IF_CRD_RGST_GEM = 0
									 THEN  0
									 WHEN a18.CRD_RGST_GEM_CNCLACT_DT = 99999999
									 THEN  0
									 ELSE 3
									 END                    as IF_CRD_RGST_GEM                     --是否销户信用账户注册创业板
							  , DECODE(a18.ORDI_GEM_OPNAC_DT ,99999999,NULL,a18.ORDI_GEM_OPNAC_DT ) as ORDI_GEM_OPNAC_DT                 --普通账户创业板开通日期
							  , DECODE(a18.ORDI_GEM_CNCLACT_DT,0,NULL,a18.ORDI_GEM_CNCLACT_DT)    as ORDI_GEM_CNCLACT_DT              --普通账户创业板销户日期
							  , CASE WHEN a18.ORDI_GEM_OPNAC_DT  = 99999999
							         THEN NULL
									 WHEN a18.ORDI_GEM_OPNAC_DT  IS NULL
									 THEN NULL
									 WHEN a18.IF_ORDI_GEM = 0
									 THEN  0
									 WHEN a18.ORDI_GEM_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                    as IF_ORDI_GEM                     --是否销户普通账户创业板
							  , DECODE(a18.CRD_GEM_OPNAC_DT ,99999999,NULL,a18.CRD_GEM_OPNAC_DT ) as CRD_GEM_OPNAC_DT                 --信用账户创业板开通日期
							  , DECODE(a18.CRD_GEM_CNCLACT_DT,0,NULL,a18.CRD_GEM_CNCLACT_DT)    as CRD_GEM_CNCLACT_DT              --信用账户创业板销户日期
							  , CASE WHEN a18.CRD_GEM_OPNAC_DT  = 99999999
							         THEN NULL
									 WHEN a18.CRD_GEM_OPNAC_DT  IS NULL
									 THEN NULL
									 WHEN a18.IF_CRD_GEM = 0
									 THEN  0
									 WHEN a18.CRD_GEM_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                    as IF_CRD_GEM                     --是否销户信用账户创业板
						      , DECODE(a18.ORDI_STIB_OPNAC_DT ,99999999,NULL,a18.ORDI_STIB_OPNAC_DT ) as ORDI_STIB_OPNAC_DT                 --普通账户科创板开通日期
							  , DECODE(a18.ORDI_STIB_CNCLACT_DT,0,NULL,a18.ORDI_STIB_CNCLACT_DT)    as ORDI_STIB_CNCLACT_DT              --普通账户科创销户日期
							  , CASE WHEN a18.ORDI_STIB_OPNAC_DT  = 99999999
							         THEN NULL
									 WHEN a18.ORDI_STIB_OPNAC_DT  IS NULL
									 THEN NULL
									 WHEN a18.IF_ORDI_STIB = 0
									 THEN  0
									 WHEN a18.ORDI_STIB_CNCLACT_DT = 99999999
									 THEN 0
									 ELSE 3
									 END                    as IF_ORDI_STIB                      --是否销户普通账户科创板 
							  , DECODE(a18.CRD_STIB_OPNAC_DT ,99999999,NULL,a18.CRD_STIB_OPNAC_DT ) as CRD_STIB_OPNAC_DT                 --信用账户科创板开通日期
							  , DECODE(a18.CRD_STIB_CNCLACT_DT,0,NULL,a18.CRD_STIB_CNCLACT_DT)    as CRD_STIB_CNCLACT_DT              --信用账户科创销户日期
							  , CASE WHEN a18.CRD_STIB_OPNAC_DT  = 99999999
							         THEN NULL
									 WHEN a18.CRD_STIB_OPNAC_DT  IS NULL
									 THEN NULL
									 WHEN a18.CRD_STIB_CNCLACT_DT = 99999999
									 THEN 0
									 WHEN a18.IF_CRD_STIB = 0
									 THEN  0
									 ELSE 3
									 END                    as IF_CRD_STIB                      --是否销户信用账户科创板 
  FROM           DDW_PROD.T_DDW_F00_CUST_CUST_INFO              t 
  INNER JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                     a1
  ON             t.BRH_NO = a1.BRH_NO
  AND            a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     (SELECT * FROM  DDW_PROD.T_DDW_LM_LABEL_V_C_HIS 
                 WHERE   LABEL_ID = '8d0fe69b4ff546f082775761d27c70a5'
				 AND     BUS_DATE = %d{yyyyMMdd}
				 )                                               a2
  ON             t.CUST_NO = a2.CUST_NO
  LEFT JOIN    (SELECT * FROM DDW_PROD.T_DDW_LM_LABEL_DM 
                WHERE LABEL_ID = '8d0fe69b4ff546f082775761d27c70a5'
			   )                                                  a3
  ON            a2.LABEL_VALUE = a3.LABEL_VALUE
  LEFT JOIN  ( SELECT     a.PSN_NO
                         ,a.CUST_NO
		                 ,a.SVC_RLN_TP
		                 ,c.BRK_CGY_NAME
						 ,a.PSN_NAME
						 ,a.PSN_BELTO_BRH
               FROM      DDW_PROD.T_DDW_F00_CUST_CUST_RLN       a
               LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN   b
               ON        a.CUST_NO = b.CUST_NO
               AND       b.BUS_DATE = %d{yyyyMMdd}
			   AND      %d{yyyyMMdd} > = b.STATS_DT 
			   AND      %d{yyyyMMdd} < NVL(b.EXPR_DT,99999999)
               LEFT JOIN  DDW_PROD.V_BRK_CGY                     c
               ON         b.BRK_CGY = c.BRK_CGY
               WHERE %d{yyyyMMdd} > = a.STATS_DT 
               AND   %d{yyyyMMdd} < NVL(a.EXPR_DT,99999999) 
               AND   a.BUS_DATE = %d{yyyyMMdd}
               AND   a.SVC_RLN_TP IN ('10')
			   )                                                a4
  ON           t.CUST_NO = a4.CUST_NO
   LEFT JOIN  ( SELECT    a.PSN_NO
                         ,a.CUST_NO
		                 ,a.SVC_RLN_TP
                         ,a.PSN_NAME
                         ,c.BRK_CGY_NAME
                         ,a.PSN_BELTO_BRH						 
               FROM      DDW_PROD.T_DDW_F00_CUST_CUST_RLN       a
               LEFT JOIN EDW_PROD.T_EDW_T01_TRYXX               b
               ON        cast(a.PSN_ID AS INT) = b.ID
			   AND       b.BUS_DATE = %d{yyyyMMdd}
			   LEFT JOIN  DDW_PROD.V_BRK_CGY                     c
               ON         b.RYLB = c.BRK_CGY
               WHERE %d{yyyyMMdd} > = a.STATS_DT 
               AND   %d{yyyyMMdd} < NVL(a.EXPR_DT,99999999) 
               AND   a.BUS_DATE = %d{yyyyMMdd}
               AND   a.SVC_RLN_TP IN ('4')
			   )                                                a5
  ON           t.CUST_NO = a5.CUST_NO
  LEFT JOIN  ( SELECT     a.PSN_NO
                         ,a.CUST_NO
		                 ,a.SVC_RLN_TP
                         ,a.PSN_NAME
                         ,c.BRK_CGY_NAME
                         ,a.PSN_BELTO_BRH						 
               FROM    ( SELECT * FROM 
			            (SELECT PSN_NO,PSN_BELTO_BRH,CUST_NO,SVC_RLN_TP,PSN_NAME,PSN_ID,ROW_NUMBER() OVER(PARTITION BY CUST_NO ORDER BY PSN_ID DESC  )  as NUM
			             FROM   DDW_PROD.T_DDW_F00_CUST_CUST_RLN  
			             WHERE  %d{yyyyMMdd} > = STATS_DT
						 AND   %d{yyyyMMdd} < NVL(EXPR_DT,99999999)
						 AND    BUS_DATE = %d{yyyyMMdd}
						 AND    SVC_RLN_TP IN ('5')
					     ) a
						 WHERE a.NUM = 1
					   
					   )a
               LEFT JOIN EDW_PROD.T_EDW_T01_TRYXX               b
               ON        cast(a.PSN_ID AS INT) = b.ID
			   AND       b.BUS_DATE = %d{yyyyMMdd}
			   LEFT JOIN  DDW_PROD.V_BRK_CGY                     c
               ON         b.RYLB = c.BRK_CGY
			   )                                                a16
  ON           t.CUST_NO = a16.CUST_NO
  LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP       a6
  ON         t.CUST_NO = a6.CUST_NO
  LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP1        a7
  ON         t.CUST_NO = a7.CUST_NO
  LEFT JOIN  (SELECT  CUST_NO
					  ,MIN(NVL(OPNAC_DT,99999999))   as OPNAC_DT
                      ,MAX(NVL(CNCLACT_DT,99999999)) as CNCLACT_DT
					  ,MIN(DECODE(CPTL_ACCNT_STAT,'0','0','3','3','0'))  as CPTL_ACCNT_STAT					  
               FROM DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
			   WHERE SYS_SRC IN ('信用账户')
			   AND   BUS_DATE = %d{yyyyMMdd}
			   GROUP BY CUST_NO
			   )                                                a8
  ON         t.CUST_NO = a8.CUST_NO		
  LEFT JOIN  (SELECT  CUST_NO
					  ,MIN(NVL(OPNAC_DT,99999999))   as OPNAC_DT
                      ,MAX(NVL(CNCLACT_DT,99999999)) as CNCLACT_DT
					  ,MIN(DECODE(CPTL_ACCNT_STAT,'0','0','3','3','0'))  as CPTL_ACCNT_STAT					  
               FROM DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
			   WHERE SYS_SRC IN ('期权账户')
			   AND   BUS_DATE = %d{yyyyMMdd}
			   GROUP BY CUST_NO
			   )                                                a9
  ON         t.CUST_NO = a9.CUST_NO
  LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP2        a10
  ON         t.CUST_NO = a10.CUST_NO  
  LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_ORG_CUST_INFO     a11
  ON         t.CUST_NO = a11.CUST_NO
  AND        a11.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP3        a12
  ON         t.CUST_NO = a12.CUST_NO
  LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP4        a13
  ON         t.CUST_NO = a13.CUST_NO
  LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP5        a14
  ON         t.CUST_NO = a14.CUST_NO
  LEFT JOIN  (SELECT cust_no
                     ,MIN(NVL(FSTTM_TRD_DT,99999999)) as CASH_PROD_FSTTM_TRD_DT
					 ,MIN(SIGN_DT)      as CASH_PROD_OPNAC_DT
					 ,MAX(TML_DT)       as CASH_PROD_CNCLACT_DT
              FROM   DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL
              WHERE  BUS_DATE = %d{yyyyMMdd}
			  GROUP BY CUST_NO
              )                                                   a15
  ON           t.CUST_NO = a15.CUST_NO
  LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP6     a17
  ON         t.CUST_NO = a17.CUST_NO
  LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP7     a18
  ON         t.CUST_NO = a18.CUST_NO
  WHERE         t.BUS_DATE = %d{yyyyMMdd} 
  AND           t.CUST_NO < > '100610335855'
  ;
  
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP1;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP2;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP3;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP4;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP5;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP6;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_TEMP7;
  INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_CUST_ATTR_LABL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL ;

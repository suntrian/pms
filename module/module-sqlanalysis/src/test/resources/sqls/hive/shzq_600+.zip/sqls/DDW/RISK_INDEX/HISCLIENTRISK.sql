------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:同一客户风险集中管理                                                            */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

--------------插入数据-------------------
INSERT OVERWRITE RISK_INDEX.HISCLIENTRISK
(
		 TRADEDATE            --日期                                            
		,UNIT_CODE            --所属机构（1、国泰君安证券；2、上海证券）   
		,BRANCH_CODE          --营业部                                        
		,SUB_BRANCH_CODE      --分支机构                                    
		,ID_TYPE              --证件类型                                    
		,ID_NO                --证件号码                                     
		,CUSTOMER_NO          --客户代码                                      
		,CLIENT_NAME          --客户名称                                       
		,BUSI_TYPE            --业务类别(1、股票质押；2、约定购回；3、融资融券)
		,INFO_TYPE            --信息类别(1、合约逾期；2、平仓预警；3、购回逾期)
		,GUAR_RAT             --维持担保（履约保障）比例                    
		,TOTAL_DEBTS          --负债                                    
		,PLEDGE_ASSET         --担保资产                                                                                    								 			                                                             
 ) 
PARTITION(DT = '%d{yyyyMMdd}')
SELECT        CAST(t.OC_DATE AS CHAR(8))                           AS TRADEDATE
			 ,CAST('2' AS VARCHAR(160))                            AS UNIT_CODE
			 ,t.BRANCH_NO                                          AS BRANCH_CODE
			 ,CAST(' ' AS VARCHAR(40))                             AS SUB_BRANCH_CODE
			 ,a2.ID_KIND                                           AS ID_TYPE
			 ,a2.ID_NO                                             AS ID_NO
			 ,t.CLIENT_ID                                          AS CUSTOMER_NO
			 ,a2.CLIENT_NAME                                       AS CLIENT_NAME
			 ,CAST(CASE WHEN a1.BUSINESS_TYPE = '3'                
			  	   THEN  '3' 
				   ELSE '1'                              
			       END AS VARCHAR(200))                            AS BUSI_TYPE
			 ,CAST('2' AS VARCHAR(200))                            AS INFO_TYPE
			 ,CAST(CASE WHEN NVL(t.BALANCE,0) = 0 
			  	   THEN 0 
			  	   ELSE NVL(a1.ASSET_BALANCE/t.BALANCE,0) 
			  	   END AS DECIMAL(20,4))                           AS GUAR_RAT
			 ,CAST(NVL(t.BALANCE,0) AS DECIMAL(20,4))              AS TOTAL_DEBTS
			 ,CAST(NVL(a1.ASSET_BALANCE,0) AS DECIMAL(20,4))       AS PLEDGE_ASSET
      FROM 		  HSFK.HSMAN_HISCLIENTFINANCING t
LEFT JOIN 	  HSFK.HSMAN_HISCLIENTASSET a1
        ON t.client_id = a1.client_id
       AND t.branch_no = a1.branch_no
       AND t.oc_date = a1.oc_date
       and ((t.business_type = '1' and a1.business_type = '3') or (t.business_type = '3' and a1.business_type = '5'))
AND           t.DT           = '%d{yyyyMMdd}'
AND           a1.DT          = '%d{yyyyMMdd}' 
LEFT JOIN     HSFK.HSMAN_CLIENT             a2 
ON t.client_id = a2.client_id
       AND t.branch_no = a1.branch_no
       AND t.oc_date = a1.oc_date
       and ((t.business_type = '1' and a1.business_type = '3') or (t.business_type = '3' and a1.business_type = '5'))      
WHERE t.oc_date = %d{yyyyMMdd}
       AND t.business_type in ('1','3')
       AND a1.business_type in ('3','5')
	   and t.balance<> 0 
	   and a1.asset_balance/t.balance <1.3
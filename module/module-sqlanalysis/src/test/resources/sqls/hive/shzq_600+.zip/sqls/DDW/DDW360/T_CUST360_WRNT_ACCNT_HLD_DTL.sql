 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360期权账户持仓明细表                                                          */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-10-27                                                                       */ 
  /* T_DDW_F02_WRNT_HLD_DTL	替换为	T_DDW_F00_AST_WRNT_HLD_DTL_HIS */
  


---------------- 插入数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_WRNT_ACCNT_HLD_DTL
 (
	 CUST_NO               --客户号               
	,CUST_NAME             --客户姓名       
	,BRH_NAME              --营业部名称     
	,EXG                   --交易所
	,CCY                   --币种
	,WRNT_CTC_CD           --期权合约代码
	,WRNT_TP               --期权类型
	,WRNT_SEC_TP           --标的证券类型
	,WRNT_BS_DRCT          --期权买卖方向
	,WRNT_CVD_LABL         --期权备兑标签
	,WRNT_CTC_QTY          --期权合约数量
	,WRNT_NEWST_MKTVAL     --期权最新市值
	,WRNT_NEWST_PRC        --收盘价
 )PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT      t.CUST_NO                as CUST_NO               --客户号              
            ,t.CUST_NAME              as CUST_NAME             --客户姓名       
            ,a1.JGMC                  as BRH_NAME              --营业部名称     
            ,a2.EXG_NAME              as EXG                   --交易所
            ,a4.CCY_CD_NAME           as CCY                   --币种
            ,T.WRNT_CTC_CD             as WRNT_CTC_CD           --期权合约代码
            ,a3.WRNT_TP_NAME          as WRNT_TP               --期权类型
            ,a6.WRNT_SEC_TP_NAME      as WRNT_SEC_TP           --标的证券类型
            ,a7.WRNT_BS_DRCT_NAME     as WRNT_BS_DRCT          --期权买卖方向
            ,a8.WRNT_CVD_LABL_NAME    as WRNT_CVD_LABL         --期权备兑标签
            ,T.WRNT_CTC_QTY            as WRNT_CTC_QTY          --期权合约数量
            ,T.WRNT_NEWST_MKTVAL       as WRNT_NEWST_MKTVAL     --期权最新市值
            ,a5.NEWST_PRC             as WRNT_NEWST_PRC        --收盘价
 FROM         DDW_PROD.T_DDW_F00_AST_WRNT_HLD_DTL_HIS       t
 LEFT JOIN    EDW_PROD.T_EDW_T03_TJGGL             a1
 ON           t.BRH_NO = a1.JGDM
 AND          t.BUS_DATE = a1.BUS_DATE
 LEFT JOIN    DDW_PROD.V_EXG                       a2
 ON           t.EXG = a2.EXG
 LEFT JOIN    DDW_PROD.V_WRNT_TP                   a3
 ON           T.WRNT_TP = a3.WRNT_TP
 LEFT JOIN    DDW_PROD.V_CCY_CD                    a4
 ON           t.CCY_CD = a4.CCY_CD
 LEFT JOIN    DDW_PROD.V_WRNT_SEC_TP               a6
 ON           T.WRNT_SEC_TP = a6.WRNT_SEC_TP
 LEFT JOIN    DDW_PROD.V_WRNT_BS_DRCT              a7
 ON           T.WRNT_BS_DRCT = a7.WRNT_BS_DRCT
 LEFT JOIN    DDW_PROD.V_WRNT_CVD_LABL             a8
 ON           T.WRNT_CVD_LABL = a8.WRNT_CVD_LABL
 LEFT JOIN    DDW_PROD.T_DDW_PUB_QOT               a5
 ON           t.EXG = a5.EXG
 AND          T.WRNT_CTC_CD = a5.CD
 AND          a5.trd_mkt = 3
 AND          t.bus_date = a5.BUS_DATE 
 WHERE        t.BUS_DATE = %d{yyyyMMdd}
 
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_WRNT_ACCNT_HLD_DTL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_WRNT_ACCNT_HLD_DTL;
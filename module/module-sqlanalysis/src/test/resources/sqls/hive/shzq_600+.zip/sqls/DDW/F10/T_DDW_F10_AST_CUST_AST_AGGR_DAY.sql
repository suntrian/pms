------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户资产汇总日表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
  
------当日资金临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP
as SELECT  a.CUST_NO
           ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		             AND  a.CCY_CD = 'USD'
				     THEN a.ACCNT_BAL
				     ELSE 0
				     END)              as ORDI_CPTL_USD                       --普通账户资金_美元
           ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		             AND a.CCY_CD = 'HKD'
				     THEN a.ACCNT_BAL
				     ELSE 0
				     END)              as ORDI_CPTL_HKD                       --普通账户资金_港币
           ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		             AND a.CCY_CD = 'RMB'
				     THEN a.ACCNT_BAL
				     ELSE 0
				     END)              as ORDI_CPTL_RMB                       --普通账户资金_人民币	
          ,SUM(ROUND(CASE WHEN a.SYS_SRC = '普通账户' 
		                  AND b.BZDM IS NOT NULL
				          THEN a.ACCNT_BAL*b.ZHHL
				          WHEN a.SYS_SRC = '普通账户' 
		                  AND b.BZDM IS  NULL
					      THEN a.ACCNT_BAL
						  ELSE 0
				          END,2)
			   )              as ORDI_CPTL                           --普通账户资金(折算人民币)
          ,SUM(ROUND(CASE WHEN a.SYS_SRC = '普通账户' 
		                  AND b.BZDM IS NOT NULL
				          THEN a.UNPY_AMT*b.ZHHL
				          WHEN a.SYS_SRC = '普通账户' 
		                  AND b.BZDM IS  NULL
					      THEN a.UNPY_AMT
						  ELSE 0
				          END,2)
			   )             as ORDI_UNPY_CPTL                      --普通账户在途资金(折算人民币)
		  ,SUM(ROUND(CASE WHEN a.SYS_SRC = '信用账户' 		                  
				          THEN a.UNPY_AMT
				          ELSE 0
				          END,2)
			   )      as CRD_UNPY_CPTL                       --信用账户在途资金
		  ,SUM(ROUND(CASE WHEN a.SYS_SRC = '期权账户' 		                  
				          THEN a.UNPY_AMT
				          ELSE 0
				          END,2)
			   )      as WRNT_UNPY_CPTL                      --期权账户在途资金
          ,SUM(ROUND(CASE WHEN a.SYS_SRC = '信用账户' 		                  
				          THEN a.ACCNT_BAL
				          ELSE 0
				          END,2)
			   )      as CRD_CPTL                            --信用账户资金
          ,SUM(ROUND(CASE WHEN a.SYS_SRC = '期权账户' 		                  
				          THEN a.ACCNT_BAL
				          ELSE 0
				          END,2)
			   )   as WRNT_CPTL                           --期权账户资金
		  ,SUM(ROUND(CASE WHEN b.BZDM IS NOT NULL
				          THEN a.UNPY_AMT*b.ZHHL
						  WHEN b.BZDM IS  NULL
						  THEN a.UNPY_AMT
				          ELSE 0
				          END,2)
			   )    as TOT_UNPY_CPTL                       --总的在途资金
          ,SUM(ROUND(CASE WHEN b.BZDM IS NOT NULL
				          THEN a.ACCNT_BAL*b.ZHHL
						  WHEN b.BZDM IS  NULL
						  THEN a.ACCNT_BAL
				          ELSE 0
				          END,2)
			   )    as TOT_CPTL                            --总资金  
   FROM           DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS  a
   LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH              b
   ON             a.CCY_CD = b.BZDM
   AND            b.BUS_DATE = %d{yyyyMMdd}
   WHERE          a.BUS_DATE = %d{yyyyMMdd}
   GROUP BY       a.CUST_NO
   ;
 
----当日资金变化临时表   
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP2 ;
CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP2
as SELECT  a.CUST_NO
           ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		             AND  a.CCY_CD = 'USD'
					 AND  SUBSTR(a.BIZ_SBJ,1,3) = '101'
				     THEN a.INCM_AMT
				     ELSE 0
				     END)   as ORDI_DEPIN_AMT_USD                  --普通账户存入金额_美元
           ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		             AND  a.CCY_CD = 'HKD'
					 AND  SUBSTR(a.BIZ_SBJ,1,3) = '101'
				     THEN a.INCM_AMT
				     ELSE 0
				     END)   as ORDI_DEPIN_AMT_HKD                  --普通账户存入金额_港币
           ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		             AND  a.CCY_CD = 'RMB'
					 AND  SUBSTR(a.BIZ_SBJ,1,3) = '101'
				     THEN a.INCM_AMT
				     ELSE 0
				     END)  as ORDI_DEPIN_AMT_RMB                  --普通账户存入金额_人民币
           ,SUM(ROUND(CASE WHEN a.SYS_SRC = '普通账户' 
		                   AND b.BZDM IS NOT NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ = '10399')
				           THEN a.INCM_AMT*b.ZHHL
				           WHEN a.SYS_SRC = '普通账户' 
		                   AND b.BZDM IS  NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ = '10399')
					       THEN a.INCM_AMT
						   ELSE 0
				           END,2)
			   )    as ORDI_TFR_IN_AMT                     --普通账户转入金额(折算人民币)
           ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		             AND  a.CCY_CD = 'USD'
					 AND  SUBSTR(a.BIZ_SBJ,1,3) = '102'
				     THEN a.PAY_AMT
				     ELSE 0
				     END)  as ORDI_WTHDR_AMT_USD                  --普通账户取出金额_美元
           ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		             AND  a.CCY_CD = 'HKD'
					 AND  SUBSTR(a.BIZ_SBJ,1,3) = '102'
				     THEN a.PAY_AMT
				     ELSE 0
				     END) as ORDI_WTHDR_AMT_HKD                  --普通账户取出金额_港币
           ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		             AND  a.CCY_CD = 'RMB'
					 AND  SUBSTR(a.BIZ_SBJ,1,3) = '102'
				     THEN a.PAY_AMT
				     ELSE 0
				     END)  as ORDI_WTHDR_AMT_RMB                  --普通账户取出金额_人民币
           ,SUM(ROUND(CASE WHEN a.SYS_SRC = '普通账户' 
		                   AND b.BZDM IS NOT NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ = '10499')
				           THEN a.PAY_AMT*b.ZHHL
				           WHEN a.SYS_SRC = '普通账户' 
		                   AND b.BZDM IS  NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ = '10499')
					       THEN a.PAY_AMT
						   ELSE 0
				           END,2)
			   )   as  ORDI_TFR_OUT_AMT                    --普通账户转出金额(折算人民币)
           ,SUM(CASE WHEN a.SYS_SRC = '信用账户' 
		             AND  a.CCY_CD = 'RMB'
					 AND  SUBSTR(a.BIZ_SBJ,1,3) = '101'
				     THEN a.INCM_AMT
				     ELSE 0
				     END) as CRD_DEPIN_AMT                   --信用账户存入金额
           ,SUM(CASE WHEN a.SYS_SRC = '信用账户' 
		             AND  a.CCY_CD = 'RMB'
					 AND  (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ = '10399')
				     THEN a.INCM_AMT
				     ELSE 0
				     END) as CRD_TFR_IN_AMT                      --信用账户转入金额
           ,SUM(CASE WHEN a.SYS_SRC = '信用账户' 
		             AND  a.CCY_CD = 'RMB'
					 AND  SUBSTR(a.BIZ_SBJ,1,3) = '102'
				     THEN a.PAY_AMT
				     ELSE 0
				     END) as CRD_WTHDR_AMT                   --信用账户取出金额
           ,SUM(CASE WHEN a.SYS_SRC = '信用账户' 
		             AND  a.CCY_CD = 'RMB'
					 AND  (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ = '10499')
				     THEN a.PAY_AMT
				     ELSE 0
				     END) as CRD_TFR_OUT_AMT                     --信用账户转出金额
           ,SUM(CASE WHEN a.SYS_SRC = '期权账户' 
		             AND  a.CCY_CD = 'RMB'
					 AND  SUBSTR(a.BIZ_SBJ,1,3) = '101'
				     THEN a.INCM_AMT
				     ELSE 0
				     END) as WRNT_DEPIN_AMT                  --期权账户存入金额
          ,SUM(CASE WHEN a.SYS_SRC = '期权账户' 
		             AND  a.CCY_CD = 'RMB'
					 AND  (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ = '10399')
				     THEN a.INCM_AMT
				     ELSE 0
				     END) as  WRNT_TFR_IN_AMT                     --期权账户转入金额
           ,SUM(CASE WHEN a.SYS_SRC = '期权账户' 
		             AND  a.CCY_CD = 'RMB'
					 AND  SUBSTR(a.BIZ_SBJ,1,3) = '102'
				     THEN a.PAY_AMT
				     ELSE 0
				     END) as WRNT_WTHDR_AMT                  --期权账户取出金额
           ,SUM(CASE WHEN a.SYS_SRC = '期权账户' 
		             AND  a.CCY_CD = 'RMB'
					 AND  (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ = '10499')
				     THEN a.PAY_AMT
				     ELSE 0
				     END)   as WRNT_TFR_OUT_AMT                    --期权账户转出金额
           ,SUM(ROUND(CASE WHEN b.BZDM IS NOT NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ = '10399')
				           THEN a.INCM_AMT*b.ZHHL
				           WHEN  b.BZDM IS  NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ = '10399')
					       THEN a.INCM_AMT
						   ELSE 0
				           END,2)
			   )    as TFR_IN_AMT                          --转入资金
           ,SUM(ROUND(CASE WHEN  b.BZDM IS NOT NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ = '10499')
				           THEN a.PAY_AMT*b.ZHHL
				           WHEN  b.BZDM IS  NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ = '10499')
					       THEN a.PAY_AMT
						   ELSE 0
				           END,2)
			   ) as TFR_OUT_AMT                         --转出资金
           ,SUM(ROUND(CASE WHEN a.SYS_SRC = '普通账户' 
		                   AND b.BZDM IS NOT NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ = '10399')
				           THEN a.INCM_AMT*b.ZHHL
				           WHEN a.SYS_SRC = '普通账户' 
		                   AND b.BZDM IS  NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ = '10399')
					       THEN a.INCM_AMT
						   WHEN a.SYS_SRC = '普通账户' 
		                   AND b.BZDM IS NOT NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ = '10499')
				           THEN 0-a.PAY_AMT*b.ZHHL
				           WHEN a.SYS_SRC = '普通账户' 
		                   AND b.BZDM IS  NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ = '10499')
					       THEN 0-a.PAY_AMT
						   ELSE 0
				           END,2)
			   )   as ORDI_NET_TFR_IN_AMT                 --普通账户净转入资金
          ,SUM(ROUND(CASE  WHEN  a.SYS_SRC = '信用账户' 
		                   AND  (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ = '10399')
					       THEN a.INCM_AMT
						   WHEN  a.SYS_SRC = '信用账户' 
		                   AND  (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ = '10499')
					       THEN 0-a.PAY_AMT
						   ELSE 0
				           END,2)
			   )  as CRD_NET_TFR_IN_AMT                  --信用账户净转入资金
           ,SUM(ROUND(CASE  WHEN  a.SYS_SRC = '期权账户' 
		                    AND  (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ = '10399')
					        THEN a.INCM_AMT
						    WHEN  a.SYS_SRC = '期权账户' 
		                    AND  (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ = '10499')
					        THEN 0-a.PAY_AMT
						    ELSE 0
				            END,2)
			   ) as WRNT_NET_TFR_IN_AMT                 --期权账户净转入资金
          ,SUM(ROUND(CASE WHEN  b.BZDM IS NOT NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ = '10399')
				           THEN a.INCM_AMT*b.ZHHL
				           WHEN  b.BZDM IS  NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ = '10399')
					       THEN a.INCM_AMT
						   WHEN  b.BZDM IS NOT NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ = '10499')
				           THEN 0-a.PAY_AMT*b.ZHHL
				           WHEN b.BZDM IS  NULL
						   AND (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ = '10499')
					       THEN 0-a.PAY_AMT
						   ELSE 0
				           END,2)
			   )  as NET_TFR_IN_AMT                      --净转入资金
   FROM    DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS   a
   LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH              b
   ON             a.CCY_CD = b.BZDM
   AND            b.BUS_DATE = %d{yyyyMMdd}
   WHERE          a.BUS_DATE = %d{yyyyMMdd}
   GROUP BY       a.CUST_NO
   ; 
--------------当日市值临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP3 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP3
 as SELECT  a.CUST_NO
            ,SUM(CASE WHEN c.SEC_CL_CD = '001'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				)   as MKTVAL_HA                           --市值_沪A主板
			,SUM(CASE WHEN c.SEC_CL_CD = '001'
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				)  as ORDI_MKTVAL_HA                      --普通账户市值_沪A主板
			,SUM(CASE WHEN c.SEC_CL_CD = '001'
			          AND  a.SYS_SRC = '信用账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_HA                       --信用账户市值_沪A主板
			,SUM(CASE WHEN c.SEC_CL_CD = '002'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as MKTVAL_SA                           --市值_深A主板
			,SUM(CASE WHEN c.SEC_CL_CD = '002'
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_SA                      --普通账户市值_深A主板
			,SUM(CASE WHEN c.SEC_CL_CD = '002'
			          AND  a.SYS_SRC = '信用账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_SA                       --信用账户市值_深A主板
			,SUM(CASE WHEN c.SEC_CL_CD = '003'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as MKTVAL_SMS                          --市值_中小板
			,SUM(CASE WHEN c.SEC_CL_CD = '003'
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_SMS                     --普通账户市值_中小板
			,SUM(CASE WHEN c.SEC_CL_CD = '003'
			          AND  a.SYS_SRC = '信用账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_SMS                      --信用账户市值_中小板
			,SUM(CASE WHEN c.SEC_CL_CD = '004'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as MKTVAL_GEM                          --市值_创业板
			,SUM(CASE WHEN c.SEC_CL_CD = '004'
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_GEM                     --普通账户市值_创业板
			,SUM(CASE WHEN c.SEC_CL_CD = '004'
			          AND  a.SYS_SRC = '信用账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_GEM                      --信用账户市值_创业板
			,SUM(CASE WHEN c.SEC_CL_CD = '005'
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_HB_USD                  --普通账户市值_沪B_美元
			,SUM(CASE WHEN c.SEC_CL_CD = '063'
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_SB_HKD                  --普通账户市值_深B_港币
			,SUM(ROUND(CASE WHEN c.SEC_CL_CD = '015'
			                AND  b.BZDM IS NOT NULL
			                AND  a.SYS_SRC = '普通账户'
			                THEN a.SEC_MKTVAL*b.ZHHL
					        ELSE 0
					        END,2
					   ) 
				)  as ORDI_MKTVAL_HK                  --普通账户市值
			,SUM(ROUND(CASE WHEN c.SEC_CL_CD = '016'
			                AND  b.BZDM IS NOT NULL
			                AND  a.SYS_SRC = '普通账户'
			                THEN a.SEC_MKTVAL*b.ZHHL
					        ELSE 0
					        END,2
					  ) 
				) as ORDI_MKTVAL_SK                  --普通账户市值
			,SUM(CASE WHEN c.SEC_CL_CD IN ('006','008')
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				)  as ORDI_MKTVAL_TA                      --普通账户市值_三板A股
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('007')
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				)  as ORDI_MKTVAL_TU_USD                  --普通账户市值_三板B股_美元
           ,SUM(CASE WHEN c.SEC_CL_CD IN ('013','014','012','011','009','010')
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_REPO                    --普通账户市值_回购
            ,SUM(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_EXG_FND                 --普通账户市值_场内基金
			,SUM(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
			          AND  a.SYS_SRC = '普通账户'
					  AND  a.EXG = 'SH'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_EXG_FND_SH                 --普通账户市值_场内基金_沪市
			,SUM(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
			          AND  a.SYS_SRC = '普通账户'
					  AND  a.EXG = 'SZ'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_EXG_FND_SZ                 --普通账户市值_场内基金_深市
			,SUM(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
			          AND  a.SYS_SRC = '信用账户'
					  AND  a.EXG = 'SH'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_EXG_FND_SH                 --信用账户市值_场内基金_沪市
			,SUM(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
			          AND  a.SYS_SRC = '信用账户'
					  AND  a.EXG = 'SZ'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_EXG_FND_SZ                 --信用账户市值_场内基金_深市
            ,SUM(CASE WHEN c.SEC_CL_CD IN ('054','059')
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_CLS_FND                 --普通账户市值_封闭式基金
            ,SUM(CASE WHEN c.SEC_CL_CD IN ('057','061')
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_ETF_FND                 --普通账户市值_ETF
            ,SUM(CASE WHEN c.SEC_CL_CD IN ('055','060','062')
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_OPN_FND                 --普通账户市值_开放式
            ,SUM(CASE WHEN c.SEC_CL_CD IN ('056')
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_LOF_FND                 --普通账户市值_LOF
            ,SUM(CASE WHEN c.SEC_CL_CD IN ('058')
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_FOF_FND                 --普通账户市值_FOF
            ,SUM(CASE WHEN c.SEC_CL_CD IN ('060','062','061','058','055','054','056','057','059')
			          AND  a.SYS_SRC = '信用账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_EXG_FND                  --信用账户市值_场内基金
            ,SUM(CASE WHEN c.SEC_CL_CD IN ('054','059')
			          AND  a.SYS_SRC = '信用账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_CLS_FND                  --信用账户市值_封闭式基金
            ,SUM(CASE WHEN c.SEC_CL_CD IN ('057','061')
			          AND  a.SYS_SRC = '信用账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_ETF_FND                  --信用账户市值_ETF
            ,SUM(CASE WHEN c.SEC_CL_CD IN ('055','060','062')
			          AND  a.SYS_SRC = '信用账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_OPN_FND                  --信用账户市值_开放式
            ,SUM(CASE WHEN c.SEC_CL_CD IN ('056')
			          AND  a.SYS_SRC = '信用账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_LOF_FND                  --信用账户市值_LOF
            ,SUM(CASE WHEN c.SEC_CL_CD IN ('058')
			          AND  a.SYS_SRC = '信用账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_FOF_FND                  --信用账户市值_FOF
            ,SUM(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
			          AND  a.SYS_SRC = '普通账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_BOND                    --普通账户市值_债券
			
			,SUM(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
			          AND  a.SYS_SRC = '普通账户'
					  AND  a.EXG = 'SH'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_BOND_SH                    --普通账户市值_债券_沪市
				,SUM(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
			          AND  a.SYS_SRC = '普通账户'
					  AND  a.EXG = 'SZ'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as ORDI_MKTVAL_BOND_SZ                    --普通账户市值_债券_深市
			,SUM(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
			          AND  a.SYS_SRC = '信用账户'
					  AND  a.EXG = 'SH'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_BOND_SH                    --信用账户市值_债券_沪市
				,SUM(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
			          AND  a.SYS_SRC = '信用账户'
					  AND  a.EXG = 'SZ'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_BOND_SZ                    --信用账户市值_债券_深市
            ,SUM(CASE WHEN c.SEC_CL_CD BETWEEN '017' AND '053'
			          AND  a.SYS_SRC = '信用账户'
			          THEN a.SEC_MKTVAL
					  ELSE 0
					  END 
				) as CRD_MKTVAL_BOND                     --信用账户市值_债券
		   ,SUM(CASE WHEN a.SYS_SRC = '普通账户'
		             AND  CCY_CD = 'USD'
			         THEN a.SEC_MKTVAL
					 ELSE 0
					 END 
				) as ORDI_MKTVAL_SEC_USD                 --普通账户证券市值_美元
         ,SUM(CASE WHEN a.SYS_SRC = '普通账户'
		             AND  a.CCY_CD = 'HKD'
					 AND  c.SEC_CL_CD NOT IN ('015','016')
			         THEN a.SEC_MKTVAL
					 ELSE 0
					 END 
				) as ORDI_MKTVAL_SEC_HKD                 --普通账户证券市值_港币
         ,SUM(ROUND(CASE WHEN c.SEC_CL_CD IN ('015','016')
			             AND  b.BZDM IS NOT NULL
			             AND  a.SYS_SRC = '普通账户'
			             THEN a.SEC_MKTVAL*b.ZHHL
				         WHEN a.CCY_CD = 'RMB'
				         AND  a.SYS_SRC = '普通账户'
				         THEN a.SEC_MKTVAL
				         ELSE 0
					     END,2) 
				) as ORDI_MKTVAL_SEC_RMD                 --普通账户证券市值_人民币 
         ,SUM(ROUND(CASE WHEN  b.BZDM IS NOT NULL
			             AND  a.SYS_SRC = '普通账户'
			             THEN a.SEC_MKTVAL*b.ZHHL
				         WHEN b.BZDM IS  NULL
				         AND  a.SYS_SRC = '普通账户'
				         THEN a.SEC_MKTVAL
				         ELSE 0
					     END,2) 
				)  as ORDI_SEC_MKTVAL                     --普通账户证券市值(折算人民币)
         ,SUM(ROUND(CASE WHEN  b.BZDM IS NOT NULL
			             AND  a.SYS_SRC = '普通账户'
			             THEN a.UN_CIR_SEC_MKTVAL*b.ZHHL
				         WHEN b.BZDM IS  NULL
				         AND  a.SYS_SRC = '普通账户'
				         THEN a.UN_CIR_SEC_MKTVAL
				         ELSE 0
					     END,2) 
				) as ORDI_UN_CIR_MKTVAL                  --普通账户非流通市值(折算人民币)
		 ,SUM(ROUND(CASE WHEN  b.BZDM IS NOT NULL
			             AND  a.SYS_SRC = '普通账户'
						 AND  a.EXG = 'SH'
			             THEN a.UN_CIR_SEC_MKTVAL*b.ZHHL
				         WHEN b.BZDM IS  NULL
				         AND  a.SYS_SRC = '普通账户'
						 AND  a.EXG = 'SH'
				         THEN a.UN_CIR_SEC_MKTVAL
				         ELSE 0
					     END,2) 
				) as ORDI_UN_CIR_MKTVAL_SH                  --普通账户沪市非流通市值(折算人民币)
		,SUM(ROUND(CASE WHEN  b.BZDM IS NOT NULL
			             AND  a.SYS_SRC = '普通账户'
						 AND  a.EXG = 'SZ'
			             THEN a.UN_CIR_SEC_MKTVAL*b.ZHHL
				         WHEN b.BZDM IS  NULL
				         AND  a.SYS_SRC = '普通账户'
						 AND  a.EXG = 'SZ'
				         THEN a.UN_CIR_SEC_MKTVAL
				         ELSE 0
					     END,2) 
				) as ORDI_UN_CIR_MKTVAL_SZ                  --普通账户深市非流通市值(折算人民币)
         ,SUM(ROUND(CASE WHEN  b.BZDM IS NOT NULL
			             AND  a.SYS_SRC = '信用账户'
			             THEN a.SEC_MKTVAL*b.ZHHL
				         WHEN a.CCY_CD = 'RMB'
				         AND  a.SYS_SRC = '信用账户'
				         THEN a.SEC_MKTVAL
				         ELSE 0
					     END,2) 
				)   as CRD_SEC_MKTVAL                      --信用账户证券市值	
      
	  ,SUM(ROUND(CASE    WHEN    a.SYS_SRC = '普通账户'
						 AND  a.EXG = 'TA'
						 AND  SUBSTR(a.SEC_CD,1,2) IN ('43','83','87')
			             THEN a.SEC_MKTVAL
				         ELSE 0
					     END,2) 
				) as ORDI_MKTVAL_NEW_TA                      --普通账户市值_新三板A股
     ,SUM(CASE WHEN  a.SYS_SRC = '普通账户'
						 AND  c.SEC_CL_CD IN ('012')						
			             THEN a.SEC_MKTVAL
				         ELSE 0
					     END
		  )  as ORDI_MKTVAL_AK_STIB                      --普通账户市值_AK科创板
	      ,SUM(CASE WHEN  a.SYS_SRC = '普通账户'
						 AND  c.SEC_CL_CD IN ('013')						
			             THEN a.SEC_MKTVAL
				         ELSE 0
					     END
		  )  as ORDI_MKTVAL_RK_STIB                      --普通账户市值_RK科创CDR
	   ,SUM(CASE WHEN  a.SYS_SRC = '信用账户'
						 AND  c.SEC_CL_CD IN ('012')						
			             THEN a.SEC_MKTVAL
				         ELSE 0
					     END
		  )  as CRD_MKTVAL_AK_STIB                      --信用账户市值_AK科创板
	      ,SUM(CASE WHEN  a.SYS_SRC = '信用账户'
						 AND  c.SEC_CL_CD IN ('013')						
			             THEN a.SEC_MKTVAL
				         ELSE 0
					     END
		  )  as CRD_MKTVAL_RK_STIB                      --信用账户市值_RK科创CDR			
    FROM  DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS  a
	LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH                             b
    ON             a.CCY_CD = b.BZDM
    AND            b.BUS_DATE = %d{yyyyMMdd}
    LEFT JOIN    (SELECT DISTINCT EXG,SEC_CD_PFX,SEC_CGY_PFX,SEC_CL_CD FROM DDW_PROD.T_DDW_CFG_SEC_TRD_CL   )                    c
    ON             a.EXG = c.EXG
    AND            SUBSTR(a.SEC_CD,1,3) = c.SEC_CD_PFX
    AND            (SUBSTR(a.SEC_CGY,1,1) = c.SEC_CGY_PFX
    OR             SUBSTR(a.SEC_CGY,1,3) = c.SEC_CGY_PFX)
    WHERE         a.BUS_DATE = %d{yyyyMMdd}
    GROUP BY  a.CUST_NO ;   
   --------------当日产品市值临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP4 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP4
 as SELECT  a.CUST_NO
           ,SUM(CASE WHEN a.PROD_CGY = 8
				     AND  SUBSTR(PROD_CD,1,1) < > 'A'
				     AND  SUBSTR(PROD_CD,1,2) < > '95'
		             THEN a.PROD_NEWST_MKTVAL 
				     ELSE 0
			         END
		       ) as AGN_FND_MKTVAL                      --代销基金市值	
           ,SUM(CASE WHEN a.PROD_CGY = 8
				     AND  SUBSTR(PROD_CD,1,1) = 'A'
		             THEN a.PROD_NEWST_MKTVAL 
				     ELSE 0
			         END
		       )  as GS_PROD_MKTVAL                      --公司产品市值
           ,SUM(CASE WHEN a.PROD_CGY = 8
				     AND  SUBSTR(PROD_CD,1,2) = '95'
		             THEN a.PROD_NEWST_MKTVAL 
				     ELSE 0
			         END
		       ) as GJ_PROD_MKTVAL                      --国君产品市值	
           ,SUM(CASE WHEN a.PROD_CGY = 9
		             THEN a.PROD_NEWST_MKTVAL 
				     ELSE 0
			         END
		       )   as BANK_PROD_MKTVAL                    --银行产品市值
		   ,SUM(CASE WHEN a.PROD_CGY = 11
		             THEN a.PROD_NEWST_MKTVAL 
				     ELSE 0
			         END
		       )   as OTC_PROD_MKTVAL                    --OTC产品市值
           ,SUM(a.PROD_NEWST_MKTVAL)  as ORDI_MKTVAL_PROD                    --普通账户产品市值	
           ,SUM(CASE WHEN b.JJDM IS NOT NULL
		             THEN a.PROD_NEWST_MKTVAL 
				     ELSE 0
			         END
		       )   as ORDI_EXG_MKTVAL_PROD                   --普通账户场内产品市值	
		   
    FROM  DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS  a
	LEFT JOIN    EDW_PROD.T_EDW_T04_TOF_JJXX      b
	ON           a.PROD_CD = b.JJDM
	AND          a.PROD_CGY = 8
	AND          b.BUS_DATE = %d{yyyyMMdd}
	AND          b.TADM IN ('98','99')
    WHERE         a.BUS_DATE = %d{yyyyMMdd}
    GROUP BY  a.CUST_NO ; 
----当日期权市值临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP5 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP5
 as SELECT  a.CUST_NO
           ,SUM(DECODE(a.WRNT_BS_DRCT,'1',a.WRNT_NEWST_MKTVAL,0))  as WRNT_RGHT_HLD_MKTVAL                --期权账户权利仓市值
           ,SUM(DECODE(a.WRNT_BS_DRCT,'2',0-a.WRNT_NEWST_MKTVAL,0)) as WRNT_DUTY_HLD_MKTVAL                --期权账户义务仓市值
           ,SUM(a.WRNT_NEWST_MKTVAL)                               as WRNT_MKTVAL                         --期权账户市值(权利仓市值-义务仓市值)	
           ,SUM(a.WRNT_CTC_QTY)	                                   as WRNT_CNTS                           --期权张数	   
           ,SUM(CASE WHEN a.EXG = 'SH'
		             AND  a.WRNT_BS_DRCT = '1'
				     THEN a.WRNT_NEWST_MKTVAL
				     ELSE 0
				     END
				) as WRNT_RGHT_HLD_MKTVAL_SH                --期权账户权利仓市值(SH)
		   ,SUM(CASE WHEN a.EXG = 'SH'
		             AND  a.WRNT_BS_DRCT = '2'
				     THEN 0-a.WRNT_NEWST_MKTVAL
				     ELSE 0
				     END
				)  as WRNT_DUTY_HLD_MKTVAL_SH                --期权账户义务仓市值(SH)      
           ,SUM(CASE WHEN a.EXG = 'SH'
		             THEN a.WRNT_NEWST_MKTVAL
				     ELSE 0
				     END
				) as WRNT_MKTVAL_SH                         --期权账户市值(权利仓市值-义务仓市值)(SH)	
           ,SUM(CASE WHEN a.EXG = 'SH'
		             THEN a.WRNT_CTC_QTY
				     ELSE 0
				     END
				)  as WRNT_CNTS_SH                           --期权张数(SH)
		    ,SUM(CASE WHEN a.EXG = 'SZ'
		             AND  a.WRNT_BS_DRCT = '1'
				     THEN a.WRNT_NEWST_MKTVAL
				     ELSE 0
				     END
				) as WRNT_RGHT_HLD_MKTVAL_SZ               --期权账户权利仓市值(SZ)
		   ,SUM(CASE WHEN a.EXG = 'SZ'
		             AND  a.WRNT_BS_DRCT = '2'
				     THEN 0-a.WRNT_NEWST_MKTVAL
				     ELSE 0
				     END
				)  as WRNT_DUTY_HLD_MKTVAL_SZ              --期权账户义务仓市值(SZ)      
           ,SUM(CASE WHEN a.EXG = 'SZ'
		             THEN a.WRNT_NEWST_MKTVAL
				     ELSE 0
				     END
				) as WRNT_MKTVAL_SZ                         --期权账户市值(权利仓市值-义务仓市值)(SZ)	
           ,SUM(CASE WHEN a.EXG = 'SZ'
		             THEN a.WRNT_CTC_QTY
				     ELSE 0
				     END
				)  as WRNT_CNTS_SZ                           --期权张数(SZ)
	
	FROM  DDW_PROD.T_DDW_F00_AST_WRNT_HLD_DTL_HIS  a
    WHERE         a.BUS_DATE = %d{yyyyMMdd}
    GROUP BY  a.CUST_NO ;	
	
	--------------当日证券交割临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP6 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP6
 as SELECT  a.CUST_NO
            ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		              AND a.ODR_CGY = 9
			          AND a.CCY_CD = 'RMB'					 
					  AND a.EXG IN ('SH','HK')
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 )    as ORDI_ASGN_TFR_IN_MKTVAL_RMB         --普通账户指定转入市值_人民币
          ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		              AND a.ODR_CGY = 9
					  AND a.EXG IN ('HB')
			          AND a.CCY_CD = 'USD'
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 ) as ORDI_ASGN_TFR_IN_MKTVAL_USD         --普通账户指定转入市值_美元
--         ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
--		              AND a.ODR_CGY = 9
--			          AND a.CCY_CD = 'HKD'
--			          THEN a.MTCH_AMT
--			          ELSE 0
--			          END
--				 ) as ORDI_ASGN_TFR_IN_MKTVAL_HKD         --普通账户指定转入市值_港币
         ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		              AND a.ODR_CGY = 15
			          AND a.CCY_CD = 'RMB'
					  AND a.EXG IN ('SZ','SK','TA')
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 ) as ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB     --普通账户转托管转入市值_人民币
--         ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
--		              AND a.ODR_CGY = 15
--			          AND a.CCY_CD = 'USD'
--			          THEN a.MTCH_AMT
--			          ELSE 0
--			          END
--				 ) as ORDI_TFR_CSTD_TFR_IN_MKTVAL_USD     --普通账户转托管转入市值_美元
         ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		              AND a.ODR_CGY = 15
					  AND  a.EXG IN ('SB')
			          AND a.CCY_CD = 'HKD'
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 ) as ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD     --普通账户转托管转入市值_港币
         ,SUM(CASE WHEN a.SYS_SRC = '信用账户' 
		              AND a.ODR_CGY = 9
			          AND a.CCY_CD = 'RMB'
					  AND a.EXG IN ('SH')
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 ) as CRD_ASGN_TFR_IN_MKTVAL          --信用账户指定转入市值	
         ,SUM(CASE WHEN a.SYS_SRC = '信用账户' 
		              AND a.ODR_CGY = 15
			          AND a.CCY_CD = 'RMB'
					  AND a.EXG IN ('SZ')
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 )    as CRD_TFR_CSTD_TFR_IN_MKTVAL      --信用账户转托管转入市值
         ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		              AND a.ODR_CGY = 10
					  AND a.EXG IN ('SH','HK')
			          AND a.CCY_CD = 'RMB'
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 ) as ORDI_ASGN_TFR_OUT_MKTVAL_RMB        --普通账户撤指定转出市值_人民币
         ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		              AND a.ODR_CGY = 10
			          AND a.CCY_CD = 'USD'
					  AND a.EXG IN ('HB')
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 ) as ORDI_ASGN_TFR_OUT_MKTVAL_USD        --普通账户撤指定转出市值_美元
--         ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
--		              AND a.ODR_CGY = 10
--			          AND a.CCY_CD = 'HKD'
--			          THEN a.MTCH_AMT
--			          ELSE 0
--			          END
--				 ) as ORDI_ASGN_TFR_OUT_MKTVAL_HKD        --普通账户撤指定转出市值_港币
         ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		              AND a.ODR_CGY = 7
			          AND a.CCY_CD = 'RMB'
					  AND a.EXG IN ('SZ','SK','TA')
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 ) as ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB    --普通账户转托管转出市值_人民币
--         ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
--		              AND a.ODR_CGY = 7
--			          AND a.CCY_CD = 'USD'
--			          THEN a.MTCH_AMT
--			          ELSE 0
--			          END
--				 ) as ORDI_TFR_CSTD_TFR_OUT_MKTVAL_USD    --普通账户转托管转出市值_美元
         ,SUM(CASE WHEN a.SYS_SRC = '普通账户' 
		              AND a.ODR_CGY = 7
					  AND a.EXG IN ('SB')
			          AND a.CCY_CD = 'HKD'
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 ) as ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD    --普通账户转托管转出市值_港币
         ,SUM(CASE WHEN a.SYS_SRC = '信用账户' 
		              AND a.ODR_CGY = 10
			          AND a.CCY_CD = 'RMB'
					  AND a.EXG IN ('SH')
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 ) as CRD_ASGN_TFR_OUT_MKTVAL         --信用账户指定转出市值		
         ,SUM(CASE WHEN a.SYS_SRC = '信用账户' 
		              AND a.ODR_CGY = 7
			          AND a.CCY_CD = 'RMB'
					  AND a.EXG IN ('SZ')
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 ) as CRD_TFR_CSTD_TFR_OUT_MKTVAL     --信用账户转托管转出市值
         ,SUM(ROUND(CASE WHEN a.SYS_SRC = '普通账户' 
		                 AND a.ODR_CGY IN (9,15,4444,6666,8888)
					     AND b.BZDM  IS NOT NULL
			             THEN a.MTCH_AMT*b.ZHHL
						 WHEN a.SYS_SRC = '普通账户' 
		                 AND a.ODR_CGY IN (9,15,4444,6666,8888)
					     AND b.BZDM  IS  NULL
			             THEN a.MTCH_AMT
			             ELSE 0
			             END,2)
				 ) as ORDI_TFR_IN_MKTVAL                  --普通账户转入市值
         ,SUM(ROUND(CASE WHEN a.SYS_SRC = '信用账户' 
		                 AND a.ODR_CGY IN (7,10,5555,7777,9999)
					     AND b.BZDM  IS NOT NULL
			             THEN a.MTCH_AMT*b.ZHHL
						 WHEN a.SYS_SRC = '信用账户' 
		                 AND a.ODR_CGY IN (7,10,5555,7777,9999)
					     AND b.BZDM  IS  NULL
			             THEN a.MTCH_AMT
			             ELSE 0
			             END,2)
				 ) as ORDI_TFR_OUT_MKTVAL                 --普通账户转出市值
         ,SUM(CASE WHEN a.SYS_SRC = '信用账户' 
		              AND a.ODR_CGY IN (9,15,4444,6666,8888)
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 ) as CRD_TFR_IN_MKTVAL                   --信用账户转入市值
         ,SUM(CASE WHEN a.SYS_SRC = '信用账户' 
		              AND a.ODR_CGY IN (7,10,5555,7777,9999)
			          THEN a.MTCH_AMT
			          ELSE 0
			          END
				 ) as CRD_TFR_OUT_MKTVAL                  --信用账户转出市值
         ,SUM(ROUND(CASE WHEN  a.ODR_CGY IN (9,15,4444,6666,8888)
					     AND b.BZDM IS NOT NULL
			             THEN a.MTCH_AMT*b.ZHHL
						 WHEN a.ODR_CGY IN (9,15,4444,6666,8888)
					     AND b.BZDM  IS  NULL
			             THEN a.MTCH_AMT
			             ELSE 0
			             END,2)
				 ) as TFR_IN_MKTVAL                       --转入市值
         ,SUM(ROUND(CASE WHEN  a.ODR_CGY IN (7,10,5555,7777,9999)
					     AND b.BZDM IS NOT NULL
			             THEN a.MTCH_AMT*b.ZHHL
						 WHEN a.ODR_CGY IN (7,10,5555,7777,9999)
					     AND b.BZDM IS  NULL
			             THEN a.MTCH_AMT
			             ELSE 0
			             END,2)
				 ) as TFR_OUT_MKTVAL                      --转出市值
         ,SUM(ROUND(CASE WHEN  a.ODR_CGY IN (9,15,4444,6666,8888)
					     AND   b.BZDM IS NOT NULL
						 AND   a.SYS_SRC = '普通账户' 
			             THEN a.MTCH_AMT*b.ZHHL
						 WHEN a.ODR_CGY IN (9,15,4444,6666,8888)
					     AND  b.BZDM IS  NULL
						 AND  a.SYS_SRC = '普通账户'
			             THEN a.MTCH_AMT
						 WHEN  a.ODR_CGY IN (7,10,5555,7777,9999)
					     AND   b.BZDM IS NOT NULL
						 AND   a.SYS_SRC = '普通账户' 
			             THEN 0-a.MTCH_AMT*b.ZHHL
						 WHEN a.ODR_CGY IN (7,10,5555,7777,9999)
					     AND  b.BZDM IS  NULL
						 AND  a.SYS_SRC = '普通账户'
			             THEN 0-a.MTCH_AMT
			             ELSE 0
			             END,2)
				 ) as ORDI_NET_TFR_IN_MKTVAL              --普通账户净转入市值
         ,SUM(ROUND(CASE WHEN  a.ODR_CGY IN (9,15,4444,6666,8888)
					     AND   b.BZDM IS NOT NULL
						 AND   a.SYS_SRC = '信用账户' 
			             THEN a.MTCH_AMT*b.ZHHL
						 WHEN a.ODR_CGY IN (9,15,4444,6666,8888)
					     AND  b.BZDM IS  NULL
						 AND  a.SYS_SRC = '信用账户'
			             THEN a.MTCH_AMT
						 WHEN  a.ODR_CGY IN (7,10,5555,7777,9999)
					     AND   b.BZDM IS NOT NULL
						 AND   a.SYS_SRC = '信用账户' 
			             THEN 0-a.MTCH_AMT*b.ZHHL
						 WHEN a.ODR_CGY IN (7,10,5555,7777,9999)
					     AND  b.BZDM IS  NULL
						 AND  a.SYS_SRC = '信用账户'
			             THEN 0-a.MTCH_AMT
			             ELSE 0
			             END,2)
				 ) as CRD_NET_TFR_IN_MKTVAL               --信用账户净转入市值
          ,SUM(ROUND(CASE WHEN  a.ODR_CGY IN (9,15,4444,6666,8888)
					     AND   b.BZDM IS NOT NULL 
			             THEN a.MTCH_AMT*b.ZHHL
						 WHEN a.ODR_CGY IN (9,15,4444,6666,8888)
					     AND  b.BZDM IS  NULL
			             THEN a.MTCH_AMT
						 WHEN  a.ODR_CGY IN (7,10,5555,7777,9999)
					     AND   b.BZDM IS NOT NULL						 
			             THEN 0-a.MTCH_AMT*b.ZHHL
						 WHEN a.ODR_CGY IN (7,10,5555,7777,9999)
					     AND  b.BZDM IS  NULL						
			             THEN 0-a.MTCH_AMT
			             ELSE 0
			             END,2)
				 ) as NET_TFR_IN_MKTVAL                   --净转入市值		
    FROM      (SELECT * 
	           FROM     DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS  
			   WHERE    BUS_DATE = %d{yyyyMMdd}
			   AND      ODR_CGY IN (9,15,4444,6666,8888,7,10,5555,7777,9999)
			   )		       a	
    LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH                             b
    ON             a.CCY_CD = b.BZDM
	AND            a.BUS_DATE = b.BUS_DATE 
	GROUP BY CUST_NO ;
	
----当日产品转入转出临时表	
	 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP7 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP7
 as SELECT  a.CUST_NO
           ,SUM(CASE WHEN a.PROD_BIZ_CD IN ('6666','8888')
		             THEN a.CNFM_AMT
				     ELSE 0
				     END
			    )  as ORDI_TFR_IN_MKTVAL                  --普通账户转入市值
          ,SUM(CASE WHEN a.PROD_BIZ_CD IN ('7777','9999')
		             THEN a.CNFM_AMT
				     ELSE 0
				     END
			   ) as ORDI_TFR_OUT_MKTVAL                 --普通账户转出市值        
          ,SUM(CASE WHEN a.PROD_BIZ_CD IN ('6666','8888')
		             THEN a.CNFM_AMT
				     ELSE 0
				     END
			    ) as TFR_IN_MKTVAL                       --转入市值
          ,SUM(CASE WHEN a.PROD_BIZ_CD IN ('7777','9999')
		             THEN a.CNFM_AMT
				     ELSE 0
				     END
			   ) as TFR_OUT_MKTVAL                      --转出市值
          ,SUM(CASE WHEN a.PROD_BIZ_CD IN ('6666','8888')
		             THEN a.CNFM_AMT
					 WHEN a.PROD_BIZ_CD IN ('7777','9999')
		             THEN 0-a.CNFM_AMT
				     ELSE 0
				     END
			    ) as ORDI_NET_TFR_IN_MKTVAL              --普通账户净转入市值        
          ,SUM(CASE WHEN a.PROD_BIZ_CD IN ('6666','8888')
		             THEN a.CNFM_AMT
					 WHEN a.PROD_BIZ_CD IN ('7777','9999')
		             THEN 0-a.CNFM_AMT
				     ELSE 0
				     END
			    ) as NET_TFR_IN_MKTVAL                   --净转入市值		
    FROM        DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS   a
	WHERE    a.BUS_DATE = %d{yyyyMMdd}
	AND      a.PROD_BIZ_CD IN ('6666','8888','7777','9999')	
	GROUP BY a.CUST_NO ;
--普通账户负债临时表	
	 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP8;
 CREATE TABLE  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP8 as
 SELECT   t.CUST_NO
          ,SUM(ORDI_ACCT_GL_PRINP) as ORDI_GL
		  ,SUM(DECODE(CL,'股票质押',ORDI_ACCT_GL_PRINP,0))     as STK_PLG_AMT     --股票质押余额
		  ,SUM(DECODE(CL,'股票质押',ORDI_ACCT_GL_ADD_PRINP,0)) as STK_PLG_ADD_INT --股票质押新增利息
		  ,SUM(DECODE(CL,'股票质押',MTCH_AMT,0))               as STK_PLG_ADD_TRD_AMT --股票质押初始交易量
		  ,SUM(DECODE(CL,'小微贷',ORDI_ACCT_GL_PRINP,0))       as MIN_STK_PLG_AMT     --小微贷余额
		  ,SUM(DECODE(CL,'小微贷',ORDI_ACCT_GL_ADD_PRINP,0))   as MIN_STK_PLG_ADD_INT --小微贷新增利息
		  ,SUM(DECODE(CL,'小微贷',MTCH_AMT,0))                 as MIN_STK_PLG_ADD_TRD_AMT --小微贷初始交易量
 FROM     DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS     t
 WHERE   t.BUS_DATE = %d{yyyyMMdd} 
 GROUP BY t.CUST_NO; 
------信用账户负债 临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP9;
 CREATE TABLE  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP9 as
 SELECT SUM(CRD_ACCT_UN_GL_PRINP+CRD_ACCT_UN_PAY_GL_INT) as CRD_GL
		,CUST_NO 
 FROM    DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS			
 WHERE     BUS_DATE = %d{yyyyMMdd}
 GROUP BY  CUST_NO ;
 ---昨日数据
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP10 ;
CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP10
as SELECT  a.CUST_NO           
          ,SUM(ROUND(CASE WHEN a.SYS_SRC = '普通账户' 
		                  AND b.BZDM IS NOT NULL
				          THEN (a.ACCNT_BAL+a.UNPY_AMT)*b.ZHHL
				          WHEN a.SYS_SRC = '普通账户' 
		                  AND b.BZDM IS  NULL
					      THEN a.ACCNT_BAL+a.UNPY_AMT
						  ELSE 0
				          END,2)
			   )              as ORDI_CPTL_Y                           --普通账户资金(折算人民币)
          
          ,SUM(ROUND(CASE WHEN a.SYS_SRC = '信用账户' 		                  
				          THEN (a.ACCNT_BAL+a.UNPY_AMT)
				          ELSE 0
				          END,2)
			   )      as CRD_CPTL_Y                            --信用账户资金
          ,SUM(ROUND(CASE WHEN a.SYS_SRC = '期权账户' 		                  
				          THEN (a.ACCNT_BAL+a.UNPY_AMT)
				          ELSE 0
				          END,2)
			   )   as WRNT_CPTL_Y                           --期权账户资金
          ,SUM(ROUND(CASE WHEN b.BZDM IS NOT NULL
				          THEN (a.ACCNT_BAL+a.UNPY_AMT)*b.ZHHL
						  WHEN b.BZDM IS  NULL
						  THEN (a.ACCNT_BAL+a.UNPY_AMT)
				          ELSE 0
				          END,2)
			   )    as TOT_CPTL_Y                            --总资金  
   FROM           DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS  a
   LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH              b
   ON             a.CCY_CD = b.BZDM
   AND            a.BUS_DATE = b.BUS_DATE
   WHERE    EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
	               WHERE  c.BUS_DATE = %d{yyyyMMdd}
				   AND    c.TRD_DT = %d{yyyyMMdd}
				   AND    a.BUS_DATE = c.LST_TRD_D
	              )
   GROUP BY       a.CUST_NO
   ; 
   --
    DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP11 ;
CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP11
as SELECT  a.CUST_NO           
          ,SUM(ROUND(CASE WHEN a.SYS_SRC = '普通账户' 
		                  AND b.BZDM IS NOT NULL
				          THEN a.SEC_MKTVAL*b.ZHHL
				          WHEN a.SYS_SRC = '普通账户' 
		                  AND b.BZDM IS  NULL
					      THEN a.SEC_MKTVAL
						  ELSE 0
				          END,2)
			   )              as ORDI_MKTVAL_Y                           --普通账户市值          
          ,SUM(ROUND(CASE WHEN a.SYS_SRC = '信用账户' 		                  
				          THEN a.SEC_MKTVAL
				          ELSE 0
				          END,2)
			   )      as CRD_MKTVAL_Y                            --信用账户市值          
          ,SUM(ROUND(CASE WHEN b.BZDM IS NOT NULL
				          THEN a.SEC_MKTVAL*b.ZHHL
						  WHEN b.BZDM IS  NULL
						  THEN a.SEC_MKTVAL
				          ELSE 0
				          END,2)
			   )    as TOT_MKTVAL_Y                            --总市值  
   FROM           DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS  a
   LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH              b
   ON             a.CCY_CD = b.BZDM
   AND            a.BUS_DATE = b.BUS_DATE
   WHERE    EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
	               WHERE  c.BUS_DATE = %d{yyyyMMdd}
				   AND    c.TRD_DT = %d{yyyyMMdd}
				   AND    a.BUS_DATE = c.LST_TRD_D
	              )
   GROUP BY       a.CUST_NO
   ; 
   
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP12 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP12
 as SELECT  a.CUST_NO           
           ,SUM(a.PROD_NEWST_MKTVAL)  as ORDI_MKTVAL_Y                    --普通账户市值
           ,SUM(a.PROD_NEWST_MKTVAL)  as TOT_MKTVAL_Y                     --总市值		   
    FROM  DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS  a
    WHERE    EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
	               WHERE  c.BUS_DATE = %d{yyyyMMdd}
				   AND    c.TRD_DT = %d{yyyyMMdd}
				   AND    a.BUS_DATE = c.LST_TRD_D
	              )
    GROUP BY  a.CUST_NO ;


DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP13 ;
 CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP13
 as SELECT  a.CUST_NO
            ,SUM(a.WRNT_NEWST_MKTVAL)  as WRNT_MKTVAL_Y                      --期权账户市值(权利仓市值-义务仓市值)
            ,SUM(a.WRNT_NEWST_MKTVAL)  as TOT_MKTVAL_Y                     --总市值			
    FROM  DDW_PROD.T_DDW_F00_AST_WRNT_HLD_DTL_HIS  a
     WHERE    EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
	               WHERE  c.BUS_DATE = %d{yyyyMMdd}
				   AND    c.TRD_DT = %d{yyyyMMdd}
				   AND    a.BUS_DATE = c.LST_TRD_D
	              )
    GROUP BY  a.CUST_NO ;	

DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP14;
 CREATE TABLE  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP14 as
 SELECT   a.CUST_NO
          ,SUM(ORDI_ACCT_GL_PRINP) as ORDI_GL_Y
 FROM     DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS     a
 WHERE    EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
	               WHERE  c.BUS_DATE = %d{yyyyMMdd}
				   AND    c.TRD_DT = %d{yyyyMMdd}
				   AND    a.BUS_DATE = c.LST_TRD_D
	              )
 GROUP BY a.CUST_NO; 
------信用账户负债 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP15;
 CREATE TABLE  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP15 as
 SELECT SUM(a.CRD_ACCT_UN_GL_PRINP+a.CRD_ACCT_UN_PAY_GL_INT) as CRD_GL_Y
		 ,a.CUST_NO 
 FROM    DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS	a		
  WHERE    EXISTS(SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE c
	               WHERE  c.BUS_DATE = %d{yyyyMMdd}
				   AND    c.TRD_DT = %d{yyyyMMdd}
				   AND    a.BUS_DATE = c.LST_TRD_D
	              )
 GROUP BY  CUST_NO ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP1 ;
CREATE TABLE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP1
as SELECT 
    COALESCE(a.CUST_NO,b.CUST_NO,c.CUST_NO,d.CUST_NO,e.CUST_NO,f.CUST_NO) as CUST_NO
   ,NVL(a.ORDI_CPTL_Y,0)+NVL(b.ORDI_MKTVAL_Y,0)+NVL(c.ORDI_MKTVAL_Y,0)-NVL(e.ORDI_GL_Y,0) as ORDI_NET_AST_Y
   ,NVL(a.CRD_CPTL_Y,0)+NVL(b.CRD_MKTVAL_Y,0)-NVL(f.CRD_GL_Y,0) as CRD_NET_AST_Y
   ,NVL(a.WRNT_CPTL_Y,0)+NVL(d.WRNT_MKTVAL_Y,0) as WRNT_NET_AST_Y
   ,NVL(a.TOT_CPTL_Y,0)+NVL(b.TOT_MKTVAL_Y,0)+NVL(c.TOT_MKTVAL_Y,0)+NVL(d.TOT_MKTVAL_Y,0)-NVL(e.ORDI_GL_Y,0)-NVL(f.CRD_GL_Y,0) as TOT_NET_AST_Y
FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP10 a
FULL JOIN  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP11 b
ON  a.CUST_NO = b.CUST_NO
FULL JOIN  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP12 c
ON  COALESCE(a.CUST_NO,b.CUST_NO) = c.CUST_NO
FULL JOIN  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP13 d
ON  COALESCE(a.CUST_NO,b.CUST_NO,c.CUST_NO) = d.CUST_NO
FULL JOIN  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP14 e
ON  COALESCE(a.CUST_NO,b.CUST_NO,c.CUST_NO,d.CUST_NO) = e.CUST_NO
FULL JOIN  DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP15 f
ON  COALESCE(a.CUST_NO,b.CUST_NO,c.CUST_NO,d.CUST_NO,e.CUST_NO) = f.CUST_NO ;

	


------插入数据
  INSERT OVERWRITE DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
(         CUST_NO                             --客户号                 
         ,BRH_NO                              --营业部编号                         
         ,CUST_CGY		                      --客户类别
         ,MKTVAL_HA                           --市值_沪A主板
         ,ORDI_MKTVAL_HA                      --普通账户市值_沪A主板
         ,CRD_MKTVAL_HA                       --信用账户市值_沪A主板
         ,MKTVAL_SA                           --市值_深A主板
         ,ORDI_MKTVAL_SA                      --普通账户市值_深A主板
         ,CRD_MKTVAL_SA                       --信用账户市值_深A主板
         ,MKTVAL_SMS                          --市值_中小板
         ,ORDI_MKTVAL_SMS                     --普通账户市值_中小板
         ,CRD_MKTVAL_SMS                      --信用账户市值_中小板
         ,MKTVAL_GEM                          --市值_创业板
         ,ORDI_MKTVAL_GEM                     --普通账户市值_创业板
         ,CRD_MKTVAL_GEM                      --信用账户市值_创业板
         ,ORDI_MKTVAL_HB_USD                  --普通账户市值_沪B_美元
         ,ORDI_MKTVAL_SB_HKD                  --普通账户市值_深B_港币
         ,ORDI_MKTVAL_HK                      --普通账户市值_沪港通
         ,ORDI_MKTVAL_SK                      --普通账户市值_深港通
         ,ORDI_MKTVAL_TA                      --普通账户市值_三板A股
         ,ORDI_MKTVAL_TU_USD                  --普通账户市值_三板B股_美元
         ,ORDI_MKTVAL_REPO                    --普通账户市值_回购
         ,ORDI_MKTVAL_EXG_FND                 --普通账户市值_场内基金
         ,ORDI_MKTVAL_CLS_FND                 --普通账户市值_封闭式基金
         ,ORDI_MKTVAL_ETF_FND                 --普通账户市值_ETF
         ,ORDI_MKTVAL_OPN_FND                 --普通账户市值_开放式
         ,ORDI_MKTVAL_LOF_FND                 --普通账户市值_LOF
         ,ORDI_MKTVAL_FOF_FND                 --普通账户市值_FOF
         ,CRD_MKTVAL_EXG_FND                  --信用账户市值_场内基金
         ,CRD_MKTVAL_CLS_FND                  --信用账户市值_封闭式基金
         ,CRD_MKTVAL_ETF_FND                  --信用账户市值_ETF
         ,CRD_MKTVAL_OPN_FND                  --信用账户市值_开放式
         ,CRD_MKTVAL_LOF_FND                  --信用账户市值_LOF
         ,CRD_MKTVAL_FOF_FND                  --信用账户市值_FOF
         ,ORDI_MKTVAL_BOND                    --普通账户市值_债券
         ,CRD_MKTVAL_BOND                     --信用账户市值_债券
         ,AGN_FND_MKTVAL                      --代销基金市值		
         ,GS_PROD_MKTVAL                      --公司产品市值
         ,GJ_PROD_MKTVAL                      --国君产品市值		
         ,BANK_PROD_MKTVAL                    --银行产品市值
         ,OTC_PROD_MKTVAL                     --OTC产品市值	
         ,WRNT_RGHT_HLD_MKTVAL                --期权账户权利仓市值
         ,WRNT_DUTY_HLD_MKTVAL                --期权账户义务仓市值
         ,ORDI_MKTVAL_SEC_USD                 --普通账户证券市值_美元
         ,ORDI_MKTVAL_SEC_HKD                 --普通账户证券市值_港币
         ,ORDI_MKTVAL_SEC_RMD                 --普通账户证券市值_人民币
         ,ORDI_MKTVAL_PROD                    --普通账户产品市值	
         ,ORDI_CPTL_USD                       --普通账户资金_美元
         ,ORDI_CPTL_HKD                       --普通账户资金_港币
         ,ORDI_CPTL_RMB                       --普通账户资金_人民币		
         ,ORDI_DEPIN_AMT_USD                  --普通账户存入金额_美元
         ,ORDI_DEPIN_AMT_HKD                  --普通账户存入金额_港币
         ,ORDI_DEPIN_AMT_RMB                  --普通账户存入金额_人民币
         ,ORDI_TFR_IN_AMT                     --普通账户转入金额(折算人民币)
         ,ORDI_WTHDR_AMT_USD                  --普通账户取出金额_美元
         ,ORDI_WTHDR_AMT_HKD                  --普通账户取出金额_港币
         ,ORDI_WTHDR_AMT_RMB                  --普通账户取出金额_人民币
         ,ORDI_TFR_OUT_AMT                    --普通账户转出金额(折算人民币)
         ,CRD_DEPIN_AMT                       --信用账户存入金额
         ,CRD_TFR_IN_AMT                      --信用账户转入金额
         ,CRD_WTHDR_AMT                       --信用账户取出金额
         ,CRD_TFR_OUT_AMT                     --信用账户转出金额
         ,WRNT_DEPIN_AMT                      --期权账户存入金额
         ,WRNT_TFR_IN_AMT                     --期权账户转入金额
         ,WRNT_WTHDR_AMT                      --期权账户取出金额
         ,WRNT_TFR_OUT_AMT                    --期权账户转出金额
         ,TFR_IN_AMT                          --转入资金
         ,TFR_OUT_AMT                         --转出资金
         ,ORDI_NET_TFR_IN_AMT                 --普通账户净转入资金
         ,CRD_NET_TFR_IN_AMT                  --信用账户净转入资金
         ,WRNT_NET_TFR_IN_AMT                 --期权账户净转入资金
         ,NET_TFR_IN_AMT                      --净转入资金
         ,ORDI_ASGN_TFR_IN_MKTVAL_RMB         --普通账户指定转入市值_人民币
         ,ORDI_ASGN_TFR_IN_MKTVAL_USD         --普通账户指定转入市值_美元       
         ,ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB     --普通账户转托管转入市值_人民币
         ,ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD     --普通账户转托管转入市值_港币
         ,CRD_ASGN_TFR_IN_MKTVAL              --信用账户指定转入市值		
         ,CRD_TFR_CSTD_TFR_IN_MKTVAL          --信用账户转托管转入市值
         ,ORDI_ASGN_TFR_OUT_MKTVAL_RMB        --普通账户撤指定转出市值_人民币
         ,ORDI_ASGN_TFR_OUT_MKTVAL_USD        --普通账户撤指定转出市值_美元
         ,ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB    --普通账户转托管转出市值_人民币
         ,ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD    --普通账户转托管转出市值_港币
         ,CRD_ASGN_TFR_OUT_MKTVAL             --信用账户指定转出市值		
         ,CRD_TFR_CSTD_TFR_OUT_MKTVAL         --信用账户转托管转出市值
         ,ORDI_TFR_IN_MKTVAL                  --普通账户转入市值
         ,ORDI_TFR_OUT_MKTVAL                 --普通账户转出市值
         ,CRD_TFR_IN_MKTVAL                   --信用账户转入市值
         ,CRD_TFR_OUT_MKTVAL                  --信用账户转出市值
         ,TFR_IN_MKTVAL                       --转入市值
         ,TFR_OUT_MKTVAL                      --转出市值
         ,ORDI_NET_TFR_IN_MKTVAL              --普通账户净转入市值
         ,CRD_NET_TFR_IN_MKTVAL               --信用账户净转入市值
         ,NET_TFR_IN_MKTVAL                   --净转入市值		
         ,ORDI_CPTL                           --普通账户资金(折算人民币)
		 ,ORDI_UNPY_CPTL                      --普通账户在途资金(折算人民币)
		 ,CRD_UNPY_CPTL                       --信用账户在途资金
		 ,WRNT_UNPY_CPTL                      --期权账户在途资金
         ,CRD_CPTL                            --信用账户资金
         ,WRNT_CPTL                           --期权账户资金
		 ,TOT_UNPY_CPTL                       --总的在途资金
         ,TOT_CPTL                            --总资金		 
         ,ORDI_SEC_MKTVAL                     --普通账户证券市值(折算人民币)
		 ,ORDI_MKTVAL                         --普通账户市值
         ,ORDI_UN_CIR_MKTVAL                  --普通账户非流通市值(折算人民币)
         ,CRD_SEC_MKTVAL                      --信用账户证券市值
         ,WRNT_MKTVAL                         --期权账户市值(权利仓市值-义务仓市值)
		 ,WRNT_CNTS                           --期权张数
         ,TOT_MKTVAL                          --总市值
         ,ORDI_GL                             --普通账户负债
         ,CRD_GL                              --信用账户负债
         ,TOTGL                               --总负债
         ,ORDI_AST_UN_OTC                     --普通资产(不包含OTC)
         ,ORDI_AST                            --普通资产
         ,ORDI_NET_AST_UN_OTC                 --普通净资产(不包含OTC)
         ,ORDI_NET_AST                        --普通净资产
         ,CRD_AST                             --信用资产
         ,CRD_NET_AST                         --信用净资产
         ,WRNT_AST                            --期权资产
         ,TOT_AST                             --总资产
		 ,EXG_NET_TOT_AST                     --场内净资产
         ,NET_TOT_AST                         --净总资产
         ,ORDI_PRFT                           --普通盈亏
         ,CRD_PRFT                            --信用盈亏
         ,WRNT_PRFT                           --期权盈亏
         ,TOT_PRFT                            --总盈亏
		 ,ORDI_MKTVAL_EXG_FND_SH              --普通账户市值_场内基金_沪市
		 ,ORDI_MKTVAL_EXG_FND_SZ              --普通账户市值_场内基金_深市
		 ,CRD_MKTVAL_EXG_FND_SH               --信用账户市值_场内基金_沪市
		 ,CRD_MKTVAL_EXG_FND_SZ               --信用账户市值_场内基金_深市
		 ,ORDI_MKTVAL_BOND_SH                 --普通账户市值_债券_沪市
		 ,ORDI_MKTVAL_BOND_SZ                 --普通账户市值_债券_深市
		 ,CRD_MKTVAL_BOND_SH                  --信用账户市值_债券_沪市
		 ,CRD_MKTVAL_BOND_SZ                  --信用账户市值_债券_深市
		 ,ORDI_UN_CIR_MKTVAL_SH               --普通账户沪市非流通市值(折算人民币)
         ,ORDI_UN_CIR_MKTVAL_SZ               --普通账户深市非流通市值(折算人民币)
         ,STK_PLG_AMT                         --股票质押余额
         ,STK_PLG_ADD_INT                     --股票质押新增利息
         ,STK_PLG_ADD_TRD_AMT                 --股票质押初始交易量
         ,MIN_STK_PLG_AMT                     --小微贷余额
         ,MIN_STK_PLG_ADD_INT                 --小微贷新增利息
         ,MIN_STK_PLG_ADD_TRD_AMT             --小微贷初始交易量
         ,ORDI_MKTVAL_NEW_TA                  --普通账户市值_新三板A股
		 ,ORDI_MKTVAL_AK_STIB                 --普通账户市值_AK科创板
         ,ORDI_MKTVAL_RK_STIB                 --普通账户市值_RK科创CDR
         ,CRD_MKTVAL_AK_STIB                  --信用账户市值_AK科创板
         ,CRD_MKTVAL_RK_STIB                  --信用账户市值_RK科创CDR
		 ,WRNT_RGHT_HLD_MKTVAL_SH                --期权账户权利仓市值(SH)
         ,WRNT_DUTY_HLD_MKTVAL_SH                --期权账户义务仓市值(SH)      
         ,WRNT_MKTVAL_SH                         --期权账户市值(权利仓市值-义务仓市值)(SH)	
         ,WRNT_CNTS_SH                           --期权张数(SH)
         ,WRNT_RGHT_HLD_MKTVAL_SZ                --期权账户权利仓市值(SZ)
         ,WRNT_DUTY_HLD_MKTVAL_SZ                --期权账户义务仓市值(SZ)      
         ,WRNT_MKTVAL_SZ                         --期权账户市值(权利仓市值-义务仓市值)(SZ)	
         ,WRNT_CNTS_SZ                           --期权张数(SZ)
         		 
 ) partition(BUS_DATE = %d{yyyyMMdd})
 SELECT   t.CUST_NO                             --客户号                 
         ,t.BRH_NO                              --营业部编号                         
         ,t.CUST_CGY		                    --客户类别
         ,NVL(a4.MKTVAL_HA,0)                           --市值_沪A主板
         ,NVL(a4.ORDI_MKTVAL_HA,0)                      --普通账户市值_沪A主板
         ,NVL(a4.CRD_MKTVAL_HA,0)                       --信用账户市值_沪A主板
         ,NVL(a4.MKTVAL_SA,0)                           --市值_深A主板
         ,NVL(a4.ORDI_MKTVAL_SA,0)                      --普通账户市值_深A主板
         ,NVL(a4.CRD_MKTVAL_SA,0)                       --信用账户市值_深A主板
         ,NVL(a4.MKTVAL_SMS,0)                          --市值_中小板
         ,NVL(a4.ORDI_MKTVAL_SMS,0)                     --普通账户市值_中小板
         ,NVL(a4.CRD_MKTVAL_SMS,0)                      --信用账户市值_中小板
         ,NVL(a4.MKTVAL_GEM,0)                          --市值_创业板
         ,NVL(a4.ORDI_MKTVAL_GEM,0)                     --普通账户市值_创业板
         ,NVL(a4.CRD_MKTVAL_GEM,0)                      --信用账户市值_创业板
         ,NVL(a4.ORDI_MKTVAL_HB_USD,0)                  --普通账户市值_沪B_美元
         ,NVL(a4.ORDI_MKTVAL_SB_HKD,0)                  --普通账户市值_深B_港币
         ,NVL(a4.ORDI_MKTVAL_HK,0)                      --普通账户市值_沪港通
         ,NVL(a4.ORDI_MKTVAL_SK,0)                      --普通账户市值_深港通
         ,NVL(a4.ORDI_MKTVAL_TA,0)                      --普通账户市值_三板A股
         ,NVL(a4.ORDI_MKTVAL_TU_USD,0)                  --普通账户市值_三板B股_美元
         ,NVL(a4.ORDI_MKTVAL_REPO,0)                    --普通账户市值_回购
         ,NVL(a4.ORDI_MKTVAL_EXG_FND,0)                 --普通账户市值_场内基金
         ,NVL(a4.ORDI_MKTVAL_CLS_FND,0)                 --普通账户市值_封闭式基金
         ,NVL(a4.ORDI_MKTVAL_ETF_FND,0)                 --普通账户市值_ETF
         ,NVL(a4.ORDI_MKTVAL_OPN_FND,0)                 --普通账户市值_开放式
         ,NVL(a4.ORDI_MKTVAL_LOF_FND,0)                 --普通账户市值_LOF
         ,NVL(a4.ORDI_MKTVAL_FOF_FND,0)                 --普通账户市值_FOF
         ,NVL(a4.CRD_MKTVAL_EXG_FND,0)                  --信用账户市值_场内基金
         ,NVL(a4.CRD_MKTVAL_CLS_FND,0)                  --信用账户市值_封闭式基金
         ,NVL(a4.CRD_MKTVAL_ETF_FND,0)                  --信用账户市值_ETF
         ,NVL(a4.CRD_MKTVAL_OPN_FND,0)                  --信用账户市值_开放式
         ,NVL(a4.CRD_MKTVAL_LOF_FND,0)                  --信用账户市值_LOF
         ,NVL(a4.CRD_MKTVAL_FOF_FND,0)                  --信用账户市值_FOF
         ,NVL(a4.ORDI_MKTVAL_BOND,0)                    --普通账户市值_债券
         ,NVL(a4.CRD_MKTVAL_BOND,0)                     --信用账户市值_债券
         ,NVL(a5.AGN_FND_MKTVAL,0)                      --代销基金市值		
         ,NVL(a5.GS_PROD_MKTVAL,0)                      --公司产品市值
         ,NVL(a5.GJ_PROD_MKTVAL,0)                      --国君产品市值		
         ,NVL(a5.BANK_PROD_MKTVAL,0)                    --银行产品市值
         ,NVL(a5.OTC_PROD_MKTVAL,0)                     --OTC产品市值	
         ,NVL(a6.WRNT_RGHT_HLD_MKTVAL,0)                --期权账户权利仓市值
         ,NVL(a6.WRNT_DUTY_HLD_MKTVAL,0)                --期权账户义务仓市值
         ,NVL(a4.ORDI_MKTVAL_SEC_USD,0)                 --普通账户证券市值_美元
         ,NVL(a4.ORDI_MKTVAL_SEC_HKD,0)                 --普通账户证券市值_港币
         ,NVL(a4.ORDI_MKTVAL_SEC_RMD,0)                 --普通账户证券市值_人民币
         ,NVL(a5.ORDI_MKTVAL_PROD,0)                    --普通账户产品市值		
         ,NVL(a1.ORDI_CPTL_USD,0)                       --普通账户资金_美元
         ,NVL(a1.ORDI_CPTL_HKD,0)                       --普通账户资金_港币
         ,NVL(a1.ORDI_CPTL_RMB,0)                       --普通账户资金_人民币		
         ,NVL(a3.ORDI_DEPIN_AMT_USD,0)                  --普通账户存入金额_美元
         ,NVL(a3.ORDI_DEPIN_AMT_HKD,0)                  --普通账户存入金额_港币
         ,NVL(a3.ORDI_DEPIN_AMT_RMB,0)                  --普通账户存入金额_人民币
         ,NVL(a3.ORDI_TFR_IN_AMT,0)                     --普通账户转入金额(折算人民币)
         ,NVL(a3.ORDI_WTHDR_AMT_USD,0)                  --普通账户取出金额_美元
         ,NVL(a3.ORDI_WTHDR_AMT_HKD,0)                  --普通账户取出金额_港币
         ,NVL(a3.ORDI_WTHDR_AMT_RMB,0)                  --普通账户取出金额_人民币
         ,NVL(a3.ORDI_TFR_OUT_AMT,0)                    --普通账户转出金额(折算人民币)
         ,NVL(a3.CRD_DEPIN_AMT,0)                       --信用账户存入金额_人民币
         ,NVL(a3.CRD_TFR_IN_AMT,0)                      --信用账户转入金额(折算人民币)
         ,NVL(a3.CRD_WTHDR_AMT,0)                       --信用账户取出金额_人民币
         ,NVL(a3.CRD_TFR_OUT_AMT,0)                     --信用账户转出金额(折算人民币)
         ,NVL(a3.WRNT_DEPIN_AMT,0)                  --期权账户存入金额_人民币
         ,NVL(a3.WRNT_TFR_IN_AMT,0)                     --期权账户转入金额(折算人民币)
         ,NVL(a3.WRNT_WTHDR_AMT,0)                      --期权账户取出金额_人民币
         ,NVL(a3.WRNT_TFR_OUT_AMT,0)                    --期权账户转出金额(折算人民币)
         ,NVL(a3.TFR_IN_AMT,0)                          --转入资金
         ,NVL(a3.TFR_OUT_AMT,0)                         --转出资金
         ,NVL(a3.ORDI_NET_TFR_IN_AMT,0)                 --普通账户净转入资金
         ,NVL(a3.CRD_NET_TFR_IN_AMT,0)                  --信用账户净转入资金
         ,NVL(a3.WRNT_NET_TFR_IN_AMT,0)                 --期权账户净转入资金
         ,NVL(a3.NET_TFR_IN_AMT,0)                      --净转入资金
         ,NVL(a7.ORDI_ASGN_TFR_IN_MKTVAL_RMB,0)         --普通账户指定转入市值_人民币
         ,NVL(a7.ORDI_ASGN_TFR_IN_MKTVAL_USD,0)         --普通账户指定转入市值_美元
       --  ,NVL(a7.ORDI_ASGN_TFR_IN_MKTVAL_HKD,0)         --普通账户指定转入市值_港币
         ,NVL(a7.ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB,0)     --普通账户转托管转入市值_人民币
       --  ,NVL(a7.ORDI_TFR_CSTD_TFR_IN_MKTVAL_USD,0)     --普通账户转托管转入市值_美元
         ,NVL(a7.ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD,0)     --普通账户转托管转入市值_港币
         ,NVL(a7.CRD_ASGN_TFR_IN_MKTVAL,0)          --信用账户指定转入市值_人民币		
         ,NVL(a7.CRD_TFR_CSTD_TFR_IN_MKTVAL,0)      --信用账户转托管转入市值_人民币
         ,NVL(a7.ORDI_ASGN_TFR_OUT_MKTVAL_RMB,0)        --普通账户撤指定转出市值_人民币
         ,NVL(a7.ORDI_ASGN_TFR_OUT_MKTVAL_USD,0)        --普通账户撤指定转出市值_美元
       --  ,NVL(a7.ORDI_ASGN_TFR_OUT_MKTVAL_HKD,0)        --普通账户撤指定转出市值_港币
         ,NVL(a7.ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB,0)    --普通账户转托管转出市值_人民币
       --  ,NVL(a7.ORDI_TFR_CSTD_TFR_OUT_MKTVAL_USD,0)    --普通账户转托管转出市值_美元
         ,NVL(a7.ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD,0)    --普通账户转托管转出市值_港币
         ,NVL(a7.CRD_ASGN_TFR_OUT_MKTVAL,0)         --信用账户指定转出市值_人民币		
         ,NVL(a7.CRD_TFR_CSTD_TFR_OUT_MKTVAL,0)     --信用账户转托管转出市值_人民币
         ,NVL(a7.ORDI_TFR_IN_MKTVAL,0)+NVL(a8.ORDI_TFR_IN_MKTVAL,0)                 --普通账户转入市值
         ,NVL(a7.ORDI_TFR_OUT_MKTVAL,0)+NVL(a8.ORDI_TFR_OUT_MKTVAL,0)                 --普通账户转出市值
         ,NVL(a7.CRD_TFR_IN_MKTVAL,0)                   --信用账户转入市值
         ,NVL(a7.CRD_TFR_OUT_MKTVAL,0)                  --信用账户转出市值
         ,NVL(a7.TFR_IN_MKTVAL,0)+NVL(a8.TFR_IN_MKTVAL,0)                       --转入市值
         ,NVL(a7.TFR_OUT_MKTVAL,0)+NVL(a8.TFR_OUT_MKTVAL,0)                      --转出市值
         ,NVL(a7.ORDI_NET_TFR_IN_MKTVAL,0)+NVL(a8.ORDI_NET_TFR_IN_MKTVAL,0)              --普通账户净转入市值
         ,NVL(a7.CRD_NET_TFR_IN_MKTVAL,0)               --信用账户净转入市值
         ,NVL(a7.NET_TFR_IN_MKTVAL,0)+NVL(a8.NET_TFR_IN_MKTVAL,0)                   --净转入市值		
         ,NVL(a1.ORDI_CPTL,0)                           --普通账户资金(折算人民币)
		 ,NVL(a1.ORDI_UNPY_CPTL,0)                      --普通账户在途资金(折算人民币)
		 ,NVL(a1.CRD_UNPY_CPTL,0)                       --信用账户在途资金
		 ,NVL(a1.WRNT_UNPY_CPTL,0)                      --期权账户在途资金         
         ,NVL(a1.CRD_CPTL,0)                            --信用账户资金
         ,NVL(a1.WRNT_CPTL,0)                           --期权账户资金
		 ,NVL(a1.TOT_UNPY_CPTL,0)                       --在途资金(折算人民币)
         ,NVL(a1.TOT_CPTL,0)                            --总资金
         ,NVL(a4.ORDI_SEC_MKTVAL,0)                     --普通账户证券市值(折算人民币)
		 ,NVL(a4.ORDI_SEC_MKTVAL,0)+NVL(a5.ORDI_MKTVAL_PROD,0) as ORDI_MKTVAL                        --普通账户市值
         ,NVL(a4.ORDI_UN_CIR_MKTVAL,0)                  --普通账户非流通市值(折算人民币)
         ,NVL(a4.CRD_SEC_MKTVAL,0)                      --信用账户证券市值
         ,NVL(a6.WRNT_MKTVAL,0)                         --期权账户市值(权利仓市值-义务仓市值)
		 ,NVL(a6.WRNT_CNTS,0) as WRNT_CNTS                         --期权张数
         ,NVL(a4.CRD_SEC_MKTVAL,0)+NVL(a4.ORDI_SEC_MKTVAL,0)+NVL(a5.ORDI_MKTVAL_PROD,0)+NVL(a6.WRNT_MKTVAL,0)  as TOT_MKTVAL                          --总市值
         ,NVL(a9.ORDI_GL,0)                             --普通账户负债
         ,NVL(a10.CRD_GL,0)                              --信用账户负债
         ,NVL(a9.ORDI_GL,0)+NVL(a10.CRD_GL,0) as TOTGL                               --总负债
         ,NVL(a4.ORDI_SEC_MKTVAL,0)+NVL(a5.ORDI_MKTVAL_PROD,0)+NVL(a1.ORDI_CPTL,0)+NVL(a1.ORDI_UNPY_CPTL,0)-NVL(a5.OTC_PROD_MKTVAL,0) as ORDI_AST_UN_OTC                     --普通资产(不包含OTC)
         ,NVL(a4.ORDI_SEC_MKTVAL,0)+NVL(a5.ORDI_MKTVAL_PROD,0)+NVL(a1.ORDI_CPTL,0)+NVL(a1.ORDI_UNPY_CPTL,0) as ORDI_AST                            --普通资产
         ,NVL(a4.ORDI_SEC_MKTVAL,0)+NVL(a5.ORDI_MKTVAL_PROD,0)+NVL(a1.ORDI_CPTL,0)+NVL(a1.ORDI_UNPY_CPTL,0)-NVL(a9.ORDI_GL,0)-NVL(a5.OTC_PROD_MKTVAL,0) as ORDI_NET_AST_UN_OTC                 --普通净资产(不包含OTC)
         ,NVL(a4.ORDI_SEC_MKTVAL,0)+NVL(a5.ORDI_MKTVAL_PROD,0)+NVL(a1.ORDI_CPTL,0)+NVL(a1.ORDI_UNPY_CPTL,0)-NVL(a9.ORDI_GL,0) as ORDI_NET_AST                        --普通净资产
         ,NVL(a4.CRD_SEC_MKTVAL,0)+NVL(a1.CRD_UNPY_CPTL,0)+NVL(a1.CRD_CPTL,0) as CRD_AST                             --信用资产
         ,NVL(a4.CRD_SEC_MKTVAL,0)+NVL(a1.CRD_UNPY_CPTL,0)+NVL(a1.CRD_CPTL,0)-NVL(a10.CRD_GL,0) as CRD_NET_AST                         --信用净资产
         ,NVL(a6.WRNT_MKTVAL,0)+NVL(a1.WRNT_CPTL,0)+NVL(a1.WRNT_UNPY_CPTL,0) as WRNT_AST                            --期权资产
         ,NVL(a4.ORDI_SEC_MKTVAL,0)+NVL(a5.ORDI_MKTVAL_PROD,0)+NVL(a1.ORDI_CPTL,0)+NVL(a1.ORDI_UNPY_CPTL,0)
		 +NVL(a4.CRD_SEC_MKTVAL,0)+NVL(a1.CRD_UNPY_CPTL,0)+NVL(a1.CRD_CPTL,0)
		 +NVL(a6.WRNT_MKTVAL,0)+NVL(a1.WRNT_CPTL,0)+NVL(a1.WRNT_UNPY_CPTL,0) as TOT_AST                             --总资产
         ,NVL(a4.ORDI_SEC_MKTVAL,0)+NVL(a5.ORDI_EXG_MKTVAL_PROD,0)+NVL(a1.ORDI_CPTL,0)+NVL(a1.ORDI_UNPY_CPTL,0)
		  +NVL(a4.CRD_SEC_MKTVAL,0)+NVL(a1.CRD_UNPY_CPTL,0)+NVL(a1.CRD_CPTL,0)
		  +NVL(a6.WRNT_MKTVAL,0)+NVL(a1.WRNT_CPTL,0)+NVL(a1.WRNT_UNPY_CPTL,0)-NVL(a9.ORDI_GL,0)-NVL(a10.CRD_GL,0) as EXG_NET_TOT_AST
		 
		  
		,NVL(a4.ORDI_SEC_MKTVAL,0)+NVL(a5.ORDI_MKTVAL_PROD,0)+NVL(a1.ORDI_CPTL,0)+NVL(a1.ORDI_UNPY_CPTL,0)
		 +NVL(a4.CRD_SEC_MKTVAL,0)+NVL(a1.CRD_UNPY_CPTL,0)+NVL(a1.CRD_CPTL,0)
		 +NVL(a6.WRNT_MKTVAL,0)+NVL(a1.WRNT_CPTL,0)+NVL(a1.WRNT_UNPY_CPTL,0)-NVL(a9.ORDI_GL,0)-NVL(a10.CRD_GL,0) as NET_TOT_AST                         --净总资产
         ,NVL(a4.ORDI_SEC_MKTVAL,0)+NVL(a5.ORDI_MKTVAL_PROD,0)+NVL(a1.ORDI_CPTL,0)+NVL(a1.ORDI_UNPY_CPTL,0)-NVL(a9.ORDI_GL,0) 
		 -NVL(a2.ORDI_NET_AST_Y,0)-NVL(a7.ORDI_NET_TFR_IN_MKTVAL,0)-NVL(a8.ORDI_NET_TFR_IN_MKTVAL,0)
		 -NVL(a3.ORDI_NET_TFR_IN_AMT,0)
		  as ORDI_PRFT                           --普通盈亏
         ,NVL(a4.CRD_SEC_MKTVAL,0)+NVL(a1.CRD_UNPY_CPTL,0)+NVL(a1.CRD_CPTL,0)-NVL(a10.CRD_GL,0)
		 -NVL(a2.CRD_NET_AST_Y,0)-NVL(a7.CRD_NET_TFR_IN_MKTVAL,0)
		 -NVL(a3.CRD_NET_TFR_IN_AMT,0)
		 as CRD_PRFT                            --信用盈亏
         ,NVL(a6.WRNT_MKTVAL,0)+NVL(a1.WRNT_CPTL,0)+NVL(a1.WRNT_UNPY_CPTL,0)-NVL(a2.WRNT_NET_AST_Y,0)
		 -NVL(a3.WRNT_NET_TFR_IN_AMT,0) as WRNT_PRFT                           --期权盈亏
         ,NVL(a4.ORDI_SEC_MKTVAL,0)+NVL(a5.ORDI_MKTVAL_PROD,0)+NVL(a1.ORDI_CPTL,0)+NVL(a1.ORDI_UNPY_CPTL,0)
		 +NVL(a4.CRD_SEC_MKTVAL,0)+NVL(a1.CRD_UNPY_CPTL,0)+NVL(a1.CRD_CPTL,0)
		 +NVL(a6.WRNT_MKTVAL,0)+NVL(a1.WRNT_CPTL,0)+NVL(a1.WRNT_UNPY_CPTL,0)-NVL(a9.ORDI_GL,0)-NVL(a10.CRD_GL,0) 
		 -NVL(a2.TOT_NET_AST_Y,0)-NVL(a7.ORDI_NET_TFR_IN_MKTVAL,0)-NVL(a8.ORDI_NET_TFR_IN_MKTVAL,0)-NVL(a7.CRD_NET_TFR_IN_MKTVAL,0)
		 -NVL(a3.ORDI_NET_TFR_IN_AMT,0)-NVL(a3.CRD_NET_TFR_IN_AMT,0)-NVL(a3.WRNT_NET_TFR_IN_AMT,0)
		 as TOT_PRFT                            --总盈亏
         ,NVL(a4.ORDI_MKTVAL_EXG_FND_SH,0)              --普通账户市值_场内基金_沪市
		 ,NVL(a4.ORDI_MKTVAL_EXG_FND_SZ,0)              --普通账户市值_场内基金_深市
		 ,NVL(a4.CRD_MKTVAL_EXG_FND_SH,0)               --信用账户市值_场内基金_沪市
		 ,NVL(a4.CRD_MKTVAL_EXG_FND_SZ,0)               --信用账户市值_场内基金_深市
		 ,NVL(a4.ORDI_MKTVAL_BOND_SH,0)                 --普通账户市值_债券_沪市
		 ,NVL(a4.ORDI_MKTVAL_BOND_SZ,0)                 --普通账户市值_债券_深市
		 ,NVL(a4.CRD_MKTVAL_BOND_SH,0)                  --信用账户市值_债券_沪市
		 ,NVL(a4.CRD_MKTVAL_BOND_SZ,0)                  --信用账户市值_债券_深市
		 ,NVL(a4.ORDI_UN_CIR_MKTVAL_SH,0)               --普通账户沪市非流通市值(折算人民币)
         ,NVL(a4.ORDI_UN_CIR_MKTVAL_SZ,0)               --普通账户深市非流通市值(折算人民币)	
		 ,NVL(a9.STK_PLG_AMT,0)                           --股票质押余额
         ,NVL(a9.STK_PLG_ADD_INT,0)                      --股票质押新增利息
         ,NVL(a11.STK_PLG_ADD_TRD_AMT,0)                   --股票质押初始交易量
         ,NVL(a9.MIN_STK_PLG_AMT,0)                       --小微贷余额
         ,NVL(a9.MIN_STK_PLG_ADD_INT,0)                   --小微贷新增利息
         ,NVL(a11.MIN_STK_PLG_ADD_TRD_AMT,0)               --小微贷初始交易量
         ,NVL(a4.ORDI_MKTVAL_NEW_TA,0)                    --普通账户市值_新三板A股
         ,NVL(a4.ORDI_MKTVAL_AK_STIB,0)                      --普通账户市值_AK科创板
         ,NVL(a4.ORDI_MKTVAL_RK_STIB,0)                      --普通账户市值_RK科创CDR
         ,NVL(a4.CRD_MKTVAL_AK_STIB,0)                       --信用账户市值_AK科创板
         ,NVL(a4.CRD_MKTVAL_RK_STIB,0)                       --信用账户市值_RK科创CDR
		 
		 ,NVL(a6.WRNT_RGHT_HLD_MKTVAL_SH,0)                --期权账户权利仓市值(SH)
         ,NVL(a6.WRNT_DUTY_HLD_MKTVAL_SH,0)                --期权账户义务仓市值(SH)      
         ,NVL(a6.WRNT_MKTVAL_SH,0)                         --期权账户市值(权利仓市值-义务仓市值)(SH)	
         ,NVL(a6.WRNT_CNTS_SH,0)                           --期权张数(SH)
         ,NVL(a6.WRNT_RGHT_HLD_MKTVAL_SZ,0)                --期权账户权利仓市值(SZ)
         ,NVL(a6.WRNT_DUTY_HLD_MKTVAL_SZ,0)                --期权账户义务仓市值(SZ)      
         ,NVL(a6.WRNT_MKTVAL_SZ,0)                         --期权账户市值(权利仓市值-义务仓市值)(SZ)	
         ,NVL(a6.WRNT_CNTS_SZ,0)                           --期权张数(SZ)
		 
		 

		 
  FROM  (SELECT CUST_NO
               ,BRH_NO
			   ,CUST_CGY
			   ,ORDI_CUST_STAT
			   ,ORDI_CNCLACT_DT
			   ,ORDI_OPNAC_DT
        FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO  
		WHERE BUS_DATE = %d{yyyyMMdd}
		AND   ORDI_OPNAC_DT < = %d{yyyyMMdd}
		)  t
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP   a1
 ON        t.CUST_NO = a1.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP1   a2
 ON        t.CUST_NO = a2.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP2   a3
 ON        t.CUST_NO = a3.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP3   a4
 ON        t.CUST_NO = a4.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP4   a5
 ON        t.CUST_NO = a5.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP5   a6
 ON        t.CUST_NO = a6.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP6   a7
 ON        t.CUST_NO = a7.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP7   a8
 ON        t.CUST_NO = a8.CUST_NO
  LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP8   a9
 ON        t.CUST_NO = a9.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP9   a10
 ON        t.CUST_NO = a10.CUST_NO

 LEFT JOIN (SELECT KHH as CUST_NO
                  ,SUM(DECODE(WTFS,8,CJJE,0)) as STK_PLG_ADD_TRD_AMT    
                  ,SUM(DECODE(WTFS,8,0,CJJE)) as MIN_STK_PLG_ADD_TRD_AMT 				  
            FROM EDW_PROD.T_EDW_T05_TJGMXLS 
			WHERE BUS_DATE = %d{yyyyMMdd} 			
			AND  WTLB = 53
            GROUP BY CUST_NO
           ) a11
 ON        t.CUST_NO = a11.CUST_NO
 WHERE EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_INR_ORG_BRH b
               WHERE  b.BUS_DATE = %d{yyyyMMdd}
			   AND   t.BRH_NO = b.BRH_NO
              )
 AND   t.CUST_NO < > '100610335855'
AND    (t.ORDI_CUST_STAT < > '3' OR t.ORDI_CNCLACT_DT > %d{yyyyMMdd})

 ;
 
 ------删除临时表

 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP1 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP2 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP3 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP4 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP5 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP6 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP7 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP8 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP9 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP10 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP11 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP12 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP13 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP14 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_BAK_TEMP15 ;
 
-----------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_AST_CUST_AST_AGGR_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY;
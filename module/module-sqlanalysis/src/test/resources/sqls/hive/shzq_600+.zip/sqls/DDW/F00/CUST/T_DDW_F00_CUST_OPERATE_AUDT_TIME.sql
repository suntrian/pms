 ----/* ***************************************** SQL Begin *****************************************  */
  ----/* 脚本功能:操作人审核时时表                                                                         */
  ----/* 创建人:黄勇华                                                                               */
  ----/* 创建时间:2018-06-12                                                                        */ 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP;
CREATE TABLE DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP
as SELECT      a.KHH           as KHH
              ,a.CZLX          as CZLX
			  ,b.YWDM          as YWDM
			  ,c.NAME          as NAME
			  ,b.clzt          as YWQQZT
			  ,a.YWQQID        as YWQQID
              ,a.BZSM          as BZSM			  
              ,CASE WHEN a.CZLX = '211'
                    THEN ROW_NUMBER() OVER(PARTITION BY a.YWQQID,a.CZLX ORDER BY a.CZSJ )
					END        as SORT_1
              ,0                as CGY 					
   FROM       CIFSS.TYWQQ_CZLS a
   LEFT JOIN  CIFSS.TYWQQ      b
   ON         a.ywqqid = b.ID
   LEFT JOIN CIFSS.TUSER       c
   ON        a.CZR = c.ID
   WHERE       (b.FQQD = '1' OR (b.YWDM = '20042' AND b.FQQD = '11'))
   AND   EXISTS(SELECT 1 
                FROM (SELECT  b.YWDM
				      FROM      CIFSS.TYWLC_TJ_SHJD a
				      LEFT JOIN  CIFSS.TYWLC_TJ     b
				      ON          a.tywlc_tj_id = b.ID
				      WHERE      a.SHJS IN ('47','48','60','813')
				      )      d
				  WHERE DECODE(b.YWDM,'20322','20321','20323','20321',b.YWDM) = d.YWDM
                  )
  AND       c.USERID IN ('00000320','00000287','00000256','00000579','00000708','00000235','00000181','00001071','00002722','88890181','88890708','88890287','88890256','88892722','88890579','88890320')    
  AND       a.CZRQ  = '%d{yyyyMMdd}'
  AND       a.CZLX IN ('211','301','302','321','322')
  UNION ALL
  SELECT      a.KHH           as KHH
              ,a.CZLX          as CZLX
			  ,b.YWDM          as YWDM
			  ,c.NAME          as NAME
			  ,b.clzt          as YWQQZT
			  ,a.YWQQID        as YWQQID
              ,a.BZSM          as BZSM			  
              ,CASE WHEN a.CZLX = '211'
                    THEN ROW_NUMBER() OVER(PARTITION BY a.YWQQID,a.CZLX ORDER BY a.CZSJ )
					END        as SORT_1
              ,1                as CGY 					
   FROM       CIFSS.TYWQQ_CZLS a
   LEFT JOIN  CIFSS.TYWQQ      b
   ON         a.ywqqid = b.ID
   LEFT JOIN CIFSS.TUSER       c
   ON        a.CZR = c.ID
   WHERE       b.FQQD IN ('2','11') 
   AND   EXISTS(SELECT 1 
                FROM (SELECT  b.YWDM
				      FROM      CIFSS.TYWLC_TJ_SHJD a
				      LEFT JOIN  CIFSS.TYWLC_TJ     b
				      ON          a.tywlc_tj_id = b.ID
				      WHERE      a.SHJS IN ('809')
				      )      d
				  WHERE DECODE(b.YWDM,'20322','20321','20323','20321',b.YWDM) = d.YWDM
                  )
  AND       c.USERID IN ('88800174','88800196','88800340','88800346','88800372','88800466','88800671','88800890','88800927','88801232','88801442','88802153','88802209','88802210','88802233','88802235','88802281','88802282','88802283','88802328','88802340','88802499','88802500')    
  AND       a.CZRQ  = '%d{yyyyMMdd}'
  AND       a.CZLX IN ('211','301','302','321','322')
  
  ;
  
  
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP1;
  CREATE TABLE DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP1
  as  SELECT   a.KHH           as KHH
              ,a.CZLX          as CZLX
			  ,a.YWDM          as YWDM
			  ,a.NAME          as NAME
			  ,a.YWQQZT        as YWQQZT
			  ,a.YWQQID        as YWQQID
              ,a.BZSM		   as BZSM  
			  ,a.SORT_1        as SORT_1
			  ,CASE WHEN c.YWQQID IS NOT NULL
			        THEN 0
					WHEN a.CZLX IN ('301','302')
					THEN 0
					WHEN d.YWQQID IS NOT NULL
			        THEN 0
					ELSE 1
					END            as IF_YWQQZT --是否看业务请求状态(0 不看 1 是看)
			 ,a.CGY
      FROM        DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP  a
      LEFT  JOIN (SELECT   YWQQID,CGY
                  FROM     DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP
			      WHERE    CZLX IN ('211')
 			      GROUP BY YWQQID,CGY  
                  )    b
      ON         a.YWQQID = b.YWQQID
	  AND        a.CGY = b.CGY
      AND        a.CZLX IN ('301','302','211')
	  LEFT  JOIN (SELECT   YWQQID,CGY
                  FROM     DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP
			      WHERE    CZLX IN ('321','322')
 			      GROUP BY YWQQID,CGY  
                  )    e
      ON         a.YWQQID = e.YWQQID
      AND        a.CZLX IN ('321','322')
	   AND        a.CGY = e.CGY
	  LEFT  JOIN (SELECT   YWQQID,CGY
                  FROM     DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP
			      WHERE    CZLX IN ('301','302')
 			      GROUP BY YWQQID,CGY  
                  )    c
      ON         a.YWQQID = c.YWQQID
	   AND        a.CGY = C.CGY
      AND        a.CZLX IN ('211')
	  LEFT  JOIN (SELECT   YWQQID,CGY
                  FROM     DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP
			      WHERE    CZLX IN ('301','302','211')
 			      GROUP BY YWQQID,CGY  
                  )    d
      ON         a.YWQQID = d.YWQQID
	   AND        a.CGY = d.CGY
      AND        a.CZLX IN ('321','322');
	  
INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME
(
               CUST_NO            --客户号
              ,OPRT_TP            --操作类型
              ,CUST_CGY           --客户类别
              ,BIZ_CD             --业务代码
			  ,BIZ_NAME           --业务名称
              ,AUDT_PSN_NAME      --审核人姓名
			  ,AUDT_TS            --审核时长                           
			  ,BIZ_APL_STAT       --业务请求状态
			  ,BIZ_APL_ID         --业务请求ID
			  ,IF_BIZ_APL_STAT    --是否看业务请求状态
			  ,IF_TMOUT_AUDT      --是否超时
			  ,PRDCT_TIME         --预计耗时
			  ,STEP_EXPLN         --步骤说明
			  ,CGY                --分类(0--运营 1--网厅)
			  
)	  
SELECT         t.KHH           as CUST_NO            --客户号
              ,t.CZLX          as OPRT_TP            --操作类型
              ,a1.KHLB         as CUST_CGY           --客户类别
              ,t.YWDM          as BIZ_CD             --业务代码
			  ,a4.YWMC         as BIZ_NAME           --业务名称
              ,t.NAME          as AUDT_PSN_NAME      --审核人姓名
			  ,CASE WHEN t.CZLX IN ('321','322')
			        THEN 0
					ELSE unix_timestamp(a3.finish_date)-unix_timestamp(a3.start_date)
					END        as AUDT_TS            --审核时长                           
			  ,t.YWQQZT        as BIZ_APL_STAT       --业务请求状态
			  ,t.YWQQID        as BIZ_APL_ID         --业务请求ID
			  ,t.IF_YWQQZT     as IF_BIZ_APL_STAT    --是否看业务请求状态
              ,CASE WHEN DECODE(t.CZLX,'321',0,'322',0,unix_timestamp(a3.finish_date)-unix_timestamp(a3.start_date)) > NVL(a5.AUDT_TIME,0)*60
                    THEN '是'
                    ELSE '否'
                    END        as IF_TMOUT_AUDT	
              ,NVL(a5.AUDT_TIME,0)   as PRDCT_TIME    --预计耗时
              ,t.BZSM as STEP_EXPLN         --步骤说明
              ,t.CGY			  
FROM      DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP1    t
LEFT JOIN CIFSS.TKHXX       a1
ON        t.KHH = a1.KHH
LEFT JOIN (SELECT    a.YWQQID
                    
                    ,a.instid
                    ,b.state	
                    ,CASE WHEN b.state IN ('1','3')
                          THEN ROW_NUMBER() OVER(PARTITION BY a.YWQQID ORDER BY b.init_date )
					      END        as SORT_2 					
             FROM       cifss.LCGTYW    a
			 LEFT JOIN  CIFSS.OS_WFENTRY b
			 ON         a.instid = b.ID
			 WHERE a.instid < > '-1'
			 UNION 
			 SELECT a.YWQQID
                    ,a.instid
                    ,b.state
                    ,CASE WHEN b.state IN ('1','3')
                          THEN ROW_NUMBER() OVER(PARTITION BY a.YWQQID ORDER BY b.init_date )
					      END		as SORT_2			
             FROM       CIFSS.LCGTYW_KHXXXG    a
			 LEFT JOIN  CIFSS.OS_WFENTRY b
			 ON         a.instid = b.ID
			 WHERE a.instid < > '-1'
			 )      a2
 ON     t.YWQQID = a2.YWQQID
 AND    ((t.CZLX IN ('301','302') AND a2.STATE IN('1','4'))
 OR     (t.CZLX IN ('211') AND t.SORT_1 = a2.SORT_2 AND a2.STATE IN('1','3')  ))
 LEFT JOIN (SELECT  entry_id
                    ,MIN(start_date) as start_date
					,MAX(finish_date) as finish_date
             FROM CIFSS.OS_HISTORYSTEP
			 GROUP BY entry_id
			 )      a3
  ON        a2.instid = a3.entry_id
  LEFT JOIN CIFSS.TYWDM    a4
  ON        t.YWDM = a4.YWDM 
  LEFT JOIN DDW_PROD.T_DDW_CFG_OPERATE_AUDT_TIME a5
  ON        DECODE(a1.KHLB,'0','0','1','1','2') = a5.CUST_CGY
  AND       DECODE(t.YWDM,'20322','20321','20323','20321',t.YWDM) = a5.BIZ_CD 
  ;   
  
  --
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP1;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME_TEMP2;
  
------------------------插入数据结束---------------------
--INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
--PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_OPERATE_AUDT_TIME',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_OPERATE_AUDT_TIME ;
	  
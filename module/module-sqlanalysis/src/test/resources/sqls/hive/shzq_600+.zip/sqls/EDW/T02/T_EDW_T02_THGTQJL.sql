 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:回购透券记录表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_THGTQJL ;
---------插入数据开始----------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_THGTQJL
(
                                    JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,BZQDM                               --标准券代码                              
                                   ,KSRQ                                --开始日期                               
                                   ,KHH                                 --客户号                                
                                   ,GDXM                                --股东姓名                               
                                   ,JSRQ                                --结束日期                               
                                   ,BZQSL                               --标准券数量                              
                                   ,WGHSL                               --未购回数量                              
                                   ,TQSL                                --透券数量                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.BZQDM                               as BZQDM                               --标准券代码                               
                                   ,t.KSRQ                                as KSRQ                                --开始日期                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.GDXM                                as GDXM                                --股东姓名                                
                                   ,t.JSRQ                                as JSRQ                                --结束日期                                
                                   ,t.BZQSL                               as BZQSL                               --标准券数量                               
                                   ,t.WGHSL                               as WGHSL                               --未购回数量                               
                                   ,t.TQSL                                as TQSL                                --透券数量                                
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类  
                                   ,'JZJY'                                as XTBS								   
 FROM      JZJYCX.SECURITIES_THGTQJL t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'JZJY'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE     t.DT = '%d{yyyyMMdd}';
---------插入数据结束--------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_THGTQJL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
      invalidate metadata EDW_PROD.T_EDW_T02_THGTQJL; 
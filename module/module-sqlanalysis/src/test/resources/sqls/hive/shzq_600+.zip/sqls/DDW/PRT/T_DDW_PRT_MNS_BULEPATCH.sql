 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:红冲兰补表                                                                      */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 
  /* T_DDW_F05_CPTL_DTL_HIS  修改为   T_DDW_F00_TRD_CPTL_TRD_DTL_HIS             */
 
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_MNS_BULEPATCH
(
								 BRH_NO                        --营业部编码  
								,BRH_NAME                      --营业部名称  
								,DT                            --日期        
								,CUST_NO                       --客户号      
								,CUST_NAME                     --客户姓名    
								,BIZ_SBJ                       --业务科目    
								,BIZ_SBJ_NAME                  --业务科目名称
								,CCY_CD                        --币种代码    
								,INCM_AMT                      --收入金额    
								,PAY_AMT                       --付出金额    
								,ABST                          --摘要        
								,CPTL_SRC                      --资金来源    
								,OPRT_TELR                     --操作柜员    
								,RECHK_TELR                    --复核柜员    
								,CGY                           --类别        
								,SECOND_CARD_VRFCTN            --二代证验证  
                                    ,CTF_CGY                    --开户证件类别
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
					 t.BRH_NO                                 AS  BRH_NO                     --营业部编码  
					,t.BRH_NAME                               AS  BRH_NAME                    --营业部名称  
					,t.DT                                     AS  DT                          --日期        
					,t.CUST_NO                                AS  CUST_NO                     --客户号      
					,t.CUST_NAME                              AS  CUST_NAME                   --客户姓名    
					,t.BIZ_SBJ                                AS  BIZ_SBJ                     --业务科目    
					,t.BIZ_SBJ_NAME                           AS  BIZ_SBJ_NAME                --业务科目名称
					,t.CCY_CD                                 AS  CCY_CD                      --币种代码    
					,t.INCM_AMT                               AS  INCM_AMT                    --收入金额    
					,t.PAY_AMT                                AS  PAY_AMT                     --付出金额    
					,t.ABST                                   AS  ABST                        --摘要        
					,t.CPTL_SRC                               AS  CPTL_SRC                    --资金来源    
					,t.OPRT_TELR                              AS  OPRT_TELR                   --操作柜员    
					,t.RECHK_TELR                             AS  RECHK_TELR                  --复核柜员    
					,t.SYS_SRC                                AS  CGY                         --类别        
					,t.SECOND_CARD_VRFCTN                     AS  SECOND_CARD_VRFCTN              --二代证验证
      				,a2.CTF_CGY_CD_NAME           AS   CTF_CGY  --开户证件类别
  FROM  		DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS             t
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a1
  ON            t.CUST_NO = a1.CUST_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD     a2
  ON            a1.CTF_CGY_CD = a2.CTF_CGY_CD
  WHERE 		t.bus_date = %d{yyyyMMdd}
  AND           t.BIZ_SBJ IN ('10401','10402','10301','10302','10499','10399')
  AND           t.SYS_SRC IN ('普通账户','信用账户')
  ORDER BY      t.BRH_NO,t.DT
;
-----------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_MNS_BULEPATCH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_MNS_BULEPATCH;
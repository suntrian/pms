------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:同一业务风险信息集中管理                                                                      */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
create table RISK_INDEX.HISBUSINESSRISK_TEMP
AS
select a3.tradedate ,a3.busi_type,a3.credit_limit from 
(select    max(dt) as tradedate, 
           '1' as busi_type,  
		   sum(sqed) as credit_limit 
from       jzjycx.securities_tzyhgjyed 
where      dt= '%d{yyyyMMdd}' 
and        type = 1 
and        khh in (select khh from jzjycx.datacenter_tkhxx where  dt= '%d{yyyyMMdd}' and  khzt <> 3)
union all 
select     max(dt) as tradedate, 
           '2' as busi_type,
		   sum(sqed) as credit_limit  
from       jzjycx.securities_tydghjyed 
where      dt= '%d{yyyyMMdd}' 
and        khh in (select khh from jzjycx.datacenter_tkhxx where  dt= '%d{yyyyMMdd}' and khzt <> 3)
union all 
select     max(dt) as tradedate,
           '3' as busi_type,  
		   sum(rzxyed + rqxyed) 
from       rzrqcx.margin_txy_htxx 
where      dt= '%d{yyyyMMdd}' 
and        khh in (select khh from jzjycx.datacenter_tkhxx where  dt= '%d{yyyyMMdd}' and khzt <> 3)) a3;


--------------插入数据-------------------
INSERT OVERWRITE RISK_INDEX.HISBUSINESSRISK
(
         TRADEDATE            --日期                                             
        ,UNIT_CODE            --所属机构（1、国泰君安证券；2、上海证券          
        ,BUSI_TYPE            --业务类别(1、股票质押；2、约定购回；3、融资融券)
        ,GUAR_RAT             --整体维持担保（履约保障）比例                    
        ,PLEDGE_ASSET         --担保资产                                        
        ,PLEDGE_ASSET_CHG     --担保资产较上期增减                              
        ,TOTAL_DEBTS          --负债                                            
        ,TOTAL_DEBTS_CHG      --负债较上期增减                                  
        ,RECOURSE_AMT         --追偿金额                                        
        ,RECOURSE_AMT_CHG     --追偿金额较上期增减
        ,CREDIT_LIMIT		
 ) 
PARTITION(DT = '%d{yyyyMMdd}')
SELECT       CAST(t.OC_DATE AS CHAR(8) )                                                      AS TRADEDATE
            ,CAST('2' AS VARCHAR(160) )                                                       AS UNIT_CODE
			,CAST(t.BUSI_TYPE AS VARCHAR(200) )                                               AS BUSI_TYPE
			,CAST(DECODE(t.BALANCE,0,0,t.ASSET_BALANCE*1.0000/t.BALANCE) AS DECIMAL(20,4) )   AS GUAR_RAT
            ,CAST(t.ASSET_BALANCE AS DECIMAL(20,4) )                                          AS PLEDGE_ASSET
			,CAST(t.ASSET_BALANCE-NVL(a2.PLEDGE_ASSET,0) AS DECIMAL(20,4) )                   AS PLEDGE_ASSET_CHG
			,CAST(t.BALANCE AS DECIMAL(20,4) )                                                AS TOTAL_DEBTS
			,CAST(t.BALANCE-NVL(a2.TOTAL_DEBTS,0) AS DECIMAL(20,4) )                          AS TOTAL_DEBTS_CHG
            ,CAST(t.RECOURSE_AMT AS DECIMAL(20,4) )                                           AS RECOURSE_AMT
			,CAST(t.RECOURSE_AMT-NVL(a2.RECOURSE_AMT,0) AS DECIMAL(20,4) )                    AS RECOURSE_AMT_CHG
			,CAST(a3.CREDIT_LIMIT AS DECIMAL(20,4))                                           AS CREDIT_LIMIT
 FROM 
(SELECT      t.OC_DATE                            AS OC_DATE
            ,CASE WHEN a1.BUSINESS_TYPE = '3'  
                  THEN  '3' 
                  ELSE '1' 
                  END                             AS BUSI_TYPE
            ,SUM(NVL(a1.ASSET_BALANCE,0))         AS ASSET_BALANCE 
		    ,SUM(t.BALANCE)                       AS BALANCE
		    ,SUM(CASE WHEN a1.BUSINESS_TYPE = '3' AND NVL(a1.ASSET_BALANCE,0) < NVL(t.BALANCE,0)
                      THEN NVL(a1.ASSET_BALANCE,0) - NVL(t.BALANCE,0)
			          ELSE 0 
					  END)                        AS RECOURSE_AMT 
FROM       HSFK.HSMAN_HISCLIENTFINANCING t
LEFT JOIN  HSFK.HSMAN_HISCLIENTASSET a1
ON         t.CLIENT_ID             = a1.CLIENT_ID
AND        t.BRANCH_NO = a1.BRANCH_NO
AND        t.OC_DATE   = a1.OC_DATE
AND        ((t.BUSINESS_TYPE = '1' AND a1.BUSINESS_TYPE = '3') 
	        OR (t.BUSINESS_TYPE = '3' AND a1.BUSINESS_TYPE = '5'))
WHERE      t.OC_DATE = %d{yyyyMMdd}
AND        t.BUSINESS_TYPE in ('1','2','3')
AND        a1.BUSINESS_TYPE in ('3','5')
GROUP BY   OC_DATE,BUSI_TYPE
		   )                        t
LEFT JOIN  (SELECT   a.BUSI_TYPE
                     ,a.PLEDGE_ASSET
                     ,a.TOTAL_DEBTS
                     ,a.RECOURSE_AMT
             FROM   RISK_INDEX.HISBUSINESSRISK  a
			
			 
             WHERE EXISTS(SELECT 1 
                          FROM     EDW_PROD.T_EDW_T99_TRD_DATE b
                          WHERE    b.BUS_DATE                             = %d{yyyyMMdd}
                          AND      b.TRD_DT                               = %d{yyyyMMdd}
                          AND      CAST( a.TRADEDATE AS DECIMAL(38,0) )   = b.LST_TRD_D
                         )
			 )a2
  ON t.BUSI_TYPE = a2.BUSI_TYPE
  LEFT JOIN RISK_INDEX.HISBUSINESSRISK_TEMP a3
  on        t.BUSI_TYPE = a3.BUSI_TYPE
UNION ALL
select                 CAST(dt AS CHAR(8))           AS tradedate
                      ,CAST('2' AS VARCHAR(160))          AS UNIT_CODEPLEDGE_ASSET
                      ,CAST('2' AS VARCHAR(200))          AS busi_type

                      ,NULL                               AS GUAR_RATRECOURSE_AMT
                      ,NULL                               AS PLEDGE_ASSET
                      ,NULL                               AS PLEDGE_ASSET_CHG
                      ,NULL                               AS TOTAL_DEBTS
                      ,NULL                               AS TOTAL_DEBTS_CHG
                      ,NULL                               AS RECOURSE_AMT
                      ,NULL                               AS RECOURSE_AMT_CHG
				      ,CAST(sum(sqed) AS DECIMAL(20,4))   as credit_limit    
from                  jzjycx.securities_tydghjyed 
where                 dt= '%d{yyyyMMdd}' 
and                   khh in (select khh from jzjycx.datacenter_tkhxx where  dt= '%d{yyyyMMdd}' and khzt <> 3)
group by              dt;

--删除表
DROP TABLE IF EXISTS RISK_INDEX.HISBUSINESSRISK_TEMP;
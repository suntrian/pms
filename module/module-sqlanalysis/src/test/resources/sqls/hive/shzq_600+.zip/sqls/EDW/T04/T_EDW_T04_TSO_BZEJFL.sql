--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:标准二级清算费率表                                                                   */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
  TRUNCATE TABLE EDW_PROD.T_EDW_T04_TSO_BZEJFL;
------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T04_TSO_BZEJFL
(
                                    YYB                                 --营业部                                
                                   ,JYS                                 --交易所                                
                                   ,SOP_BDZQPZ                          --标的证券品种                               
                                   ,SOP_FYLB                            --期权费用类别                             
                                   ,SOP_MMFX                            --买卖方向                               
                                   ,SOP_KPCBZ                           --开平仓标志                              
                                   ,SOP_BDBQ                            --备兑标签                               
                                   ,SOP_FYJSFS                          --个股期权费用计算方式                         
                                   ,FL                                  --费用参数                               
                                   ,XX                                  --费用下限                               
                                   ,SX                                  --费用上限        
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    CAST(COALESCE(t7.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZQLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as SOP_BDZQPZ                          --证券类型                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.FYLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as SOP_FYLB                            --费用类别                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.MMFX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as SOP_MMFX                            --买卖方向                                
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.KPBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as SOP_KPCBZ                           --开平标志                                
                                   ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.BDBQ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as SOP_BDBQ                            --备兑标签                                
                                   ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as SOP_FYJSFS                          --计算方式                                
                                   ,t.FL                                  as FL                                  --费用参数                                
                                   ,t.XX                                  as XX                                  --费用下限                                
                                   ,t.SX                                  as SX                                  --费用上限   
                                   ,'GGQQ'	                              as XTBS							   
FROM 		   GGQQCX.SOPTION_TSO_BZEJFL 						t
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t1 
ON             t1.DMLX = 'SOP_BDZQPZ'
AND            t1.YXT = 'GGQQ'
AND            t1.YDM = CAST(t.ZQLX AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t2 
ON             t2.DMLX = 'SOP_FYLB'
AND            t2.YXT = 'GGQQ'
AND            t2.YDM = CAST(t.FYLB AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t3 
ON             t3.DMLX = 'SOP_MMFX'
AND            t3.YXT = 'GGQQ'
AND            t3.YDM = CAST(t.MMFX AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t4 
ON             t4.DMLX = 'SOP_KPCBZ'
AND            t4.YXT = 'GGQQ'
AND            t4.YDM = CAST(t.KPBZ AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t5
ON             t5.DMLX = 'SOP_BDBQ'
AND            t5.YXT = 'GGQQ'
AND            t5.YDM = CAST(t.BDBQ AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t6 
ON             t6.DMLX = 'SOP_FYJSFS'
AND            t6.YXT = 'GGQQ'
AND            t6.YDM = CAST(t.JSFS AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t7
ON             t7.YXT = 'GGQQ'
AND            t7.JGDM = CAST(t.YYB AS VARCHAR(20))
WHERE 		   t.DT = '%d{yyyyMMdd}';
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TSO_BZEJFL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
INVALIDATE METADATA DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_KUDU ;
INVALIDATE METADATA DDW_PROD.T_DDW_INR_ORG_BRH_KUDU ;
INVALIDATE METADATA DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_KUDU ;
INVALIDATE METADATA DDW_PROD.T_DDW_F00_CUST_CUST_INFO_KUDU ;
INVALIDATE METADATA DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_KUDU ;
INVALIDATE METADATA DDW_PROD.FINEDB_IMPORT_WZPROD_KUDU ;
INVALIDATE METADATA DDW_PROD.T_DDW_F10_CUST_PROD_DAY_KUDU ;  
INVALIDATE METADATA DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU ;

INVALIDATE METADATA DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_KUDU ;
------------1-----------------
DELETE FROM DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_KUDU ;

INSERT INTO DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_KUDU 
SELECT REPLACE(uuid(),'-','') AS id
       ,EXG
       ,BRH_NO
       ,BRH_NAME
       ,CUST_NO
       ,CUST_NAME
       ,PLCG_ETMT_MKTVAL
       ,CO_MKTVAL
       ,ETMT_FCTR_CMP
       ,BUS_DATE 

FROM DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP
WHERE BUS_DATE = %d{yyyyMMdd} ;




---------------------------2--------------------
DELETE FROM DDW_PROD.T_DDW_INR_ORG_BRH_KUDU ;
INSERT INTO DDW_PROD.T_DDW_INR_ORG_BRH_KUDU 
SELECT REPLACE(UUID(),'-','') AS ID,BRH_NO,BRH_FULLNM,BRH_SHRTNM,BELTO_FILIL,BELTO_FILIL_CDG,BELTO_PROV,BELTO_CITY,CDG_PFX,BUS_DATE 
FROM DDW_PROD.T_DDW_INR_ORG_BRH ;


---------------------------3--------------------
DELETE FROM DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_KUDU WHERE BUS_DATE = %d{yyyyMMdd};
INSERT INTO DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_KUDU 
SELECT REPLACE(UUID(),'-','') AS ID
      ,CUST_NO
	  ,CUST_NAME
	  ,BRH_NO
	  ,PROD_ACTNO
	  ,PROD_CD
	  ,PROD_NAME
	  ,CCY_CD
	  ,PROD_CL
	  ,ADMIN_CD
	  ,PROD_SHR_QTY
	  ,PROD_NEWST_MKTVAL
	  ,PROD_CGY,BUS_DATE 
FROM DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS
WHERE BUS_DATE = %d{yyyyMMdd} ;

---------------------4--------------------
DELETE FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO_KUDU WHERE BUS_DATE = %d{yyyyMMdd};
INSERT INTO DDW_PROD.T_DDW_F00_CUST_CUST_INFO_KUDU 
SELECT REPLACE(uuid(),'-','') AS id,cust_no,cust_name,                                                            
       BRH_NO,                                                              
       BRH_NAME,                                                            
       OPNAC_MOD,                                                            
       OPNAC_CLNT,                                                          
       OPNAC_DT ,                                                     
       ORDI_OPNAC_DT ,                                                 
       CRD_OPNAC_DT ,                                                  
       WRNT_OPNAC_DT ,                                                
       CNCLACT_DT ,                                                   
       ORDI_CNCLACT_DT ,                                               
       CRD_CNCLACT_DT ,                                               
       WRNT_CNCLACT_DT ,                                              
       ORDI_CUST_GROUP ,
       CRD_CUST_GROUP ,
       WRNT_CUST_GROUP ,
       CTF_CGY_CD ,
       CTF_NO ,
       CUST_CGY ,
       CUST_STAT ,
       ORDI_CUST_STAT ,
       CRD_CUST_STAT ,
       WRNT_CUST_STAT ,
       GNDR_CD ,
       DEPMGT_BANK ,
       CTRL_ATTR ,
       M_LAUND_RSK_LVL ,
       M_LAUND_RSK_IDSTR_CGY_CD ,
       RSK_BEAR_ABLTY ,
       IMAGE_TP ,
       CTF_EXPR_DT ,                                                  
       CTCT_ADDR ,
       CTCT_TEL ,
       CTCT_PSN_NAME ,
       PHONE ,
       BRTH_YM ,                                                      
       EDU_CD ,
       OCP_CD ,
       SECOND_CARD_VRFCTN ,
       CUST_RSK_LVL ,
       FRIST_EVAL_DT ,                                                
       CMSN_SETUP_DT ,                                                
       CMSN_SETUP_ABST ,
       IF_OPN_PHONE_ODR ,
       ORDI_ODR_MOD_SCP ,                                             
       CRD_ODR_MOD_SCP ,                                              
       WRNT_ODR_MOD_SCP ,                                             
       CTF_ADDR ,
       CITY_CD ,
       NATN_CD ,
       MARG_STAT_CD ,
       AGE ,                                                          
       CID ,
       BUS_DATE 
FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO 
WHERE BUS_DATE=%d{yyyyMMdd} 
;
   
---------------------5-------------------- 
DELETE FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_KUDU WHERE BUS_DATE = %d{yyyyMMdd};
INSERT INTO DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_KUDU SELECT REPLACE(uuid(),'-','') AS id,
            CUST_NO ,                                                            
            BRH_NO ,                                                             
            CUST_CGY ,                                                           
            MKTVAL_HA ,                                                   
            ORDI_MKTVAL_HA ,                                              
            CRD_MKTVAL_HA ,                                               
            MKTVAL_SA ,                                                   
            ORDI_MKTVAL_SA ,                                              
            CRD_MKTVAL_SA ,                                               
            MKTVAL_SMS ,                                                  
            ORDI_MKTVAL_SMS ,                                             
            CRD_MKTVAL_SMS ,                                              
            MKTVAL_GEM ,                                                  
            ORDI_MKTVAL_GEM ,                                             
            CRD_MKTVAL_GEM ,                                              
            ORDI_MKTVAL_HB_USD ,                                          
            ORDI_MKTVAL_SB_HKD ,                                          
            ORDI_MKTVAL_HK ,
            ORDI_MKTVAL_SK ,                                              
            ORDI_MKTVAL_TA ,                                              
            ORDI_MKTVAL_TU_USD ,                                          
            ORDI_MKTVAL_REPO ,                                            
            ORDI_MKTVAL_EXG_FND ,                                         
            ORDI_MKTVAL_CLS_FND ,                                         
            ORDI_MKTVAL_ETF_FND ,                                         
            ORDI_MKTVAL_OPN_FND ,                                         
            ORDI_MKTVAL_LOF_FND ,                                         
            ORDI_MKTVAL_FOF_FND ,                                         
            CRD_MKTVAL_EXG_FND ,                                          
            CRD_MKTVAL_CLS_FND ,                                          
            CRD_MKTVAL_ETF_FND ,                                          
            CRD_MKTVAL_OPN_FND ,                                          
            CRD_MKTVAL_LOF_FND ,                                          
            CRD_MKTVAL_FOF_FND ,                                          
            ORDI_MKTVAL_BOND ,                                            
            CRD_MKTVAL_BOND ,                                             
            AGN_FND_MKTVAL ,                                              
            GS_PROD_MKTVAL ,                                              
            GJ_PROD_MKTVAL ,                                              
            BANK_PROD_MKTVAL ,                                            
            OTC_PROD_MKTVAL ,                                             
            WRNT_RGHT_HLD_MKTVAL ,                                        
            WRNT_DUTY_HLD_MKTVAL ,                                        
            ORDI_MKTVAL_SEC_USD ,                                         
            ORDI_MKTVAL_SEC_HKD ,                                         
            ORDI_MKTVAL_SEC_RMD ,                                         
            ORDI_MKTVAL_PROD ,                                            
            ORDI_CPTL_USD ,                                               
            ORDI_CPTL_HKD ,                                               
            ORDI_CPTL_RMB ,                                               
            ORDI_DEPIN_AMT_USD ,                                          
            ORDI_DEPIN_AMT_HKD ,                                          
            ORDI_DEPIN_AMT_RMB ,                                          
            ORDI_TFR_IN_AMT ,                                             
            ORDI_WTHDR_AMT_USD ,                                          
            ORDI_WTHDR_AMT_HKD ,                                          
            ORDI_WTHDR_AMT_RMB ,                                          
            ORDI_TFR_OUT_AMT ,                                            
            CRD_DEPIN_AMT ,                                               
            CRD_TFR_IN_AMT ,                                              
            CRD_WTHDR_AMT ,                                               
            CRD_TFR_OUT_AMT ,                                             
            WRNT_DEPIN_AMT ,                                              
            WRNT_TFR_IN_AMT ,                                             
            WRNT_WTHDR_AMT ,                                              
            WRNT_TFR_OUT_AMT ,                                            
            TFR_IN_AMT ,                                                  
            TFR_OUT_AMT ,                                                 
            ORDI_NET_TFR_IN_AMT ,                                         
            CRD_NET_TFR_IN_AMT ,                                          
            WRNT_NET_TFR_IN_AMT ,                                         
            NET_TFR_IN_AMT ,                                              
            ORDI_ASGN_TFR_IN_MKTVAL_RMB ,                                 
            ORDI_ASGN_TFR_IN_MKTVAL_USD ,                                 
            ORDI_TFR_CSTD_TFR_IN_MKTVAL_RMB ,                             
            ORDI_TFR_CSTD_TFR_IN_MKTVAL_HKD ,                             
            CRD_ASGN_TFR_IN_MKTVAL ,                                      
            CRD_TFR_CSTD_TFR_IN_MKTVAL ,                                  
            ORDI_ASGN_TFR_OUT_MKTVAL_RMB ,                                
            ORDI_ASGN_TFR_OUT_MKTVAL_USD ,                                
            ORDI_TFR_CSTD_TFR_OUT_MKTVAL_RMB ,                            
            ORDI_TFR_CSTD_TFR_OUT_MKTVAL_HKD ,                            
            CRD_ASGN_TFR_OUT_MKTVAL ,                                     
            CRD_TFR_CSTD_TFR_OUT_MKTVAL ,                                 
            ORDI_TFR_IN_MKTVAL ,                                          
            ORDI_TFR_OUT_MKTVAL ,                                         
            CRD_TFR_IN_MKTVAL ,                                           
            CRD_TFR_OUT_MKTVAL ,                                          
            TFR_IN_MKTVAL ,                                               
            TFR_OUT_MKTVAL ,                                              
            ORDI_NET_TFR_IN_MKTVAL ,                                      
            CRD_NET_TFR_IN_MKTVAL ,                                       
            NET_TFR_IN_MKTVAL ,                                           
            ORDI_CPTL ,                                                   
            ORDI_UNPY_CPTL ,                                              
            CRD_UNPY_CPTL ,                                               
            WRNT_UNPY_CPTL ,                                              
            CRD_CPTL ,                                                    
            WRNT_CPTL ,                                                   
            TOT_UNPY_CPTL ,                                               
            TOT_CPTL ,                                                    
            ORDI_SEC_MKTVAL ,                                             
            ORDI_MKTVAL ,                                                 
            ORDI_UN_CIR_MKTVAL ,                                          
            CRD_SEC_MKTVAL ,                                              
            WRNT_MKTVAL ,                                                 
            WRNT_CNTS ,                                                   
            TOT_MKTVAL ,                                                  
            ORDI_GL ,                                                     
            CRD_GL ,                                                      
            TOTGL ,                                                       
            ORDI_AST_UN_OTC ,                                             
            ORDI_AST ,                                                    
            ORDI_NET_AST_UN_OTC ,                                         
            ORDI_NET_AST ,                                                
            CRD_AST ,                                                     
            CRD_NET_AST ,                                                 
            WRNT_AST ,                                                    
            TOT_AST ,                                                     
            EXG_NET_TOT_AST ,                                             
            NET_TOT_AST ,                                                 
            ORDI_PRFT ,                                                   
            CRD_PRFT ,                                                    
            WRNT_PRFT ,                                                   
            TOT_PRFT ,                                                    
            ORDI_MKTVAL_EXG_FND_SH ,                                      
            ORDI_MKTVAL_EXG_FND_SZ ,                                      
            CRD_MKTVAL_EXG_FND_SH ,                                       
            CRD_MKTVAL_EXG_FND_SZ ,                                       
            ORDI_MKTVAL_BOND_SH ,                                         
            ORDI_MKTVAL_BOND_SZ ,                                         
            CRD_MKTVAL_BOND_SH ,                                          
            CRD_MKTVAL_BOND_SZ ,                                          
            ORDI_UN_CIR_MKTVAL_SH ,                                       
            ORDI_UN_CIR_MKTVAL_SZ ,                                       
            STK_PLG_AMT ,                                                 
            STK_PLG_ADD_INT ,
            STK_PLG_ADD_TRD_AMT ,                                         
            MIN_STK_PLG_AMT ,                                             
            MIN_STK_PLG_ADD_INT ,                                         
            MIN_STK_PLG_ADD_TRD_AMT ,                                     
            ORDI_MKTVAL_NEW_TA ,                                          
            ORDI_MKTVAL_AK_STIB ,                                         
            ORDI_MKTVAL_RK_STIB ,                                         
            CRD_MKTVAL_AK_STIB ,                                          
            CRD_MKTVAL_RK_STIB, 
            BUS_DATE 
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
  WHERE BUS_DATE = %d{yyyyMMdd};  

---------------------6-------------------- 
DELETE FROM DDW_PROD.T_DDW_F10_CUST_PROD_DAY_KUDU WHERE BUS_DATE = %d{yyyyMMdd};
INSERT INTO DDW_PROD.T_DDW_F10_CUST_PROD_DAY_KUDU 
SELECT         REPLACE(uuid(),'-','') AS id,
               CUST_NO                 --客户号                
              , PROD_CD                 --产品代码
              , PROD_CL_CD              --产品分类代码
              , PROD_CL_NAME            --产品分类名称
              , DATA_SRC                --数据来源
              , BUYIN_AMT               --买入金额
              , SELL_AMT                --卖入金额
              , SCRP_AMT                --认购金额
              , PRCH_AMT                --申购金额
              , FIXINV_AMT              --定投金额
              , RDMPT_AMT               --赎回金额
              , BUYIN_QTY               --买入数量
              , SELL_QTY                --卖入数量
              , SCRP_QTY                --认购数量
              , PRCH_QTY                --申购数量
              , FIXINV_QTY              --定投数量
              , RDMPT_QTY               --赎回数量
              , BNS_AMT                 --红利金额
              , BUYIN_S1                --买入佣金
              , SELL_S1                 --卖出佣金
              , SCRP_S1_CSMN_FEE        --认购佣金及手续费收入
              , PRCH_S1_CSMN_FEE        --申购佣金及手续费收入
              , FIXINV_S1_CSMN_FEE      --定投佣金及手续费收入
              , RDMPT_S1_CSMN_FEE       --赎回佣金及手续费收入
			  , S1_CSMN_FEE             --佣金及手续费收入			  
              , HLD_AMT                 --持仓金额
              , HLD_QTY                 --持仓数量
              , MAIN_SALE_FLG           --重点销售标志
              , IF_TRD_DATE             --是否交易日	  
              ,BUS_DATE
FROM DDW_PROD.T_DDW_F10_CUST_PROD_DAY
WHERE BUS_DATE = %d{yyyyMMdd} ;


---------------------7-------------------- 
DELETE FROM DDW_PROD.FINEDB_IMPORT_WZPROD_KUDU ;
INSERT INTO DDW_PROD.FINEDB_IMPORT_WZPROD_KUDU 

SELECT REPLACE(uuid(),'-','') AS id    
       ,ASS_MLTP	
       ,FND_CGY	
       ,PROD_CD	
       ,PROD_NAME
FROM C5CX.FINEDB_IMPORT_WZPROD ;

DELETE FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU WHERE BUS_DATE = %d{yyyyMMdd};
INSERT INTO DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU 
SELECT     REPLACE(uuid(),'-','') AS id 
          ,BELTO_FILIL_CDG               --分公司编码
          ,BELTO_FILIL                    --分公司名称
          ,BRH_NO                         --营业部编码
          ,BRH_FULLNM                     --营业部名称
          ,CUST_STAR                      --客户星级
          ,CUST_VOL                       --客户数
          ,TRD_CUST_VOL                   --交易客户客户数
          ,ADDED_VLD_CUST_VOL             --新增有效客户数
          ,ADDED_OLD_VLD_CUST_VOL         --新增存量有效客户数
          ,CRD_CUST_VOL                   --信用客户数
          ,TRD_CRD_CUST_VOL               --交易信用客户数
          ,H_K_CUST_VOL                   --港股通客户数
          ,TRD_H_K_CUST_VOL               --交易港股通客户数
          ,WRNT_CUST_VOL                  --期权客户数
          ,TRD_WRNT_CUST_VOL              --交易期权客户数
          ,STIB_CUST_VOL                  --科创板客户数
		  ,TRD_STIB_CUST_VOL              --交易科创板客户数
          ,NEW_T3BOD_CUST_VOL             --新三板客户数(受限制+非受限制)
          ,TRD_NWE_T3BOD_CUST_VOL         --交易新三板客户数
          ,T3BOD_CUST_VOL                 --三板客户数
          ,PLG_REPO_CUST_VOL              --质押回购客户数(股票质押)
          ,STK_PLG_CUST_VOL               --股票质押客户数(小微贷)
		  ,TRD_PLG_REPO_CUST_VOL          --交易质押回购客户数(股票质押)
          ,TRD_STK_PLG_CUST_VOL           --交易股票质押客户数(小微贷)		  		  
          ,STR_FND_CUST_VOL               --分级基金客户数
          ,PROD_CUST_VOL                  --产品客户数
          ,INR_PB_CUST_VOL                --内部PB账户数
          ,EXTN_PB_CUST_VOL               --外部PB账户数
          ,CASH_PROD_CUST_VOL             --现金添利客户数
          ,QLFD_CUST_VOL                  --合格客户数
          ,BROK_RLN_QLFD_CUST_VOL         --经纪关系合格客户数
          ,STRONG_SVC_RLN_QLFD_CUST_VOL   --强服务关系合格客户数
          ,WEAK_SVC_RLN_QLFD_CUST_VOL     --弱服务关系合格客户数
		  ,BROK_RLN_CUST_VOL              --经纪关系客户数
		  ,STRONG_SVC_RLN_CUST_VOL        --强服务关系客户数
		  ,WEAK_SVC_RLN_CUST_VOL          --弱服务关系客户数
          ,OPNAC_CUST_VOL                 --开户数(当日)
          ,OPNAC_CRD_CUST_VOL             --开户信用客户数(当日)
          ,OPNAC_WRNT_CUST_VOL            --开户期权客户数(当日)
          ,OPN_STIB_CUST_VOL              --开通科创板客户数(当日) 
          ,OPN_H_K_CUST_VOL               --开通港股通客户数(当日)			  
          ,OPN_PLG_REPO_CUST_VOL          --开通质押回购客户数(股票质押)(当日)
          ,OPN_STK_PLG_CUST_VOL           --开通股票质押客户数(小微贷)(当日)
          ,OPN_STR_FND_CUST_VOL           --开通分级基金客户数
          ,OPN_NEW_T3BOD_CUST_VOL         --开通新三板客户数(受限制当日+非受限制当日)
          ,OPN_T3BOD_CUST_VOL             --开通三板客户数(当日)
		  ,OPNAC_INR_PB_CUST_VOL          --开户内部PB客户数(当日)
          ,CNCLACT_CUST_VOL               --销户数(当日)
          ,CNCLACT_CRD_CUST_VOL           --销户信用客户数(当日)
          ,CNCLACT_WRNT_CUST_VOL          --销户期权客户数(当日)
          ,CLS_STIB_CUST_VOL              --关闭科创板客户数(当日)
          ,CLS_H_K_CUST_VOL               --关闭港股通客户数(当日)
          ,CLS_PLG_REPO_CUST_VOL          --关闭质押回购客户数(股票质押)(当日)
          ,CLS_STK_PLG_CUST_VOL           --关闭股票质押客户数(小微贷)(当日)
          ,CLS_STR_FND_CUST_VOL           --关闭分级基金客户数
          ,CLS_NEW_T3BOD_CUST_VOL         --关闭新三板客户数(受限制当日+非受限制当日)
          ,CLS_T3BOD_CUST_VOL             --关闭三板客户数(当日)
          ,CUST_TOT_AST                   --客户总资产
          ,CUST_NET_TOT_AST               --客户净资产
          ,BROK_RLN_CUST_NET_TOT_AST      --经纪关系净资产
          ,STRONG_SVC_CUST_NET_TOT_AST    --强服务关系净资产
          ,WEAK_SVC_CUST_NET_TOT_AST      --弱服务关系净资产
          ,NEW_OPNAC_NET_TOT_AST          --新开户净资产
          ,ADDED_VLD_NET_TOT_AST          --新增有效户净资产
          ,ADDED_OLD_VLD_NET_TOT_AST      --存量有效户净资产
          ,NET_TFR_IN_AST                 --资产净流入
          ,STK_TRD_VOL                    --股票交易量
          ,BROK_RLN_STK_TRD_VOL           --经纪关系股票交易量
          ,STRONG_SVC_STK_TRD_VOL         --强服务关系股票交易量
          ,WEAK_SVC_STK_TRD_VOL           --弱服务关系股票交易量
          ,FND_TRD_VOL                    --基金交易量
          ,BROK_RLN_FND_TRD_VOL           --经纪关系基金交易量
          ,STRONG_SVC_FND_TRD_VOL         --强服务关系基金交易量
          ,WEAK_SVC_FND_TRD_VOL           --弱服务关系基金交易量
          ,H_K_TRD_VOL                    --港股通交易量
          ,BROK_RLN_H_K_TRD_VOL           --经纪关系港股通交易量
          ,STRONG_SVC_H_K_TRD_VOL         --强服务关系港股通交易量
          ,WEAK_SVC_H_K_TRD_VOL           --弱服务关系港股通交易量
          ,NEW_T3BOD_TRD_VOL              --新三板交易量
          ,BROK_RLN_NEW_T3BOD_TRD_VOL     --经纪关系新三板交易量
          ,STRONG_SVC_NEW_T3BOD_TRD_VOL   --强服务关系新三板交易量
          ,WEAK_SVC_NEW_T3BOD_TRD_VOL     --弱服务关系新三板交易量
          ,CRD_TRD_VOL                    --融资融券交易量
		  ,BROK_RLN_CRD_TRD_VOL           --经纪关系融资融券交易量
          ,STRONG_SVC_RLN_CRD_TRD_VOL         --强服务关系融资融券交易量
          ,WEAK_SVC_RLN_CRD_TRD_VOL           --弱服务关系融资融券交易量
          ,TDY_ADDED_MRGNC_INT            --当日新增融资利息
          ,TDY_ADDED_MRGNS_INT            --当日新增融券利息
          ,STK_PLG_AMT                    --股票质押余额
          ,STK_PLG_ADD_INT                --股票质押新增利息
          ,STK_PLG_ADD_TRD_AMT            --股票质押初始交易量
          ,MIN_STK_PLG_AMT                --小微贷余额
          ,MIN_STK_PLG_ADD_INT            --小微贷新增利息
          ,MIN_STK_PLG_ADD_TRD_AMT        --小微贷初始交易量
          ,STK_NET_S1                     --股票净佣金
          ,BROK_RLN_STK_NET_S1            --经纪关系股票净佣金
          ,STRONG_SVC_STK_NET_S1          --强服务关系股票净佣金
          ,WEAK_SVC_STK_NET_S1            --弱服务关系股票净佣金
          ,FND_NET_S1                     --基金净佣金
          ,BROK_RLN_FND_NET_S1            --经纪关系基金净佣金
          ,STRONG_SVC_FND_NET_S1          --强服务关系基金净佣金
          ,WEAK_SVC_FND_NET_S1            --弱服务关系基金净佣金
          ,H_K_NET_S1                     --港股通净佣金
          ,BROK_RLN_H_K_NET_S1            --经纪关系港股通净佣金
          ,STRONG_SVC_H_K_NET_S1          --强服务关系港股通净佣金
          ,WEAK_SVC_H_K_NET_S1            --弱服务关系港股通净佣金
          ,NEW_T3BOD_NET_S1               --新三板净佣金
          ,BROK_RLN_NEW_T3BOD_NET_S1      --经纪关系新三板净佣金
          ,STRONG_SVC_NEW_T3BOD_NET_S1    --强服务关系新三板净佣金
          ,WEAK_SVC_NEW_T3BOD_NET_S1      --弱服务关系新三板净佣金
          ,CPTL_BAL                       --资金余额
          ,A_STK_MKTVAL                   --A股票市值
          ,B_STK_MKTVAL                   --B股票市值
          ,H_K_STK_MKTVAL                 --港股股票市值
          ,TRD_VOL                        --交易量
          ,NET_S1_INCM                    --净佣金收入
          ,INT_INCM                       --息费收入
          ,A_STK_NET_S1                   --A股净佣金
          ,A_STK_TRD_VOL                  --A股交易量
          ,MRGNC_CPTL_BAL                 --融资余额
          ,MRGNS_CPTL_BAL                 --融券余额  
          ,BUS_DATE 		  
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY
WHERE BUS_DATE = %d{yyyyMMdd} ;

DELETE FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_KUDU WHERE BUS_DATE = %d{yyyyMMdd};
INSERT INTO DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_KUDU 
SELECT     REPLACE(uuid(),'-','') AS id 
,CUST_NO                       --客户号
, CUST_NAME                     --客户姓名  
, BRH_NO                        --营业部编号       
, BRH_NAME                      --营业部名称       
, CUST_STAR                     --客户星级
, CUST_RLN                      --客户关系
, BROK_RLN_PSN_NO               --经纪关系人员编号
, BROK_RLN_PSN_NAME             --经纪关系人员姓名
, BROK_RLN_PSN_BRH_NO           --经纪关系人员营业部
, SVC_RLN_PSN_NO                --服务关系人员编号
, SVC_RLN_PSN_NAME              --服务关系人员姓名
, SVC_RLN_PSN_BRH_NO            --服务关系人员营业部
, SVC_RLN_PSN_CGY               --服务关系人员类别
, FSTTM_DT_AST_1000             --首次资产达到1000的日期
, FSTTM_DT_AST_0                --首次有资产日期
, VLD_DT                        --有效日期
, CUST_CGY                      --客户类别
, BRTH_YM                       --出生年月
, AGE                           --年龄
, EDU_CD                        --学历代码
, OCP_CD                        --职业代码
, GNDR_CD                       --性别代码
, CUST_RSK_LVL                  --客户风险级别
, OPNAC_DT                      --开户日期
, CNCLACT_DT                    --销户日期
, CUST_STAT                     --客户状态
, CRD_OPNAC_DT                  --融资融券开户日期
, CRD_CNCLACT_DT                --融资融券开户日期
, IF_CRD_CNCLACT                --是否销户融资融券
, WRNT_OPNAC_DT                 --期权开户日期
, WRNT_CNCLACT_DT               --期权销户日期
, IF_WRNT_CNCLACT               --是否销户期权账户
, H_K_OPNAC_DT                  --港股通开户日期
, H_K_CNCLACT_DT                --港股通销户日期
, IF_H_K                        --是否销户港股通
, HK_OPNAC_DT                   --沪港通开户日期
, HK_CNCLACT_DT                 --沪港通销户日期
, IF_HK                         --是否销户沪港通 
, SK_OPNAC_DT                   --深港通开户日期
, SK_CNCLACT_DT                 --深港通销户日期
, IF_SK                         --是否销户深港通 							  
, NEW_T3BOD_OPNAC_DT            --新三板开通日期
, NEW_T3BOD_CNCLACT_DT          --新三板销户日期
, IF_NEW_T3BOD                  --是否销户新三板
, T3BOD_OPNAC_DT                --三板开通日期
, T3BOD_CNCLACT_DT              --三板销户日期
, IF_T3BOD                      --是否销户三板
, REPO_MRGNC_OPNAC_DT           --回购融资开通日期
, REPO_MRGNC_CNCLACT_DT         --回购融资销户日期
, IF_REPO_MRGNC                 --是否销户回购融资
, REPO_MRGNS_OPNAC_DT           --回购融券开通日期
, REPO_MRGNS_CNCLACT_DT         --回购融券销户日期
, IF_REPO_MRGNS                 --是否销户回购融券

, GEM_OPNAC_DT                  --创业板开通日期
, GEM_CNCLACT_DT                --创业板销户日期
, IF_GEM                        --是否销户创业板
, DLSTG_OPNAC_DT                --退市整理开通日期
, DLSTG_CNCLACT_DT              --退市整理销户日期
, IF_DLSTG                      --是否销户退市整理
, BOND_QLFD_IVSM_OPNAC_DT       --债券合格投资开通日期
, BOND_QLFD_IVSM_CNCLACT_DT     --债券合格投资销户日期
, IF_BOND_QLFD_IVSM             --是否销户债券合格投资
, QOT_REPO_OPNAC_DT             --报价回购开通日期
, QOT_REPO_CNCLACT_DT           --报价回购销户日期
, IF_QOT_REPO                   --是否销户报价回购
, PROMS_RPHS_OPNAC_DT           --约定购回开通日期
, PROMS_RPHS_CNCLACT_DT         --约定购回销户日期
, IF_PROMS_RPHS                 --是否销户约定购回
, PLG_REPO_OPNAC_DT             --质押回购开通日期(股票质押)
, PLG_REPO_CNCLACT_DT           --质押回购销户日期(股票质押)
, IF_PLG_REPO                   --是否销户质押回购(股票质押)
, STK_PLG_OPNAC_DT              --股票质押开通日期(小微贷)
, STK_PLG_CNCLACT_DT            --股票质押销户日期(小微贷)
, IF_STK_PLG                    --是否销户股票质押(小微贷)
, STR_FND_OPNAC_DT              --分级基金开通日期
, STR_FND_CNCLACT_DT            --分级基金销户日期
, IF_STR_FND                    --是否销户分级基金
, STIB_OPNAC_DT                 --科创板开通日期
, STIB_CNCLACT_DT               --科创板开通日期
, IF_STIB                       --是否销户科创板
, IB_CUST_FLG                   --IB客户标志 
, CRD_FSTTM_TRD_DT              --信用账户首次交易日期
, PLG_REPO_FSTTM_TRD_DT         --质押回购首次交易日期(股票质押)
, STK_PLG_FSTTM_TRD_DT	        --股票质押首次交易日期(小微贷) 
, LMT_NEW_T3BOD_OPNAC_DT        --新三板开通日期(受限制)
, LMT_NEW_T3BOD_CNCLACT_DT      --新三板销户日期(受限制)
, IF_LMT_NEW_T3BOD              --是否销户新三板(受限制)
, CASH_PROD_OPNAC_DT            --现金添利开通日期
, CASH_PROD_CNCLACT_DT          --现金添利销户日期
, IF_CASH_PROD                  --是否销户现金添利
, CASH_PROD_FSTTM_TRD_DT        --现金添利首次交易日期
, BUS_DATE
FROM DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL
WHERE BUS_DATE = %d{yyyyMMdd} ;


INVALIDATE METADATA DDW_PROD.T_DDW_PRT_PLCG_ETMT_CMP_KUDU ;
INVALIDATE METADATA DDW_PROD.T_DDW_INR_ORG_BRH_KUDU ;
INVALIDATE METADATA DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS_KUDU ;
INVALIDATE METADATA DDW_PROD.T_DDW_F00_CUST_CUST_INFO_KUDU ;
INVALIDATE METADATA DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY_KUDU ;
INVALIDATE METADATA DDW_PROD.FINEDB_IMPORT_WZPROD_KUDU ;
INVALIDATE METADATA DDW_PROD.T_DDW_F10_CUST_PROD_DAY_KUDU ;  
INVALIDATE METADATA DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_KUDU ;
INVALIDATE METADATA DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL_KUDU ;
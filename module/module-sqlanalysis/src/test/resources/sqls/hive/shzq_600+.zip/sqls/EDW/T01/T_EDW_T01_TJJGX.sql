-- /* ***************************************** SQL Begin ***************************************** */
 -- /* 脚本功能:经纪人关系表                                                                  */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
   TRUNCATE TABLE EDW_PROD.T_EDW_T01_TJJGX ; 
--------插入数据开始-------------
INSERT OVERWRITE EDW_PROD.T_EDW_T01_TJJGX
(                                         ID                      --主键
										 ,JJR                     --经纪人
										 ,JSZH                    --结算账户
										 ,JJRYYB                  --营业部
										 ,KHH                     --客户号
										 ,FWGXLX                  --关系类型
										 ,KHGX                    --考核关系
										 ,KHPZ                    --考核品种
										 ,TCFS                    --提成方式
										 ,YXLB                    --有效类别
										 ,KHJYE                   --
										 ,YMZC                    --月末资产
										 ,SYQZ                    --收益权重
										 ,ZCQZ                    --资产权重
										 ,CBQZ                    --成本权重
										 ,TJRQ                    --添加日期
										 ,SXRQ                    --生效日期
										 ,ZXRQ                    --注销日期
										 ,JZRQ                    --截止日期
										 ,QDWD                    --代理权限
										 ,YXQRRQ                  --有效确认日期
										 ,YXQRRQ2                 --有效确认日期2
										 ,KHH_DC                  --客户号（薪酬）
										 ,KHJQR                   --
										 ,XYH                     --
                                         ,XTBS										 
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                          t.ID         as ID               --主键
                                         ,t.JJR        as JJR              --经纪人
                                         ,t.JSZH       as JSZH             --结算账户
                                         ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))	     as JJRYYB                      --经纪人营业部							   
                                         ,CAST(t.KHH as STRING)       as KHH            --客户号
                                         ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.GXLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20))         as FWGXLX           --关系类型
                                         ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHGX AS VARCHAR(20))),'ERR')) AS VARCHAR(20))       as KHGX               --考核关系
                                         ,t.KHPZ       as KHPZ               --考核品种
                                         ,t.TCFS       as TCFS               --提成方式
                                         ,t.YXLB       as YXLB               --有效类别
                                         ,t.KHJYE      as KHJYE              --
                                         ,t.YMZC       as YMZC               --月末资产
                                         ,t.SYQZ       as SYQZ               --收益权重
                                         ,t.ZCQZ       as ZCQZ               --资产权重
                                         ,t.CBQZ       as CBQZ               --成本权重
                                         ,t.TJRQ       as TJRQ               --添加日期
                                         ,t.SXRQ       as SXRQ               --生效日期
                                         ,t.ZXRQ       as ZXRQ               --注销日期
                                         ,t.JZRQ       as JZRQ               --截止日期
                                         ,t.QDWD       as QDWD               --代理权限
                                         ,t.YXQRRQ     as YXQRRQ             --有效确认日期
                                         ,t.YXQRRQ2    as YXQRRQ2            --有效确认日期2
                                         ,t.KHH_DC     as KHH_DC             --客户号（薪酬）
                                         ,t.KHJQR      as KHJQR              --
                                         ,t.XYH        as XYH                --	
                                         ,'CRM'         as XTBS										 
 FROM           NEWCRM.CRMII_TJJGX                             t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'CRM'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t2
 ON             t2.YXT = 'CRM'
 AND            t2.YDM = CAST(t.GXLX AS VARCHAR(20))
 AND            t2.dmlx = 'FWGXLX'
  LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING         t3
 ON             t3.YXT = 'CRM'
 AND            t3.YDM = CAST(t.KHGX AS VARCHAR(20))
 AND            t3.dmlx = 'KHGX'
 WHERE   t.DT = '%d{yyyyMMdd}';
--------插入数据结束---------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TJJGX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T01_TJJGX;

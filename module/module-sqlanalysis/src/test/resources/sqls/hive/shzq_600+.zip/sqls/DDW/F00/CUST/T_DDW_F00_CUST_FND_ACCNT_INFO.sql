 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:基金账户信息表                                                                      */
  --/* 创建人:刘桂汝                                                                               */
  --/* 创建时间:2017-10-20                                                                        */ 
  



---------------- 插入集中交易数据开始 -----------------------
 INSERT  OVERWRITE DDW_PROD.T_DDW_F00_CUST_FND_ACCNT_INFO
  (
	                         CUST_NO		                                --客户号
	                        ,TA_CD		                                    --TA代码
	                        ,FND_ACTNO		                                --基金帐号
	                        ,CCY_CD	 	                                    --币种代码
	                        ,OPNAC_DT		                                --开户日期
	                        ,FND_BNS_MOD		                            --基金分红方式
	                        ,FND_ACCNT_CTRL_ATTR		                    --基金帐户控制属性
	                        ,FND_ACCNT_STAT		                            --基金帐户状态
	                        ,FND_ACCNT_CGY		                            --基金账户类别
	                        ,CUST_NAME		                                --基金帐户姓名
	                        ,FND_IDV_CTF_CGY_CD		                        --基金个人证件类别
	                        ,FND_ACCNT_CTF_NO		                        --基金帐户证件编号
	                        ,FND_ACCNT_FZN_DT		                        --基金帐户冻结日期
	                        ,ATTN_NAME		                                --经办人姓名
	                        ,ATTN_CTF_CGY_CD		                        --经办人基金证件类别
	                        ,ATTN_CTF_NO		                            --经办人证件编号
	                        ,LGLPSN_NAME		                            --法人姓名
	                        ,LGLPSN_CTF_CGY_CD		                        --法人基金证件类别
	                        ,LGLPSN_CTF_NO		                            --法人证件编号
	                        ,PSTCD	                                        --邮政编码	
	                        ,ADDR		                                    --地址
	                        ,TEL	                                        --电话	 
	                        ,BRH_NO		                                    --营业部编号
	                        ,BRH_NAME	 	                                --营业部名称 
 )PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT    t.KHH                         as CUST_NO		                                    --客户号
	       ,t.TADM                       as TA_CD		                                    --TA代码
	       ,t.JJZH                       as FND_ACTNO		                                --基金帐号
	       ,t.BZDM                       as CCY_CD	 	                                    --币种代码
	       ,t.KHRQ                       as OPNAC_DT		                                --开户日期
	       ,t.OF_FHFS                    as FND_BNS_MOD		                                --基金分红方式
	       ,t.OF_ZHSX                    as FND_ACCNT_CTRL_ATTR		                        --基金帐户控制属性
	       ,t.OF_JJZHZT                  as FND_ACCNT_ACCNT_STAT		                    --基金基金帐户状态
	       ,CAST(t.OF_ZHLB as STRING)    as FND_ACCNT_ACCNT_CGY		                        --基金账户类别
	       ,t.KHXM                       as CUST_NAME		                                --基金帐户姓名
	       ,t.OF_GRZJLB                  as FND_IDV_CTF_CGY_CD		                        --基金个人证件类别
	       ,t.ZJBH                       as FND_ACCNT_CTF_NO		                        --基金帐户证件编号
	       ,t.ZHDJRQ                     as FND_ACCNT_FZN_DT		                        --基金帐户冻结日期
	       ,t.JBRXM                      as ATTN_NAME		                                --经办人姓名
	       ,t.JBR_OF_GRZJLB              as ATTN_NAME_CTF_CGY_CD		                    --经办人基金证件类别
	       ,t.JBRZJBH                    as ATTN_CTF_NO		                                --经办人证件编号
	       ,t.FRXM                       as LGLPSN_NAME		                                --法人姓名
	       ,t.FR_OF_GRZJLB               as LGLPSN_CTF_CGY_CD		                        --法人基金证件类别
	       ,t.FRZJBH                     as LGLPSN_CTF_NO		                            --法人证件编号
	       ,t.YZBM                       as PSTCD	                                        --邮政编码	
	       ,t.DZ                         as ADDR		                                    --地址
	       ,t.DH                         as TEL	                                            --电话	 
	       ,t.YYB                        as BRH_NO		                                    --营业部编号
	       ,NVL(a2.BRH_SHRTNM,a3.FILIL_DEPT_SHRTNM)    		             as BRH_NAME	 	                                --营业部名称 
 FROM          EDW_PROD.T_EDW_T02_TOF_JJZH   t
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH    a2
 ON             t.YYB = a2.BRH_NO   
 AND           a2.BUS_DATE = %d{yyyyMMdd} 
 LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a3
 ON            t.YYB = a3.FILIL_DEPT_CDG
 AND           a3.BUS_DATE = %d{yyyyMMdd}
 WHERE         t.bus_date = %d{yyyyMMdd}
;

---------------- 插入结束 -----------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_FND_ACCNT_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_FND_ACCNT_INFO ;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:资金帐户统计表                                                                  */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
-----------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZJZHTJ
(
  RQ            --日期
, YYB           --营业部
, ZHGLJG        --帐户管理机构
, YHDM          --银行代码
, KHFLFS        --客户分类方式
, KHFL          --客户分类
, ZJZHLB        --资金帐户类别
, BZDM          --币种代码
, SRYE          --收入金额
, BRBD          --本日变动
, ZJYE          --资金余额
, XYJKFSJE      --信用借款发生金额
, XYJKYE        --信用借款余额
, CKJE          --存款金额
, QKJE          --取款金额
, LXJS          --利息基数
, DZLX          --待转利息
, TZJS          --透支基数
, KHS           --开户数
, XHS           --销户数
, YXHS          --有效户数
, WJSZJ         --未交收资金
, YJLX          --佣金利息           
, XTBS      								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT  t.RQ            as RQ        --日期
      , CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))           as YYB       --营业部
      , t.ZHGLJG        as ZHGLJG    --帐户管理机构
      , t.YHDM          as YHDM      --银行代码
      , CAST(t.KHFLFS as STRING)        as KHFLFS    --客户分类方式
      , t.KHFL          as KHFL      --客户分类
      , CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )        as ZJZHLB    --资金帐户类别
      , CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )          as BZDM      --币种代码
      , t.SRYE          as SRYE      --收入金额
      , t.BRBD          as BRBD      --本日变动
      , t.ZJYE          as ZJYE      --资金余额
      , t.XYJKFSJE      as XYJKFSJE  --信用借款发生金额
      , t.XYJKYE        as XYJKYE    --信用借款余额
      , t.CKJE          as CKJE      --存款金额
      , t.QKJE          as QKJE      --取款金额
      , t.LXJS          as LXJS      --利息基数
      , t.DZLX          as DZLX      --待转利息
      , t.TZJS          as TZJS      --透支基数
      , t.KHS           as KHS       --开户数
      , t.XHS           as XHS       --销户数
      , t.YXHS          as YXHS      --有效户数
      , t.WJSZJ         as WJSZJ     --未交收资金
      , t.YJLX          as YJLX      --佣金利息           
      ,'JZJY'     as XTBS				   
 FROM  JZJYCX.DATACENTER_TZJZHTJ t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'JZJY'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t2 
 ON             t2.DMLX = 'ZJZHLB'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'BZDM'
 AND            t3.YXT = 'JZJY'
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20))
 WHERE      t.DT = '%d{yyyyMMdd}'
 UNION ALL
 SELECT  t.RQ            as RQ        --日期
      , CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))           as YYB       --营业部
      , t.ZHGLJG        as ZHGLJG    --帐户管理机构
      , t.YHDM          as YHDM      --银行代码
      , CAST(t.KHFLFS as STRING)        as KHFLFS    --客户分类方式
      , t.KHFL          as KHFL      --客户分类
      , CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )        as ZJZHLB    --资金帐户类别
      , CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )          as BZDM      --币种代码
      , t.SRYE          as SRYE      --收入金额
      , t.BRBD          as BRBD      --本日变动
      , t.ZJYE          as ZJYE      --资金余额
      , t.XYJKFSJE      as XYJKFSJE  --信用借款发生金额
      , t.XYJKYE        as XYJKYE    --信用借款余额
      , t.CKJE          as CKJE      --存款金额
      , t.QKJE          as QKJE      --取款金额
      , t.LXJS          as LXJS      --利息基数
      , t.DZLX          as DZLX      --待转利息
      , t.TZJS          as TZJS      --透支基数
      , t.KHS           as KHS       --开户数
      , t.XHS           as XHS       --销户数
      , t.YXHS          as YXHS      --有效户数
      , t.WJSZJ         as WJSZJ     --未交收资金
      , t.YJLX          as YJLX      --佣金利息           
      ,'RZRQ'     as XTBS				   
 FROM  RZRQCX.DATACENTER_TZJZHTJ t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'RZRQ'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t2 
 ON             t2.DMLX = 'ZJZHLB'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'BZDM'
 AND            t3.YXT = 'RZRQ'
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20))
 WHERE      t.DT = '%d{yyyyMMdd}'
 UNION ALL
 SELECT  t.RQ            as RQ        --日期
      , CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))           as YYB       --营业部
      , t.ZHGLJG        as ZHGLJG    --帐户管理机构
      , t.YHDM          as YHDM      --银行代码
      , CAST(t.KHFLFS as STRING)        as KHFLFS    --客户分类方式
      , t.KHFL          as KHFL      --客户分类
      , CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )        as ZJZHLB    --资金帐户类别
      , CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )          as BZDM      --币种代码
      , t.SRYE          as SRYE      --收入金额
      , t.BRBD          as BRBD      --本日变动
      , t.ZJYE          as ZJYE      --资金余额
      , t.XYJKFSJE      as XYJKFSJE  --信用借款发生金额
      , t.XYJKYE        as XYJKYE    --信用借款余额
      , t.CKJE          as CKJE      --存款金额
      , t.QKJE          as QKJE      --取款金额
      , t.LXJS          as LXJS      --利息基数
      , t.DZLX          as DZLX      --待转利息
      , t.TZJS          as TZJS      --透支基数
      , t.KHS           as KHS       --开户数
      , t.XHS           as XHS       --销户数
      , t.YXHS          as YXHS      --有效户数
      , t.WJSZJ         as WJSZJ     --未交收资金
      , t.YJLX          as YJLX      --佣金利息           
      ,'GGQQ'     as XTBS				   
 FROM  GGQQCX.DATACENTER_TZJZHTJ t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'GGQQ'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t2 
 ON             t2.DMLX = 'ZJZHLB'
 AND            t2.YXT = 'GGQQ'
 AND            t2.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'BZDM'
 AND            t3.YXT = 'GGQQ'
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20))
 WHERE      t.DT = '%d{yyyyMMdd}'
 ;
----插入数据结束---------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZJZHTJ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TZJZHTJ;
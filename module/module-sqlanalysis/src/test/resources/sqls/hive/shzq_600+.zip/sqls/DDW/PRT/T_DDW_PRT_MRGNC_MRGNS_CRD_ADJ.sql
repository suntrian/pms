 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:融资融券授信额度调整表                                                                       */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 
 /*  T_DDW_F05_BIZ_SYS_TRD_OPE_DETAIL 修改为   t_ddw_f00_cust_trd_src_ope_detail_his  */
			  
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_CRD_ADJ
(
									 BRH_NO                             --营业部编号     
									,BRH_NAME                           --营业部名称
									,CUST_NO                            --客户号
									,CUST_NAME                          --客户姓名
									,CRD_ADJ_DT                         --授信额度调整日期
									,BFR_ADJ_MRGNC_QUO                  --调整前融资额度
									,BFR_ADJ_MRGNS_QUO                  --调整前融券额度
									,AFT_ADJ_MRGNC_QUO                  --调整后融资额度					      
									,AFT_ADJ_MRGNS_QUO                  --调整后融券额度
									,ABST                               --摘要                 
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
						 t.BRH_NO         AS BRH_NO                   --营业部编号     
						,t.BRH_NAME       AS BRH_NAME                 --营业部名称
						,t.CUST_NO        AS CUST_NO                  --客户号
						,t.CUST_NAME      AS CUST_NAME                --客户姓名
						,t.BUS_DATE       AS CRD_ADJ_DT               --授信额度调整日期
						,a1.RZED          AS BFR_ADJ_MRGNC_QUO        --调整前融资额度
						,a1.RQED          AS BFR_ADJ_MRGNS_QUO        --调整前融券额度
						,a2.RZED          AS AFT_ADJ_MRGNC_QUO        --调整后融资额度	        
						,a2.RQED          AS AFT_ADJ_MRGNS_QUO        --调整后融券额度
						,t.ABST           AS ABST                     --摘要                                              
  FROM  		DDW_PROD.t_ddw_f00_cust_trd_src_ope_detail_his               t
  LEFT JOIN     (SELECT a.KHH,a.BUS_DATE,a.RZED,a.RQED 
                 FROM       EDW_PROD.T_EDW_T02_TXY_HTXXLS  a 
                 WHERE EXISTS  (SELECT 1 
				             FROM   EDW_PROD.T_EDW_T99_TRD_DATE   b
							 WHERE  b.TRD_DT = %d{yyyyMMdd}
							 --AND    b.BUS_DATE = %d{yyyyMMdd}
							 AND    a.BUS_DATE = b.LST_TRD_D
							 ) 
				)                                                a1			
  ON            t.CUST_NO = a1.KHH                                   --前一天融资融券额度
  LEFT JOIN     EDW_PROD.T_EDW_T02_TXY_HTXXLS                   a2
  ON            t.CUST_NO = a2.KHH
  AND           t.BUS_DATE = a2.BUS_DATE                             --当天的融资融券额度
  LEFT JOIN (SELECT t.KHH FROM (SELECT  KHH ,SUM(RZED+RQED) as TOTAL
                                FROM   EDW_PROD.T_EDW_T02_TXY_HTXXLS
			                    WHERE  BUS_DATE <  %d{yyyyMMdd}
			                    GROUP BY KHH
			                    )             t
						  WHERE  t.TOTAL = 0
			 )                                                a3
 ON    t.CUST_NO = a3.KHH                                            --剔除首次融资融券额度
 LEFT JOIN (SELECT DISTINCT KHH FROM EDW_PROD.T_EDW_T02_TXY_HTXXLS WHERE BUS_DATE <  %d{yyyyMMdd}) a4
 ON     t.CUST_NO = a4.KHH
 WHERE  t.BUS_DATE = %d{yyyyMMdd}
 AND    t.BIZ_SBJ IN ('20064','20066')
 AND    t.ABST like '%额度%' 
 AND    a3.KHH IS NULL
 AND    a4.KHH IS NOT NULL                                           --之前没有融资融券的客户剔除掉
  ;
 
-----------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_MRGNC_MRGNS_CRD_ADJ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_CRD_ADJ ; 
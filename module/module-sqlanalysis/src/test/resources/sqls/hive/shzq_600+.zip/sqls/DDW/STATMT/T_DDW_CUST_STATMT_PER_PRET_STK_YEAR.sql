--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户对账单客户个股盈亏年表                                                                     */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-11-08                                                                        */ 


  
 ---创建临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR_TEMP;
 CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR_TEMP as
  SELECT   CUST_NO                   --客户号
           ,EXG                      --交易所
		   ,SEC_CD                   --证券代码
		   ,SUM(TOT_PRET_RMB) as TOT_PRET_RMB --总盈亏
  FROM     DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY
  WHERE    BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'0101') as INT)
  AND      BUS_DATE < = %d{yyyyMMdd} 
  AND      PROD_CGY IN (1,2,5,7)
  GROUP BY CUST_NO,EXG,SEC_CD ;
  ---持仓临时表
    DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR_TEMP1;
    CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR_TEMP1 as
    SELECT EXG,CUST_NO,SEC_CD,COUNT(1) as HLD_DYS
	FROM 
	(SELECT            EXG
                     ,CUST_NO
					 ,SEC_CD
					 ,BUS_DATE 
	FROM           DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS 
    WHERE          BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'0101') as INT)
    AND            BUS_DATE < = %d{yyyyMMdd} 
	AND            SEC_MKTVAL > 0
	GROUP BY       EXG,CUST_NO,SEC_CD,BUS_DATE
	) t
	GROUP BY EXG,CUST_NO,SEC_CD ;
  
  
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR_TEMP2;
  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR_TEMP2 as
  SELECT     t.EXG                as EXG
            ,t.SEC_CD             as SEC_CD
		    ,t.CUST_NO            as CUST_NO
            ,COUNT(1)             as HLD_DYS		   
 FROM       (SELECT   t.EXG
                     ,t.CUST_NO
					 ,t.SEC_CD
					 ,t.BUS_DATE 
			FROM     DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS t
            WHERE    t.BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'0101') as INT)
            AND      t.BUS_DATE < = %d{yyyyMMdd} 
			AND      t.CRD_ACCT_UN_GL_PRINP > 0
			AND      NOT EXISTS (SELECT 1 FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS a
			                     WHERE    a.BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4),'0101') as INT)
                                 AND      a.BUS_DATE < = %d{yyyyMMdd}
			                     AND      a.SEC_MKTVAL > 0
                                 AND      t.BUS_DATE = a.BUS_DATE
                                 AND      t.CUST_NO = a.CUST_NO
                                 AND      t.SEC_CD = a.SEC_CD
                                 AND      t.EXG = a.EXG								 
                         	    )
			GROUP BY t.EXG,t.CUST_NO,t.SEC_CD,t.BUS_DATE
             ) t
 GROUP BY EXG,SEC_CD,CUST_NO;
  
------插入数据  
   INSERT 	OVERWRITE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR
 (
                                  
           CUST_NO             --客户号
          ,EXG                 --交易所   
          ,SEC_CD              --证券代码
          ,SEC_NAME            --证券名称
          ,TOT_PRET_RMB        --总盈亏(人名币)
          ,PAYOF_RANK          --盈利排名
          ,LOSS_RANK           --亏损排名
          ,HLD_DYS             --持仓天数                                             
          ,ETL_DT              --加载日期
 ) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT) )
 SELECT        t.CUST_NO                           as CUST_NO             --客户号
              ,t.EXG                               as EXG                 --交易所   
              ,t.SEC_CD                            as SEC_CD              --证券代码
              ,a3.ZQMC                             as SEC_NAME            --证券名称
              ,t.TOT_PRET_RMB                      as TOT_PRET_RMB        --总盈亏(人名币)
              ,CASE WHEN t.TOT_PRET_RMB > 0  
				    THEN ROW_NUMBER() OVER(PARTITION BY t.CUST_NO ORDER BY t.TOT_PRET_RMB DESC) 
 				    ELSE 9999
				    END                             as PAYOF_RANK   --盈利排名
			  ,CASE WHEN t.TOT_PRET_RMB < 0 
				    THEN ROW_NUMBER() OVER(PARTITION BY t.CUST_NO ORDER BY t.TOT_PRET_RMB ASC) 
 				    ELSE 9999
				    END                             as LOSS_RANK    --亏损排名
             ,NVL(a1.HLD_DYS,0)+NVL(a2.HLD_DYS,0)   as HLD_DYS             --持仓天数       
             ,%d{yyyyMMdd}                              as ETL_DT              --加载日期
 FROM            DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR_TEMP         t 
 LEFT JOIN       DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR_TEMP1        a1
 ON              t.CUST_NO = a1.CUST_NO
 AND             t.EXG = a1.EXG
 AND             t.SEC_CD = a1.SEC_CD 
 LEFT JOIN       DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR_TEMP2        a2
 ON              t.CUST_NO = a2.CUST_NO
 AND             t.EXG = a2.EXG
 AND             t.SEC_CD = a2.SEC_CD 
 LEFT JOIN       EDW_PROD.T_EDW_T04_TZQDM                                  a3
 ON              t.EXG = a3.JYS
 AND             t.SEC_CD = a3.ZQDM
 AND             a3.BUS_DATE = %d{yyyyMMdd}
 ;  
-------删除临时表  
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR_TEMP;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR_TEMP1;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR_TEMP2; 
  
-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_STATMT_PER_PRET_STK_YEAR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;  
  invalidate metadata DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR;
  

 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360资金账户信息                                                                 */
  --/* 创建人:程骏                                                                                 */
  --/* 创建时间:2017-10-19                                                                        */ 
   /* T_DDW_F02_ACCNT_CPTL_BAL_INFO 替换为 T_DDW_F00_AST_CPTL_BAL_HIS */
  
  
---------------- 插入集中交易数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_CPTL_ACCNT_INFO
 (
	 CUST_NO                     	--客户号
	,CPTL_ACCNT						--柜台资金帐号
	,ACCNT_BAL						--帐户余额
	,CCY							--币种
	,CPTL_ACCNT_STAT				--账户状态
	,OPNAC_DT						--开户日期
	,CNCLACT_DT						--销户日期
	,BRH_NAME                   	--营业部名称 
	,CUST_NAME                   	--账户姓名 
	,ACCNT_TYPE						--账户类型
	,BANK_ACTNO						--银行账号
	,BANK_NAME						--银行名称
	,ACCNT_BANK_ACTNO_RLN_STAT		--账户银行账号关系状态
	,ACCNT_CGY						--账户类别           
 ) 
 PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT   t.CUST_NO                                      as CUST_NO                     	--客户号
	     ,t.CNTR_CPTL_ACCNT                              as CPTL_ACCNT						--柜台资金帐号
	     ,t.ACCNT_BAL                                    as ACCNT_BAL						--帐户余额
	     ,a1.CCY_CD_NAME                                 as CCY							    --币种
	     ,a2.CPTL_ACCNT_STAT_NAME                        as CPTL_ACCNT_STAT				    --账户状态
	     ,t.opnac_dt                                     as OPNAC_DT						--开户日期
	     ,t.CNCLACT_DT                                   as CNCLACT_DT						--销户日期
	     ,a5.JGMC                                        as BRH_NAME                   	    --营业部名称 
	     ,t.CUST_NAME                                    as CUST_NAME                   	--账户姓名 
	     ,DECODE(NVL(t.MAIN_ACCNT_FLG,99),1,'主',0,'子',NULL)          as ACCNT_TYPE						--账户类型
	     ,t.BANK_ACTNO                                   as BANK_ACTNO						--银行账号
	     ,a4.WBJGMC                                      as BANK_NAME						--银行名称
	     ,DECODE(t.ACCNT_BANK_ACTNO_RLN_STAT,0,'正常',4,'预指定存管银行',5,'三方存管未签约')                   as ACCNT_BANK_ACTNO_RLN_STAT		--账户银行账号关系状态
	     ,t.SYS_SRC                                      as ACCNT_CGY						--账户类别           
 FROM        DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS           t
 LEFT JOIN   DDW_PROD.V_CCY_CD                          a1
 ON          t.CCY_CD = a1.CCY_CD
 LEFT JOIN   DDW_PROD.V_CPTL_ACCNT_STAT                 a2
 ON          t.CPTL_ACCNT_STAT = a2.CPTL_ACCNT_STAT
------------------LEFT JOIN (SELECT KHH,GTZJZH,YHDM,YHZH,BZDM,DECODE(ZH_YHZHGXZT,0,'正常',4,'预指定存管银行',5,'三方存管未签约') as ZH_YHZHGXZT
------------------FROM EDW_PROD.T_EDW_T02_TCGZHDY
------------------WHERE BUS_DATE = 20171018
------------------UNION ALL 
------------------SELECT KHH,GTZJZH,YHDM,YHZH,BZDM,DECODE(ZH_YHZHGXZT,0,'正常',4,'预指定存管银行',5,'三方存管未签约') as ZH_YHZHGXZT
------------------FROM EDW_PROD.T_EDW_T02_TYZZZDY
------------------WHERE BUS_DATE = 20171018) A3
------------------	ON on t.CPTL_ACCNT = a3.GTZJZH AND t.cust_no = a3.KHH AND t.CCY_CD = a3.BZDM
 LEFT JOIN    EDW_PROD.T_EDW_T03_TWBJGDM                 a4
 ON           t.BANK_CD = a4.WBJGDM 
 AND          a4.xtbs ='JZJY'
 AND          t.BUS_DATE = a4.BUS_DATE
 LEFT JOIN    EDW_PROD.T_EDW_T03_TJGGL                  a5
 ON           t.BRH_NO = a5.JGDM
 AND          t.BUS_DATE = a5.BUS_DATE
 WHERE        t.BUS_DATE = %d{yyyyMMdd}
		;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_CPTL_ACCNT_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_CUST360_CPTL_ACCNT_INFO; 
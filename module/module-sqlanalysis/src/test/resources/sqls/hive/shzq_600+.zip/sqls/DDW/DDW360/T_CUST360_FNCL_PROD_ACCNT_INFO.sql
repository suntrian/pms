 --/* ***************************************** SQL BEGIN *****************************************  */
  --/* 脚本功能:客户360金融产品信息表                                                                      */
  --/* 创建人:程骏                                                                               */
  --/* 创建时间:2017-10-19                                                                        */ 
  /* T_DDW_F02_FNCL_PROD_ACCNT_INFO 替换为 T_DDW_F00_CUST_FNCL_PROD_ACCNT_INFO */
  
---------------- 插入集中交易数据开始 -----------------------
 INSERT  OVERWRITE  DDW_PROD.T_CUST360_FNCL_PROD_ACCNT_INFO
 (
	 CUST_NO					       --客户号          
	,ISSUE_ORG                         --发行机构        
	,ISSUE_ORG_NAME                    --发行机构名称    
	,FNCL_PROD_ACTNO                   --产品帐号        
	,CCY_CD                            --币种代码        
	,OPNAC_DT                          --开户日期        
	,FNCL_PROD_ACCNT_ATTR              --金融产品帐户属性
	,FNCL_PROD_ACCNT_STAT              --金融产品帐户状态
	,CUST_NAME                         --客户姓名姓名    
	,BRH_NAME                          --营业部名称           
 )PARTITION( BUS_DATE = %d{yyyyMMdd})
 SELECT     t.CUST_NO                            as CUST_NO					       --客户号          
	       ,t.ISSUE_ORG                          as ISSUE_ORG                         --发行机构        
	       ,a1.WBJGMC                            as ISSUE_ORG_NAME                    --发行机构名称    
	       ,t.FNCL_PROD_ACTNO                    as FNCL_PROD_ACTNO                   --产品帐号        
	       ,a2.CCY_CD_NAME                       as CCY_CD                            --币种代码        
	       ,t.OPNAC_DT                           as OPNAC_DT                          --开户日期        
	       ,DECODE(t.FNCL_PROD_ACCNT_ATTR,0,'未设置',a3.FNCL_PROD_ACCNT_ATTR_NAME)         as FNCL_PROD_ACCNT_ATTR              --金融产品帐户属性
	       ,a4.FNCL_PROD_ACCNT_STAT_NAME         as FNCL_PROD_ACCNT_STAT              --金融产品帐户状态
	       ,t.CUST_NAME                          as CUST_NAME                         --客户姓名姓名    
	       ,t.BRH_NAME                           as BRH_NAME                          --营业部名称           
 FROM         DDW_PROD.T_DDW_F00_CUST_FNCL_PROD_ACCNT_INFO     t
 LEFT JOIN    EDW_PROD.T_EDW_T03_TWBJGDM                  a1
 ON           t.ISSUE_ORG = a1.WBJGDM 
 AND          t.BUS_DATE = a1.BUS_DATE
 LEFT JOIN    DDW_PROD.V_CCY_CD                           a2
 ON           t.CCY_CD = a2.CCY_CD
 LEFT JOIN    DDW_PROD.V_FNCL_PROD_ACCNT_ATTR             a3
 ON           CAST(t.FNCL_PROD_ACCNT_ATTR as STRING) = a3.FNCL_PROD_ACCNT_ATTR
 LEFT JOIN    DDW_PROD.V_FNCL_PROD_ACCNT_STAT A4
 ON           CAST(t.FNCL_PROD_ACCNT_STAT as STRING) = a4.FNCL_PROD_ACCNT_STAT
 WHERE        t.BUS_DATE = %d{yyyyMMdd}
 ;

---------------- 插入结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_CUST360_FNCL_PROD_ACCNT_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

invalidate metadata DDW_PROD.T_CUST360_FNCL_PROD_ACCNT_INFO;
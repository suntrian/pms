--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:经纪业务领导驾驶舱月表                                                        */
--/* 创建人:黄勇华                                                                              */
--/* 创建时间:2018-08-16                                                                        */ 
------------------- 删除数据
DELETE FROM RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU WHERE YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT);
---------------

-----插入股票交易量
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
)
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'STK_TRD_VOL'        as IDX_CODE        --指标代码
           , '股票交易量'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.STK_TRD_VOL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;

-----插入基金交易量
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'FND_TRD_VOL'        as IDX_CODE        --指标代码
           , '基金交易量'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.FND_TRD_VOL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;

-----插入期初A股票市值
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'STRT_A_STK_MKTVAL'        as IDX_CODE        --指标代码
           , '期初A股票市值'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.STRT_A_STK_MKTVAL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;

-----插入期初B股票市值
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'STRT_B_STK_MKTVAL'        as IDX_CODE        --指标代码
           , '期初B股票市值'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.STRT_B_STK_MKTVAL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;


-----插入期末A股票市值
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'FNL_A_STK_MKTVAL'        as IDX_CODE        --指标代码
           , '期末A股票市值'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.FNL_A_STK_MKTVAL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;

-----插入期末B股票市值
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'FNL_B_STK_MKTVAL'        as IDX_CODE        --指标代码
           , '期末B股票市值'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.FNL_B_STK_MKTVAL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;

-----插入期初资金余额
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'STRT_CPTL_BAL'        as IDX_CODE        --指标代码
           , '期初资金余额'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.STRT_CPTL_BAL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;

-----插入期末资金余额
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'FNL_CPTL_BAL'        as IDX_CODE        --指标代码
           , '期末资金余额'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.FNL_CPTL_BAL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;


-----插入期初融资余额
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON                 --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'STRT_MRGNC_CPTL_BAL'        as IDX_CODE        --指标代码
           , '期初融资余额'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.STRT_MRGNC_CPTL_BAL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;


-----插入期初融券余额
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'STRT_MRGNS_CPTL_BAL'        as IDX_CODE        --指标代码
           , '期初融券余额'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.STRT_MRGNS_CPTL_BAL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;



-----插入期末融资余额
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID               --主键
           , BELTO_FILIL      --所属分公司
           , BELTO_FILIL_CDG  --所属分公司编码 
           , BRH_NO           --营业部编号
           , BRH_NAME         --营业部名称
           , CUST_STAR        --客户星级
           , IDX_CODE         --指标代码
           , IDX_NAME         --指标名称
           , VALUE_STR       --指标值_字符
           , VALUE           --指标值_数字
           , ETL_DT          --加载日期
           , YEAR_MON        --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'FNL_MRGNC_CPTL_BAL'        as IDX_CODE        --指标代码
           , '期末融资余额'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.FNL_MRGNC_CPTL_BAL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;


-----插入期末融券余额
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'FNL_MRGNS_CPTL_BAL'        as IDX_CODE        --指标代码
           , '期末融券余额'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.STRT_MRGNS_CPTL_BAL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;

-----插入净佣金收入
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'NET_S1_INCM'        as IDX_CODE        --指标代码
           , '净佣金收入'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.NET_S1_INCM        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;

-----插入息费收入
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'INT_INCM'        as IDX_CODE        --指标代码
           , '息费收入'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.INT_INCM        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;

-----插入资产净流入
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'NET_TFR_IN_AST'        as IDX_CODE        --指标代码
           , '资产净流入'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.NET_TFR_IN_AST        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;

-----插入开户数
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID               --主键
           , BELTO_FILIL      --所属分公司
           , BELTO_FILIL_CDG  --所属分公司编码 
           , BRH_NO           --营业部编号
           , BRH_NAME         --营业部名称
           , CUST_STAR        --客户星级
           , IDX_CODE         --指标代码
           , IDX_NAME         --指标名称
           , VALUE_STR       --指标值_字符
           , VALUE           --指标值_数字
           , ETL_DT          --加载日期
           , YEAR_MON        --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'OPNAC_CUST_VOL'        as IDX_CODE        --指标代码
           , '开户数'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.OPNAC_CUST_VOL        as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;

-----插入交易量
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'TRD_VOL'        as IDX_CODE        --指标代码
           , '交易量'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.TRD_VOL       as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;


-----插入客户数
INSERT INTO RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU
(            ID                --主键
           , BELTO_FILIL       --所属分公司
           , BELTO_FILIL_CDG   --所属分公司编码 
           , BRH_NO            --营业部编号
           , BRH_NAME          --营业部名称
           , CUST_STAR         --客户星级
           , IDX_CODE          --指标代码
           , IDX_NAME          --指标名称
           , VALUE_STR        --指标值_字符
           , VALUE            --指标值_数字
           , ETL_DT           --加载日期
           , YEAR_MON         --年月	
) 
SELECT     REPLACE(UUID(),'-','') as ID              --主键
           , a1.BELTO_FILIL       as BELTO_FILIL     --所属分公司
           , a1.BELTO_FILIL_CDG   as BELTO_FILIL_CDG --所属分公司编码 
           , a1.BRH_NO            as BRH_NO          --营业部编号
           , a1.BRH_FULLNM        as BRH_NAME        --营业部名称
           , t.CUST_STAR          as CUST_STAR       --客户星级
           , 'FNL_CUST_VOL'        as IDX_CODE        --指标代码
           , '客户数'         as IDX_NAME        --指标名称
           , NULL                 as VALUE_STR       --指标值_字符
           , t.FNL_CUST_VOL       as VALUE           --指标值_数字
           , %d{yyyyMMdd}             as ETL_DT          --加载日期
           , CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) as YEAR_MON              --年月	
FROM DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_MON  t
INNER JOIN RPT_DB.V_BRH_NO                     a1   
ON         t.BRH_NO = a1.BRH_NO  
WHERE  t.YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('RPT_DB','DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
INVALIDATE METADATA RPT_DB.DDW_APP_DASHBORD_BROK_BIZ_MON_KUDU;
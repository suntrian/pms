------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户生命周期初始化                                                                  */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2018-11-16 

ALTER  TABLE  DDW_PROD.T_DDW_CUST_LCS_STATAS DROP IF EXISTS PARTITION(BUS_DATE = %d{yyyyMMdd});

---------创建临时表1 客户开户日期------------
DROP TABLE IF EXISTS DDW_PROD.CUST_OPN_DT_%d{yyyyMMdd};
CREATE TABLE DDW_PROD.CUST_OPN_DT_%d{yyyyMMdd} AS
SELECT DISTINCT KHH      AS CUST_NO
               ,YGT_KHRQ AS BUS_DATE
FROM  EDW_PROD.T_EDW_T01_TKHXX
WHERE JZJYKH_KHZTDM = '0'
AND BUS_dATE = %d{yyyyMMdd}
;

---------创建临时表2 客户交易日期------------
DROP TABLE IF EXISTS DDW_PROD.CUST_TRD_DT_%d{yyyyMMdd};
CREATE TABLE DDW_PROD.CUST_TRD_DT_%d{yyyyMMdd} AS
SELECT DISTINCT CUST_NO
               ,MTCH_DT AS BUS_DATE
FROM   DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
WHERE  MTCH_AMT > 0
AND    IF_TRD = 1
AND   CUST_NO IN (SELECT KHH FROM EDW_PROD.T_EDW_T01_TKHXX WHERE BUS_DATE = %d{yyyyMMdd} AND JZJYKH_KHZTDM = '0')
UNION ALL
SELECT DISTINCT CUST_NO
               ,CNFM_DT AS BUS_DATE
FROM   DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS
WHERE  CNFM_AMT > 0
AND    IF_TRD = 1
AND   CUST_NO IN (SELECT KHH FROM EDW_PROD.T_EDW_T01_TKHXX WHERE BUS_DATE = %d{yyyyMMdd} AND JZJYKH_KHZTDM = '0')
UNION ALL
SELECT DISTINCT CUST_NO
               ,MTCH_DT AS BUS_DATE
FROM   DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
WHERE  MTCH_AMT > 0
AND   CUST_NO IN (SELECT KHH FROM EDW_PROD.T_EDW_T01_TKHXX WHERE BUS_DATE = %d{yyyyMMdd} AND JZJYKH_KHZTDM = '0')
;

---------创建临时表3 沉寂复苏------------
DROP TABLE IF EXISTS DDW_PROD.CUST_TRD_TEST_%d{yyyyMMdd};
CREATE TABLE DDW_PROD.CUST_TRD_TEST_%d{yyyyMMdd} AS
SELECT          CUST_NO
               ,DT1,DT2
			   ,ROW_NUMBER()OVER(PARTITION BY CUST_NO ORDER BY CUST_NO,DT1) NUM
FROM(
SELECT DISTINCT CUST_NO  as cust_no
               ,BUS_DATE as DT1
               ,EDW_PROD.G_DATE_ADD_STR(cast(BUS_DATE as STRING),'yyyyMMdd','yyyyMMdd',0,6,0) DT2 
FROM(
SELECT * FROM DDW_PROD.CUST_OPN_DT_%d{yyyyMMdd}
UNION ALL
SELECT * FROM DDW_PROD.CUST_TRD_DT_%d{yyyyMMdd}
)T
)T;

---------创建临时表4 投资偏好------------
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_LABEL_V_C_HIS_TEMP111_%d{yyyyMMdd};
CREATE TABLE DDW_PROD.T_DDW_LM_LABEL_V_C_HIS_TEMP111_%d{yyyyMMdd} AS 
SELECT 
         CUST_NO
        ,LABEL_VALUE
        ,BUS_DATE
        ,ROW_NUMBER()OVER(PARTITION BY CUST_NO ORDER BY BUS_DATE) NUM
FROM DDW_PROD.T_DDW_LM_LABEL_V_C_HIS
WHERE LABEL_ID = '8b6c8a85b0014e8384a884a8f8ceb7ee'
AND   LABEL_VALUE IS NOT NULL;

---------创建临时表5 佣金调整------------
DROP TABLE IF EXISTS EDW_PROD.T_EDW_T02_TYJDJDX_KH_TEMP1111_%d{yyyyMMdd};
CREATE TABLE EDW_PROD.T_EDW_T02_TYJDJDX_KH_TEMP1111_%d{yyyyMMdd} AS 
SELECT 
         KHH
		,YJDJFS
        ,djrq
        ,ROW_NUMBER()OVER(PARTITION BY KHH ORDER BY djrq) NUM
FROM  EDW_PROD.T_EDW_T02_TYJDJDX_KH;



-----开始插入数据
--开户成功日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'001'                       AS IMPO_PHS_CD 
			       ,'开户日期'                  AS IMPO_PHS_DSC
			       ,CAST(T1.YGT_KHRQ AS STRING) AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
INNER JOIN          EDW_PROD.T_EDW_T01_TKHXX    T1
ON                  T.CUST_NO  = T1.KHH
AND                 T.BUS_DATE = T1.BUS_DATE			  
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.YGT_KHRQ IS NOT NULL
;

--销户日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'002'                       AS IMPO_PHS_CD 
			       ,'销户日期'                  AS IMPO_PHS_DSC
			       ,CAST(T1.YGT_XHRQ AS STRING) AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
INNER JOIN          EDW_PROD.T_EDW_T01_TKHXX    T1
ON                  T.CUST_NO  = T1.KHH
AND                 T.BUS_DATE = T1.BUS_DATE			  
WHERE               T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.YGT_XHRQ IS NOT NULL
AND                 T1.YGT_XHRQ > 19000101
AND                 T1.YGT_KHZTDM = '3'
;

--首笔资金转入日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'003'                       AS IMPO_PHS_CD 
			       ,'首笔资金转入日期'          AS IMPO_PHS_DSC
			       ,CAST(T1.SBZJ AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN           (SELECT   KHH,MIN(BUS_DATE) AS SBZJ 
                     FROM     EDW_PROD.T_EDW_T05_TZJMXLS
		             WHERE    YWKM LIKE '101%'
		             GROUP BY KHH)   T1
ON                  T.CUST_NO = T1.KHH			  
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.SBZJ IS NOT NULL
;

--首笔交易日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'004'                       AS IMPO_PHS_CD 
			       ,'首笔交易日期'          AS IMPO_PHS_DSC
			       ,CAST(T1.DT AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN           (SELECT CUST_NO,MIN(BUS_DATE) AS DT
                     FROM DDW_PROD.CUST_TRD_DT_%d{yyyyMMdd}
                     GROUP BY CUST_NO)   T1
ON                  T.CUST_NO = T1.CUST_NO			  
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.DT IS NOT NULL
;

--变为有效户日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'005'                                AS IMPO_PHS_CD 
			       ,'变为有效户日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.BWYXH AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN          (SELECT   CUST_NO,MIN(BUS_DATE) AS BWYXH 
                    FROM     DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
                    WHERE    TOT_AST >= 1000
		            GROUP BY CUST_NO) T1
ON                  T.CUST_NO = T1.CUST_NO		  
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.BWYXH IS NOT NULL
;

--两融开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'006'                                AS IMPO_PHS_CD 
			       ,'两融开通日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.LRKT AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN          (SELECT   CUST_NO,MIN(OPNAC_DT) AS LRKT 
                    FROM     DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
                    WHERE    SYS_SRC = '信用账户'
		            AND      BUS_DATE = %d{yyyyMMdd}
		            GROUP BY CUST_NO) T1
ON                  T.CUST_NO = T1.CUST_NO  
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.LRKT IS NOT NULL
;

--两融激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'007'                                AS IMPO_PHS_CD 
			       ,'两融激活日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.LRJH AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT   KHH,MIN(CJRQ) AS LRJH 
           FROM     RZRQCX.DATACENTER_TJGMXLS
           WHERE    WTLB IN (61,62,63,64,71,72)
		   AND      CJJE > 0
		   GROUP BY KHH
		   ) T1
ON T.CUST_NO = T1.KHH 
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.LRJH IS NOT NULL
;

--股票期权开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'008'                                AS IMPO_PHS_CD 
			       ,'股票期权开通日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.GPKT AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT   CUST_NO,MIN(OPNAC_DT) AS GPKT
           FROM     DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS
           WHERE    SYS_SRC = '期权账户'
		   AND    BUS_DATE = %d{yyyyMMdd}
		   GROUP BY CUST_NO) T1
ON         T.CUST_NO = T1.CUST_NO
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.GPKT IS NOT NULL
;

--股票期权激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'009'                                AS IMPO_PHS_CD 
			       ,'股票期权激活日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.GPJH AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT KHH,MIN(CJRQ) AS GPJH
           FROM   EDW_PROD.T_EDW_T05_TSO_JGMXLS
		   WHERE  SOP_MMFX IN ('1','2')
		   AND    SOP_KPCBZ IN ('O','C')
		   AND    CJJE > 0
		   GROUP BY KHH
		   ) T1
ON         T.CUST_NO = T1.KHH
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.GPJH IS NOT NULL
;

--港股通开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'010'                                AS IMPO_PHS_CD 
			       ,'港股通开通日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.GGKT AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT KHH,MIN(NVL(KTRQ,20140101)) AS GGKT
           FROM   EDW_PROD.T_EDW_T02_TKHJYQX
		   WHERE  GDZHLB IN ('9','10')
		   AND    JYQX = 1
		   AND    BUS_DATE = %d{yyyyMMdd}
		   GROUP  BY KHH)T1
ON         T.CUST_NO = T1.KHH
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.GGKT IS NOT NULL
;

--港股通激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'011'                                AS IMPO_PHS_CD 
			       ,'港股通激活日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.GGJH AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT     KHH,MIN(CJRQ) AS GGJH
           FROM       EDW_PROD.T_EDW_T05_TJGMXLS
		   WHERE      JYS IN ('HK','SK')
		   AND        WTLB IN(1,2)
		   AND        CJJE > 0
		   GROUP BY   KHH
		   ) T1
ON T.CUST_NO = T1.KHH
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.GGJH IS NOT NULL
;

--基金定投开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'012'                                AS IMPO_PHS_CD 
			       ,'基金定投开通日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.JJQY AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT KHH,MIN(NVL(KSRQ,20140101)) AS JJQY
           FROM   EDW_PROD.T_EDW_T02_TOF_DQDESGXY
		   WHERE  BUS_DATE = %d{yyyyMMdd}
		   GROUP  BY KHH
		   )T1
ON         T.CUST_NO = T1.KHH
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.JJQY IS NOT NULL
;

--基金定投激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'013'                                AS IMPO_PHS_CD 
			       ,'基金定投激活日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.JJJH AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT     KHH,MIN(QRRQ) AS JJJH
           FROM       EDW_PROD.T_EDW_T05_TOF_JJJGLS T1
		   WHERE      YWDM LIKE '139%'
		   AND        QRJE > 0
		   GROUP BY   KHH
		   ) T1
ON T.CUST_NO = T1.KHH
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.JJJH IS NOT NULL
;


--分级基金开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'014'                                AS IMPO_PHS_CD 
			       ,'分级基金开通日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.FJJJKT AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT CUST_NO,MIN(NVL(OPN_DT,20140101)) AS FJJJKT
           FROM   DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
		   WHERE  OPN_PRVL = 117
		   AND    BUS_DATE = %d{yyyyMMdd}
		   GROUP  BY CUST_NO)T1
ON         T.CUST_NO = T1.CUST_NO
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.FJJJKT IS NOT NULL
;

--分级基金激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'015'                                AS IMPO_PHS_CD 
			       ,'分级基金激活日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.FJJJJH AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN(SELECT KHH,MIN(CJRQ) AS FJJJJH
          FROM EDW_PROD.T_EDW_T05_TJGMXLS T
          WHERE T.CJJE > 0 
		  AND T.WTLB IN(1,2,41,42,43,62,80,81,83)
          AND T.ZQDM IN 
          (
            SELECT ZQDM  FROM 
(
            SELECT JJDM AS ZQDM FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS WHERE BUS_DATE = %d{yyyyMMdd} AND %d{yyyyMMdd} > KSRQ AND %d{yyyyMMdd} < JSRQ
            UNION ALL
            SELECT ZQDM FROM EDW_PROD.T_EDW_T04_TFXJJDM_LS WHERE BUS_DATE = %d{yyyyMMdd} AND %d{yyyyMMdd} > KSRQ AND %d{yyyyMMdd} < JSRQ
          )A)
          GROUP BY KHH
)T1
ON        T.CUST_NO = T1.KHH
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.FJJJJH IS NOT NULL
;

--回购融券开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'016'                                AS IMPO_PHS_CD 
			       ,'回购融券开通日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.HGKT AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT CUST_NO,MIN(NVL(OPN_DT,20140101)) AS HGKT
           FROM   DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
		   WHERE  OPN_PRVL = 3
		   AND    BUS_DATE = %d{yyyyMMdd}
		   GROUP  BY CUST_NO)T1
ON         T.CUST_NO = T1.CUST_NO
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.HGKT IS NOT NULL
;

--回购融券激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'017'                                AS IMPO_PHS_CD 
			       ,'回购融券激活日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.HGJH AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT     KHH,MIN(CJRQ) AS HGJH
           FROM       EDW_PROD.T_EDW_T05_TJGMXLS T
		   WHERE      ZQLB LIKE 'H%'
		   AND        WTLB = 5
		   GROUP BY   KHH
		   ) T1
ON T.CUST_NO = T1.KHH
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.HGJH IS NOT NULL
;

--现金添利开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'018'                                AS IMPO_PHS_CD 
			       ,'现金添利开通日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.QYXJ AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT CUST_NO,MIN(NVL(SIGN_DT,20140101)) AS QYXJ
           FROM   DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL
		   WHERE  BUS_DATE = %d{yyyyMMdd}
		   GROUP  BY CUST_NO)T1
ON T.CUST_NO = T1.CUST_NO
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.QYXJ IS NOT NULL
;

--现金添利激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'019'                                AS IMPO_PHS_CD 
			       ,'现金添利激活日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.CASH_FND_ACTVT_DT AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT CUST_NO,MIN(FSTTM_TRD_DT) AS CASH_FND_ACTVT_DT
           FROM   DDW_PROD.T_DDW_F00_CUST_CASH_PROD_SIGN_DTL
		   WHERE  BUS_DATE = %d{yyyyMMdd}
		   GROUP  BY CUST_NO)T1
ON T.CUST_NO = T1.CUST_NO
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.CASH_FND_ACTVT_DT IS NOT NULL
;

--聚赢快线(报价回购)开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'020'                                AS IMPO_PHS_CD 
			       ,'聚赢快线(报价回购)开通日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.JYKX AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT CUST_NO,MIN(NVL(OPN_DT,20140101)) AS JYKX
           FROM   DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
		   WHERE  OPN_PRVL = 101
		   AND    BUS_DATE = %d{yyyyMMdd}
		   GROUP  BY CUST_NO)T1
ON         T.CUST_NO = T1.CUST_NO
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.JYKX IS NOT NULL
;

--新三板合格投资者(股转交易)开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'021'                                AS IMPO_PHS_CD 
			       ,'新三板合格投资者(股转交易)开通日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.XSBHG AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT CUST_NO,MIN(NVL(OPN_DT,20140101)) AS XSBHG
           FROM   DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
		   WHERE   OPN_PRVL = 6
		   AND    BUS_DATE = %d{yyyyMMdd}
		   GROUP  BY CUST_NO)T1
ON         T.CUST_NO = T1.CUST_NO
WHERE               T.ORDI_CUST_STAT = '0'
AND                 T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.XSBHG IS NOT NULL
;

--债券合格投资者开通日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'022'                                AS IMPO_PHS_CD 
			       ,'债券合格投资者开通日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.ZQHG AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT CUST_NO,MIN(NVL(OPN_DT,20140101)) AS ZQHG
           FROM   DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
		   WHERE   OPN_PRVL = 12
		   AND    BUS_DATE = %d{yyyyMMdd}
		   GROUP  BY CUST_NO)T1
ON         T.CUST_NO = T1.CUST_NO
WHERE ORDI_CUST_STAT = '0'
AND   T.BUS_DATE = %d{yyyyMMdd}
AND                 T1.ZQHG IS NOT NULL
;

--沪伦通开通日期

--沪伦通激活日期




--最近一次购买理财产品
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'025'                                AS IMPO_PHS_CD 
			       ,'最近一次购买理财产品'                         AS IMPO_PHS_DSC
			       ,CAST(T1.zjgmrq AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT CUST_NO,MAX(CNFM_DT) as zjgmrq
           FROM DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS
		   WHERE IF_TRD = 1
		   and   CNFM_AMT > 0
		   GROUP BY CUST_NO) T1
ON        T.CUST_NO = T1.CUST_NO
WHERE ORDI_CUST_STAT = '0'
AND   T.BUS_DATE = %d{yyyyMMdd}
AND   T1.zjgmrq IS NOT NULL
;

--订阅咨询服务产品（聚赢理财）



--客户沉寂
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'026'                                AS IMPO_PHS_CD 
			       ,'客户沉寂'                         AS IMPO_PHS_DSC
			       ,CAST(T1.DT2 AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT CUST_NO1,DT2  
           FROM
          (SELECT    T1.CUST_NO               AS CUST_NO1
                    ,T1.DT1                   AS DT1
          		    ,T1.DT2                   AS DT2
          		    ,T1.NUM                   AS NUM1
          		    ,T2.CUST_NO               AS CUST_NO2
          		    ,T2.DT1                   AS DT11
          		    ,T2.DT2                   AS DT22
          		    ,T2.NUM                   AS NUM11
          FROM      DDW_PROD.CUST_TRD_TEST_%d{yyyyMMdd} T1
          LEFT JOIN DDW_PROD.CUST_TRD_TEST_%d{yyyyMMdd} T2
          ON        T1.CUST_NO = T2.CUST_NO
          AND       T1.NUM = T2.NUM - 1
          WHERE     cast(T1.DT2 as string) < cast(NVL(cast(T2.DT1 as string),'%d{yyyyMMdd}') as string)
          )T
) T1
ON        T.CUST_NO = T1.CUST_NO1
WHERE ORDI_CUST_STAT = '0'
AND   T.BUS_DATE = %d{yyyyMMdd}
AND   T1.DT2 IS NOT NULL
;

--客户复苏
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'027'                                AS IMPO_PHS_CD 
			       ,'客户复苏'                         AS IMPO_PHS_DSC
			       ,CAST(T1.DT11 AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT CUST_NO1,DT11 
           FROM
          (SELECT    T1.CUST_NO               AS CUST_NO1
                    ,T1.DT1                   AS DT1
                    ,T1.DT2                   AS DT2
                    ,T1.NUM                   AS NUM1
                    ,T2.CUST_NO               AS CUST_NO2
                    ,T2.DT1                   AS DT11
                    ,T2.DT2                   AS DT22
                    ,T2.NUM                   AS NUM11
          FROM      DDW_PROD.CUST_TRD_TEST_%d{yyyyMMdd} T1
          LEFT JOIN DDW_PROD.CUST_TRD_TEST_%d{yyyyMMdd} T2
          ON        T1.CUST_NO = T2.CUST_NO
          AND       T1.NUM = T2.NUM - 1
          WHERE     cast(T1.DT2 as string) < cast(T2.DT1 as string)
         )T
) T1
ON        T.CUST_NO = T1.CUST_NO1
WHERE ORDI_CUST_STAT = '0'
AND   T.BUS_DATE = %d{yyyyMMdd}
AND   T1.DT11 IS NOT NULL
;

--佣金调整
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'028'                                AS IMPO_PHS_CD 
			       ,'佣金调整'                         AS IMPO_PHS_DSC
			       ,CAST(T1.djrq AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT CUST_NO1 as CUST_NO,DJRQ2 AS DJRQ FROM(
           SELECT 
                       T1.KHH          AS CUST_NO1
                      ,T1.YJDJFS       AS YJDJFS1
                      ,T1.DJRQ         AS DJRQ1
                      ,T1.NUM          AS NUM1
                      ,T2.KHH          AS CUST_NO2
                      ,T2.YJDJFS       AS YJDJFS2
                      ,T2.DJRQ         AS DJRQ2
                      ,T2.NUM          AS NUM2
           FROM        EDW_PROD.T_EDW_T02_TYJDJDX_KH_TEMP1111_%d{yyyyMMdd} T1
           LEFT JOIN   EDW_PROD.T_EDW_T02_TYJDJDX_KH_TEMP1111_%d{yyyyMMdd} T2
           ON          T1.KHH = T2.KHH
           AND         T1.NUM = T2.NUM - 1
)T
WHERE       YJDJFS1 <> YJDJFS2
AND         DJRQ2 IS NOT NULL
) T1
ON        T.CUST_NO = T1.CUST_NO
WHERE ORDI_CUST_STAT = '0'
AND   T.BUS_DATE = %d{yyyyMMdd}
AND   T1.djrq IS NOT NULL
;

--客户投诉
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'029'                                AS IMPO_PHS_CD 
			       ,'客户投诉'                         AS IMPO_PHS_DSC
			       ,CAST(T1.TSSJ AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN (SELECT khh,CONCAT(SUBSTR(TSSJ,1,4),SUBSTR(TSSJ,6,2),SUBSTR(TSSJ,9,2)) as TSSJ 
           FROM NEWCRM.CRMII_LCKHTSBD
          )T1
ON         T.CUST_NO = cast(T1.KHH as string)
WHERE ORDI_CUST_STAT = '0'
AND   T.BUS_DATE = %d{yyyyMMdd}
AND   T1.TSSJ IS NOT NULL
;

--客户成为专业投资者
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'030'                                AS IMPO_PHS_CD 
			       ,'客户成为专业投资者'                         AS IMPO_PHS_DSC
			       ,CAST(CAST(T1.tzzpdrq AS DECIMAL(38,0)) AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN  (SELECT KHH,min(tzzpdrq) AS tzzpdrq
            FROM EDW_PROD.T_EDW_T99_TKHYWSX
            WHERE GT_TZZFLDM <> '0'
			group by khh
			)T1
ON          T.CUST_NO = T1.KHH
WHERE       ORDI_CUST_STAT = '0'
AND         T.BUS_DATE = %d{yyyyMMdd}
AND         T1.tzzpdrq IS NOT NULL
;

--客户风险承受能力保守型（最低类别）
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO
			       ,'031'                                AS IMPO_PHS_CD 
			       ,'客户风险承受能力保守型（最低类别）'                         AS IMPO_PHS_DSC
			       ,CAST(T1.CPRQ AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN  (SELECT KHH,min(CPRQ) as cprq
            FROM EDW_PROD.T_EDW_T99_TKHSDX
		    WHERE SDXLBDM = 'JJFXCSNL'
            AND   CPDJ    = 11
			group by khh)T1
ON          T.CUST_NO = T1.KHH
WHERE       ORDI_CUST_STAT = '0'
AND         T.BUS_DATE = %d{yyyyMMdd}
AND         T1.CPRQ IS NOT NULL
;

--客户星级变动
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'032'                                AS IMPO_PHS_CD 
			       ,'客户星级变动'                         AS IMPO_PHS_DSC
			       ,CAST(T1.KHXJBDRQ AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN  (SELECT  cust_no,bus_date as KHXJBDRQ
            FROM DDW_PROD.T_DDW_LM_CUST_STAR_LVL_CHG_STATS)T1
ON          T.CUST_NO = T1.cust_no
WHERE       ORDI_CUST_STAT = '0'
AND         T.BUS_DATE = %d{yyyyMMdd}
AND         T1.KHXJBDRQ IS NOT NULL
;

--成为休眠账户
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'033'                                AS IMPO_PHS_CD 
			       ,'成为休眠账户'                         AS IMPO_PHS_DSC
			       ,CAST(T1.bdrq AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN  (SELECT khh,MIN(bdrq) as bdrq
            FROM jzjycx.GFZHGL_TZJZH
            WHERE BDRQ <> 0
			AND   DT = '%d{yyyyMMdd}'
			GROUP BY khh)T1
ON          T.CUST_NO = T1.khh
WHERE       ORDI_CUST_STAT = '0'
AND         T.BUS_DATE = %d{yyyyMMdd}
AND         T1.bdrq IS NOT NULL
;

--休眠激活日期
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'034'                                AS IMPO_PHS_CD 
			       ,'休眠激活日期'                         AS IMPO_PHS_DSC
			       ,CAST(T1.dt AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN  
(select cust_no,min(dt1) as dt from
(SELECT cust_no,dt1,khh,bdrq 
FROM DDW_PROD.CUST_TRD_TEST_%d{yyyyMMdd} T
INNER JOIN (SELECT khh,MIN(bdrq) as bdrq
            FROM jzjycx.GFZHGL_TZJZH
            WHERE BDRQ <> 0
			AND   DT = '%d{yyyyMMdd}'
			GROUP BY khh) T1
ON T.CUST_NO = T1.KHH
where dt1 >bdrq
)t
group by cust_no)T1
ON          T.CUST_NO = T1.cust_no
WHERE       ORDI_CUST_STAT = '0'
AND         T.BUS_DATE = %d{yyyyMMdd}
AND         T1.dt IS NOT NULL
;


--投资偏好变化
INSERT INTO DDW_PROD.T_DDW_CUST_LCS_STATAS
(
                CUST_NO     
			   ,IMPO_PHS_CD 
			   ,IMPO_PHS_DSC
			   ,DT          
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT              T.CUST_NO     
			       ,'035'                                AS IMPO_PHS_CD 
			       ,'投资偏好变化'                         AS IMPO_PHS_DSC
			       ,CAST(T1.TZPHBH AS STRING)     AS DT
FROM                DDW_PROD.T_DDW_F00_CUST_CUST_INFO T
LEFT JOIN  (SELECT CUST_NO1 AS CUST_NO,BUS_DATE2 AS TZPHBH FROM(
            SELECT 
                        T1.CUST_NO      AS CUST_NO1
            		   ,T1.LABEL_VALUE  AS LABEL_VALUE1
                       ,T1.BUS_DATE     AS BUS_DATE1
                       ,T1.NUM          AS NUM1
            		   ,T2.CUST_NO      AS CUST_NO2
            		   ,T2.LABEL_VALUE  AS LABEL_VALUE2
                       ,T2.BUS_DATE     AS BUS_DATE2
                       ,T2.NUM          AS NUM2
            FROM        DDW_PROD.T_DDW_LM_LABEL_V_C_HIS_TEMP111_%d{yyyyMMdd} T1
            LEFT JOIN   DDW_PROD.T_DDW_LM_LABEL_V_C_HIS_TEMP111_%d{yyyyMMdd} T2
            ON          T1.CUST_NO  = T2.CUST_NO
            AND         T1.NUM      = T2.NUM - 1
)T1
WHERE       LABEL_VALUE1 <> LABEL_VALUE2
AND         BUS_DATE2 IS NOT NULL)T1
ON          T.CUST_NO = T1.CUST_NO
WHERE       ORDI_CUST_STAT = '0'
AND         T.BUS_DATE = %d{yyyyMMdd}
AND         T1.TZPHBH IS NOT NULL
;
------插入数据结束

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_LCS_STATAS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;


---------删除临时表
DROP TABLE IF EXISTS DDW_PROD.CUST_OPN_DT_%d{yyyyMMdd};
DROP TABLE IF EXISTS DDW_PROD.CUST_TRD_DT_%d{yyyyMMdd};
DROP TABLE IF EXISTS DDW_PROD.CUST_TRD_TEST_%d{yyyyMMdd};
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_LABEL_V_C_HIS_TEMP111_%d{yyyyMMdd};
DROP TABLE IF EXISTS EDW_PROD.T_EDW_T02_TYJDJDX_KH_TEMP1111_%d{yyyyMMdd};
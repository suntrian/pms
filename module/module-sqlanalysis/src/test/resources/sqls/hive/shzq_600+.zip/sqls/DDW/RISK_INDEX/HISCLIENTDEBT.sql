------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户负债集中度                                                                      */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

--------------插入数据-------------------
INSERT OVERWRITE RISK_INDEX.HISCLIENTDEBT
(
        TRADEDATE             --日期                                     
       ,UNIT_CODE             --所属机构（1、国泰君安证券；2、上海证券) 
       ,BRANCH_CODE           --营业部                                  
       ,SUB_BRANCH_CODE       --分支机构                                 
       ,ID_TYPE               --证件类型                                 
       ,ID_NO                 --证件号码                                 
       ,CUSTOMER_NO           --客户代码                                 
       ,CLIENT_NAME           --客户名称                               
       ,PLEDGE_ASSET          --担保资产                                  
       ,PLEDGE_ASSET_CHG      --担保资产较上期增减                      
       ,TOTAL_DEBTS           --负债                                     
       ,TOTAL_DEBTS_CHG       --负债较上期增减                                                                             								 			                                                             
 ) 
 PARTITION(DT = '%d{yyyyMMdd}')
 SELECT 
                   CAST(t.TRADEDATE AS CHAR(8))                                  AS TRADEDATE             --日期                                                       
                  ,CAST('2' AS VARCHAR(160))                                     AS UNIT_CODE             --所属机构（1、国泰君安证券；2、上海证券)                      
                  ,t.BRANCH_CODE                                                 AS BRANCH_CODE           --营业部                                                             
                  ,CAST('1' AS VARCHAR(40))                                     AS SUB_BRANCH_CODE       --分支机构                                                                                       
                  ,t.ID_TYPE                                                     AS ID_TYPE               --证件类型                                                       
                  ,t.ID_NO                                                       AS ID_NO                 --证件号码                                                  
                  ,t.CUSTOMER_NO                                                 AS CUSTOMER_NO           --客户代码                                                    
                  ,t.CLIENT_NAME                                                 AS CLIENT_NAME           --客户名称                                              
                  ,CAST(t.PLEDGE_ASSET AS DECIMAL(20,4))                         AS PLEDGE_ASSET          --担保资产                                                          						   
                  ,CAST(t.PLEDGE_ASSET-NVL(a1.PLEDGE_ASSET,0) AS DECIMAL(20,4))  AS PLEDGE_ASSET_CHG      --担保资产较上期增减                      
                  ,CAST(t.TOTAL_DEBTS AS DECIMAL(20,4))                          AS TOTAL_DEBTS           --负债                                     
                  ,CAST(t.TOTAL_DEBTS-NVL(a1.TOTAL_DEBTS,0) AS DECIMAL(20,4))    AS TOTAL_DEBTS_CHG       --负债较上期增减                            
FROM (SELECT             t.OC_DATE                      AS TRADEDATE
                        ,t.BRANCH_NO                    AS BRANCH_CODE
				        ,a2.ID_KIND                     AS ID_TYPE
				        ,a2.ID_NO                       AS ID_NO
				        ,t.CLIENT_ID                    AS CUSTOMER_NO
				        ,a2.CLIENT_NAME                 AS CLIENT_NAME
				        ,SUM(NVL(a1.ASSET_BALANCE,0))   AS PLEDGE_ASSET
				        ,SUM(t.BALANCE)                 AS TOTAL_DEBTS
      FROM          HSFK.HSMAN_HISCLIENTFINANCING            t  
      LEFT JOIN     HSFK.HSMAN_HISCLIENTASSET                a1
      ON            t.client_id     = a1.client_id
      AND           t.branch_no     = a1.branch_no
      AND           t.oc_date       = a1.oc_date
      AND           t.business_type = a1.business_type
	  AND           a1.DT          = '%d{yyyyMMdd}'
      LEFT JOIN     HSFK.HSMAN_CLIENT                         a2
      ON            t.CLIENT_ID    = a2.CLIENT_ID
      WHERE         t.OC_DATE      = %d{yyyyMMdd}
	  AND           t.DT           = '%d{yyyyMMdd}'
	  AND           t.business_type = '0'
      GROUP BY      TRADEDATE
                   ,BRANCH_CODE
                   ,ID_TYPE
                   ,ID_NO
                   ,CUSTOMER_NO
                   ,CLIENT_NAME
      )                                                       t
LEFT JOIN (SELECT BRANCH_CODE
                  ,ID_TYPE
				  ,ID_NO
                  ,CUSTOMER_NO
                  ,PLEDGE_ASSET
				  ,TOTAL_DEBTS
           FROM   RISK_INDEX.HISCLIENTDEBT  a
		   WHERE EXISTS(SELECT * FROM EDW_PROD.T_EDW_T99_TRD_DATE b
		                WHERE  b.BUS_DATE                         = %d{yyyyMMdd} 
		                AND    b.TRD_DT                           = %d{yyyyMMdd}
						AND    CAST(a.TRADEDATE AS DECIMAL(38,0)) = b.LST_TRD_D
		               )
           )  a1
 ON  t.BRANCH_CODE   = a1.BRANCH_CODE
 AND t.ID_TYPE       = a1.ID_TYPE
 AND t.ID_NO         = a1.ID_NO
 AND t.CUSTOMER_NO   = a1.CUSTOMER_NO
 ;
		
---------------- 插入数据结束 -----------------------  
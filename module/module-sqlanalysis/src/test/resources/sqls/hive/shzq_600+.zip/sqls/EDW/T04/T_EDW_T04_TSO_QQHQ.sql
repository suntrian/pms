--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:个股期权历史行情表                                                                   */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  

------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TSO_QQHQ
 (
                                     RQ                                  --日期                                 
                                    ,JYS                                 --交易所                                
                                    ,HYDM                                --期权合约代码                             
                                    ,ZXJ                                 --最新价                                
                                    ,JSJ                                 --结算价                                
                                    ,ZSP                                 --昨收盘                                
                                    ,ZJSJ                                --昨结算价                               
                                    ,JKP                                 --今开盘                                
                                    ,ZGJ                                 --最高价                                
                                    ,ZDJ                                 --最低价                                
                                    ,CJSL                                --成交数量                               
                                    ,CJJE                                --成交金额                               
                                    ,HYDW                                --合约单位                               
                                    ,HYMC                                --合约名称   
                                    ,XTBS								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.RQ                                  as RQ                                  --日期                                  
                                    ,t.JYS                                 as JYS                                 --交易所                                 
                                    ,t.HYDM                                as HYDM                                --合约代码                                
                                    ,t.ZXJ                                 as ZXJ                                 --最新价                                 
                                    ,t.JSJ                                 as JSJ                                 --结算价                                 
                                    ,t.ZSP                                 as ZSP                                 --昨收盘                                 
                                    ,t.ZJSJ                                as ZJSJ                                --昨结算价                                
                                    ,t.JKP                                 as JKP                                 --今开盘                                 
                                    ,t.ZGJ                                 as ZGJ                                 --最高价                                 
                                    ,t.ZDJ                                 as ZDJ                                 --最低价                                 
                                    ,t.CJSL                                as CJSL                                --成交数量                                
                                    ,t.CJJE                                as CJJE                                --成交金额                                
                                    ,t.HYDW                                as HYDW                                --合约单位                                
                                    ,t.HYMC                                as HYMC                                --合约名称        
 								    ,'GGQQ'                                as XTBS
  								   
 FROM 		GGQQCX.DATACENTER_TSO_QQHQ 			t
 WHERE 		t.DT = '%d{yyyyMMdd}';
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TSO_QQHQ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

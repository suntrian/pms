-- /* ***************************************** SQL Begin ***************************************** */
-- /* 脚本功能:反洗钱需求明细报表_电商                                                        		*/
-- /* 创建人:OYJ                                                                                    */
-- /* 创建时间:2019-11-12                                                                           */


----表1.1.1个人客户姓名或证件信息字段为空
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP;
CREATE TABLE DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP 
AS
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'1_1_1' AS CDG                                           --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
AND (
       LENGTH(TRIM(NVL(T1.KHMC,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(CAST(T1.ZJLB AS STRING),''))) = 0
	  OR
	   LENGTH(TRIM(NVL(T1.ZJBH,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(CAST(T1.ZJJZRQ AS STRING),''))) = 0
    )
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '1_1_1')
;

----表1.2.1机构客户姓名或证件信息字段为空
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'1_2_1' AS CDG                                           --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB <> 0
AND (
       LENGTH(TRIM(NVL(T1.KHMC,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(CAST(T1.ZJLB AS STRING),''))) = 0
	  OR
	   LENGTH(TRIM(NVL(T1.ZJBH,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(CAST(T1.ZJJZRQ AS STRING),''))) = 0
    )
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '1_2_1')
;

----表4_客户姓名中包含非法字符
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'4' AS CDG                                               --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TJGKHXX T3
ON T3.KHH = T1.KHH
AND T3.DT = T1.DT
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND
(
( T1.KHLB = 0
  AND ((T1.ZJLB = 0 and (   regexp_like(regexp_replace(NVL(T1.KHMC,''),'[.,（,(,),）]',''),'[[:digit:]]') > 0 --身份证开户含有字符或数字，不含'.()（）'
                         or regexp_like(regexp_replace(NVL(T1.KHMC,''),'[.,（,(,),）]',''),'[[:punct:]]') > 0
					     or REGEXP_LIKE(TRIM(NVL(T1.KHMC,'')),'[[:alpha:]]') > 0
				        )
       )
        OR
       (T1.ZJLB <> 0 and (   regexp_like(regexp_replace(T1.KHMC,'[.,（,(,),）,-,—]',''),'[[:digit:]]') > 0 --非身份证开户含有字符或数字，不含'.()-（）'
                          or regexp_like(regexp_replace(T1.KHMC,'[.,（,(,),）,-,—]',''),'[[:punct:]]') > 0
                         )
       )
        OR
	     T1.KHH = '103383304696'
      )
)
OR
(
  T1.KHLB <> 0
  AND NVL(T3.CPBZ,0) <> 1
  AND ( regexp_like(regexp_replace(NVL(T1.KHMC,''),'[-,—,（,(,),）]',''),'[[:digit:]]') > 0 --含有字符或数字，不含'.()（）'
       or regexp_like(regexp_replace(NVL(T1.KHMC,''),'[-,—,（,(,),）]',''),'[[:punct:]]') > 0
	   or (NVL(T1.ZJLB,9) = 0 and REGEXP_LIKE(TRIM(NVL(T1.KHMC,'')),'[[:alpha:]]') > 0)
      )
)
)
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '4')
;

----表5.1_证件编号为全0和1或长度小于5
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'5_1' AS CDG                                             --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND  LENGTH(TRIM(NVL(T1.ZJBH,''))) > 0
AND ( LENGTH(REGEXP_REPLACE(TRIM(T1.ZJBH),'[0,1]','')) = 0 --证件编号全为0、1
     OR
	  LENGTH(TRIM(T1.ZJBH)) < 5
	)
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '5_1')
;

----表5.2非个人证件类型开个人户或非机构证件类型开机构户
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'5_2' AS CDG                                             --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND
(
    (T1.KHLB = 0 AND NVL(T1.ZJLB,999) IN (7,8,9,10,11,12,13,14,24,25))
  OR
    (T1.KHLB <> 0 AND NVL(T1.ZJLB,999) IN (0,1,2,3,4,5,6,15,16,18,19,20,22,23,27))
)
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '5_2')
;

----表5.3.1个人客户身份证不符合校验规则
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'5_3_1' AS CDG                                           --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
AND LENGTH(TRIM(NVL(T1.ZJBH,''))) > 0
AND NVL(T1.ZJLB,999) = 0
AND (      LENGTH(TRIM(NVL(T1.ZJBH,''))) NOT IN (15,18)
	   OR (LENGTH(TRIM(NVL(T1.ZJBH,''))) IN (15,18) AND LENGTH(REGEXP_REPLACE(SUBSTR(TRIM(NVL(T1.ZJBH,'')),1,1),'[1-9]','')) > 0)
	   OR (LENGTH(TRIM(NVL(T1.ZJBH,''))) IN (15,18) AND LENGTH(REGEXP_REPLACE(SUBSTR(TRIM(NVL(T1.ZJBH,'')),2,16),'[0-9]','')) > 0)
	   OR (LENGTH(TRIM(NVL(T1.ZJBH,''))) = 18
	       AND                                                      --最后一位不符合校验规则
              ( CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),1,1) AS INT) * 7
              + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),2,1) AS INT) * 9
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),3,1) AS INT) * 10
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),4,1) AS INT) * 5
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),5,1) AS INT) * 8
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),6,1) AS INT) * 4
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),7,1) AS INT) * 2
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),8,1) AS INT) * 1
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),9,1) AS INT) * 6
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),10,1) AS INT) * 3
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),11,1) AS INT) * 7
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),12,1) AS INT) * 9
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),13,1) AS INT) * 10
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),14,1) AS INT) * 5
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),15,1) AS INT) * 8
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),16,1) AS INT) * 4
	          + CAST(SUBSTR(TRIM(NVL(T1.ZJBH,'')),17,1) AS INT) * 2) % 11
	       <>
	          CASE WHEN SUBSTR(TRIM(NVL(T1.ZJBH,'')),18,1) = '1' THEN 0
                   WHEN SUBSTR(TRIM(NVL(T1.ZJBH,'')),18,1) = '0' THEN 1
	               WHEN UPPER(SUBSTR(TRIM(NVL(T1.ZJBH,'')),18,1)) = 'X' THEN 2
	               WHEN SUBSTR(TRIM(NVL(T1.ZJBH,'')),18,1) = '9' THEN 3
	               WHEN SUBSTR(TRIM(NVL(T1.ZJBH,'')),18,1) = '8' THEN 4
	               WHEN SUBSTR(TRIM(NVL(T1.ZJBH,'')),18,1) = '7' THEN 5
	               WHEN SUBSTR(TRIM(NVL(T1.ZJBH,'')),18,1) = '6' THEN 6
	               WHEN SUBSTR(TRIM(NVL(T1.ZJBH,'')),18,1) = '5' THEN 7
	               WHEN SUBSTR(TRIM(NVL(T1.ZJBH,'')),18,1) = '4' THEN 8
	               WHEN SUBSTR(TRIM(NVL(T1.ZJBH,'')),18,1) = '3' THEN 9
	               WHEN SUBSTR(TRIM(NVL(T1.ZJBH,'')),18,1) = '2' THEN 10
              ELSE 99 END
	      )
	)
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '5_3_1')
;

----表5.3.2个人客户港澳通行证不符合校验规则
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'5_3_2' AS CDG                                           --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
AND  LENGTH(TRIM(NVL(T1.ZJBH,''))) > 0
AND NVL(T1.ZJLB,999) = 4
AND (  LENGTH(TRIM(NVL(T1.ZJBH,''))) NOT IN (9,11)
	 OR SUBSTR(TRIM(NVL(T1.ZJBH,'')),1,1) NOT IN ('H','M')
	 OR LENGTH(REGEXP_REPLACE(SUBSTR(TRIM(NVL(T1.ZJBH,'')),2),'[0-9]','')) > 0
	)
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '5_3_2')
;

----表5.3.3个人客户台湾通行证不符合校验规则
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'5_3_3' AS CDG                                           --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
AND  LENGTH(TRIM(NVL(T1.ZJBH,''))) > 0
AND NVL(T1.ZJLB,999) = 15
AND (LENGTH(TRIM(NVL(T1.ZJBH,''))) <> 8 OR LENGTH(REGEXP_REPLACE(TRIM(NVL(T1.ZJBH,'')),'[0-9]','')) > 0)
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '5_3_3')
;

----表5.3.4_个人客户其他证件不符合校验规则
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'5_3_4' AS CDG                                           --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
AND LENGTH(TRIM(NVL(T1.ZJBH,''))) > 0
AND NVL(T1.ZJLB,999) NOT IN (0,4,7,8,9,10,11,12,13,14,15,24,25,999)
AND LENGTH(REGEXP_REPLACE(TRIM(NVL(T1.ZJBH,'')),'[[:alnum:]]','')) > 0
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '5_3_4')
;

----表5.4.1_机构客户营业执照不符合校验规则
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'5_4_1' AS CDG                                           --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB <> 0
AND LENGTH(TRIM(NVL(T1.ZJBH,''))) > 0
AND NVL(T1.ZJLB,999) = 8
AND (
         LENGTH(TRIM(T1.ZJBH)) NOT IN (15,18)
     OR (LENGTH(TRIM(NVL(T1.ZJBH,''))) = 15 AND REGEXP_LIKE(TRIM(NVL(T1.ZJBH,'')),'[[:alpha:]]') > 0)
     OR (LENGTH(TRIM(NVL(T1.ZJBH,''))) = 18 AND REGEXP_LIKE(TRIM(NVL(T1.ZJBH,'')),'[IiOoZzSsVv]') > 0)
    )
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '5_4_1')
;

----表5.4.2机构客户其他可开户证件不符合校验规则
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'5_4_2' AS CDG                                           --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB <> 0
AND NVL(T1.ZJLB,999) IN (7,9,10,11,12,13,14,24,25,26,99)
AND LENGTH(TRIM(NVL(T1.ZJBH,''))) > 0
AND REGEXP_LIKE(REGEXP_REPLACE(NVL(T1.ZJBH,''),'[-,(,),－,（,）]',''),'[[:punct:]]') > 0
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '5_4_2')
;

----表6.3_个人客户15位身份证开户
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'6_3' AS CDG                                             --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
AND NVL(T1.ZJLB,999) = 0
AND LENGTH(TRIM(NVL(T1.ZJBH,''))) = 15
AND LENGTH(REGEXP_REPLACE(TRIM(NVL(T1.ZJBH,'')),'[[:alnum:]]','')) = 0
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '6_3')
;

----表7_同一证件姓名不同
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'7' AS CDG                                               --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
INNER JOIN
(
SELECT DISTINCT ZJBH
FROM 
(
SELECT ZJBH,RANK() OVER(PARTITION BY ZJBH ORDER BY KHMC DESC) AS NUM
FROM
(
SELECT KHMC,CASE WHEN ZJLB = 0 AND LENGTH(TRIM(ZJBH)) = 18 THEN CONCAT(SUBSTR(ZJBH,1,6),SUBSTR(ZJBH,9,9)) ELSE ZJBH END AS ZJBH
FROM YGTCX.CIF_TKHXX
WHERE DT = '%d{yyyyMMdd}'
AND ZJLB = 0
AND KHZT IN (0,99)
AND LENGTH(TRIM(ZJBH)) IN (15,18)
AND LENGTH(REGEXP_REPLACE(TRIM(ZJBH),'[0-9,X,x]','')) = 0
AND KHH IN(SELECT KHH FROM YGTCX.CIF_TKHSX WHERE DT= '%d{yyyyMMdd}' AND SXDM = 'KHFXJB' AND SXZ IN ('0','1','2','8','19'))
AND CAST(YYB AS STRING) IN (SELECT BRH_NO FROM DDW_PROD.T_DDW_INR_ORG_BRH)
AND KHH NOT IN (SELECT KHH FROM YGTCX.CIF_TJGKHXX WHERE DT= '%d{yyyyMMdd}' AND NVL(CPBZ,0) = 1)
UNION ALL
SELECT KHMC,ZJBH
FROM YGTCX.CIF_TKHXX
WHERE DT = '%d{yyyyMMdd}'
AND ZJLB <> 0
AND KHZT IN (0,99)
AND KHH IN(SELECT KHH FROM YGTCX.CIF_TKHSX WHERE DT= '%d{yyyyMMdd}' AND SXDM = 'KHFXJB' AND SXZ IN ('0','1','2','8','19'))
AND CAST(YYB AS STRING) IN (SELECT BRH_NO FROM DDW_PROD.T_DDW_INR_ORG_BRH)
AND KHH NOT IN (SELECT KHH FROM YGTCX.CIF_TJGKHXX WHERE DT= '%d{yyyyMMdd}' AND NVL(CPBZ,0) = 1)
) A
) B
WHERE NUM > 1
) T18
ON T18.ZJBH = CASE WHEN T1.ZJLB = 0 AND LENGTH(TRIM(T1.ZJBH)) = 18 THEN CONCAT(SUBSTR(T1.ZJBH,1,6),SUBSTR(T1.ZJBH,9,9)) ELSE T1.ZJBH END
LEFT JOIN YGTCX.CIF_TJGKHXX T19
ON T19.KHH = T1.KHH
AND T19.DT = T1.DT
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND LENGTH(TRIM(NVL(T1.ZJBH,''))) > 0
AND (T1.KHLB = 0 OR (T1.KHLB <> 0 AND NVL(T19.CPBZ,0) <> 1))
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '7')
;


----表1.1.2个人客户其他信息字段为空
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP;
CREATE TABLE DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP 
AS
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'1_1_2' AS CDG                                           --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TGRKHXX T3
ON T3.KHH = T1.KHH
AND T3.DT = T1.DT
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
AND (
       LENGTH(TRIM(NVL(CAST(T3.XB AS STRING),''))) = 0
	  OR
	   NVL(T1.GJ,0) = 0
	  OR
	   LENGTH(TRIM(NVL(T1.DZ,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(T1.SJ,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(CAST(T3.ZYDM AS STRING),''))) = 0
    )
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '1_1_2')
;

----表1.2.2_机构客户其他信息字段为空
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'1_2_2' AS CDG                                           --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TJGKHXX T3
ON T3.KHH = T1.KHH
AND T3.DT = T1.DT
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
LEFT JOIN
(
  SELECT KHH
  FROM YGTCX.CIF_TDLR
  WHERE DT = '%d{yyyyMMdd}'
  GROUP BY KHH
  HAVING MIN(LENGTH(TRIM(NVL(DLRMC,'')))) > 0 AND MIN(LENGTH(TRIM(NVL(CAST(ZJLB AS STRING),'')))) > 0 AND MIN(LENGTH(TRIM(NVL(ZJBH,'')))) > 0 AND MIN(LENGTH(TRIM(NVL(CAST(ZJJZRQ AS STRING),'')))) > 0
) T8
ON T1.KHH = T8.KHH
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB <> 0
AND (
	   LENGTH(TRIM(NVL(T1.ZJDZ,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(T3.JGJYFW,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(T3.KGGD,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(CAST(T3.KGGDZJLB AS STRING),''))) = 0
	  OR
	   LENGTH(TRIM(NVL(T3.KGGDZJBH,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(CAST(T3.KGGDZJJZRQ AS STRING),''))) = 0
	  OR
	   LENGTH(TRIM(NVL(T3.FRDBXM,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(CAST(T3.FRDBZJLB AS STRING),''))) = 0
	  OR
	   LENGTH(TRIM(NVL(T3.FRDBZJBH,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(CAST(T3.FRDBZJJZRQ AS STRING),''))) = 0
	  OR
	   LENGTH(TRIM(NVL(T3.FZRXM,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(CAST(T3.FZRZJLB AS STRING),''))) = 0
	  OR
	   LENGTH(TRIM(NVL(T3.FZRZJBH,''))) = 0
	  OR
	   LENGTH(TRIM(NVL(CAST(T3.FZRZJJZRQ AS STRING),''))) = 0
	  OR
	   NVL(T8.KHH,'') = ''
    )
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '1_2_2')
;

----表2.1_机构客户受益所有人信息未收集
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'2_1' AS CDG                                             --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TJGKHXX T3
ON T3.KHH = T1.KHH
AND T3.DT = T1.DT
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
LEFT JOIN 
(
  SELECT CID
        ,MIN(LENGTH(TRIM(NVL(SYRXM,'')))) AS SYRXM
		,MIN(LENGTH(TRIM(NVL(CAST(SYRZJLB AS STRING),'')))) AS SYRZJLB
		,MIN(LENGTH(TRIM(NVL(SYRZJBH,'')))) AS SYRZJBH
		,MIN(LENGTH(TRIM(NVL(CAST(SYRZJJZRQ AS STRING),'')))) AS SYRZJJZRQ
		,MIN(LENGTH(TRIM(NVL(SYRDZ,'')))) AS SYRDZ
  FROM YGTCX.CIF_TJGSYSYR
  WHERE DT='%d{yyyyMMdd}'
  GROUP BY CID
) T7
ON T1.CID = T7.CID
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB <> 0
AND NVL(T3.JGLB,0) <> 2
AND (
         NVL(T7.CID,'') = ''
      OR (T7.SYRXM = 0 AND T7.SYRZJLB = 0 AND T7.SYRZJBH = 0 AND T7.SYRZJJZRQ = 0 AND T7.SYRDZ = 0)
    )
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '2_1')
;

----表2.2_机构客户受益所有人信息收集不完整
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'2_2' AS CDG                                             --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TJGKHXX T3
ON T3.KHH = T1.KHH
AND T3.DT = T1.DT
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
LEFT JOIN 
(
  SELECT CID
        ,MIN(LENGTH(TRIM(NVL(SYRXM,'')))) AS SYRXM
		,MIN(LENGTH(TRIM(NVL(CAST(SYRZJLB AS STRING),'')))) AS SYRZJLB
		,MIN(LENGTH(TRIM(NVL(SYRZJBH,'')))) AS SYRZJBH
		,MIN(LENGTH(TRIM(NVL(CAST(SYRZJJZRQ AS STRING),'')))) AS SYRZJJZRQ
		,MIN(LENGTH(TRIM(NVL(SYRDZ,'')))) AS SYRDZ
  FROM YGTCX.CIF_TJGSYSYR
  WHERE DT='%d{yyyyMMdd}'
  GROUP BY CID
) T7
ON T1.CID = T7.CID
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB <> 0
AND NVL(T3.JGLB,0) <> 2
AND NVL(T7.CID,'') <> ''
AND NOT (T7.SYRXM = 0 AND T7.SYRZJLB = 0 AND T7.SYRZJBH = 0 AND T7.SYRZJJZRQ = 0 AND T7.SYRDZ = 0)
AND NOT (T7.SYRXM > 0 AND T7.SYRZJLB > 0 AND T7.SYRZJBH > 0 AND T7.SYRZJJZRQ > 0 AND T7.SYRDZ = 0)
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '2_2')
;

----表3_个人客户性别与编码规则不一致
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'3' AS CDG                                               --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TGRKHXX T3
ON T3.KHH = T1.KHH
AND T3.DT = T1.DT
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
AND T1.ZJLB = 0
AND LENGTH(TRIM(T1.ZJBH)) IN (15,18)
AND LENGTH(REGEXP_REPLACE(TRIM(T1.ZJBH),'[0-9,x,X]','')) = 0
AND CASE WHEN T1.ZJLB = 0 AND LENGTH(T1.ZJBH) = 18 AND SUBSTR(T1.ZJBH,17,1) IN ('1','3','5','7','9') THEN 1
         WHEN T1.ZJLB = 0 AND LENGTH(T1.ZJBH) = 18 AND SUBSTR(T1.ZJBH,17,1) IN ('2','4','6','8','0') THEN 2
		 WHEN T1.ZJLB = 0 AND LENGTH(T1.ZJBH) = 15 AND SUBSTR(T1.ZJBH,15,1) IN ('1','3','5','7','9') THEN 1
		 WHEN T1.ZJLB = 0 AND LENGTH(T1.ZJBH) = 15 AND SUBSTR(T1.ZJBH,15,1) IN ('2','4','6','8','0') THEN 2
	ELSE 9 END <> NVL(T3.XB,99)
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '3')
;

----表5.4.3_机构客户营业执照非三证合一
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'5_4_3' AS CDG                                           --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB <> 0
AND NVL(T1.ZJLB,999) = 8
AND LENGTH(TRIM(NVL(T1.ZJBH,''))) < 18
AND LENGTH(TRIM(NVL(T1.ZJBH,''))) > 0
--AND (LENGTH(REGEXP_REPLACE(TRIM(NVL(T1.ZJBH,'')),'[[:digit:]]','')) = 0 OR T1.KHH = '100620080326')
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '5_4_3')
;

----表8国籍与证件类型不匹配
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'8' AS CDG                                               --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND NVL(T1.GJ,0) <> 0
AND (
      (NVL(T1.GJ,0) = 156 AND T1.ZJLB NOT IN (0,2,3,5,21,22,23,7,8,9,10,11,12,13,14,24,25,1))
	 OR
	  (NVL(T1.GJ,0) = 344 AND T1.ZJLB NOT IN (4,16,19,27))
	 OR
	  (NVL(T1.GJ,0) = 446 AND T1.ZJLB NOT IN (4,16,20,27))
	 OR
	  (NVL(T1.GJ,0) = 158 AND T1.ZJLB NOT IN (15,16,27))
	 OR
	  (NVL(T1.GJ,0) NOT IN (156,158,344,446,0) AND T1.ZJLB NOT IN (1,6,18))
    )
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '8')
;

----表9.2_联系手机不符合规范
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'9_2' AS CDG                                             --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND LENGTH(TRIM(NVL(SJ,''))) > 0
AND (LENGTH(TRIM(NVL(SJ,''))) <> 11 OR LENGTH(REGEXP_REPLACE(TRIM(NVL(SJ,'')),'[0-9]','')) > 0 OR SUBSTR(TRIM(NVL(SJ,'')),1,1) <> '1')
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '9_2')
;

----表10.2_职业登记为其他客户(特别说明为空)
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'10_2' AS CDG                                            --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TGRKHXX T3
ON T3.KHH = T1.KHH
AND T3.DT = T1.DT
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
AND NVL(T3.ZYDM,999) = 99
AND LENGTH(TRIM(NVL(T1.TBSM,''))) = 0
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '10_2')
;

----表10.3_职业登记为其他客户(特别说明不为空)
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'10_3' AS CDG                                            --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TGRKHXX T3
ON T3.KHH = T1.KHH
AND T3.DT = T1.DT
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
AND NVL(T3.ZYDM,999) = 99
AND LENGTH(TRIM(NVL(T1.TBSM,''))) > 0
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '10_3')
;

----表12证件截止日期不规范
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'12' AS CDG                                              --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND LENGTH(TRIM(NVL(CAST(T1.ZJJZRQ AS STRING),''))) > 0
AND (   LENGTH(CAST(NVL(T1.ZJJZRQ,0) AS STRING)) <> 8
     OR 
	    ( LENGTH(CAST(NVL(T1.ZJJZRQ,0) AS STRING)) = 8
	      AND (SUBSTR(CAST(NVL(T1.ZJJZRQ,0) AS STRING),1,2) <> '20' AND SUBSTR(CAST(NVL(T1.ZJJZRQ,0) AS STRING),1,3) <> '199' AND NVL(T1.ZJJZRQ,0) <> 29991231 AND NVL(T1.ZJJZRQ,0) <> 30001231)
        )
    )
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '12')
;

----表13.1_个人客户联系地址不符合规范
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'13_1' AS CDG                                            --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
AND LENGTH(TRIM(NVL(T1.DZ,''))) > 0
AND (   (TRIM(NVL(T1.DZ,'')) NOT LIKE '%省%' AND TRIM(NVL(T1.DZ,'')) NOT LIKE '%市%' AND TRIM(NVL(T1.DZ,'')) NOT LIKE '%区%')      --不包含省、市、区3个汉字之一
     OR LENGTH(REGEXP_REPLACE(REGEXP_REPLACE(TRIM(NVL(T1.DZ,'')),'[[:punct:]]',''),'[[:alnum:],（,）]','')) < 24                   --少于8个汉字
    )
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '13_1')
;

----表13.2_机构客户联系地址不符合规范
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP
SELECT 
        CAST(T1.YYB AS STRING) AS YYB                            --1 .营业部代码
	   ,T2.BRH_FULLNM AS YYBMC                                   --2 .营业部名称
	   ,T1.KHH                                                   --3 .客户号
	   ,T1.KHMC                                                  --4 .客户姓名
	   ,'13_2' AS CDG                                            --5 .编号
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.YYB NOT IN(1,1052,1058,1088,4444)
AND NVL(T1.KHRQ,10000101) BETWEEN 10000101 AND %d{yyyyMMdd}
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB <> 0
AND LENGTH(TRIM(NVL(T1.ZJDZ,''))) > 0
AND (   (TRIM(NVL(T1.ZJDZ,'')) NOT LIKE '%省%' AND TRIM(NVL(T1.ZJDZ,'')) NOT LIKE '%市%' AND TRIM(NVL(T1.ZJDZ,'')) NOT LIKE '%区%')      --不包含省、市、区3个汉字之一
     OR LENGTH(REGEXP_REPLACE(REGEXP_REPLACE(TRIM(NVL(T1.ZJDZ,'')),'[[:punct:]]',''),'[[:alnum:],（,）]','')) < 24                       --少于8个汉字
    )
AND T1.KHH NOT IN (SELECT CUST_NO FROM DDW_PROD.T_DDW_EXCLU_CUST_LST_FXQ WHERE TAB_SEQ = '13_2')
;


----删除当日数据
ALTER TABLE DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS DROP IF EXISTS PARTITION(BUS_DATE = %d{yyyyMMdd});

----插入四禁客户数据
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS
(
 BRH_NO                                                                  -- 1.网点代号
,BRH_NAME                                                                -- 2.营业部名称
,CUST_NO                                                                 -- 3.客户号
,CUST_NAME                                                               -- 4.客户姓名
,SFYJYZH                                                                 -- 5.三年内是否有转账或交易记录
,TOT_AST                                                                 -- 6.总资产
,TOT_MKTVAL                                                              -- 7.总市值
,TOT_CPTL                                                                -- 8.总资金
,FBDN_TP                                                                 -- 9.禁止类型
,IP_PHONE                                                                --10.IP手机号
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT 
       T1.YYB AS BRH_NO                                                  -- 1.网点代号
      ,T1.YYBMC AS BRH_NAME                                              -- 2.营业部名称
      ,T1.KHH AS CUST_NO                                                 -- 3.客户号
      ,T1.KHMC AS CUST_NAME                                              -- 4.客户姓名
      ,CASE WHEN NVL(T3.KHH,'') <> '' THEN '有转帐或交易'
              WHEN NVL(T4.KHH,'') <> '' THEN '有转帐或交易'
			  WHEN NVL(T5.KHH,'') <> '' THEN '有转帐或交易'
			  WHEN NVL(T6.KHH,'') <> '' THEN '有转帐或交易'
         ELSE '没有转帐或交易' END AS SFYJYZH                            -- 5.是否有转帐或交易
      ,NVL(T2.TOT_AST,0) AS TOT_AST                                      -- 6.总资产
      ,NVL(T2.TOT_MKTVAL,0) AS TOT_MKTVAL                                -- 7.总市值
      ,NVL(T2.TOT_CPTL,0) AS TOT_CPTL                                    -- 8.总资金
      ,'四禁' AS FBDN_TP                                                 -- 9.禁止类型
      ,NVL(T7.IP_PHONE,'') AS IP_PHONE                                   --10.IP手机号
FROM (SELECT DISTINCT YYB,YYBMC,KHH,KHMC FROM DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP) T1
LEFT JOIN
(
  SELECT CUST_NO,SUM(TOT_AST) AS TOT_AST,SUM(TOT_MKTVAL) AS TOT_MKTVAL,SUM(TOT_CPTL) AS TOT_CPTL
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
) T2
ON T1.KHH = T2.CUST_NO
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM EDW_PROD.T_EDW_T05_TZJMXLS
  WHERE BUS_DATE BETWEEN 20160101 AND %d{yyyyMMdd}
  AND SUBSTR(YWKM,1,3) IN('101','102')
) T3
ON T1.KHH = T3.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM JZJYCX.DATACENTER_TJRCP_YH_WTLS
  WHERE CAST(DT AS INT) BETWEEN 20160101 AND %d{yyyyMMdd}
  AND YWDM IN ('020','022','024','039')
) T4
ON T1.KHH = T4.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM JZJYCX.DATACENTER_TOF_JJWTLS
  WHERE CAST(DT AS INT) BETWEEN 20160101 AND %d{yyyyMMdd}
  AND YWDM IN ('020','022','024','039')
) T5
ON T1.KHH = T5.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM EDW_PROD.T_EDW_T05_TWTLS
  WHERE BUS_DATE BETWEEN 20160101 AND %d{yyyyMMdd}
  AND WTLB IN (1,2,3,4,5,29,30,41,42,43,53,57,58,59,60,61,62,63,64,71,72,78,79,83,114,115)
  AND ZQLB NOT LIKE 'F%' 
) T6
ON T1.KHH = T6.KHH
LEFT JOIN
(
  SELECT KHH,IP_PHONE FROM
  (
    SELECT IP_PHONE,KHH,ROW_NUMBER() OVER(PARTITION BY KHH ORDER BY WTRQ DESC,WTSJ DESC) as ID,WTRQ,WTSJ,BUS_DATE
    FROM EDW_PROD.T_EDW_T05_TWTLS T
    WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) AS INT) AND %d{yyyyMMdd}
    --AND WTLB = 64
	AND NVL(IP_PHONE,'') <> ''
  ) T
  WHERE ID = 1
) T7
ON T1.KHH = T7.KHH
WHERE T1.KHH NOT IN (SELECT KHH FROM DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP)
;

----插入六禁客户数据
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS
(
 BRH_NO                                                                  -- 1.网点代号
,BRH_NAME                                                                -- 2.营业部名称
,CUST_NO                                                                 -- 3.客户号
,CUST_NAME                                                               -- 4.客户姓名
,SFYJYZH                                                                 -- 5.三年内是否有转账或交易记录
,TOT_AST                                                                 -- 6.总资产
,TOT_MKTVAL                                                              -- 7.总市值
,TOT_CPTL                                                                -- 8.总资金
,FBDN_TP                                                                 -- 9.禁止类型
,IP_PHONE                                                                --10.IP手机号
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT 
       T1.YYB AS BRH_NO                                                  -- 1.网点代号
      ,T1.YYBMC AS BRH_NAME                                              -- 2.营业部名称
      ,T1.KHH AS CUST_NO                                                 -- 3.客户号
      ,T1.KHMC AS CUST_NAME                                              -- 4.客户姓名
      ,CASE WHEN NVL(T3.KHH,'') <> '' THEN '有转帐或交易'
              WHEN NVL(T4.KHH,'') <> '' THEN '有转帐或交易'
			  WHEN NVL(T5.KHH,'') <> '' THEN '有转帐或交易'
			  WHEN NVL(T6.KHH,'') <> '' THEN '有转帐或交易'
         ELSE '没有转帐或交易' END AS SFYJYZH                            -- 5.是否有转帐或交易
      ,NVL(T2.TOT_AST,0) AS TOT_AST                                      -- 6.总资产
      ,NVL(T2.TOT_MKTVAL,0) AS TOT_MKTVAL                                -- 7.总市值
      ,NVL(T2.TOT_CPTL,0) AS TOT_CPTL                                    -- 8.总资金
      ,'六禁' AS FBDN_TP                                                 -- 9.禁止类型
      ,NVL(T7.IP_PHONE,'') AS IP_PHONE                                   --10.IP手机号
FROM (SELECT DISTINCT YYB,YYBMC,KHH,KHMC FROM DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP) T1
LEFT JOIN
(
  SELECT CUST_NO,SUM(TOT_AST) AS TOT_AST,SUM(TOT_MKTVAL) AS TOT_MKTVAL,SUM(TOT_CPTL) AS TOT_CPTL
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
) T2
ON T1.KHH = T2.CUST_NO
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM EDW_PROD.T_EDW_T05_TZJMXLS
  WHERE BUS_DATE BETWEEN 20160101 AND %d{yyyyMMdd}
  AND SUBSTR(YWKM,1,3) IN('101','102')
) T3
ON T1.KHH = T3.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM JZJYCX.DATACENTER_TJRCP_YH_WTLS
  WHERE CAST(DT AS INT) BETWEEN 20160101 AND %d{yyyyMMdd}
  AND YWDM IN ('020','022','024','039')
) T4
ON T1.KHH = T4.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM JZJYCX.DATACENTER_TOF_JJWTLS
  WHERE CAST(DT AS INT) BETWEEN 20160101 AND %d{yyyyMMdd}
  AND YWDM IN ('020','022','024','039')
) T5
ON T1.KHH = T5.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM EDW_PROD.T_EDW_T05_TWTLS
  WHERE BUS_DATE BETWEEN 20160101 AND %d{yyyyMMdd}
  AND WTLB IN (1,2,3,4,5,29,30,41,42,43,53,57,58,59,60,61,62,63,64,71,72,78,79,83,114,115)
  AND ZQLB NOT LIKE 'F%' 
) T6
ON T1.KHH = T6.KHH
LEFT JOIN
(
  SELECT KHH,IP_PHONE FROM
  (
    SELECT IP_PHONE,KHH,ROW_NUMBER() OVER(PARTITION BY KHH ORDER BY WTRQ DESC,WTSJ DESC) as ID,WTRQ,WTSJ,BUS_DATE
    FROM EDW_PROD.T_EDW_T05_TWTLS T
    WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) AS INT) AND %d{yyyyMMdd}
    --AND WTLB = 64
	AND NVL(IP_PHONE,'') <> ''
  ) T
  WHERE ID = 1
) T7
ON T1.KHH = T7.KHH
WHERE T1.KHH NOT IN (SELECT KHH FROM DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP)
;

----插入四禁和六禁客户数据
INSERT INTO DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS
(
 BRH_NO                                                                  -- 1.网点代号
,BRH_NAME                                                                -- 2.营业部名称
,CUST_NO                                                                 -- 3.客户号
,CUST_NAME                                                               -- 4.客户姓名
,SFYJYZH                                                                 -- 5.三年内是否有转账或交易记录
,TOT_AST                                                                 -- 6.总资产
,TOT_MKTVAL                                                              -- 7.总市值
,TOT_CPTL                                                                -- 8.总资金
,FBDN_TP                                                                 -- 9.禁止类型
,IP_PHONE                                                                --10.IP手机号
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT 
       T1.YYB AS BRH_NO                                                  -- 1.网点代号
      ,T1.YYBMC AS BRH_NAME                                              -- 2.营业部名称
      ,T1.KHH AS CUST_NO                                                 -- 3.客户号
      ,T1.KHMC AS CUST_NAME                                              -- 4.客户姓名
      ,CASE WHEN NVL(T3.KHH,'') <> '' THEN '有转帐或交易'
              WHEN NVL(T4.KHH,'') <> '' THEN '有转帐或交易'
			  WHEN NVL(T5.KHH,'') <> '' THEN '有转帐或交易'
			  WHEN NVL(T6.KHH,'') <> '' THEN '有转帐或交易'
         ELSE '没有转帐或交易' END AS SFYJYZH                            -- 5.是否有转帐或交易
      ,NVL(T2.TOT_AST,0) AS TOT_AST                                      -- 6.总资产
      ,NVL(T2.TOT_MKTVAL,0) AS TOT_MKTVAL                                -- 7.总市值
      ,NVL(T2.TOT_CPTL,0) AS TOT_CPTL                                    -- 8.总资金
      ,'四禁和六禁' AS FBDN_TP                                           -- 9.禁止类型
      ,NVL(T7.IP_PHONE,'') AS IP_PHONE                                   --10.IP手机号
FROM (SELECT DISTINCT YYB,YYBMC,KHH,KHMC FROM DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP) T1
LEFT JOIN
(
  SELECT CUST_NO,SUM(TOT_AST) AS TOT_AST,SUM(TOT_MKTVAL) AS TOT_MKTVAL,SUM(TOT_CPTL) AS TOT_CPTL
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
) T2
ON T1.KHH = T2.CUST_NO
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM EDW_PROD.T_EDW_T05_TZJMXLS
  WHERE BUS_DATE BETWEEN 20160101 AND %d{yyyyMMdd}
  AND SUBSTR(YWKM,1,3) IN('101','102')
) T3
ON T1.KHH = T3.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM JZJYCX.DATACENTER_TJRCP_YH_WTLS
  WHERE CAST(DT AS INT) BETWEEN 20160101 AND %d{yyyyMMdd}
  AND YWDM IN ('020','022','024','039')
) T4
ON T1.KHH = T4.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM JZJYCX.DATACENTER_TOF_JJWTLS
  WHERE CAST(DT AS INT) BETWEEN 20160101 AND %d{yyyyMMdd}
  AND YWDM IN ('020','022','024','039')
) T5
ON T1.KHH = T5.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM EDW_PROD.T_EDW_T05_TWTLS
  WHERE BUS_DATE BETWEEN 20160101 AND %d{yyyyMMdd}
  AND WTLB IN (1,2,3,4,5,29,30,41,42,43,53,57,58,59,60,61,62,63,64,71,72,78,79,83,114,115)
  AND ZQLB NOT LIKE 'F%' 
) T6
ON T1.KHH = T6.KHH
LEFT JOIN
(
  SELECT KHH,IP_PHONE FROM
  (
    SELECT IP_PHONE,KHH,ROW_NUMBER() OVER(PARTITION BY KHH ORDER BY WTRQ DESC,WTSJ DESC) as ID,WTRQ,WTSJ,BUS_DATE
    FROM EDW_PROD.T_EDW_T05_TWTLS T
    WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-6,0) AS INT) AND %d{yyyyMMdd}
    --AND WTLB = 64
	AND NVL(IP_PHONE,'') <> ''
  ) T
  WHERE ID = 1
) T7
ON T1.KHH = T7.KHH
WHERE T1.KHH IN (SELECT KHH FROM DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP)
;


----删除临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_6J_TMP;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS_4J_TMP;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_CUST_CHK_DTL_FXQ_DS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

INVALIDATE METADATA DDW_PROD.T_DDW_PRT_CUST_CHK_DTL_FXQ_DS;

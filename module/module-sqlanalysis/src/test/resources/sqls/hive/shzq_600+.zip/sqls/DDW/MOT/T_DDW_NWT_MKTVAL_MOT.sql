--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:市值监控                                                         */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-04-05                                                                        */ 
-----
---持仓表EDW未算市值:'510090','510120','512610','161507','501005','510680','501018','502013','501021' DDW根据行情算市值
---持仓表EDW算市值:'519505','519506','519508', DDW根据净值算市值
---519028转成519029
---错误类别0:市值相差大于5%,1:EDW有市值,DDW没有市值

--插入数据---
INSERT OVERWRITE DDW_PROD.T_DDW_NWT_MKTVAL_MOT
       (
                                     CUST_NO			                   --客户号  
                                    ,EXG                                   --交易所
									,SEC_CD                                --证券代码 
                                    ,SRC_TABLE                             --源表
                                    ,TAR_TABLE                             --目标表	                    
                                    ,ERR_CGY                               --错误类别
		)partition(bus_date = %d{yyyyMMdd})
  SELECT    t.CUST_NO                as CUST_NO
	        ,t.EXG                   as EXG
			,t.SEC_CD                as SEC_CD
			,'T_EDW_T02_TZQGL'       as SRC_TABLE
	        ,'T_DDW_F02_SEC_HLD_DTL' as TAR_TABLE
			,0                       as ERR_CGY
  FROM (SELECT  CUST_NO
	            ,EXG
			    ,SEC_CD
			    ,SUM(sec_mktval) as sec_newst_mktval
 	    FROM     DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
	    WHERE    BUS_DATE = %d{yyyyMMdd}
	    AND      SEC_CD NOT IN ('510090','501021','510120','501018','501005','512610','519505','161507','510680','519506','519508','501018','502013')
        AND      sec_cgy NOT IN ('A3','C3','Z6','Z3')
        AND      SUBSTR(SEC_CD1,1,2) NOT IN ('07','08')
	    GROUP BY CUST_NO,EXG,SEC_CD
	    )            t
  LEFT JOIN (SELECT  KHH
	                 ,JYS
			         ,ZQDM
			         ,SUM(ZXSZ)  as ZXSZ
	         FROM     EDW_PROD.T_EDW_T02_TZQGL
	         WHERE    BUS_DATE = %d{yyyyMMdd}
	         GROUP BY KHH,JYS,ZQDM	 
	        )                  a1 
  ON         t.CUST_NO = a1.KHH
  AND        t.EXG = a1.JYS
  AND        t.SEC_CD = a1.ZQDM
  WHERE      a1.ZQDM IS NOT NULL
  AND        abs(t.sec_newst_mktval-a1.ZXSZ)*1.000/t.sec_newst_mktval > 0.05
  UNION ALL
  SELECT      t.CUST_NO                  as CUST_NO
	          ,t.EXG                     as EXG
			  ,t.SEC_CD                  as SEC_CD
			  ,'T_EDW_T02_TZQGL'         as SRC_TABLE
	          ,'T_DDW_F02_SEC_HLD_DTL'   as TAR_TABLE
			  ,1                         as ERR_CGY
  FROM  (SELECT    a.KHH as CUST_NO
	               ,a.JYS as EXG
			       ,NVL(c.SecurityCode,a.ZQDM) as 	SEC_CD		 
	     FROM       EDW_PROD.T_EDW_T02_TZQGL a
		 LEFT JOIN (SELECT  SecurityCode
		                    ,ExApplyingCode
							,DT 
		             FROM   fundext.dbo_MF_FundArchives
					 WHERE  length(trim(exapplyingcode))>0
					 AND    securitycode <> exapplyingcode
					 AND    substr(securitycode,7,1) <> 'J'
					 AND    DT =  '%d{yyyyMMdd}'
					  )   c
		 ON          a.ZQDM = c.ExApplyingCode 
		 LEFT JOIN  (SELECT     a.JYS
		                        ,a.ZQDM
								,LEAST(a.SSRQ,NVL(b.SSRQ,99999999)) as SSRQ
								,GREATEST(a.TSRQ,NVL(b.TSRQ,00000000)) as TSRQ
                     FROM       EDW_PROD.T_EDW_T04_TSZQDM a
			         LEFT JOIN  (SELECT * 
					              FROM EDW_PROD.T_EDW_T04_TSZQDM
			                      WHERE CPLB = 5
				                  AND   ZQDM LIKE '%J'
				                  ) b
				     ON           a.ZQDM = SUBSTR(b.ZQDM,1,6)
			         AND          a.JYS = b.JYS
				     AND          a.BUS_DATE = b.BUS_DATE 
				     WHERE        a.CPLB IN (1,2,3,4,5,6,7) 
			         AND          a.BUS_DATE = %d{yyyyMMdd}
			         AND          a.ZQDM NOT LIKE '%J'
			         ) b
		  ON        a.JYS = b.JYS
		  AND       NVL(c.SecurityCode,a.ZQDM) = b.ZQDM
	      WHERE    a.BUS_DATE = %d{yyyyMMdd}
		  AND      a.ZQDM NOT IN ('519028')
		  AND      ((%d{yyyyMMdd} BETWEEN b.SSRQ AND b.TSRQ) OR b.ZQDM IS NULL)
		  AND      a.ZQLB NOT IN ('A3','A4','Z3','E3','L3','C3')
		  AND     SUBSTR(a.GDH,1,2) < > 'C9'
		  AND     ZXSZ > 0
          AND      SUBSTR(a.ZQDM,1,2) < > '07' 
	      GROUP BY  CUST_NO,EXG,SEC_CD	 
	    )                 t
 LEFT JOIN (SELECT  CUST_NO
	               ,EXG
			       ,SEC_CD			
 	        FROM     DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
	        WHERE    BUS_DATE = %d{yyyyMMdd}
	        GROUP BY CUST_NO,EXG,SEC_CD
			) a1
 ON        t.CUST_NO = a1.CUST_NO
 AND       t.EXG = a1.EXG
 AND       t.SEC_CD = a1.SEC_CD
 WHERE     a1.CUST_NO IS NULL	
	;



    	

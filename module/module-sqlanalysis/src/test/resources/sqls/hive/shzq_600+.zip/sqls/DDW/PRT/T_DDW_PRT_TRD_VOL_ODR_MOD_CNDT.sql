  /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:交易量_交易方式情况月表                                                                   */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-11-14                                                                        */ 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP as
  SELECT t.KHH      as CUST_NO
         ,COUNT(1)  as TRD_ITMS
		 ,SUM(CASE WHEN SUBSTR(t.ZQLB,1,1) IN ('A','C')
		           AND  WTLB IN (1,2,59,60,61,62,63,64,71,72)
				   AND  JYS IN ('SH','SZ')
			       THEN CJJE
			       ELSE 0
			       END
		      )  as TRD_VOL
		 ,DECODE(t.WTFS,1,'电话',2,'磁卡',4,'热键',8,'柜台',16,'远程',32,'互联网',64,'手机',128,'银行','其他')  as ODR_MOD
		 ,DECODE(t.CZZD1,'1001','掌厅业务','1002','临柜','1003','非现','1004','其他','1005','通达信','1006','同花顺手机','1007','同花顺网上','1008','网上营业厅','1008','网上营业厅','1009','恒生网上','1010','微信','1011','玉如意同化顺','1012','速E通','1013','联通华建','1014','指E通','1015','闪电通','1016','汇点','1017','玉如意大智慧','其他')    as ODR_CLNT            --委托终端  
  FROM  EDW_PROD.T_EDW_T05_TWTLS t
  WHERE t.BUS_DATE = %d{yyyyMMdd}
  AND   SBJG IN(2,5,6,7,8,9) 
  AND   DDLX < > '3' 
  AND   SUBSTR(ZQLB,1,1)<>'F'
  GROUP BY CUST_NO,ODR_MOD,ODR_CLNT  ;
  
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP1 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP1 as
  SELECT CUST_NO,'经纪关系' as SVC_RLN_TP 
               FROM   DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN 
               WHERE  %d{yyyyMMdd} > = STATS_DT 
               AND    %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
			   AND    BUS_DATE = %d{yyyyMMdd}
			   GROUP BY CUST_NO
               UNION ALL
               SELECT CUST_NO,'强服务关系'  as SVC_RLN_TP
               FROM DDW_PROD.T_DDW_F00_CUST_CUST_RLN
               WHERE    %d{yyyyMMdd} > = STATS_DT 
               AND      %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
               AND      BUS_DATE = %d{yyyyMMdd}
               AND       SVC_RLN_TP = '4'
			   GROUP BY CUST_NO ;
  
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP2 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP2 as
  SELECT t.KHH      as CUST_NO
         
		 ,SUM(CASE WHEN SUBSTR(t.ZQLB,1,1) IN ('A','C')
		           AND  WTLB IN (1,2,59,60,61,62,63,64,71,72)
				   AND  JYS IN ('SH','SZ')
			       THEN S1
			       ELSE 0
			       END
		      )  as S1
		 ,DECODE(t.WTFS,1,'电话',2,'磁卡',4,'热键',8,'柜台',16,'远程',32,'互联网',64,'手机',128,'银行','其他')  as ODR_MOD
		 ,DECODE(t.CZZD1,'1001','掌厅业务','1002','临柜','1003','非现','1004','其他','1005','通达信','1006','同花顺手机','1007','同花顺网上','1008','网上营业厅','1008','网上营业厅','1009','恒生网上','1010','微信','1011','玉如意同化顺','1012','速E通','1013','联通华建','1014','指E通','1015','闪电通','1016','汇点','1017','玉如意大智慧','其他')    as ODR_CLNT            --委托终端  
  FROM  EDW_PROD.T_EDW_T05_TJGMXLS t
  WHERE t.BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO,ODR_MOD,ODR_CLNT  ;  
  
------期初创建临时表1  
 INSERT OVERWRITE DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT
 (
           BELTO_FILIL                   --地区
		  ,BRH_NO                        --营业部
		  ,BRH_NAME                      --营业部名称
          ,CUST_NO                       --客户号
          ,CUST_NAME                     --客户姓名		  
		  ,TEL                           --电话
		  ,PHONE                         --手机
		  ,BRTH_DT                       --出生日期
		  ,AGE                           --年龄
		  ,EDU                           --学历
		  ,OCP                           --职业
		  ,CTCT_ADDR                     --联系地址
		  ,IF_CRD_ACCNT                  --是否有信用账户
		  ,IF_ZET_APP_TRD                --是否有指e通交易
		  ,CUST_RLN                      --客户关系
		  ,ODR_MOD                       --委托方式
		  ,ODR_CLNT                      --委托终端
		  ,TRD_ITMS                      --交易笔数
		  ,TRD_VOL                       --交易量
		  ,S1                            --佣金
          ,FNL_NET_AST	                 --期末净资产
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT    a4.BELTO_FILIL                          --地区
		  ,t.BRH_NO                               --营业部
		  ,a4.BRH_SHRTNM                           --营业部名称
          ,t.CUST_NO                               --客户号
          ,t.CUST_NAME                            --客户姓名		  
		  ,t.CTCT_TEL                             --电话
		  ,t.PHONE                                --手机
		  ,t.BRTH_YM                              --出生日期
		  ,t.AGE                                  --年龄
		  ,b1.EDU_CD_NAME                          --学历
		  ,b2.OCP_CD_NAME                          --职业
		  ,t.CTCT_ADDR                            --联系地址
		  ,CASE WHEN a2.CUST_NO IS NOT NULL 
		        THEN '是'
				ELSE '否'
				END                                --是否有信用账户
		  ,CASE WHEN a3.CUST_NO IS NOT NULL 
		        THEN '是'
				ELSE '否'
				END                                --是否有指e通交易
		  ,a5.SVC_RLN_TP                           --客户关系
		  ,a1.ODR_MOD                               --委托方式
		  ,a1.ODR_CLNT                              --委托终端
		  ,NVL(a1.TRD_ITMS,0)                              --交易笔数
		  ,NVL(a1.TRD_VOL,0)                               --交易量
		  ,NVL(a7.S1,0) 	               --期末净资产
          ,NVL(a6.NET_TOT_AST,0) 	               --期末净资产
 FROM        DDW_PROD.T_DDW_F00_CUST_CUST_INFO   t
 INNER JOIN  DDW_PROD.T_DDW_INR_ORG_BRH   a4
 ON          t.BRH_NO = a4.BRH_NO
 AND         a4.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP a1
 ON        t.CUST_NO = a1.CUST_NO
 LEFT JOIN (SELECT CUST_NO 
            FROM DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS 
			WHERE SYS_SRC = '信用账户' 
			AND (CPTL_ACCNT_STAT < > '3' OR CNCLACT_DT > = %d{yyyyMMdd})
			AND BUS_DATE = %d{yyyyMMdd}
			GROUP BY CUST_NO
			)    a2
 ON    t.CUST_NO = a2.CUST_NO
 LEFT JOIN (SELECT CUST_NO FROM DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP
            WHERE ODR_CLNT = '指E通'
			GROUP BY CUST_NO
           )             a3
 ON    t.CUST_NO = a3.CUST_NO
 LEFT JOIN  DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP1  a5
 ON t.CUST_NO = a5.CUST_NO
 LEFT JOIN (SELECT CUST_NO,NET_TOT_AST 
            FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
			WHERE BUS_DATE = %d{yyyyMMdd}
			)                         a6
 ON t.CUST_NO = a6.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP2                      a7
 ON  t.CUST_NO = a7.CUST_NO
 AND a1.ODR_MOD = a7.ODR_MOD
 AND a1.ODR_CLNT = a7.ODR_CLNT
 LEFT JOIN DDW_PROD.V_EDU_CD  b1
 ON    t.EDU_CD = b1.EDU_CD   
 LEFT JOIN DDW_PROD.V_OCP_CD  b2
 ON    t.OCP_CD = b2.OCP_CD	
 WHERE  t.BUS_DATE = %d{yyyyMMdd}
 ;
 
 
 
 

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP1 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT_TEMP2 ;
------ 
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
 PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_PRT_TRD_VOL_ODR_MOD_CNDT;
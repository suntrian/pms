------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:证券交易类别代码表                                                                 */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
TRUNCATE TABLE DDW_PROD.T_DDW_PUB_SEC_TRD_CGY_CD ;
INSERT OVERWRITE DDW_PROD.T_DDW_PUB_SEC_TRD_CGY_CD
(
                                   TRD_CGY_CD                       --交易类别编码  
                                  ,TRD_CGY_NAME                     --交易类别名称
                                  ,SYS_SRC                          --系统来源 							                                   								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT         t.JYLB	                                                   as TRD_CGY_CD                       --交易类别编码                         
               ,t.JYLBMC                                                   as TRD_CGY_NAME                     --交易类别名称
               ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户')         as SYS_SRC                          --系统来源 		                                        						    
 FROM           EDW_PROD.T_EDW_T99_TJYLB                                 t       
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_SEC_TRD_CGY_CD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_SEC_TRD_CGY_CD;
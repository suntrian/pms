 ----/* ***************************************** SQL Begin *****************************************  */
  ----/* 脚本功能:操作人审核表                                                                         */
  ----/* 创建人:黄勇华                                                                               */
  ----/* 创建时间:2018-06-12                                                                        */ 

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_CFG_OPERATE_AUDT_TIME_TEMP ;
 CREATE TABLE  DDW_PROD.T_DDW_CFG_OPERATE_AUDT_TIME_TEMP as
  SELECT         b.YWDM
  FROM       CIFSS.TYWLC_TJ_SHJD a
  LEFT JOIN  CIFSS.TYWLC_TJ     b
  ON          a.tywlc_tj_id = b.ID
  WHERE      a.SHJS IN ('47','48','60','813','809')					  
  GROUP BY   b.YWDM ;
  
  -----
  INSERT OVERWRITE DDW_PROD.T_DDW_CFG_OPERATE_AUDT_TIME
(
                 CUST_CGY	         --客户类别	              
				,BIZ_CD	             --业务代码	        
				,BIZ_CD_NAME         --业务名称	   
				,AUDT_TIME	         --审核时间	  
)
 SELECT  '0'          as CUST_CGY	         --客户类别
         ,a.YWDM      as BIZ_CD	             --业务代码	
		 ,b.YWMC      as BIZ_CD_NAME         --业务名称
		 ,CASE WHEN a.YWDM = '20001'
		       THEN 20
			   WHEN a.YWDM IN ('20071','20072','20073','90101')
		       THEN 10
			   WHEN a.YWDM = '90118'
		       THEN 8
			   ELSE 5
			   END  as AUDT_TIME	         --审核时间			            
 FROM  DDW_PROD.T_DDW_CFG_OPERATE_AUDT_TIME_TEMP a
 LEFT JOIN (SELECT YWDM,YWMC FROM CIFSS.TYWDM  GROUP BY  YWDM,YWMC)                        b
 ON        a.YWDM = b.YWDM
 UNION ALL
  SELECT  '1'         as CUST_CGY	         --客户类别
         ,a.YWDM      as BIZ_CD	             --业务代码	
		 ,b.YWMC      as BIZ_CD_NAME         --业务名称
		 ,CASE WHEN a.YWDM = '20001'
		       THEN 40
			   WHEN a.YWDM = '20002'
		       THEN 15
			   WHEN a.YWDM IN ('20071','20072','20073','90101','90112')
		       THEN 10
			   WHEN a.YWDM = '90118'
		       THEN 8
			   ELSE 5
			   END           as AUDT_TIME	         --审核时间
         
 FROM  DDW_PROD.T_DDW_CFG_OPERATE_AUDT_TIME_TEMP a
 LEFT JOIN (SELECT YWDM,YWMC FROM CIFSS.TYWDM  GROUP BY  YWDM,YWMC)                        b
 ON        a.YWDM = b.YWDM
  UNION ALL
  SELECT  '2'         as CUST_CGY	         --客户类别
         ,a.YWDM      as BIZ_CD	             --业务代码	
		 ,b.YWMC      as BIZ_CD_NAME         --业务名称
		 ,5           as AUDT_TIME	         --审核时间
         
 FROM  DDW_PROD.T_DDW_CFG_OPERATE_AUDT_TIME_TEMP a
 LEFT JOIN (SELECT YWDM,YWMC FROM CIFSS.TYWDM  GROUP BY  YWDM,YWMC)                        b
 ON        a.YWDM = b.YWDM ;
----- 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_CFG_OPERATE_AUDT_TIME_TEMP ;
 invalidate metadata DDW_PROD.T_DDW_CFG_OPERATE_AUDT_TIME ;
-----------------插入数据结束----------------
--INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
--PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CFG_OPERATE_AUDT_TIME',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户收入、盈亏统计表                                                                 */
------/* 创建人:OYJ                                                                                    */
------/* 创建时间:2018-09-26                                                                           */ 

-----删除今天的数据
ALTER TABLE DDW_PROD.T_DDW_LM_CUST_PRET_STATS DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ; 

----插入总账户日周期数据
INSERT INTO DDW_PROD.T_DDW_LM_CUST_PRET_STATS
(
 CUST_NO             	--1. 客户号
,ACCT_CGY             	--2. 账户类别
,DATA_PRD	            --3. 统计周期
,TOT_PRET		        --4. 总盈亏
,STK_PRET               --5. 股票盈亏
,BOND_PRET		        --6. 债券盈亏
,FND_PRET			    --7. 基金盈亏
,TOT_PRET_RTO		    --8. 总盈亏率
,TOT_INCM               --9. 总收入贡献
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO AS CUST_NO
      ,'0' AS ACCT_CGY
	  ,'1' AS DATA_PRD
	  ,T.TOT_PRET AS TOT_PRET 
	  ,T1.STK_TOT_PRET AS STK_PRET
	  ,T1.BOND_TOT_PRET AS BOND_PRET 
	  ,T1.FUND_TOT_PRET AS FND_PRET
	  ,CAST(T.TOT_PRET AS DECIMAL(38,6)) / (CASE WHEN T3.TOL_AST_AVG = 0 THEN NULL ELSE T3.TOL_AST_AVG END) AS TOT_PRET_RTO
	  ,T2.TOT_INCM AS TOT_INCM
FROM 
(
  SELECT CUST_NO
        ,SUM(TOT_PRFT) AS TOT_PRET
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
) T
LEFT JOIN
(
  SELECT CUST_NO
	    ,SUM(TOT_PRET_RMB) AS TOT_PRET
	    ,SUM(CASE WHEN PROD_CGY IN (1,2,6,7) THEN TOT_PRET_RMB ELSE 0 END) AS STK_TOT_PRET
	    ,SUM(CASE WHEN PROD_CGY IN (4) THEN TOT_PRET_RMB ELSE 0 END) AS BOND_TOT_PRET
	    ,SUM(CASE WHEN PROD_CGY IN (5,8) THEN TOT_PRET_RMB ELSE 0 END) AS FUND_TOT_PRET
  FROM DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
) T1
ON T.CUST_NO = T1.CUST_NO
LEFT JOIN
(
  SELECT CUST_NO
	    ,SUM(CRD_MRGNC_MRGNS_RTN_INT) + SUM(ORDI_NET_S1_INCM_RMB) + SUM(CRD_NET_S1_INCM) + SUM(WRNT_NET_S1_INCM) AS TOT_INCM
  FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  --BETWEEN CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4),'0101') AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T2
ON T.CUST_NO = T2.CUST_NO
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(TOL_AST) AS TOL_AST_AVG
  FROM DDW_PROD.T_DDW_CUST_STATMT_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T3
ON T.CUST_NO = T3.CUST_NO
;

----插入总账户月周期数据
INSERT INTO DDW_PROD.T_DDW_LM_CUST_PRET_STATS
(
 CUST_NO             	--1. 客户号
,ACCT_CGY             	--2. 账户类别
,DATA_PRD	            --3. 统计周期
,TOT_PRET		        --4. 总盈亏
,STK_PRET               --5. 股票盈亏
,BOND_PRET		        --6. 债券盈亏
,FND_PRET			    --7. 基金盈亏
,TOT_PRET_RTO		    --8. 总盈亏率
,TOT_INCM               --9. 总收入贡献
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO AS CUST_NO
      ,'0' AS ACCT_CGY
	  ,'2' AS DATA_PRD
	  ,T.TOT_PRET AS TOT_PRET
	  ,T1.STK_TOT_PRET AS STK_PRET
	  ,T1.BOND_TOT_PRET AS BOND_PRET
	  ,T1.FUND_TOT_PRET AS FND_PRET
	  ,CAST(T.TOT_PRET AS DECIMAL(38,6)) / (CASE WHEN T3.TOL_AST_AVG = 0 THEN NULL ELSE T3.TOL_AST_AVG END) AS TOT_PRET_RTO
	  ,T2.TOT_INCM AS TOT_INCM
FROM 
(
  SELECT CUST_NO
        ,AVG(TOT_PRET) AS TOT_PRET
  FROM
  (
    SELECT CUST_NO
          ,SUM(TOT_PRFT) AS TOT_PRET
	      ,BUS_DATE
    FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
    WHERE BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6) ,'01') AS INT) AND %d{yyyyMMdd}
    GROUP BY CUST_NO,BUS_DATE
  ) A
  GROUP BY CUST_NO
) T
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(STK_TOT_PRET) AS STK_TOT_PRET
		,AVG(BOND_TOT_PRET) AS BOND_TOT_PRET
		,AVG(FUND_TOT_PRET) AS FUND_TOT_PRET
  FROM
  (
    SELECT CUST_NO
          ,SUM(TOT_PRET_RMB) AS TOT_PRET
          ,SUM(CASE WHEN PROD_CGY IN (1,2,6,7) THEN TOT_PRET_RMB ELSE 0 END) AS STK_TOT_PRET
          ,SUM(CASE WHEN PROD_CGY IN (4) THEN TOT_PRET_RMB ELSE 0 END) AS BOND_TOT_PRET
          ,SUM(CASE WHEN PROD_CGY IN (5,8) THEN TOT_PRET_RMB ELSE 0 END) AS FUND_TOT_PRET
		  ,BUS_DATE
    FROM DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY
    WHERE BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6) ,'01') AS INT) AND %d{yyyyMMdd}
    GROUP BY CUST_NO,BUS_DATE
  ) B
  GROUP BY CUST_NO
) T1
ON T.CUST_NO = T1.CUST_NO
LEFT JOIN
(
  SELECT CUST_NO
	    ,SUM(CRD_MRGNC_MRGNS_RTN_INT) + SUM(ORDI_NET_S1_INCM_RMB) + SUM(CRD_NET_S1_INCM) + SUM(WRNT_NET_S1_INCM) AS TOT_INCM
  FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
  WHERE BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6) ,'01') AS INT) AND %d{yyyyMMdd}
  --BETWEEN CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4),'0101') AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T2
ON T.CUST_NO = T2.CUST_NO
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(TOL_AST) AS TOL_AST_AVG
  FROM DDW_PROD.T_DDW_CUST_STATMT_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T3
ON T.CUST_NO = T3.CUST_NO
;

----插入总账户年周期数据
INSERT INTO DDW_PROD.T_DDW_LM_CUST_PRET_STATS
(
 CUST_NO             	--1. 客户号
,ACCT_CGY             	--2. 账户类别
,DATA_PRD	            --3. 统计周期
,TOT_PRET		        --4. 总盈亏
,STK_PRET               --5. 股票盈亏
,BOND_PRET		        --6. 债券盈亏
,FND_PRET			    --7. 基金盈亏
,TOT_PRET_RTO		    --8. 总盈亏率
,TOT_INCM               --9. 总收入贡献
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO AS CUST_NO
      ,'0' AS ACCT_CGY
	  ,'3' AS DATA_PRD
	  ,T.TOT_PRET AS TOT_PRET
	  ,T1.STK_TOT_PRET AS STK_PRET
	  ,T1.BOND_TOT_PRET AS BOND_PRET
	  ,T1.FUND_TOT_PRET AS FND_PRET
	  ,CAST(T.TOT_PRET AS DECIMAL(38,6)) / (CASE WHEN T3.TOL_AST_AVG = 0 THEN NULL ELSE T3.TOL_AST_AVG END) AS TOT_PRET_RTO
	  ,T2.TOT_INCM AS TOT_INCM
FROM 
(
  SELECT CUST_NO
        ,AVG(TOT_PRET) AS TOT_PRET
  FROM
  (
    SELECT CUST_NO
          ,SUM(TOT_PRFT) AS TOT_PRET
	      ,BUS_DATE
    FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
    WHERE BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4) ,'0101') AS INT) AND %d{yyyyMMdd}
    GROUP BY CUST_NO,BUS_DATE
  ) A
  GROUP BY CUST_NO
) T
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(STK_TOT_PRET) AS STK_TOT_PRET
		,AVG(BOND_TOT_PRET) AS BOND_TOT_PRET
		,AVG(FUND_TOT_PRET) AS FUND_TOT_PRET
  FROM
  (
    SELECT CUST_NO
          ,SUM(TOT_PRET_RMB) AS TOT_PRET
          ,SUM(CASE WHEN PROD_CGY IN (1,2,6,7) THEN TOT_PRET_RMB ELSE 0 END) AS STK_TOT_PRET
          ,SUM(CASE WHEN PROD_CGY IN (4) THEN TOT_PRET_RMB ELSE 0 END) AS BOND_TOT_PRET
          ,SUM(CASE WHEN PROD_CGY IN (5,8) THEN TOT_PRET_RMB ELSE 0 END) AS FUND_TOT_PRET
		  ,BUS_DATE
    FROM DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY
    WHERE BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4) ,'0101') AS INT) AND %d{yyyyMMdd}
    GROUP BY CUST_NO,BUS_DATE
  ) B
  GROUP BY CUST_NO
) T1
ON T.CUST_NO = T1.CUST_NO
LEFT JOIN
(
  SELECT CUST_NO
	    ,SUM(CRD_MRGNC_MRGNS_RTN_INT) + SUM(ORDI_NET_S1_INCM_RMB) + SUM(CRD_NET_S1_INCM) + SUM(WRNT_NET_S1_INCM) AS TOT_INCM
  FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY
  WHERE BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4) ,'0101') AS INT) AND %d{yyyyMMdd}
  --BETWEEN CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4),'0101') AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T2
ON T.CUST_NO = T2.CUST_NO
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(TOL_AST) AS TOL_AST_AVG
  FROM DDW_PROD.T_DDW_CUST_STATMT_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T3
ON T.CUST_NO = T3.CUST_NO
;

----插入普通账户日周期数据
INSERT INTO DDW_PROD.T_DDW_LM_CUST_PRET_STATS
(
 CUST_NO             	--1. 客户号
,ACCT_CGY             	--2. 账户类别
,DATA_PRD	            --3. 统计周期
,TOT_PRET		        --4. 总盈亏
,STK_PRET               --5. 股票盈亏
,BOND_PRET		        --6. 债券盈亏
,FND_PRET			    --7. 基金盈亏
,TOT_PRET_RTO		    --8. 总盈亏率
,TOT_INCM               --9. 总收入贡献
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO AS CUST_NO
      ,'1' AS ACCT_CGY
	  ,'1' AS DATA_PRD
	  ,T.TOT_PRET AS TOT_PRET
	  ,0 AS STK_PRET
	  ,0 AS BOND_PRET
	  ,0 AS FND_PRET
	  ,CAST(T.TOT_PRET AS DECIMAL(38,6)) / (CASE WHEN T1.TOL_AST_AVG = 0 THEN NULL ELSE T1.TOL_AST_AVG END) AS TOT_PRET_RTO
	  ,0 AS TOT_INCM
FROM 
(
  SELECT CUST_NO
        ,SUM(ORDI_PRFT) AS TOT_PRET
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
) T
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(ORDI_NET_AST) AS TOL_AST_AVG
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T1
ON T.CUST_NO = T1.CUST_NO
;

----插入普通账户月周期数据
INSERT INTO DDW_PROD.T_DDW_LM_CUST_PRET_STATS
(
 CUST_NO             	--1. 客户号
,ACCT_CGY             	--2. 账户类别
,DATA_PRD	            --3. 统计周期
,TOT_PRET		        --4. 总盈亏
,STK_PRET               --5. 股票盈亏
,BOND_PRET		        --6. 债券盈亏
,FND_PRET			    --7. 基金盈亏
,TOT_PRET_RTO		    --8. 总盈亏率
,TOT_INCM               --9. 总收入贡献
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO AS CUST_NO
      ,'1' AS ACCT_CGY
	  ,'2' AS DATA_PRD
	  ,T.TOT_PRET AS TOT_PRET
	  ,0 AS STK_PRET
	  ,0 AS BOND_PRET
	  ,0 AS FND_PRET
	  ,CAST(T.TOT_PRET AS DECIMAL(38,6)) / (CASE WHEN T1.TOL_AST_AVG = 0 THEN NULL ELSE T1.TOL_AST_AVG END) AS TOT_PRET_RTO
	  ,0 AS TOT_INCM
FROM 
(
  SELECT CUST_NO
        ,AVG(TOT_PRET) AS TOT_PRET
  FROM
  (
    SELECT CUST_NO
          ,SUM(ORDI_PRFT) AS TOT_PRET
          ,BUS_DATE
    FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
    WHERE BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6) ,'01') AS INT) AND %d{yyyyMMdd}
    GROUP BY CUST_NO,BUS_DATE
  ) A
  GROUP BY CUST_NO
) T
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(ORDI_NET_AST) AS TOL_AST_AVG
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T1
ON T.CUST_NO = T1.CUST_NO
;

----插入普通账户年周期数据
INSERT INTO DDW_PROD.T_DDW_LM_CUST_PRET_STATS
(
 CUST_NO             	--1. 客户号
,ACCT_CGY             	--2. 账户类别
,DATA_PRD	            --3. 统计周期
,TOT_PRET		        --4. 总盈亏
,STK_PRET               --5. 股票盈亏
,BOND_PRET		        --6. 债券盈亏
,FND_PRET			    --7. 基金盈亏
,TOT_PRET_RTO		    --8. 总盈亏率
,TOT_INCM               --9. 总收入贡献
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO AS CUST_NO
      ,'1' AS ACCT_CGY
	  ,'3' AS DATA_PRD
	  ,T.TOT_PRET AS TOT_PRET
	  ,0 AS STK_PRET
	  ,0 AS BOND_PRET
	  ,0 AS FND_PRET
	  ,CAST(T.TOT_PRET AS DECIMAL(38,6)) / (CASE WHEN T1.TOL_AST_AVG = 0 THEN NULL ELSE T1.TOL_AST_AVG END) AS TOT_PRET_RTO
	  ,0 AS TOT_INCM
FROM 
(
  SELECT CUST_NO
        ,AVG(TOT_PRET) AS TOT_PRET
  FROM
  (
    SELECT CUST_NO
          ,SUM(ORDI_PRFT) AS TOT_PRET
          ,BUS_DATE
    FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
    WHERE BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4) ,'0101') AS INT) AND %d{yyyyMMdd}
    GROUP BY CUST_NO,BUS_DATE
  ) A
  GROUP BY CUST_NO
) T
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(ORDI_NET_AST) AS TOL_AST_AVG
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T1
ON T.CUST_NO = T1.CUST_NO
;

----插入信用账户日周期数据
INSERT INTO DDW_PROD.T_DDW_LM_CUST_PRET_STATS
(
 CUST_NO             	--1. 客户号
,ACCT_CGY             	--2. 账户类别
,DATA_PRD	            --3. 统计周期
,TOT_PRET		        --4. 总盈亏
,STK_PRET               --5. 股票盈亏
,BOND_PRET		        --6. 债券盈亏
,FND_PRET			    --7. 基金盈亏
,TOT_PRET_RTO		    --8. 总盈亏率
,TOT_INCM               --9. 总收入贡献
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO AS CUST_NO
      ,'2' AS ACCT_CGY
	  ,'1' AS DATA_PRD
	  ,T.TOT_PRET AS TOT_PRET
	  ,0 AS STK_PRET
	  ,0 AS BOND_PRET
	  ,0 AS FND_PRET
	  ,CAST(T.TOT_PRET AS DECIMAL(38,6)) / (CASE WHEN T1.TOL_AST_AVG = 0 THEN NULL ELSE T1.TOL_AST_AVG END) AS TOT_PRET_RTO
	  ,0 AS TOT_INCM
FROM 
(
  SELECT CUST_NO
        ,SUM(CRD_PRFT) AS TOT_PRET
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
) T
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(CRD_NET_AST) AS TOL_AST_AVG
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T1
ON T.CUST_NO = T1.CUST_NO
;

----插入信用账户月周期数据
INSERT INTO DDW_PROD.T_DDW_LM_CUST_PRET_STATS
(
 CUST_NO             	--1. 客户号
,ACCT_CGY             	--2. 账户类别
,DATA_PRD	            --3. 统计周期
,TOT_PRET		        --4. 总盈亏
,STK_PRET               --5. 股票盈亏
,BOND_PRET		        --6. 债券盈亏
,FND_PRET			    --7. 基金盈亏
,TOT_PRET_RTO		    --8. 总盈亏率
,TOT_INCM               --9. 总收入贡献
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO AS CUST_NO
      ,'2' AS ACCT_CGY
	  ,'2' AS DATA_PRD
	  ,T.TOT_PRET AS TOT_PRET
	  ,0 AS STK_PRET
	  ,0 AS BOND_PRET
	  ,0 AS FND_PRET
	  ,CAST(T.TOT_PRET AS DECIMAL(38,6)) / (CASE WHEN T1.TOL_AST_AVG = 0 THEN NULL ELSE T1.TOL_AST_AVG END) AS TOT_PRET_RTO
	  ,0 AS TOT_INCM
FROM 
(
  SELECT CUST_NO
        ,AVG(TOT_PRET) AS TOT_PRET
  FROM
  (
    SELECT CUST_NO
          ,SUM(CRD_PRFT) AS TOT_PRET
          ,BUS_DATE
    FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
    WHERE BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6) ,'01') AS INT) AND %d{yyyyMMdd}
    GROUP BY CUST_NO,BUS_DATE
  ) A
  GROUP BY CUST_NO
) T
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(CRD_NET_AST) AS TOL_AST_AVG
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T1
ON T.CUST_NO = T1.CUST_NO
;

----插入信用账户年周期数据
INSERT INTO DDW_PROD.T_DDW_LM_CUST_PRET_STATS
(
 CUST_NO             	--1. 客户号
,ACCT_CGY             	--2. 账户类别
,DATA_PRD	            --3. 统计周期
,TOT_PRET		        --4. 总盈亏
,STK_PRET               --5. 股票盈亏
,BOND_PRET		        --6. 债券盈亏
,FND_PRET			    --7. 基金盈亏
,TOT_PRET_RTO		    --8. 总盈亏率
,TOT_INCM               --9. 总收入贡献
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO AS CUST_NO
      ,'2' AS ACCT_CGY
	  ,'3' AS DATA_PRD
	  ,T.TOT_PRET AS TOT_PRET
	  ,0 AS STK_PRET
	  ,0 AS BOND_PRET
	  ,0 AS FND_PRET
	  ,CAST(T.TOT_PRET AS DECIMAL(38,6)) / (CASE WHEN T1.TOL_AST_AVG = 0 THEN NULL ELSE T1.TOL_AST_AVG END) AS TOT_PRET_RTO
	  ,0 AS TOT_INCM
FROM 
(
  SELECT CUST_NO
        ,AVG(TOT_PRET) AS TOT_PRET
  FROM
  (
    SELECT CUST_NO
          ,SUM(CRD_PRFT) AS TOT_PRET
          ,BUS_DATE
    FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
    WHERE BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4) ,'0101') AS INT) AND %d{yyyyMMdd}
    GROUP BY CUST_NO,BUS_DATE
  ) A
  GROUP BY CUST_NO
) T
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(CRD_NET_AST) AS TOL_AST_AVG
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T1
ON T.CUST_NO = T1.CUST_NO
;

----插入期权账户日周期数据
INSERT INTO DDW_PROD.T_DDW_LM_CUST_PRET_STATS
(
 CUST_NO             	--1. 客户号
,ACCT_CGY             	--2. 账户类别
,DATA_PRD	            --3. 统计周期
,TOT_PRET		        --4. 总盈亏
,STK_PRET               --5. 股票盈亏
,BOND_PRET		        --6. 债券盈亏
,FND_PRET			    --7. 基金盈亏
,TOT_PRET_RTO		    --8. 总盈亏率
,TOT_INCM               --9. 总收入贡献
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO AS CUST_NO
      ,'3' AS ACCT_CGY
	  ,'1' AS DATA_PRD
	  ,T.TOT_PRET AS TOT_PRET
	  ,0 AS STK_PRET
	  ,0 AS BOND_PRET
	  ,0 AS FND_PRET
	  ,CAST(T.TOT_PRET AS DECIMAL(38,6)) / (CASE WHEN T1.TOL_AST_AVG = 0 THEN NULL ELSE T1.TOL_AST_AVG END) AS TOT_PRET_RTO
	  ,0 AS TOT_INCM
FROM 
(
  SELECT CUST_NO
        ,SUM(WRNT_PRFT) AS TOT_PRET
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
) T
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(WRNT_AST) AS TOL_AST_AVG
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T1
ON T.CUST_NO = T1.CUST_NO
;

----插入期权账户月周期数据
INSERT INTO DDW_PROD.T_DDW_LM_CUST_PRET_STATS
(
 CUST_NO             	--1. 客户号
,ACCT_CGY             	--2. 账户类别
,DATA_PRD	            --3. 统计周期
,TOT_PRET		        --4. 总盈亏
,STK_PRET               --5. 股票盈亏
,BOND_PRET		        --6. 债券盈亏
,FND_PRET			    --7. 基金盈亏
,TOT_PRET_RTO		    --8. 总盈亏率
,TOT_INCM               --9. 总收入贡献
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO AS CUST_NO
      ,'3' AS ACCT_CGY
	  ,'2' AS DATA_PRD
	  ,T.TOT_PRET AS TOT_PRET
	  ,0 AS STK_PRET
	  ,0 AS BOND_PRET
	  ,0 AS FND_PRET
	  ,CAST(T.TOT_PRET AS DECIMAL(38,6)) / (CASE WHEN T1.TOL_AST_AVG = 0 THEN NULL ELSE T1.TOL_AST_AVG END) AS TOT_PRET_RTO
	  ,0 AS TOT_INCM
FROM 
(
  SELECT CUST_NO
        ,AVG(TOT_PRET) AS TOT_PRET
  FROM
  (
    SELECT CUST_NO
          ,SUM(WRNT_PRFT) AS TOT_PRET
          ,BUS_DATE
    FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
    WHERE BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6) ,'01') AS INT) AND %d{yyyyMMdd}
    GROUP BY CUST_NO,BUS_DATE
  ) A
  GROUP BY CUST_NO
) T
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(WRNT_AST) AS TOL_AST_AVG
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T1
ON T.CUST_NO = T1.CUST_NO
;

----插入期权账户年周期数据
INSERT INTO DDW_PROD.T_DDW_LM_CUST_PRET_STATS
(
 CUST_NO             	--1. 客户号
,ACCT_CGY             	--2. 账户类别
,DATA_PRD	            --3. 统计周期
,TOT_PRET		        --4. 总盈亏
,STK_PRET               --5. 股票盈亏
,BOND_PRET		        --6. 债券盈亏
,FND_PRET			    --7. 基金盈亏
,TOT_PRET_RTO		    --8. 总盈亏率
,TOT_INCM               --9. 总收入贡献
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT T.CUST_NO AS CUST_NO
      ,'3' AS ACCT_CGY
	  ,'3' AS DATA_PRD
	  ,T.TOT_PRET AS TOT_PRET
	  ,0 AS STK_PRET
	  ,0 AS BOND_PRET
	  ,0 AS FND_PRET
	  ,CAST(T.TOT_PRET AS DECIMAL(38,6)) / (CASE WHEN T1.TOL_AST_AVG = 0 THEN NULL ELSE T1.TOL_AST_AVG END) AS TOT_PRET_RTO
	  ,0 AS TOT_INCM
FROM 
(
  SELECT CUST_NO
        ,AVG(TOT_PRET) AS TOT_PRET
  FROM
  (
    SELECT CUST_NO
          ,SUM(WRNT_PRFT) AS TOT_PRET
          ,BUS_DATE
    FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
    WHERE BUS_DATE BETWEEN CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,4) ,'0101') AS INT) AND %d{yyyyMMdd}
    GROUP BY CUST_NO,BUS_DATE
  ) A
  GROUP BY CUST_NO
) T
LEFT JOIN
(
  SELECT CUST_NO
        ,AVG(WRNT_AST) AS TOL_AST_AVG
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS INT) AND %d{yyyyMMdd}
  GROUP BY CUST_NO
) T1
ON T.CUST_NO = T1.CUST_NO
;


INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_LM_CUST_PRET_STATS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
invalidate metadata DDW_PROD.T_DDW_LM_CUST_PRET_STATS;
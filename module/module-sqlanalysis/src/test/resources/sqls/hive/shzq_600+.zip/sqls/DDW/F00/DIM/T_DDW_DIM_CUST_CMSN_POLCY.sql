 --/* ***************************************** SQL Begin *****************************************  */
  --/* 脚本功能:客户佣金策略维表                                                                    */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2016-11-30                                                                        */ 
  
  
--------------插入数据-------------------
INSERT OVERWRITE DDW_PROD.T_DDW_DIM_CUST_CMSN_POLCY
(
                                     CUST_NO                        --客户号   
                                    ,BRH_NO                         --营业部编号                                    
                                    ,SRC                            --来源                                       						
                                    ,SETUP_DT                       --设置日期  
                                    ,POLCY_NAME                     --策略名称  
                                    ,CMSN_FIXPRC_MOD                --佣金定价方式
                                    ,AUDT_FLG                       --审核标志  
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
                                    t.KHH                                                          as CUST_NO                         --客户号                                       
                                   ,t.YYB                                                          as BRH_NO                         --营业部编号                                                                                                        
                                   ,CASE WHEN t.XTBS = 'JZJY' 
                                         THEN 'ABOSS'	
                                         WHEN t.XTBS = 'RZRQ'	
                                         THEN  'RZRQ'		
                                    END										                       as SRC                            --来源                                                                                                                                                							   
                                   ,t.DJRQ                                                         as SETUP_DT                       --设置日期                                       
                                   ,a3.CLMC                                                        as POLCY_NAME                     --策略名称                                       
                                   ,t.YJDJFS                                                       as CMSN_FIXPRC_MOD               --佣金定价方式                                     
                                   ,t.SHBZ                                                         as AUDT_FLG                       --审核标志                                       
 FROM         EDW_PROD.T_EDW_T02_TYJDJDX_KH                        t
 LEFT JOIN    EDW_PROD.T_EDW_T02_TYJDJ_DJCLID                      a3
 ON           t.FID = a3.FID
 AND          t.YJDJFS = a3.YJDJFS
 AND          t.XTBS = a3.XTBS
 AND          t.BUS_DATE = a3.BUS_DATE
 WHERE        t.BUS_DATE = %d{yyyyMMdd}
 
 ;		
---------------- 插入数据结束 -----------------------






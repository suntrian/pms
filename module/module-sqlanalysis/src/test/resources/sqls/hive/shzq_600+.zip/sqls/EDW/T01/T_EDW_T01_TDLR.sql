--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:代理人信息表                                                                       */
--/* 创建人:黄勇华                                                                              */
--/* 创建时间:2016-11-02                                                                        */ 

 TRUNCATE TABLE EDW_PROD.T_EDW_T01_TDLR ;
---------------- 插入数据开始
INSERT OVERWRITE EDW_PROD.T_EDW_T01_TDLR
(
                                    DLRID                               --代理人主键                              
                                   ,KHH                                 --客户号                                
                                   ,DLRMC                               --代理人名称                              
                                   ,DLRLXDM                             --代理人类型代码                            
                                   ,DLQSRQ                              --代理起始日期                             
                                   ,DLJZRQ                              --代理截止日期                             
                                   ,DLQXFW                              --代理权限范围                             
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,ZJQSRQ                              --证件起始日期                             
                                   ,ZJJZRQ                              --证件截止日期                             
                                   ,ZJDZ                                --证件地址                               
                                   ,GJDM                                --国籍代码                               
                                   ,CSRQ                                --出生日期                               
                                   ,XBDM                                --性别代码                               
                                   ,XLDM                                --学历代码                               
                                   ,ZYDM                                --职业代码                               
                                   ,MZDM                                --民族代码                               
                                   ,JG                                  --籍贯                                 
                                   ,HYZKDM                              --婚姻状况代码                             
                                   ,DZ                                  --联系地址                               
                                   ,YZBM                                --邮政编码                               
                                   ,LXDH                                --联系电话                               
                                   ,MOBILE                              --手机                                 
                                   ,EMAIL                               --EMAIL                              
                                   ,TBSM                                --特别说明                               
                                   ,DJRQ                                --登记日期                               
                                   ,BDRQ                                --变动日期   
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.ID                                  as DLRID                               --ID                                  
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.DLRMC                               as DLRMC                               --代理人名称                               
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.DLRLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as DLRLXDM                             --代理人类型                               
                                   ,t.DLQSRQ                              as DLQSRQ                              --代理起始日期                              
                                   ,t.DLJZRQ                              as DLJZRQ                              --代理截止日期                              
                                   ,t.DLQXFW                              as DLQXFW                              --代理权限范围                              
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,t.ZJQSRQ                              as ZJQSRQ                              --证件起始日期                              
                                   ,t.ZJJZRQ                              as ZJJZRQ                              --证件截止日期                              
                                   ,t.ZJDZ                                as ZJDZ                                --证件地址                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.GJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as GJDM                                --国籍                                  
                                   ,t.CSRQ                                as CSRQ                                --出生日期                                
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.XB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as XBDM                                --性别                                  
                                   ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.XLDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as XLDM                                --学历                                  
                                   ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZYDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZYDM                                --职业                                  
                                   ,CAST(COALESCE(t7.MBDM,NULLIF(CONCAT('ERR',CAST(t.MZDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as MZDM                                --民族                                  
                                   ,t.JG                                  as JG                                  --籍贯                                  
                                   ,CAST(COALESCE(t8.MBDM,NULLIF(CONCAT('ERR',CAST(t.HYZK AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as HYZKDM                              --婚姻状况                                
                                   ,t.DZ                                  as DZ                                  --联系地址                                
                                   ,t.YZBM                                as YZBM                                --邮政编码                                
                                   ,t.DH                                  as LXDH                                --联系电话                                
                                   ,t.SJ                                  as MOBILE                              --手机                                  
                                   ,t.EMAIL                               as EMAIL                               --EMAIL                               
                                   ,t.TBSM                                as TBSM                                --特别说明                                
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期     
                                   ,'YGT_GT'								   
 FROM           YGTCX.CIF_TDLR                                      t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING              t1 
 ON             t1.DMLX = 'DLRLXDM'                                 
 AND            t1.YXT = 'YGT_GT'                                   
 AND            t1.YDM = CAST(t.DLRLX AS VARCHAR(20))               
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING              t2 
 ON             t2.DMLX = 'ZJLBDM'                                 
 AND            t2.YXT = 'YGT_GT'                                   
 AND            t2.YDM = CAST(t.ZJLB AS VARCHAR(20))                
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING              t3  
 ON             t3.DMLX = 'GJDM'                                    
 AND            t3.YXT = 'YGT'                                      
 AND            t3.YDM = CAST(t.GJ AS VARCHAR(20))                  
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING              t4  
 ON             t4.DMLX = 'XBDM'                                    
 AND            t4.YXT = 'YGT_GT'                                   
 AND            t4.YDM = CAST(t.XB AS VARCHAR(20))                  
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING              t5   
 ON             t5.DMLX = 'XLDM'                                    
 AND            t5.YXT = 'YGT_GT'                                   
 AND            t5.YDM = CAST(t.XLDM AS VARCHAR(20))                
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING              t6   
 ON             t6.DMLX = 'ZYDM'                                    
 AND            t6.YXT = 'YGT_GT'                                   
 AND            t6.YDM = CAST(t.ZYDM AS VARCHAR(20))                
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING              t7     
 ON             t7.DMLX = 'MZDM'                                    
 AND            t7.YXT = 'YGT_GT'                                   
 AND            t7.YDM = CAST(t.MZDM AS VARCHAR(20))                
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING              t8       
 ON             t8.DMLX = 'HYZKDM'                                  
 AND            t8.YXT = 'YGT_GT'                                   
 AND            t8.YDM = CAST(t.HYZK AS VARCHAR(20))                
 WHERE          t.DT = '%d{yyyyMMdd}';
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TDLR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T01_TDLR;


--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:代码新增区段监控  */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-08-11                                                                        */ 
  

 

 
  ----插入数据--
   INSERT OVERWRITE DDW_PROD.T_DDW_CD_SECTION_ADD_MOT
   
 (
                                   CD                --代码 
                                  ,EXG               --交易所                             
								  ,SRC_TABLE         --来源表							  
) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT 
                     t.ZQDM                      as CD                --代码 
                    ,t.JYS                       as EXG               --交易所                  
					,'T_EDW_T02_TZQGL'	         as SRC_TABLE         --来源表		   
  FROM       EDW_PROD.T_EDW_T02_TZQGL       t
  LEFT JOIN  (SELECT    EXG
                       ,SEC_CD_PFX 
              FROM     DDW_PROD.T_DDW_CFG_SEC
			  GROUP BY EXG,SEC_CD_PFX
              )         a1
  ON         t.JYS = a1.EXG
  AND        (t.ZQDM = a1.SEC_CD_PFX OR SUBSTR(t.ZQDM,1,3) = a1.SEC_CD_PFX
             OR  CONCAT(SUBSTR(t.ZQDM,1,3),SUBSTR(t.ZQDM,6,1)) = a1.SEC_CD_PFX) 
  WHERE     a1.EXG IS NULL
  AND       t.BUS_DATE = %d{yyyyMMdd}
  AND       ((t.JYS = 'SH' AND SUBSTR(t.ZQDM,1,3) < > '002') OR t.JYS IN ('TA','SZ','TU','HB','SB','HK','SK'))
  UNION ALL
  SELECT 
                     t.ZQDM                      as CD                --代码 
                    ,t.JYS                       as EXG               --交易所                  
					,'T_EDW_T05_TJGMXLS'	         as SRC_TABLE         --来源表		   
  FROM       EDW_PROD.T_EDW_T05_TJGMXLS       t
  LEFT JOIN  (SELECT    EXG
                       ,SEC_CD_PFX 
              FROM     DDW_PROD.T_DDW_CFG_SEC
			  GROUP BY EXG,SEC_CD_PFX
              )         a1
  ON         t.JYS = a1.EXG
  AND        (t.ZQDM = a1.SEC_CD_PFX OR SUBSTR(t.ZQDM,1,3) = a1.SEC_CD_PFX
             OR  CONCAT(SUBSTR(t.ZQDM,1,3),SUBSTR(t.ZQDM,6,1)) = a1.SEC_CD_PFX) 
  WHERE     a1.EXG IS NULL
  AND       t.BUS_DATE = %d{yyyyMMdd}
  AND       SUBSTR(t.ZQDM,1,3) NOT IN ('799')
  
  
  ;
-- /* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:联系人信息表                                                                         */
 -- /* 创建人:黄勇华                                                                              */
 -- /* 创建时间:2016-11-02                                                                        */ 
 --  TRUNCATE TABLE EDW_PROD.T_EDW_T01_TLXR;   
-----插入数据开始-------
INSERT OVERWRITE EDW_PROD.T_EDW_T01_TLXR
 (
                                    LXRID                               --联系人主键                              
                                   ,KHH                                 --客户号                                
                                   ,LXRMC                               --联系人名称                              
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,ZJQSRQ                              --证件起始日期                             
                                   ,ZJJZRQ                              --证件截止日期                             
                                   ,LXDZ                                --联系地址                               
                                   ,YZBM                                --邮政编码                               
                                   ,LXDH                                --联系电话                               
                                   ,MOBILE                              --手机                                 
                                   ,EMAIL                               --EMAIL                              
                                   ,GXSM                                --关系说明                               
                                   ,DJRQ                                --登记日期                               
                                   ,BDRQ                                --变动日期                                 
                                   ,XTBS								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.ID                                  as LXRID                               --ID                                  
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.LXRMC                               as LXRMC                               --联系人名称                               
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,t.ZJQSRQ                              as ZJQSRQ                              --证件起始日期                              
                                   ,t.ZJJZRQ                              as ZJJZRQ                              --证件截止日期                              
                                   ,t.DZ                                  as LXDZ                                --联系地址                                
                                   ,t.YZBM                                as YZBM                                --邮政编码                                
                                   ,t.DH                                  as LXDH                                --联系电话                                
                                   ,t.SJ                                  as MOBILE                              --手机                                  
                                   ,t.EMAIL                               as EMAIL                               --EMAIL                               
                                   ,t.GXSM                                as GXSM                                --关系说明                                
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                                          
                                   ,'YGT_GT'								   
 FROM           YGTCX.CIF_TLXR t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'ZJLBDM'
 AND            t1.YXT = 'YGT_GT'
 AND            t1.YDM = CAST(t.ZJLB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
-------插入数据结束----------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TLXR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T01_TLXR;

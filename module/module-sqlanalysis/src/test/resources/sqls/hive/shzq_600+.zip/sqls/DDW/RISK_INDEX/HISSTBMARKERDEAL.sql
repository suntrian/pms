 --/* ***************************************** SQL Begin *****************************************  */
  --/* 脚本功能:股转做市历史成交表                                                                    */
  --/* 创建人:黄勇华                                                                                 */
  --/* 创建时间:2017-12-21                                                                         */

 INSERT  OVERWRITE  RISK_INDEX.HISSTBMARKERDEAL
 (
         RECORD_ID              --记录号
        ,OC_DATE                --发生日期
        ,BUSINESS_TIME          --成交时间 
        ,REPORT_TIME            --申报时间
        ,SERIAL_NO              --序列号
        ,BUSINESS_NO            --成交编号 
        ,ENTRUST_NO             --委托号
        ,REPORT_NO              --申报号
        ,SEAT_NO                --席位号
        ,ASSET_PROP             --资产属性
        ,FUND_PROP              --资金属性
        ,FUND_ACCOUNT           --资产账户
        ,STOCK_ACCOUNT          --证券账户
        ,CLIENT_NAME            --客户名称
        ,EXCHANGE_TYPE          --交易市场
        ,STOCK_CODE             --证券代码
        ,STOCK_NAME             --证券名称
        ,ENTRUST_PROP           --委托属性
        ,ENTRUST_BS             --买卖方向
        ,REAL_TYPE              --成交类别
        ,MONEY_TYPE             --币种类别
        ,BUSINESS_AMOUNT        --成交数量
        ,BUSINESS_AMOUNT2       --成交数量2
        ,BUSINESS_PRICE         --成交价格
        ,BUSINESS_BALANCE       --成交金额
        ,REAL_STATUS            --成交状态
 ) PARTITION(DT = '%d{yyyyMMdd}')
SELECT     RECORD_ID                                                                                       AS RECORD_ID              --记录号
          ,CAST(EDW_PROD.G_DATE_CONVERT_INT(CAST(OC_DATE AS INT),'yyyyMMdd','yyyy-MM-dd') AS VARCHAR(16) ) AS OC_DATE                --发生日期
          ,CAST(CASE WHEN LENGTH(CAST(BUSINESS_TIME as STRING)) = 5
		        THEN CONCAT('0',SUBSTR(CAST(BUSINESS_TIME as STRING),1,1),':',SUBSTR(CAST(BUSINESS_TIME as STRING),2,2),':',SUBSTR(CAST(BUSINESS_TIME as STRING),4,2))
		        ELSE CONCAT(SUBSTR(CAST(BUSINESS_TIME as STRING),1,2),':',SUBSTR(CAST(BUSINESS_TIME as STRING),3,2),':',SUBSTR(CAST(BUSINESS_TIME as STRING),5,2))
				END AS VARCHAR(16))                                                                        AS BUSINESS_TIME          --成交时间  
		  
		  ,CAST(CASE WHEN LENGTH(CAST(REPORT_TIME as STRING)) = 5
		        THEN CONCAT('0',SUBSTR(CAST(REPORT_TIME as STRING),1,1),':',SUBSTR(CAST(REPORT_TIME as STRING),2,2),':',SUBSTR(CAST(REPORT_TIME as STRING),4,2))
		        ELSE CONCAT(SUBSTR(CAST(REPORT_TIME as STRING),1,2),':',SUBSTR(CAST(REPORT_TIME as STRING),3,2),':',SUBSTR(CAST(REPORT_TIME as STRING),5,2))
				END AS VARCHAR(16))                                        AS REPORT_TIME            --申报时间   
		  ,SERIAL_NO                                                                                       AS SERIAL_NO              --序列号
          ,BUSINESS_NO                                                                                     AS BUSINESS_NO            --成交编号 
		  ,ENTRUST_NO                                                                                      AS ENTRUST_NO             --委托号
		  ,REPORT_NO                                                                                       AS REPORT_NO              --申报号
		  ,SEAT_NO                                                                                         AS SEAT_NO                --席位号
		  ,ASSET_PROP                                                                                      AS ASSET_PROP             --资产属性
          ,FUND_PROP                                                                                       AS FUND_PROP              --资金属性
          ,FUND_ACCOUNT                                                                                    AS FUND_ACCOUNT           --资产账户
          ,STOCK_ACCOUNT                                                                                   AS STOCK_ACCOUNT          --证券账户
          ,CAST(CLIENT_NAME AS VARCHAR(256))                                                               AS CLIENT_NAME            --客户名称
          ,CAST(DECODE(TRIM(EXCHANGE_TYPE),'9','股转') AS CHAR(6))                                         AS EXCHANGE_TYPE          --交易市场
          ,STOCK_CODE                                                                                      AS STOCK_CODE             --证券代码
          ,CAST(a1.ZQMC AS VARCHAR(64))                                                                    AS STOCK_NAME             --证券名称
          ,ENTRUST_PROP                                                                                    AS ENTRUST_PROP           --委托属性
          ,CAST(DECODE(ENTRUST_BS,'B','买入','S','卖出','C','撤单','A','做市商双向报价') AS VARCHAR(64))   AS ENTRUST_BS             --买卖方向
          ,CAST(DECODE(REAL_TYPE,'2','做市申报','4','做市商互报成交确认申报') AS VARCHAR(64))              AS REAL_TYPE              --成交类别
          ,MONEY_TYPE                                                                                      AS MONEY_TYPE             --币种类别
          ,BUSINESS_AMOUNT                                                                                 AS BUSINESS_AMOUNT        --成交数量
          ,BUSINESS_AMOUNT2                                                                                AS BUSINESS_AMOUNT2       --成交数量2
          ,BUSINESS_PRICE                                                                                  AS BUSINESS_PRICE         --成交价格
          ,BUSINESS_BALANCE                                                                                AS BUSINESS_BALANCE       --成交金额
          ,REAL_STATUS                                                                                                                                                              
FROM       HSFK.HSMAN_HISSTBMAKERREALTIME     t                                                              
LEFT JOIN  EDW_PROD.T_EDW_T04_TZQDM           a1                                                               
ON         TRIM(t.STOCK_CODE)       = a1.ZQDM                                                                    
AND        a1.BUS_DATE              = %d{yyyyMMdd}                                                                         
WHERE      t.DT                     = '%d{yyyyMMdd}'
;  
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户开通交易权限表                                                                       */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */ 

ALTER TABLE DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd} ) ; 
---取昨天变动的客户临时表  
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP; 
 CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP
 as SELECT        t.CUST_NO                   --客户号
				 ,t.EXG                       --交易所
                 ,t.SHRHLD_NO                 --股东号								   
                 ,t.BRH_NO                    --营业部编号       
                 ,t.OPN_PRVL                  --开通权限     
                 ,t.OPN_DT                    --开通日期 
                 ,t.CHG_DT                    --变动日期	
   FROM  DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL t
   INNER JOIN (SELECT LST_TRD_D 
              FROM    EDW_PROD.T_EDW_T99_TRD_DATE
              WHERE   BUS_DATE = %d{yyyyMMdd}
			  AND TRD_DT = %d{yyyyMMdd} 
			  GROUP BY LST_TRD_D
			 )   a1
   ON    t.BUS_DATE = a1.LST_TRD_D
   WHERE t.CHG_DT < > 99999999
    ;
  ---取昨天未变动的客户临时表 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP1; 
 CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP1
 as SELECT        t.CUST_NO                   --客户号
				 ,t.EXG                       --交易所
                 ,t.SHRHLD_NO                 --股东号								   
                 ,t.BRH_NO                    --营业部编号       
                 ,t.OPN_PRVL                  --开通权限     
                 ,t.OPN_DT                    --开通日期 
                 ,t.CHG_DT                    --变动日期	
   FROM  DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL t
   INNER JOIN (SELECT LST_TRD_D 
              FROM    EDW_PROD.T_EDW_T99_TRD_DATE
              WHERE   BUS_DATE = %d{yyyyMMdd}
			  AND TRD_DT = %d{yyyyMMdd}
             GROUP BY LST_TRD_D			  
			 )   a1
   ON    t.BUS_DATE = a1.LST_TRD_D
   WHERE t.CHG_DT = 99999999
	;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP2; 
 CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP2
 as SELECT    t.KHH                        as CUST_NO                   --客户号
			  ,t.JYS                       as EXG                       --交易所
              ,t.GDH                       as SHRHLD_NO                 --股东号								   
              ,t.YYB                       as BRH_NO                    --营业部编号       
              ,t.JYQX                      as OPN_PRVL                  --开通权限     
              ,MIN(t.KTRQ)  as OPN_DT                    --开通日期  
              ,CASE WHEN a1.JZJYKH_KHZTDM = '3'
			        THEN a1.JZJYKH_XHRQ
					ELSE 99999999 
					END                    as CHG_DT                    --变动日期              
   FROM         EDW_PROD.T_EDW_T02_TKHJYQX t
   LEFT JOIN    EDW_PROD.T_EDW_T01_TKHXX    a1
   ON           t.KHH = a1.KHH
   AND          a1.BUS_DATE = %d{yyyyMMdd}
   LEFT JOIN   EDW_PROD.T_EDW_T99_TRD_DATE a2
   ON           t.KTRQ = a2.NAT_DT
   AND          a2.BUS_DATE = %d{yyyyMMdd}
   WHERE        t.BUS_DATE = %d{yyyyMMdd}
   AND          t.IF_TJ = 0
   AND         NVL(t.KTRQ,20140101) < = %d{yyyyMMdd}
   AND         (NVL(a1.JZJYKH_XHRQ,99999999) > = %d{yyyyMMdd} OR a1.JZJYKH_KHZTDM < > '3')
   GROUP BY CUST_NO,EXG,SHRHLD_NO,BRH_NO,OPN_PRVL,CHG_DT 
   ;
 


	
	
   
		   
 --------------插入数据-------------
 INSERT INTO DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
 (
                                   CUST_NO                   --客户号
								  ,EXG                       --交易所
                                  ,SHRHLD_NO                 --股东号								   
                                  ,BRH_NO                    --营业部编号       
                                  ,OPN_PRVL                  --开通权限     
                                  ,OPN_DT                    --开通日期 
                                  ,CHG_DT                    --变动日期								  
 ) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.CUST_NO                  as CUST_NO                   --客户号              
                                   ,t.EXG                      as EXG                       --交易所        
                                   ,t.SHRHLD_NO                as SHRHLD_NO                 --股东号		      
                                   ,t.BRH_NO                   as BRH_NO                    --营业部编号          
                                   ,t.OPN_PRVL 			       as OPN_PRVL                  --开通权限     
                                   ,t.OPN_DT                   as OPN_DT                    --开通日期 
                                   ,t.CHG_DT                   as CHG_DT                    --变动日期		

 FROM    DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP  t ; 
  INSERT INTO DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
 (
                                   CUST_NO                   --客户号
								  ,EXG                       --交易所
                                  ,SHRHLD_NO                 --股东号								   
                                  ,BRH_NO                    --营业部编号       
                                  ,OPN_PRVL                  --开通权限     
                                  ,OPN_DT                    --开通日期 
                                  ,CHG_DT                    --变动日期								  
 ) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.CUST_NO                  as CUST_NO                   --客户号              
                                   ,t.EXG                      as EXG                       --交易所        
                                   ,t.SHRHLD_NO                as SHRHLD_NO                 --股东号		      
                                   ,t.BRH_NO                   as BRH_NO                    --营业部编号          
                                   ,t.OPN_PRVL 			       as OPN_PRVL                  --开通权限     
                                   ,LEAST(NVL(t.OPN_DT,99999999),NVL(a1.OPN_DT,99999999))                   as OPN_DT                    --开通日期 
                                   ,t.CHG_DT                   as CHG_DT                    --变动日期		

 FROM    DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP2  t
 LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP1 a1
 ON          t.EXG = a1.EXG
 AND         t.CUST_NO = a1.CUST_NO
 AND         t.OPN_PRVL = a1.OPN_PRVL
 AND         t.SHRHLD_NO = a1.SHRHLD_NO
 WHERE     t.OPN_DT < = %d{yyyyMMdd} ;
 INSERT INTO DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL
 (
                                   CUST_NO                   --客户号
								  ,EXG                       --交易所
                                  ,SHRHLD_NO                 --股东号								   
                                  ,BRH_NO                    --营业部编号       
                                  ,OPN_PRVL                  --开通权限     
                                  ,OPN_DT                    --开通日期 
                                  ,CHG_DT                    --变动日期								  
 ) 
 partition(bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.CUST_NO           as CUST_NO                   --客户号              
                                   ,t.EXG               as EXG                       --交易所        
                                   ,t.SHRHLD_NO         as SHRHLD_NO                 --股东号		      
                                   ,t.BRH_NO            as BRH_NO                    --营业部编号          
                                   ,t.OPN_PRVL 		    as OPN_PRVL                  --开通权限     
                                   ,t.OPN_DT            as OPN_DT                    --开通日期 
                                   ,%d{yyyyMMdd}        as CHG_DT                    --变动日期		

 FROM         DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP1  t
 LEFT  JOIN   DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP2  a1
 ON          t.EXG = a1.EXG
 AND         t.CUST_NO = a1.CUST_NO
 AND         t.OPN_PRVL = a1.OPN_PRVL
 AND         t.SHRHLD_NO = a1.SHRHLD_NO
 WHERE    a1.EXG IS  NULL
 ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP; 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP1; 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL_TEMP2; 
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_CUST_OPN_TRD_PRVL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL ;
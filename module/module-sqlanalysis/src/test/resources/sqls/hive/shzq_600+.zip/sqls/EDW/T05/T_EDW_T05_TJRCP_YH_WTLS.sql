 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:金融产品银行委托历史表                                                              */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
---------------- 插入数据开始 -----------------------
INSERT OVERWRITE EDW_PROD.T_EDW_T05_TJRCP_YH_WTLS(
                                    SEQNO                               --事件序号                               
                                   ,LSH                                 --流水号                                
                                   ,WTH                                 --委托号                                
                                   ,SQBH                                --申请编号                               
                                   ,CXBZ                                --撤销标志                               
                                   ,YSQBH                               --原申请编号                              
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,CPZH                                --产品帐号                               
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,JSZH                                --结算帐号                               
                                   ,FXJG                                --发行机构                               
                                   ,CPDM                                --产品代码                               
                                   ,CPJC                                --产品简称                               
                                   ,LCZH                                --理财帐号                               
                                   ,ZHMM                                --帐户密码                               
                                   ,JRCP_YWDM                           --金融产品业务代码                           
                                   ,JRCP_SFFS                           --金融产品收费方式                           
                                   ,XTYWDM                              --系统业务代码                             
                                   ,WTRQ                                --委托日期                               
                                   ,WTSJ                                --委托时间                               
                                   ,WTFE                                --委托份额                               
                                   ,WTJE                                --委托金额                               
                                   ,XYBH                                --协议编号                               
                                   ,ZDRGRQ                              --指定认购日期                             
                                   ,SFLX                                --SFLX                               
                                   ,ZKL                                 --折扣率                                
                                   ,ZDFY                                --指定费用                               
                                   ,ZDFL                                --指定费率                               
                                   ,JESHCLFS                            --巨额赎回处理方式                           
                                   ,WTGY                                --委托柜员                               
                                   ,WTFS                                --委托方式                               
                                   ,FSYYB                               --发生营业部                              
                                   ,CZZD                                --操作站点                               
                                   ,BZDM                                --币种代码                               
                                   ,ZJDJXM_LSH                          --资金冻结项目流水号                          
                                   ,LSH_FEDJXM                          --份额冻结项目流水号                          
                                   ,SQCZRH                              --授权操作人号                             
                                   ,SBRQ                                --申报日期                               
                                   ,SBSJ                                --申报时间                               
                                   ,SBJG                                --申报结果                               
                                   ,CLJG                                --处理结果                               
                                   ,CSCS                                --超时次数                               
                                   ,PCJGSM                              --评测结果说明 
                                   ,KHGMNL                              --客户购买年龄								   
                                   ,CZZD1                               --操作终端                               
                                   ,IP_PHONE                            --IP地址/ 电话号码                         
                                   ,MAC                                 --MAC地址   
                                   ,XTBS                                --系统标识								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.SEQNO                               as SEQNO                               --序号                                  
                                   ,t.LSH                                 as LSH                                 --流水号                                 
                                   ,t.WTH                                 as WTH                                 --委托号                                 
                                   ,t.SQBH                                as SQBH                                --申请编号                                
                                   ,t.CXBZ                                as CXBZ                                --撤销标志                                
                                   ,t.YSQBH                               as YSQBH                               --原申请编号                               
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,t.CPZH                                as CPZH                                --产品帐号                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZJJSLX                              --结算类型                                
                                   ,t.JSJG                                as JSJG                                --结算机构                                
                                   ,t.JSZH                                as JSZH                                --结算帐号                                
                                   ,t.FXJG                                as FXJG                                --发行机构                                
                                   ,t.CPDM                                as CPDM                                --产品代码                                
                                   ,t.CPJC                                as CPJC                                --产品简称                                
                                   ,t.LCZH                                as LCZH                                --理财帐号                                
                                   ,t.ZHMM                                as ZHMM                                --帐户密码                                
                                   ,t.YWDM                                as JRCP_YWDM                           --业务代码                                
                                   ,t.SFFS                                as JRCP_SFFS                           --收费方式                                
                                   ,t.XTYWDM                              as XTYWDM                              --系统业务代码                              
                                   ,t.WTRQ                                as WTRQ                                --委托日期                                
                                   ,t.WTSJ                                as WTSJ                                --委托时间                                
                                   ,t.WTFE                                as WTFE                                --委托份额                                
                                   ,t.WTJE                                as WTJE                                --委托金额                                
                                   ,t.XYBH                                as XYBH                                --协议编号                                
                                   ,t.ZDRGRQ                              as ZDRGRQ                              --指定认购日期                              
                                   ,t.SFLX                                as SFLX                                --                                    
                                   ,t.ZKL                                 as ZKL                                 --折扣率                                 
                                   ,t.ZDFY                                as ZDFY                                --指定费用                                
                                   ,t.ZDFL                                as ZDFL                                --指定费率                                
                                   ,t.JESHCLFS                            as JESHCLFS                            --巨额赎回处理方式                            
                                   ,t.WTGY                                as WTGY                                --委托柜员                                
                                   ,CAST( EDW_PROD.G_WTFS_J_WTFS(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD) AS DECIMAL(38,0) )     as WTFS                                --委托方式                                
                                   ,t.FSYYB                               as FSYYB                               --发生营业部                               
                                   ,t.CZZD                                as CZZD                                --操作站点                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                   as BZDM                                --币种                                  
                                   ,t.LSH_ZJDJXM                          as ZJDJXM_LSH                          --资金冻结项目流水号                           
                                   ,t.LSH_FEDJXM                          as LSH_FEDJXM                          --份额冻结项目流水号                           
                                   ,t.SQCZRH                              as SQCZRH                              --授权操作人号                              
                                   ,t.SBRQ                                as SBRQ                                --申报日期                                
                                   ,t.SBSJ                                as SBSJ                                --申报时间                                
                                   ,t.SBJG                                as SBJG                                --申报结果                                
                                   ,t.CLJG                                as CLJG                                --处理结果                                
                                   ,t.CSCS                                as CSCS                                --超时次数                                
                                   ,t.PCJGSM                              as PCJGSM                              --评测结果说明 
                                   ,CASE WHEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),5,2) AS INT) > CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(a1.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}                                      
									  THEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),1,4) AS INT) - CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),1,4) AS INT)
                                      WHEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),5,2) AS INT) < CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(a1.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
                                      THEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),1,4) AS INT) - CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),1,4) AS INT) - 1
                                      WHEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),5,2) AS INT) = CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(a1.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
                                      AND CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),7,2) AS INT) >= CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),7,2) AS INT)
                                      THEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),1,4) AS INT) - CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),1,4) AS INT)
                                      WHEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),5,2) AS INT) = CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(a1.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
                                      AND CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),7,2) AS INT) < CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),7,2) AS INT)
                                      THEN CAST(SUBSTR(CAST(NVL(t.SBRQ,0) as STRING),1,4) AS INT) - CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),1,4) AS INT) - 1
                                      ELSE 0 END as KHGMNL
								   --CASE WHEN t.SBRQ <>0 AND a1.CSRQ <>99999999 
								     --    THEN ROUND(EDW_PROD.G_DATE_COMPARE_DATE(CAST(t.SBRQ AS STRING),'yyyyMMdd',CAST(a1.CSRQ AS STRING),'yyyyMMdd')/365,0)
									--	 ELSE NULL 
									--	 END                             as KHGMNL  								   
                                   ,EDW_PROD.G_WTFS_J_TERM(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD)                                  as CZZD1                                             --                                    
                                   ,NVL(NVL(CONCAT(EDW_PROD.G_WTFS_J_IP(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD),',',EDW_PROD.G_WTFS_J_PHONE(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD)),EDW_PROD.G_WTFS_J_IP(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD)),EDW_PROD.G_WTFS_J_PHONE(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD))                       as IP_PHONE                            --IP地址/ 电话号码
								   ,NVL(NVL(CONCAT(EDW_PROD.G_WTFS_J_MAC(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD),',',EDW_PROD.G_WTFS_J_IMEI(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD)),EDW_PROD.G_WTFS_J_MAC(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD)),EDW_PROD.G_WTFS_J_IMEI(CAST(t.WTFS AS INT),0,t.FSYYB,t.WTGY,t.CZZD)) 						  as MAC                                 --  
                                   ,'JZJY'		                          as XTBS						   
 FROM      (SELECT * FROM JZJYCX.DATACENTER_TJRCP_YH_WTLS WHERE 	DT = '%d{yyyyMMdd}'	) t
 LEFT JOIN      (SELECT KHH,CSRQ FROM EDW_PROD.T_EDW_T01_TGRKHXX  WHERE  BUS_DATE = %d{yyyyMMdd})                  a1
  ON             t.KHH = a1.KHH
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'ZJJSLX'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.JSLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'BZDM'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t4
 ON             t4.YXT = 'JZJY'
 AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE 			t.DT = '%d{yyyyMMdd}' 

;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TJRCP_YH_WTLS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_TJRCP_YH_WTLS;
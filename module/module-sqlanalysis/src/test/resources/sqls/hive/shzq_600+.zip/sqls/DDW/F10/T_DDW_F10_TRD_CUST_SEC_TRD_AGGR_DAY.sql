------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户证券交易汇总日表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
  
----创建证券交易汇总临时表
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP;
 CREATE TABLE  DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP as 
   SELECT           t.CUST_NO
                   --,a1.BRH_NO
                   ,t.EXG
                  -- ,a1.CUST_CGY 
	               ,a3.BS_DRCT
	               ,a3.SEC_CL_CD
				   ,t.MTCH_AMT
				   ,a2.BZDM
				   ,a2.ZHHL
				   ,t.MTCH_QTY
				   ,t.S1
				   ,t.S11
				   ,t.S12
				   ,t.odr_cgy
				   ,t.sys_src as ACCNT_CGY
	FROM          DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS  		      t		
  --  LEFT JOIN      DDW_PROD.T_DDW_F00_CUST_CUST_INFO                   a1
  --  ON             t.CUST_NO = a1.CUST_NO
  --  AND            a1.BUS_DATE = %d{yyyyMMdd}
    LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH                             a2
    ON             t.CCY_CD = a2.BZDM
	AND            t.BUS_DATE = a2.BUS_DATE
    LEFT JOIN      DDW_PROD.T_DDW_CFG_SEC_TRD_CL                       a3
    ON             t.EXG = a3.EXG
    AND            SUBSTR(t.SEC_CD,1,3) = a3.SEC_CD_PFX
    AND            (SUBSTR(t.SEC_CGY,1,1) = a3.SEC_CGY_PFX
    OR             SUBSTR(t.SEC_CGY,1,3) = a3.SEC_CGY_PFX)
    AND            t.ODR_CGY = a3.TRD_CGY
	WHERE          t.BUS_DATE = %d{yyyyMMdd} ;
--	UNION ALL
--	SELECT          t.CUST_NO
--                   --,a1.BRH_NO
--                   ,t.EXG
--                  -- ,a1.CUST_CGY 
--	               ,a3.BS_DRCT
--	               ,a3.SEC_CL_CD
--				   ,t.MTCH_AMT
--				   ,a2.BZDM
--				   ,a2.ZHHL
--				   ,t.MTCH_QTY
--				   ,t.S1
--				   ,t.S11
--				   ,t.S12
--				   ,t.odr_cgy
--				   ,t.sys_src as ACCNT_CGY
--	FROM          DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS  		      t		
--   -- LEFT JOIN      DDW_PROD.T_DDW_F00_CUST_CUST_INFO                   a1
--  --  ON             t.CUST_NO = a1.CUST_NO
--  --  AND            a1.BUS_DATE = %d{yyyyMMdd}
--    LEFT JOIN      EDW_PROD.T_EDW_T99_HLZH                             a2
--    ON             t.CCY_CD = a2.BZDM
--	AND            t.BUS_DATE = a2.BUS_DATE
--    LEFT JOIN      DDW_PROD.T_DDW_CFG_SEC_TRD_CL                       a3
--    ON             t.EXG = a3.EXG
--    AND            SUBSTR(t.SEC_CD,1,3) = a3.SEC_CD_PFX
--    AND            SUBSTR(t.SEC_CGY,1,3) = a3.SEC_CGY_PFX
--	AND            t.ODR_CGY = a3.TRD_CGY
--	WHERE          a3.EXG IS NOT NULL
--	AND            t.BUS_DATE = %d{yyyyMMdd}
--	;
-------------------
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP1;
 CREATE TABLE  DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP1
 as SELECT          t.CUST_NO
                  -- ,t.BRH_NO
                   ,t.EXG
                   --,t.CUST_CGY
				     ,t.ACCNT_CGY
				   ,SUM(CASE WHEN t.BS_DRCT = 1 
			                 AND  t.SEC_CL_CD IN ('001','002','003')                      				  
				             THEN t.MTCH_AMT
				             ELSE 0 
				             END
			            )                                     as ASTK_BUYIN_MTCH_AMT              --A股买入成交金额
                   ,SUM(CASE WHEN t.BS_DRCT = 2
			                 AND  t.SEC_CL_CD IN ('001','002','003')				 
				             THEN t.MTCH_AMT
				             ELSE 0 
				             END
			             )                                     as ASTK_SELL_MTCH_AMT               --A股卖出成交金额
                   ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			                 AND  t.SEC_CL_CD IN ('001','002','003')				  
				             THEN t.MTCH_AMT
				             ELSE 0 
				             END
				        )                                      as ASTK_MTCH_AMT                    --A股成交金额
                   ,SUM(CAST(CASE WHEN t.BS_DRCT = 1 
			                      AND  t.SEC_CL_CD IN ('005','063')
			                      AND  t.BZDM IS NOT NULL
					              THEN t.MTCH_AMT*t.ZHHL
			                      ELSE 0 
			                      END as DECIMAL(38,2))
		                )	                                   as BSTK_BUYIN_MTCH_AMT_RMB          --B股买入成交金额
                   ,SUM(CAST(CASE WHEN t.BS_DRCT = 2 
			                      AND  t.SEC_CL_CD IN ('005','063')
			                      AND  t.BZDM IS NOT NULL
				                  THEN t.MTCH_AMT*t.ZHHL
			                      ELSE 0 
			                      END as DECIMAL(38,2))
		                )                                         as BSTK_SELL_MTCH_AMT_RMB           --B股卖出成交金额
                   ,SUM(CAST(CASE WHEN t.BS_DRCT IN (1,2) 
			                      AND  t.SEC_CL_CD IN ('005','063')
			                      AND  t.BZDM IS NOT NULL
					              THEN t.MTCH_AMT*t.ZHHL
			                      ELSE 0 
			                      END as DECIMAL(38,2))
		               )                                     as BSTK_MTCH_AMT_RMB                --B股成交金额
	              ,SUM(CASE WHEN t.BS_DRCT = 1 
			                AND  t.SEC_CL_CD IN ('005')                      				  
			                THEN t.MTCH_AMT
			                ELSE 0 
			                END
		                )			                               as BSTK_BUYIN_MTCH_AMT_USD          --B股美元买入成交金额
                 ,SUM(CASE WHEN t.BS_DRCT = 2 
			               AND  t.SEC_CL_CD IN ('005')                      				  
			               THEN t.MTCH_AMT
			               ELSE 0 
			               END
		              )                                          as BSTK_SELL_MTCH_AMT_USD           --B股美元卖出成交金额
                ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			              AND  t.SEC_CL_CD IN ('005')                      				  
			              THEN t.MTCH_AMT
			              ELSE 0 
			              END
		            )                                          as BSTK_MTCH_AMT_USD                --B股美元成交金额
		        ,SUM(CASE WHEN t.BS_DRCT = 1 
			              AND  t.SEC_CL_CD IN ('063')                      				  
			              THEN t.MTCH_AMT
			              ELSE 0 
			              END
		            ) 		                                   as BSTK_BUYIN_MTCH_AMT_HKD          --B股港币买入成交金额
               ,SUM(CASE WHEN t.BS_DRCT = 2 
			             AND  t.SEC_CL_CD IN ('063')                      				  
			             THEN t.MTCH_AMT
			             ELSE 0 
			             END
		            )                                           as BSTK_SELL_MTCH_AMT_HKD           --B股港币卖出成交金额
               ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			             AND  t.SEC_CL_CD IN ('063')                      				  
			             THEN t.MTCH_AMT
			             ELSE 0 
			             END
		            )                                           as BSTK_MTCH_AMT_HKD                --B股港币成交金额
               ,SUM(CASE WHEN t.BS_DRCT = 1 
			             AND  t.SEC_CL_CD IN ('004')                      				  
			             THEN t.MTCH_AMT
			             ELSE 0 
			             END
		            )                                            as GEM_BUYIN_MTCH_AMT               --创业板买入成交金额
               ,SUM(CASE WHEN t.BS_DRCT = 2 
			             AND  t.SEC_CL_CD IN ('004')                      				  
			             THEN t.MTCH_AMT
			             ELSE 0 
			             END
		           )                                            as GEM_SELL_MTCH_AMT                --创业板卖出成交金额
               ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			             AND  t.SEC_CL_CD IN ('004')                      				  
			             THEN t.MTCH_AMT
			             ELSE 0 
			             END
		           )                                            as GEM_MTCH_AMT                     --创业板成交金额
               ,SUM(CAST(CASE WHEN t.BS_DRCT = 1
			                   AND  t.SEC_CL_CD IN ('006','007')
			                   AND  t.BZDM IS NOT NULL
				               THEN t.MTCH_AMT*t.ZHHL
				               WHEN t.BS_DRCT = 1
			                   AND  t.SEC_CL_CD IN ('006','007')
			                   AND  t.BZDM IS  NULL
				               THEN t.MTCH_AMT
			                   ELSE 0 
			                   END as DECIMAL(38,2))
		            )                                              as OLD_T3BOD_BUYIN_MTCH_AMT         --老三板买入成交金额
                ,SUM(CAST(CASE WHEN t.BS_DRCT = 2
			                   AND  t.SEC_CL_CD IN ('006','007')
			                   AND  t.BZDM IS NOT NULL
		                       THEN t.MTCH_AMT*t.ZHHL
				               WHEN t.BS_DRCT = 2
			                   AND  t.SEC_CL_CD IN ('006','007')
			                   AND  t.BZDM IS  NULL
				               THEN t.MTCH_AMT
			                   ELSE 0 
			                   END as DECIMAL(38,2))
		             )                                          as OLD_T3BOD_SELL_MTCH_AMT          --老三板卖出成交金额
	            ,SUM(CAST(CASE WHEN t.BS_DRCT IN (1,2)
			                   AND  t.SEC_CL_CD IN ('006','007')
			                   AND  t.BZDM IS NOT NULL
		                       THEN t.MTCH_AMT*t.ZHHL
				               WHEN t.BS_DRCT = 0
			                   AND  t.SEC_CL_CD IN ('006','007')
			                   AND  t.BZDM IS  NULL
			                   THEN t.MTCH_AMT
			                   ELSE 0 
			                   END as DECIMAL(38,2))
		            ) 		                                    as OLD_T3BOD_MTCH_AMT               --老三板成交金额
	           ,SUM(CASE WHEN t.BS_DRCT = 1
			             AND  t.SEC_CL_CD IN ('007')                      				  
			             THEN t.MTCH_AMT
			             ELSE 0 
			             END
		            )		                                        as OLD_T3BOD_BUYIN_MTCH_AMT_USD     --老三板美元买入成交金额
              ,SUM(CASE WHEN t.BS_DRCT = 2 
			            AND  t.SEC_CL_CD IN ('007')                      				  
			            THEN t.MTCH_AMT
			            ELSE 0 
			            END
		           )                                            as OLD_T3BOD_SELL_MTCH_AMT_USD      --老三板美元卖出成交金额
		      ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			            AND  t.SEC_CL_CD IN ('007')                      				  
			            THEN t.MTCH_AMT
			            ELSE 0 
			            END
		          ) 		                                    as OLD_T3BOD_MTCH_AMT_USD           --老三板美元成交金额
             ,SUM(CASE WHEN t.BS_DRCT = 1
			           AND  t.SEC_CL_CD IN ('008')                      				  
			           THEN t.MTCH_AMT
			           ELSE 0 
			           END
		          )	                                            as NEW_T3BOD_BUYIN_MTCH_AMT         --新三板买入成交金额
             ,SUM(CASE WHEN t.BS_DRCT = 2
			           AND  t.SEC_CL_CD IN ('008')                      				  
			           THEN t.MTCH_AMT
			           ELSE 0 
			           END
		          )                                             as NEW_T3BOD_SELL_MTCH_AMT          --新三板卖出成交金额
             ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			           AND  t.SEC_CL_CD IN ('008')                      				  
			           THEN t.MTCH_AMT
			           ELSE 0 
			           END
		         )                                             as NEW_T3BOD_MTCH_AMT               --新三板成交金额
	        ,SUM(CASE WHEN t.BS_DRCT = 4
			          AND  t.SEC_CL_CD IN ('013')                      				  
			          THEN t.MTCH_AMT
			          ELSE 0 
			          END
		        ) 			                                as QOT_REPO_MRGNS_AMT          --报价回购融券金额
	        ,SUM(CASE WHEN t.BS_DRCT = 4
			          AND  t.SEC_CL_CD IN ('009','010','011','014')                      				  
			          THEN t.MTCH_AMT
			          ELSE 0 
			          END
		        ) 			                                    as ORDI_REPO_MRGNS_AMT         --普通回购融券金额
	        ,SUM(CASE WHEN t.BS_DRCT = 3
			          AND  t.SEC_CL_CD IN ('009','010','011','014')                      				  
			          THEN t.MTCH_AMT
			          ELSE 0 
			          END
		         )			                                    as ORDI_REPO_MRGNC_AMT         --普通回购融资金额
	        ,SUM(CASE WHEN t.BS_DRCT = 1
			          AND  t.SEC_CL_CD IN ('015','016')                      				  
			          THEN t.MTCH_AMT
			          ELSE 0 
			          END
		         )    			                                as HK_STK_BUYIN_MTCH_AMT            --港股买入成交金额
	        ,SUM(CASE WHEN t.BS_DRCT = 2
			          AND  t.SEC_CL_CD IN ('015','016')                      				  
			          THEN t.MTCH_AMT
			          ELSE 0 
			          END
		          )  			                                as HK_STK_SELL_MTCH_AMT             --港股卖出成交金额
	       ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			         AND  t.SEC_CL_CD IN ('015','016')                      				  
			         THEN t.MTCH_AMT
			         ELSE 0 
			         END
		       )			                                    as HK_STK_MTCH_AMT                  --港股成交金额
	       ,SUM(CASE WHEN t.BS_DRCT = 1
			         AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			         THEN t.MTCH_AMT
			         ELSE 0 
			         END
		       )			                                    as BOND_BUYIN_MTCH_AMT              --债券买入成交金额
	      ,SUM(CASE WHEN t.BS_DRCT = 2
			        AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			        THEN t.MTCH_AMT
			        ELSE 0 
			        END
		      )			                                    as BOND_SELL_MTCH_AMT               --债券卖出成交金额
	      ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			        AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			        THEN t.MTCH_AMT
			        ELSE 0 
			        END
		      )				                                as BOND_MTCH_AMT                    --债券成交金额
	      ,SUM(CASE WHEN t.ODR_CGY = 83
			        AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			        THEN t.MTCH_AMT
			        ELSE 0 
			        END
		      )                  as EXG_FND_SCRP_MTCH_AMT           --场内基金认购成交金额
		  
		  ,SUM(CASE WHEN (t.BS_DRCT = 1 OR t.ODR_CGY = 83)
			        AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			        THEN t.MTCH_AMT
			        ELSE 0 
			        END
		      )				                                as EXG_FND_BUYIN_MTCH_AMT           --场内基金买入成交金额
	      ,SUM(CASE WHEN t.BS_DRCT = 2
			        AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			        THEN t.MTCH_AMT
			        ELSE 0 
			        END
		      )			                                    as EXG_FND_SELL_MTCH_AMT            --场内基金卖出成交金额
	     ,SUM(CASE WHEN (t.BS_DRCT IN (1,2) OR t.ODR_CGY = 83)
			       AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			       THEN t.MTCH_AMT
			       ELSE 0 
			       END
		     )			                                    as EXG_FND_MTCH_AMT                 --场内基金成交金额
    FROM          DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP  		      t	
    GROUP BY      CUST_NO,EXG,ACCNT_CGY	;	    
		
		
		
		
		
---------

DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP2;
 CREATE TABLE  DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP2
 as  SELECT          t.CUST_NO
                  -- ,t.BRH_NO
                   ,t.EXG
                   --,t.CUST_CGY
				     ,t.ACCNT_CGY

,SUM(CASE WHEN t.BS_DRCT = 1 
			      AND  t.SEC_CL_CD IN ('001','002','003')                      				  
		          THEN t.MTCH_QTY
			      ELSE 0 
			      END
		    )                                               as ASTK_BUYIN_MTCH_QTY              --A股买入成交数量
       ,SUM(CASE WHEN t.BS_DRCT = 2  
			     AND  t.SEC_CL_CD IN ('001','002','003')				 
			     THEN t.MTCH_QTY
			     ELSE 0 
			     END
		   )                                               as ASTK_SELL_MTCH_QTY               --A股卖出成交数量
      ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			    AND  t.SEC_CL_CD IN ('001','002','003')				  
			    THEN t.MTCH_QTY
			    ELSE 0 
			    END
		  )                                               as ASTK_MTCH_QTY                    --A股成交数量
      ,SUM(CASE WHEN t.BS_DRCT = 1
			    AND  t.SEC_CL_CD IN ('005','063')
			    THEN t.MTCH_QTY
			    ELSE 0 
			    END
		  )	                                            as BSTK_BUYIN_MTCH_QTY              --B股买入成交数量
     ,SUM(CASE WHEN t.BS_DRCT = 2 
			   AND  t.SEC_CL_CD IN ('005','063')			          
			   THEN t.MTCH_QTY
			   ELSE 0 
			   END
		  )                                              as BSTK_SELL_MTCH_QTY               --B股卖出成交数量
    ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			  AND  t.SEC_CL_CD IN ('005','063')
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		 )                                              as BSTK_MTCH_QTY                    --B股成交数量	
   ,SUM(CASE WHEN t.BS_DRCT = 1 
			 AND  t.SEC_CL_CD IN ('004')                      				  
			 THEN t.MTCH_QTY
			 ELSE 0 
			 END
		)                                               as GEM_BUYIN_MTCH_QTY               --创业板买入成交数量
   ,SUM(CASE WHEN t.BS_DRCT = 2 
			 AND  t.SEC_CL_CD IN ('004')                      				  
			 THEN t.MTCH_QTY
			 ELSE 0 
			 END
		)                                               as GEM_SELL_MTCH_QTY                --创业板卖出成交数量
   ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			 AND  t.SEC_CL_CD IN ('004')                      				  
			 THEN t.MTCH_QTY
			 ELSE 0 
			 END
		)                                               as GEM_MTCH_QTY                     --创业板成交数量
    ,SUM(CASE WHEN t.BS_DRCT = 1
			  AND  t.SEC_CL_CD IN ('006','007')
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		)                                               as OLD_T3BOD_BUYIN_MTCH_QTY         --老三板买入成交数量
    ,SUM(CASE WHEN t.BS_DRCT = 2
			  AND  t.SEC_CL_CD IN ('006','007')
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		)                                               as OLD_T3BOD_SELL_MTCH_QTY          --老三板卖出成交数量
	,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			  AND  t.SEC_CL_CD IN ('006','007')
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		 ) 		                                        as OLD_T3BOD_MTCH_QTY               --老三板成交数量		
    ,SUM(CASE WHEN t.BS_DRCT = 1
			  AND  t.SEC_CL_CD IN ('008')                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		 )	                                            as NEW_T3BOD_BUYIN_MTCH_QTY         --新三板买入成交数量
   ,SUM(CASE WHEN t.BS_DRCT = 2
			 AND  t.SEC_CL_CD IN ('008')                      				  
			 THEN t.MTCH_QTY
			 ELSE 0 
			 END
		)                                               as NEW_T3BOD_SELL_MTCH_QTY          --新三板卖出成交数量
   ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			 AND  t.SEC_CL_CD IN ('008')                      				  
			 THEN t.MTCH_QTY
			 ELSE 0 
			 END
		)                                               as NEW_T3BOD_MTCH_QTY               --新三板成交数量
	,SUM(CASE WHEN t.BS_DRCT = 4
			  AND  t.SEC_CL_CD IN ('013')                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		 ) 			                                    as QOT_REPO_MRGNS_MTCH_QTY          --报价回购融券成交数量
	,SUM(CASE WHEN t.BS_DRCT = 4
			  AND  t.SEC_CL_CD IN ('009','010','011','014')                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		 ) 			                                    as ORDI_REPO_MRGNS_MTCH_QTY         --普通回购融券成交数量
	,SUM(CASE WHEN t.BS_DRCT = 3
			  AND  t.SEC_CL_CD IN ('009','010','011','014')                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		 )			                                    as ORDI_REPO_MRGNC_MTCH_QTY         --普通回购融资成交数量
	,SUM(CASE WHEN t.BS_DRCT = 1
			  AND  t.SEC_CL_CD IN ('015','016')                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		 )    			                                as HK_STK_BUYIN_MTCH_QTY            --港股买入成交数量
	,SUM(CASE WHEN t.BS_DRCT = 2
			  AND  t.SEC_CL_CD IN ('015','016')                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		 )  			                                as HK_STK_SELL_MTCH_QTY             --港股卖出成交数量
	,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			  AND  t.SEC_CL_CD IN ('015','016')                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		 )			                                    as HK_STK_MTCH_QTY                  --港股成交数量
	 ,SUM(CASE WHEN t.BS_DRCT = 1
			   AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			   THEN t.MTCH_QTY
			   ELSE 0 
			   END
		  )			                                    as BOND_BUYIN_MTCH_QTY              --债券买入成交数量
	,SUM(CASE WHEN t.BS_DRCT = 2
			  AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		 )			                                    as BOND_SELL_MTCH_QTY               --债券卖出成交数量
	,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			  AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		 )				                                as BOND_MTCH_QTY                    --债券成交数量
	,SUM(CASE WHEN  t.ODR_CGY = 83
			  AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		)	as EXG_FND_SCRP_MTCH_QTY      --场内基金认购数量
	,SUM(CASE WHEN t.BS_DRCT = 1 
			  AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		)				                                as EXG_FND_BUYIN_MTCH_QTY           --场内基金买入成交数量
	,SUM(CASE WHEN t.BS_DRCT = 2
			  AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		 )			                                    as EXG_FND_SELL_MTCH_QTY            --场内基金卖出成交数量
	,SUM(CASE WHEN (t.BS_DRCT IN (1,2) OR t.ODR_CGY = 83)
			  AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			  THEN t.MTCH_QTY
			  ELSE 0 
			  END
		  )			                                    as EXG_FND_MTCH_QTY                 --场内基金成交数量
     FROM          DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP  		      t	
    GROUP BY      CUST_NO,EXG,ACCNT_CGY	;	
	
	
	
	
	
	
--------
 
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP3;
 CREATE TABLE  DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP3
 as  SELECT          t.CUST_NO
                  -- ,t.BRH_NO
                     ,t.EXG	
				     ,t.ACCNT_CGY
	,SUM(CASE WHEN t.BS_DRCT = 1 
			  AND  t.SEC_CL_CD IN ('001','002','003')                      				  
			  THEN t.S1
			  ELSE 0 
			  END
		 )                                              as ASTK_BUYIN_S1                     --A股买入毛佣金
    ,SUM(CASE WHEN t.BS_DRCT = 2  
			  AND  t.SEC_CL_CD IN ('001','002','003')				 
			  THEN t.S1
			  ELSE 0 
			  END
		)                                                as ASTK_SELL_S1               --A股卖出毛佣金
    ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			  AND  t.SEC_CL_CD IN ('001','002','003')				  
			  THEN t.S1
			  ELSE 0 
			  END
		)                                                 as ASTK_S1                    --A股毛佣金
    ,SUM(CAST(CASE WHEN t.BS_DRCT = 1 
			  AND  t.SEC_CL_CD IN ('005','063')
			  AND  t.BZDM IS NOT NULL
			  THEN t.S1*t.ZHHL
			  ELSE 0 
			  END as DECIMAL(38,2))
		)	                                              as BSTK_BUYIN_S1_RMB          --B股买入毛佣金
    ,SUM(CAST(CASE WHEN t.BS_DRCT = 2 
			  AND  t.SEC_CL_CD IN ('005','063')
			  AND  t.BZDM IS NOT NULL
			  THEN t.S1*t.ZHHL
			  ELSE 0 
			  END as DECIMAL(38,2))
		)                                                 as BSTK_SELL_S1_RMB           --B股卖出毛佣金
    ,SUM(CAST(CASE WHEN t.BS_DRCT IN (1,2) 
			  AND  t.SEC_CL_CD IN ('005','063')
			  AND  t.BZDM IS NOT NULL
		      THEN t.S1*t.ZHHL
			  ELSE 0 
			  END as DECIMAL(38,2))
		 )                                                as BSTK_S1_RMB                --B股毛佣金
	,SUM(CASE WHEN t.BS_DRCT = 1 
			  AND  t.SEC_CL_CD IN ('005')                      				  
			  THEN t.S1
			  ELSE 0 
			  END
		 )			                                      as BSTK_BUYIN_S1_USD          --B股美元买入毛佣金
    ,SUM(CASE WHEN t.BS_DRCT = 2 
			  AND  t.SEC_CL_CD IN ('005')                      				  
			  THEN t.S1
			  ELSE 0 
			  END
		 )                                                as BSTK_SELL_S1_USD           --B股美元卖出毛佣金
   ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			 AND  t.SEC_CL_CD IN ('005')                      				  
			 THEN t.S1
			 ELSE 0 
			 END
		)                                                 as BSTK_S1_USD                --B股美元毛佣金
   ,SUM(CASE WHEN t.BS_DRCT = 1 
			 AND  t.SEC_CL_CD IN ('063')                      				  
			 THEN t.S1
			 ELSE 0 
			 END
		) 		                                          as BSTK_BUYIN_S1_HKD          --B股港币买入毛佣金
   ,SUM(CASE WHEN t.BS_DRCT = 2 
			 AND  t.SEC_CL_CD IN ('063')                      				  
			 THEN t.S1
			 ELSE 0 
			 END
	   )                                                  as BSTK_SELL_S1_HKD           --B股港币卖出毛佣金
   ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			 AND  t.SEC_CL_CD IN ('063')                      				  
			 THEN t.S1
			 ELSE 0 
			 END
		)                                                 as BSTK_S1_HKD                --B股港币毛佣金
   ,SUM(CASE WHEN t.BS_DRCT = 1 
			 AND  t.SEC_CL_CD IN ('004')                      				  
			 THEN t.S1
			 ELSE 0 
			 END
		)                                                 as GEM_BUYIN_S1               --创业板买入毛佣金
   ,SUM(CASE WHEN t.BS_DRCT = 2 
			 AND  t.SEC_CL_CD IN ('004')                      				  
			 THEN t.S1
			 ELSE 0 
			 END
	    )                                                 as GEM_SELL_S1                --创业板卖出毛佣金
   ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			 AND  t.SEC_CL_CD IN ('004')                      				  
			 THEN t.S1
			 ELSE 0 
			 END
	   )                                                   as GEM_S1                     --创业板毛佣金
   ,SUM(CAST(CASE WHEN t.BS_DRCT = 1
			 AND  t.SEC_CL_CD IN ('006','007')
			 AND  t.BZDM IS NOT NULL
		     THEN t.S1*t.ZHHL
		     WHEN t.BS_DRCT = 1
			 AND  t.SEC_CL_CD IN ('006','007')
			 AND  t.BZDM IS  NULL
			 THEN t.S1
			 ELSE 0 
			 END as DECIMAL(38,2))
		)                                                   as OLD_T3BOD_BUYIN_S1         --老三板买入毛佣金
   ,SUM(CAST(CASE WHEN t.BS_DRCT = 2
			 AND  t.SEC_CL_CD IN ('006','007')
			 AND  t.BZDM IS NOT NULL
			 THEN t.S1*t.ZHHL
			 WHEN t.BS_DRCT = 2
			 AND  t.SEC_CL_CD IN ('006','007')
			 AND  t.BZDM IS  NULL
			 THEN t.S1
			 ELSE 0 
			 END as DECIMAL(38,2))
		)                                                    as OLD_T3BOD_SELL_S1          --老三板卖出毛佣金
  ,SUM(CAST(CASE WHEN t.BS_DRCT IN (1,2)
			AND  t.SEC_CL_CD IN ('006','007')
			AND  t.BZDM IS NOT NULL
			THEN t.S1*t.ZHHL
			WHEN t.BS_DRCT IN (1,2)
			AND  t.SEC_CL_CD IN ('006','007')
		    AND  t.BZDM IS  NULL
			THEN t.S1
			ELSE 0 
			END as DECIMAL(38,2))
		) 		                                              as OLD_T3BOD_S1               --老三板毛佣金
  ,SUM(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD IN ('007')                      				  
			THEN t.S1
			ELSE 0 
			END
	  )		                                                  as OLD_T3BOD_BUYIN_S1_USD     --老三板美元买入毛佣金
  ,SUM(CASE WHEN t.BS_DRCT = 2 
			AND  t.SEC_CL_CD IN ('007')                      				  
			THEN t.S1
			ELSE 0 
			END
	  )                                                       as OLD_T3BOD_SELL_S1_USD      --老三板美元卖出毛佣金
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			AND  t.SEC_CL_CD IN ('007')                      				  
			THEN t.S1
			ELSE 0 
			END
	  ) 		                                               as OLD_T3BOD_S1_USD           --老三板美元毛佣金
  ,SUM(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD IN ('008')                      				  
			THEN t.S1
			ELSE 0 
			END
	  )	                                                       as NEW_T3BOD_BUYIN_S1         --新三板买入毛佣金
  ,SUM(CASE WHEN t.BS_DRCT = 2
			AND  t.SEC_CL_CD IN ('008')                      				  
			THEN t.S1
			ELSE 0 
			END
	  )                                                        as NEW_T3BOD_SELL_S1          --新三板卖出毛佣金
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			AND  t.SEC_CL_CD IN ('008')                      				  
			THEN t.S1
			ELSE 0 
			END
	  )                                                        as NEW_T3BOD_S1               --新三板毛佣金
  ,SUM(CASE WHEN t.BS_DRCT = 4
			AND  t.SEC_CL_CD IN ('013')                      				  
			THEN t.S1
			ELSE 0 
			END
	  ) 			                                           as QOT_REPO_MRGNS_S1          --报价回购融券毛佣金
  ,SUM(CASE WHEN t.BS_DRCT = 4
			AND  t.SEC_CL_CD IN ('009','010','011','014')                      				  
			THEN t.S1
			ELSE 0 
			END
	  ) 			                                           as ORDI_REPO_MRGNS_S1         --普通回购融券毛佣金
  ,SUM(CASE WHEN t.BS_DRCT = 3
			AND  t.SEC_CL_CD IN ('009','010','011','014')                      				  
			THEN t.S1
			ELSE 0 
			END
	  )			                                               as ORDI_REPO_MRGNC_S1         --普通回购融资金额
  ,SUM(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD IN ('015','016')                      				  
			THEN t.S1
			ELSE 0 
			END
	 )    			                                           as HK_STK_BUYIN_S1            --港股买入毛佣金
  ,SUM(CASE WHEN t.BS_DRCT = 2
			AND  t.SEC_CL_CD IN ('015','016')                      				  
			THEN t.S1
			ELSE 0 
			END
	 )  			                                           as HK_STK_SELL_S1             --港股卖出毛佣金
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			AND  t.SEC_CL_CD IN ('015','016')                      				  
			THEN t.S1
			ELSE 0 
			END
	  )			                                               as HK_STK_S1                  --港股毛佣金
  ,SUM(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			THEN t.S1
			ELSE 0 
			END
	  )			                                              as BOND_BUYIN_S1              --债券买入毛佣金
  ,SUM(CASE WHEN t.BS_DRCT = 2
			AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			THEN t.S1
			ELSE 0 
			END
		  )			                                          as BOND_SELL_S1               --债券卖出毛佣金
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			THEN t.S1
			ELSE 0 
			END
	 )				                                          as BOND_S1                    --债券毛佣金
  ,SUM(CASE WHEN (t.BS_DRCT = 1 OR t.ODR_CGY IN (80,83))
			AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			THEN t.S1
			ELSE 0 
			END
	  )				                                          as EXG_FND_BUYIN_S1           --场内基金买入毛佣金
    ,SUM(CASE WHEN t.BS_DRCT = 2
			AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			THEN t.S1
			ELSE 0 
			END
	  )			                                              as EXG_FND_SELL_S1            --场内基金卖出毛佣金
 ,SUM(CASE WHEN (t.BS_DRCT IN (1,2) OR t.ODR_CGY IN (80,83))
		   AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
		   THEN t.S1
		   ELSE 0 
		   END
	  )			                                              as EXG_FND_S1                 --场内基金毛佣金
      FROM          DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP  		      t	
    GROUP BY      CUST_NO,EXG,ACCNT_CGY	;	
--------  
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP4;
 CREATE TABLE  DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP4
 as  SELECT          t.CUST_NO
                  -- ,t.BRH_NO
                   ,t.EXG 
                   ,t.ACCNT_CGY
 ,SUM(CASE WHEN t.BS_DRCT = 1 
		   AND  t.SEC_CL_CD IN ('001','002','003')                      				  
		   THEN t.S1-t.S11-t.S12
		   ELSE 0 
		   END
	)                                                         as ASTK_BUYIN_NET_S1              --A股买入净佣金
  ,SUM(CASE WHEN t.BS_DRCT = 2  
			AND  t.SEC_CL_CD IN ('001','002','003')				 
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	   )                                                      as ASTK_SELL_NET_S1               --A股卖出净佣金
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			AND  t.SEC_CL_CD IN ('001','002','003')				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )                                                       as ASTK_NET_S1                    --A股净佣金
  ,SUM(CAST(CASE WHEN t.BS_DRCT = 1 
			AND  t.SEC_CL_CD IN ('005','063')
			AND  t.BZDM IS NOT NULL
			THEN (t.S1-t.S11-t.S12)*t.ZHHL
			ELSE 0 
			END as DECIMAL(38,2))
		)	                                                  as BSTK_BUYIN_NET_S1_RMB          --B股买入净佣金
  ,SUM(CAST(CASE WHEN t.BS_DRCT = 2 
			AND  t.SEC_CL_CD IN ('005','063')
			AND  t.BZDM IS NOT NULL
			THEN (t.S1-t.S11-t.S12)*t.ZHHL
			ELSE 0 
			END as DECIMAL(38,2))
	  )                                                       as BSTK_SELL_NET_S1_RMB           --B股卖出净佣金
  ,SUM(CAST(CASE WHEN t.BS_DRCT IN (1,2) 
			AND  t.SEC_CL_CD IN ('005','063')
			AND  t.BZDM IS NOT NULL
			THEN (t.S1-t.S11-t.S12)*t.ZHHL
			ELSE 0 
			END as DECIMAL(38,2))
	   )                                                      as BSTK_NET_S1_RMB                --B股净佣金
 ,SUM(CASE WHEN t.BS_DRCT = 1 
		   AND  t.SEC_CL_CD IN ('005')                      				  
		   THEN t.S1-t.S11-t.S12
		   ELSE 0 
		   END
	 )			                                              as BSTK_BUYIN_NET_S1_USD          --B股美元买入净佣金
  ,SUM(CASE WHEN t.BS_DRCT = 2 
			AND  t.SEC_CL_CD IN ('005')                      				  
		    THEN t.S1-t.S11-t.S12
		    ELSE 0 
			END
	   )                                                      as BSTK_SELL_NET_S1_USD           --B股美元卖出净佣金
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			AND  t.SEC_CL_CD IN ('005')                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )                                                        as BSTK_NET_S1_USD                --B股美元净佣金
  ,SUM(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD IN ('063')                      				  
		    THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  ) 		                                               as BSTK_BUYIN_NET_S1_HKD          --B股港币买入净佣金
  ,SUM(CASE WHEN t.BS_DRCT = 2 
			AND  t.SEC_CL_CD IN ('063')                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	   )                                                       as BSTK_SELL_NET_S1_HKD           --B股港币卖出净佣金
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			AND  t.SEC_CL_CD IN ('063')                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )                                                        as BSTK_NET_S1_HKD                --B股港币净佣金
  ,SUM(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD IN ('004')                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )                                                        as GEM_BUYIN_NET_S1               --创业板买入净佣金
  ,SUM(CASE WHEN t.BS_DRCT = 2 
			AND  t.SEC_CL_CD IN ('004')                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )                                                         as GEM_SELL_NET_S1                --创业板卖出净佣金
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
		    AND  t.SEC_CL_CD IN ('004')                      				  
		    THEN t.S1-t.S11-t.S12
		    ELSE 0 
		    END
	  )                                                         as GEM_NET_S1                     --创业板净佣金
  ,SUM(CAST(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD IN ('006','007')
			AND  t.BZDM IS NOT NULL
			THEN (t.S1-t.S11-t.S12)*t.ZHHL
			WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD IN ('006','007')
			AND  t.BZDM IS  NULL
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END as DECIMAL(38,2))
		)                                                        as OLD_T3BOD_BUYIN_NET_S1         --老三板买入净佣金
   ,SUM(CAST(CASE WHEN t.BS_DRCT = 2
			 AND  t.SEC_CL_CD IN ('006','007')
			 AND  t.BZDM IS NOT NULL
			 THEN (t.S1-t.S11-t.S12)*t.ZHHL
		     WHEN t.BS_DRCT = 2
			 AND  t.SEC_CL_CD IN ('006','007')
			 AND  t.BZDM IS  NULL
		     THEN t.S1-t.S11-t.S12
			 ELSE 0 
			 END as DECIMAL(38,2))
		)                                                         as OLD_T3BOD_SELL_NET_S1          --老三板卖出净佣金
   ,SUM(CAST(CASE WHEN t.BS_DRCT IN (1,2)
			 AND  t.SEC_CL_CD IN ('006','007')
			 AND  t.BZDM IS NOT NULL
			 THEN (t.S1-t.S11-t.S12)*t.ZHHL
		     WHEN t.BS_DRCT IN (1,2)
			 AND  t.SEC_CL_CD IN ('006','007')
			 AND  t.BZDM IS  NULL
			 THEN t.S1-t.S11-t.S12
			 ELSE 0 
			 END as DECIMAL(38,2))
	   ) 		                                                  as OLD_T3BOD_NET_S1               --老三板净佣金
   ,SUM(CASE WHEN t.BS_DRCT = 1
			 AND  t.SEC_CL_CD IN ('007')                      				  
			 THEN t.S1-t.S11-t.S12
			 ELSE 0 
			 END
	   )		                                                  as OLD_T3BOD_BUYIN_NET_S1_USD     --老三板美元买入净佣金
   ,SUM(CASE WHEN t.BS_DRCT = 2
			 AND  t.SEC_CL_CD IN ('007')                      				  
			 THEN t.S1-t.S11-t.S12
			 ELSE 0 
			 END
		)                                                          as OLD_T3BOD_SELL_NET_S1_USD      --老三板美元卖出净佣金
   ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			 AND  t.SEC_CL_CD IN ('007')                      				  
			 THEN t.S1-t.S11-t.S12
			 ELSE 0 
			 END
		) 		                                                   as OLD_T3BOD_NET_S1_USD           --老三板美元净佣金
   ,SUM(CASE WHEN t.BS_DRCT = 1
			 AND  t.SEC_CL_CD IN ('008')                      				  
			 THEN t.S1-t.S11-t.S12
			 ELSE 0 
			 END
	   )	                                                       as NEW_T3BOD_BUYIN_NET_S1         --新三板买入净佣金
   ,SUM(CASE WHEN t.BS_DRCT = 2
			 AND  t.SEC_CL_CD IN ('008')                      				  
			 THEN t.S1-t.S11-t.S12
			 ELSE 0 
			 END
	   )                                                           as NEW_T3BOD_SELL_NET_S1          --新三板卖出净佣金
   ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			 AND  t.SEC_CL_CD IN ('008')                      				  
			 THEN t.S1-t.S11-t.S12
			 ELSE 0 
			 END
		)                                                          as NEW_T3BOD_NET_S1               --新三板净佣金
   ,SUM(CASE WHEN t.BS_DRCT = 4
			 AND  t.SEC_CL_CD IN ('013')                      				  
			 THEN t.S1-t.S11-t.S12
			 ELSE 0 
			 END
		) 			                                               as QOT_REPO_MRGNS_NET_S1          --报价回购融券净佣金
  ,SUM(CASE WHEN t.BS_DRCT = 4
			AND  t.SEC_CL_CD IN ('009','010','011','014')                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	 ) 			                                                   as ORDI_REPO_MRGNS_NET_S1         --普通回购融券净佣金
  ,SUM(CASE WHEN t.BS_DRCT = 3
			AND  t.SEC_CL_CD IN ('009','010','011','014')                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )			                                                   as ORDI_REPO_MRGNC_NET_S1         --普通回购融额净佣金
  ,SUM(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD IN ('015','016')                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )    			                                               as HK_STK_BUYIN_NET_S1            --港股买入净佣金
  ,SUM(CASE WHEN t.BS_DRCT = 2
			AND  t.SEC_CL_CD IN ('015','016')                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )  			                                               as HK_STK_SELL_NET_S1             --港股卖出净佣金
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			AND  t.SEC_CL_CD IN ('015','016')                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )			                                                   as HK_STK_NET_S1                  --港股净佣金
  ,SUM(CASE WHEN t.BS_DRCT = 1 
			AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )			                                                  as BOND_BUYIN_NET_S1              --债券买入净佣金
  ,SUM(CASE WHEN t.BS_DRCT = 2
			AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )			                                                  as BOND_SELL_NET_S1               --债券卖出净佣金
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2)  
			AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )				                                              as BOND_NET_S1                    --债券净佣金
 ,SUM(CASE WHEN (t.BS_DRCT = 1 OR t.ODR_CGY IN (80,83))
		   AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
		   THEN t.S1-t.S11-t.S12
		   ELSE 0 
		   END
     )				                                              as EXG_FND_BUYIN_NET_S1           --场内基金买入净佣金
 ,SUM(CASE WHEN t.BS_DRCT = 2
		   AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
		   THEN t.S1-t.S11-t.S12
		   ELSE 0 
		   END
	 )			                                                  as EXG_FND_SELL_NET_S1            --场内基金卖出净佣金
  ,SUM(CASE WHEN (t.BS_DRCT IN (1,2) OR t.ODR_CGY IN (80,83))
			AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			THEN t.S1-t.S11-t.S12
			ELSE 0 
			END
	  )			                                                  as EXG_FND_NET_S1                 --场内基金净佣金
   FROM          DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP  		      t	
    GROUP BY      CUST_NO,EXG,ACCNT_CGY	;
----------------	
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP5;
 CREATE TABLE  DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP5
 as  SELECT          t.CUST_NO
                  -- ,t.BRH_NO
                   ,t.EXG 
                   ,t.ACCNT_CGY

  ,SUM(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD IN ('001','002','003')                      				  
			THEN 1
			ELSE 0 
			END
	  )                                                           as ASTK_BUYIN_MTCH_ITMS              --A股买入成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 2 
			AND  t.SEC_CL_CD IN ('001','002','003')				 
			THEN 1
			ELSE 0 
			END
	 )                                                            as ASTK_SELL_MTCH_ITMS               --A股卖出成交笔数
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			AND  t.SEC_CL_CD IN ('001','002','003')				  
			THEN 1
			ELSE 0 
			END
	   )                                                          as ASTK_MTCH_ITMS                    --A股成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 1 
			AND  t.SEC_CL_CD IN ('005','063')
			THEN 1
			ELSE 0 
			END
	  )	                                                          as BSTK_BUYIN_MTCH_ITMS          --B股买入成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 2 
			AND  t.SEC_CL_CD IN ('005','063')			          
			THEN 1
			ELSE 0 
			END
	  )                                                           as BSTK_SELL_MTCH_ITMS           --B股卖出成交笔数
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			AND  t.SEC_CL_CD IN ('005','063')			         
			THEN 1
			ELSE 0 
			END
	  )                                                           as BSTK_MTCH_ITMS                --B股成交笔数	
  ,SUM(CASE WHEN t.BS_DRCT = 1 
			AND  t.SEC_CL_CD IN ('004')                      				  
			THEN 1
			ELSE 0 
			END
	  )                                                           as GEM_BUYIN_MTCH_ITMS               --创业板买入成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 2
			AND  t.SEC_CL_CD IN ('004')                      				  
			THEN 1
			ELSE 0 
			END
	  )                                                           as GEM_SELL_MTCH_ITMS                --创业板卖出成交笔数
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2) 
			AND  t.SEC_CL_CD IN ('004')                      				  
			THEN 1
			ELSE 0 
			END
	  )                                                           as GEM_MTCH_ITMS                     --创业板成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD IN ('006','007')
			THEN 1
			ELSE 0 
			END
	  )                                                            as OLD_T3BOD_BUYIN_MTCH_ITMS         --老三板买入成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 2
			AND  t.SEC_CL_CD IN ('006','007')
			THEN 1
			ELSE 0 
		    END
	  )                                                            as OLD_T3BOD_SELL_MTCH_ITMS          --老三板卖出成交笔数
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			AND  t.SEC_CL_CD IN ('006','007')
			THEN 1
			ELSE 0 
			END
	  ) 		                                                   as OLD_T3BOD_MTCH_ITMS               --老三板成交笔数		
  ,SUM(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD IN ('008')                      				  
			THEN 1
			ELSE 0 
			END
	   )	                                                       as NEW_T3BOD_BUYIN_MTCH_ITMS         --新三板买入成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 2
			AND  t.SEC_CL_CD IN ('008')                      				  
			THEN 1
			ELSE 0 
			END
	  )                                                            as NEW_T3BOD_SELL_MTCH_ITMS          --新三板卖出成交笔数
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
		    AND  t.SEC_CL_CD IN ('008')                      				  
			THEN 1
			ELSE 0 
		    END
	  )                                                            as NEW_T3BOD_MTCH_ITMS               --新三板成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 4
			AND  t.SEC_CL_CD IN ('013')                      				  
			THEN 1
		    ELSE 0 
		    END
	  ) 			                                              as QOT_REPO_MRGNS_MTCH_ITMS          --报价回购融券成交笔数
 ,SUM(CASE WHEN t.BS_DRCT = 4
		   AND  t.SEC_CL_CD IN ('009','010','011','014')                      				  
		   THEN 1
		   ELSE 0 
		   END
	 ) 			                                                  as ORDI_REPO_MRGNS_MTCH_ITMS         --普通回购融券成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 3
			AND  t.SEC_CL_CD IN ('009','010','011','014')                      				  
			THEN 1
			ELSE 0 
			END
	  )			                                                  as ORDI_REPO_MRGNC_MTCH_ITMS        --普通回购融资金额
  ,SUM(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD IN ('015','016')                      				  
			THEN 1
			ELSE 0 
			END
	  )    		                                                  as HK_STK_BUYIN_MTCH_ITMS            --港股买入成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 2
			AND  t.SEC_CL_CD IN ('015','016')                      				  
			THEN 1
			ELSE 0 
			END
	  )  			                                              as HK_STK_SELL_MTCH_ITMS             --港股卖出成交笔数
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			AND  t.SEC_CL_CD IN ('015','016')                      				  
			THEN 1
			ELSE 0 
			END
	  )			                                                  as HK_STK_MTCH_ITMS                  --港股成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 1
			AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			THEN 1
			ELSE 0 
			END
	 )			                                                  as BOND_BUYIN_MTCH_ITMS              --债券买入成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 2
			AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			THEN 1
			ELSE 0 
			END
	  )			                                                   as BOND_SELL_MTCH_ITMS               --债券卖出成交笔数
  ,SUM(CASE WHEN t.BS_DRCT IN (1,2)
			AND  t.SEC_CL_CD BETWEEN '017' AND '053'                      				  
			THEN 1
			ELSE 0 
			END
	  )				                                               as BOND_MTCH_ITMS                    --债券成交笔数
  ,SUM(CASE WHEN t.ODR_CGY = 83
			AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			THEN 1
			ELSE 0 
			END
	  )	   as EXG_FND_SCRP_MTCH_ITMS       --场内基金认购成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 1 
			AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			THEN 1
			ELSE 0 
			END
	  )				                                               as EXG_FND_BUYIN_MTCH_ITMS           --场内基金买入成交笔数
  ,SUM(CASE WHEN t.BS_DRCT = 2
			AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			THEN 1
			ELSE 0 
			END
	  )			                                                   as EXG_FND_SELL_MTCH_ITMS            --场内基金卖出成交笔数
  ,SUM(CASE WHEN (t.BS_DRCT IN (1,2) OR t.ODR_CGY = 83)
			AND  t.SEC_CL_CD BETWEEN '054' AND '062'                      				  
			THEN 1
			ELSE 0 
			END
	  )			                                                    as EXG_FND_MTCH_ITMS   
  ,SUM(ROUND(CASE WHEN t.BZDM IS NOT NULL
            AND  t.ODR_CGY IN (9,15,4444,6666,8888)
			THEN NVL(t.MTCH_AMT,0)*t.ZHHL
			WHEN t.BZDM IS NULL
            AND  t.ODR_CGY IN (9,15,4444,6666,8888)
			THEN NVL(t.MTCH_AMT,0)
			ELSE 0
			END,2) 
		)                                                          as SEC_TFR_IN_MKTVAL     --证券转入市值  
  ,SUM(ROUND(CASE WHEN t.BZDM IS NOT NULL
                  AND  t.ODR_CGY IN (7,10,5555,7777,9999)
			      THEN t.MTCH_AMT*t.ZHHL
			      WHEN t.BZDM IS NULL
                  AND  t.ODR_CGY IN (7,10,5555,7777,9999)
			      THEN t.MTCH_AMT
			      ELSE 0
			      END,2
			) 
		)                                                          as SEC_TFR_OUT_MKTVAL     --证券转入市值 
  ,SUM(ROUND(CASE WHEN t.BZDM IS NOT NULL
            AND  t.ODR_CGY IN (9,15,4444,6666,8888)
			THEN t.MTCH_AMT*t.ZHHL
			WHEN t.BZDM IS NULL
            AND  t.ODR_CGY IN (9,15,4444,6666,8888)
			THEN t.MTCH_AMT
			WHEN t.BZDM IS NOT NULL
            AND  t.ODR_CGY IN (7,10,5555,7777,9999)
			THEN 0-t.MTCH_AMT*t.ZHHL
			WHEN t.BZDM IS NULL
            AND  t.ODR_CGY IN (7,10,5555,7777,9999)
			THEN 0-t.MTCH_AMT
			ELSE 0
			END,2) 
		)                                                          as SEC_NET_TFR_IN_MKTVAL     --证券净转入市值 
    FROM          DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP  		      t	
    GROUP BY      CUST_NO,EXG,ACCNT_CGY	;

--------------	
--OR SUBSTR(t.SEC_CGY,1,3) = t.SEC_CGY_PFX
-- DROP TABLE  IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP2;
-- CREATE TABLE   DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP2
-- as
-- SELECT             a.CUST_NO
--                    ,SUM(ROUND(CASE WHEN b.BZDM IS NOT NULL AND (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ IN ('10399'))
--                              THEN a.INCM_AMT*b.ZHHL
--							  WHEN b.BZDM IS  NULL AND (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ IN ('10399'))
--							  THEN a.INCM_AMT
--							  ELSE 0
--							  END,2)) as TFR_IN_AMT  --流入
--					,SUM(ROUND(CASE WHEN b.BZDM IS NOT NULL AND (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ IN ('10499'))
--                              THEN a.PAY_AMT*b.ZHHL  --流出
--							  WHEN b.BZDM IS  NULL AND (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ IN ('10499','13028'))
--							  THEN a.PAY_AMT
--							  ELSE 0
--							  END,2)) as TURN_OUT_AMT
--					,SUM(ROUND(CASE WHEN b.BZDM IS NOT NULL AND  a.BIZ_SBJ IN ('10705','10701','10501','10503','10505') AND a.INCM_AMT > 0
--					          THEN a.INCM_AMT*b.ZHHL
--							  WHEN a.BIZ_SBJ IN ('10705','10701','10501','10503','10505') AND a.INCM_AMT > 0
--					          THEN a.INCM_AMT
--							  WHEN b.BZDM IS NOT NULL AND  a.BIZ_SBJ IN ('10705','10701','10501','10503','10505') AND a.PAY_AMT > 0
--					          THEN 0-a.PAY_AMT*b.ZHHL
--							  WHEN a.BIZ_SBJ IN ('10705','10701','10501','10503','10505') AND a.PAY_AMT > 0
--					          THEN 0-a.PAY_AMT
--							  ELSE 0
--							  END,2))    as INT_YLD                    --利息收益
--					 ,SUM(ROUND(CASE WHEN b.BZDM IS NOT NULL AND (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ IN ('10399'))
--                              THEN a.INCM_AMT*b.ZHHL
--							  WHEN b.BZDM IS  NULL AND (SUBSTR(a.BIZ_SBJ,1,3) = '101' OR a.BIZ_SBJ IN ('10399'))
--							  THEN a.INCM_AMT
--							  WHEN b.BZDM IS NOT NULL AND (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ IN ('10499'))
--                              THEN 0-a.PAY_AMT*b.ZHHL  
--							  WHEN b.BZDM IS  NULL AND (SUBSTR(a.BIZ_SBJ,1,3) = '102' OR a.BIZ_SBJ IN ('10499','13028'))
--							  THEN 0-a.PAY_AMT
--							  ELSE 0
--							  END,2)) as NET_TFR_IN_AMT  --净流入
-- FROM       DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS   a
-- LEFT JOIN  EDW_PROD.T_EDW_T99_HLZH      b
-- ON         a.CCY_CD = b.BZDM
-- AND        a.BUS_DATE = b.BUS_DATE
-- WHERE      a.BUS_DATE = %d{yyyyMMdd} 
-- AND        SUBSTR(a.BIZ_SBJ,1,3) IN ('101','102','105','107','103','104','130')
-- GROUP BY   a.CUST_NO;
--




------插入数据
  INSERT OVERWRITE DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY
(
                 CUST_NO                          --客户号                 
                ,BRH_NO                           --营业部编号         
                ,EXG                              --交易所
                ,CUST_CGY				          --客户类别
                ,ASTK_BUYIN_MTCH_AMT              --A股买入成交金额
                ,ASTK_SELL_MTCH_AMT               --A股卖出成交金额
                ,ASTK_MTCH_AMT                    --A股成交金额
                ,BSTK_BUYIN_MTCH_AMT_RMB          --B股买入成交金额
                ,BSTK_SELL_MTCH_AMT_RMB           --B股卖出成交金额
                ,BSTK_MTCH_AMT_RMB                --B股成交金额
                ,BSTK_BUYIN_MTCH_AMT_USD          --B股美元买入成交金额
                ,BSTK_SELL_MTCH_AMT_USD           --B股美元卖出成交金额
                ,BSTK_MTCH_AMT_USD                --B股美元成交金额
                ,BSTK_BUYIN_MTCH_AMT_HKD          --B股港币买入成交金额
                ,BSTK_SELL_MTCH_AMT_HKD           --B股港币卖出成交金额
                ,BSTK_MTCH_AMT_HKD                --B股港币成交金额
                ,GEM_BUYIN_MTCH_AMT               --创业板买入成交金额
                ,GEM_SELL_MTCH_AMT                --创业板卖出成交金额
                ,GEM_MTCH_AMT                     --创业板成交金额
                ,OLD_T3BOD_BUYIN_MTCH_AMT         --老三板买入成交金额
                ,OLD_T3BOD_SELL_MTCH_AMT          --老三板卖出成交金额
                ,OLD_T3BOD_MTCH_AMT               --老三板成交金额
                ,OLD_T3BOD_BUYIN_MTCH_AMT_USD     --老三板美元买入成交金额
                ,OLD_T3BOD_SELL_MTCH_AMT_USD      --老三板美元卖出成交金额
                ,OLD_T3BOD_MTCH_AMT_USD           --老三板美元成交金额
                ,NEW_T3BOD_BUYIN_MTCH_AMT         --新三板买入成交金额
                ,NEW_T3BOD_SELL_MTCH_AMT          --新三板卖出成交金额
                ,NEW_T3BOD_MTCH_AMT               --新三板成交金额
                ,QOT_REPO_MRGNS_AMT               --报价回购融券金额
                ,ORDI_REPO_MRGNS_AMT              --普通回购融券金额
                ,ORDI_REPO_MRGNC_AMT              --普通回购融资金额
                ,HK_STK_BUYIN_MTCH_AMT            --港股买入成交金额
                ,HK_STK_SELL_MTCH_AMT             --港股卖出成交金额
                ,HK_STK_MTCH_AMT                  --港股成交金额
                ,BOND_BUYIN_MTCH_AMT              --债券买入成交金额
                ,BOND_SELL_MTCH_AMT               --债券卖出成交金额
                ,BOND_MTCH_AMT                    --债券成交金额
                ,EXG_FND_SCRP_MTCH_AMT            --场内基金认购成交金额				
                ,EXG_FND_BUYIN_MTCH_AMT           --场内基金买入成交金额
                ,EXG_FND_SELL_MTCH_AMT            --场内基金卖出成交金额
                ,EXG_FND_MTCH_AMT                 --场内基金成交金额
				,ASTK_BUYIN_MTCH_QTY              --A股买入成交数量
                ,ASTK_SELL_MTCH_QTY               --A股卖出成交数量
                ,ASTK_MTCH_QTY                    --A股成交数量
                ,BSTK_BUYIN_MTCH_QTY              --B股买入成交数量
                ,BSTK_SELL_MTCH_QTY               --B股卖出成交数量
                ,BSTK_MTCH_QTY                    --B股成交数量	
                ,GEM_BUYIN_MTCH_QTY               --创业板买入成交数量
                ,GEM_SELL_MTCH_QTY                --创业板卖出成交数量
                ,GEM_MTCH_QTY                     --创业板成交数量
                ,OLD_T3BOD_BUYIN_MTCH_QTY         --老三板买入成交数量
                ,OLD_T3BOD_SELL_MTCH_QTY          --老三板卖出成交数量
                ,OLD_T3BOD_MTCH_QTY               --老三板成交数量		
                ,NEW_T3BOD_BUYIN_MTCH_QTY         --新三板买入成交数量
                ,NEW_T3BOD_SELL_MTCH_QTY          --新三板卖出成交数量
                ,NEW_T3BOD_MTCH_QTY               --新三板成交数量
                ,QOT_REPO_MRGNS_MTCH_QTY          --报价回购融券成交数量
                ,ORDI_REPO_MRGNS_MTCH_QTY         --普通回购融券成交数量
                ,ORDI_REPO_MRGNC_MTCH_QTY         --普通回购融资成交数量
                ,HK_STK_BUYIN_MTCH_QTY            --港股买入成交数量
                ,HK_STK_SELL_MTCH_QTY             --港股卖出成交数量
                ,HK_STK_MTCH_QTY                  --港股成交数量
                ,BOND_BUYIN_MTCH_QTY              --债券买入成交数量
                ,BOND_SELL_MTCH_QTY               --债券卖出成交数量
                ,BOND_MTCH_QTY                    --债券成交数量
				,EXG_FND_SCRP_MTCH_QTY            --场内基金认购数量
                ,EXG_FND_BUYIN_MTCH_QTY           --场内基金买入成交数量
                ,EXG_FND_SELL_MTCH_QTY            --场内基金卖出成交数量
                ,EXG_FND_MTCH_QTY                 --场内基金成交数量                             
			    ,ASTK_BUYIN_S1                    --A股买入毛佣金
                ,ASTK_SELL_S1                     --A股卖出毛佣金
                ,ASTK_S1                          --A股毛佣金
                ,BSTK_BUYIN_S1_RMB                --B股买入毛佣金
                ,BSTK_SELL_S1_RMB                 --B股卖出毛佣金
                ,BSTK_S1_RMB                      --B股毛佣金
                ,BSTK_BUYIN_S1_USD                --B股美元买入毛佣金
                ,BSTK_SELL_S1_USD                 --B股美元卖出毛佣金
                ,BSTK_S1_USD                      --B股美元毛佣金
                ,BSTK_BUYIN_S1_HKD                --B股港币买入毛佣金
                ,BSTK_SELL_S1_HKD                 --B股港币卖出毛佣金
                ,BSTK_S1_HKD                      --B股港币毛佣金
                ,GEM_BUYIN_S1                     --创业板买入毛佣金
                ,GEM_SELL_S1                      --创业板卖出毛佣金
                ,GEM_S1                           --创业板毛佣金
                ,OLD_T3BOD_BUYIN_S1               --老三板买入毛佣金
                ,OLD_T3BOD_SELL_S1                --老三板卖出毛佣金
                ,OLD_T3BOD_S1                     --老三板毛佣金
                ,OLD_T3BOD_BUYIN_S1_USD           --老三板美元买入毛佣金
                ,OLD_T3BOD_SELL_S1_USD            --老三板美元卖出毛佣金
                ,OLD_T3BOD_S1_USD                 --老三板美元毛佣金
                ,NEW_T3BOD_BUYIN_S1               --新三板买入毛佣金
                ,NEW_T3BOD_SELL_S1                --新三板卖出毛佣金
                ,NEW_T3BOD_S1                     --新三板毛佣金
                ,QOT_REPO_MRGNS_S1                --报价回购融券毛佣金
                ,ORDI_REPO_MRGNS_S1               --普通回购融券毛佣金
                ,ORDI_REPO_MRGNC_S1               --普通回购融资毛佣金
                ,HK_STK_BUYIN_S1                  --港股买入毛佣金
                ,HK_STK_SELL_S1                   --港股卖出毛佣金
                ,HK_STK_S1                        --港股毛佣金
                ,BOND_BUYIN_S1                    --债券买入毛佣金
                ,BOND_SELL_S1                     --债券卖出毛佣金
                ,BOND_S1                          --债券毛佣金
                ,EXG_FND_BUYIN_S1                 --场内基金买入毛佣金
                ,EXG_FND_SELL_S1                  --场内基金卖出毛佣金
                ,EXG_FND_S1                       --场内基金毛佣金
                ,ASTK_BUYIN_NET_S1                --A股买入净佣金
                ,ASTK_SELL_NET_S1                 --A股卖出净佣金
                ,ASTK_NET_S1                      --A股净佣金
                ,BSTK_BUYIN_NET_S1_RMB            --B股买入净佣金
                ,BSTK_SELL_NET_S1_RMB             --B股卖出净佣金
                ,BSTK_NET_S1_RMB                  --B股净佣金
                ,BSTK_BUYIN_NET_S1_USD            --B股美元买入净佣金
                ,BSTK_SELL_NET_S1_USD             --B股美元卖出净佣金
                ,BSTK_NET_S1_USD                  --B股美元净佣金
                ,BSTK_BUYIN_NET_S1_HKD            --B股港币买入净佣金
                ,BSTK_SELL_NET_S1_HKD             --B股港币卖出净佣金
                ,BSTK_NET_S1_HKD                  --B股港币净佣金
                ,GEM_BUYIN_NET_S1                 --创业板买入净佣金
                ,GEM_SELL_NET_S1                  --创业板卖出净佣金
                ,GEM_NET_S1                       --创业板净佣金
                ,OLD_T3BOD_BUYIN_NET_S1           --老三板买入净佣金
                ,OLD_T3BOD_SELL_NET_S1            --老三板卖出净佣金
                ,OLD_T3BOD_NET_S1                 --老三板净佣金
                ,OLD_T3BOD_BUYIN_NET_S1_USD       --老三板美元买入净佣金
                ,OLD_T3BOD_SELL_NET_S1_USD        --老三板美元卖出净佣金
                ,OLD_T3BOD_NET_S1_USD             --老三板美元净佣金
                ,NEW_T3BOD_BUYIN_NET_S1           --新三板买入净佣金
                ,NEW_T3BOD_SELL_NET_S1            --新三板卖出净佣金
                ,NEW_T3BOD_NET_S1                 --新三板净佣金
                ,QOT_REPO_MRGNS_NET_S1            --报价回购融券净佣金
                ,ORDI_REPO_MRGNS_NET_S1           --普通回购融券净佣金
                ,ORDI_REPO_MRGNC_NET_S1           --普通回购融额净佣金
                ,HK_STK_BUYIN_NET_S1              --港股买入净佣金
                ,HK_STK_SELL_NET_S1               --港股卖出净佣金
                ,HK_STK_NET_S1                    --港股净佣金
                ,BOND_BUYIN_NET_S1                --债券买入净佣金
                ,BOND_SELL_NET_S1                 --债券卖出净佣金
                ,BOND_NET_S1                      --债券净佣金
                ,EXG_FND_BUYIN_NET_S1             --场内基金买入净佣金
                ,EXG_FND_SELL_NET_S1              --场内基金卖出净佣金
                ,EXG_FND_NET_S1                   --场内基金净佣金               
			    ,ASTK_BUYIN_MTCH_ITMS             --A股买入成交笔数
                ,ASTK_SELL_MTCH_ITMS              --A股卖出成交笔数
                ,ASTK_MTCH_ITMS                   --A股成交笔数
                ,BSTK_BUYIN_MTCH_ITMS             --B股买入成交笔数
                ,BSTK_SELL_MTCH_ITMS              --B股卖出成交笔数
                ,BSTK_MTCH_ITMS                   --B股成交笔数	
                ,GEM_BUYIN_MTCH_ITMS              --创业板买入成交笔数
                ,GEM_SELL_MTCH_ITMS               --创业板卖出成交笔数
                ,GEM_MTCH_ITMS                    --创业板成交笔数
                ,OLD_T3BOD_BUYIN_MTCH_ITMS        --老三板买入成交笔数
                ,OLD_T3BOD_SELL_MTCH_ITMS         --老三板卖出成交笔数
                ,OLD_T3BOD_MTCH_ITMS              --老三板成交笔数		
                ,NEW_T3BOD_BUYIN_MTCH_ITMS        --新三板买入成交笔数
                ,NEW_T3BOD_SELL_MTCH_ITMS         --新三板卖出成交笔数
                ,NEW_T3BOD_MTCH_ITMS              --新三板成交笔数
                ,QOT_REPO_MRGNS_MTCH_ITMS         --报价回购融券成交笔数
                ,ORDI_REPO_MRGNS_MTCH_ITMS        --普通回购融券成交笔数
                ,ORDI_REPO_MRGNC_MTCH_ITMS        --普通回购融资成交笔数
                ,HK_STK_BUYIN_MTCH_ITMS           --港股买入成交笔数
                ,HK_STK_SELL_MTCH_ITMS            --港股卖出成交笔数
                ,HK_STK_MTCH_ITMS                 --港股成交笔数
                ,BOND_BUYIN_MTCH_ITMS             --债券买入成交笔数
                ,BOND_SELL_MTCH_ITMS              --债券卖出成交笔数
                ,BOND_MTCH_ITMS                   --债券成交笔数
				,EXG_FND_SCRP_MTCH_ITMS           --场内基金认购成交笔数
                ,EXG_FND_BUYIN_MTCH_ITMS          --场内基金买入成交笔数
                ,EXG_FND_SELL_MTCH_ITMS           --场内基金卖出成交笔数
                ,EXG_FND_MTCH_ITMS                --场内基金成交笔数
                ,SEC_TFR_IN_MKTVAL                --证券转入市值  
                ,SEC_TFR_OUT_MKTVAL               --证券转入市值 
                ,SEC_NET_TFR_IN_MKTVAL            --证券净转入市值 	
                ,ACCNT_CGY	                      --账户类别				
 ) partition(BUS_DATE = %d{yyyyMMdd})
 SELECT          COALESCE(a1.CUST_NO,a2.CUST_NO,a3.CUST_NO,a4.CUST_NO,a5.CUST_NO) as CUST_NO                          --客户号                 
                ,t.BRH_NO                           --营业部编号         
                ,COALESCE(a1.EXG,a2.EXG,a3.EXG,a4.EXG,a5.EXG) as EXG                              --交易所
                ,t.CUST_CGY				          --客户类别
                ,NVL(a1.ASTK_BUYIN_MTCH_AMT,0)              --A股买入成交金额
                ,NVL(a1.ASTK_SELL_MTCH_AMT,0)               --A股卖出成交金额
                ,NVL(a1.ASTK_MTCH_AMT,0)                    --A股成交金额
                ,NVL(a1.BSTK_BUYIN_MTCH_AMT_RMB,0)          --B股买入成交金额
                ,NVL(a1.BSTK_SELL_MTCH_AMT_RMB,0)           --B股卖出成交金额
                ,NVL(a1.BSTK_MTCH_AMT_RMB,0)                --B股成交金额
                ,NVL(a1.BSTK_BUYIN_MTCH_AMT_USD,0)          --B股美元买入成交金额
                ,NVL(a1.BSTK_SELL_MTCH_AMT_USD,0)           --B股美元卖出成交金额
                ,NVL(a1.BSTK_MTCH_AMT_USD,0)                --B股美元成交金额
                ,NVL(a1.BSTK_BUYIN_MTCH_AMT_HKD,0)          --B股港币买入成交金额
                ,NVL(a1.BSTK_SELL_MTCH_AMT_HKD,0)           --B股港币卖出成交金额
                ,NVL(a1.BSTK_MTCH_AMT_HKD,0)                --B股港币成交金额
                ,NVL(a1.GEM_BUYIN_MTCH_AMT,0)               --创业板买入成交金额
                ,NVL(a1.GEM_SELL_MTCH_AMT,0)                --创业板卖出成交金额
                ,NVL(a1.GEM_MTCH_AMT,0)                     --创业板成交金额
                ,NVL(a1.OLD_T3BOD_BUYIN_MTCH_AMT,0)         --老三板买入成交金额
                ,NVL(a1.OLD_T3BOD_SELL_MTCH_AMT,0)          --老三板卖出成交金额
                ,NVL(a1.OLD_T3BOD_MTCH_AMT,0)               --老三板成交金额
                ,NVL(a1.OLD_T3BOD_BUYIN_MTCH_AMT_USD,0)     --老三板美元买入成交金额
                ,NVL(a1.OLD_T3BOD_SELL_MTCH_AMT_USD,0)      --老三板美元卖出成交金额
                ,NVL(a1.OLD_T3BOD_MTCH_AMT_USD,0)           --老三板美元成交金额
                ,NVL(a1.NEW_T3BOD_BUYIN_MTCH_AMT,0)         --新三板买入成交金额
                ,NVL(a1.NEW_T3BOD_SELL_MTCH_AMT,0)          --新三板卖出成交金额
                ,NVL(a1.NEW_T3BOD_MTCH_AMT,0)               --新三板成交金额
                ,NVL(a1.QOT_REPO_MRGNS_AMT,0)               --报价回购融券金额
                ,NVL(a1.ORDI_REPO_MRGNS_AMT,0)              --普通回购融券金额
                ,NVL(a1.ORDI_REPO_MRGNC_AMT,0)              --普通回购融资金额
                ,NVL(a1.HK_STK_BUYIN_MTCH_AMT,0)            --港股买入成交金额
                ,NVL(a1.HK_STK_SELL_MTCH_AMT,0)             --港股卖出成交金额
                ,NVL(a1.HK_STK_MTCH_AMT,0)                  --港股成交金额
                ,NVL(a1.BOND_BUYIN_MTCH_AMT,0)              --债券买入成交金额
                ,NVL(a1.BOND_SELL_MTCH_AMT,0)               --债券卖出成交金额
                ,NVL(a1.BOND_MTCH_AMT,0)                    --债券成交金额
                ,NVL(a1.EXG_FND_SCRP_MTCH_AMT,0)            --场内基金认购金额					
                ,NVL(a1.EXG_FND_BUYIN_MTCH_AMT,0)           --场内基金买入成交金额
                ,NVL(a1.EXG_FND_SELL_MTCH_AMT,0)            --场内基金卖出成交金额
                ,NVL(a1.EXG_FND_MTCH_AMT,0)                 --场内基金成交金额
				,NVL(a2.ASTK_BUYIN_MTCH_QTY,0)              --A股买入成交数量
                ,NVL(a2.ASTK_SELL_MTCH_QTY,0)               --A股卖出成交数量
                ,NVL(a2.ASTK_MTCH_QTY,0)                    --A股成交数量
                ,NVL(a2.BSTK_BUYIN_MTCH_QTY,0)              --B股买入成交数量
                ,NVL(a2.BSTK_SELL_MTCH_QTY,0)               --B股卖出成交数量
                ,NVL(a2.BSTK_MTCH_QTY,0)                    --B股成交数量	
                ,NVL(a2.GEM_BUYIN_MTCH_QTY,0)               --创业板买入成交数量
                ,NVL(a2.GEM_SELL_MTCH_QTY,0)                --创业板卖出成交数量
                ,NVL(a2.GEM_MTCH_QTY,0)                     --创业板成交数量
                ,NVL(a2.OLD_T3BOD_BUYIN_MTCH_QTY,0)         --老三板买入成交数量
                ,NVL(a2.OLD_T3BOD_SELL_MTCH_QTY,0)          --老三板卖出成交数量
                ,NVL(a2.OLD_T3BOD_MTCH_QTY,0)               --老三板成交数量		
                ,NVL(a2.NEW_T3BOD_BUYIN_MTCH_QTY,0)         --新三板买入成交数量
                ,NVL(a2.NEW_T3BOD_SELL_MTCH_QTY,0)          --新三板卖出成交数量
                ,NVL(a2.NEW_T3BOD_MTCH_QTY,0)               --新三板成交数量
                ,NVL(a2.QOT_REPO_MRGNS_MTCH_QTY,0)          --报价回购融券成交数量
                ,NVL(a2.ORDI_REPO_MRGNS_MTCH_QTY,0)         --普通回购融券成交数量
                ,NVL(a2.ORDI_REPO_MRGNC_MTCH_QTY,0)         --普通回购融资成交数量
                ,NVL(a2.HK_STK_BUYIN_MTCH_QTY,0)            --港股买入成交数量
                ,NVL(a2.HK_STK_SELL_MTCH_QTY,0)             --港股卖出成交数量
                ,NVL(a2.HK_STK_MTCH_QTY,0)                  --港股成交数量
                ,NVL(a2.BOND_BUYIN_MTCH_QTY,0)              --债券买入成交数量
                ,NVL(a2.BOND_SELL_MTCH_QTY,0)               --债券卖出成交数量
                ,NVL(a2.BOND_MTCH_QTY,0)                    --债券成交数量
				,NVL(a2.EXG_FND_SCRP_MTCH_QTY,0)            --场内基金认购数量
                ,NVL(a2.EXG_FND_BUYIN_MTCH_QTY,0)           --场内基金买入成交数量
                ,NVL(a2.EXG_FND_SELL_MTCH_QTY,0)            --场内基金卖出成交数量
                ,NVL(a2.EXG_FND_MTCH_QTY,0)                 --场内基金成交数量                             
			    ,NVL(a3.ASTK_BUYIN_S1,0)                    --A股买入毛佣金
                ,NVL(a3.ASTK_SELL_S1,0)                     --A股卖出毛佣金
                ,NVL(a3.ASTK_S1,0)                          --A股毛佣金
                ,NVL(a3.BSTK_BUYIN_S1_RMB,0)                --B股买入毛佣金
                ,NVL(a3.BSTK_SELL_S1_RMB,0)                 --B股卖出毛佣金
                ,NVL(a3.BSTK_S1_RMB,0)                      --B股毛佣金
                ,NVL(a3.BSTK_BUYIN_S1_USD,0)                --B股美元买入毛佣金
                ,NVL(a3.BSTK_SELL_S1_USD,0)                 --B股美元卖出毛佣金
                ,NVL(a3.BSTK_S1_USD,0)                      --B股美元毛佣金
                ,NVL(a3.BSTK_BUYIN_S1_HKD,0)                --B股港币买入毛佣金
                ,NVL(a3.BSTK_SELL_S1_HKD,0)                 --B股港币卖出毛佣金
                ,NVL(a3.BSTK_S1_HKD,0)                      --B股港币毛佣金
                ,NVL(a3.GEM_BUYIN_S1,0)                     --创业板买入毛佣金
                ,NVL(a3.GEM_SELL_S1,0)                      --创业板卖出毛佣金
                ,NVL(a3.GEM_S1,0)                           --创业板毛佣金
                ,NVL(a3.OLD_T3BOD_BUYIN_S1,0)               --老三板买入毛佣金
                ,NVL(a3.OLD_T3BOD_SELL_S1,0)                --老三板卖出毛佣金
                ,NVL(a3.OLD_T3BOD_S1,0)                     --老三板毛佣金
                ,NVL(a3.OLD_T3BOD_BUYIN_S1_USD,0)           --老三板美元买入毛佣金
                ,NVL(a3.OLD_T3BOD_SELL_S1_USD,0)            --老三板美元卖出毛佣金
                ,NVL(a3.OLD_T3BOD_S1_USD,0)                 --老三板美元毛佣金
                ,NVL(a3.NEW_T3BOD_BUYIN_S1,0)               --新三板买入毛佣金
                ,NVL(a3.NEW_T3BOD_SELL_S1,0)                --新三板卖出毛佣金
                ,NVL(a3.NEW_T3BOD_S1,0)                     --新三板毛佣金
                ,NVL(a3.QOT_REPO_MRGNS_S1,0)                --报价回购融券毛佣金
                ,NVL(a3.ORDI_REPO_MRGNS_S1,0)               --普通回购融券毛佣金
                ,NVL(a3.ORDI_REPO_MRGNC_S1,0)               --普通回购融资毛佣金
                ,NVL(a3.HK_STK_BUYIN_S1,0)                  --港股买入毛佣金
                ,NVL(a3.HK_STK_SELL_S1,0)                   --港股卖出毛佣金
                ,NVL(a3.HK_STK_S1,0)                        --港股毛佣金
                ,NVL(a3.BOND_BUYIN_S1,0)                    --债券买入毛佣金
                ,NVL(a3.BOND_SELL_S1,0)                     --债券卖出毛佣金
                ,NVL(a3.BOND_S1,0)                          --债券毛佣金
                ,NVL(a3.EXG_FND_BUYIN_S1,0)                 --场内基金买入毛佣金
                ,NVL(a3.EXG_FND_SELL_S1,0)                  --场内基金卖出毛佣金
                ,NVL(a3.EXG_FND_S1,0)                       --场内基金毛佣金
                ,NVL(a4.ASTK_BUYIN_NET_S1,0)                --A股买入净佣金
                ,NVL(a4.ASTK_SELL_NET_S1,0)                 --A股卖出净佣金
                ,NVL(a4.ASTK_NET_S1,0)                      --A股净佣金
                ,NVL(a4.BSTK_BUYIN_NET_S1_RMB,0)            --B股买入净佣金
                ,NVL(a4.BSTK_SELL_NET_S1_RMB,0)             --B股卖出净佣金
                ,NVL(a4.BSTK_NET_S1_RMB,0)                  --B股净佣金
                ,NVL(a4.BSTK_BUYIN_NET_S1_USD,0)            --B股美元买入净佣金
                ,NVL(a4.BSTK_SELL_NET_S1_USD,0)             --B股美元卖出净佣金
                ,NVL(a4.BSTK_NET_S1_USD,0)                  --B股美元净佣金
                ,NVL(a4.BSTK_BUYIN_NET_S1_HKD,0)            --B股港币买入净佣金
                ,NVL(a4.BSTK_SELL_NET_S1_HKD,0)             --B股港币卖出净佣金
                ,NVL(a4.BSTK_NET_S1_HKD,0)                  --B股港币净佣金
                ,NVL(a4.GEM_BUYIN_NET_S1,0)                 --创业板买入净佣金
                ,NVL(a4.GEM_SELL_NET_S1,0)                  --创业板卖出净佣金
                ,NVL(a4.GEM_NET_S1,0)                       --创业板净佣金
                ,NVL(a4.OLD_T3BOD_BUYIN_NET_S1,0)           --老三板买入净佣金
                ,NVL(a4.OLD_T3BOD_SELL_NET_S1,0)            --老三板卖出净佣金
                ,NVL(a4.OLD_T3BOD_NET_S1,0)                 --老三板净佣金
                ,NVL(a4.OLD_T3BOD_BUYIN_NET_S1_USD,0)       --老三板美元买入净佣金
                ,NVL(a4.OLD_T3BOD_SELL_NET_S1_USD,0)        --老三板美元卖出净佣金
                ,NVL(a4.OLD_T3BOD_NET_S1_USD,0)             --老三板美元净佣金
                ,NVL(a4.NEW_T3BOD_BUYIN_NET_S1,0)           --新三板买入净佣金
                ,NVL(a4.NEW_T3BOD_SELL_NET_S1,0)            --新三板卖出净佣金
                ,NVL(a4.NEW_T3BOD_NET_S1,0)                 --新三板净佣金
                ,NVL(a4.QOT_REPO_MRGNS_NET_S1,0)            --报价回购融券净佣金
                ,NVL(a4.ORDI_REPO_MRGNS_NET_S1,0)           --普通回购融券净佣金
                ,NVL(a4.ORDI_REPO_MRGNC_NET_S1,0)           --普通回购融额净佣金
                ,NVL(a4.HK_STK_BUYIN_NET_S1,0)              --港股买入净佣金
                ,NVL(a4.HK_STK_SELL_NET_S1,0)               --港股卖出净佣金
                ,NVL(a4.HK_STK_NET_S1,0)                    --港股净佣金
                ,NVL(a4.BOND_BUYIN_NET_S1,0)                --债券买入净佣金
                ,NVL(a4.BOND_SELL_NET_S1,0)                 --债券卖出净佣金
                ,NVL(a4.BOND_NET_S1,0)                      --债券净佣金
                ,NVL(a4.EXG_FND_BUYIN_NET_S1,0)             --场内基金买入净佣金
                ,NVL(a4.EXG_FND_SELL_NET_S1,0)              --场内基金卖出净佣金
                ,NVL(a4.EXG_FND_NET_S1,0)                   --场内基金净佣金               
			    ,NVL(a5.ASTK_BUYIN_MTCH_ITMS,0)             --A股买入成交笔数
                ,NVL(a5.ASTK_SELL_MTCH_ITMS,0)              --A股卖出成交笔数
                ,NVL(a5.ASTK_MTCH_ITMS,0)                   --A股成交笔数
                ,NVL(a5.BSTK_BUYIN_MTCH_ITMS,0)             --B股买入成交笔数
                ,NVL(a5.BSTK_SELL_MTCH_ITMS,0)              --B股卖出成交笔数
                ,NVL(a5.BSTK_MTCH_ITMS,0)                  --B股成交笔数	
                ,NVL(a5.GEM_BUYIN_MTCH_ITMS,0)              --创业板买入成交笔数
                ,NVL(a5.GEM_SELL_MTCH_ITMS,0)               --创业板卖出成交笔数
                ,NVL(a5.GEM_MTCH_ITMS,0)                    --创业板成交笔数
                ,NVL(a5.OLD_T3BOD_BUYIN_MTCH_ITMS,0)        --老三板买入成交笔数
                ,NVL(a5.OLD_T3BOD_SELL_MTCH_ITMS,0)         --老三板卖出成交笔数
                ,NVL(a5.OLD_T3BOD_MTCH_ITMS,0)              --老三板成交笔数		
                ,NVL(a5.NEW_T3BOD_BUYIN_MTCH_ITMS,0)        --新三板买入成交笔数
                ,NVL(a5.NEW_T3BOD_SELL_MTCH_ITMS,0)         --新三板卖出成交笔数
                ,NVL(a5.NEW_T3BOD_MTCH_ITMS,0)              --新三板成交笔数
                ,NVL(a5.QOT_REPO_MRGNS_MTCH_ITMS,0)         --报价回购融券成交笔数
                ,NVL(a5.ORDI_REPO_MRGNS_MTCH_ITMS,0)        --普通回购融券成交笔数
                ,NVL(a5.ORDI_REPO_MRGNC_MTCH_ITMS,0)        --普通回购融资成交笔数
                ,NVL(a5.HK_STK_BUYIN_MTCH_ITMS,0)           --港股买入成交笔数
                ,NVL(a5.HK_STK_SELL_MTCH_ITMS,0)            --港股卖出成交笔数
                ,NVL(a5.HK_STK_MTCH_ITMS,0)                 --港股成交笔数
                ,NVL(a5.BOND_BUYIN_MTCH_ITMS,0)             --债券买入成交笔数
                ,NVL(a5.BOND_SELL_MTCH_ITMS,0)              --债券卖出成交笔数
                ,NVL(a5.BOND_MTCH_ITMS,0)                   --债券成交笔数			
				,NVL(a5.EXG_FND_SCRP_MTCH_ITMS,0)            --场内基金认购笔数
                ,NVL(a5.EXG_FND_BUYIN_MTCH_ITMS,0)          --场内基金买入成交笔数
                ,NVL(a5.EXG_FND_SELL_MTCH_ITMS,0)           --场内基金卖出成交笔数
                ,NVL(a5.EXG_FND_MTCH_ITMS,0)                --场内基金成交笔数		         
                ,NVL(a5.SEC_TFR_IN_MKTVAL,0)                --证券转入市值  
                ,NVL(a5.SEC_TFR_OUT_MKTVAL,0)               --证券转入市值 
                ,NVL(a5.SEC_NET_TFR_IN_MKTVAL,0)            --证券净转入市值 
				,COALESCE(a1.ACCNT_CGY,a2.ACCNT_CGY,a3.ACCNT_CGY,a4.ACCNT_CGY,a5.ACCNT_CGY) as ACCNT_CGY	                      --账户类别
				--,BUS_DATE as BUS_DATE
 FROM       DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP1   a1
 FULL JOIN  DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP2   a2
 ON             a1.CUST_NO = a2.CUST_NO
 AND            a1.EXG = a2.EXG
 AND            a1.ACCNT_CGY = a2.ACCNT_CGY
 FULL JOIN  DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP3   a3
 ON             COALESCE(a1.CUST_NO,a2.CUST_NO) = a3.CUST_NO
 AND            COALESCE(a1.EXG,a2.EXG) = a3.EXG
 AND            COALESCE(a1.ACCNT_CGY,a2.ACCNT_CGY) = a3.ACCNT_CGY
 FULL JOIN  DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP4   a4
 ON             COALESCE(a1.CUST_NO,a2.CUST_NO,a3.CUST_NO) = a4.CUST_NO
 AND            COALESCE(a1.EXG,a2.EXG,a3.EXG) = a4.EXG
 AND            COALESCE(a1.ACCNT_CGY,a2.ACCNT_CGY,a3.ACCNT_CGY) = a4.ACCNT_CGY
 FULL JOIN  DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP5   a5
 ON             COALESCE(a1.CUST_NO,a2.CUST_NO,a3.CUST_NO,a4.CUST_NO) = a5.CUST_NO
 AND            COALESCE(a1.EXG,a2.EXG,a3.EXG,a4.EXG) = a5.EXG
 AND            COALESCE(a1.ACCNT_CGY,a2.ACCNT_CGY,a3.ACCNT_CGY,a4.ACCNT_CGY) = a5.ACCNT_CGY
 LEFT JOIN  DDW_PROD.T_DDW_F00_CUST_CUST_INFO  t
 ON         COALESCE(a1.CUST_NO,a2.CUST_NO,a3.CUST_NO,a4.CUST_NO,a5.CUST_NO) = t.CUST_NO
 AND        t.BUS_DATE = %d{yyyyMMdd}
 ;
 --删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP1;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP2;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP3;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP4;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY_TEMP5;
 
-----------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F10_TRD_CUST_SEC_TRD_AGGR_DAY;
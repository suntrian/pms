------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:全市场基金表                                                                    */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2018-11-26                                                                        */ 

 
 --清除数据
 TRUNCATE TABLE EDW_PROD.T_EDW_T04_FUND_INFO;
 
 ------插入数据
  INSERT OVERWRITE EDW_PROD.T_EDW_T04_FUND_INFO
(
            INNER_CODE                    --基金内码
           ,FUND_CODE                     --基金代码
           ,FUND_TAG                      --基金标签代码(逗号分隔)
           ,FUND_TAG_NAME                 --基金标签名称(逗号分隔)
           ,FUND_ABBR                     --基金名称
           ,FIRST_CATEGORY                --一级分类id
           ,FIRST_CATEGORY_NAME           --一级分类名称
           ,SECOND_CATEGORY               --二级分类id
           ,SECOND_CATEGORY_NAME          --二级分类名称
           ,THIRD_CATEGORY                --三级分类id
           ,THIRD_CATEGORY_NAME           --三级分类名称
           ,RISK_LEVEL                    --风险等级id
           ,RANK_COMPOSITERATING_THREE    --三年基金评级id
           ,RANK_COMPOSITERATING_FIVE     --5年基金评级id
           ,FUND_SIZE                     --基金规模
           ,FUND_SIZE_NAME                --基金规模名称
           ,FUND_VALUE                    --基金价值风格
           ,FUND_VALUE_NAME               --基金价值风格名称
           ,FUND_TAG_THEME                --基金主题id
           ,UNITNV                        --基金单位净值
           ,DAILY_NVGR                    --日涨跌幅
           ,NVGR_FOR_1MONTH               --近一个月增长率
           ,NVGR_FOR_3MONTH               --近3个月增长率
           ,NVGR_FOR_6MONTH               --近6个月增长率
           ,NVGR_FOR_1YEAR                --近一年增长率
           ,NVGR_FOR_3YEAR                --近3年增长率
           ,END_DATE                      --净值日期
           ,UPDATE_TIME                   
 ) partition(BUS_DATE = %d{yyyyMMdd})
 SELECT     
            INNER_CODE                                                      --基金内码
           ,FUND_CODE                                                       --基金代码
           ,FUND_TAG                                                        --基金标签代码(逗号分隔)
           ,FUND_TAG_NAME                                                   --基金标签名称(逗号分隔)
           ,FUND_ABBR                                                       --基金名称
           ,FIRST_CATEGORY                                                  --一级分类id
           ,FIRST_CATEGORY_NAME                                             --一级分类名称
           ,SECOND_CATEGORY                                                 --二级分类id
           ,SECOND_CATEGORY_NAME                                            --二级分类名称
           ,THIRD_CATEGORY                                                  --三级分类id
           ,THIRD_CATEGORY_NAME                                             --三级分类名称
           ,RISK_LEVEL                                                      --风险等级id
           ,RANK_COMPOSITERATING_THREE                                      --三年基金评级id
           ,RANK_COMPOSITERATING_FIVE                                       --5年基金评级id
           ,FUND_SIZE                                                       --基金规模
           ,FUND_SIZE_NAME                                                  --基金规模名称
           ,FUND_VALUE                                                      --基金价值风格
           ,FUND_VALUE_NAME                                                 --基金价值风格名称
           ,FUND_TAG_THEME                                                  --基金主题id
           ,UNITNV                                                          --基金单位净值
           ,cast(DAILY_NVGR as DECIMAL(38,0)) AS DAILY_NVGR                 --日涨跌幅
           ,cast(NVGR_FOR_1MONTH as DECIMAL(38,0)) AS NVGR_FOR_1MONTH       --近一个月增长率       
           ,cast(NVGR_FOR_3MONTH as DECIMAL(38,0)) AS NVGR_FOR_3MONTH       --近3个月增长率         
           ,cast(NVGR_FOR_6MONTH as DECIMAL(38,0)) AS NVGR_FOR_6MONTH       --近6个月增长率         
           ,cast(NVGR_FOR_1YEAR as DECIMAL(38,0)) AS NVGR_FOR_1YEAR         --近一年增长率      
           ,cast(NVGR_FOR_3YEAR as DECIMAL(38,0)) AS NVGR_FOR_3YEAR         --近3年增长率        
           ,END_DATE                                                        --净值日期
           ,UPDATE_TIME
FROM       jjlc. FUND_INFO
;
 
 ----删除临时表
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_FUND_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
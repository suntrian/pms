 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:合约账户信息表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 TRUNCATE TABLE EDW_PROD.T_EDW_T02_THYZH; 
-------插入数据开始--------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_THYZH
(
                                    JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,KHH                                 --客户号                                
                                   ,YYB                                 --营业部                                
                                   ,ZZHBM                               --子账户编码                              
                                   ,BZDM                                --币种代码                               
                                   ,GDMC                                --股东名称                               
                                   ,GDJC                                --股东简称                               
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,GDZT                                --股东状态                               
                                   ,GDZHLB                              --股东账户类别                             
                                   ,GDLB                                --股东类别                               
                                   ,GDSBJBDM                            --股东帐户申报级别代码                         
                                   ,KHRQ                                --开户日期                               
                                   ,XHRQ                                --销户日期                               
                                   ,GDZZHBZ                             --股东主账户标志                            
                                   ,GDZDSX                              --股东指定属性                             
                                   ,SOP_HYKZSX                          --合约控制属性                             
                                   ,GDZDXW                              --股东指定席位                             
                                   ,BPGDH                               --报盘股东号                              
                                   ,YWXT                                --业务系统                               
                                   ,YWZH                                --业务账号     
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,CAST(COALESCE(t9.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as YYB                                 --营业部                                 
                                   ,t.ZZHBM                               as ZZHBM                               --子账户编码                               
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.GDMC                                as GDMC                                --股东名称                                
                                   ,t.GDJC                                as GDJC                                --股东简称                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.GDZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as GDZT                                --股东状态                                
                                   ,CAST(t.ZHLB AS VARCHAR(20))           as GDZHLB                              --账户类别                                
                                   ,CAST(t.GDLB AS STRING)                as GDLB                                --股东类别                                
                                   ,CAST(COALESCE(t7.MBDM,NULLIF(CONCAT('ERR',CAST(t.SBJB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as GDSBJBDM                            --申报级别                                
                                   ,t.KHRQ                                as KHRQ                                --开户日期                                
                                   ,t.XHRQ                                as XHRQ                                --销户日期                                
                                   ,CAST(COALESCE(t8.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZZHBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as GDZZHBZ                             --主账户标志                               
                                   ,t.GDZDSX                              as GDZDSX                              --股东指定属性                              
                                   ,t.HYKZSX                              as SOP_HYKZSX                          --合约控制属性                              
                                   ,t.GDZDXW                              as GDZDXW                              --股东指定席位                              
                                   ,t.BPGDH                               as BPGDH                               --报盘股东号                               
                                   ,t.YWXT                                as YWXT                                --业务系统                                
                                   ,t.YWZH                                as YWZH                                --业务账号  
                                   ,'YGT_GT'                              as XTBS								   
 FROM           YGTCX.CIF_THYZH                                    t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING             t1 
 ON             t1.DMLX = 'JYS'
 AND            t1.YXT = 'YGT_GT'
 AND            t1.YDM = CAST(t.JYS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING              t2 
 ON             t2.DMLX = 'BZDM'
 AND            t2.YXT = 'YGT_GT'
 AND            t2.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING              t3 
 ON             t3.DMLX = 'ZJLBDM'
 AND            t3.YXT = 'YGT_GT'
 AND            t3.YDM = CAST(t.ZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING               t4 
 ON             t4.DMLX = 'GDZT'
 AND            t4.YXT = 'YGT_GT'
 AND            t4.YDM = CAST(t.GDZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING                t5 
 ON             t5.DMLX = 'GDZHLB'
 AND            t5.YXT = 'YGT_GT'
 AND            t5.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING                 t7 
 ON             t7.DMLX = 'GDSBJBDM'
 AND            t7.YXT = 'YGT_GT'
 AND            t7.YDM = CAST(t.SBJB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING                  t8 
 ON             t8.DMLX = 'GDZZHBZ'
 AND            t8.YXT = 'YGT_GT'
 AND            t8.YDM = CAST(t.ZZHBZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING                      t9   
 ON             t9.YXT = 'CIF'
 AND            t9.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---------插入数据结束-----------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_THYZH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_THYZH;
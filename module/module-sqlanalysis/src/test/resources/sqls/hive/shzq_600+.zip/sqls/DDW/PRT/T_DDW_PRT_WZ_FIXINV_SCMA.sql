------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:温州定投基金方案表                                                           */
------/* 创建人:黄勇华                                                                                 */
------/* 创建时间:2019-04-02                                                                          */ 
  --清空数据
  TRUNCATE TABLE DDW_PROD.T_DDW_PRT_WZ_FIXINV_SCMA ;
  ----创建临时表1
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FIXINV_SCMA_TEMP ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_FIXINV_SCMA_TEMP as
  SELECT KHH as CUST_NO
  FROM EDW_PROD.T_EDW_T02_TOF_DQDESGXY 
  WHERE KSRQ > = 20190101
  AND KHH NOT IN (SELECT KHH 
                  FROM  EDW_PROD.T_EDW_T02_TOF_DQDESGXY
                  WHERE KSRQ < 20190101
                  )
  GROUP BY KHH
  ;
  ----创建临时表2
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FIXINV_SCMA_TEMP1 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_FIXINV_SCMA_TEMP1 as
  SELECT CUST_NO,PROD_CD,COUNT(1) as NUM 
  FROM   DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS 
  WHERE  PROD_BIZ_CD = '139'
  AND    CNFM_AMT >= 500
  AND   BUS_DATE >= 20190101
  GROUP BY CUST_NO,PROD_CD
  HAVING COUNT(1) >= 3 ;

------插入数据开始
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_WZ_FIXINV_SCMA
(              BRH_NO                        --营业部编号
              ,BRH_NAME                      --营业部名称 
              ,CUST_NO                       --客户号 
              ,CUST_NAME                     --客户姓名 								   
              ,FND_CD                        --定投基金代码
		      ,FND_NAME                      --基金名称      
              ,FIXINV_PRD_NUM                --定投期数  
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
    SELECT 
               a2.BRH_NO                        --营业部编号
              ,a2.BRH_NAME                      --营业部名称 
              ,t.CUST_NO                        --客户号 
              ,a2.CUST_NAME                     --客户姓名 								   
              ,a1.PROD_CD     as FND_CD         --定投基金代码
		      ,a4.JJMC        as FND_NAME        --基金名称      
              ,a1.NUM         as FIXINV_PRD_NUM --定投期数  
    FROM DDW_PROD.T_DDW_PRT_WZ_FIXINV_SCMA_TEMP t
	INNER JOIN DDW_PROD.T_DDW_PRT_WZ_FIXINV_SCMA_TEMP1 a1
    ON         t.CUST_NO = a1.CUST_NO
	INNER JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO   a2
	ON         t.CUST_NO = a2.CUST_NO
	AND        a2.BUS_DATE = %d{yyyyMMdd}
	INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH         a3
	ON         a2.BRH_NO = a3.BRH_NO
	AND        a3.BUS_DATE = %d{yyyyMMdd}
	AND        a3.BELTO_FILIL_CDG = '0032'
	LEFT JOIN  EDW_PROD.T_EDW_T04_TOF_JJXX        a4
	ON         a1.PROD_CD = a4.JJDM
	AND        a4.BUS_DATE = %d{yyyyMMdd}
;


------删除临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FIXINV_SCMA_TEMP;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FIXINV_SCMA_TEMP1;

-----------------------------加载结束--------------------
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_WZ_FIXINV_SCMA',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PRT_WZ_FIXINV_SCMA ; 
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:期权委托明细历史表                                                         */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */ 
  


--------------插入数据-------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_TRD_WRNT_ODR_DEL_HIS
(
                EVNT_SEQNBR                       --事件序号     	  
               ,TRD_DT                            --交易日期	     
			   ,ODR_NO                            --内部委托号	     
			   ,PRT_NO                            --申报委托号	     
               ,OLD_PRT_NO                        --原申报委托号	 
               ,CUST_NO                           --客户号	         
               ,CUST_NAME                         --客户姓名	     
               ,BRH_NO                            --客户营业部	     
               ,EXG                               --交易所	         
               ,SHRHLD_NO                         --股东号	         
               ,WRNT_CTC_CD                       --期权合约代码	 
			   ,WRNT_CTC_SHRTNM                   --期权合约简称	 
               ,WRNT_SEC_TP                       --标的证券品种	 
			   ,SEC_CD                            --证券代码	     
			   ,SEC_NAME                          --证券名称	     
               ,WRNT_TP                           --期权类型	     
			   ,WRNT_BS_DRCT                      --期权买卖方向	 
			   ,WRNT_OPN_CP_FLG                   --开平仓标志	     
               ,WRNT_CVD_LABL                     --备兑标签	     
               ,RVK_FLG                           --撤单标志	     
			   ,RVK_CRPDG_ODR_NO                  --撤销对应的委托号
			   ,WRNT_ODRS_TP                      --期权订单类型	 
               ,ODR_QTY                           --委托数量	     
               ,ODR_LMTPRC                        --委托限价	     
               ,WRNT_SRCPTY                       --期权发起方	     
			   ,ODR_DT                            --委托日期	     
			   ,ODR_TM                            --委托时间	     
               ,PRT_DT                            --申报日期	     
			   ,PRT_TM                            --申报时间	     
			   ,PRT_RSLT                          --申报结果	     
			   ,RSLT_EXPLN                        --结果说明	     
			   ,MTCH_QTY                          --成交数量	     
			   ,MTCH_AMT                          --成交金额	     
               ,MTCH_PRC                          --成交均价	     
               ,CCY_CD                            --清算币种	     
               ,ODR_MOD                           --委托方式	     
               ,OPRT_CLNT                         --操作终端	    
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT             t.SEQNO	                    as EVNT_SEQNBR                       --事件序号     	  
                   ,t.JYRQ	                    as TRD_DT                            --交易日期	     
                   ,t.WTH	                    as ODR_NO                            --内部委托号	     
                   ,t.SBWTH	                    as PRT_NO                            --申报委托号	     
                   ,t.SBWTH_OLD	                as OLD_PRT_NO                        --原申报委托号	 
                   ,t.KHH	                    as CUST_NO                           --客户号	         
                   ,t.KHXM	                    as CUST_NAME                         --客户姓名	     
                   ,t.YYB	                    as BRH_NO                            --客户营业部	     
                   ,t.JYS	                    as EXG                               --交易所	         
                   ,t.GDH	                    as SHRHLD_NO                         --股东号	         
                   ,t.HYDM	                    as WRNT_CTC_CD                       --期权合约代码	 
                   ,t.HYMC	                    as WRNT_CTC_SHRTNM                   --期权合约简称	 
                   ,t.SOP_BDZQPZ	            as WRNT_SEC_TP                       --标的证券品种	 
                   ,t.ZQDM	                    as SEC_CD                            --证券代码	     
                   ,t.ZQMC	                    as SEC_NAME                          --证券名称	     
                   ,t.SOP_QQLX	                as WRNT_TP                           --期权类型	     
                   ,t.SOP_MMFX	                as WRNT_BS_DRCT                      --期权买卖方向	 
                   ,t.SOP_KPCBZ	                as WRNT_OPN_CP_FLG                   --开平仓标志	     
                   ,t.SOP_BDBQ	                as WRNT_CVD_LABL                     --备兑标签	     
                   ,t.CDBZ	                    as RVK_FLG                           --撤单标志	     
                   ,t.CXWTH	                    as RVK_CRPDG_ODR_NO                  --撤销对应的委托号
                   ,t.SOP_DDLX                  as WRNT_ODRS_TP                      --期权订单类型	 
                   ,NVL(t.WTSL,0)	            as ODR_QTY                           --委托数量	     
                   ,NVL(t.WTJG,0)	            as ODR_LMTPRC                        --委托限价	     
                   ,t.SOP_FQF	                as WRNT_SRCPTY                       --期权发起方	     
                   ,t.WTRQ	                    as ODR_DT                            --委托日期	     
                   ,t.WTSJ	                    as ODR_TM                            --委托时间	     
                   ,t.SBRQ	                    as PRT_DT                            --申报日期	     
                   ,t.SBSJ	                    as PRT_TM                            --申报时间	     
                   ,t.SBJG	                    as PRT_RSLT                          --申报结果	     
                   ,t.JGSM	                    as RSLT_EXPLN                        --结果说明	     
                   ,NVL(t.CJSL,0)	            as MTCH_QTY                          --成交数量	     
                   ,NVL(t.CJJE,0)	            as MTCH_AMT                          --成交金额	     
                   ,NVL(t.CJJG,0)	            as MTCH_PRC                          --成交均价	     
                   ,t.QSBZDM	                as CCY_CD                            --清算币种	     
                   ,t.WTFS	                    as ODR_MOD                           --委托方式	     
				   ,t.CZZD1	                    as OPRT_CLNT                         --操作终端	    
 FROM          EDW_PROD.T_EDW_T05_TSO_WTLS                                                t
 WHERE         t.BUS_DATE =  %d{yyyyMMdd} 			   
 ;				   				  				   
---------------- 插入数据结束 -----------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_TRD_WRNT_ODR_DEL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_F00_TRD_WRNT_ODR_DEL_HIS ;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:集中开户表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
-- TRUNCATE TABLE EDW_PROD.T_EDW_T02_LCJZKH;  
--------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_LCJZKH
(
                                    LCJZKH_ID                           --集中开户主键                             
                                   ,INSTID                              --INSTID                             
                                   ,TITLE                               --标题                                 
                                   ,YWDM                                --业务代码                               
                                   ,FQQD                                --发起渠道                               
                                   ,YWQQID                              --业务请求主键                             
                                   ,SQRQ                                --申请日期                               
                                   ,SQSJ                                --申请时间                               
                                   ,KHLB                                --客户类别                               
                                   ,KH_KHFS                             --开户_开户方式                            
                                   ,YYB                                 --营业部                                
                                   ,KHH                                 --客户号                                
                                   ,KHLYDM                              --客户来源代码                             
                                   ,KHJC                                --客户简称                               
                                   ,KHMC                                --客户名称                               
                                   ,FQR                                 --发起人编码                              
                                   ,CZZD                                --操作站点                               
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,ZJQSRQ                              --证件起始日期                             
                                   ,ZJJZRQ                              --证件截止日期                             
                                   ,ZJDZ                                --证件地址                               
                                   ,ZJDZYB                              --证件地址邮编                             
                                   ,ZJFZJG                              --证件发证机关                             
                                   ,ZJZP                                --ZJZP                               
                                   ,EDZ                                 --是否二代证                              
                                   ,YYZZNJRQ                            --营业执照年检日期                           
                                   ,LXDZ                                --联系地址                               
                                   ,YZBM                                --邮政编码                               
                                   ,DH                                  --电话                                 
                                   ,MOBILE                              --手机                                 
                                   ,CZ                                  --传真                                 
                                   ,EMAIL                               --EMAIL                              
                                   ,JTDZ                                --家庭地址                               
                                   ,JTYB                                --家庭邮编                               
                                   ,JTDH                                --家庭电话                               
                                   ,GZDW_DZ                             --工作单位地址                             
                                   ,GZDWYB                              --工作单位邮编                             
                                   ,GZDW_DH                             --工作单位电话                             
                                   ,GJDM                                --国籍代码                               
                                   ,FXQHYLBDM                           --反洗钱行业类别代码                          
                                   ,XQFXDJDM                            --洗钱风险等级代码                           
                                   ,TBSM                                --特别说明                               
                                   ,CSRQ                                --出生日期                               
                                   ,XBDM                                --性别代码                               
                                   ,XLDM                                --学历代码                               
                                   ,ZYDM                                --职业代码 
                                   ,MZDM                                --名族代码								   
                                   ,JG                                  --籍贯                                 
                                   ,HYZKDM                              --婚姻状况代码                             
                                   ,GZDW                                --工作单位                               
                                   ,YWMC                                --英文名称                               
                                   ,YGT_JGLB                            --一柜通机构类别                            
                                   ,ZBSXDM                              --资本属性代码                             
                                   ,GYSX                                --国有属性                               
                                   ,SSSXDM                              --上市属性代码                             
                                   ,FRLBDM                              --法人类别代码                             
                                   ,QYLBDM                              --企业类别代码                             
                                   ,HYLB                               --行业代码                               
                                   ,JGWZDZ                              --机构网站地址                             
                                   ,JGZCDZ                              --机构注册地址                             
                                   ,JGZCRQ                              --机构注册日期                             
                                   ,JGJYFW                              --机构经营范围                             
                                   ,JGZCZB                              --机构注册资本                             
                                   ,JGZCBZ                              --JGZCBZ                             
                                   ,JGZGB                               --机构总股本                              
                                   ,JGLTGB                              --机构流通股本                             
                                   ,SSGPDM                              --SSGPDM                             
                                   ,SSDD                                --SSDD                               
                                   ,ZZJGDM                              --组织机构代码                             
                                   ,ZZJGDMQSRQ                          --组织机构代码起始日期                         
                                   ,ZZJGDMJZRQ                          --组织机构代码截止日期                         
                                   ,ZZJGDMFZJG                          --组织机构代码发证机关                         
                                   ,ZZJGDMNJRQ                          --组织机构代码年间日期                         
                                   ,ZZJGDMZJDZ                          --组织机构代码证件地址                         
                                   ,GSSWDJZ                             --国税税务登记证                            
                                   ,GSSWDJZQSRQ                         --国税税务登记证起始日期                        
                                   ,GSSWDJZJZRQ                         --国税税务登记证截止日期                        
                                   ,GSSWDJZFZJG                         --国税税务登记证发证机关                        
                                   ,GSSWDJZNJRQ                         --国税税务登记证年检日期                        
                                   ,DSSWDJZ                             --地税税务登记证                            
                                   ,DSSWDJZQSRQ                         --地税税务登记证起始日期                        
                                   ,DSSWDJZJZRQ                         --地税税务登记证截止日期                        
                                   ,DSSWDJZFZJG                         --地税税务登记证发证机关                        
                                   ,DSSWDJZNJRQ                         --地税税务登记年检日期                         
                                   ,FRDBXM                              --法人代表姓名                             
                                   ,FRDBZJLBDM                          --法人代表证件类别代码                         
                                   ,FRDBZJBH                            --法人代表证件编号                           
                                   ,FRDBZJQSRQ                          --法人代表证件起始日期                         
                                   ,FRDBZJJZRQ                          --法人代表证件截止日期                         
                                   ,JBRXM                               --经办人姓名                              
                                   ,JBRZJLBDM                           --经办人证件类别                            
                                   ,JBRZJBH                             --经办人证件编号                            
                                   ,JBRZJQSRQ                           --经办人证件起始日期                          
                                   ,JBRZJJZRQ                           --经办人证件截止日期                          
                                   ,JBRDH                               --经办人电话                              
                                   ,JBRSJ                               --经办人手机                              
                                   ,JBRXBDM                             --经办人性别代码                            
                                   ,BZ                                  --备注                                 
                                   ,KHQZ                                --客户群组                               
                                   ,KHKH                                --客户卡号                               
                                   ,WTFS                                --委托方式                               
                                   ,FWXM                                --服务项目                               
                                   ,KHFXJBDM                            --客户风险级别代码                           
                                   ,FXCSNL                              --FXCSNL                             
                                   ,GPFXCSNL                            --GPFXCSNL                           
                                   ,JYMM                                --交易密码                               
                                   ,ZJMM                                --ZJMM                               
                                   ,FWMM                                --服务密码                               
                                   ,DTKLXL                              --DTKLXL                             
                                   ,SQJJZH                              --申请基金账号                             
                                   ,SFWLFW                              --SFWLFW                             
                                   ,WLFWMM                              --WLFWMM                             
                                   ,KHZP                                --KHZP                                                                                           
                                   ,YHTMM                               --一户通密码                              
                                   ,FSSJ                                --发生时间                               
                                   ,FSRQ                                --发生日期                               
                                   ,KHBZ                                --KHBZ                               
                                   ,MMLDBS                              --MMLDBS                             
                                   ,CPDF                                --CPDF                               
                                   ,GPCPDF                              --GPCPDF                             
                                   ,ZDKHH                               --ZDKHH                              
                                   ,SMJJGLRBM                           --SMJJGLRBM                          
) 
PARTITION( bus_date = %d{yyyyMMdd})
select 
                                    t.ID                                  as LCJZKH_ID                           --ID                                  
                                   ,t.INSTID                              as INSTID                              --                                    
                                   ,t.TITLE                               as TITLE                               --标题                                  
                                   ,t.YWDM                                as YWDM                                --业务代码                                
                                   ,t.FQQD                                as FQQD                                --发起渠道                                
                                   ,t.YWQQID                              as YWQQID                              --业务请求ID                              
                                   ,t.SQRQ                                as SQRQ                                --申请日期                                
                                   ,t.SQSJ                                as SQSJ                                --申请时间                                
                                   ,t.KHLB                                as KHLB                                --客户类别                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as KH_KHFS                             --开户方式                                
                                   ,CAST(COALESCE(t22.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as YYB                                 --营业部                                 
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.KHLY AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as KHLYDM                              --客户来源                                
                                   ,t.KHJC                                as KHJC                                --客户简称                                
                                   ,t.KHMC                                as KHMC                                --客户名称                                
                                   ,t.FQR                                 as FQR                                 --发起人编码                               
                                   ,t.CZZD                                as CZZD                                --操作站点                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,t.ZJQSRQ                              as ZJQSRQ                              --证件起始日期                              
                                   ,t.ZJJZRQ                              as ZJJZRQ                              --证件截止日期                              
                                   ,t.ZJDZ                                as ZJDZ                                --证件地址                                
                                   ,t.ZJDZYB                              as ZJDZYB                              --证件地址邮编                              
                                   ,t.ZJFZJG                              as ZJFZJG                              --证件发证机关                              
                                   ,t.ZJZP                                as ZJZP                                --                                    
                                   ,t.EDZ                                 as EDZ                                 --是否二代证                               
                                   ,t.YYZZNJRQ                            as YYZZNJRQ                            --营业执照年检日期                            
                                   ,t.DZ                                  as LXDZ                                --联系地址                                
                                   ,t.YZBM                                as YZBM                                --邮政编码                                
                                   ,t.DH                                  as DH                                  --电话                                  
                                   ,t.SJ                                  as MOBILE                              --手机                                  
                                   ,t.CZ                                  as CZ                                  --传真                                  
                                   ,t.EMAIL                               as EMAIL                               --EMAIL                               
                                   ,t.JTDZ                                as JTDZ                                --家庭地址                                
                                   ,t.JTYB                                as JTYB                                --家庭邮编                                
                                   ,t.JTDH                                as JTDH                                --家庭电话                                
                                   ,t.GZDWDZ                              as GZDW_DZ                             --工作单位地址                              
                                   ,t.GZDWYB                              as GZDWYB                              --工作单位邮编                              
                                   ,t.GZDWDH                              as GZDW_DH                             --工作单位电话                              
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.GJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as GJDM                                --国籍                                  
                                   ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.FXQHYLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                             as FXQHYLBDM                           --反洗钱行业类别                             
                                   ,CAST(COALESCE(t6.MBDM,NULLIF(CONCAT('ERR',CAST(t.XQFXDJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as XQFXDJDM                            --洗钱风险等级                              
                                   ,t.TBSM                                as TBSM                                --特别说明                                
                                   ,t.CSRQ                                as CSRQ                                --出生日期                                
                                   ,CAST(COALESCE(t7.MBDM,NULLIF(CONCAT('ERR',CAST(t.XB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as XBDM                                --性别                                  
                                   ,CAST(COALESCE(t8.MBDM,NULLIF(CONCAT('ERR',CAST(t.XLDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as XLDM                                --学历代码                                
                                   ,CAST(COALESCE(t9.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZYDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as ZYDM                                --职业代码      
                                   ,CAST(COALESCE(t18.MBDM,NULLIF(CONCAT('ERR',CAST(t.MZDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )								as MZDM                         --名族代码  
                                   ,t.JG                                  as JG                                  --籍贯                                  
                                   ,CAST(COALESCE(t10.MBDM,NULLIF(CONCAT('ERR',CAST(t.HYZK AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as HYZKDM                              --婚姻状况                                
                                   ,t.GZDW                                as GZDW                                --工作单位                                
                                   ,t.YWMC                                as YWMC                                --英文名称                                
                                   ,CAST(COALESCE(t11.MBDM,NULLIF(CONCAT('ERR',CAST(t.JGLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as YGT_JGLB                            --机构类别                                
                                   ,CAST(COALESCE(t12.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZBSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZBSXDM                              --资本属性                                
                                   ,CAST(COALESCE(t13.MBDM,NULLIF(CONCAT('ERR',CAST(t.GYSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as GYSX                                --国有属性                                
                                   ,CAST(COALESCE(t14.MBDM,NULLIF(CONCAT('ERR',CAST(t.SSSX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as SSSXDM                              --上市属性                                
                                   ,CAST(COALESCE(t15.MBDM,NULLIF(CONCAT('ERR',CAST(t.FRLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as FRLBDM                              --法人类别                                
                                   ,CAST(COALESCE(t16.MBDM,NULLIF(CONCAT('ERR',CAST(t.QYLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as QYLBDM                              --企业类别                                
                                   ,CAST(COALESCE(t17.MBDM,NULLIF(CONCAT('ERR',CAST(t.HYDM AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as HYLB                                --行业代码                                
                                   ,t.JGWZDZ                              as JGWZDZ                              --机构网站地址                              
                                   ,t.JGZCDZ                              as JGZCDZ                              --机构注册地址                              
                                   ,t.JGZCRQ                              as JGZCRQ                              --机构注册日期                              
                                   ,t.JGJYFW                              as JGJYFW                              --机构经营范围                              
                                   ,t.JGZCZB                              as JGZCZB                              --机构注册资本                              
                                   ,t.JGZCBZ                              as JGZCBZ                              --                                    
                                   ,t.JGZGB                               as JGZGB                               --机构总股本                               
                                   ,t.JGLTGB                              as JGLTGB                              --机构流通股本                              
                                   ,t.SSGPDM                              as SSGPDM                              --                                    
                                   ,t.SSDD                                as SSDD                                --                                    
                                   ,t.ZZJGDM                              as ZZJGDM                              --组织机构代码                              
                                   ,t.ZZJGDMQSRQ                          as ZZJGDMQSRQ                          --组织机构代码起始日期                          
                                   ,t.ZZJGDMJZRQ                          as ZZJGDMJZRQ                          --组织机构代码截止日期                          
                                   ,t.ZZJGDMFZJG                          as ZZJGDMFZJG                          --组织机构代码发证机关                          
                                   ,t.ZZJGDMNJRQ                          as ZZJGDMNJRQ                          --组织机构代码年间日期                          
                                   ,t.ZZJGDMZJDZ                          as ZZJGDMZJDZ                          --组织机构代码证件地址                          
                                   ,t.GSSWDJZ                             as GSSWDJZ                             --国税税务登记证                             
                                   ,t.GSSWDJZQSRQ                         as GSSWDJZQSRQ                         --国税税务登记证起始日期                         
                                   ,t.GSSWDJZJZRQ                         as GSSWDJZJZRQ                         --国税税务登记证截止日期                         
                                   ,t.GSSWDJZFZJG                         as GSSWDJZFZJG                         --国税税务登记证发证机关                         
                                   ,t.GSSWDJZNJRQ                         as GSSWDJZNJRQ                         --国税税务登记证年检日期                         
                                   ,t.DSSWDJZ                             as DSSWDJZ                             --地税税务登记证                             
                                   ,t.DSSWDJZQSRQ                         as DSSWDJZQSRQ                         --地税税务登记证起始日期                         
                                   ,t.DSSWDJZJZRQ                         as DSSWDJZJZRQ                         --地税税务登记证截止日期                         
                                   ,t.DSSWDJZFZJG                         as DSSWDJZFZJG                         --地税税务登记证发证机关                         
                                   ,t.DSSWDJZNJRQ                         as DSSWDJZNJRQ                         --地税税务登记年检日期                          
                                   ,t.FRDBXM                              as FRDBXM                              --法人代表姓名                              
                                   ,CAST(COALESCE(t19.MBDM,NULLIF(CONCAT('ERR',CAST(t.FRDBZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                            as FRDBZJLBDM                          --法人代表证件类别                            
                                   ,t.FRDBZJBH                            as FRDBZJBH                            --法人代表证件编号                            
                                   ,t.FRDBZJQSRQ                          as FRDBZJQSRQ                          --法人代表证件起始日期                          
                                   ,t.FRDBZJJZRQ                          as FRDBZJJZRQ                          --法人代表证件截止日期                          
                                   ,t.JBRXM                               as JBRXM                               --经办人姓名                               
                                   ,CAST(COALESCE(t20.MBDM,NULLIF(CONCAT('ERR',CAST(t.JBRZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                             as JBRZJLBDM                           --经办人证件类别                             
                                   ,t.JBRZJBH                             as JBRZJBH                             --经办人证件编号                             
                                   ,t.JBRZJQSRQ                           as JBRZJQSRQ                           --经办人证件起始日期                           
                                   ,t.JBRZJJZRQ                           as JBRZJJZRQ                           --经办人证件截止日期                           
                                   ,t.JBRDH                               as JBRDH                               --经办人电话                               
                                   ,t.JBRSJ                               as JBRSJ                               --经办人手机                               
                                   ,CAST(COALESCE(t21.MBDM,NULLIF(CONCAT('ERR',CAST(t.JBRXB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as JBRXBDM                             --经办人性别                               
                                   ,t.BZ                                  as BZ                                  --备注                                  
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.KHKH                                as KHKH                                --客户卡号                                
                                   ,t.WTFS                                as WTFS                                --委托方式                                
                                   ,t.FWXM                                as FWXM                                --服务项目                                
                                   ,t.KHFXJB                              as KHFXJBDM                            --客户风险级别                              
                                   ,t.FXCSNL                              as FXCSNL                              --                                    
                                   ,t.GPFXCSNL                            as GPFXCSNL                            --                                    
                                   ,t.JYMM                                as JYMM                                --交易密码                                
                                   ,t.ZJMM                                as ZJMM                                --                                    
                                   ,t.FWMM                                as FWMM                                --服务密码                                
                                   ,t.DTKLXLH                             as DTKLXL                              --                                    
                                   ,t.SQJJZH                              as SQJJZH                              --申请基金账号                              
                                   ,t.SFWLFW                              as SFWLFW                              --                                    
                                   ,t.WLFWMM                              as WLFWMM                              --                                    
                                   ,t.KHZP                                as KHZP                                --                                                        
                                   ,t.YHTMM                               as YHTMM                               --一户通密码                               
                                   ,t.FSSJ                                as FSSJ                                --发生时间                                
                                   ,t.FSRQ                                as FSRQ                                --发生日期                                
                                   ,t.KHBZ                                as KHBZ                                --                                    
                                   ,t.MMLDBS                              as MMLDBS                              --                                    
                                   ,t.CPDF                                as CPDF                                --                                    
                                   ,t.GPCPDF                              as GPCPDF                              --                                    
                                   ,t.ZDKHH                               as ZDKHH                               --                                    
                                   ,t.SMJJGLRBM                           as SMJJGLRBM                           --                                    
 FROM           YGTCX.CIF_LCJZKH                       t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'KH_KHFS'
 AND            t1.YXT = 'YGT_GT'
 AND            t1.YDM = CAST(t.KHFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t2 
 ON             t2.DMLX = 'KHLYDM'
 AND            t2.YXT = 'YGT_GT'
 AND            t2.YDM = CAST(t.KHLY AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'ZJLBDM'
 AND            t3.YXT = 'YGT_GT'
 AND            t3.YDM = CAST(t.ZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4 
 ON             t4.DMLX = 'GJDM'
 AND            t4.YXT = 'YGT'
 AND            t4.YDM = CAST(t.GJ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t5 
 ON             t5.DMLX = 'FXQHYLBDM'
 AND            t5.YXT = 'YGT'
 AND            t5.YDM = CAST(t.FXQHYLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t6 
 ON             t6.DMLX = 'XQFXDJDM'
 AND            t6.YXT = 'YGT'
 AND            t6.YDM = CAST(t.XQFXDJ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t7
 ON             t7.DMLX = 'XBDM'
 AND            t7.YXT = 'YGT_GT'
 AND            t7.YDM = CAST(t.XB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t8 
 ON             t8.DMLX = 'XLDM'
 AND            t8.YXT = 'YGT_GT'
 AND            t8.YDM = CAST(t.XLDM AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t9 
 ON             t9.DMLX = 'ZYDM'
 AND            t9.YXT = 'YGT_GT'
 AND            t9.YDM = CAST(t.ZYDM AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t18
 ON             t18.DMLX = 'MZDM'
 AND            t18.YXT = 'YGT_GT'
 AND            t18.YDM = CAST(t.MZDM AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t10 
 ON             t10.DMLX = 'HYZKDM'
 AND            t10.YXT = 'YGT_GT'
 AND            t10.YDM = CAST(t.HYZK AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t11 
 ON             t11.DMLX = 'YGT_JGLB'
 AND            t11.YXT = 'YGT_GT'
 AND            t11.YDM = CAST(t.JGLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t12 
 ON             t12.DMLX = 'ZBSXDM'
 AND            t12.YXT = 'YGT_GT'
 AND            t12.YDM = CAST(t.ZBSX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t13 
 ON             t13.DMLX = 'GYSX'
 AND            t13.YXT = 'YGT_GT'
 AND            t13.YDM = CAST(t.GYSX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t14 
 ON             t14.DMLX = 'SSSXDM'
 AND            t14.YXT = 'YGT_GT'
 AND            t14.YDM = CAST(t.SSSX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t15 
 ON             t15.DMLX = 'FRLBDM'
 AND            t15.YXT = 'YGT_GT'
 AND            t15.YDM = CAST(t.FRLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t16
 ON             t16.DMLX = 'QYLBDM'
 AND            t16.YXT = 'YGT_GT'
 AND            t16.YDM = CAST(t.QYLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t17 
 ON             t17.DMLX = 'HYLB'
 AND            t17.YXT = 'YGT_GT'
 AND            t17.YDM = CAST(t.HYDM AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t19 
 ON             t19.DMLX = 'ZJLBDM'
 AND            t19.YXT = 'YGT_GT'
 AND            t19.YDM = CAST(t.FRDBZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t20 
 ON             t20.DMLX = 'ZJLBDM'
 AND            t20.YXT = 'YGT_GT'
 AND            t20.YDM = CAST(t.JBRZJLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t21
 ON             t21.DMLX = 'XBDM'
 AND            t21.YXT = 'YGT_GT'
 AND            t21.YDM = CAST(t.JBRXB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t22
 ON             t22.YXT = 'CIF'
 AND            t22.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}'	;
------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_LCJZKH',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata EDW_PROD.T_EDW_T02_LCJZKH;
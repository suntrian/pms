 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:客户委托性能月表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2019-02-26                                                                        */ 
  

 
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP  as 
 SELECT  COUNT(1) as CUST_ACTA --客户数
        ,SUBSTR('%d{yyyyMMdd}',1,6) as YEAR_MON 
        ,'普通账户' as ACCNT_SRC		
 FROM   DDW_PROD.T_DDW_F00_CUST_CUST_INFO  t
 INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1 
 ON        t.BRH_NO = a1.BRH_NO
 AND       a1.BUS_DATE = %d{yyyyMMdd}
 WHERE  t.BUS_DATE = %d{yyyyMMdd}
 AND    t.ORDI_CUST_STAT < > '3'
 AND   t.CUST_RSK_LVL IN ('0','1','2','8','19')
 GROUP BY YEAR_MON,ACCNT_SRC
 UNION ALL
  SELECT  COUNT(distinct CUST_NO) as CUST_ACTA --客户数
        ,SUBSTR('%d{yyyyMMdd}',1,6) as YEAR_MON 
        ,'信用账户' as ACCNT_SRC		
 FROM   DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS t
 INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH  a1 
 ON        t.BRH_NO = a1.BRH_NO
 AND       a1.BUS_DATE = %d{yyyyMMdd}
 WHERE  t.BUS_DATE = %d{yyyyMMdd}
 AND    t.CPTL_ACCNT_STAT < > '3'
 AND    t.SYS_SRC = '信用账户'
 GROUP BY YEAR_MON,ACCNT_SRC
 ;
 
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP1 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP1  as 
 SELECT  AVG(t.ODR_NUM)   as ODR_NUM_AVG_DAY
        ,MAX(t.ODR_NUM)  as ODR_NUM_MAX_DAY
		,AVG(t.ODR_NUM*1.00/14400)   as ODR_NUM_AVG_SS
		,SUBSTR('%d{yyyyMMdd}',1,6)  as YEAR_MON
		,ACCNT_SRC	
 FROM 
 (SELECT  COUNT(1) as ODR_NUM --委托数
        ,BUS_DATE as BUS_DATE 
        ,DECODE(XTBS,'JZJY','普通账户','RZRQ','信用账户') as ACCNT_SRC		
 FROM   EDW_PROD.T_EDW_T05_TWTLS 
 WHERE  ((WTSJ > = '09:30:00'
 AND    WTSJ < = '11:30:00')
 OR   ((WTSJ > = '13:00:00'
 AND    WTSJ < = '15:00:00')))
 AND   SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 GROUP BY BUS_DATE,ACCNT_SRC 
 )    t
 GROUP  BY  YEAR_MON ,ACCNT_SRC	
 ;
 
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP2 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP2  as 
 SELECT  
		 MAX(t.ODR_NUM)   as ODR_NUM_MAX_SS
		,SUBSTR('%d{yyyyMMdd}',1,6)  as YEAR_MON
		,ACCNT_SRC	
 FROM 
 (SELECT  COUNT(1) as ODR_NUM --委托数
        ,WTSJ as WTSJ 
        ,DECODE(XTBS,'JZJY','普通账户','RZRQ','信用账户') as ACCNT_SRC	
        ,BUS_DATE		
 FROM   EDW_PROD.T_EDW_T05_TWTLS 
 WHERE  ((WTSJ > = '09:30:00'
 AND    WTSJ < = '11:30:00')
 OR   ((WTSJ > = '13:00:00'
 AND    WTSJ < = '15:00:00')))
 AND   SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 GROUP BY BUS_DATE,ACCNT_SRC,WTSJ 
 )    t
 GROUP  BY  YEAR_MON ,ACCNT_SRC	
 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP3 ;
 CREATE TABLE DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP3  as 
 SELECT  MAX(t.WALL_ODR_NUM)   as WALL_ODR_NUM_MAX
		,SUBSTR('%d{yyyyMMdd}',1,6)  as YEAR_MON
		,SUM(t.WALL_ODR_NUM)   as WALL_ODR_NUM_TOT
		,ACCNT_SRC	
 FROM 
 (SELECT  
         BUS_DATE
		,COUNT(1) as WALL_ODR_NUM
		,DECODE(XTBS,'JZJY','普通账户','RZRQ','信用账户') as ACCNT_SRC	
 FROM   EDW_PROD.T_EDW_T05_TWTLS 
 WHERE  ((WTSJ >  '09:30:00'
 AND    WTSJ <  '11:30:00')
 OR   ((WTSJ >  '13:00:00'
 AND    WTSJ <  '15:00:00')))
 AND   SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
 AND   JYS IN ('SH','SZ','HK','SB','HB')
 AND   SBJG > 1
 AND   CXBZ < > 'W'
 AND   WTLB NOT IN (65,66,73)
 AND UNIX_TIMESTAMP(CONCAT(CAST(WTRQ as STRING),' ',SBSJ),'yyyyMMdd HH:mm:ss')-UNIX_TIMESTAMP(CONCAT(CAST(WTRQ as STRING),' ',WTSJ),'yyyyMMdd HH:mm:ss') > 1
 GROUP BY BUS_DATE,ACCNT_SRC
)      t
GROUP BY YEAR_MON,ACCNT_SRC
;


INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON
(
                                     CUST_ACTA                --客户数                                                                  
								    ,ODR_NUM_AVG_DAY          --平均日委托数  
                                    ,ODR_NUM_MAX_DAY          --日委托峰值	
									,ODR_NUM_AVG_SS           --平均每秒委托数
									,ODR_NUM_MAX_SS           --秒委托峰值
									,WALL_ODR_NUM_AVG         --日均堵单数
									,WALL_ODR_NUM_MAX         --日堵单峰值
                                    ,ACCNT_SRC                --系统来源									
) 
 PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT                              t.CUST_ACTA                --客户数                                                                  
								    ,CAST(ROUND(a1.ODR_NUM_AVG_DAY,0) as DECIMAL(38,0))         --平均日委托数  
                                    ,a1.ODR_NUM_MAX_DAY          --日委托峰值	
									,CAST(ROUND(a1.ODR_NUM_AVG_SS,0) as DECIMAL(38,0))          --平均每秒委托数
									,a2.ODR_NUM_MAX_SS           --秒委托峰值
									,CAST(ROUND(a3.WALL_ODR_NUM_TOT*1.00/a4.NUM,0) as DECIMAL(38,0))   --日均堵单数
									,a3.WALL_ODR_NUM_MAX        --日堵单峰值
                                    ,t.ACCNT_SRC									
 FROM       DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP t
 LEFT JOIN  DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP1 a1
 ON         t.YEAR_MON  = a1.YEAR_MON 
 AND        t.ACCNT_SRC = a1.ACCNT_SRC
 LEFT JOIN  DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP2 a2
 ON         t.YEAR_MON  = a2.YEAR_MON 
 AND        t.ACCNT_SRC = a2.ACCNT_SRC
 LEFT JOIN  DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP3 a3
 ON         t.YEAR_MON  = a3.YEAR_MON 
 AND        t.ACCNT_SRC = a3.ACCNT_SRC
 LEFT JOIN   (SELECT SUBSTR('%d{yyyyMMdd}',1,6) as YEAR_MON
                     ,COUNT(DISTINCT TRD_DT) as NUM 
              FROM EDW_PROD.T_EDW_T99_TRD_DATE 
              WHERE BUS_DATE = %d{yyyyMMdd}
			  AND   TRD_DT < = %d{yyyyMMdd}
			  AND  SUBSTR(CAST(TRD_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			  GROUP BY YEAR_MON
             )                                    a4
 ON         t.YEAR_MON  = a4.YEAR_MON  
 ;
 --删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP1 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP2 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON_TEMP3 ;
 
 ---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_DDW_PRT_CUST_ODR_FUNC_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
     invalidate metadata DDW_PROD.T_DDW_PRT_CUST_ODR_FUNC_MON ;
 
 
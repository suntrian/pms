 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:资金冻结解冻信息表                                                                      */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 
  /*  T_DDW_F05_CPTL_FZN_DTL 修改为  T_DDW_F00_TRD_CPTL_FZN_DTL_HIS*/

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CPTL_FZN_UNFRZN_INFO
(
								 BRH_NO                 --营业部编码
								,BRH_NAME               --营业部名称
								,OCC_BRH_NO             --发生营业部
								,DT                     --日期      
								,CUST_NO                --客户号    
								,CUST_NAME              --客户姓名  
								,ABST                   --摘要      
								,OPRT_TELR              --操作柜员  
								,RECHK_TELR             --复核柜员  
								,OPRT_MOD               --操作方式
								,CTF_CGY                --开户证件类别
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
					 t.BRH_NO                                AS  BRH_NO                      --营业部编码
					,t.BRH_NAME                              AS  BRH_NAME                    --营业部名称
					,t.OCC_BRH_NO                            AS  OCC_BRH_NO                  --发生营业部
					,t.DT                                    AS  DT                          --日期      
					,t.CUST_NO                               AS  CUST_NO                     --客户号    
					,t.CUST_NAME                             AS  CUST_NAME                   --客户姓名  
					,t.ABST                                  AS  ABST                        --摘要      
					,t.OPRT_TELR                             AS  OPRT_TELR                   --操作柜员  
					,t.RECHK_TELR                            AS  RECHK_TELR                  --复核柜员  					
                    ,t.OPRT_MOD                              AS	 OPRT_MOD                    --操作方式				
                    ,a2.CTF_CGY_CD_NAME           AS   CTF_CGY  --开户证件类别
  FROM  		DDW_PROD.T_DDW_F00_TRD_CPTL_FZN_DTL_HIS					  	t
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a1
  ON            t.CUST_NO = a1.CUST_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD     a2
  ON            a1.CTF_CGY_CD = a2.CTF_CGY_CD
  WHERE 		t.bus_date = %d{yyyyMMdd}
  AND           t.OPRT_MOD = '临柜'
;
 
-----------------------------加载结束--------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_CPTL_FZN_UNFRZN_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_CPTL_FZN_UNFRZN_INFO;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:国债代保管明细表                                                                */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
   TRUNCATE TABLE EDW_PROD.T_EDW_T02_TGZDBGMX ; 
----插入数据开始--------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TGZDBGMX(
                                    LSH                                 --流水号                                
                                   ,GTZJZH                              --柜台资金帐号                             
                                   ,KHH                                 --客户号                                
                                   ,NBDM                                --内部代码                               
                                   ,YWKM                                --业务科目                               
                                   ,DBGBH                               --代保管编号                              
                                   ,SRJE                                --SRJE                               
                                   ,FCJE                                --FCJE                               
                                   ,ZY                                  --摘要                                 
                                   ,LOGINID                             --柜台柜员                               
                                   ,FSYYB                               --发生营业部                              
                                   ,CZZD                                --操作站点                               
                                   ,RQ                                  --日期                                 
                                   ,FSSJ                                --发生时间                               
                                   ,KHXM                                --客户姓名                               
                                   ,DBGYYB                              --代保管营业部                             
                                   ,NF                                  --年份                                 
                                   ,ZJLSH                               --资金流水号                              
                                   ,CJJE                                --CJJE                               
                                   ,CQBZ                                --CQBZ   
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.LSH                                 as LSH                                 --流水号                                 
                                   ,t.ZJZH                                as GTZJZH                              --资金账户                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.NBDM                                as NBDM                                --内部代码                                
                                   ,t.YWKM                                as YWKM                                --业务科目                                
                                   ,t.DBGBH                               as DBGBH                               --代保管编号                               
                                   ,t.SRJE                                as SRJE                                --                                    
                                   ,t.FCJE                                as FCJE                                --                                    
                                   ,t.ZY                                  as ZY                                  --摘要                                  
                                   ,t.LOGINID                             as LOGINID                             --柜台柜员                                
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.FSYYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                               as FSYYB                               --发生营业部                               
                                   ,t.CZZD                                as CZZD                                --操作站点                                
                                   ,t.RQ                                  as RQ                                  --日期                                  
                                   ,t.FSSJ                                as FSSJ                                --发生时间                                
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.DBGYYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as DBGYYB                              --代保管营业部                              
                                   ,t.NF                                  as NF                                  --年份                                  
                                   ,t.ZJLSH                               as ZJLSH                               --资金流水号                               
                                   ,t.CJJE                                as CJJE                                --                                    
                                   ,t.CQBZ                                as CQBZ                                --   
                                   ,'JZJY'                                as XTBS								   
  FROM        JZJYCX.SECURITIES_TGZDBGMX t
  LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
  ON             t1.YXT = 'JZJY'
  AND            t1.JGDM = CAST(t.FSYYB AS VARCHAR(20))
  LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t2
  ON             t2.YXT = 'JZJY'
  AND            t2.JGDM = CAST(t.DBGYYB AS VARCHAR(20))
  WHERE       t.DT = '%d{yyyyMMdd}';
--------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TGZDBGMX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T02_TGZDBGMX; 
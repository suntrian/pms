 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:国君资管产品报表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 

--DDW_PROD.T_DDW_PRT_GTJA_ASTMGT_PROD_JDJXL
--------插入数据开始-----------
------插入营业部
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_GTJA_ASTMGT_PROD
(
								 BELTO_FILIL                   --地区
								,BRH_NO 					   --营业部编号
								,BRH_NAME                      --营业部名称
								,PROD_CD                       --产品代码
								,BUYIN_SHR                     --买入份额
								,BUYIN_AMT                     --买入金额
								,SELL_SHR                      --卖出份额
								,SELL_AMT                      --卖出金额
								,BNS_AMT                       --红利金额
								,SHR_GT                        --累计份额
								,AMT_GT                        --累计金额
								,FNL_SHR                       --期末份额
								,FNL_AMT                       --期末金额
								,AVGDLY_AMT                    --日均金额(自然日)
								,AVGDLY_QTY                    --日均数量(自然日)   
								,ASS_INCM                      --收益考核   
)		
 PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT 
								 t.BELTO_FILIL                                  as BELTO_FILIL    --地区
								,t.BRH_NO 			                            as BRH_NO		  --营业部编号
								,t.BRH_SHRTNM                                   as BRH_NAME       --营业部名称
								,a2.PROD_CD                                     as PROD_CD        --产品代码
								,SUM(NVl(a1.SCRP_SHR,0) + NVl(a1.PRCH_SHR,0))   as BUYIN_SHR      --买入份额
								,SUM(NVl(a1.SCRP_AMT,0) + NVl(a1.PRCH_AMT,0))   as BUYIN_AMT      --买入金额
								,SUM(NVl(a1.RDMPT_SHR,0))                       as SELL_SHR       --卖出份额
								,SUM(NVl(a1.RDMPT_AMT,0))                       as SELL_AMT       --卖出金额
								,SUM(NVl(a1.BNS_AMT,0))                         as BNS_AMT        --红利金额
								,SUM(NVL(a1.RTAN_AMT_SHR_GT,0))                 as SHR_GT         --累计份额
								,SUM(NVL(a1.RTAN_AMT_AMT_GT,0))                 as AMT_GT         --累计金额
								,SUM(NVL(a1.FNL_SHR,0))                         as FNL_SHR        --期末份额
								,SUM(NVL(a1.FNL_AMT,0))                         as FNL_AMT        --期末金额
								,SUM(NVL(a1.AVGDLY_AMT,0))                      as AVGDLY_AMT     --日均金额(自然日)
								,SUM(NVL(a1.AVGDLY_QTY,0))                      as AVGDLY_QTY     --日均数量(自然日)   
								,SUM(ROUND((CASE WHEN a2.PROD_CD = '952024'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.009/365
									         WHEN a2.PROD_CD = '952020'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.0072/365
									         WHEN a2.PROD_CD = '952001'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.00297/365
									         WHEN a2.PROD_CD = '952010'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.00045/365
									         WHEN a2.PROD_CD = '953633'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.009/365
								             WHEN a2.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
									         THEN NVL(a1.RTAN_AMT_AMT_GT,0)*0.0036/365
									         WHEN a2.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
									         THEN NVL(a1.RTAN_AMT_AMT_GT,0)*0.0045/365
									         ELSE 0
									         END),2))                    as ASS_INCM       --考核收入   
								                                                          
  FROM  	(SELECT BELTO_FILIL,BRH_NO,BRH_SHRTNM,1 as NUM
             FROM  DDW_PROD.T_DDW_INR_ORG_BRH 	 
			 WHERE BUS_DATE = %d{yyyyMMdd}
			 )          t
  LEFT JOIN  (SELECT DISTINCT JJDM as PROD_CD,1 as NUM
              FROM  EDW_PROD.T_EDW_T04_TOF_JJXX	 
			  WHERE BUS_DATE = %d{yyyyMMdd}
			  AND   SUBSTR(JJDM,1,2) = '95'
			  )           a2
  ON          t.NUM = a2.NUM
  LEFT JOIN     DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON   a1
  ON            t.BRH_NO = a1.BRH_NO
  AND           a2.PROD_CD = a1.PROD_CD
  AND           CAST(a1.YEAR_MON as STRING) = SUBSTR('%d{yyyyMMdd}',1,6)
  GROUP BY BELTO_FILIL,BRH_NO,BRH_NAME,PROD_CD 

  
  
  ---插入分公司
  UNION  ALL
   SELECT 
								 t.BELTO_FILIL       as BELTO_FILIL    --地区
								,t.BELTO_FILIL 		 as BRH_NO		  --营业部编号
								,t.BELTO_FILIL       as BRH_NAME       --营业部名称
								,a2.PROD_CD          as PROD_CD        --产品代码
								,SUM(NVl(a1.SCRP_SHR,0) + NVl(a1.PRCH_SHR,0))   as BUYIN_SHR      --买入份额
								,SUM(NVl(a1.SCRP_AMT,0) + NVl(a1.PRCH_AMT,0))   as BUYIN_AMT      --买入金额
								,SUM(NVl(a1.RDMPT_SHR,0))                       as SELL_SHR       --卖出份额
								,SUM(NVl(a1.RDMPT_AMT,0))                       as SELL_AMT       --卖出金额
								,SUM(NVl(a1.BNS_AMT,0))                         as BNS_AMT        --红利金额
								,SUM(NVL(a1.RTAN_AMT_SHR_GT,0))                 as SHR_GT         --累计份额
								,SUM(NVL(a1.RTAN_AMT_AMT_GT,0))                 as AMT_GT         --累计金额
								,SUM(NVL(a1.FNL_SHR,0))                         as FNL_SHR        --期末份额
								,SUM(NVL(a1.FNL_AMT,0))                         as FNL_AMT        --期末金额
								,SUM(NVL(a1.AVGDLY_AMT,0))                      as AVGDLY_AMT     --日均金额(自然日)
								,SUM(NVL(a1.AVGDLY_QTY,0))                      as AVGDLY_QTY     --日均数量(自然日)   
								,SUM(ROUND((CASE WHEN a2.PROD_CD = '952024'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.009/365
									         WHEN a2.PROD_CD = '952020'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.0072/365
									         WHEN a2.PROD_CD = '952001'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.00297/365
									         WHEN a2.PROD_CD = '952010'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.00045/365
									         WHEN a2.PROD_CD = '953633'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.009/365
								             WHEN a2.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
									         THEN NVL(a1.RTAN_AMT_AMT_GT,0)*0.0036/365
									         WHEN a2.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
									         THEN NVL(a1.RTAN_AMT_AMT_GT,0)*0.0045/365
									         ELSE 0
									         END),2))                    as ASS_INCM       --考核收入   
								                                                          
  FROM  	(SELECT BELTO_FILIL,BRH_NO,BRH_SHRTNM,1 as NUM
             FROM  DDW_PROD.T_DDW_INR_ORG_BRH 	 
			 WHERE BUS_DATE = %d{yyyyMMdd}
			 )          t
  LEFT JOIN  (SELECT DISTINCT JJDM as PROD_CD,1 as NUM
              FROM  EDW_PROD.T_EDW_T04_TOF_JJXX	 
			  WHERE BUS_DATE = %d{yyyyMMdd}
			  AND   SUBSTR(JJDM,1,2) = '95'
			  )           a2
  ON          t.NUM = a2.NUM
  LEFT JOIN     DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON   a1
  ON            t.BRH_NO = a1.BRH_NO
  AND           a2.PROD_CD = a1.PROD_CD
  AND           CAST(a1.YEAR_MON as STRING) = SUBSTR('%d{yyyyMMdd}',1,6)
  GROUP BY BELTO_FILIL,BRH_NO,BRH_NAME,PROD_CD 
  ---插入分公司
  UNION  ALL
   SELECT 
								 '上海证券总计'      as BELTO_FILIL    --地区
								,'上海证券总计' 	 as BRH_NO		  --营业部编号
								,'上海证券总计'      as BRH_NAME       --营业部名称
								,a2.PROD_CD          as PROD_CD        --产品代码
								,SUM(NVl(a1.SCRP_SHR,0) + NVl(a1.PRCH_SHR,0))   as BUYIN_SHR      --买入份额
								,SUM(NVl(a1.SCRP_AMT,0) + NVl(a1.PRCH_AMT,0))   as BUYIN_AMT      --买入金额
								,SUM(NVl(a1.RDMPT_SHR,0))                       as SELL_SHR       --卖出份额
								,SUM(NVl(a1.RDMPT_AMT,0))                       as SELL_AMT       --卖出金额
								,SUM(NVl(a1.BNS_AMT,0))                         as BNS_AMT        --红利金额
								,SUM(NVL(a1.RTAN_AMT_SHR_GT,0))                 as SHR_GT         --累计份额
								,SUM(NVL(a1.RTAN_AMT_AMT_GT,0))                 as AMT_GT         --累计金额
								,SUM(NVL(a1.FNL_SHR,0))                         as FNL_SHR        --期末份额
								,SUM(NVL(a1.FNL_AMT,0))                         as FNL_AMT        --期末金额
								,SUM(NVL(a1.AVGDLY_AMT,0))                      as AVGDLY_AMT     --日均金额(自然日)
								,SUM(NVL(a1.AVGDLY_QTY,0))                      as AVGDLY_QTY     --日均数量(自然日)   
								,SUM(ROUND((CASE WHEN a2.PROD_CD = '952024'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.009/365
									         WHEN a2.PROD_CD = '952020'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.0072/365
									         WHEN a2.PROD_CD = '952001'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.00297/365
									         WHEN a2.PROD_CD = '952010'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.00045/365
									         WHEN a2.PROD_CD = '953633'
								             THEN NVL(a1.RTAN_AMT_SHR_GT,0)*0.009/365
								             WHEN a2.PROD_CD IN ('952653','952624','952625','952654','952655','952656','952657','952602','952603','952604','952605','952606','952607','952612','952613','952614','952615','952633','952634','952636','952637','952638','952639','952640','952641','952643')
									         THEN NVL(a1.RTAN_AMT_AMT_GT,0)*0.0036/365
									         WHEN a2.PROD_CD IN ('952222','952223','952224','952225','952226','952227','952228','952229','952230','952231','952232','952233','952234','952235','952280','952281','952282','952283','952284','952285','952286','952287','952288','952289','952290','952291','952236')
									         THEN NVL(a1.RTAN_AMT_AMT_GT,0)*0.0045/365
									         ELSE 0
									         END),2))                    as ASS_INCM       --考核收入   
								                                                          
  FROM  	(SELECT BELTO_FILIL,BRH_NO,BRH_SHRTNM,1 as NUM
             FROM  DDW_PROD.T_DDW_INR_ORG_BRH 	 
			 WHERE BUS_DATE = %d{yyyyMMdd}
			 )          t
  LEFT JOIN  (SELECT DISTINCT JJDM as PROD_CD,1 as NUM
              FROM  EDW_PROD.T_EDW_T04_TOF_JJXX	 
			  WHERE BUS_DATE = %d{yyyyMMdd}
			  AND   SUBSTR(JJDM,1,2) = '95'
			  )           a2
  ON          t.NUM = a2.NUM
  LEFT JOIN     DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON   a1
  ON            t.BRH_NO = a1.BRH_NO
  AND           a2.PROD_CD = a1.PROD_CD
  AND           CAST(a1.YEAR_MON as STRING) = SUBSTR('%d{yyyyMMdd}',1,6)
  GROUP BY BELTO_FILIL,BRH_NO,BRH_NAME,PROD_CD  
 ;
 

 

 
-----------------------------加载结束--------------------
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_GTJA_ASTMGT_PROD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_GTJA_ASTMGT_PROD;
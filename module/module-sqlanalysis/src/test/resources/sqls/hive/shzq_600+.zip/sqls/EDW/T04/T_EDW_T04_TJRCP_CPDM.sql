--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:金融产品产品代码表                                                                   */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T04_TJRCP_CPDM ;
------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T04_TJRCP_CPDM
(
                                    FXJG                                --发行机构                               
                                   ,CPDM                                --产品代码                               
                                   ,CPJC                                --产品简称                               
                                   ,CPQC                                --产品全称                               
                                   ,JRCP_SFFS                           --金融产品收费方式                           
                                   ,JRCP_JYZT                           --金融产品产品状态                           
                                   ,CPJZ                                --参考收益率                              
                                   ,PYDM                                --拼音代码                               
                                   ,BZDM                                --币种代码                               
                                   ,YYYZ                                --是否校验预约单                            
                                   ,YYKSRQ                              --预约开始日期                             
                                   ,YYJSRQ                              --预约结束日期                             
                                   ,RGKSRQ                              --认购开始日期                             
                                   ,RGJSRQ                              --认购结束日期                             
                                   ,JKKSRQ                              --缴款开始日起                             
                                   ,JKJSRQ                              --缴款结束日期                             
                                   ,CPQXR                               --产品起息日                              
                                   ,CPDQR                               --产品到期日                              
                                   ,CPDFR                               --产品兑付日                              
                                   ,RGJS                                --认购金额基数                             
                                   ,SGJEJS                              --申购金额基数                             
                                   ,FXZFE                               --发行总份额                              
                                   ,FXFW                                --发行范围                               
                                   ,ZDCYFE                              --最低持有份额                             
                                   ,ZGCYFE                              --最高持有份额                             
                                   ,DBGMSX                              --单笔购买上限                             
                                   ,DHDRGMSX                            --单户当日购买上限                           
                                   ,CDKZ                                --撤单控制                               
                                   ,JYKSSJ                              --交易开始时间                             
                                   ,JYJSSJ                              --交易结束时间                             
                                   ,RGZDZJ                              --认购最低金额                             
                                   ,RGDZZJ                              --认购递增金额                             
                                   ,SGZDZJ                              --申购最低金额                             
                                   ,SGDZZJ                              --申购递增金额                             
                                   ,SHZDZJ                              --赎回最低金额                             
                                   ,SHDZZJ                              --赎回递增金额                             
                                   ,SGZDZJ_JG                           --申购最低金额（机构）                         
                                   ,SGDZZJ_JG                           --申购递增金额（机构）                         
                                   ,RGZDZJ_JG                           --认购最低金额（机构）                         
                                   ,RGDZZJ_JG                           --认购递增金额（机构）                         
                                   ,SHZDZJ_JG                           --赎回最低金额（机构）                         
                                   ,SHDZZJ_JG                           --赎回递增金额（机构）                         
                                   ,WTFSFW                              --委托方式范围                             
                                   ,FEMXBZ                              --FEMXBZ                             
                                   ,CPLX                                --产品类型                               
                                   ,JRCP_CPFXDJ                         --金融产品风险等级                           
                                   ,JRCP_ZQFXDJ                         --金融证券端风险等级                          
                                   ,KHLX                                --客户类型                               
                                   ,JRCP_DZYZFS                         --金融电子验证方式                           
                                   ,KHSJXZ                              --开户时间限制                             
                                   ,BHCGXZ                              --购买本行存管限制                           
                                   ,TZQX                                --投资期限  
                                   ,TZPZ                                --投资品种	
                                   ,YQSY                                --预期收益	
                                   ,PPYSFW	
                                   ,SLBZ								   
								   ,XTBS                                  								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.FXJG                                as FXJG                                --发行机构                                
                                   ,t.CPDM                                as CPDM                                --产品代码                                
                                   ,t.CPJC                                as CPJC                                --产品简称                                
                                   ,t.CPQC                                as CPQC                                --产品全称                                
                                   ,CAST(t.SFFS AS VARCHAR(20) )                            as JRCP_SFFS                           --收费方式                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYZT AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as JRCP_JYZT                           --交易状态                                
                                   ,t.CPJZ                                as CPJZ                                --参考收益率（净值）                           
                                   ,t.PYDM                                as PYDM                                --拼音代码                                
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.YYYZ                                as YYYZ                                --是否校验预约单                             
                                   ,t.YYKSRQ                              as YYKSRQ                              --预约开始日期                              
                                   ,t.YYJSRQ                              as YYJSRQ                              --预约结束日期                              
                                   ,t.RGKSRQ                              as RGKSRQ                              --认购开始日期                              
                                   ,t.RGJSRQ                              as RGJSRQ                              --认购结束日期                              
                                   ,t.JKKSRQ                              as JKKSRQ                              --缴款开始日起                              
                                   ,t.JKJSRQ                              as JKJSRQ                              --缴款结束日期                              
                                   ,t.CPQXR                               as CPQXR                               --产品起息日                               
                                   ,t.CPDQR                               as CPDQR                               --产品到期日                               
                                   ,t.CPDFR                               as CPDFR                               --产品兑付日                               
                                   ,t.RGJS                                as RGJS                                --认购金额基数                              
                                   ,t.SGJS                                as SGJEJS                              --申购金额基数                              
                                   ,t.FXZFE                               as FXZFE                               --发行总份额                               
                                   ,t.FXFW                                as FXFW                                --发行范围                                
                                   ,t.ZDCYFE                              as ZDCYFE                              --最低持有份额                              
                                   ,t.ZGCYFE                              as ZGCYFE                              --最高持有份额                              
                                   ,t.DBGMSX                              as DBGMSX                              --单笔购买上限                              
                                   ,t.DHDRGMSX                            as DHDRGMSX                            --单户当日购买上限                            
                                   ,t.CDKZ                                as CDKZ                                --撤单控制                                
                                   ,t.JYKSSJ                              as JYKSSJ                              --交易开始时间                              
                                   ,t.JYJSSJ                              as JYJSSJ                              --交易结束时间                              
                                   ,t.RGZDZJ                              as RGZDZJ                              --认购最低金额                              
                                   ,t.RGDZZJ                              as RGDZZJ                              --认购递增金额                              
                                   ,t.SGZDZJ                              as SGZDZJ                              --申购最低金额                              
                                   ,t.SGDZZJ                              as SGDZZJ                              --申购递增金额                              
                                   ,t.SHZDZJ                              as SHZDZJ                              --赎回最低金额                              
                                   ,t.SHDZZJ                              as SHDZZJ                              --赎回递增金额                              
                                   ,t.SGZDZJ_JG                           as SGZDZJ_JG                           --申购最低金额（机构）                          
                                   ,t.SGDZZJ_JG                           as SGDZZJ_JG                           --申购递增金额（机构）                          
                                   ,t.RGZDZJ_JG                           as RGZDZJ_JG                           --认购最低金额（机构）                          
                                   ,t.RGDZZJ_JG                           as RGDZZJ_JG                           --认购递增金额（机构）                          
                                   ,t.SHZDZJ_JG                           as SHZDZJ_JG                           --赎回最低金额（机构）                          
                                   ,t.SHDZZJ_JG                           as SHDZZJ_JG                           --赎回递增金额（机构）                          
                                   ,t.WTFSFW                              as WTFSFW                              --委托方式范围                              
                                   ,t.FEMXBZ                              as FEMXBZ                              --                                    
                                   ,t.CPLX                                as CPLX                                --产品类型                                
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.FXDJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as JRCP_CPFXDJ                         --银行风险等级                              
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZQFXDJ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                              as JRCP_ZQFXDJ                         --券商风险评级                              
                                   ,t.KHLX                                as KHLX                                --客户类型                                
                                   ,t.DZYZFS                              as JRCP_DZYZFS                         --电签验证方式                              
                                   ,t.KHSJXZ                              as KHSJXZ                              --开户时间限制                              
                                   ,t.BHCGXZ                              as BHCGXZ                              --购买本行存管限制                            
                                   ,CASE WHEN t.TZQX IN (1,2,4)								             
 								         THEN t.TZQX
										 WHEN t.TZQX BETWEEN 5 AND 365										      
										 THEN 1
										 WHEN t.TZQX BETWEEN 365 AND 1825										      
										 THEN 2
										 WHEN t.TZQX > 1825										      
										 THEN 4
										 ELSE t.TZQX
										 END                                as TZQX                                --投资期限   
									,t.TZPZ                                --投资品种	
                                    ,t.YQSY                                --预期收益	
                                    ,t.PPYSFW	
                                    ,t.SLBZ	
										
										,'JZJY'								   
 FROM 			JZJYCX.JRCP_TJRCP_CPDM 							t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t1 
 ON             t1.DMLX = 'JRCP_JYZT'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.JYZT AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t2 
 ON             t2.DMLX = 'BZDM'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t3
 ON             t3.DMLX = 'JRCP_CPFXDJ'
 AND            t3.YXT = 'JZJY'
 AND            t3.YDM = CAST(t.FXDJ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t4
 ON             t4.DMLX = 'JRCP_ZQFXDJ'
 AND            t4.YXT = 'JZJY'
 AND            t4.YDM = CAST(t.ZQFXDJ AS VARCHAR(20))
 WHERE 			t.DT = '%d{yyyyMMdd}';
-------插入数据结束

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TJRCP_CPDM',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T04_TJRCP_CPDM;
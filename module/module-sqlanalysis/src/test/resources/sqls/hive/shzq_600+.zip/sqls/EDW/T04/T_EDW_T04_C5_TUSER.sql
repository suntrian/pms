 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:岗位成员表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
-----------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T04_C5_TUSER(
                    ID          
                   ,USERID      
                   ,NAME        
                   ,GRADE       
                   ,YHLB        
                   ,ZT          
                   ,ORGID       
                   ,SM          
                   ,CJRQ        
                   ,CERTNO      
                   ,DZ          
                   ,YZBM        
                   ,PHONE       
                   ,SJ          
                   ,EMAIL       
                   ,MSN         
                   ,QQ          
                   ,STATUS      
                   ,IPLIMIT     
                   ,LOGINS      
                   ,LASTLOGIN   
                   ,CHGPWDLIMIT 
                   ,CHGPWDTIME  
                   ,PASSWORD    
                   ,DLYZFS      
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                    t.ID          
                   ,t.USERID      
                   ,t.NAME        
                   ,t.GRADE       
                   ,t.YHLB        
                   ,t.ZT          
                   ,t.ORGID       
                   ,t.SM          
                   ,t.CJRQ        
                   ,t.CERTNO      
                   ,t.DZ          
                   ,t.YZBM        
                   ,t.PHONE       
                   ,t.SJ          
                   ,t.EMAIL       
                   ,t.MSN         
                   ,t.QQ          
                   ,t.STATUS      
                   ,t.IPLIMIT     
                   ,t.LOGINS      
                   ,t.LASTLOGIN   
                   ,t.CHGPWDLIMIT 
                   ,t.CHGPWDTIME  
                   ,t.PASSWORD    
                   ,t.DLYZFS					   
 FROM       C5CX.SPIF_TUSER    t
 WHERE      t.DT = '%d{yyyyMMdd}';
----插入数据结束--------------
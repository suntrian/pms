 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:个股盈亏月表                                                         */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-07-07                                                                        */
---A 股1 B 股 2 权证 3 债券4 场内基金5 三板 6 港股7 场外基金 8 金融产品 9 期权 10--
 --
-----删除今天的数据---
 --ALTER TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_MON DROP IF EXISTS PARTITION (YEAR_MON = cast(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) AS INT) ) ; 
 -----创建临时表1(取出产品是-A 股1 B 股 2场内基金5港股7)
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_MON_TEMP1_%d{yyyyMMdd};
  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_MON_TEMP1_%d{yyyyMMdd}
  as SELECT       CUST_NO
                 ,EXG
				 ,CCY_CD
				 ,SEC_CD
				 ,SUM(TRD_COST)         as TRD_COST
				 ,SUM(TRD_FEE_PAYOUT)   as TRD_FEE_PAYOUT
                 ,SUM(CMSN_PAYOUT)      as CMSN_PAYOUT
				 ,SUM(INT_PAYOUT)       as INT_PAYOUT
				 ,SUM(OTH_PAYOUT)       as OTH_PAYOUT
				 ,SUM(TOT_PRET)         as TOT_PRET
				 ,SUM(BUYIN_AMT)        as BUYIN_AMT
				 ,SUM(SELL_AMT)         as SELL_AMT
				 ,PROD_CGY
	 FROM       DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_DAY   t
	 WHERE      SUBSTR(CAST(BUS_DATE as STRING),1,6) =  SUBSTR('%d{yyyyMMdd}',1,6)
	 AND        PROD_CGY IN (1,2,5,7)
	 AND        CUST_NO < > '100610335855' 
     AND        SUBSTR(CUST_NO,1,4) NOT IN ('4444','9999','1058','1088','1052','8888')
     GROUP BY   CUST_NO,EXG,CCY_CD,SEC_CD,PROD_CGY;
 ----起初和期末持仓市值
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_MON_TEMP2_%d{yyyyMMdd};  
  CREATE TABLE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_MON_TEMP2_%d{yyyyMMdd} as 
  SELECT         t.CUST_NO 
				,t.EXG
				,t.SEC_CD
				,SUM(CASE WHEN t.EXG IN ('HK','SK') 
				      AND  a2.TRD_DT IS NOT NULL
					  THEN t.SEC_MKTVAL*a1.ZHHL
					  WHEN t.EXG NOT IN ('HK','SK')
					  AND  a2.TRD_DT IS NOT NULL
					  THEN t.SEC_MKTVAL
					  ELSE 0
					  END)   as STRT_MKTVAL
				,SUM(CASE WHEN t.EXG IN ('HK','SK') 
				      AND  t.BUS_DATE = %d{yyyyMMdd}
					  THEN t.SEC_MKTVAL*a1.ZHHL
					  WHEN t.EXG NOT IN ('HK','SK')
					  AND  t.BUS_DATE = %d{yyyyMMdd}
					  THEN t.SEC_MKTVAL
					  ELSE 0
					  END)   as FNL_MKTVAL 
               					  
  FROM        DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS   t
  LEFT JOIN   EDW_PROD.T_EDW_T99_HLZH          a1
  ON          t.BUS_DATE = a1.BUS_DATE
  AND         t.CCY_CD = a1.BZDM
  LEFT JOIN   (SELECT MAX(TRD_DT) as TRD_DT 
			   FROM   EDW_PROD.T_EDW_T99_TRD_DATE
			   WHERE  SUBSTR(CAST(TRD_DT as STRING),1,6) =  SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			   AND    BUS_DATE = %d{yyyyMMdd}
			   )       a2
  ON          t.BUS_DATE = a2.TRD_DT
  WHERE       (t.BUS_DATE = a2.TRD_DT OR t.BUS_DATE = %d{yyyyMMdd} ) 
  GROUP BY   t.CUST_NO,t.EXG,t.SEC_CD;
 ------------临时表2

		
 --------------插入数据-------------
 INSERT OVERWRITE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_MON
 (                                  CUST_NO                    --客户号
                                  ,EXG                        --交易所   
                                  ,CCY_CD                     --币种代码                                 
                                  ,SEC_CD                     --证券代码
								  ,SEC_NAME                   --证券名称
								  ,TRD_COST                   --交易成本
                                  ,TRD_FEE_PAYOUT             --交易费用支出
                                  ,CMSN_PAYOUT                --佣金支出
                                  ,INT_PAYOUT		          --利息支出
                                  ,OTH_PAYOUT                 --其他支出
                                  ,TOT_PRET   			      --总盈亏
								  ,BUYIN_AMT                  --买入金额
								  ,SELL_AMT                   --卖出金额
								  ,FEE                        --费用
								  ,OTH                        --其他
								  ,STRT_MKTVAL                --期初市值
								  ,FNL_MKTVAL                 --期末市值
                                  ,PROD_CGY	                  --产品类别
								  ,PAYOF_RANK                 --盈利排名
								  ,LOSS_RANK                  --亏损排名
								  ,IF_MRGNS_GL_FLG            --月末是否有融券负债
                                  ,BUS_DATE                   --加载日期
 ) 
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT 
                                    t.CUST_NO                   AS CUST_NO                     --客户号                         
                                   ,t.EXG                       AS EXG                         --交易所
                                   ,t.CCY_CD               		AS CCY_CD                 		--币种代码                                                                     
                                   ,t.SEC_CD                    AS SEC_CD                      --证券代码		
 								   ,a3.ZQMC                     AS SEC_NAME
  								   ,t.TRD_COST       		    AS TRD_COST             		--交易成本
								   ,t.TRD_FEE_PAYOUT            AS TRD_FEE_PAYOUT      		   --交易费用支出
								   ,t.CMSN_PAYOUT          		AS CMSN_PAYOUT          		--佣金支出                        
                                   ,t.INT_PAYOUT        		AS INT_PAYOUT           		--利息支出
								   ,t.OTH_PAYOUT        		AS OTH_PAYOUT          			--其他支出                        
                                   ,t.TOT_PRET       			AS TOT_PRET           			--总盈亏
								   ,t.BUYIN_AMT                 AS BUYIN_AMT                    --买入金额
								   ,t.SELL_AMT                  AS SELL_AMT                     --卖出金额
								   ,0-NVL(t.TRD_FEE_PAYOUT,0)-NVL(t.CMSN_PAYOUT,0) AS FEE                        --费用								 
								   ,ROUND(0-NVL(a1.FNL_MKTVAL,0)-NVL(t.SELL_AMT,0)
                                   +NVL(t.BUYIN_AMT,0)+nvl(t.TOT_PRET,0)
								   +NVL(a1.STRT_MKTVAL,0)-(NVL(t.TRD_FEE_PAYOUT,0)+NVL(t.CMSN_PAYOUT,0)),2)      AS OTH                        --其他
								   ,CAST(ROUND(NVL(a1.STRT_MKTVAL,0),2) as DECIMAL(38,2))      AS STRT_MKTVAL                  --期初市值
								   ,CAST(ROUND(NVL(a1.FNL_MKTVAL,0),2) as DECIMAL(38,2))        AS FNL_MKTVAL                   --期末市值
                                   ,t.PROD_CGY                  AS PROD_CGY                     --产品类别
                                   ,CASE WHEN t.TOT_PRET > 0  AND t.PROD_CGY IN (1,2,5,7)
								         THEN ROW_NUMBER() OVER(PARTITION BY t.CUST_NO ORDER BY t.TOT_PRET DESC) 
 										 ELSE 9999
										 END                   AS PAYOF_RANK                 --盈利排名
								     ,CASE WHEN t.TOT_PRET < 0 AND t.PROD_CGY IN (1,2,5,7)
								         THEN ROW_NUMBER() OVER(PARTITION BY t.CUST_NO ORDER BY t.TOT_PRET ASC) 
 										 ELSE 9999
										 END                   AS LOSS_RANK                  --亏损排名
                                   ,CASE WHEN a2.SEC_CD IS NOT NULL 
								         THEN 1
										 ELSE 0
										 END               AS IF_MRGNS_GL_FLG            --月末是否有融券负债
								   ,%d{yyyyMMdd}               AS BUS_DATE															   								  								
  FROM          DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_MON_TEMP1_%d{yyyyMMdd} t
  LEFT JOIN     DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_MON_TEMP2_%d{yyyyMMdd}   a1
  ON            t.CUST_NO = a1.CUST_NO
  AND           t.EXG     = a1.EXG
  AND           t.SEC_CD = a1.SEC_CD
  LEFT JOIN     DDW_PROD.T_DDW_F00_AST_CRD_ACCNT_GL_DTL_HIS                  a2
  ON            t.CUST_NO = a2.CUST_NO
  AND           t.EXG     = a2.EXG
  AND           t.SEC_CD  = a2.SEC_CD
  AND           a2.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     EDW_PROD.T_EDW_T04_TZQDM a3  --EDW_PROD.T_EDW_T04_TZQDM    a3
  ON            t.EXG = a3.JYS
  AND           t.SEC_CD = a3.ZQDM
  AND           a3.BUS_DATE = %d{yyyyMMdd}
  ;
  
  
 ----
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_MON_TEMP1_%d{yyyyMMdd};
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_MON_TEMP2_%d{yyyyMMdd};										
---------------- 插入数据结束 -----------------------

-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_STATMT_PER_PRET_STK_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_MON;  
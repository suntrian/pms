 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:基金理财合同签名电子化表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
 --  TRUNCATE TABLE EDW_PROD.T_EDW_T02_TOF_ELCHTXY;   
------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TOF_ELCHTXY
(
                                    HTID                                --合同序列                               
                                   ,KHH                                 --客户号                                
                                   ,KHQZ                                --客户群组                               
                                   ,YYB                                 --营业部                                
                                   ,JJDM                                --基金代码                               
                                   ,TADM                                --基金公司                               
                                   ,OF_SFFSFW                           --基金收费方式范围                           
                                   ,HTLX                                --合同类型                               
                                   ,QYLSH                               --电子合同签署流水号                          
                                   ,GTZZHTH                             --柜面纸质合同编号                           
                                   ,XSDM                                --销售商代码                              
                                   ,QYRQ                                --合同签署日期                             
                                   ,QYSJ                                --合同签署时间                             
                                   ,QYTJ                                --合同签署途径                             
                                   ,QYJQ                                --合同签署机器                             
                                   ,CZWD                                --操作网点号                              
                                   ,FJXX                                --代销商附加信息                            
                                   ,JSSLX                               --客户已签署风险揭示书                         
                                 --  ,FXPP                                --客户风险承受能力匹配情况                       
                                 --  ,CSNL                                --客户风险评级结果                           
                                   ,KSRQ                                --合同申请日期                             
                                   ,JSRQ                                --合同结束日期                             
                                   ,BDRQ                                --推广机构修改日期                           
                                   ,WBZH                                --客户银行卡号                             
                                   ,SBJG                                --申报结果                               
                                   ,HBSM                                --回报说明                               
                                   ,HTZT                                --合同状态                               
                                   ,BLED                                --保留额度                               
                                   ,JHZT                                --计划状态                               
                                   ,BLRQ                                --保留到期日                              
                                   ,CYFS                                --参与方式  
                                   ,YQKJE                               --取款金额								   
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.HTID                                as HTID                                --合同序列                                
                                   ,t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --营业部                                 
                                   ,t.JJDM                                as JJDM                                --基金代码                                
                                   ,t.TADM                                as TADM                                --基金公司                                
                                   ,t.SFFSFW                              as OF_SFFSFW                           --收费方式                                
                                   ,t.HTLX                                as HTLX                                --合同类型                                
                                   ,t.QYLSH                               as QYLSH                               --电子合同签署流水号                           
                                   ,t.GTZZHTH                             as GTZZHTH                             --柜面纸质合同编号                            
                                   ,t.XSDM                                as XSDM                                --销售商代码                               
                                   ,t.QYRQ                                as QYRQ                                --合同签署日期                              
                                   ,t.QYSJ                                as QYSJ                                --合同签署时间                              
                                   ,t.QYTJ                                as QYTJ                                --合同签署途径                              
                                   ,t.QYJQ                                as QYJQ                                --合同签署机器                              
                                   ,t.CZWD                                as CZWD                                --操作网点号                               
                                   ,t.FJXX                                as FJXX                                --代销商附加信息                             
                                   ,t.JSSLX                               as JSSLX                               --客户已签署风险揭示书                          
                                   --,NULL                                as FXPP                                --客户风险承受能力匹配情况                        
                                   --,NULL                                as CSNL                                --客户风险评级结果                            
                                   ,t.KSRQ                                as KSRQ                                --合同申请日期                              
                                   ,t.JSRQ                                as JSRQ                                --合同结束日期                              
                                   ,t.BDRQ                                as BDRQ                                --推广机构修改日期                            
                                   ,t.WBZH                                as WBZH                                --客户银行卡号或券商端资金帐号                      
                                   ,t.SBJG                                as SBJG                                --申报结果                                
                                   ,t.HBSM                                as HBSM                                --回报说明                                
                                   ,t.ZT                                  as HTZT                                --合同状态                                
                                   ,t.BLED                                as BLED                                --保留额度(现金宝)                           
                                   ,t.JHZT                                as JHZT                                --计划状态(现金宝)                           
                                   ,t.BLRQ                                as BLRQ                                --保留到期日(现金宝)                          
                                   ,t.CYFS                                as CYFS                                --参与方式(现金宝)  
                                   ,t.YQKJE                               as YQKJE                               --取款金额								   
                                   ,'JZJY'					              as XTBS			   
 FROM          JZJYCX.OFS_TOF_ELCHTXY t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'JZJY'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE         t.DT = '%d{yyyyMMdd}'
 AND           t.JHZT NOT IN (2,3);
----------插入数据结束-------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TOF_ELCHTXY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

 invalidate metadata EDW_PROD.T_EDW_T02_TOF_ELCHTXY;
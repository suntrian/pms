------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:营业部产品汇总月表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */
----删除当月
  ALTER TABLE DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON DROP IF EXISTS PARTITION (YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) ) ;
---保有量临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP;
 CREATE TABLE  DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP
 as SELECT       t.BRH_NO  as BRH_NO
                ,t.PROD_CD as PROD_CD
				,CASE WHEN SUBSTR(t.PROD_CD,1,1) = 'A' AND t.PROD_CGY = 8
				      THEN '公司自管'
					  WHEN SUBSTR(t.PROD_CD,1,2) = '95' AND t.PROD_CGY = 8
					  THEN '国君自管'
					  WHEN SUBSTR(t.PROD_CD,1,2) < > '95' AND t.PROD_CGY = 8 AND SUBSTR(t.PROD_CD,1,1) < > 'A'
					  THEN '代销基金'
					  WHEN  t.PROD_CGY = 9
					  THEN '金融理财产品'
					  END                             as PROD_CD_AGGR
				,SUM(t.PROD_SHR_QTY)       as RTAN_AMT_SHR_GT
				,SUM(t.PROD_NEWST_MKTVAL)  as RTAN_AMT_AMT_GT
				,SUM(DECODE(a1.NAT_DT,%d{yyyyMMdd},t.PROD_SHR_QTY,0))      as FNL_SHR                    --期末份额
				,SUM(DECODE(a1.NAT_DT,%d{yyyyMMdd},t.PROD_NEWST_MKTVAL,0)) as FNL_AMT                    --期末金额
				,SUBSTR('%d{yyyyMMdd}',1,6)   as YEAR_MON
    FROM         DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS t
	LEFT JOIN    EDW_PROD.T_EDW_T99_TRD_DATE a1
	ON           t.BUS_DATE = a1.TRD_DT
	AND          a1.BUS_DATE = %d{yyyyMMdd}
	WHERE        a1.NAT_DT > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
	AND          a1.NAT_DT < CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,1,0),1,6),'01') as INT)
	AND          t.CUST_NO NOT IN ('100610335855','105810000001')
	AND          LENGTH(TRIM(NVL(t.PROD_CD,''))) > 0
	GROUP BY BRH_NO,PROD_CD,PROD_CD_AGGR,YEAR_MON
	UNION ALL
	SELECT       t.BRH_NO                  as BRH_NO
                ,t.SEC_CD                  as PROD_CD
				,'场内基金'                as PROD_CD_AGGR
				,SUM(t.SEC_QTY)            as RTAN_AMT_SHR_GT
				,SUM(t.SEC_MKTVAL)         as RTAN_AMT_AMT_GT
				,SUM(DECODE(a1.NAT_DT,%d{yyyyMMdd},t.SEC_QTY,0))      as FNL_SHR                    --期末份额
				,SUM(DECODE(a1.NAT_DT,%d{yyyyMMdd},t.SEC_MKTVAL,0)) as FNL_AMT                    --期末金额
				,SUBSTR('%d{yyyyMMdd}',1,6)    as YEAR_MON
    FROM         DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS t
	LEFT JOIN    EDW_PROD.T_EDW_T99_TRD_DATE a1
	ON           t.BUS_DATE = a1.TRD_DT
	AND          a1.BUS_DATE = %d{yyyyMMdd}
	WHERE        a1.NAT_DT > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
	AND          a1.NAT_DT < CAST(CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,1,0),1,6),'01') as INT)
	AND          t.CUST_NO NOT IN ('100610335855','105810000001')
	AND          LENGTH(TRIM(NVL(t.SEC_CD,''))) > 0
	AND          ((t.EXG = 'SH' AND SUBSTR(t.SEC_CD,1,3) IN ('510','511','512','513','500','505','501','502','503','506','518','519','515')) 
	OR          (t.EXG = 'SZ' AND SUBSTR(t.SEC_CD,1,3) IN ('150','151','159','184','160','161','162','163','164','165','166','167','168','169')))
	GROUP BY BRH_NO,PROD_CD,PROD_CD_AGGR,YEAR_MON	
    ;


----申购,赎回,认购金额,份额临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP1;
 CREATE TABLE  DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP1
 as SELECT       t.BRH_NO
                ,t.PROD_CD
				,CASE WHEN SUBSTR(t.PROD_CD,1,1) = 'A' AND t.PROD_CGY = 8
				      THEN '公司自管'
					  WHEN SUBSTR(t.PROD_CD,1,2) = '95' AND t.PROD_CGY = 8
					  THEN '国君自管'
					  WHEN SUBSTR(t.PROD_CD,1,2) < > '95' AND t.PROD_CGY = 8 AND SUBSTR(t.PROD_CD,1,1) < > 'A'
					  THEN '代销基金'
					  WHEN  t.PROD_CGY = 9
					  THEN '金融理财产品'
					  END                             as PROD_CD_AGGR
				,SUM(CASE WHEN t.PROD_BIZ_CD IN ('122','139')
				          THEN t.CNFM_AMT
					      ELSE 0
					      END) as PRCH_AMT
				,SUM(CASE WHEN t.PROD_BIZ_CD IN ('124','142')
				          THEN t.CNFM_AMT
					      ELSE 0
					      END) as RDMPT_AMT
				,SUM(CASE WHEN t.PROD_BIZ_CD IN ('130')
				          THEN t.CNFM_AMT
					      ELSE 0
					      END) as SCRP_AMT
				,SUM(CASE WHEN t.PROD_BIZ_CD IN ('122','139')
				          THEN t.CNFM_SHR
					      ELSE 0
					      END) as PRCH_SHR
				,SUM(CASE WHEN t.PROD_BIZ_CD IN ('124','142')
				          THEN t.CNFM_SHR
					      ELSE 0
					      END) as RDMPT_SHR
				,SUM(CASE WHEN t.PROD_BIZ_CD IN ('130')
				          THEN t.CNFM_SHR
					      ELSE 0
					      END) as SCRP_SHR
			    ,SUM(CASE WHEN t.PROD_BIZ_CD IN ('143')
				          THEN t.CNFM_SHR
					      ELSE 0
					      END) as BNS_AMT
				,SUBSTR('%d{yyyyMMdd}',1,6)    as YEAR_MON
    FROM         DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS t
	WHERE        t.BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
	AND          t.BUS_DATE < = %d{yyyyMMdd}
    AND          t.CUST_NO NOT IN ('100610335855','105810000001')
    AND          LENGTH(TRIM(NVL(t.PROD_CD,''))) > 0
	GROUP BY     BRH_NO,PROD_CD,PROD_CD_AGGR,YEAR_MON
	UNION ALL
	SELECT       t.BRH_NO
                ,t.SEC_CD                              as PROD_CD
				,'场内基金'                             as PROD_CD_AGGR
				,SUM(CASE WHEN t.ODR_CGY IN (61,63,59,57,1111,1,42)
				          THEN t.MTCH_AMT
					      ELSE 0
					      END) as PRCH_AMT  --场内基金的(买+申购)
				,SUM(CASE WHEN t.ODR_CGY IN (64,2222,60,58,62,43,71,2)
				          THEN t.MTCH_AMT
					      ELSE 0
					      END) as RDMPT_AMT --场内基金的(卖出+赎回)
				,SUM(CASE WHEN t.ODR_CGY IN (83)
				          THEN t.MTCH_AMT
					      ELSE 0
					      END) as SCRP_AMT
				,SUM(CASE WHEN t.ODR_CGY IN (61,63,59,57,1111,1,42)
				          THEN t.MTCH_QTY
					      ELSE 0
					      END) as PRCH_SHR
				,SUM(CASE WHEN t.ODR_CGY IN (64,2222,60,58,62,43,71,2)
				          THEN t.MTCH_QTY
					      ELSE 0
					      END) as RDMPT_SHR
				,SUM(CASE WHEN t.ODR_CGY IN (83)
				          THEN t.MTCH_QTY
					      ELSE 0
					      END) as SCRP_SHR
				 ,SUM(CASE WHEN t.ODR_CGY IN (6,16) 
				          THEN t.MTCH_AMT
					      ELSE 0
					      END) as BNS_AMT
				,SUBSTR('%d{yyyyMMdd}',1,6)    as YEAR_MON
    FROM         DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS t
	WHERE        t.BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
	AND          t.BUS_DATE < = %d{yyyyMMdd}
    AND          t.CUST_NO NOT IN ('100610335855','105810000001')
    AND          LENGTH(TRIM(NVL(t.SEC_CD,''))) > 0
	AND          ((t.EXG = 'SH' AND SUBSTR(t.SEC_CD,1,3) IN ('510','511','512','513','500','505','501','502','503','506','518','519','515')) 
	OR          (t.EXG = 'SZ' AND SUBSTR(t.SEC_CD,1,3) IN ('150','151','159','184','160','161','162','163','164','165','166','167','168','169')))
	GROUP BY     BRH_NO,PROD_CD,PROD_CD_AGGR,YEAR_MON	
    ;
 ----认购,申购,赎回客户数
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP2;
 CREATE TABLE  DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP2
 as SELECT       t.BRH_NO
                ,t.PROD_CD
				,CASE WHEN SUBSTR(t.PROD_CD,1,1) = 'A' AND t.PROD_CGY = 8
				      THEN '公司自管'
					  WHEN SUBSTR(t.PROD_CD,1,2) = '95' AND t.PROD_CGY = 8
					  THEN '国君自管'
					  WHEN SUBSTR(t.PROD_CD,1,2) < > '95' AND t.PROD_CGY = 8 AND SUBSTR(t.PROD_CD,1,1) < > 'A'
					  THEN '代销基金'
					  WHEN  t.PROD_CGY = 9
					  THEN '金融理财产品'
					  END                             as PROD_CD_AGGR
				,SUM(CASE WHEN t.PROD_BIZ_CD = 1
				          THEN 1
					      ELSE 0
					      END) as PRCH_CUST_VOL
				,SUM(CASE WHEN t.PROD_BIZ_CD = 2
				          THEN 1
					      ELSE 0
					      END) as RDMPT_CUST_VOL
				,SUM(CASE WHEN t.PROD_BIZ_CD = 3
				          THEN 1
					      ELSE 0
					      END) as SCRP_CUST_VOL
				,SUBSTR('%d{yyyyMMdd}',1,6)    as YEAR_MON
    FROM      (SELECT BRH_NO,CUST_NO,PROD_CD,CASE WHEN PROD_BIZ_CD IN ('122','139')
				                                  THEN 1
					                              WHEN PROD_BIZ_CD IN ('124','142')
												  THEN 2
												  WHEN PROD_BIZ_CD IN ('130')
												  THEN 3												  
					                              END PROD_BIZ_CD,PROD_CGY
	           FROM DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS  t
			   WHERE t.BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
			   AND   t.BUS_DATE < = %d{yyyyMMdd}
			   AND          LENGTH(TRIM(NVL(t.PROD_CD,''))) > 0
               AND          t.CUST_NO NOT IN ('100610335855','105810000001')
               GROUP BY BRH_NO,CUST_NO,PROD_CD,PROD_BIZ_CD,PROD_CGY
	          ) t
	GROUP BY BRH_NO,PROD_CD,PROD_CD_AGGR,YEAR_MON
	UNION ALL
	SELECT       t.BRH_NO
                ,t.PROD_CD
				,'场内基金'                             as PROD_CD_AGGR
				,SUM(CASE WHEN t.PROD_BIZ_CD = 1
				          THEN 1
					      ELSE 0
					      END) as PRCH_CUST_VOL
				,SUM(CASE WHEN t.PROD_BIZ_CD = 2
				          THEN 1
					      ELSE 0
					      END) as RDMPT_CUST_VOL
				,SUM(CASE WHEN t.PROD_BIZ_CD = 3
				          THEN 1
					      ELSE 0
					      END) as SCRP_CUST_VOL
				,SUBSTR('%d{yyyyMMdd}',1,6)    as YEAR_MON
    FROM      ( SELECT       BRH_NO
	                        ,CUST_NO    
	                        ,SEC_CD as PROD_CD
							,CASE WHEN ODR_CGY IN (61,63,59,57,1111,1,42)
							      THEN 1
								  WHEN ODR_CGY IN (64,2222,60,58,62,43,71,2)
								  THEN 2
								  WHEN ODR_CGY IN (83)
								  THEN 3
								  END PROD_BIZ_CD
	            FROM         DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS t
	            WHERE        t.BUS_DATE > = CAST(CONCAT(SUBSTR('%d{yyyyMMdd}',1,6),'01') as INT)
	            AND          t.BUS_DATE < = %d{yyyyMMdd}
                AND          t.CUST_NO NOT IN ('100610335855','105810000001')
                AND          LENGTH(TRIM(NVL(t.SEC_CD,''))) > 0
	            AND          ((t.EXG = 'SH' AND SUBSTR(t.SEC_CD,1,3) IN ('510','511','512','513','500','505','501','502','503','506','518','519','515')) 
	            OR          (t.EXG = 'SZ' AND SUBSTR(t.SEC_CD,1,3) IN ('150','151','159','184','160','161','162','163','164','165','166','167','168','169')))
	            GROUP BY BRH_NO,CUST_NO,PROD_CD,PROD_BIZ_CD
			 ) t
	GROUP BY BRH_NO,PROD_CD,PROD_CD_AGGR,YEAR_MON
    ;


--------------插入数据单个产品-------------------
INSERT INTO DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON
(
                                    BRH_NO                     --营业部
                                   ,PROD_CD                    --产品代码
								   ,PROD_CGY                   --产品类别
                                   ,PRCH_AMT                   --申购金额
                                   ,RDMPT_AMT                  --赎回金额
                                   ,SCRP_AMT                   --认购金额
                                   ,RTAN_AMT_AMT_GT            --累计保有量金额
								   ,AVGDLY_AMT                 --日均金额(自然日)
                                   ,PRCH_SHR                   --申购份额
                                   ,RDMPT_SHR                  --赎回份额
                                   ,SCRP_SHR                   --认购份额
                                   ,RTAN_AMT_SHR_GT            --累计保有量份额
								   ,AVGDLY_QTY                 --日均数量(自然日)
                                   ,PRCH_CUST_VOL              --申购客户数
                                   ,RDMPT_CUST_VOL             --赎回客户数
                                   ,SCRP_CUST_VOL              --认购客户数
								   ,FNL_SHR                    --期末份额
								   ,FNL_AMT                    --期末金额
								   ,BNS_AMT                    --红利金额
                                   ,ETL_DT                     --加载日期
 )
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT
                                    NVL(t.BRH_NO,a1.BRH_NO)                         as BRH_NO                     --营业部
                                   ,NVL(t.PROD_CD,a1.PROD_CD)                       as PROD_CD                    --产品代码
								   ,NVL(t.PROD_CD_AGGR,a1.PROD_CD_AGGR)             as PROD_CGY                   --产品类别
                                   ,NVL(a1.PRCH_AMT,0)                              as PRCH_AMT                   --申购金额
                                   ,NVL(a1.RDMPT_AMT,0)                             as RDMPT_AMT                  --赎回金额
                                   ,NVL(a1.SCRP_AMT,0)                              as SCRP_AMT                   --认购金额
                                   ,NVL(t.RTAN_AMT_AMT_GT,0)                        as RTAN_AMT_AMT_GT            --累计保有量金额
								   ,ROUND(NVL(t.RTAN_AMT_AMT_GT,0)*1.000/a4.DAYS,2)   as AVGDLY_AMT                 --日均金额(自然日)
                                   ,NVL(a1.PRCH_SHR,0)                              as PRCH_SHR                   --申购份额
                                   ,NVL(a1.RDMPT_SHR,0)                             as RDMPT_SHR                  --赎回份额
                                   ,NVL(a1.SCRP_SHR,0)                              as SCRP_SHR                   --认购份额
                                   ,NVL(t.RTAN_AMT_SHR_GT,0)                        as RTAN_AMT_SHR_GT            --累计保有量份额
								   ,ROUND(NVL(t.RTAN_AMT_SHR_GT,0)*1.000/a4.DAYS,2) as AVGDLY_QTY                 --日均数量(自然日)
                                   ,NVL(a2.PRCH_CUST_VOL,0)                         as PRCH_CUST_VOL              --申购客户数
                                   ,NVL(a2.RDMPT_CUST_VOL,0)                        as RDMPT_CUST_VOL             --赎回客户数
                                   ,NVL(a2.SCRP_CUST_VOL,0)                         as SCRP_CUST_VOL              --认购客户数
                                   ,NVL(t.FNL_SHR,0)                           as FNL_SHR                    --期末份额
								   ,NVL(t.FNL_AMT,0)                           as FNL_AMT                    --期末金额
								   ,NVL(a1.BNS_AMT,0)                          as BNS_AMT                    --红利金额
	 							   ,%d{yyyyMMdd}                                    as ETL_DT                     --加载日期
 


  FROM      DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP     t
  FULL JOIN DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP1    a1
  ON        t.BRH_NO = a1.BRH_NO
  AND       t.PROD_CD = a1.PROD_CD
  LEFT JOIN DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP2    a2
  ON        NVL(t.BRH_NO,a1.BRH_NO) = a2.BRH_NO
  AND       NVL(t.PROD_CD,a1.PROD_CD) = a2.PROD_CD
  LEFT JOIN DDW_PROD.T_DDW_INR_ORG_BRH                    a3
  ON        NVL(t.BRH_NO,a1.BRH_NO) = a3.BRH_NO
  AND       a3.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN  (SELECT SUBSTR('%d{yyyyMMdd}',1,6) as YEAR_MON,COUNT(1) as DAYS  
              FROM EDW_PROD.T_EDW_T99_TRD_DATE  
			  WHERE BUS_DATE = %d{yyyyMMdd}
			  AND   SUBSTR(CAST(NAT_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			  GROUP BY YEAR_MON
			  )              a4 
  ON           NVL(t.YEAR_MON,a1.YEAR_MON) = a4.YEAR_MON 
  WHERE     a3.BRH_NO IS NOT NULL
 ;
 --插入代销基金，国君自管,公司自管,金融产品理财
 --------------插入数据-------------------
INSERT INTO DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON
(
                                    BRH_NO                     --营业部
                                   ,PROD_CD                    --产品代码
								   ,PROD_CGY                   --产品类别
                                   ,PRCH_AMT                   --申购金额
                                   ,RDMPT_AMT                  --赎回金额
                                   ,SCRP_AMT                   --认购金额
                                   ,RTAN_AMT_AMT_GT            --累计保有量金额
								   ,AVGDLY_AMT                 --日均金额(自然日)
                                   ,PRCH_SHR                   --申购份额
                                   ,RDMPT_SHR                  --赎回份额
                                   ,SCRP_SHR                   --认购份额
                                   ,RTAN_AMT_SHR_GT            --累计保有量份额
								   ,AVGDLY_QTY                 --日均数量(自然日)
                                   ,PRCH_CUST_VOL              --申购客户数
                                   ,RDMPT_CUST_VOL             --赎回客户数
                                   ,SCRP_CUST_VOL              --认购客户数
								   ,FNL_SHR                    --期末份额
								   ,FNL_AMT                    --期末金额
								   ,BNS_AMT                    --红利金额
                                   ,ETL_DT                     --加载日期
 )
 partition(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT
                                    NVL(t.BRH_NO,a1.BRH_NO)                                 as BRH_NO                     --营业部
                                   ,NVL(t.PROD_CD_AGGR,a1.PROD_CD_AGGR)                     as PROD_CD                    --产品代码
								   ,NVL(t.PROD_CD_AGGR,a1.PROD_CD_AGGR)                     as PROD_CGY                   --产品类别
                                   ,SUM(NVL(a1.PRCH_AMT,0))                                 as PRCH_AMT                   --申购金额
                                   ,SUM(NVL(a1.RDMPT_AMT,0))                                as RDMPT_AMT                  --赎回金额
                                   ,SUM(NVL(a1.SCRP_AMT,0))                                 as SCRP_AMT                   --认购金额
                                   ,SUM(NVL(t.RTAN_AMT_AMT_GT,0))                           as RTAN_AMT_AMT_GT            --累计保有量金额
								   ,SUM(ROUND(NVL(t.RTAN_AMT_AMT_GT,0)*1.000/a4.DAYS,2))    as AVGDLY_AMT                 --日均金额(自然日)
                                   ,SUM(NVL(a1.PRCH_SHR,0))                                 as PRCH_SHR                   --申购份额
                                   ,SUM(NVL(a1.RDMPT_SHR,0))                                as RDMPT_SHR                  --赎回份额
                                   ,SUM(NVL(a1.SCRP_SHR,0))                                 as SCRP_SHR                   --认购份额
                                   ,SUM(NVL(t.RTAN_AMT_SHR_GT,0))                           as RTAN_AMT_SHR_GT            --累计保有量份额
								   ,SUM(ROUND(NVL(t.RTAN_AMT_SHR_GT,0)*1.000/a4.DAYS,2))    as AVGDLY_QTY                 --日均数量(自然日)
                                   ,SUM(NVL(a2.PRCH_CUST_VOL,0))                            as PRCH_CUST_VOL              --申购客户数
                                   ,SUM(NVL(a2.RDMPT_CUST_VOL,0))                           as RDMPT_CUST_VOL             --赎回客户数
                                   ,SUM(NVL(a2.SCRP_CUST_VOL,0))                            as SCRP_CUST_VOL              --认购客户数
                                   ,SUM(NVL(t.FNL_SHR,0))                                   as FNL_SHR                    --期末份额
								   ,SUM(NVL(t.FNL_AMT,0))                                   as FNL_AMT                    --期末金额
								   ,SUM(NVL(a1.BNS_AMT,0))                                   as BNS_AMT                    --红利金额
								  ,%d{yyyyMMdd}                                                as ETL_DT                     --加载日期



  FROM      DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP     t
  FULL JOIN DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP1    a1
  ON        t.BRH_NO = a1.BRH_NO
  AND       t.PROD_CD_AGGR = a1.PROD_CD_AGGR
  LEFT JOIN DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP2    a2
  ON        NVL(t.BRH_NO,a1.BRH_NO) = a2.BRH_NO
  AND       NVL(t.PROD_CD_AGGR,a1.PROD_CD_AGGR) = a2.PROD_CD_AGGR
  LEFT JOIN DDW_PROD.T_DDW_INR_ORG_BRH                    a3
  ON        NVL(t.BRH_NO,a1.BRH_NO) = a3.BRH_NO
  AND       a3.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN  (SELECT SUBSTR('%d{yyyyMMdd}',1,6) as YEAR_MON,COUNT(1) as DAYS  
              FROM EDW_PROD.T_EDW_T99_TRD_DATE  
			  WHERE BUS_DATE = %d{yyyyMMdd}
			  AND   SUBSTR(CAST(NAT_DT as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			  GROUP BY YEAR_MON
			  )              a4 
  ON           NVL(t.YEAR_MON,a1.YEAR_MON) = a4.YEAR_MON 
  WHERE     a3.BRH_NO IS NOT NULL
  GROUP BY BRH_NO,PROD_CD,ETL_DT,PROD_CGY
 ;

---------------- 插入数据结束 -----------------------

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP1;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON_TEMP2;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_PROD_AGGR_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_MON;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:质押回购黑名单表                                                                   */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 

 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TZYHG_HMD ;

-----插入数据开始-----------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZYHG_HMD(
                                    KHH                                 --客户号                                
                                   ,TYPE                                --类型                                 
                                   ,ZJYT                                --资金用途                               
                                   ,ZQDM                                --证券代码                               
                                   ,DJRQ                                --登记日期                               
                                   ,XGRQ                                --修改日期                               
                                   ,SHBZ                                --审核标志
								   ,BY1
								   ,BY2
								   ,MDBZ
								   ,GZLB
								   ,WYJE
								   ,FSRQ
								   ,GZBZ
								   ,BZ
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.TYPE                                as TYPE                                --类型                                  
                                   ,t.ZJYT                                as ZJYT                                --资金用途                                
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.XGRQ                                as XGRQ                                --修改日期                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.SHBZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as SHBZ                                --审核标志              
                                   ,t.BY1 	                              as BY1
								   ,t.BY2                                 as BY2
								   ,t.MDBZ		                          as MDBZ
								   ,t.GZLB                                as GZLB
								   ,t.WYJE		                          as WYJE
								   ,t.FSRQ                 		          as FSRQ
								   ,t.GZBZ                                as GZBZ
								   ,t.BZ	                              as BZ
                                   ,'JZJY'								  as XTBS
 FROM           JZJYCX.SECURITIES_TZYHG_HMD                t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING     t1 
 ON             t1.DMLX = 'SHBZ'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.SHBZ AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---------插入数据结束------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZYHG_HMD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

invalidate metadata EDW_PROD.T_EDW_T02_TZYHG_HMD;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:产品历史份额                                                                 */
  --/* 创建人:段智泓                                                                             */
  --/* 创建时间:2018-08-29                                                                 */ 

-------插入数据开始--------------

INSERT OVERWRITE EDW_PROD.T_EDW_T02_TFP_CPFE_LS
(
                                 CPDM	           --产品代码 
                                ,JGDM	           --发行机构代码 
                                ,YYB	           --营业部
                                ,KHH	           --客户号 
                                ,KHXM	           --客户姓名
                                ,TZZH	           --投资帐号
                                ,CPFL	           --产品大类
                                ,CPFE	           --产品份额(金额)
                                ,DJFE	           --冻结份额(金额)
                                ,CCCB	           --持仓成本
                                ,ZXSZ	           --最新市值
                                ,BDRQ	           --份额变动日期
                                ,KCRQ	           --首次购买日期
                                ,TJRQ	           --统计日期
                                ,SFFS	           --收费方式
                                ,JYZH	           --交易账号
                                ,JSLX	           --结算类型
                                ,TKJC	           --???
                                ,DRDJFE            --当日冻结份额
                                ,LJSY	           --累计份额
								,XTBS              --系统标识
)
PARTITION( bus_date = %d{yyyyMMdd})
SELECT                           
                                 t.CPDM	as CPDM    --产品代码             
                                ,t.JGDM	as JGDM    --发行机构代码 
                                ,CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))	as YYB   --营业部
                                ,t.KHH	    as KHH     --客户号 
                                ,t.KHXM	as KHXM    --客户姓名
                                ,t.TZZH	as TZZH    --投资帐号
                                ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.CPFL AS VARCHAR(20))),'ERR')) AS DECIMAL(4,0))	as CPFL  --产品大类
                                ,t.CPFE	as CPFE	   --产品份额(金额)
                                ,t.DJFE	as DJFE	   --冻结份额(金额)
                                ,t.CCCB	as CCCB	   --持仓成本
                                ,t.ZXSZ	as ZXSZ	   --最新市值
                                ,t.BDRQ	as BDRQ	   --份额变动日期
                                ,t.KCRQ	as KCRQ	   --首次购买日期
                                ,t.TJRQ	as TJRQ	   --统计日期
                                ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.SFFS	 AS VARCHAR(20))),'ERR')) AS DECIMAL(22,0)) as SFFS	 --收费方式
                                ,t.JYZH	as JYZH	   --交易账号
                                ,CAST(COALESCE(t5.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX	 AS VARCHAR(20))),'ERR')) AS DECIMAL(12,0)) as JSLX	 --结算类型
                                ,t.TKJC	as TKJC	   --???
                                ,t.DRDJFE  as DRDJFE  --当日冻结份额
                                ,t.LJSY	as LJSY	   --累计份额
								,'OTC'   AS XTBS
FROM OTCCX.FPSS_HIS_TFP_CPFE_LS t
LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t1
ON             t1.YXT = 'OTC'
AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3
ON             t3.DMLX = 'OTC_CPFL'
AND            t3.YXT = 'OTC'
AND            t3.YDM = CAST(t.CPFL AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t4
ON             t4.DMLX = 'OTC_SFFS'
AND            t4.YXT = 'OTC'
AND            t4.YDM = CAST(t.SFFS AS VARCHAR(20))
LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t5
ON             t5.DMLX = 'OTC_JSLX'
AND            t5.YXT = 'OTC'
AND            t5.YDM = CAST(t.JSLX AS VARCHAR(20))
WHERE          t.DT = '%d{yyyyMMdd}';
----------插入数据结束------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TFP_CPFE_LS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TFP_CPFE_LS;
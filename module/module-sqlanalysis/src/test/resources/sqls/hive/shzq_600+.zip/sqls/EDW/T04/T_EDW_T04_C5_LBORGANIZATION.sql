 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:岗位成员表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
-----------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T04_C5_LBORGANIZATION(
                       FID     
                      ,GRADE   
                      ,TYPET    
                      ,ORGTYPE 
                      ,ORGCODE 
                      ,NAME    
                      ,FDNCODE 
                      ,ID      
                      ,JNSEQ   
                      ,PYDM    
                      ,DESCRIBED
                      ,DQFL    
                      ,GLDQ    
                      ,YYBFL   
                      ,PROVINCE
                      ,CITY    
                      ,RQ      
                      ,NOTE    
                      ,SX      
                      ,ZXDH    
                      ,DZ      
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                       t.FID     
                      ,t.GRADE   
                      ,t.TYPE    
                      ,t.ORGTYPE 
                      ,t.ORGCODE 
                      ,t.NAME    
                      ,t.FDNCODE 
                      ,t.ID      
                      ,t.JNSEQ   
                      ,t.PYDM    
                      ,t.DESCRIBE
                      ,t.DQFL    
                      ,t.GLDQ    
                      ,t.YYBFL   
                      ,t.PROVINCE
                      ,t.CITY    
                      ,t.RQ      
                      ,t.NOTE    
                      ,t.SX      
                      ,t.ZXDH    
                      ,t.DZ      
 FROM       C5CX.SPIF_LBORGANIZATION    t
 WHERE      t.DT = '%d{yyyyMMdd}';
----插入数据结束--------------
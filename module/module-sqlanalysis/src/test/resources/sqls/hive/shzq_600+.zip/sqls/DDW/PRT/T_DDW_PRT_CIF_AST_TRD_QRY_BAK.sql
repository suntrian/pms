TRUNCATE TABLE DDW_PROD.T_DDW_PRT_CIF_AST_TRD_QRY ;
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_CIF_AST_TRD_QRY
  (
            CUST_NO                                     --客户号		 
           ,CUST_NAME                                   --客户姓名		
           ,NET_AST_AVG_10                              --10日日均净资产            
           ,NET_AST_AVG_20                              --20日日均净资产                          
           ,NET_AST                                     --净资产                           
           ,AST                                         --资产	
 ) 
PARTITION( BUS_DATE )
SELECT 
            CUST_NO                                     --客户号		 
           ,CUST_NAME                                   --客户姓名		
           ,NET_AST_AVG_10                              --10日日均净资产            
           ,NET_AST_AVG_20                              --20日日均净资产                          
           ,NET_AST                                     --净资产                           
           ,AST                                         --资产
		   ,BUS_DATE    as BUS_DATE
FROM DDW_PROD.T_DDW_PRT_CIF_AST_TRD_QRY1 ;
 invalidate metadata DDW_PROD.T_DDW_PRT_CIF_AST_TRD_QRY1 ;
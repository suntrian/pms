   --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户对账单个股盈亏汇总年表                                                        */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-02-02                                                                        */ 
-----删除今年的数据---  
 INSERT OVERWRITE DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_AGGR_YEAR
(
                                  
			CUST_NO           --客户号
           ,PAYOF_AMT         --盈亏金额
		   ,LOSS_AMT          --亏损金额
		   ,PAYOF_NBRS        --盈利只数
		   ,LOSS_NBRS         --亏损只数
		   ,ETL_DT            --加载日期
) 
 partition(YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)  )
 SELECT t.CUST_NO              as CUST_NO           --客户号
        ,SUM(CASE WHEN TOT_PRET_RMB > = 0 
              THEN TOT_PRET_RMB
			  ELSE 0 
			  END)             as PAYOF_AMT         --盈亏金额
        ,SUM(CASE WHEN TOT_PRET_RMB < 0 
              THEN TOT_PRET_RMB
			  ELSE 0 
			  END)             as LOSS_AMT          --亏损金额
        ,SUM(CASE WHEN TOT_PRET_RMB > = 0 
              THEN 1
			  ELSE 0 
			  END) as PAYOF_NBRS        --盈利只数
        ,SUM(CASE WHEN TOT_PRET_RMB < 0 
              THEN 1
			  ELSE 0 
			  END)        as LOSS_NBRS         --亏损只数
		,%d{yyyyMMdd}   as ETL_DT            --加载日期
  
 FROM DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_YEAR t
 WHERE t.YEAR = CAST(SUBSTR('%d{yyyyMMdd}',1,4) as INT)
 GROUP BY CUST_NO,ETL_DT ;
 
-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_STATMT_PER_PRET_STK_AGGR_YEAR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_CUST_STATMT_PER_PRET_STK_AGGR_YEAR;
 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:洗钱等级调整表                                                                     */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */
  /* T_DDW_F05_CIF_CUST_OPE_DETAIL  修改为   T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS             */
  

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_M_LAUND_LVL_CHANGE
(        
								 BRH_NO                     --营业部编码
								,BRH_NAME                   --营业部名称
								,DT                         --日期      
								,CUST_NO                    --客户号    
								,CUST_NAME                  --客户姓名  
								,OLD_VAL                    --旧值      
								,NEW_VAL                    --新值
                                ,OPER                       --操作人员								
								,ABST                       --摘要      						       						 				
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
					 t.BRH_NO                           AS BRH_NO                     --营业部编码   
					,t.BRH_NAME                         AS BRH_NAME                   --营业部名称   
					,t.DT                               AS DT                         --日期         
					,t.CUST_NO                          AS CUST_NO                    --客户号       
					,t.CUST_NAME                        AS CUST_NAME                  --客户姓名     
					,SUBSTR(t.ABST,instr(t.ABST,'等级:')+7,instr(t.ABST,'->')-instr(t.ABST,'等级:')-7)          AS OLD_VAL                    --旧值         
					,SUBSTR(t.ABST,instr(t.ABST,'->')+2,instr(t.ABST,']')-instr(t.ABST,'->')-2)                 AS NEW_VAL                    --新值 
                    ,t.OPRT_TELR                        AS OPER                       --操作人员					
					,t.ABST                             AS ABST                       --摘要         
			        
  FROM  		DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS     t
  WHERE 		t.bus_date = %d{yyyyMMdd}
  AND           t.BIZ_SBJ = '20097'
  AND           t.ABST <> '客户反洗钱信息修改[]'
  AND           t.ABST LIKE '%风险%'
  ;
  ------结束----
  

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_M_LAUND_LVL_CHANGE',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_M_LAUND_LVL_CHANGE;
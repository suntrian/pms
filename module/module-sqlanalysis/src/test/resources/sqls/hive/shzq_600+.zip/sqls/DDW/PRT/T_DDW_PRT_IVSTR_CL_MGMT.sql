 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:投资者分类管理                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-04-23                                                                        */ 
 

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_IVSTR_CL_MGMT
(
								    JOUR_NO                     --流水号                                
                                   ,DT                          --日期 
                                   ,TM                          --发生时间
								   ,CUST_NO                     --客户号                
                                   ,CUST_NAME                   --客户姓名 
								   ,CPTL_ACTNO                  --资金账号
								   ,BIZ_SBJ                     --业务科目
                                   ,BIZ_SBJ_NAME                --业务科目名称
								   ,ABST                        --摘要
								   ,OPRT_TELR                   --操作柜员
								   ,BRH_NO                      --营业部编号              
                                   ,BRH_NAME                    --营业部名称  
								   ,OCC_BRH_NO                  --发生营业部
								   ,OCC_BRH_NAME                --发生营业部名称
								   ,OPRT_SITE                   --操作站点
								   ,SPNS_CNL				    --发起渠道
								   ,OPST_JOUR_NO			    --对方流水号
								   ,BIZ_APL_NO                  --业务申请号

								   
								   
								   
)		
 PARTITION(bus_date=%d{yyyyMMdd})
  SELECT 
								 t.JOUR_NO    			     AS JOUR_NO                     --流水号  
								,t.DT                        AS DT                          --日期 
								,t.TM                        AS TM                          --发生时间
								,t.CUST_NO                   AS CUST_NO                     --客户号          
								,t.CUST_NAME                 AS CUST_NAME                   --客户姓名 
								,t.CPTL_ACTNO                AS CPTL_ACTNO                  --资金账号
                                ,t.BIZ_SBJ                   AS BIZ_SBJ                     --业务科目
                                ,t.BIZ_SBJ_NAME              AS BIZ_SBJ_NAME                --业务科目名称
                                ,t.ABST                      AS ABST                        --摘要
                                ,t.OPRT_TELR                 AS OPRT_TELR                   --操作柜员
                                ,t.BRH_NO                    AS BRH_NO                      --营业部编号      
                                ,NVL(a4.BRH_SHRTNM,a5.FILIL_DEPT_SHRTNM)    AS BRH_NAME                    --营业部名称  
                                ,t.OCC_BRH_NO                AS OCC_BRH_NO                  --发生营业部
                                ,NVL(a6.BRH_SHRTNM,a7.FILIL_DEPT_SHRTNM)                             AS OCC_BRH_NAME                --发生营业部名称
                                ,t.OPRT_SITE                 AS OPRT_SITE                   --操作站点
                                ,CAST(t.SPNS_CNL as STRING)  AS SPNS_CNL				    --发起渠道
                                ,t.OPST_JOUR_NO              AS OPST_JOUR_NO			    --对方流水号
                                ,t.BIZ_RQM_ID                AS BIZ_APL_NO                  --业务申请号
  
  
  
  FROM  		DDW_PROD.T_DDW_F00_CUST_CIF_SRC_OPE_DETAIL_HIS	t
 --LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a1
 -- ON            t.KHH = a1.CUST_NO
 -- AND           a1.BUS_DATE = %d{yyyyMMdd}
 -- LEFT JOIN    EDW_PROD.T_EDW_T99_TYGTYWKM                a2
 -- ON           t.YWKM = a2.YWKM
 -- AND          a2.bus_date = %d{yyyyMMdd}
 -- LEFT JOIN    EDW_PROD.T_EDW_T02_TUSER                    a3
 -- ON           t.CZGY = a3.TUSER_ID
 -- AND          a3.bus_date = %d{yyyyMMdd}
  LEFT JOIN    DDW_PROD.T_DDW_INR_ORG_BRH                a4
  ON            t.BRH_NO = a4.BRH_NO   
  AND           a4.BUS_DATE = %d{yyyyMMdd} 
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a5
  ON            t.BRH_NO = a5.FILIL_DEPT_CDG
  AND           a5.BUS_DATE = %d{yyyyMMdd}
   LEFT JOIN    DDW_PROD.T_DDW_INR_ORG_BRH                a6
  ON            t.OCC_BRH_NO = a6.BRH_NO   
  AND           a6.BUS_DATE = %d{yyyyMMdd} 
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a7
  ON            t.OCC_BRH_NO = a7.FILIL_DEPT_CDG
  AND           a7.BUS_DATE = %d{yyyyMMdd}    
  WHERE 		t.bus_date = %d{yyyyMMdd}
  AND           t.BIZ_SBJ BETWEEN '20035' AND '20038'
  ;

 
-----------------------------加载结束--------------------
  
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_IVSTR_CL_MGMT',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_IVSTR_CL_MGMT ;
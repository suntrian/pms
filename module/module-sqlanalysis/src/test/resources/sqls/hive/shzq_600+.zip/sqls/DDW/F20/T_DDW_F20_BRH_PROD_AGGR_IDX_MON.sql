------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:营业部产品汇总指标月表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2019-05-21                                                                       */

--IF_MAIN  0--不重要 1-重要 2-全部
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON_TEMP as
SELECT         BELTO_FILIL_CDG                                                    --分公司编码
             , BELTO_FILIL                                                        --分公司名称
             , BRH_NO                                                             --营业部编码
             , BRH_FULLNM                                                         --营业部名称
             , IF_MAIN                                                            --是否重要销售
             , SUM(ETMT_PUB_PROD_SALE)         as ETMT_PUB_PROD_SALE              --权益类公募销量
			 , SUM(BOND_PUB_PROD_SALE)         as BOND_PUB_PROD_SALE              --债券类公募销量
             , SUM(CCY_PUB_PROD_SALE)          as CCY_PUB_PROD_SALE               --货币类公募销量
			 , SUM(FND_SPELACT_PROD_SALE)      as FND_SPELACT_PROD_SALE           --基金专产品户销量
             , SUM(PRV_FND_PROD_SALE)          as PRV_FND_PROD_SALE               --私募基金销量
             , SUM(BANK_PROD_SALE)             as BANK_PROD_SALE                  --银行产品销量
			 , SUM(GTJA_PROD_SALE)             as GTJA_PROD_SALE                  --国君产品销量
			 , SUM(SHZQ_PROD_SALE)             as SHZQ_PROD_SALE                  --公司产品销量
			 , SUM(CASH_PROD_SALE)             as CASH_PROD_SALE                  --现金添利产品销量
			 , SUM(OTC_PROD_SALE)              as OTC_PROD_SALE                   --OTC产品销量
			 , AVG(ETMT_PUB_PROD_HLD_AMT)       as AVG_ETMT_PUB_PROD_HLD_AMT       --权益类公募日均保有量			 
			 , AVG(BOND_PUB_PROD_HLD_AMT)       as AVG_BOND_PUB_PROD_HLD_AMT       --债券类公募日均保有量
             , AVG(CCY_PUB_PROD_HLD_AMT)        as AVG_CCY_PUB_PROD_HLD_AMT        --货币类公募日均保有量
			 , AVG(FND_SPELACT_PROD_HLD_AMT)    as AVG_FND_SPELACT_PROD_HLD_AMT    --基金专产品日均户保有量
             , AVG(PRV_FND_PROD_HLD_AMT)        as AVG_PRV_FND_PROD_HLD_AMT        --私募基金日均保有量
             , AVG(BANK_PROD_HLD_AMT)           as AVG_BANK_PROD_HLD_AMT           --银行产品日均保有量
			 , AVG(GTJA_PROD_HLD_AMT)           as AVG_GTJA_PROD_HLD_AMT           --国君产品日均保有量
			 , AVG(SHZQ_PROD_HLD_AMT)           as AVG_SHZQ_PROD_HLD_AMT           --公司产品日均保有量
			 , AVG(CASH_PROD_HLD_AMT)           as AVG_CASH_PROD_HLD_AMT           --现金添利产品日均保有量
			 , AVG(OTC_PROD_HLD_AMT)            as AVG_OTC_PROD_HLD_AMT            --OTC产品日均保有量
			 
			 
FROM DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY 
WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
GROUP BY   BELTO_FILIL_CDG     
         , BELTO_FILIL         
         , BRH_NO              
         , BRH_FULLNM          
         , IF_MAIN  
 ;	

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON_TEMP1 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON_TEMP1 as
SELECT         a.BELTO_FILIL_CDG                            --分公司编码
             , a.BELTO_FILIL                                --分公司名称
             , a.BRH_NO                                     --营业部编码
             , a.BRH_FULLNM                                 --营业部名称
             , a.IF_MAIN                                    --是否重要销售
			 , a.ETMT_PUB_PROD_HLD_AMT      as STRT_ETMT_PUB_PROD_HLD_AMT       --权益类公募期初保有量			 
			 , a.BOND_PUB_PROD_HLD_AMT      as STRT_BOND_PUB_PROD_HLD_AMT       --债券类公募期初保有量
             , a.CCY_PUB_PROD_HLD_AMT       as STRT_CCY_PUB_PROD_HLD_AMT        --货币类公募期初保有量
			 , a.FND_SPELACT_PROD_HLD_AMT   as STRT_FND_SPELACT_PROD_HLD_AMT    --基金专产品户期初保有量
             , a.PRV_FND_PROD_HLD_AMT       as STRT_PRV_FND_PROD_HLD_AMT        --私募基金期初保有量
             , a.BANK_PROD_HLD_AMT          as STRT_BANK_PROD_HLD_AMT           --银行产品期初保有量
			 , a.GTJA_PROD_HLD_AMT          as STRT_GTJA_PROD_HLD_AMT           --国君产品期初保有量
			 , a.SHZQ_PROD_HLD_AMT          as STRT_SHZQ_PROD_HLD_AMT           --公司产品期初保有量
			 , a.CASH_PROD_HLD_AMT          as STRT_CASH_PROD_HLD_AMT           --现金添利产品期初保有量
			 , a.OTC_PROD_HLD_AMT           as STRT_OTC_PROD_HLD_AMT            --OTC产品期初保有量
			 
			 
 FROM        DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY    a
  WHERE  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                                    FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                       WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                       AND BUS_DATE = %d{yyyyMMdd}
				                   )  b
                     WHERE  a.BUS_DATE = b.MON_START
				      )
AND  SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)  
 ;	

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON_TEMP2 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON_TEMP2 as
SELECT         a.BELTO_FILIL_CDG                            --分公司编码
             , a.BELTO_FILIL                                --分公司名称
             , a.BRH_NO                                     --营业部编码
             , a.BRH_FULLNM                                 --营业部名称
             , a.IF_MAIN                                    --是否重要销售
			 , a.ETMT_PUB_PROD_HLD_AMT      as FNL_ETMT_PUB_PROD_HLD_AMT       --权益类公募期末保有量			 
			 , a.BOND_PUB_PROD_HLD_AMT      as FNL_BOND_PUB_PROD_HLD_AMT       --债券类公募期末保有量
             , a.CCY_PUB_PROD_HLD_AMT       as FNL_CCY_PUB_PROD_HLD_AMT        --货币类公募期末保有量
			 , a.FND_SPELACT_PROD_HLD_AMT   as FNL_FND_SPELACT_PROD_HLD_AMT    --基金专产品户期末保有量
             , a.PRV_FND_PROD_HLD_AMT       as FNL_PRV_FND_PROD_HLD_AMT        --私募基金期末保有量
             , a.BANK_PROD_HLD_AMT          as FNL_BANK_PROD_HLD_AMT           --银行产品期末保有量
			 , a.GTJA_PROD_HLD_AMT          as FNL_GTJA_PROD_HLD_AMT           --国君产品期末保有量
			 , a.SHZQ_PROD_HLD_AMT          as FNL_SHZQ_PROD_HLD_AMT           --公司产品期末保有量
			 , a.CASH_PROD_HLD_AMT          as FNL_CASH_PROD_HLD_AMT           --现金添利产品期末保有量
			 , a.OTC_PROD_HLD_AMT           as FNL_OTC_PROD_HLD_AMT            --OTC产品期末保有量
			 
			 
 FROM        DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_DAY    a
  WHERE  a.BUS_DATE = %d{yyyyMMdd} 
 ;	  
INSERT OVERWRITE DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON
(              BELTO_FILIL_CDG                    --分公司编码
             , BELTO_FILIL                        --分公司名称
             , BRH_NO                             --营业部编码
             , BRH_FULLNM                         --营业部名称
             , IF_MAIN                            --是否重要销售
             , ETMT_PUB_PROD_SALE                 --权益类公募销量
			 , BOND_PUB_PROD_SALE                 --债券类公募销量
             , CCY_PUB_PROD_SALE                  --货币类公募销量
			 , FND_SPELACT_PROD_SALE              --基金专产品户销量
             , PRV_FND_PROD_SALE                  --私募基金销量
             , BANK_PROD_SALE                     --银行产品销量
			 , GTJA_PROD_SALE                     --国君产品销量
			 , SHZQ_PROD_SALE                     --公司产品销量
			 , CASH_PROD_SALE                     --现金添利产品销量
			 , OTC_PROD_SALE                      --OTC产品销量
			 , STRT_ETMT_PUB_PROD_HLD_AMT         --权益类公募期初保有量			 
			 , STRT_BOND_PUB_PROD_HLD_AMT         --债券类公募期初保有量
             , STRT_CCY_PUB_PROD_HLD_AMT          --货币类公募期初保有量
			 , STRT_FND_SPELACT_PROD_HLD_AMT      --基金专产品户期初保有量
             , STRT_PRV_FND_PROD_HLD_AMT          --私募基金期初保有量
             , STRT_BANK_PROD_HLD_AMT             --银行产品期初保有量
			 , STRT_GTJA_PROD_HLD_AMT             --国君产品期初保有量
			 , STRT_SHZQ_PROD_HLD_AMT             --公司产品期初保有量
			 , STRT_CASH_PROD_HLD_AMT             --现金添利产品期初保有量
			 , STRT_OTC_PROD_HLD_AMT              --OTC产品期初保有量
			 , FNL_ETMT_PUB_PROD_HLD_AMT          --权益类公募期末保有量			 
			 , FNL_BOND_PUB_PROD_HLD_AMT          --债券类公募期末保有量
             , FNL_CCY_PUB_PROD_HLD_AMT           --货币类公募期末保有量
			 , FNL_FND_SPELACT_PROD_HLD_AMT       --基金专产品户期末保有量
             , FNL_PRV_FND_PROD_HLD_AMT           --私募基金期末保有量
             , FNL_BANK_PROD_HLD_AMT              --银行产品期末保有量
			 , FNL_GTJA_PROD_HLD_AMT              --国君产品期末保有量
			 , FNL_SHZQ_PROD_HLD_AMT              --公司产品期末保有量
			 , FNL_CASH_PROD_HLD_AMT              --现金添利产品期末保有量
			 , FNL_OTC_PROD_HLD_AMT               --OTC产品期末保有量			 
			 , AVG_ETMT_PUB_PROD_HLD_AMT          --权益类公募日均保有量			 
			 , AVG_BOND_PUB_PROD_HLD_AMT          --债券类公募日均保有量
             , AVG_CCY_PUB_PROD_HLD_AMT           --货币类公募日均保有量
			 , AVG_FND_SPELACT_PROD_HLD_AMT       --基金专产品日均户保有量
             , AVG_PRV_FND_PROD_HLD_AMT           --私募基金日均保有量
             , AVG_BANK_PROD_HLD_AMT              --银行产品日均保有量
			 , AVG_GTJA_PROD_HLD_AMT              --国君产品日均保有量
			 , AVG_SHZQ_PROD_HLD_AMT              --公司产品日均保有量
			 , AVG_CASH_PROD_HLD_AMT              --现金添利产品日均保有量
			 , AVG_OTC_PROD_HLD_AMT               --OTC产品日均保有量
			 , ETL_DT                                   
 ) PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT) )
 SELECT        t.BELTO_FILIL_CDG                    --分公司编码
             , t.BELTO_FILIL                        --分公司名称
             , t.BRH_NO                             --营业部编码
             , t.BRH_FULLNM                         --营业部名称
             , t.IF_MAIN                            --是否重要销售
             , t.ETMT_PUB_PROD_SALE                 --权益类公募销量
			 , t.BOND_PUB_PROD_SALE                 --债券类公募销量
             , t.CCY_PUB_PROD_SALE                  --货币类公募销量
			 , t.FND_SPELACT_PROD_SALE              --基金专产品户销量
             , t.PRV_FND_PROD_SALE                  --私募基金销量
             , t.BANK_PROD_SALE                     --银行产品销量
			 , t.GTJA_PROD_SALE                     --国君产品销量
			 , t.SHZQ_PROD_SALE                     --公司产品销量
			 , t.CASH_PROD_SALE                     --现金添利产品销量
			 , t.OTC_PROD_SALE                      --OTC产品销量
			 , NVL(a1.STRT_ETMT_PUB_PROD_HLD_AMT,0)         --权益类公募期初保有量			 
			 , NVL(a1.STRT_BOND_PUB_PROD_HLD_AMT,0)         --债券类公募期初保有量
             , NVL(a1.STRT_CCY_PUB_PROD_HLD_AMT,0)          --货币类公募期初保有量
			 , NVL(a1.STRT_FND_SPELACT_PROD_HLD_AMT,0)      --基金专产品户期初保有量
             , NVL(a1.STRT_PRV_FND_PROD_HLD_AMT,0)          --私募基金期初保有量
             , NVL(a1.STRT_BANK_PROD_HLD_AMT,0)             --银行产品期初保有量
			 , NVL(a1.STRT_GTJA_PROD_HLD_AMT,0)             --国君产品期初保有量
			 , NVL(a1.STRT_SHZQ_PROD_HLD_AMT,0)             --公司产品期初保有量
			 , NVL(a1.STRT_CASH_PROD_HLD_AMT,0)             --现金添利产品期初保有量
			 , NVL(a1.STRT_OTC_PROD_HLD_AMT,0)              --OTC产品期初保有量
			 , NVL(a2.FNL_ETMT_PUB_PROD_HLD_AMT,0)          --权益类公募期末保有量			 
			 , NVL(a2.FNL_BOND_PUB_PROD_HLD_AMT,0)          --债券类公募期末保有量
             , NVL(a2.FNL_CCY_PUB_PROD_HLD_AMT,0)           --货币类公募期末保有量
			 , NVL(a2.FNL_FND_SPELACT_PROD_HLD_AMT,0)       --基金专产品户期末保有量
             , NVL(a2.FNL_PRV_FND_PROD_HLD_AMT,0)           --私募基金期末保有量
             , NVL(a2.FNL_BANK_PROD_HLD_AMT,0)              --银行产品期末保有量
			 , NVL(a2.FNL_GTJA_PROD_HLD_AMT,0)              --国君产品期末保有量
			 , NVL(a2.FNL_SHZQ_PROD_HLD_AMT,0)              --公司产品期末保有量
			 , NVL(a2.FNL_CASH_PROD_HLD_AMT,0)              --现金添利产品期末保有量
			 , NVL(a2.FNL_OTC_PROD_HLD_AMT,0)               --OTC产品期末保有量			 
			 , t.AVG_ETMT_PUB_PROD_HLD_AMT          --权益类公募日均保有量			 
			 , t.AVG_BOND_PUB_PROD_HLD_AMT          --债券类公募日均保有量
             , t.AVG_CCY_PUB_PROD_HLD_AMT           --货币类公募日均保有量
			 , t.AVG_FND_SPELACT_PROD_HLD_AMT       --基金专产品日均户保有量
             , t.AVG_PRV_FND_PROD_HLD_AMT           --私募基金日均保有量
             , t.AVG_BANK_PROD_HLD_AMT              --银行产品日均保有量
			 , t.AVG_GTJA_PROD_HLD_AMT              --国君产品日均保有量
			 , t.AVG_SHZQ_PROD_HLD_AMT              --公司产品日均保有量
			 , t.AVG_CASH_PROD_HLD_AMT              --现金添利产品日均保有量
			 , t.AVG_OTC_PROD_HLD_AMT               --OTC产品日均保有量
			 , %d{yyyyMMdd} 
FROM DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON_TEMP t
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON_TEMP1 a1
ON     t.BRH_NO = a1.BRH_NO
AND    t.IF_MAIN = a1.IF_MAIN
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON_TEMP2 a2
ON     t.BRH_NO = a2.BRH_NO
AND    t.IF_MAIN = a2.IF_MAIN
 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON_TEMP ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON_TEMP1 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON_TEMP2 ;
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_PROD_AGGR_IDX_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F20_BRH_PROD_AGGR_IDX_MON;

-- /* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:季度手机委托活跃个人客户统计报表                                                    */
 -- /* 创建人:OYJ                                                                                   */
  --/* 创建时间:2019-08-27                                                                          */  

------插入数据
----临时表,日期处理，取每个季度末的交易日等信息
DROP TABLE IF EXISTS DDW_PROD.TRD_DATE_TMP;
CREATE TABLE DDW_PROD.TRD_DATE_TMP
AS
 SELECT
  NAT_DT
 ,TRD_DT
 ,YR
 ,QUA
 ,CASE WHEN QUA = 1 THEN CONCAT(CAST(YR AS STRING),'0101')
       WHEN QUA = 2 THEN CONCAT(CAST(YR AS STRING),'0401')
       WHEN QUA = 3 THEN CONCAT(CAST(YR AS STRING),'0701')
       WHEN QUA = 4 THEN CONCAT(CAST(YR AS STRING),'1001')
  END AS QUA_STAR_DT
 ,CASE WHEN QUA = 1 THEN CONCAT(CAST(YR AS STRING),'0331')
       WHEN QUA = 2 THEN CONCAT(CAST(YR AS STRING),'0630')
       WHEN QUA = 3 THEN CONCAT(CAST(YR AS STRING),'0930')
       WHEN QUA = 4 THEN CONCAT(CAST(YR AS STRING),'1231')
  END AS QUA_END_DT
 FROM EDW_PROD.T_EDW_T99_TRD_DATE
 WHERE SUBSTR(NVL(CAST(NAT_DT AS STRING),''),5,4) IN ('0331','0630','0930','1231')
 AND TRD_DT = %d{yyyyMMdd}
;

----临时表,数据主表，计算季度内个人客户的手机委托A股买卖交易量
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_IDV_CUST_PHONE_ODR_STATS_TMP1;
CREATE TABLE DDW_PROD.T_DDW_PRT_IDV_CUST_PHONE_ODR_STATS_TMP1
AS
SELECT
 T1.YYB
,T5.BRH_FULLNM
,T1.KHH
,T1.KHMC
,T1.KHRQ
,T1.SJ
,CASE WHEN T4.SXZ = '0' THEN '合格帐户'
      WHEN T4.SXZ = '1' THEN '资料合规个人'
      WHEN T4.SXZ = '2' THEN '资料合规机构'
      WHEN T4.SXZ = '8' THEN '一般资料不合格'
      WHEN T4.SXZ = '19' THEN '纯B股帐户'
 END AS FXJB                                                                     --9.风险级别
,CASE WHEN T1.KHLB = 0 THEN '个人' WHEN T1.KHLB = 1 THEN '机构' END AS KHLB      --20.客户类别
--,T3.BUS_DATE,T3.WTFS,T3.BUS_DATE,T3.CJJE
,SUM(T3.CJJE) AS CJJE
,t2.YR
,t2.QUA
,t2.TRD_DT
,t2.NAT_DT
FROM YGTCX.CIF_TKHXX T1
INNER JOIN DDW_PROD.TRD_DATE_TMP T2
ON T1.DT = CAST (T2.TRD_DT AS STRING)
INNER JOIN 
(
 SELECT KHH,SUM(CJJE) AS CJJE,BUS_DATE FROM EDW_PROD.T_EDW_T05_TWTLS
 WHERE WTLB IN (1,2,61,62,63,64)
   AND WTFS = 64
   and CJJE <> 0
   AND (   (LENGTH(SPLIT_PART(IP_PHONE,',',1)) = 11 AND IP_PHONE NOT LIKE '%.%')
        OR (LENGTH(SPLIT_PART(IP_PHONE,',',2)) = 11 AND IP_PHONE NOT LIKE '%.%')
       )
 GROUP BY KHH,BUS_DATE
) T3
ON T1.KHH = T3.KHH
AND T3.BUS_DATE >= CAST(T2.QUA_STAR_DT AS INT)
AND T3.BUS_DATE <= CAST(T2.QUA_END_DT AS INT)
LEFT JOIN YGTCX.CIF_TKHSX T4
ON T4.KHH = T1.KHH
AND T4.DT = T1.DT
AND T4.SXDM = 'KHFXJB'
LEFT JOIN DDW_PROD.T_DDW_INR_ORG_BRH T5
ON T5.BRH_NO = CAST(T1.YYB AS STRING)
LEFT JOIN YGTCX.CIF_TXTDM T6
ON T1.ZJLB = T6.IBM
AND T6.DT = T1.DT
AND T6.FLDM = 'GT_ZJLB'
WHERE T1.DT = '%d{yyyyMMdd}'
AND T1.KHZT IN (0,99)
AND T4.SXZ IN ('0','1','2','8','19')
AND T1.KHLB = 0
GROUP BY 1,2,3,4,5,6,7,8,10,11,12,13
;

----临时表,对"季度内个人客户手机委托A股买卖交易量"进行排名
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_IDV_CUST_PHONE_ODR_STATS_TMP2;
CREATE TABLE DDW_PROD.T_DDW_PRT_IDV_CUST_PHONE_ODR_STATS_TMP2
AS
SELECT KHH,CJJE,RANK() OVER(ORDER BY CJJE DESC) AS NUM
FROM DDW_PROD.T_DDW_PRT_IDV_CUST_PHONE_ODR_STATS_TMP1
;

----插入当日数据，如不是季度末则无数据
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_IDV_CUST_PHONE_ODR_STATS
(
        BRH_NO           -- 1. 营业部编号
       ,BRH_NAME         -- 2. 营业部名称
       ,CUST_NO          -- 3. 客户号
       ,CUST_NAME        -- 4. 客户名称
       ,OPN_DT           -- 5. 开户日期
       ,PHONE_NO         -- 6. 手机号
       ,RSK_LVL          -- 7. 风险级别
       ,CUST_CGY         -- 8. 客户类别
       ,A_TRD_AMT        -- 9. A股买卖交易量
       ,YR               --10. 年份
       ,QUA              --11. 季度
       ,NAT_DT           --12. 自然日
       ,RANK_NO          --13. A股买卖交易量排名
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT 
        NVL(T2.YYB,0) AS BRH_NO          
       ,NVL(T2.BRH_FULLNM,'') AS BRH_NAME
       ,NVL(T1.KHH,'') AS CUST_NO
       ,NVL(T2.KHMC,'') AS CUST_NAME
       ,NVL(T2.KHRQ,0) AS OPN_DT
       ,NVL(T2.SJ,'') AS PHONE_NO
       ,NVL(T2.FXJB,'') AS RSK_LVL
       ,NVL(T2.KHLB,'') CUST_CGY
       ,NVL(T1.CJJE,0) AS A_TRD_AMT
	   ,NVL(T2.YR,0) AS YR
       ,NVL(T2.QUA,0) AS QUA
       ,NVL(T2.NAT_DT,0) AS NAT_DT
	   ,NVL(T1.NUM,0) AS RANK_NO
FROM DDW_PROD.T_DDW_PRT_IDV_CUST_PHONE_ODR_STATS_TMP2 T1
INNER JOIN DDW_PROD.T_DDW_PRT_IDV_CUST_PHONE_ODR_STATS_TMP1 T2
ON T1.KHH = T2.KHH
WHERE T2.TRD_DT = %d{yyyyMMdd}
AND T1.NUM <= 300
;

-------插入数据结束

DROP TABLE IF EXISTS DDW_PROD.TRD_DATE_TMP;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_IDV_CUST_PHONE_ODR_STATS_TMP1;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_IDV_CUST_PHONE_ODR_STATS_TMP2;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_IDV_CUST_PHONE_ODR_STATS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

INVALIDATE METADATA DDW_PROD.T_DDW_PRT_IDV_CUST_PHONE_ODR_STATS;

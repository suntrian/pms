-- /* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:反洗钱需求明细报表_电商                                                        		*/
 -- /* 创建人:OYJ                                                                                   */
  --/* 创建时间:2019-09-12                                                                          */  

TRUNCATE TABLE DDW_PROD.T_DDW_PRT_KHMX_FXQ_DS;

------插入数据

INSERT OVERWRITE DDW_PROD.T_DDW_PRT_KHMX_FXQ_DS
(
 BELTO_FILIL                                                             -- 1.分公司
,BRH_NO                                                                  -- 2.网点代号
,BRH_NAME                                                                -- 3.营业部名称
,CUST_NO                                                                 -- 4.客户号
,CUST_NAME                                                               -- 5.客户姓名
,CTF_TP                                                                  -- 6.证件类型
,CSRQ                                                                    -- 7.出生日期
,AGE                                                                     -- 8.年龄
,KHRQ                                                                    -- 9.开户日期
,WTFS                                                                    --10.在本公司委托方式
,IF_ACCNT_REGST                                                          --11.是否登记证券账户
,SFYJYZH                                                                 --12.三年内是否有转账或交易记录
,TOT_AST                                                                 --13.总资产
,TOT_MKTVAL                                                              --14.总市值
,TOT_CPTL                                                                --15.总资金
,FBDN_TP                                                                 --16.禁止类型
,KZSX_YWSX                                                               --17.控制属性_业务属性
,KZSX_FXKZ                                                               --18.控制属性_风险项目控制
)
PARTITION(BUS_DATE = %d{yyyyMMdd})
SELECT 
        T2.BELTO_FILIL                                                             -- 1.分公司
       ,T1.BRH_NO                                                                  -- 2.网点代号
       ,T1.BRH_NAME                                                                -- 3.营业部名称
       ,T1.CUST_NO                                                                 -- 4.客户号
       ,NVL(T3.KHMC,'') AS CUST_NAME                                               -- 5.客户姓名
       ,NVL(T4.NOTE,'') AS CTF_TP                                                  -- 6.证件类型
       ,T5.CSRQ                                                                    -- 7.出生日期
       ,CASE WHEN CAST(SUBSTR('%d{yyyyMMdd}',5,2) AS INT) > CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(T5.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
             THEN CAST(SUBSTR('%d{yyyyMMdd}',1,4) AS INT) - CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),1,4) AS INT)
             WHEN CAST(SUBSTR('%d{yyyyMMdd}',5,2) AS INT) < CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(T5.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
             THEN CAST(SUBSTR('%d{yyyyMMdd}',1,4) AS INT) - CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),1,4) AS INT) - 1
             WHEN CAST(SUBSTR('%d{yyyyMMdd}',5,2) AS INT) = CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(T5.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
              AND CAST(SUBSTR('%d{yyyyMMdd}',7,2) AS INT) >= CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),7,2) AS INT)
             THEN CAST(SUBSTR('%d{yyyyMMdd}',1,4) AS INT) - CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),1,4) AS INT)
             WHEN CAST(SUBSTR('%d{yyyyMMdd}',5,2) AS INT) = CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(T5.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
              AND CAST(SUBSTR('%d{yyyyMMdd}',7,2) AS INT) < CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),7,2) AS INT)
             THEN CAST(SUBSTR('%d{yyyyMMdd}',1,4) AS INT) - CAST(SUBSTR(CAST(NVL(T5.CSRQ,0) AS STRING),1,4) AS INT) - 1
        ELSE 0 END AS AGE                                                          -- 8.年龄
       ,T3.KHRQ                                                                    -- 9.开户日期
       ,REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(TRIM(NVL(T12.WTFS,'')),'1','电话')
                                      ,'2','磁卡')
                                      ,'3','热键')
                                      ,'4','柜台')
                                      ,'6','互联网')
                                      ,'7','手机') AS WTFS    --10.在本公司委托方式
       ,CASE WHEN T6.KHH IS NOT NULL THEN '是' ELSE '否' END AS IF_ACCNT_REGST     --11.是否登记证券账户
       ,CASE WHEN NVL(T7.KHH,'') <> '' THEN '有'
             WHEN NVL(T8.KHH,'') <> '' THEN '有'
             WHEN NVL(T9.KHH,'') <> '' THEN '有'
             WHEN NVL(T10.KHH,'') <> '' THEN '有'
        ELSE '无' END AS SFYJYZH                                                   --12.三年内是否有转账或交易记录
       ,NVL(T11.TOT_AST,0) AS TOT_AST                                              --13.总资产
       ,NVL(T11.TOT_MKTVAL,0) AS TOT_MKTVAL                                        --14.总市值
       ,NVL(T11.TOT_CPTL,0) AS TOT_CPTL                                            --15.总资金
       ,T1.FBDN_TP                                                                 --16.禁止类型
       ,REPLACE(
          REPLACE(
            REPLACE(
              REPLACE(
                REPLACE(
                  REPLACE(
                    REPLACE(
                      REPLACE(
                        REPLACE(
                          REPLACE(
                            REPLACE(
                              REPLACE(
                                REPLACE(
                                  REPLACE(NVL(T12.KZSX_YWSX,''),'16','禁止定投')
        		                ,'15','禁止转换转入')
                              ,'14','禁止申购')
                            ,'13','禁止认购')
                          ,'12','禁止清密')
                        ,'9','禁止单户资金内转')
                      ,'8','禁止卖出')
                    ,'7','禁止买入')
                  ,'6','禁止销户')
                ,'5','禁止撤指')
              ,'4','禁止转托管')
            ,'3','禁止银证转账')
          ,'2','禁止取款')
        ,'1','禁止存款') AS KZSX_YWSX                                              --17.控制属性_业务属性
       ,REPLACE(
          REPLACE(
            REPLACE(
              REPLACE(
                REPLACE(
                  REPLACE(
                    REPLACE(
                      REPLACE(
                        REPLACE(
                          REPLACE(
                            REPLACE(
                              REPLACE(
                                REPLACE(
                                  REPLACE(NVL(T13.KZSX_FXKZ,''),'16','禁止定投')
        		                ,'15','禁止转换转入')
                              ,'14','禁止申购')
                            ,'13','禁止认购')
                          ,'12','禁止清密')
                        ,'9','禁止单户资金内转')
                      ,'8','禁止卖出')
                    ,'7','禁止买入')
                  ,'6','禁止销户')
                ,'5','禁止撤指')
              ,'4','禁止转托管')
            ,'3','禁止银证转账')
          ,'2','禁止取款')
        ,'1','禁止存款') AS KZSX_FXKZ                                              --18.控制属性_风险项目控制
FROM DDW_PROD.T_DDW_PRT_CUST_DTL_FXQ_DS T1
LEFT JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
ON T2.BRH_NO = T1.BRH_NO
LEFT JOIN 
(
 SELECT KHH,KHMC,KHRQ,ZJLB
 FROM YGTCX.CIF_TKHXX
 WHERE DT = '%d{yyyyMMdd}'
) T3
ON T1.CUST_NO = T3.KHH
LEFT JOIN 
( 
 SELECT IBM,NOTE
 FROM YGTCX.CIF_TXTDM
 WHERE DT = '%d{yyyyMMdd}'
 AND FLDM = 'GT_ZJLB'
) T4
ON T3.ZJLB = T4.IBM
LEFT JOIN 
(
 SELECT KHH,CSRQ
 FROM YGTCX.CIF_TGRKHXX
 WHERE DT = '%d{yyyyMMdd}'
) T5
ON T1.CUST_NO = T5.KHH
LEFT JOIN
(
 SELECT DISTINCT KHH
 FROM YGTCX.CIF_TGDZH
 WHERE DT = '%d{yyyyMMdd}'
 AND GDZT = 0
 AND ((JYS IN (1,3,7) AND NVL(GDKZSX,'') <> '') OR JYS NOT IN (1,3,7))
) T6
ON T1.CUST_NO = T6.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM EDW_PROD.T_EDW_T05_TZJMXLS
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-3,0,0) AS INT) AND %d{yyyyMMdd}
  AND SUBSTR(YWKM,1,3) IN('101','102')
) T7
ON T1.CUST_NO = T7.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM JZJYCX.DATACENTER_TJRCP_YH_WTLS
  WHERE DT BETWEEN EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-3,0,0) AND '%d{yyyyMMdd}'
  AND YWDM IN ('020','022','024','039')
) T8
ON T1.CUST_NO = T8.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM JZJYCX.DATACENTER_TOF_JJWTLS
  WHERE DT BETWEEN EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-3,0,0) AND '%d{yyyyMMdd}'
  AND YWDM IN ('020','022','024','039')
) T9
ON T1.CUST_NO = T9.KHH
LEFT JOIN
(
  SELECT DISTINCT KHH
  FROM EDW_PROD.T_EDW_T05_TWTLS
  WHERE BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-3,0,0) AS INT) AND %d{yyyyMMdd}
  AND WTLB IN (1,2,3,4,5,29,30,41,42,43,53,57,58,59,60,61,62,63,64,71,72,78,79,83,114,115)
  AND ZQLB NOT LIKE 'F%' 
) T10
ON T1.CUST_NO = T10.KHH
LEFT JOIN
(
  SELECT CUST_NO,SUM(TOT_AST) AS TOT_AST,SUM(TOT_MKTVAL) AS TOT_MKTVAL,SUM(TOT_CPTL) AS TOT_CPTL
  FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
  WHERE BUS_DATE = %d{yyyyMMdd}
  GROUP BY CUST_NO
) T11
ON T1.CUST_NO = T11.CUST_NO
LEFT JOIN 
(
 SELECT KHH,KZSX AS KZSX_YWSX,WTFS
 FROM YGTCX.CIF_TKHYWSX
 WHERE DT = '%d{yyyyMMdd}'
) T12
ON T1.CUST_NO = T12.KHH
LEFT JOIN 
(
 SELECT KHH,KZSX AS KZSX_FXKZ
 FROM YGTCX.CIF_TKHFXXMKZ
 WHERE DT = '%d{yyyyMMdd}'
) T13
ON T1.CUST_NO = T13.KHH
;


INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_KHMX_FXQ_DS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

INVALIDATE METADATA DDW_PROD.T_DDW_PRT_KHMX_FXQ_DS;

--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:聚源采集监控表                                                                      */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */
  TRUNCATE TABLE DDW_PROD.T_DDW_FUNDEXT_CJ_MOT ;
  INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 210000
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_BOND_BASICINFO' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_BOND_BASICINFO           WHERE DT = '%d{yyyyMMdd}'
) t ;


  INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 227491
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_BOND_CODE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_BOND_CODE           WHERE DT = '%d{yyyyMMdd}'
) t ;


 INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 843
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_BOND_CONBDISSUE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_BOND_CONBDISSUE           WHERE DT = '%d{yyyyMMdd}'
) t ;

 INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 214668
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_BOND_ISSUE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_BOND_ISSUE           WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 190310
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_BOND_REDEMPTIONINFO' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_BOND_REDEMPTIONINFO           WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 50652
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_CT_SYSTEMCONST' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_CT_SYSTEMCONST           WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 6131650
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_ED_BOCEXCHANGEQUOTERT' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_ED_BOCEXCHANGEQUOTERT           WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 260649
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_HK_SECUMAIN' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_HK_SECUMAIN           WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 3945
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_ASHAREIPO' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_ASHAREIPO           WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 1658
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_ASHAREPLACEMENT' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_ASHAREPLACEMENT           WHERE DT = '%d{yyyyMMdd}'
) t ;



INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 269944
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_CODECHANGE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_CODECHANGE           WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 104675
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_DIVIDEND' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_DIVIDEND           WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 89148
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_EXGINDUSTRY' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_EXGINDUSTRY           WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 801157
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_LISTSTATUS' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_LISTSTATUS           WHERE DT = '%d{yyyyMMdd}'
) t ;




INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 167
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_STIBCODECHANGE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_STIBCODECHANGE          WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 147
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_STIBDAILYQUOTE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_STIBDAILYQUOTE          WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 279
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_STIBDIVIDEND' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_STIBDIVIDEND          WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 166
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_STIBIPOISSUE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_STIBIPOISSUE          WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 2
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_STIBNEWISSUE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_STIBNEWISSUE          WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 0
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_STIBSHAREPLACEMENT' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_STIBSHAREPLACEMENT          WHERE DT = '%d{yyyyMMdd}'
) t ;



INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 62100
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_SUSPENDRESUMPTION' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_SUSPENDRESUMPTION          WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 98
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_LC_WARRANTSUMMARY' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_LC_WARRANTSUMMARY          WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 5890
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_MF_CODERELATIONSHIPNEW' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_MF_CODERELATIONSHIPNEW          WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 18908
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_MF_DIVIDEND' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_MF_DIVIDEND          WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 13104
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_MF_FUNDARCHIVES' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_MF_FUNDARCHIVES          WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 13104
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_MF_ISSUEANDLISTING' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_MF_ISSUEANDLISTING          WHERE DT = '%d{yyyyMMdd}'
) t ;



INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 10400009
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_MF_NETVALUE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_MF_NETVALUE          WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 4096
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_MF_SHARESSPLIT' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_MF_SHARESSPLIT          WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 12082739
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_NQ_DAILYQUOTE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_NQ_DAILYQUOTE          WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 72
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_NQ_IPOISSUE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_NQ_IPOISSUE          WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 14802
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_NQ_SECUMAIN' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_NQ_SECUMAIN          WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 1481238
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_OPT_DAILYQUOTE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_OPT_DAILYQUOTE          WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 17406
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_OPT_OPTIONCONTRACT' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_OPT_OPTIONCONTRACT          WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 23184
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_QT_DAILYQUOTE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_QT_DAILYQUOTE          WHERE DT = '%d{yyyyMMdd}'
) t ;

INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 16757
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_QT_HKDAILYQUOTE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_QT_HKDAILYQUOTE          WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 	4617
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_QT_INDEXQUOTE' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_QT_INDEXQUOTE          WHERE DT = '%d{yyyyMMdd}'
) t ;


INSERT INTO DDW_PROD.T_DDW_FUNDEXT_CJ_MOT
 (
           IF_CJ             --是否采集有问题
           ,T_NAME           --表名																							   
 ) PARTITION( bus_date = %d{yyyyMMdd})
  
  SELECT CASE WHEN t.NUM > = 	303960
            THEN 0
			ELSE 1
			END as IF_CJ
	  ,'FUNDEXT.DBO_SECUMAIN' as T_NAME
			
FROM 
(SELECT COUNT(1) as NUM FROM FUNDEXT.DBO_SECUMAIN          WHERE DT = '%d{yyyyMMdd}'
) t ;

 
    invalidate metadata DDW_PROD.T_DDW_FUNDEXT_CJ_MOT ; 


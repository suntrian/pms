 /* ***************************************** SQL Begin ***************************************** */
 /* 脚本功能:营业部监管报表指标月表                                                         */
 /* 创建人:黄勇华                                                                                 */
 /* 创建时间:2019-10-21                                                                      */
----插入上上个月的数据
---创建临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_JGBB_IDX_MON_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_NO_JGBB_IDX_MON_TEMP as 
 SELECT    t.BELTO_FILIL_CDG               --分公司编码
          ,t.BELTO_FILIL                    --分公司名称
          ,t.BRH_NO                         --营业部编码
          ,t.BRH_FULLNM                     --营业部名称
		  ,NVL(a1.G11,0)   as G11                             
		  ,NVL(a1.C3,0)    as C3                                 
		  ,NVL(a1.C4,0)    as C4                                 
		  ,NVL(a1.C5,0)    as C5                                 
		  ,NVL(a1.C6,0)    as C6                                 
		  ,NVL(a1.C7,0)    as C7                                 
		  ,NVL(a1.C8,0)    as C8                                 
		  ,NVL(a1.C9,0)    as C9                        
		  ,NVL(a1.C11,0)   as C11   
          ,%d{yyyyMMdd} as ETL_DT 		  
 FROM 	DDW_PROD.T_DDW_INR_ORG_BRH  t
 LEFT JOIN (SELECT   NVL(a.G11,0)   as G11                              
		            ,NVL(a.C3,0)    as C3                              
		            ,NVL(a.C4,0)    as C4                             
		            ,NVL(a.C5,0)    as C5                             
		            ,NVL(a.C6,0)    as C6                              
		            ,NVL(a.C7,0)    as C7                              
		            ,NVL(a.C8,0)    as C8                              
		            ,NVL(a.C9,0)+NVL(a.C10,0) as C9                               
		            ,NVL(a.C11,0)     as C11 
		            ,CAST(CAST(b.p001 as INT) as STRING) as BRH_NO
           FROM    KRCS.KRCS_T_CSRC0328_B_A4_1 a
           LEFT JOIN (SELECT  CASE WHEN SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) < = '201806'
		                           AND p001 IN (1111,1109,1110)
								   THEN NULL
								   WHEN SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) > '201806'
		                           AND p001 IN (1013,1002,1007)
								   THEN NULL
								   ELSE a002
								   END AS a002
		                      ,p001

		              FROM KRCS.KRCS_T_CTL_T036 
		              )b
           ON        a.USERID = b.a002
           WHERE   SUBSTR(a.BBQ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
            
			)   a1
 ON t.BRH_NO = a1.BRH_NO
 WHERE t.BUS_DATE = %d{yyyyMMdd} ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_NO_JGBB_IDX_MON_TEMP1 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_NO_JGBB_IDX_MON_TEMP1 as 
 SELECT    t.BELTO_FILIL_CDG               --分公司编码
          ,t.BELTO_FILIL                    --分公司名称
          ,t.BRH_NO                         --营业部编码
          ,t.BRH_FULLNM                     --营业部名称
		  ,NVL(a1.G1,0)+NVL(a1.G2,0)+NVL(a1.G3,0)+NVL(a1.G4,0)+NVL(a1.G5,0)+NVL(a1.G6,0)+NVL(a1.G7,0)           as G11                       
		  ,NVL(a1.C3,0)                                                                                         as C3  
		  ,NVL(a1.C4,0)                                                                                         as C4  
		  ,NVL(a1.C5,0)                                                                                         as C5  
		  ,NVL(a1.C6,0)                                                                                         as C6  
		  ,NVL(a1.C7,0)                                                                                         as C7  
		  ,NVL(a1.C8,0)                                                                                         as C8  
		  ,NVL(a1.C9,0)                                                                                         as C9  
		  ,NVL(a1.C3,0)+NVL(a1.C4,0)+NVL(a1.C5,0)+NVL(a1.C6,0)+NVL(a1.C7,0)+NVL(a1.C8,0)+NVL(a1.C9,0)           as C11 
          ,%d{yyyyMMdd} as ETL_DT 		  
 FROM 	DDW_PROD.T_DDW_INR_ORG_BRH  t
 LEFT JOIN (SELECT   SUM(DECODE(CAST(a.p002 as INT),1001,NVL(a.A003,0),0)) as C3                              
		            ,SUM(ROUND(DECODE(CAST(a.p002 as INT),1002,NVL(a.A003,0)*b.A002,1003,NVL(a.A003,0)*b.A003,0),2))    as C4                             
		            ,SUM(DECODE(CAST(a.p002 as INT),1005,NVL(a.A003,0),0))    as C5                             
		            ,SUM(DECODE(CAST(a.p002 as INT),1006,NVL(a.A003,0),0))    as C6                              
		            ,SUM(DECODE(CAST(a.p002 as INT),1007,NVL(a.A003,0),0))    as C7                              
		            ,SUM(DECODE(CAST(a.p002 as INT),1008,NVL(a.A003,0),0))    as C8                              
		            ,SUM(DECODE(CAST(a.p002 as INT),1009,NVL(a.A003,0),1010,NVL(a.A003,0),0))    as C9                               
					,SUM(DECODE(CAST(a.p002 as INT),1001,NVL(a.A007,0),0)) as G1                              
		            ,SUM(ROUND(DECODE(CAST(a.p002 as INT),1002,NVL(a.A007,0)*b.A002,1003,NVL(a.A007,0)*b.A003,0),2))    as G2                             
		            ,SUM(DECODE(CAST(a.p002 as INT),1005,NVL(a.A007,0),0))    as G3                             
		            ,SUM(DECODE(CAST(a.p002 as INT),1006,NVL(a.A007,0),0))    as G4                              
		            ,SUM(DECODE(CAST(a.p002 as INT),1007,NVL(a.A007,0),0))    as G5                              
		            ,SUM(DECODE(CAST(a.p002 as INT),1008,NVL(a.A007,0),0))    as G6                              
		            ,SUM(DECODE(CAST(a.p002 as INT),1009,NVL(a.A007,0),1010,NVL(a.A007,0),0))    as G7  
					
		            ,CAST(CAST(a.p001 as INT) as STRING) as BRH_NO
           FROM      (SELECT *,1 AS ID FROM KRCS.KRCS_T_DB_B4_01)      a
           LEFT JOIN (SELECT *,1 AS ID FROM KRCS.KRCS_T_BKS_T007)      b 
		   ON        a.ID = b.ID 
           GROUP BY BRH_NO		   
            )   a1
 ON t.BRH_NO = a1.BRH_NO
 WHERE t.BUS_DATE = %d{yyyyMMdd} ;


 INSERT OVERWRITE DDW_PROD.T_DDW_F20_BRH_NO_JGBB_IDX_MON
(
           BELTO_FILIL_CDG                       --分公司编码
          ,BELTO_FILIL                           --分公司名称
          ,BRH_NO                                --营业部编码
          ,BRH_FULLNM                            --营业部名称        
		  ,G11                                
		  ,C3                                 
		  ,C4                                 
		  ,C5                                 
		  ,C6                                 
		  ,C7                                 
		  ,C8                                 
		  ,C9                                 
		  ,C11                                
		  ,ETL_DT                                 --加载日期
 ) PARTITION(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) as INT)  )
 SELECT    t.BELTO_FILIL_CDG               --分公司编码
          ,t.BELTO_FILIL                    --分公司名称
          ,t.BRH_NO                         --营业部编码
          ,t.BRH_FULLNM                     --营业部名称
		  ,NVL(a1.G11,0)                                
		  ,NVL(a1.C3,0)                                 
		  ,NVL(a1.C4,0)                                 
		  ,NVL(a1.C5,0)                                 
		  ,NVL(a1.C6,0)                                 
		  ,NVL(a1.C7,0)                                 
		  ,NVL(a1.C8,0)                                 
		  ,NVL(a1.C9,0)                        
		  ,NVL(a1.C11,0) 
          ,%d{yyyyMMdd} as ETL_DT 		  
 FROM 	DDW_PROD.T_DDW_INR_ORG_BRH  t
 LEFT JOIN (SELECT   NVL(a.G11,0)   as G11                              
		            ,NVL(a.C3,0)    as C3                              
		            ,NVL(a.C4,0)    as C4                             
		            ,NVL(a.C5,0)    as C5                             
		            ,NVL(a.C6,0)    as C6                              
		            ,NVL(a.C7,0)    as C7                              
		            ,NVL(a.C8,0)    as C8                              
		            ,NVL(a.C9,0)+NVL(a.C10,0) as C9                               
		            ,NVL(a.C11,0)     as C11 
		            ,CAST(CAST(b.p001 as INT) as STRING) as BRH_NO
           FROM    KRCS.KRCS_T_CSRC0328_B_A4_1 a
           LEFT JOIN (SELECT  CASE WHEN SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) < = '201806'
		                           AND p001 IN (1111,1109,1110)
								   THEN NULL
								   WHEN SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6) > '201806'
		                           AND p001 IN (1013,1002,1007)
								   THEN NULL
								   ELSE a002
								   END AS a002
		                      ,p001

		              FROM KRCS.KRCS_T_CTL_T036 
		              )      b
           ON        a.USERID = b.a002
           WHERE   SUBSTR(a.BBQ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-2,0),1,6)
            )   a1
 ON t.BRH_NO = a1.BRH_NO
 WHERE t.BUS_DATE = %d{yyyyMMdd} ;
 
 
 ----插入上个月的数据
 INSERT OVERWRITE DDW_PROD.T_DDW_F20_BRH_NO_JGBB_IDX_MON
(
           BELTO_FILIL_CDG                       --分公司编码
          ,BELTO_FILIL                           --分公司名称
          ,BRH_NO                                --营业部编码
          ,BRH_FULLNM                            --营业部名称        
		  ,G11                                   --托管市值                             
		  ,C3                                    --A股交易量                               
		  ,C4                                    --B股交易量                                 
		  ,C5                                    --场内基金交易量                               
		  ,C6                                    --债券交易量                               
		  ,C7                                    --权证交易量                                
		  ,C8                                    --其他交易量                              
		  ,C9                                    --回购交易量                               
		  ,C11                                   --交易量合计                               
		  ,ETL_DT                                 --加载日期
 ) PARTITION(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)  )
 SELECT    NVL(t.BELTO_FILIL_CDG,a1.BELTO_FILIL_CDG)               --分公司编码
          ,NVL(t.BELTO_FILIL,a1.BELTO_FILIL)                    --分公司名称
          ,NVL(t.BRH_NO,a1.BRH_NO)                        --营业部编码
          ,NVL(t.BRH_FULLNM,a1.BRH_NO)                     --营业部名称
		  ,DECODE(t.G11,0,a1.G11,t.G11)                                  
		  ,DECODE(t.C3,0 ,a1.C3,t.C3 )    
		  ,DECODE(t.C4,0 ,a1.C4,t.C4 )    
		  ,DECODE(t.C5,0 ,a1.C5,t.C5 )    
		  ,DECODE(t.C6,0 ,a1.C6,t.C6 )    
		  ,DECODE(t.C7,0 ,a1.C7,t.C7 )    
		  ,DECODE(t.C8,0 ,a1.C8,t.C8 )    
		  ,DECODE(t.C9,0 ,a1.C9,t.C9 )    
		  ,DECODE(t.C11,0,a1.C11,t.C11)    
          ,%d{yyyyMMdd} as ETL_DT 		  
 FROM 	DDW_PROD.T_DDW_F20_BRH_NO_JGBB_IDX_MON_TEMP1  t
 FULL JOIN  DDW_PROD.T_DDW_F20_BRH_NO_JGBB_IDX_MON_TEMP a1
 ON   t.BRH_NO = a1.BRH_NO;
 
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_NO_JGBB_IDX_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F20_BRH_NO_JGBB_IDX_MON;
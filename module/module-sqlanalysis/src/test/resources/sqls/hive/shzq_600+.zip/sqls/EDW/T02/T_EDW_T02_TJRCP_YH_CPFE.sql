 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:金融产品银行产品份额表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
-------插入数据开始-----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TJRCP_YH_CPFE(
                                     KHH                                 --客户号                                
                                   ,CPZH                                --产品帐号                               
                                   ,CPDM                                --产品代码                               
                                   ,KHXM                                --客户姓名                               
                                   ,FXJG                                --发行机构                               
                                   ,CPJC                                --产品简称                               
                                   ,JRCP_SFFS                           --金融产品收费方式                           
                                   ,SL                                  --份额数量                               
                                   ,DJSL                                --冻结数量                               
                                   ,MCWTSL                              --卖出委托数量                             
                                   ,MCCJSL                              --卖出成交数量                             
                                   ,MRWTSL                              --买入委托数量                             
                                   ,MRCJSL                              --买入成交数量                             
                                   ,FELB                                --份额类别                               
                                   ,SQBH                                --申请编号                               
                                   ,XYBH                                --协议编号                               
                                   ,ZXSZ                                --最新市值                               
                                   ,KCRQ                                --开仓日期                               
                                   ,BDRQ                                --变动日期                               
                                   ,CCCB                                --持仓成本                               
                                   ,LJYK                                --累计盈亏                               
                                   ,LSH_ZJDJXM                          --资金冻结明细流水号                          
                                   ,YYB                                 --营业部                                
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,BZDM                                --币种代码                               
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期   
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.CPZH                                as CPZH                                --产品帐号                                
                                   ,t.CPDM                                as CPDM                                --产品代码                                
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,t.FXJG                                as FXJG                                --发行机构                                
                                   ,t.CPJC                                as CPJC                                --产品简称                                
                                   ,CAST(t.SFFS  AS VARCHAR(20))                                as JRCP_SFFS                           --收费方式                                
                                   ,t.SL                                  as SL                                  --份额数量                                
                                   ,t.DJSL                                as DJSL                                --冻结数量                                
                                   ,t.MCWTSL                              as MCWTSL                              --卖出委托数量                              
                                   ,t.MCCJSL                              as MCCJSL                              --卖出成交数量                              
                                   ,t.MRWTSL                              as MRWTSL                              --买入委托数量                              
                                   ,t.MRCJSL                              as MRCJSL                              --买入成交数量                              
                                   ,t.FELB                                as FELB                                --份额类别                                
                                   ,t.SQBH                                as SQBH                                --申请编号                                
                                   ,t.XYBH                                as XYBH                                --协议编号                                
                                   ,t.ZXSZ                                as ZXSZ                                --最新市值                                
                                   ,t.KCRQ                                as KCRQ                                --开仓日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.CCCB                                as CCCB                                --持仓成本                                
                                   ,t.LJYK                                as LJYK                                --累计盈亏                                
                                   ,t.LSH_ZJDJXM                          as LSH_ZJDJXM                          --资金冻结明细流水号                           
                                   ,CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as KHQZ                                --客户群组                                
                                   ,t.GSFL                                as GSFLDM                              --公司分类                                
                                   ,t.ZHGLJG                              as ZHGLJG                              --帐户管理机构                              
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                    as BZDM                                --币种代码                                
                                   ,%d{yyyyMMdd}                           as KSRQ                                --                                    
                                   ,%d{yyyyMMdd}                           as JSRQ                                --   
                                   ,'JZJY'								   
 FROM           JZJYCX.DATACENTER_TJRCP_YH_CPFE        t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t2
 ON             t2.YXT = 'JZJY'
 AND            t2.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE 			t.DT = '%d{yyyyMMdd}';
--------插入数据结束 
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TJRCP_YH_CPFE',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata EDW_PROD.T_EDW_T02_TJRCP_YH_CPFE;

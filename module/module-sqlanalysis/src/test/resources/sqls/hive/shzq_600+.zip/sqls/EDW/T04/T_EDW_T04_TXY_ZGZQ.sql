--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:融资融券资格证券表                                                                   */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T04_TXY_ZGZQ;
------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TXY_ZGZQ
 (
                                     JYS                                 --交易所                                
                                    ,ZQDM                                --证券代码                               
                                    ,ZQMC                                --证券名称                               
                                    ,ZQSX                                --证券属性                               
                                    ,ZQJYZT                              --证券交易状态                             
                                    ,RZYE                                --市场融资余额                             
                                    ,RQYE                                --市场融券余额                             
                                    ,RZSL                                --市场融资数量                             
                                    ,RQSL                                --市场融券数量                             
                                    ,RZJESX                              --融资上限                               
                                    ,RQSX                                --融券上限                               
                                    ,DHRZJESX                            --单户融资上限                             
                                    ,DHRQSLSX                            --单户融券上限                             
                                    ,ZSBL                                --标准折算比例                             
                                    ,ZSXS                                --折算系数                               
                                    ,RZJEBL                              --融资保证金比例                            
                                    ,RQJEBL                              --融券保证金比例                            
                                    ,RQ                                  --日期                                 
                                    ,ZXJ                                 --最新价                                
                                    ,JYDW                                --交易单位                               
                                    ,ZQLDX                               --证券流动性                              
                                    ,JYLBXZ                              --交易类别限制                             
                                    ,WBRZJEBL                            --交易所融资比例                            
                                    ,WBRQJEBL                            --交易所融券比例                            
                                    ,WBZSL                               --交易所折算率                             
                                    ,WBZT                                --外部状态                               
                                    ,MBDM                                --证券比例模板                             
                                    ,ZQBZ                                --展期标志                               
                                    ,ZQCS                                --展期次数    
                                    ,XTBS								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                     t.JYS                                 as JYS                                 --交易所                                 
                                    ,t.ZQDM                                as ZQDM                                --证券代码　                               
                                    ,t.ZQMC                                as ZQMC                                --证券名称                                
                                    ,t.ZQSX                                as ZQSX                                --证券属性                                
                                    ,t.JYZT                                as ZQJYZT                              --交易状态                                
                                    ,t.RZYE                                as RZYE                                --市场融资余额                              
                                    ,t.RQYE                                as RQYE                                --市场融券余额                              
                                    ,t.RZSL                                as RZSL                                --市场融资数量                              
                                    ,t.RQSL                                as RQSL                                --市场融券数量                              
                                    ,t.RZJESX                              as RZJESX                              --融资上限                                
                                    ,t.RQSLSX                              as RQSX                                --融券上限                                
                                    ,t.DHRZJESX                            as DHRZJESX                            --单户融资上限                              
                                    ,t.DHRQSLSX                            as DHRQSLSX                            --单户融券上限                              
                                    ,t.ZSBL                                as ZSBL                                --标准折算比例                              
                                    ,t.ZSXS                                as ZSXS                                --折算系数                                
                                    ,t.RZJEBL                              as RZJEBL                              --融资保证金比例                             
                                    ,t.RQJEBL                              as RQJEBL                              --融券保证金比例                             
                                    ,t.RQ                                  as RQ                                  --日期                                  
                                    ,t.ZXJ                                 as ZXJ                                 --最新价                                 
                                    ,t.JYDW                                as JYDW                                --交易单位                                
                                    ,t.ZQLDX                               as ZQLDX                               --证券流动性                               
                                    ,t.JYLBXZ                              as JYLBXZ                              --交易类别限制                              
                                    ,t.WBRZJEBL                            as WBRZJEBL                            --交易所融资比例                             
                                    ,t.WBRQJEBL                            as WBRQJEBL                            --交易所融券比例                             
                                    ,t.WBZSL                               as WBZSL                               --交易所折算率                              
                                    ,t.WBZT                                as WBZT                                --外部状态                                
                                    ,t.MBDM                                as MBDM                                --证券比例模板                              
                                    ,t.ZQBZ                                as ZQBZ                                --展期标志                                
                                    ,t.ZQCS                                as ZQCS                                --展期次数  
                                    ,'RZRQ'                                as XTBS								   
 FROM     RZRQCX.MARGIN_TXY_ZGZQ t 
 WHERE    t.DT = '%d{yyyyMMdd}';
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TXY_ZGZQ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:个股期权开户客户信息表                                                                 */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 

   TRUNCATE TABLE DDW_PROD.T_DDW_PRT_WRNT_OPN_CUST_INFO;
--删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WRNT_OPN_CUST_INFO_TEMP;
--创建临时表
 CREATE TABLE DDW_PROD.T_DDW_PRT_WRNT_OPN_CUST_INFO_TEMP
  AS 
   SELECT   T.BUS_DATE
                                   ,t.KHH                                            as CUST_NO                                   --客户号                                                 
                                   ,t.YYB                                           as BRH_NO                                    --营业部编号                                                                                                                  
                                   ,t.YWXT                                          as BIZ_SYS                                   --业务系统                                                
                                   ,t.YWZH                                          as BIZ_ACTNO                                 --业务账号                                                
                                   ,t.KHRQ                                          as OPNAC_DT                                  --开户日期                                                
                                   ,t.ZJZH                                          as CPT_ACCNT                                             
                                   ,CASE WHEN t.YWXT = 1000
								         THEN a2.YHDM  
                                         WHEN t.YWXT = 1001
                                         THEN a3.YHDM
                                         WHEN t.YWXT = 1002
                                         THEN a4.YHDM
                                         END										 as DEPMGT_BANK                               --存管银行                                                                                                                                                    
  

  FROM          EDW_PROD.T_EDW_T02_TYWZH                                           t    
  LEFT JOIN ( SELECT  b1.khh,b2.yhdm,b1.BUS_DATE
              FROM    
			             (  SELECT  GTZJZH,KHH,BUS_DATE 
                            FROM    EDW_PROD.T_EDW_T02_TZJZH 
                            WHERE   ZZHBZ = 1 AND XTBS = 'JZJY' AND BZDM = 'RMB'                    ---取交易系统的主账号标志为1的资金账号
                         )             b1                            
             INNER JOIN  (
                          SELECT  GTZJZH,YHDM, BUS_DATE
                          FROM    EDW_PROD.T_EDW_T02_TCGZHDY
                          WHERE   XTBS = 'JZJY'
                        )              b2
            ON         b1.GTZJZH = b2.GTZJZH
			AND        b1.BUS_DATE = b2.BUS_DATE
            )                                                                      a2              --取银行代码
 ON           t.KHH = a2.KHH
 AND        t.BUS_DATE =  a2.BUS_DATE
 LEFT JOIN  (SELECT KHH,YHDM,BUS_DATE FROM EDW_PROD.T_EDW_T02_TCGZHDY WHERE XTBS = 'RZRQ')    a3
 ON         t.KHH = a3.KHH
 AND        t.BUS_DATE =  a3.BUS_DATE
 LEFT JOIN  (SELECT KHH,YHDM,BUS_DATE FROM EDW_PROD.T_EDW_T02_TCGZHDY WHERE XTBS = 'GGQQ')    a4
 ON         t.KHH = a4.KHH
 AND        t.BUS_DATE =  a4.BUS_DATE
 WHERE      t.BUS_DATE = %d{yyyyMMdd} 
 ;
  
--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_WRNT_OPN_CUST_INFO
(
			    BRH_NO                --营业部编号 
               ,BRH_NAME              --营业部名称 
               ,OPNAC_DT              --开户日期  
               ,CUST_NO               --客户号   
               ,CUST_NAME             --客户姓名  
               ,CTF_CGY_CD            --证件类别代码
               ,CTF_NO                --证件号码  
               ,DEPMGT_BANK           --存管银行  
               ,CTRL_ATTR             --控制属性  
               ,IMAGE_TP              --影像资料  
               ,M_LAUND_RSK_LVL       --洗钱风险等级
               ,RSK_BEAR_ABLTY        --风险承受能力
			   ,IVSER_LVL             --投资者分级
               ,CTF_EXPR_DT           --证件截至日期
               ,CTCT_ADDR             --联系地址  
               ,CTCT_TEL              --联系电话  
               ,PHONE                 --手机    
               ,EDU_CD                --学历代码  
               ,OCP_CD                --职业代码
               ,FLOT_PRFT_TOT               --浮动盈亏
               ,CPT_ACCNT             --资金账户
               ,CONT_ACCNT			  --合约账户			   
) 
 PARTITION(bus_date=%d{yyyyMMdd})
 SELECT 
						 a1.BRH_NO                     AS BRH_NO                --营业部编号         
						,a1.BRH_NAME                   AS BRH_NAME              --营业部名称         
						,t.OPNAC_DT                    AS OPNAC_DT              --开户日期          
						,t.CUST_NO                     AS CUST_NO               --客户号           
						,a1.CUST_NAME                  AS CUST_NAME             --客户姓名          
						,b1.CTF_CGY_CD_NAME                 AS CTF_CGY_CD            --证件类别代码                
						,a1.CTF_NO                     AS CTF_NO                --证件号码          
						,t.DEPMGT_BANK                 AS DEPMGT_BANK           --存管银行          
						,a1.CTRL_ATTR                  AS CTRL_ATTR             --控制属性          
						,a1.IMAGE_TP                   AS IMAGE_TP              --影像资料          
						,b6.M_LAUND_RSK_LVL_NAME            AS M_LAUND_RSK_LVL       --洗钱风险等级        
						,b2.RSK_BEAR_ABLTY_NAME             AS RSK_BEAR_ABLTY        --风险承受能力   
                        ,a2.OPT_IVSTR_LVL_NAME         AS IVSER_LVL             --投资者分级						
						,a1.CTF_EXPR_DT                AS CTF_EXPR_DT           --证件截至日期        
						,a1.CTCT_ADDR                  AS CTCT_ADDR             --联系地址          
						,a1.CTCT_TEL                   AS CTCT_TEL              --联系电话          
						,a1.PHONE                      AS PHONE                 --手机            
						,b4.EDU_CD_NAME                    AS EDU_CD                --学历代码          
						,b5.OCP_CD_NAME                    AS OCP_CD                --职业代码 
                       ,NVL(a10.TOL_YLD,0)				as FLOT_PRFT_TOT               --浮动盈亏
                        ,t.CPT_ACCNT                    as CPT_ACCNT				--资金账户   
                        ,CONCAT(a5.GDH,a5.ZZHBM)        as CONT_ACCNT               --合约账户
  FROM  		DDW_PROD.T_DDW_PRT_WRNT_OPN_CUST_INFO_TEMP                                 	t   
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO                                        a1
  ON            t.CUST_NO = a1.CUST_NO 
  AND           t.bus_date = a1.bus_date 
  LEFT JOIN     (SELECT a.KHH,a.BUS_DATE,b.OPT_IVSTR_LVL_NAME
                 FROM   EDW_PROD.T_EDW_T01_TKHQQXX       a
				 LEFT JOIN DDW_PROD.V_OPT_IVSTR_LVL             b
				 ON     a.SOP_FXJB = b.OPT_IVSTR_LVL			
				 )                                             a2				 
  ON            t.CUST_NO = a2.KHH
  AND           t.BUS_DATE = a2.BUS_DATE
  LEFT JOIN 		DDW_PROD.V_CTF_CGY_CD					b1
ON				a1.CTF_CGY_CD = b1.CTF_CGY_CD
LEFT JOIN 		DDW_PROD.V_RSK_BEAR_ABLTY				b2
ON				a1.RSK_BEAR_ABLTY = b2.RSK_BEAR_ABLTY
--LEFT JOIN 		DDW_PROD.V_IVSER_LVL					b3
--ON				a1.IVSER_LVL = b1.IVSER_LVL
LEFT JOIN 		DDW_PROD.V_EDU_CD						b4
ON				a1.EDU_CD = b4.EDU_CD
LEFT JOIN 		DDW_PROD.V_OCP_CD						b5
ON				a1.OCP_CD = b5.OCP_CD
 LEFT JOIN  DDW_PROD.V_M_LAUND_RSK_LVL            b6
  ON         a1.M_LAUND_RSK_LVL = b6.M_LAUND_RSK_LVL
  LEFT JOIN     EDW_PROD.T_EDW_T02_THYZH                                 a5
  ON            t.cust_no   = a5.KHH
  and           a5.GDH like 'A%'
   AND           A5.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN (SELECT CUST_NO,SUM(TOT_PRFT) as TOL_YLD FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
              WHERE  BUS_DATE BETWEEN CAST(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0) AS DECIMAL(38,0)) AND %d{yyyyMMdd} 
              GROUP BY CUST_NO
             )            a10
ON           t.CUST_NO = a10.CUST_NO 
  WHERE			t.bus_date = %d{yyyyMMdd}  
  AND           t.BIZ_SYS = 1002
  AND           CAST( t.OPNAC_DT as STRING)   > =  CONCAT(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-3,0,0),1,4),'0101')     
  ;
-----------------------------加载结束--------------------

--删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WRNT_OPN_CUST_INFO_TEMP;
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_WRNT_OPN_CUST_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ; 
invalidate metadata DDW_PROD.T_DDW_PRT_WRNT_OPN_CUST_INFO ;
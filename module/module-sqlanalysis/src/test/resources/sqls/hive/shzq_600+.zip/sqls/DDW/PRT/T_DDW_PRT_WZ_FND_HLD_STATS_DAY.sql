------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:温州事业部基金持有统计日表                                                           */
------/* 创建人:欧阳晶                                                                                 */
------/* 创建时间:2018-06-29                                                                           */ 

----基金持仓临时表-从证券持仓/产品持仓表取数
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FND_HLD_STATS_DAY_TEMP1;
CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_FND_HLD_STATS_DAY_TEMP1
AS 
    SELECT 
	       T1.CUST_NO                                            --1.客户号
		  ,T5.CUST_NAME                                          --2.客户名称
		  ,T1.BRH_NO                                             --3.营业部编号
          ,T3.BRH_FULLNM AS BRH_NAME                             --4.营业部名称
		  ,T1.SEC_CD AS FND_CD                                   --5.基金代码
		  ,COALESCE(T7.JJQC,T6.CPQC,t8.ZQMC) AS FND_NAME         --6.基金名称
		  ,T1.SYS_SRC AS ACCNT_CGY                               --7.账户类别
		  ,SUM(T1.SEC_MKTVAL) AS HLD_AMT                         --8.持有金额
		  ,T4.NAT_DT AS BUS_DATE                                 --9.数据日期
        FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS T1
		INNER JOIN DDW_PROD.T_DDW_CFG_WZ_PROD T2
		        ON T1.SEC_CD = T2.PROD_CD
        INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T3
		        ON T1.BRH_NO = T3.BRH_NO
               AND T3.BELTO_FILIL_CDG = '0032'
			   AND T3.BUS_DATE = %d{yyyyMMdd}
		LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE T4
		       ON T1.BUS_DATE = T4.TRD_DT
		      AND T4.BUS_DATE = %d{yyyyMMdd}
		LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO T5
		       ON T1.CUST_NO = T5.CUST_NO
		      AND T5.BUS_DATE = %d{yyyyMMdd}
        LEFT JOIN EDW_PROD.T_EDW_T99_TJRCP_CPDM T6
               ON T1.SEC_CD = T6.CPDM
              AND T6.BUS_DATE = %d{yyyyMMdd}
        LEFT JOIN EDW_PROD.T_EDW_T04_TOF_JJXX T7
               ON T1.SEC_CD = T7.JJDM
              AND T7.BUS_DATE = %d{yyyyMMdd}
        LEFT JOIN EDW_PROD.T_EDW_T04_TZQDM T8
               ON T1.EXG = T8.JYS
              AND T1.SEC_CD = T8.ZQDM
              AND T8.BUS_DATE = %d{yyyyMMdd}
        WHERE T1.BUS_DATE > = 20180101
          AND T1.SEC_QTY > 0
	      AND ((SUBSTR(T1.SEC_CD,1,2) IN ('50','51','52') AND T1.EXG = 'SH') OR (SUBSTR(T1.SEC_CD,1,2) IN ('15','16','18') AND T1.EXG = 'SZ'))
        GROUP BY 
		         T1.CUST_NO
		        ,T5.CUST_NAME
		        ,T1.BRH_NO
                ,T3.BRH_FULLNM
		        ,T1.SEC_CD
		        ,COALESCE(T7.JJQC,T6.CPQC,t8.ZQMC)
		        ,T1.SYS_SRC
				,T4.NAT_DT
   UNION ALL
    SELECT 
	       T1.CUST_NO                                            --1.客户号
		  ,T5.CUST_NAME                                          --2.客户名称
		  ,T1.BRH_NO                                             --3.营业部编号
          ,T3.BRH_FULLNM AS BRH_NAME                             --4.营业部名称
		  ,T1.PROD_CD AS FND_CD                                  --5.基金代码
		  ,COALESCE(T7.JJQC,T6.CPQC,T8.CPQC) AS FND_NAME                 --6.基金名称
		  ,'普通账户' AS ACCNT_CGY                               --7.账户类别
		  ,SUM(T1.PROD_NEWST_MKTVAL) AS HLD_AMT                  --8.持有金额
		  ,T4.NAT_DT AS BUS_DATE                                 --9.数据日期
        FROM DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS T1
		INNER JOIN DDW_PROD.T_DDW_CFG_WZ_PROD T2
		        ON T1.PROD_CD = T2.PROD_CD
        INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T3
		        ON T1.BRH_NO = T3.BRH_NO
               AND T3.BELTO_FILIL_CDG = '0032'
			   AND T3.BUS_DATE = %d{yyyyMMdd}
		LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE T4
		       ON T1.BUS_DATE = T4.TRD_DT
		      AND T4.BUS_DATE = %d{yyyyMMdd}
		LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO T5
		       ON T1.CUST_NO = T5.CUST_NO
		      AND T5.BUS_DATE = %d{yyyyMMdd}
        LEFT JOIN EDW_PROD.T_EDW_T99_TJRCP_CPDM T6
               ON T1.PROD_CD = T6.CPDM
              AND T6.BUS_DATE = %d{yyyyMMdd}
        LEFT JOIN EDW_PROD.T_EDW_T04_TOF_JJXX T7
               ON T1.PROD_CD = T7.JJDM
              AND T7.BUS_DATE = %d{yyyyMMdd}
		 LEFT JOIN EDW_PROD.T_EDW_T04_TFP_CPDM T8
               ON T1.PROD_CD = T8.CPDM
              AND T8.BUS_DATE = %d{yyyyMMdd}
        WHERE T1.BUS_DATE > = 20180101
          AND T1.PROD_SHR_QTY > 0
        GROUP BY 
		         T1.CUST_NO
		        ,T5.CUST_NAME
		        ,T1.BRH_NO
                ,T3.BRH_FULLNM
		        ,T1.PROD_CD
		        ,COALESCE(T7.JJQC,T6.CPQC,T8.CPQC)
				,T4.NAT_DT
;

------插入数据开始
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_WZ_FND_HLD_STATS_DAY
(    CUST_NO                                     --1.客户号
    ,CUST_NANE                                   --2.客户名称
    ,BRH_NO                                      --3.营业部编号
	,BRH_NAME                                    --4.营业部名称
    ,FND_CD			                             --5.基金代码
    ,FND_NAME                                    --6.基金名称
	,ACCNT_CGY                                   --7.账户类别
	,HLD_AMT                                     --8.持有金额
 ) partition(BUS_DATE)
    SELECT 
           CUST_NO AS CUST_NO                    --1.客户号
	      ,CUST_NAME AS CUST_NAME                --2.客户名称
	      ,BRH_NO AS BRH_NO                      --3.营业部编号
		  ,BRH_NAME AS BRH_NAME                  --4.营业部名称
	      ,FND_CD AS FND_CD                      --5.基金代码
	      ,FND_NAME AS FND_NAME                  --6.基金名称
	      ,ACCNT_CGY AS ACCNT_CGY                --7.账户类别
	      ,SUM(HLD_AMT) AS HLD_AMT               --8.持有金额
		  ,CAST(BUS_DATE AS INT) AS BUS_DATE     --9.数据日期
    FROM DDW_PROD.T_DDW_PRT_WZ_FND_HLD_STATS_DAY_TEMP1
    GROUP BY
	         CUST_NO
	        ,CUST_NAME
	        ,BRH_NO
			,BRH_NAME
	        ,FND_CD
	        ,FND_NAME
	        ,ACCNT_CGY
			,BUS_DATE
;
------插入数据结束

------删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FND_HLD_STATS_DAY_TEMP1;
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_WZ_FND_HLD_STATS_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ; 
  invalidate metadata DDW_PROD.T_DDW_PRT_WZ_FND_HLD_STATS_DAY ;
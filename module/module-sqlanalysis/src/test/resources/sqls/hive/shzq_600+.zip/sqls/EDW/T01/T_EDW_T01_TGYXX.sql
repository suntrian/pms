----/* ***************************************** SQL Begin ***************************************** */
----/* 脚本功能:柜员信息表                                                                         */
----/* 创建人:黄勇华                                                                              */
----/* 创建时间:2016-11-02                                                                        */ 


TRUNCATE TABLE EDW_PROD.T_EDW_T01_TGYXX ;
---插入数据 ---
---插入集中交易数据---
INSERT INTO EDW_PROD.T_EDW_T01_TGYXX(
                                   GYDM                                 --柜员代码                               
                                   ,LOGINID                             --登陆ID                               
                                   ,JGDM                                --机构代码                               
                                   ,XM                                  --姓名                                 
                                   ,DH                                  --电话                                 
                                   ,DZ                                  --地址                                 
                                   ,YZBM                                --邮政编码                               
                                   ,MOBILE                              --手机                                 
                                   ,EMAIL                               --EMAIL                              
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,ZT                                  --状态                                 
                                   ,BZXX                                --备注信息                               
                                   ,DJRQ                                --登记日期                               
                                   ,BDRQ                                --变动日期                               
                                   ,KH                                  --卡号                                 
                                   ,XTBS                                --系统标识                               
) 
PARTITION( bus_date = %d{yyyyMMdd})
select 
                                    t.GYDM                                as GYDM                                --柜员代码                                
                                   ,t.LOGINID                             as LOGINID                             --登陆ID                                
                                   ,t.JGDM                                as JGDM                                --机构代码                                
                                   ,t.XM                                  as XM                                  --姓名                                  
                                   ,t.DH                                  as DH                                  --电话                                  
                                   ,t.DZ                                  as DZ                                  --地址                                  
                                   ,t.YZBM                                as YZBM                                --邮政编码                                
                                   ,t.MOBILE                              as MOBILE                              --手机                                  
                                   ,t.EMAIL                               as EMAIL                               --EMAILE                              
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,t.ZT                                  as ZT                                  --状态                                  
                                   ,t.BZXX                                as BZXX                                --备注信息                                
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.KH                                  as KH                                  --卡号                                  
                                   ,'JZJY'                                as XTBS                                --                                    
 FROM           JZJYCX.ABOSS_TGYXX                            t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t1 
 ON             t1.DMLX = 'ZJLBDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.ZJLB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---插入集中交易数据结束----	

---插入个股期权数据开始---
 INSERT INTO EDW_PROD.T_EDW_T01_TGYXX
 (
                                    GYDM                                --柜员代码                               
                                   ,LOGINID                             --登陆ID                               
                                   ,JGDM                                --机构代码                               
                                   ,XM                                  --姓名                                 
                                   ,DH                                  --电话                                 
                                   ,DZ                                  --地址                                 
                                   ,YZBM                                --邮政编码                               
                                   ,MOBILE                              --手机                                 
                                   ,EMAIL                               --EMAIL                              
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,ZT                                  --状态                                 
                                   ,BZXX                                --备注信息                               
                                   ,DJRQ                                --登记日期                               
                                   ,BDRQ                                --变动日期                               
                                   ,KH                                  --卡号     
                                   ,XTBS                                --系统标识								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.GYDM                                as GYDM                                --柜员代码                                
                                   ,t.LOGINID                             as LOGINID                             --登陆ID                                
                                   ,t.JGDM                                as JGDM                                --机构代码                                
                                   ,t.XM                                  as XM                                  --姓名                                  
                                   ,t.DH                                  as DH                                  --电话                                  
                                   ,t.DZ                                  as DZ                                  --地址                                  
                                   ,t.YZBM                                as YZBM                                --邮政编码                                
                                   ,t.MOBILE                              as MOBILE                              --手机                                  
                                   ,t.EMAIL                               as EMAIL                               --EMAILE                              
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,t.ZT                                  as ZT                                  --状态                                  
                                   ,t.BZXX                                as BZXX                                --备注信息                                
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.KH                                  as KH                                  --卡号                                  
                                   ,'GGQQ'                                   as XTBS                                --                                    
 FROM           GGQQCX.ABOSS_TGYXX                           t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING       t1 
 ON             t1.DMLX = 'ZJLBDM'
 AND            t1.YXT = 'GGQQ'
 AND            t1.YDM = CAST(t.ZJLB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---插入个股期权的数据结束----
	
---插入融资融券的数据开始---
 INSERT  INTO EDW_PROD.T_EDW_T01_TGYXX
 (
                                    GYDM                                --柜员代码                               
                                   ,LOGINID                             --登陆ID                               
                                   ,JGDM                                --机构代码                               
                                   ,XM                                  --姓名                                 
                                   ,DH                                  --电话                                 
                                   ,DZ                                  --地址                                 
                                   ,YZBM                                --邮政编码                               
                                   ,MOBILE                              --手机                                 
                                   ,EMAIL                               --EMAIL                              
                                   ,ZJLBDM                              --证件类别代码                             
                                   ,ZJBH                                --证件编号                               
                                   ,ZT                                  --状态                                 
                                   ,BZXX                                --备注信息                               
                                   ,DJRQ                                --登记日期                               
                                   ,BDRQ                                --变动日期                               
                                   ,KH                                  --卡号    
                                   ,XTBS                                --系统标识								   
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.GYDM                                as GYDM                                --柜员代码                                
                                   ,t.LOGINID                             as LOGINID                             --登陆ID                                
                                   ,t.JGDM                                as JGDM                                --机构代码                                
                                   ,t.XM                                  as XM                                  --姓名                                  
                                   ,t.DH                                  as DH                                  --电话                                  
                                   ,t.DZ                                  as DZ                                  --地址                                  
                                   ,t.YZBM                                as YZBM                                --邮政编码                                
                                   ,t.MOBILE                              as MOBILE                              --手机                                  
                                   ,t.EMAIL                               as EMAIL                               --EMAILE                              
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZJLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                as ZJLBDM                              --证件类别                                
                                   ,t.ZJBH                                as ZJBH                                --证件编号                                
                                   ,t.ZT                                  as ZT                                  --状态                                  
                                   ,t.BZXX                                as BZXX                                --备注信息                                
                                   ,t.DJRQ                                as DJRQ                                --登记日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,t.KH                                  as KH                                  --卡号                                  
                                   ,'RZRQ'                                as XTBS                                --                                    
 FROM           RZRQCX.ABOSS_TGYXX                           t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING       t1 
 ON             t1.DMLX = 'ZJLBDM'
 AND            t1.YXT = 'RZRQ'
 AND            t1.YDM = CAST(t.ZJLB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
----插入融资融券的数据结束---
----插入数据结束----
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T01_TGYXX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T01_TGYXX;

------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:组合基金关联关系表                                                                    */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2018-11-26                                                                        */ 

 
 --清除数据
 TRUNCATE TABLE EDW_PROD.T_EDW_T04_GROUP_FUND_REL;
 
 ------插入数据
  INSERT OVERWRITE EDW_PROD.T_EDW_T04_GROUP_FUND_REL
(
                 GROUP_ID           --组合id
				,FUND_CODE          --基金代码
				,FUND_SEQ           --组合中基金的序号
				,FUND_PROPORTION    --基金占比
				,SHARE              --基金份额
				,BUILD_DATE         --建仓调仓日期
				,COUNT_DATE         --备用
				,UPDATE_TIME        --更新时间
				,STATUS             --状态（备用）
 ) partition(BUS_DATE = %d{yyyyMMdd})
 SELECT     
                 GROUP_ID                                                     --组合id
				,FUND_CODE                                                    --基金代码
				,FUND_SEQ                                                     --组合中基金的序号
				,CAST(FUND_PROPORTION AS DECIMAL(38,0)) AS  FUND_PROPORTION   --基金占比
				,CAST(SHARE AS DECIMAL(38,0)) AS    SHARE                     --基金份额
				,BUILD_DATE                                                   --建仓调仓日期
				,COUNT_DATE                                                   --备用
				,UPDATE_TIME                                                  --更新时间
				,STATUS                                                       --状态（备用）
FROM       jjlc.GROUP_FUND_REL
;
 ----删除临时表
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_GROUP_FUND_REL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:岗位成员表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
    TRUNCATE TABLE EDW_PROD.T_EDW_T02_LBMEMBER;  
-----------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_LBMEMBER(
                                    LBMEMBER_ID                         --岗位成员主键                             
                                   ,USERID                              --用户ID                               
                                   ,ROLEID                              --角色ID                               
                                   ,ORGID                               --隶属部门                               
                                   ,XGSJ                                --修改时间                               
                                   ,SHBZ                                --审核标志                               
                                   ,SHR                                 --审核人                                
                                   ,SHRQ                                --审核日期 
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.ID                                  as LBMEMBER_ID                         --ID                                  
                                   ,t.USERID                              as USERID                              --用户ID                                
                                   ,t.ROLEID                              as ROLEID                              --角色ID                                
                                   ,t.ORGID                               as ORGID                               --隶属部门                                
                                   ,t.MODIDATE                            as XGSJ                                --修改时间                                
                                   ,t.AUDITFLAG                           as SHBZ                                --审核标志                                
                                   ,t.AUTHUSER                            as SHR                                 --审核人                                 
                                   ,t.AUTHDATE                            as SHRQ                                --审核日        
                                   ,'YGT'		                          as XTBS						   
 FROM       YGTCX.CIF_LBMEMBER t
 WHERE      t.DT = '%d{yyyyMMdd}';
----插入数据结束---------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_LBMEMBER',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_LBMEMBER;
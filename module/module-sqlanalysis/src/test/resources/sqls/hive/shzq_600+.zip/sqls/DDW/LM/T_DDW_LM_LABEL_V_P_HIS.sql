------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:产品标签结果表(历史)                                                                 */
------/* 创建人:OYJ                                                                                    */
------/* 创建时间:2018-12-26                                                                           */ 

INSERT OVERWRITE DDW_PROD.T_DDW_LM_LABEL_V_P_HIS
(
       PRODUCT_NO
      ,LABEL_ID
      ,LABEL_VALUE
      ,BUILD_TIME
      ,BIZ_TIME_RANGE_START
      ,BIZ_TIME_RANGE_END
)
 partition(BUS_DATE = %d{yyyyMMdd})
SELECT
       PRODUCT_NO
      ,LABEL_ID
      ,LABEL_VALUE
      ,BUILD_TIME
      ,BIZ_TIME_RANGE_START
      ,BIZ_TIME_RANGE_END
FROM DDW_PROD.T_DDW_LM_LABEL_V_P
WHERE BUS_DATE = %d{yyyyMMdd}
;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_LM_LABEL_V_P_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
invalidate metadata DDW_PROD.T_DDW_LM_LABEL_V_P_HIS;
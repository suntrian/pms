 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:资金帐户统计表                                                                  */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2020-01-14                                                                   */ 
-----------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TZJYWTJ
(
  RQ             --日期
, YYB            --营业部
, FSYYB          --发生营业部
, ZHGLJG         --帐户管理机构
, YHDM           --银行代码
, KHFLFS         --客户分类方式
, KHFL           --客户分类
, ZJZHLB         --资金帐户类别
, YWKM           --业务科目
, BZDM           --币种代码
, ZJLY           --资金来源
, SRJE          --收入金额
, FCJE          --发出金额
, BS            --笔数       
, XTBS     						   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT  t.RQ            as RQ        --日期
      , CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))           as YYB       --营业部
      , CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.FSYYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))          as FSYYB          --发生营业部
	  , t.ZHGLJG        as ZHGLJG    --帐户管理机构
      , t.YHDM          as YHDM      --银行代码
      , CAST(t.KHFLFS as STRING)        as KHFLFS    --客户分类方式
      , t.KHFL          as KHFL      --客户分类
      , CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )        as ZJZHLB    --资金帐户类别
      , t.YWKM          as YWKM      --业务科目
	  , CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )          as BZDM      --币种代码
	  , t.ZJLY          as ZJLY      --资金来源
	  , t.SRJE          as SRJE      --收入金额
      , t.FCJE          as FCJE      --发出金额
	  , t.BS            as BS            --笔数  	  	            
      ,'JZJY'     as XTBS				   
 FROM  JZJYCX.DATACENTER_TZJYWTJ t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'JZJY'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t2 
 ON             t2.DMLX = 'ZJZHLB'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'BZDM'
 AND            t3.YXT = 'JZJY'
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t4
 ON             t4.YXT = 'JZJY'
 AND            t4.JGDM = CAST(t.FSYYB AS VARCHAR(20))
 WHERE      t.DT = '%d{yyyyMMdd}'
 UNION ALL
 SELECT  t.RQ            as RQ        --日期
      , CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))           as YYB       --营业部
      , CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.FSYYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))          as FSYYB          --发生营业部
	  , t.ZHGLJG        as ZHGLJG    --帐户管理机构
      , t.YHDM          as YHDM      --银行代码
      , CAST(t.KHFLFS as STRING)        as KHFLFS    --客户分类方式
      , t.KHFL          as KHFL      --客户分类
      , CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )        as ZJZHLB    --资金帐户类别
      , t.YWKM          as YWKM      --业务科目
	  , CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )          as BZDM      --币种代码
	  , t.ZJLY          as ZJLY      --资金来源
	  , t.SRJE          as SRJE      --收入金额
      , t.FCJE          as FCJE      --发出金额
	  , t.BS            as BS            --笔数  	  	            
      ,'RZRQ'     as XTBS				   
 FROM  RZRQCX.DATACENTER_TZJYWTJ t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'RZRQ'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t2 
 ON             t2.DMLX = 'ZJZHLB'
 AND            t2.YXT = 'RZRQ'
 AND            t2.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'BZDM'
 AND            t3.YXT = 'RZRQ'
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t4
 ON             t4.YXT = 'RZRQ'
 AND            t4.JGDM = CAST(t.FSYYB AS VARCHAR(20))
 WHERE      t.DT = '%d{yyyyMMdd}'
 UNION ALL
  SELECT  t.RQ            as RQ        --日期
      , CAST(COALESCE(t1.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))           as YYB       --营业部
      , CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.FSYYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))          as FSYYB          --发生营业部
	  , t.ZHGLJG        as ZHGLJG    --帐户管理机构
      , t.YHDM          as YHDM      --银行代码
      , CAST(t.KHFLFS as STRING)        as KHFLFS    --客户分类方式
      , t.KHFL          as KHFL      --客户分类
      , CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.ZHLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )        as ZJZHLB    --资金帐户类别
      , t.YWKM          as YWKM      --业务科目
	  , CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )          as BZDM      --币种代码
	  , t.ZJLY          as ZJLY      --资金来源
	  , t.SRJE          as SRJE      --收入金额
      , t.FCJE          as FCJE      --发出金额
	  , t.BS            as BS            --笔数  	  	            
      ,'GGQQ'     as XTBS				   
 FROM  GGQQCX.DATACENTER_TZJYWTJ t
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t1
 ON             t1.YXT = 'GGQQ'
 AND            t1.JGDM = CAST(t.YYB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING        t2 
 ON             t2.DMLX = 'ZJZHLB'
 AND            t2.YXT = 'GGQQ'
 AND            t2.YDM = CAST(t.ZHLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t3 
 ON             t3.DMLX = 'BZDM'
 AND            t3.YXT = 'GGQQ'
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING            t4
 ON             t4.YXT = 'GGQQ'
 AND            t4.JGDM = CAST(t.FSYYB AS VARCHAR(20))
 WHERE      t.DT = '%d{yyyyMMdd}'
 ;
----插入数据结束---------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TZJYWTJ',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TZJYWTJ;
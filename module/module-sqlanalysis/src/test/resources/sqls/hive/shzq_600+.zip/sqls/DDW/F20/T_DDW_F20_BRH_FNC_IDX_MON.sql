------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:营业部财务指标月表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2019-12-20                                                                      */

-----创建临时表

DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP as
SELECT    ORG_CD as DEPT_NO
         ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6021','6011','6017','6051','6061','6071','6115','6111','6101')
		           THEN LC_LND_AMT
                   WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6411','6417','6421')
		           THEN 0-LC_LND_AMT				     
				   ELSE 0
				   END
			 )  as OPRTG_INCM                    --营业收入
          ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6301')
		            THEN LC_LND_AMT				     
				    ELSE 0
				    END
			  )  as OTH_OPRTG_INCM                   --营业外收入
			  ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,8) IN ('60210101','60210102','60210106')
		          THEN LC_LND_AMT	
                  WHEN SUBSTR(FNC_SBJ_CD,1,8) IN ('64210101','64210102','64210106','64210107')
		          THEN 0-LC_LND_AMT				  
				  ELSE 0
				  END
		    )  as AGENT_BS_NET_INCM       --代理买卖净收入
          ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6021','6011','6017')
		            THEN LC_LND_AMT
                    WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6421','6411','6417')
		            THEN 0-LC_LND_AMT				     
				    ELSE 0
				    END
			  )  as BROK_BIZ_INCM                    --经纪业务净收入
		  ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6051','6061','6071','6115')
		            THEN LC_LND_AMT				     
				    ELSE 0
				    END
			  )  as OTH_INCM                         --其他收入
          ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6111')
		            THEN LC_LND_AMT				     
				    ELSE 0
				    END
			  )  as IVSM_YLD                         --投资收益 
         ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6101')
		            THEN LC_LND_AMT				     
				    ELSE 0
				    END
			  )  as FAIRS_VAL_CHG_PL     --公允价值变动损益
         ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) = '6021'
		           THEN LC_LND_AMT
				   WHEN SUBSTR(FNC_SBJ_CD,1,4) = '6421'
		           THEN 0-LC_LND_AMT
				   ELSE 0
				   END
			 )  as CMSN_FEE_NET_S1_INCM    --手续费及佣金净收入
         ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6011','6017')
		           THEN LC_LND_AMT
				   WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6411','6417')
		           THEN 0-LC_LND_AMT
				   ELSE 0
				   END
			 )  as INT_INCM                  --利息净收入
        ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,8) = '60210108'
		          THEN LC_LND_AMT	
                  WHEN SUBSTR(FNC_SBJ_CD,1,8) = '64210109'
		          THEN 0-LC_LND_AMT					   
				  ELSE 0
				  END
		   )  as AGENT_BS_FNCL_PROD_INCM     --代理销售金融产品净收入
        ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,8) = '60210105'
		          THEN LC_LND_AMT
                  WHEN SUBSTR(FNC_SBJ_CD,1,8) = '64210105'
		          THEN 0-LC_LND_AMT				  
				  ELSE 0
				  END
		    )  as STK_WRNT_BIZ_INCM                 --股票期权业务净收入
        ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,8) IN ('64210107')
		          THEN LC_LND_AMT					  
				  ELSE 0
				  END
		    ) as BRK_RWD                              --经纪人报酬	
        
		,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6601','6402','6403','6701','6702')
		          THEN LC_LND_AMT					  
				  ELSE 0
				  END
		    )  as OPRTG_PAYOUT         --营业支出
		,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6711')
		          THEN LC_LND_AMT					  
				  ELSE 0
				  END
		    )  as OTH_OPRTG_PAYOUT         --营业外支出
        ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6801')
		          THEN LC_LND_AMT					  
				  ELSE 0
				  END
		    )  as INCM_TAX_FEE         --所得税费用	
		,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6901')
		          THEN LC_LND_AMT					  
				  ELSE 0
				  END
		    )  as PFX_ANUL_PL_ADJ       --以前年度损益调整
		,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) = '6601'
		          THEN LC_LND_AMT			  
				  ELSE 0
				  END
		    )       as BIZ_MGMT_FEE   --业务及管理费用
	    ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6402','6403')
		          THEN LC_LND_AMT			  
				  ELSE 0
				  END
		    )       as OTH_PAYOUT   --其他支出
		,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('6701','6702')
		          THEN LC_LND_AMT			  
				  ELSE 0
				  END
		    )       as AST_IMPMT_PREP      --资产减值准备
		,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,6) IN ('660112')
		          THEN LC_LND_AMT			  
				  ELSE 0
				  END
		    )	    as PSN_SALA --人员固薪
		 ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,6) IN ('660101','660108','660113','660114','660115','660116','660117','660118','660119','660120','660128','660131','660133','660136','660150','660151')
		           THEN LC_LND_AMT	
                   WHEN SUBSTR(FNC_SBJ_CD,1,8) IN ('66010701')
				   THEN LC_LND_AMT
				   ELSE 0
				   END
		    )	  as PSN_OTH_FEE --人员其他费用		 			
FROM  DDW_PROD.T_DDW_FNC_ENTR_DETAIL_MON
WHERE YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
GROUP BY ORG_CD ;
-----

DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP5 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP5 as
SELECT    ORG_CD as DEPT_NO	 
        ,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) IN ('2311','2315','2316')
		          THEN LC_LND_AMT-LC_BROW_AMT				     
				  ELSE 0
				  END
		    )  as AGENT_BS_SEC_INCM       --代理买卖证券款
		
		 
		,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) = '2311'
		          THEN LC_LND_AMT-LC_BROW_AMT				     
				  ELSE 0
				  END
		    )  as ORDI_AGENT_BS_SEC_INCM       --普通代理买卖证券款
		,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) = '2315'
		          THEN LC_LND_AMT-LC_BROW_AMT				     
				  ELSE 0
				  END
		    )  as CRD_TRD_AGENT_BS_SEC_INCM    --信用代理买卖证券款
		,SUM(CASE WHEN SUBSTR(FNC_SBJ_CD,1,4) = '2316'
		          THEN LC_LND_AMT-LC_BROW_AMT				     
				  ELSE 0
				  END
		    )  as PROD_AGENT_BS_SEC_INCM      --衍生产品代理买卖证券款			
FROM  DDW_PROD.T_DDW_FNC_ENTR_DETAIL_MON
WHERE YEAR_MON < = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
AND   SUBSTR(CAST(YEAR_MON as STRING),1,4) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,4)
GROUP BY ORG_CD ;
-------------------------三方存管
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP1 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP1 as
SELECT     a.YYB  as DEPT_NO
          ,a.YHDM as BANK_CODE
          ,ROUND(SUM(DECODE(a.XTBS,'JZJY',a.ZJYE*1.000*NVL(c.RATE_PARA,0)*1.000000/36000,0)),2) as ORDI_T3IP_DEPMGT_FEE   --普通三方存管费用
          ,ROUND(SUM(DECODE(a.XTBS,'RZRQ',a.ZJYE*1.000*NVL(c.RATE_PARA,0)*1.000000/36000,0)),2) as CRD_T3IP_DEPMGT_FEE    --信用三方存管费用
          ,ROUND(SUM(a.ZJYE*NVL(c.RATE_PARA,0)*1.000000/36000),2) as T3IP_DEPMGT_FEE    --三方存管费用
FROM EDW_PROD.T_EDW_T02_TZJZHTJ	a
LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE b
ON   a.BUS_DATE = b.TRD_DT
AND  b.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN C5CX.FINEDB_IMPORT_BANK_RATE_INFO c
ON   a.YHDM = c.BANK_CODE
AND  a.XTBS = DECODE(c.SYS_SRC,'ABOSS','JZJY','RZRQ') 
WHERE a.KHFLFS = '0'
AND   b.NAT_DT BETWEEN NVL(c.STRT_DT,0) AND NVL(c.END_DT,0)
AND   a.BZDM = 'RMB'
AND  SUBSTR(CAST(c.END_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) 
GROUP BY DEPT_NO,BANK_CODE ;
----三方存管
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP2 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP2 as
SELECT     SUM(DECODE(a.XTBS,'JZJY',a.ZJYE*1.000*NVL(c.RATE_PARA,0)*1.000000/36000,0)) as ORDI_T3IP_DEPMGT_FEE   --普通三方存管费用
          ,SUM(DECODE(a.XTBS,'RZRQ',a.ZJYE*1.000*NVL(c.RATE_PARA,0)*1.000000/36000,0)) as CRD_T3IP_DEPMGT_FEE    --信用三方存管费用
          ,SUM(a.ZJYE*NVL(c.RATE_PARA,0)*1.000000/36000) as T3IP_DEPMGT_FEE    --三方存管费用
          ,SUM(CASE WHEN a.XTBS = 'JZJY'
                    AND  a.YYB < > '1001'
                    THEN a.ZJYE*NVL(c.RATE_PARA,0)*1.000000/36000
                    ELSE 0
                    END
			  )  as ORDI_T3IP_DEPMGT_FEE_1001   --普通三方存管费用	
         ,SUM(CASE WHEN a.XTBS = 'RZRQ'
                   AND  a.YYB < > '1001'
                   THEN a.ZJYE*NVL(c.RATE_PARA,0)*1.000000/36000
                   ELSE 0
                   END
			  )  as CRD_T3IP_DEPMGT_FEE_1001   --信用三方存管费用
        ,SUM(CASE WHEN  a.YYB < > '1001'
                   THEN a.ZJYE*NVL(c.RATE_PARA,0)*1.000000/36000
                   ELSE 0
                   END
			 )  as T3IP_DEPMGT_FEE_1001   --三方存管费用
        ,a.YHDM as BANK_CODE		 
FROM EDW_PROD.T_EDW_T02_TZJZHTJ	a
LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE b
ON   a.BUS_DATE = b.TRD_DT
AND  b.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN C5CX.FINEDB_IMPORT_BANK_RATE_INFO c
ON   a.YHDM = c.BANK_CODE
AND  a.XTBS = DECODE(c.SYS_SRC,'ABOSS','JZJY','RZRQ') 
WHERE a.KHFLFS = '0'
AND   b.NAT_DT BETWEEN NVL(c.STRT_DT,0) AND NVL(c.END_DT,0)
AND   a.BZDM = 'RMB'
AND  SUBSTR(CAST(c.END_DT as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) 
GROUP BY a.YYB,BANK_CODE
 ;
----三方存管
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP3 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP3 as
SELECT '1001' as DEPT_NO
       ,SUM(ORDI_T3IP_DEPMGT_FEE-ORDI_T3IP_DEPMGT_FEE_1001)  as ORDI_T3IP_DEPMGT_FEE
	   ,SUM(CRD_T3IP_DEPMGT_FEE-CRD_T3IP_DEPMGT_FEE_1001)    as CRD_T3IP_DEPMGT_FEE
	   ,SUM(T3IP_DEPMGT_FEE-T3IP_DEPMGT_FEE_1001)            as T3IP_DEPMGT_FEE
FROM DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP2
GROUP BY DEPT_NO 
UNION ALL
SELECT  DEPT_NO
       ,SUM(ORDI_T3IP_DEPMGT_FEE)   as ORDI_T3IP_DEPMGT_FEE
	   ,SUM(CRD_T3IP_DEPMGT_FEE)    as CRD_T3IP_DEPMGT_FEE
	   ,SUM(T3IP_DEPMGT_FEE)        as T3IP_DEPMGT_FEE
FROM DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP1
WHERE DEPT_NO < > '1001'
GROUP BY DEPT_NO
;
------部门临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP4 ;
CREATE TABLE DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP4 as
SELECT BRH_NO      as DEPT_NO            --部门编号
      ,BRH_FULLNM  as DEPT_NAME          --部门名称       
FROM  DDW_PROD.T_DDW_INR_ORG_BRH 
WHERE BUS_DATE = %d{yyyyMMdd}
UNION ALL
SELECT FILIL_DEPT_CDG      as DEPT_NO            --部门编号
      ,FILIL_DEPT_FULLNM   as DEPT_NAME          --部门名称       
FROM  DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT 
WHERE BUS_DATE = %d{yyyyMMdd}
;
--------插入上个月数据	
INSERT OVERWRITE DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON
(           DEPT_NO                       --部门编号
           ,DEPT_NAME                     --部门名称
		   ,OPRTG_INCM                    --营业收入
           ,OTH_OPRTG_INCM                --营业外收入
		   ,AGENT_BS_NET_INCM             --代理买卖净收入
           ,BROK_BIZ_INCM                 --经纪业务净收入
           ,OTH_INCM                      --其他收入
           ,IVSM_YLD                      --投资收益 
           ,FAIRS_VAL_CHG_PL              --公允价值变动损益
           ,CMSN_FEE_NET_S1_INCM          --手续费及佣金净收入
           ,INT_INCM                      --利息净收入
           ,AGENT_BS_FNCL_PROD_INCM       --代理销售金融产品净收入
           ,STK_WRNT_BIZ_INCM             --股票期权业务净收入
           ,BRK_RWD                       --经纪人报酬
           ,ORDI_T3IP_DEPMGT_FEE          --普通三方存管费用
           ,CRD_T3IP_DEPMGT_FEE           --信用三方存管费用
	       ,T3IP_DEPMGT_FEE               --三方存管费用
           ,OPRTG_PAYOUT                 --营业支出
           ,OTH_OPRTG_PAYOUT             --营业外支出
           ,INCM_TAX_FEE                  --所得税费用	
           ,PFX_ANUL_PL_ADJ               --以前年度损益调整
           ,BIZ_MGMT_FEE                  --业务及管理费用
           ,OTH_PAYOUT                    --其他支出
           ,AST_IMPMT_PREP                --资产减值准备
		   ,YEAR_PFR_WAG                  --年终绩效工资
           ,PSN_SALA                      --人员固薪
           ,PSN_OTH_FEE                   --人员其他费用
		   ,OTH_BIZ_MGMT_FEE              --其他业务及管理费
		   ,RTL_CUST_AST                  --零售客户资产
           ,AGENT_BS_SEC_INCM             --代理买卖证券款
           ,ORDI_AGENT_BS_SEC_INCM        --普通代理买卖证券款
           ,CRD_TRD_AGENT_BS_SEC_INCM     --信用代理买卖证券款
           ,PROD_AGENT_BS_SEC_INCM        --衍生产品代理买卖证券款
		   ,CSTD_SEC_MKTVAL               --托管证券市值
           ,ETL_DT                             
)PARTITION(YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT) )
SELECT      t.DEPT_NO                       --部门编号
           ,t.DEPT_NAME                     --部门名称
		   ,ROUND(NVL(a1.OPRTG_INCM,0)-NVL(a2.T3IP_DEPMGT_FEE,0),2)                   --营业收入
           ,ROUND(NVL(a1.OTH_OPRTG_INCM,0),2)                --营业外收入
		   ,ROUND(NVL(a1.AGENT_BS_NET_INCM,0)-NVL(a2.T3IP_DEPMGT_FEE,0),2)             --代理买卖净收入
           ,ROUND(NVL(a1.BROK_BIZ_INCM,0)-NVL(a2.T3IP_DEPMGT_FEE,0),2)                  --经纪业务净收入
           ,ROUND(NVL(a1.OTH_INCM,0),2)                      --其他收入
           ,ROUND(NVL(a1.IVSM_YLD,0),2)                      --投资收益 
           ,ROUND(NVL(a1.FAIRS_VAL_CHG_PL,0),2)              --公允价值变动损益
           ,ROUND(NVL(a1.CMSN_FEE_NET_S1_INCM,0)-NVL(a2.T3IP_DEPMGT_FEE,0),2)          --手续费及佣金净收入
           ,ROUND(NVL(a1.INT_INCM,0),2)                      --利息净收入
           ,ROUND(NVL(a1.AGENT_BS_FNCL_PROD_INCM,0),2)       --代理销售金融产品净收入
           ,ROUND(NVL(a1.STK_WRNT_BIZ_INCM,0),2)             --股票期权业务净收入
           ,ROUND(NVL(a1.BRK_RWD,0),2)                       --经纪人报酬
           ,ROUND(NVL(a2.ORDI_T3IP_DEPMGT_FEE,0),2)          --普通三方存管费用
           ,ROUND(NVL(a2.CRD_T3IP_DEPMGT_FEE,0),2)           --信用三方存管费用
	       ,ROUND(NVL(a2.T3IP_DEPMGT_FEE,0),2)               --三方存管费用
           ,ROUND(NVL(a1.OPRTG_PAYOUT,0)+NVL(a3.FEE_SUM,0),2)                 --营业支出
           ,ROUND(NVL(a1.OTH_OPRTG_PAYOUT,0),2)             --营业外支出
           ,ROUND(NVL(a1.INCM_TAX_FEE,0),2)                  --所得税费用	
           ,ROUND(NVL(a1.PFX_ANUL_PL_ADJ,0),2)               --以前年度损益调整
           ,ROUND(NVL(a1.BIZ_MGMT_FEE,0)+NVL(a3.FEE_SUM,0),2)                 --业务及管理费用
           ,ROUND(NVL(a1.OTH_PAYOUT,0),2)                    --其他支出
           ,ROUND(NVL(a1.AST_IMPMT_PREP,0),2)                --资产减值准备
		   ,ROUND(NVL(a4.YEAR_PFR_WAG,0),2)                  --年终绩效工资
           ,ROUND(NVL(a1.PSN_SALA,0)-NVL(a4.YEAR_PFR_WAG,0)+NVL(a3.PSN_SALA,0),2)                      --人员固薪
           ,ROUND(NVL(a1.PSN_OTH_FEE,0)+NVL(a3.PSN_FEE_AGGR,0),2)                   --人员其他费用
		   ,ROUND(NVL(a1.BIZ_MGMT_FEE,0)+NVL(a3.FEE_SUM,0)-NVL(a4.YEAR_PFR_WAG,0)-NVL(a1.PSN_SALA,0)-NVL(a3.PSN_SALA,0)+NVL(a4.YEAR_PFR_WAG,0)-NVL(a1.PSN_OTH_FEE,0)-NVL(a3.PSN_FEE_AGGR,0),2)              --其他业务及管理费
		   ,ROUND(NVL(a6.AGENT_BS_SEC_INCM,0)+NVL(a5.CSTD_SEC_MKTVAL,0),2)                  --零售客户资产
           ,ROUND(NVL(a6.AGENT_BS_SEC_INCM,0),2)             --代理买卖证券款
           ,ROUND(NVL(a6.ORDI_AGENT_BS_SEC_INCM,0),2)        --普通代理买卖证券款
           ,ROUND(NVL(a6.CRD_TRD_AGENT_BS_SEC_INCM,0),2)     --信用代理买卖证券款
           ,ROUND(NVL(a6.PROD_AGENT_BS_SEC_INCM,0),2)        --衍生产品代理买卖证券款
		   ,ROUND(NVL(a5.CSTD_SEC_MKTVAL,0),2)               --托管证券市值
           ,%d{yyyyMMdd} as ETL_DT 
FROM DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP4   t
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP a1
ON        t.DEPT_NO = a1.DEPT_NO
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP3 a2
ON        t.DEPT_NO = a2.DEPT_NO
LEFT JOIN (SELECT    DEPT_CODE as DEPT_NO
                    ,SUM(PSN_FEE_AGGR) as PSN_FEE_AGGR	  --人员费用汇总
	                ,SUM(FEE_SUM)      as FEE_SUM        --费用合计
					,SUM(PSN_SALA)     as PSN_SALA
           FROM     C5CX.FINEDB_IMPORT_FEE_CL_INFO
           WHERE MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
           GROUP BY DEPT_NO
		   )                  a3
ON        t.DEPT_NO = a3.DEPT_NO
LEFT JOIN (SELECT  DECODE(DEPT_NO,'9968','1068',DEPT_NO) as DEPT_NO 
	              ,SUM(PRO_PFR+ADD_RWD+SSON_RWD+TALENT_RWD+ANUL_RWD+EXCTV_SETL+DECODE(OTH1_CGY,'2',OTH1+OTH2,'3',OTH1+OTH2,0)+DECODE(OTH2_CGY,'2',OTH1+OTH2,'3',OTH1+OTH2,0)) as YEAR_PFR_WAG --年终绩效工资
           FROM  C5CX.FINEDB_IMPORT_DEPT_SALR_INFO
           WHERE MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
           GROUP BY DEPT_NO
		   )                     a4
ON        t.DEPT_NO = a4.DEPT_NO
LEFT JOIN (SELECT  BRH_NO as DEPT_NO 
	              ,SUM(G11) as CSTD_SEC_MKTVAL
           FROM  DDW_PROD.T_DDW_F20_BRH_NO_JGBB_IDX_MON
           WHERE YEAR_MON = CAST(SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6) as INT)
           GROUP BY DEPT_NO
		   )                     a5
ON        t.DEPT_NO = a5.DEPT_NO
LEFT JOIN DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP5 a6
ON        t.DEPT_NO = a6.DEPT_NO

;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP1 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP2 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP3 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP4 ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON_TEMP5 ;
---------------标志位插入
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_BRH_FNC_IDX_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
------------------更新
INVALIDATE METADATA DDW_PROD.T_DDW_F20_BRH_FNC_IDX_MON;

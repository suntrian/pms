------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:行政区域代码                                                                      */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
 TRUNCATE TABLE DDW_PROD.T_DDW_PUB_DISTRICT_REGION_CD ;
INSERT OVERWRITE DDW_PROD.T_DDW_PUB_DISTRICT_REGION_CD
(                                  DISTRICT_REGION_CD        --行政区域代码
                                  ,DISTRICT_REGION_NAME      --行政区域名称
                                  ,DISTRICT_REGION_CGY       --行政区域类别                       
                                  ,SUPRS_REGION_CD           --上级区域代码							                                   								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT         t.XZQYDM	       as DISTRICT_REGION_CD        --行政区域代码                         
               ,t.XZQYMC	       as DISTRICT_REGION_NAME      --行政区域名称
               ,t.XZQYLB	       as DISTRICT_REGION_CGY       --行政区域类别	                                        						    
               ,t.SJXZQYDM         as SUPRS_REGION_CD           --上级区域代码
 FROM           EDW_PROD.T_EDW_T99_TXZQYDM                                 t       
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_DISTRICT_REGION_CD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_DISTRICT_REGION_CD;
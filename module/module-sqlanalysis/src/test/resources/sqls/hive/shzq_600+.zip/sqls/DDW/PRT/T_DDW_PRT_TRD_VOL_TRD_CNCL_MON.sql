  /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:交易量_交易终端月表                                                                   */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2018-11-14                                                                        */ 

  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP as
  SELECT TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,YEAR_MON
         ,SUM(ODR_ITMS) as ODR_ITMS
		 ,SUM(VOL) as VOL
		 ,COUNT(1) as ODR_PSNNUM
		 ,SEQ1
  
  FROM 
  (SELECT TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,SUBSTR('20181121',1,6) as YEAR_MON
         ,SUM(ODR_ITMS) as ODR_ITMS
		 ,SUM(ROUND(VOL*1.00000000/100000000,10))      as VOL
		 ,CUST_NO  as ODR_PSNNUM
		 ,SEQ1
  FROM 
  (SELECT   CASE WHEN WTFS = 32
                THEN '网上交易'
				WHEN WTFS = 64
                THEN '手机交易'
				WHEN WTFS = 1
                THEN '电话交易'
				ELSE '其他交易'
				END  as TRD_CGY
		  ,CASE WHEN WTFS = 32
                THEN 1
				WHEN WTFS = 64
                THEN 2
				WHEN WTFS = 1
                THEN 3
				ELSE 4
				END  as SEQ
		  ,CASE WHEN WTFS = 32
		        AND  CZZD1 = '1005'
				THEN '通达信网上'
				WHEN WTFS = 32
		        AND  CZZD1 = '1007'
				THEN '同花顺网上'
				WHEN WTFS = 32
		        AND  CZZD1 = '1008'
				THEN '网上营业厅'
				WHEN WTFS = 64
		        AND  CZZD1 = '1006'
				THEN '同花顺手机'
				WHEN WTFS = 64
		        AND  CZZD1 = '1010'
				THEN '微信'
				WHEN WTFS = 64
		        AND  CZZD1 = '1011'
				THEN '玉如意同花顺'
				WHEN WTFS = 64
		        AND  CZZD1 = '1012'
				THEN '速E通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1013'
				THEN '联通华建'
				WHEN WTFS = 64
		        AND  CZZD1 = '1014'
				THEN '指E通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1015'
				THEN '闪电通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1016'
				THEN '汇点'
				WHEN WTFS = 64
		        AND  CZZD1 = '1017'
				THEN '玉如意大智慧'				
				WHEN WTFS = 1
                THEN '电话交易'
				ELSE '其他交易'
				END  as TRD_CNCL	
          ,CASE WHEN WTFS = 32
		        AND  CZZD1 = '1005'
				THEN  1
				WHEN WTFS = 32
		        AND  CZZD1 = '1007'
				THEN 2
				WHEN WTFS = 32
		        AND  CZZD1 = '1008'
				THEN 3
				WHEN WTFS = 64
		        AND  CZZD1 = '1006'
				THEN 5
				WHEN WTFS = 64
		        AND  CZZD1 = '1010'
				THEN 6
				WHEN WTFS = 64
		        AND  CZZD1 = '1011'
				THEN 7
				WHEN WTFS = 64
		        AND  CZZD1 = '1012'
				THEN 8
				WHEN WTFS = 64
		        AND  CZZD1 = '1013'
				THEN 9
				WHEN WTFS = 64
		        AND  CZZD1 = '1014'
				THEN 10
				WHEN WTFS = 64
		        AND  CZZD1 = '1015'
				THEN 11
				WHEN WTFS = 64
		        AND  CZZD1 = '1016'
				THEN 12
				WHEN WTFS = 64
		        AND  CZZD1 = '1017'
				THEN 13				
				WHEN WTFS = 1
                THEN 15
				ELSE 17
				END  as SEQ1	

				
		  ,COUNT(1)      as ODR_ITMS
		  ,SUM(CJJE)   as VOL
		  ,KHH         as CUST_NO
          ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户') as SYS_SRC
 FROM EDW_PROD.T_EDW_T05_TWTLS t
 WHERE SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR('20181121',1,6)
  AND  SBJG IN(2,5,6,7,8,9) 
  AND  DDLX < > '3' 
  AND SUBSTR(ZQLB,1,1)<>'F'
 GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,CUST_NO,SEQ1 
 UNION ALL 
  SELECT   CASE WHEN WTFS = 32
                THEN '网上交易'
				WHEN WTFS = 64
                THEN '手机交易'
				WHEN WTFS = 1
                THEN '电话交易'
				ELSE '其他交易'
				END  as TRD_CGY
		   ,CASE WHEN WTFS = 32
                THEN 1
				WHEN WTFS = 64
                THEN 2
				WHEN WTFS = 1
                THEN 3
				ELSE 4
				END  as SEQ
		  ,CASE WHEN WTFS = 32
		        AND  CZZD1 = '1005'
				THEN '通达信网上'
				WHEN WTFS = 32
		        AND  CZZD1 = '1007'
				THEN '同花顺网上'
				WHEN WTFS = 32
		        AND  CZZD1 = '1008'
				THEN '网上营业厅'
				WHEN WTFS = 64
		        AND  CZZD1 = '1006'
				THEN '同花顺手机'
				WHEN WTFS = 64
		        AND  CZZD1 = '1010'
				THEN '微信'
				WHEN WTFS = 64
		        AND  CZZD1 = '1011'
				THEN '玉如意同花顺'
				WHEN WTFS = 64
		        AND  CZZD1 = '1012'
				THEN '速E通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1013'
				THEN '联通华建'
				WHEN WTFS = 64
		        AND  CZZD1 = '1014'
				THEN '指E通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1015'
				THEN '闪电通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1016'
				THEN '汇点'
				WHEN WTFS = 64
		        AND  CZZD1 = '1017'
				THEN '玉如意大智慧'				
				WHEN WTFS = 1
                THEN '电话交易'
				ELSE '其他交易'
				END  as TRD_CNCL
		   ,CASE WHEN WTFS = 32
		        AND  CZZD1 = '1005'
				THEN  1
				WHEN WTFS = 32
		        AND  CZZD1 = '1007'
				THEN 2
				WHEN WTFS = 32
		        AND  CZZD1 = '1008'
				THEN 3
				WHEN WTFS = 64
		        AND  CZZD1 = '1006'
				THEN 5
				WHEN WTFS = 64
		        AND  CZZD1 = '1010'
				THEN 6
				WHEN WTFS = 64
		        AND  CZZD1 = '1011'
				THEN 7
				WHEN WTFS = 64
		        AND  CZZD1 = '1012'
				THEN 8
				WHEN WTFS = 64
		        AND  CZZD1 = '1013'
				THEN 9
				WHEN WTFS = 64
		        AND  CZZD1 = '1014'
				THEN 10
				WHEN WTFS = 64
		        AND  CZZD1 = '1015'
				THEN 11
				WHEN WTFS = 64
		        AND  CZZD1 = '1016'
				THEN 12
				WHEN WTFS = 64
		        AND  CZZD1 = '1017'
				THEN 13				
				WHEN WTFS = 1
                THEN 15
				ELSE 17
				END  as SEQ1
		  ,COUNT(1)      as ODR_ITMS
		  ,SUM(0)   as VOL
		  ,KHH         as CUST_NO
           ,'普通账户' as SYS_SRC
 FROM EDW_PROD.T_EDW_T05_TOF_JJWTLS t
 WHERE SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR('20181121',1,6)
 AND   YWDM < > '001'
 AND   ZY NOT LIKE '%现金宝业务批量自动触发%'
 GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,CUST_NO,SEQ1
 UNION ALL
 SELECT    CASE WHEN WTFS = 32
                THEN '网上交易'
				WHEN WTFS = 64
                THEN '手机交易'
				WHEN WTFS = 1
                THEN '电话交易'
				ELSE '其他交易'
				END  as TRD_CGY
		  ,CASE WHEN WTFS = 32
                THEN 1
				WHEN WTFS = 64
                THEN 2
				WHEN WTFS = 1
                THEN 3
				ELSE 4
				END  as SEQ
		  ,CASE WHEN WTFS = 32
		        AND  CZZD1 = '1005'
				THEN '通达信网上'
				WHEN WTFS = 32
		        AND  CZZD1 = '1007'
				THEN '同花顺网上'
				WHEN WTFS = 32
		        AND  CZZD1 = '1008'
				THEN '网上营业厅'
				WHEN WTFS = 64
		        AND  CZZD1 = '1006'
				THEN '同花顺手机'
				WHEN WTFS = 64
		        AND  CZZD1 = '1010'
				THEN '微信'
				WHEN WTFS = 64
		        AND  CZZD1 = '1011'
				THEN '玉如意同花顺'
				WHEN WTFS = 64
		        AND  CZZD1 = '1012'
				THEN '速E通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1013'
				THEN '联通华建'
				WHEN WTFS = 64
		        AND  CZZD1 = '1014'
				THEN '指E通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1015'
				THEN '闪电通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1016'
				THEN '汇点'
				WHEN WTFS = 64
		        AND  CZZD1 = '1017'
				THEN '玉如意大智慧'				
				WHEN WTFS = 1
                THEN '电话交易'
				ELSE '其他交易'
				END  as TRD_CNCL
			 ,CASE WHEN WTFS = 32
		        AND  CZZD1 = '1005'
				THEN  1
				WHEN WTFS = 32
		        AND  CZZD1 = '1007'
				THEN 2
				WHEN WTFS = 32
		        AND  CZZD1 = '1008'
				THEN 3
				WHEN WTFS = 64
		        AND  CZZD1 = '1006'
				THEN 5
				WHEN WTFS = 64
		        AND  CZZD1 = '1010'
				THEN 6
				WHEN WTFS = 64
		        AND  CZZD1 = '1011'
				THEN 7
				WHEN WTFS = 64
		        AND  CZZD1 = '1012'
				THEN 8
				WHEN WTFS = 64
		        AND  CZZD1 = '1013'
				THEN 9
				WHEN WTFS = 64
		        AND  CZZD1 = '1014'
				THEN 10
				WHEN WTFS = 64
		        AND  CZZD1 = '1015'
				THEN 11
				WHEN WTFS = 64
		        AND  CZZD1 = '1016'
				THEN 12
				WHEN WTFS = 64
		        AND  CZZD1 = '1017'
				THEN 13				
				WHEN WTFS = 1
                THEN 15
				ELSE 17
				END  as SEQ1
		   ,COUNT(1)      as ODR_ITMS
		   ,SUM(0)      as VOL
		   ,KHH         as CUST_NO
           ,'普通账户'  as SYS_SRC
 FROM EDW_PROD.T_EDW_T05_TJRCP_YH_WTLS t
 WHERE SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR('20181121',1,6)
 GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,CUST_NO,SEQ1 
 )   t
 GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,YEAR_MON,ODR_PSNNUM,SEQ1
 ) t
 GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,YEAR_MON,SEQ1
 ;
  
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP1 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP1 as
  SELECT  TRD_CGY
         ,SEQ as SEQ
		  ,CASE WHEN SEQ = 1
               THEN 4
			   WHEN SEQ = 2
               THEN 14
			   WHEN SEQ = 3
               THEN 16
			   WHEN SEQ = 4
               THEN 18
			   END  as SEQ1
			   
         ,CASE WHEN SEQ = 1
               THEN '网上交易小计'
			   WHEN SEQ = 2
               THEN '手机交易小计'
			   WHEN SEQ = 3
               THEN '电话交易小计'
			   WHEN SEQ = 4
               THEN '其他交易小计'
			   END  as TRD_CNCL
          ,SYS_SRC,YEAR_MON
         ,SUM(ODR_ITMS) as ODR_ITMS
		 ,SUM(VOL) as VOL
		 ,SUM(ODR_PSNNUM) as ODR_PSNNUM
  FROM DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP
  GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,YEAR_MON ;
  
    DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP2 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP2 as
  SELECT  '合计'  as TRD_CGY
         ,6       as SEQ
		 ,18       as SEQ1
         ,'合计'  as TRD_CNCL
          ,SYS_SRC,YEAR_MON
         ,SUM(ODR_ITMS) as ODR_ITMS
		 ,SUM(VOL) as VOL
		 ,SUM(ODR_PSNNUM) as ODR_PSNNUM
  FROM DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP1
  GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,YEAR_MON ;
  
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP3 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP3 as
  SELECT TRD_CGY
         ,SEQ
		 ,SEQ1
		 ,TRD_CNCL
		 ,SYS_SRC
		 ,YEAR_MON
		 ,ODR_ITMS
		 ,VOL
		 ,ODR_PSNNUM
  FROM DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP
  UNION ALL 
  SELECT TRD_CGY
         ,SEQ
		 ,SEQ1
		 ,TRD_CNCL
		 ,SYS_SRC
		 ,YEAR_MON
		 ,ODR_ITMS
		 ,VOL
		 ,ODR_PSNNUM
  FROM DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP1
  UNION ALL 
  SELECT TRD_CGY
         ,SEQ
		 ,SEQ1
		 ,TRD_CNCL
		 ,SYS_SRC
		 ,YEAR_MON
		 ,ODR_ITMS
		 ,VOL
		 ,ODR_PSNNUM
  FROM DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP2 ;
  
    DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP4 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP4 as
  SELECT TRD_CGY,SEQ,TRD_CNCL,SYS_SRC
         ,SUM(ODR_ITMS) as ODR_ITMS
		 ,SUM(VOL) as VOL
		 ,COUNT(1) as ODR_PSNNUM
		 ,SEQ1
  
  FROM 
  (SELECT TRD_CGY,SEQ,TRD_CNCL,SYS_SRC
         ,SUM(ODR_ITMS) as ODR_ITMS
		 ,SUM(ROUND(VOL*1.00000000/100000000,10))      as VOL
		 ,CUST_NO  as ODR_PSNNUM
		 ,SEQ1
  FROM 
  (SELECT   CASE WHEN WTFS = 32
                THEN '网上交易'
				WHEN WTFS = 64
                THEN '手机交易'
				WHEN WTFS = 1
                THEN '电话交易'
				ELSE '其他交易'
				END  as TRD_CGY
		  ,CASE WHEN WTFS = 32
                THEN 1
				WHEN WTFS = 64
                THEN 2
				WHEN WTFS = 1
                THEN 3
				ELSE 4
				END  as SEQ
		  ,CASE WHEN WTFS = 32
		        AND  CZZD1 = '1005'
				THEN '通达信网上'
				WHEN WTFS = 32
		        AND  CZZD1 = '1007'
				THEN '同花顺网上'
				WHEN WTFS = 32
		        AND  CZZD1 = '1008'
				THEN '网上营业厅'
				WHEN WTFS = 64
		        AND  CZZD1 = '1006'
				THEN '同花顺手机'
				WHEN WTFS = 64
		        AND  CZZD1 = '1010'
				THEN '微信'
				WHEN WTFS = 64
		        AND  CZZD1 = '1011'
				THEN '玉如意同花顺'
				WHEN WTFS = 64
		        AND  CZZD1 = '1012'
				THEN '速E通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1013'
				THEN '联通华建'
				WHEN WTFS = 64
		        AND  CZZD1 = '1014'
				THEN '指E通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1015'
				THEN '闪电通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1016'
				THEN '汇点'
				WHEN WTFS = 64
		        AND  CZZD1 = '1017'
				THEN '玉如意大智慧'				
				WHEN WTFS = 1
                THEN '电话交易'
				ELSE '其他交易'
				END  as TRD_CNCL	
          ,CASE WHEN WTFS = 32
		        AND  CZZD1 = '1005'
				THEN  1
				WHEN WTFS = 32
		        AND  CZZD1 = '1007'
				THEN 2
				WHEN WTFS = 32
		        AND  CZZD1 = '1008'
				THEN 3
				WHEN WTFS = 64
		        AND  CZZD1 = '1006'
				THEN 5
				WHEN WTFS = 64
		        AND  CZZD1 = '1010'
				THEN 6
				WHEN WTFS = 64
		        AND  CZZD1 = '1011'
				THEN 7
				WHEN WTFS = 64
		        AND  CZZD1 = '1012'
				THEN 8
				WHEN WTFS = 64
		        AND  CZZD1 = '1013'
				THEN 9
				WHEN WTFS = 64
		        AND  CZZD1 = '1014'
				THEN 10
				WHEN WTFS = 64
		        AND  CZZD1 = '1015'
				THEN 11
				WHEN WTFS = 64
		        AND  CZZD1 = '1016'
				THEN 12
				WHEN WTFS = 64
		        AND  CZZD1 = '1017'
				THEN 13				
				WHEN WTFS = 1
                THEN 15
				ELSE 17
				END  as SEQ1	

				
		  ,COUNT(1)      as ODR_ITMS
		  ,SUM(CJJE)   as VOL
		  ,KHH         as CUST_NO
          ,DECODE(t.XTBS,'JZJY','普通账户','RZRQ','信用账户') as SYS_SRC
 FROM EDW_PROD.T_EDW_T05_TWTLS t
 WHERE SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('20181121','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
  AND  SBJG IN(2,5,6,7,8,9) 
  AND  DDLX < > '3' 
  AND SUBSTR(ZQLB,1,1)<>'F'
 GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,CUST_NO,SEQ1 
 UNION ALL 
  SELECT   CASE WHEN WTFS = 32
                THEN '网上交易'
				WHEN WTFS = 64
                THEN '手机交易'
				WHEN WTFS = 1
                THEN '电话交易'
				ELSE '其他交易'
				END  as TRD_CGY
		   ,CASE WHEN WTFS = 32
                THEN 1
				WHEN WTFS = 64
                THEN 2
				WHEN WTFS = 1
                THEN 3
				ELSE 4
				END  as SEQ
		  ,CASE WHEN WTFS = 32
		        AND  CZZD1 = '1005'
				THEN '通达信网上'
				WHEN WTFS = 32
		        AND  CZZD1 = '1007'
				THEN '同花顺网上'
				WHEN WTFS = 32
		        AND  CZZD1 = '1008'
				THEN '网上营业厅'
				WHEN WTFS = 64
		        AND  CZZD1 = '1006'
				THEN '同花顺手机'
				WHEN WTFS = 64
		        AND  CZZD1 = '1010'
				THEN '微信'
				WHEN WTFS = 64
		        AND  CZZD1 = '1011'
				THEN '玉如意同花顺'
				WHEN WTFS = 64
		        AND  CZZD1 = '1012'
				THEN '速E通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1013'
				THEN '联通华建'
				WHEN WTFS = 64
		        AND  CZZD1 = '1014'
				THEN '指E通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1015'
				THEN '闪电通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1016'
				THEN '汇点'
				WHEN WTFS = 64
		        AND  CZZD1 = '1017'
				THEN '玉如意大智慧'				
				WHEN WTFS = 1
                THEN '电话交易'
				ELSE '其他交易'
				END  as TRD_CNCL
		   ,CASE WHEN WTFS = 32
		        AND  CZZD1 = '1005'
				THEN  1
				WHEN WTFS = 32
		        AND  CZZD1 = '1007'
				THEN 2
				WHEN WTFS = 32
		        AND  CZZD1 = '1008'
				THEN 3
				WHEN WTFS = 64
		        AND  CZZD1 = '1006'
				THEN 5
				WHEN WTFS = 64
		        AND  CZZD1 = '1010'
				THEN 6
				WHEN WTFS = 64
		        AND  CZZD1 = '1011'
				THEN 7
				WHEN WTFS = 64
		        AND  CZZD1 = '1012'
				THEN 8
				WHEN WTFS = 64
		        AND  CZZD1 = '1013'
				THEN 9
				WHEN WTFS = 64
		        AND  CZZD1 = '1014'
				THEN 10
				WHEN WTFS = 64
		        AND  CZZD1 = '1015'
				THEN 11
				WHEN WTFS = 64
		        AND  CZZD1 = '1016'
				THEN 12
				WHEN WTFS = 64
		        AND  CZZD1 = '1017'
				THEN 13				
				WHEN WTFS = 1
                THEN 15
				ELSE 17
				END  as SEQ1
		  ,COUNT(1)      as ODR_ITMS
		  ,SUM(0)   as VOL
		  ,KHH         as CUST_NO
           ,'普通账户' as SYS_SRC
 FROM EDW_PROD.T_EDW_T05_TOF_JJWTLS t
 WHERE SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('20181121','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
 AND   YWDM < > '001'
 AND   ZY NOT LIKE '%现金宝业务批量自动触发%'
 GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,CUST_NO,SEQ1
 UNION ALL
 SELECT    CASE WHEN WTFS = 32
                THEN '网上交易'
				WHEN WTFS = 64
                THEN '手机交易'
				WHEN WTFS = 1
                THEN '电话交易'
				ELSE '其他交易'
				END  as TRD_CGY
		  ,CASE WHEN WTFS = 32
                THEN 1
				WHEN WTFS = 64
                THEN 2
				WHEN WTFS = 1
                THEN 3
				ELSE 4
				END  as SEQ
		  ,CASE WHEN WTFS = 32
		        AND  CZZD1 = '1005'
				THEN '通达信网上'
				WHEN WTFS = 32
		        AND  CZZD1 = '1007'
				THEN '同花顺网上'
				WHEN WTFS = 32
		        AND  CZZD1 = '1008'
				THEN '网上营业厅'
				WHEN WTFS = 64
		        AND  CZZD1 = '1006'
				THEN '同花顺手机'
				WHEN WTFS = 64
		        AND  CZZD1 = '1010'
				THEN '微信'
				WHEN WTFS = 64
		        AND  CZZD1 = '1011'
				THEN '玉如意同花顺'
				WHEN WTFS = 64
		        AND  CZZD1 = '1012'
				THEN '速E通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1013'
				THEN '联通华建'
				WHEN WTFS = 64
		        AND  CZZD1 = '1014'
				THEN '指E通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1015'
				THEN '闪电通'
				WHEN WTFS = 64
		        AND  CZZD1 = '1016'
				THEN '汇点'
				WHEN WTFS = 64
		        AND  CZZD1 = '1017'
				THEN '玉如意大智慧'				
				WHEN WTFS = 1
                THEN '电话交易'
				ELSE '其他交易'
				END  as TRD_CNCL
			 ,CASE WHEN WTFS = 32
		        AND  CZZD1 = '1005'
				THEN  1
				WHEN WTFS = 32
		        AND  CZZD1 = '1007'
				THEN 2
				WHEN WTFS = 32
		        AND  CZZD1 = '1008'
				THEN 3
				WHEN WTFS = 64
		        AND  CZZD1 = '1006'
				THEN 5
				WHEN WTFS = 64
		        AND  CZZD1 = '1010'
				THEN 6
				WHEN WTFS = 64
		        AND  CZZD1 = '1011'
				THEN 7
				WHEN WTFS = 64
		        AND  CZZD1 = '1012'
				THEN 8
				WHEN WTFS = 64
		        AND  CZZD1 = '1013'
				THEN 9
				WHEN WTFS = 64
		        AND  CZZD1 = '1014'
				THEN 10
				WHEN WTFS = 64
		        AND  CZZD1 = '1015'
				THEN 11
				WHEN WTFS = 64
		        AND  CZZD1 = '1016'
				THEN 12
				WHEN WTFS = 64
		        AND  CZZD1 = '1017'
				THEN 13				
				WHEN WTFS = 1
                THEN 15
				ELSE 17
				END  as SEQ1
		   ,COUNT(1)      as ODR_ITMS
		   ,SUM(0)      as VOL
		   ,KHH         as CUST_NO
           ,'普通账户'  as SYS_SRC
 FROM EDW_PROD.T_EDW_T05_TJRCP_YH_WTLS t
 WHERE SUBSTR(CAST(t.BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('20181121','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
 GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,CUST_NO,SEQ1 
 )   t
 GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,ODR_PSNNUM,SEQ1
 ) t
 GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC,SEQ1
 ;
  
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP5 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP5 as
  SELECT  TRD_CGY
         ,SEQ as SEQ
		  ,CASE WHEN SEQ = 1
               THEN 4
			   WHEN SEQ = 2
               THEN 14
			   WHEN SEQ = 3
               THEN 16
			   WHEN SEQ = 4
               THEN 18
			   END  as SEQ1
			   
         ,CASE WHEN SEQ = 1
               THEN '网上交易小计'
			   WHEN SEQ = 2
               THEN '手机交易小计'
			   WHEN SEQ = 3
               THEN '电话交易小计'
			   WHEN SEQ = 4
               THEN '其他交易小计'
			   END  as TRD_CNCL
          ,SYS_SRC
         ,SUM(ODR_ITMS) as ODR_ITMS
		 ,SUM(VOL) as VOL
		 ,SUM(ODR_PSNNUM) as ODR_PSNNUM
  FROM DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP4
  GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC ;
  
    DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP6 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP6 as
  SELECT  '合计'  as TRD_CGY
         ,6       as SEQ
		 ,18       as SEQ1
         ,'合计'  as TRD_CNCL
          ,SYS_SRC
         ,SUM(ODR_ITMS) as ODR_ITMS
		 ,SUM(VOL) as VOL
		 ,SUM(ODR_PSNNUM) as ODR_PSNNUM
  FROM DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP5
  GROUP BY TRD_CGY,SEQ,TRD_CNCL,SYS_SRC ;
  
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP7 ;
  CREATE TABLE DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP7 as
  SELECT TRD_CGY
         ,SEQ
		 ,SEQ1
		 ,TRD_CNCL
		 ,SYS_SRC		 
		 ,ODR_ITMS
		 ,VOL
		 ,ODR_PSNNUM
  FROM DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP4
  UNION ALL 
  SELECT TRD_CGY
         ,SEQ
		 ,SEQ1
		 ,TRD_CNCL
		 ,SYS_SRC		 
		 ,ODR_ITMS
		 ,VOL
		 ,ODR_PSNNUM
  FROM DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP5
  UNION ALL 
  SELECT TRD_CGY
         ,SEQ
		 ,SEQ1
		 ,TRD_CNCL
		 ,SYS_SRC		 
		 ,ODR_ITMS
		 ,VOL
		 ,ODR_PSNNUM
  FROM DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP6 ;
  
  
------期初创建临时表1  
 INSERT OVERWRITE DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON
 (
           TRD_CGY                      --交易类型
          ,TRD_CNCL                     --交易终端
          ,ODR_ITMS                     --委托笔数
          ,ODR_ITMS_MON_INCRS_RTO       --委托笔数环比增长率
          ,ODR_ITMS_SIM_PCT             --委托笔数同类占比
		  ,ODR_ITMS_TOT_PCT             --委托笔数总数占比		  
		  ,ODR_PSNNUM                   --委托人数
          ,ODR_PSNNUM_MON_INCRS_RTO     --委托人数环比增长率
          ,ODR_PSNNUM_SIM_PCT           --委托人数同类占比
		  ,ODR_PSNNUM_TOT_PCT           --委托人数总数占比
		  ,VOL                          --成交量
          ,VOL_MON_INCRS_RTO            --成交量环比增长率
          ,VOL_SIM_PCT                  --成交量同类占比
		  ,VOL_TOT_PCT                  --成交量总数占比
		  ,SYS_SRC                      --系统来源 
          ,SEQ
          ,SEQ1		  
) 
PARTITION( YEAR_MON = CAST(SUBSTR('20181121',1,6) as INT))
 SELECT   t.TRD_CGY                      --交易类型
          ,t.TRD_CNCL                     --交易终端
          ,t.ODR_ITMS                     --委托笔数
          ,CAST(CASE WHEN a3.SEQ1 IS NOT NULL 
		        AND  a3.ODR_ITMS > 0
				THEN ROUND((t.ODR_ITMS-a3.ODR_ITMS)*1.00000/a3.ODR_ITMS,4)
				ELSE NULL
				END  as DECIMAL(38,4))             as ODR_ITMS_MON_INCRS_RTO       --委托笔数环比增长率
          ,NVL(CAST(ROUND(t.ODR_ITMS*1.00000/a1.ODR_ITMS,4)as DECIMAL(38,4)),1) as ODR_ITMS_SIM_PCT             --委托笔数同类占比
		  ,CAST(ROUND(t.ODR_ITMS*1.00000/a2.ODR_ITMS,4)as DECIMAL(38,4)) as ODR_ITMS_TOT_PCT             --委托笔数总数占比		  
		  ,t.ODR_PSNNUM                   --委托人数
          ,CAST(CASE WHEN a3.SEQ1 IS NOT NULL 
		        AND  a3.ODR_PSNNUM > 0
				THEN ROUND((t.ODR_PSNNUM-a3.ODR_PSNNUM)*1.00000/a3.ODR_PSNNUM,4)
				ELSE NULL
				END as DECIMAL(38,4))                  as ODR_PSNNUM_MON_INCRS_RTO     --委托人数环比增长率
          ,NVL(CAST(ROUND(t.ODR_PSNNUM*1.00000/a1.ODR_PSNNUM,4)as DECIMAL(38,4)),1) as ODR_PSNNUM_SIM_PCT           --委托人数同类占比
		  ,CAST(ROUND(t.ODR_PSNNUM*1.00000/a2.ODR_PSNNUM,4)as DECIMAL(38,4)) as ODR_PSNNUM_TOT_PCT           --委托人数总数占比
		  ,t.VOL                          --成交量
          ,CAST(CASE WHEN a3.SEQ1 IS NOT NULL 
		             AND  a3.VOL > 0
				     THEN ROUND((t.VOL-a3.VOL)*1.00000/a3.VOL,4)
				     ELSE NULL
				     END as DECIMAL(38,4))              as VOL_MON_INCRS_RTO            --成交量环比增长率
          ,NVL(CAST(ROUND(t.VOL*1.00000/a1.VOL,4)as DECIMAL(38,4)),1)  as VOL_SIM_PCT                  --成交量同类占比
		  ,CAST(ROUND(t.VOL*1.00000/a2.VOL,4)as DECIMAL(38,4))  as VOL_TOT_PCT                  --成交量总数占比
		  ,t.SYS_SRC                      --系统来源  
          ,t.SEQ
          ,t.SEQ1		  
 FROM DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP3 t
 LEFT JOIN  DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP1  a1
 ON        t.SEQ = a1.SEQ
 AND       t.SYS_SRC = a1.SYS_SRC
 LEFT JOIN  DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP2  a2
 ON        t.YEAR_MON = a2.YEAR_MON
 AND       t.SYS_SRC = a2.SYS_SRC
 LEFT JOIN DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON_TEMP7  a3
 ON        t.SEQ1 = a3.SEQ1
 AND       t.SYS_SRC = a3.SYS_SRC
 AND       t.TRD_CGY = a3.TRD_CGY
 ;
 
-----------------------加载结束---------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_TRD_VOL_TRD_CNCL_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ; 
 invalidate metadata DDW_PROD.T_DDW_PRT_TRD_VOL_TRD_CNCL_MON;
------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:组合基金比例表                                                                    */
------/* 创建人:段智泓                                                                               */
------/* 创建时间:2018-11-26                                                                        */ 

 
 --清除数据
 TRUNCATE TABLE EDW_PROD.T_EDW_T04_GROUP_NV_FUND;
 
 ------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T04_GROUP_NV_FUND
(
                GROUP_ID       --组合id
			   ,FUND_CODE      --基金代码
			   ,SHARE          --基金比例
			   ,DT             --比例日期
			   ,UPDATE_TIME    --更细日期
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT     
                GROUP_ID       --组合id
			   ,FUND_CODE      --基金代码
			   ,SHARE          --基金比例
			   ,DT             --比例日期
			   ,UPDATE_TIME    --更细日期
FROM       JJLC.GROUP_NV_FUND
;
 ----删除临时表
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_GROUP_NV_FUND',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
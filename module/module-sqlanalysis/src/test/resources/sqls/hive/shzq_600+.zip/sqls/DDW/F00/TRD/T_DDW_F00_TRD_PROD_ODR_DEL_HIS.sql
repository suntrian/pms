 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:产品委托明细历史表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
--------------------------------------删除今天的数据--------------------------------
ALTER TABLE DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS DROP IF EXISTS  PARTITION (BUS_DATE = %d{yyyyMMdd});
------------------------------------删除今天的数据结束------------------------------ 
-------------删除临时表-------------------
DROP TABLE IF EXISTS DDW_PROD.TEMP_T_DDW_F00_TRD_PROD_ODR_DEL_HIS;
------------删除临时表结束-----------------

--------创建临时表 二代证验证------
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP ;
  CREATE  TABLE DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP 
  as SELECT      t1.KHH
                ,t1.RQ
				, 1  as BZ 
     FROM ( SELECT    t.KHH
	                 ,t.RQ
            FROM  ( SELECT    KHH
			                  ,RQ
                    FROM    EDW_PROD.T_EDW_T05_TYGTXTCZMX
                    WHERE   YWKM = '20090' 
					OR      ZY LIKE '%二代证验证%'
                    UNION ALL
                    SELECT     a.KHH
					          ,b.SQRQ as RQ
                    FROM       (SELECT YYB
					                  ,ZJBH
									  ,KHH
								FROM  EDW_PROD.T_EDW_T01_TKHXX 
								WHERE BUS_DATE = %d{yyyyMMdd}
								)     a
                   INNER JOIN (SELECT  ZJBH
				                       ,YYB
									   ,SQRQ
							   FROM  EDW_PROD.T_EDW_T02_TGMSFCXSQ 
							   WHERE CLJG = 1
							   )                b
                  ON           a.yyb = b.yyb
                  AND          a.zjbh = b.zjbh
                 ) t
           GROUP BY t.khh,t.rq
          )       t1
	  ; 
-----创建临时表2	  
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP1;
  CREATE TABLE DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP1 as
  SELECT   ApplyingCodeFront as ZQDM1
          ,SecurityCode      as ZQDM
		  ,a.DT              as DT
  FROM   FUNDEXT.DBO_MF_FundArchives  a
  WHERE  a.DT = '%d{yyyyMMdd}'
  AND    LENGTH(TRIM(NVL(a.ApplyingCodeFront,'')))>0
  AND    LENGTH(TRIM(NVL(a.SecurityCode,'')))>0 
  AND    a.ApplyingCodeFront <> a.SecurityCode
  AND    SUBSTR(a.SecurityCode,7,1) <> 'J'
  UNION 
  SELECT  ApplyingCodeBack as ZQDM1
         ,SecurityCode     as ZQDM
		 ,a.DT             as DT
  FROM    FUNDEXT.DBO_MF_FundArchives  a
  WHERE   a.DT = '%d{yyyyMMdd}'
  AND     LENGTH(TRIM(NVL(a.ApplyingCodeBack,'')))>0
  AND     LENGTH(TRIM(NVL(a.SecurityCode,'')))>0 
  AND     a.ApplyingCodeBack <> a.SecurityCode
  AND     SUBSTR(a.securitycode,7,1) <> 'J'
  ;
  -----创建临时表2
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP2;
  CREATE TABLE DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP2 as
  SELECT    a.ApplyingCode    as ZQDM1
           ,MIN(b.SecurityCode) as ZQDM  
  FROM        FUNDEXT.DBO_MF_IssueAndListing                 a
  LEFT JOIN   fundext.dbo_MF_FundArchives                    b
  ON          a.INNERCODE = b.INNERCODE
  AND         a.DT = b.DT
  WHERE       a.DT = '%d{yyyyMMdd}'	
  AND         b.SecurityCode NOT LIKE '%J' 
  AND         LENGTH(TRIM(NVL(a.ApplyingCode,'')))>0
  GROUP BY   a.ApplyingCode
  UNION 
  SELECT     SUBSTR(a.ApplyingCode,1,6)     as ZQDM1
             ,MIN(SUBSTR(SecurityCode,1,6)) as ZQDM  
  FROM        FUNDEXT.DBO_MF_IssueAndListing                 a
  LEFT JOIN   fundext.dbo_MF_FundArchives                    b
  ON          a.INNERCODE = b.INNERCODE
  AND         a.DT = b.DT
  WHERE       a.DT = '%d{yyyyMMdd}'	
  AND         b.SecurityCode  LIKE '%J'
  AND         LENGTH(TRIM(NVL(a.ApplyingCode,'')))>0
  GROUP BY    SUBSTR(a.ApplyingCode,1,6)
  ;
  
  
  
  
--------------插入基金委托数据-------------------
 INSERT INTO DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS
(
                                    EVNT_SEQNBR                                   --事件序号
                                   ,ODR_NO                                        --委托号   
                                   ,CNCL_FLG                                      --撤销标志  
                                   ,CUST_NO                                       --客户号   
                                   ,CUST_NAME                                     --客户姓名  
                                   ,BRH_NO                                        --营业部编号
                                   ,OCC_BRH_NO                                    --发生营业部编号								   
                                   ,BRH_NAME                                      --营业部名称
                                   ,TA_CD                                         --TA代码
                                   ,ISSUE_ORG                                     --发行机构								   
								   ,ADMIN_CD                                      --管理人代码
								   ,PROD_BIZ_CD                                   --产品业务代码
								   ,APL_NO                                        --申请编号
								   ,AGMT_NO                                       --协议编号
								   ,PROD_CD                                       --产品代码
                                   ,PROD_CD1                                      --产品代码  
                                   ,PROD_NAME                                     --产品简称  
                                   ,ODR_DT                                        --委托日期
                                   ,ODR_TM                                        --委托时间								   
                                   ,RPT_DT                                        --申报日期  
                                   ,RPT_TM                                        --申报时间
                                   ,PRT_RSLT                                      --申报结果
                                   ,DEAL_RSLT                                     --处理结果								   
                                   ,ODR_MOD                                       --委托方式  
                                --   ,BIZ_CGY                                       --业务类别  
                                   ,PROD_RSK_LVL                                  --产品风险等级
                                   ,RSK_BEAR_ABLTY                                --风险承受能力
								   ,CCY_CD                                        --币种代码
                                   ,ODR_SHR                                       --委托份额  
                                   ,ODR_AMT                                       --委托金额  
                                   ,ABST                                          --摘要    
                                   ,SECOND_CARD_VRFCTN                            --二代证验证 
								   ,OPRT_CLNT                                     --操作终端
                                   ,SCRP_AGE                                      --认购年龄  
                                   ,ODR_CGY                                       --委托来源 
)								   
 partition(bus_date=%d{yyyyMMdd})
 SELECT                 t.SEQNO                                   as EVNT_SEQNBR                                   --事件序号
                       ,t.WTH                                     as ODR_NO                                        --委托号   
                       ,t.CXBZ                                    as CNCL_FLG                                      --撤销标志  
                       ,t.KHH                                     as CUST_NO                                       --客户号   
                       ,t.KHXM                                    as CUST_NAME                                     --客户姓名  
                       ,t.YYB                                     as BRH_NO                                        --营业部编号 
                       ,t.FSYYB                                   as OCC_BRH_NO                                    --发生营业部编号	
					   ,NVL(a4.BRH_SHRTNM,a7.FILIL_DEPT_SHRTNM)                             as BRH_NAME                                      --营业部名称
                       ,t.TADM                                    as TA_CD                                         --TA代码	
                       ,NULL                                      as ISSUE_ORG                                     --发行机构					   
                       ,a3.GLRDM                                  as ADMIN_CD                                      --管理人代码
                       ,t.YWDM                                    as PROD_BIZ_CD                                   --产品业务代码
                       ,t.SQBH                                    as APL_NO                                        --申请编号
					   ,NULL                                      as AGMT_NO                                       --协议编号
                       ,CASE WHEN a1.ZQDM1 IS NOT NULL
							 THEN a1.ZQDM
							 WHEN a2.ZQDM1 IS NOT NULL
							 THEN a2.ZQDM
							 WHEN t.JJDM = '519028'
							 THEN '519029'
							 WHEN t.JJDM = '180042'
							 THEN '180002'
							 ELSE t.JJDM
							 END                                  as PROD_CD                                       --产品代码
                       ,t.JJDM                                    as PROD_CD1                                      --产品代码  
                       ,t.JJJC                                    as PROD_NAME                                     --产品简称  
                       ,t.WTRQ                                    as ODR_DT                                        --委托日期
                       ,t.WTSJ                                    as ODR_TM                                        --委托时间		
                       ,t.SBRQ                                    as RPT_DT                                        --申报日期  
                       ,t.SBSJ                                    as RPT_TM                                        --申报时间
                       ,t.SBJG                                    as PRT_RSLT                                      --申报结果
                       ,NULL                                      as DEAL_RSLT                                     --处理结果					   
                       ,t.WTFS                                    as ODR_MOD                                       --委托方式    
                       ,CAST(a3.JJFXDJ AS STRING)                 as PROD_RSK_LVL                                  --产品风险等级
                       ,a5.FXCSNL                                 as RSK_BEAR_ABLTY                                --风险承受能力
                       ,t.JSBZDM                                  as CCY_CD                                        --币种代码
                       ,t.WTFE                                    as ODR_SHR                                       --委托份额  
                       ,t.WTJE                                    as ODR_AMT                                       --委托金额  
                       ,t.ZY                                      as ABST                                          --摘要    
                       ,CASE WHEN a6.BZ = 1 
                             THEN '已验证'	
 							 ELSE '未验证'
							 END                                  as SECOND_CARD_VRFCTN                            --二代证验证 
                       ,t.CZZD1                                   as OPRT_CLNT                                     --操作终端
                       ,CAST(t.KHGMNL as DECIMAL(38,0))           as SCRP_AGE                                      --认购年龄  
                       ,8                                         as ODR_CGY                                       --委托来源 
 FROM 	    EDW_PROD.T_EDW_T05_TOF_JJWTLS                      t
 LEFT JOIN  DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP2      a1
 ON         t.JJDM = a1.ZQDM1
 LEFT JOIN  ( SELECT    ZQDM1
                       ,MIN(ZQDM) as ZQDM 
			   FROM     DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP1
			   GROUP BY ZQDM1
			 )                                                 a2  
 ON         t.JJDM = a2.ZQDM1
 LEFT JOIN     EDW_PROD.T_EDW_T04_TOF_JJXX                     a3
 ON            t.JJDM = a3.JJDM
 AND           t.TADM = a3.TADM
 AND           a3.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                a4
  ON            t.YYB = a4.BRH_NO
  AND           a4.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a7
  ON            t.YYB = a7.FILIL_DEPT_CDG
  AND           a7.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     EDW_PROD.T_EDW_T01_TKHXX                  a5 
 ON            t.KHH = a5.KHH 
 AND           a5.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP     a6
 ON            t.SBRQ = a6.RQ
 AND           t.KHH = a6.KHH
 WHERE         t.bus_date = %d{yyyyMMdd}
  ;
 
  ----插入金融产品委托
  INSERT INTO DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS
(
                                    EVNT_SEQNBR                                   --事件序号
                                   ,ODR_NO                                        --委托号   
                                   ,CNCL_FLG                                      --撤销标志  
                                   ,CUST_NO                                       --客户号   
                                   ,CUST_NAME                                     --客户姓名  
                                   ,BRH_NO                                        --营业部编号 
                                   ,OCC_BRH_NO                                    --发生营业部编号					
								   ,BRH_NAME                                      --营业部名称
                                   ,TA_CD                                         --TA代码
                                   ,ISSUE_ORG                                     --发行机构								   
								   ,ADMIN_CD                                      --管理人代码
								   ,PROD_BIZ_CD                                   --产品业务代码
								   ,APL_NO                                        --申请编号
								   ,AGMT_NO                                       --协议编号
								   ,PROD_CD                                       --产品代码
                                   ,PROD_CD1                                      --产品代码  
                                   ,PROD_NAME                                     --产品简称  
                                   ,ODR_DT                                        --委托日期
                                   ,ODR_TM                                        --委托时间								   
                                   ,RPT_DT                                        --申报日期  
                                   ,RPT_TM                                        --申报时间
                                   ,PRT_RSLT                                      --申报结果
                                   ,DEAL_RSLT                                     --处理结果								   
                                   ,ODR_MOD                                       --委托方式  
                                --   ,BIZ_CGY                                       --业务类别  
                                   ,PROD_RSK_LVL                                  --产品风险等级
                                   ,RSK_BEAR_ABLTY                                --风险承受能力
								   ,CCY_CD                                        --币种代码
                                   ,ODR_SHR                                       --委托份额  
                                   ,ODR_AMT                                       --委托金额  
                                   ,ABST                                          --摘要    
                                   ,SECOND_CARD_VRFCTN                            --二代证验证 
								   ,OPRT_CLNT                                     --操作终端
                                   ,SCRP_AGE                                      --认购年龄  
                                   ,ODR_CGY                                       --委托来源 
)								   
 partition(bus_date=%d{yyyyMMdd})
 SELECT                 t.SEQNO                                    as EVNT_SEQNBR                                   --事件序号
                       ,t.WTH                                     as ODR_NO                                        --委托号   
                       ,t.CXBZ                                    as CNCL_FLG                                      --撤销标志  
                       ,t.KHH                                     as CUST_NO                                       --客户号   
                       ,t.KHXM                                    as CUST_NAME                                     --客户姓名  
                       ,t.YYB                                     as BRH_NO                                        --营业部编号 
                       ,t.FSYYB                                   as OCC_BRH_NO                                    --发生营业部编号
					   ,NVL(a1.BRH_SHRTNM,a6.FILIL_DEPT_SHRTNM)                             as BRH_NAME                                      --营业部名称
                       ,NULL                                      as TA_CD                                         --TA代码	
                       ,t.FXJG                                    as ISSUE_ORG                                     --发行机构					   
                       ,NULL                                      as ADMIN_CD                                      --管理人代码
                       ,t.JRCP_YWDM                               as PROD_BIZ_CD                                   --产品业务代码
                       ,t.SQBH                                    as APL_NO                                        --申请编号
					   ,t.XYBH                                    as AGMT_NO                                       --协议编号
                       ,t.CPDM                                    as PROD_CD                                       --产品代码
                       ,t.CPDM                                    as PROD_CD1                                      --产品代码  
                       ,t.CPJC                                    as PROD_NAME                                     --产品简称  
                       ,t.WTRQ                                    as ODR_DT                                        --委托日期
                       ,t.WTSJ                                    as ODR_TM                                        --委托时间		
                       ,t.SBRQ                                    as RPT_DT                                        --申报日期  
                       ,t.SBSJ                                    as RPT_TM                                        --申报时间
                       ,t.SBJG                                    as PRT_RSLT                                      --申报结果
                       ,t.CLJG                                    as DEAL_RSLT                                     --处理结果					   
                       ,t.WTFS                                    as ODR_MOD                                       --委托方式    
                       ,CAST(a5.JRCP_ZQFXDJ AS STRING)            as PROD_RSK_LVL                                  --产品风险等级
                       ,a2.FXCSNL                                 as RSK_BEAR_ABLTY                                --风险承受能力
                       ,t.BZDM                                    as CCY_CD                                        --币种代码
                       ,t.WTFE                                    as ODR_SHR                                       --委托份额  
                       ,t.WTJE                                    as ODR_AMT                                       --委托金额  
                       ,NULL                                      as ABST                                          --摘要    
                       ,CASE WHEN a3.BZ = 1 
                             THEN '已验证'	
 							 ELSE '未验证'
							 END                                  as SECOND_CARD_VRFCTN                            --二代证验证 
                       ,t.CZZD1                                   as OPRT_CLNT                                     --操作终端
                       ,CAST(t.KHGMNL as DECIMAL(38,0))           as SCRP_AGE                                      --认购年龄  
                       ,9                                         as ODR_CGY                                       --委托来源 
  FROM          EDW_PROD.T_EDW_T05_TJRCP_YH_WTLS                 t
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                a1
  ON            t.YYB = a1.BRH_NO
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a6
  ON            t.YYB = a6.FILIL_DEPT_CDG
  AND           a6.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     EDW_PROD.T_EDW_T01_TKHXX                         a2 
  ON            t.KHH = a2.KHH  
  AND           a2.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP            a3
  ON            t.SBRQ = a3.RQ
  AND           t.KHH = a3.KHH
  LEFT JOIN     EDW_PROD.T_EDW_T04_TJRCP_CPDM              a5
  ON            t.CPDM = a5.CPDM
  AND           a5.BUS_DATE = %d{yyyyMMdd}
  WHERE         t.BUS_DATE = %d{yyyyMMdd}
  ;
 --------------删除临时表-------------------
    DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP1;
    DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP;
	DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS_TEMP2;

----------------------插入数据结束------------------------

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_TRD_PROD_ODR_DEL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata DDW_PROD.T_DDW_F00_TRD_PROD_ODR_DEL_HIS ;
 /* ***************************************** SQL Begin *****************************************  */
  /* 脚本功能:大宗交易表                                                                          */
  /* 创建人:黄勇华                                                                               */
  /* 创建时间:2016-11-30                                                                        */ 
  /* T_DDW_F05_SYS_ACCNT_ODR_DEL  修改为 T_DDW_F00_TRD_SEC_ODR_DEL_HIS*/
  /* T_DDW_F05_SYS_ACCNT_DLV_HIS  修改为 T_EDW_T05_TJGMXLS  */
  
  
  --删除临时表
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_BULK_TRD_TEMP1;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_BULK_TRD_TEMP;
--创建临时表

CREATE TABLE  DDW_PROD.T_DDW_PRT_BULK_TRD_TEMP1  AS 
  SELECT t1.khh,t1.rq, 1 as bz 
  FROM (
         SELECT t.khh,t.rq
         FROM (
	             SELECT  khh,rq 
                 FROM   EDW_PROD.T_EDW_T05_TYGTXTCZMX
                 WHERE  YWKM = '20090' OR  zy like '%二代证验证%'
                 UNION ALL
                 SELECT     a1.khh,a2.sqrq as rq
                 FROM       (SELECT yyb,zjbh,khh FROM  EDW_PROD.T_EDW_T01_TKHXX where bus_date = %d{yyyyMMdd})     a1
                 INNER JOIN (SELECT zjbh,yyb,sqrq FROM EDW_PROD.T_EDW_T02_TGMSFCXSQ WHERE CLJG = 1)                a2
                 ON           a1.yyb = a2.yyb
                 AND          a1.zjbh = a2.zjbh
              ) t
       GROUP BY t.khh,t.rq
      )   t1
	  ; 
	  


--------初始化开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_BULK_TRD
(
									 BRH_NO						--营业部编号
									,BRH_NAME
									,CUST_NO             		--客户号
									,CUST_NAME           		--客户姓名
									,EXG                 		--交易所
									,SHRHLD_NO           		--股东号
									,ODR_DT              		--委托日期
									,ODR_TM              		--委托时间
									,ODR_CGY             		--委托类别
									,ODR_CGY_NAME             	--委托类别名称
									,SEC_CD              		--证券代码
									,SEC_NAME            		--证券名称
									,SEC_CGY             		--证券类别
									,ODR_QTY             		--委托数量
									,ODR_PRC             		--委托价格
									,RPT_RSLT            		--申报结果
									,RSLT_EXPLN          		--结果说明
									,MTCH_QTY            		--成交数量
									,MTCH_AMT            		--成交金额
									,MTCH_PRC            		--成交价格
									,MTCH_MT             		--成交时间
									,ODR_TELR            		--委托柜员
									,RECHK_TELR          		--复核柜员
									,SECOND_CARD_VRFCTN  		--二代证验证
                                    ,CTF_CGY                    --开户证件类别
) 
 PARTITION(bus_date = %d{yyyyMMdd})
 SELECT 
						 t.BRH_NO						AS  BRH_NO									--营业部编号
						,t.BRH_NAME						AS	BRH_NAME	
						,t.CUST_NO						AS  CUST_NO             					--客户号
						,t.CUST_NAME					AS  CUST_NAME           					--客户姓名
						,t.EXG							AS  EXG                 					--交易所
						,t.SHRHLD_NO					AS  SHRHLD_NO           					--股东号
						,t.ODR_DT						AS  ODR_DT              					--委托日期
						,t.ODR_TM						AS  ODR_TM              					--委托时间
						,t.ODR_CGY						AS  ODR_CGY             					--委托类别
						,a1.JYLBMC						AS	ODR_CGY_NAME             				--委托类别名称
						,t.SEC_CD						AS  SEC_CD              					--证券代码
						,t.SEC_NAME						AS  SEC_NAME            					--证券名称
						,t.SEC_CGY						AS  SEC_CGY             					--证券类别
						,t.ODR_QTY						AS  ODR_QTY             					--委托数量
						,t.ODR_PRC						AS  ODR_PRC             					--委托价格
						,t.RPT_RSLT						AS  RPT_RSLT            					--申报结果
						,t.RSLT_EXPLN					AS  RSLT_EXPLN          					--结果说明
						,t.MTCH_QTY						AS  MTCH_QTY            					--成交数量
						,t.MTCH_AMT						AS  MTCH_AMT            					--成交金额
						,t.MTCH_PRC						AS  MTCH_PRC            					--成交价格
						,t.MTCH_MT						AS  MTCH_MT             					--成交时间
						,t.ODR_TELR						AS  ODR_TELR            					--委托柜员
						,t.RECHK_TELR					AS  RECHK_TELR          					--复核柜员
						,t.SECOND_CARD_VRFCTN			AS  SECOND_CARD_VRFCTN  					--二代证验证
						--,t.BUS_DATE                  	AS  BUS_DATE
    				    ,a3.CTF_CGY_CD_NAME             AS   CTF_CGY  --开户证件类别
  FROM  		DDW_PROD.T_DDW_F00_TRD_SEC_ODR_DEL_HIS  	t
  LEFT JOIN     EDW_PROD.T_EDW_T99_TJYLB			a1
  ON			CAST(t.ODR_CGY AS DECIMAL(38,0)) = a1.JYLB
  AND			a1.XTBS = 'JZJY'
  AND           t.BUS_DATE = a1.BUS_DATE
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a2
  ON            t.CUST_NO = a2.CUST_NO
  AND           a2.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD     a3
  ON            a2.CTF_CGY_CD = a3.CTF_CGY_CD
  WHERE 		ACCNT_CGY = '普通账户' 
  AND           ODR_CGY IN (57,58,59,60)
  AND			t.bus_date  =  %d{yyyyMMdd}
  AND           t.EXG <> 'TA'
  UNION ALL     
  SELECT 
  						 t.BRH_NO						AS  BRH_NO									--营业部编号
						,a2.BRH_NAME				    AS	BRH_NAME	
						,t.CUST_NO						AS  CUST_NO             					--客户号
						,t.CUST_NAME					AS  CUST_NAME           					--客户姓名
						,t.EXG							AS  EXG                 					--交易所
						,t.SHRHLD_NO					AS  SHRHLD_NO           					--股东号
						,t.MTCH_DT						AS  ODR_DT              					--委托日期
						,NULL						    AS  ODR_TM              					--委托时间
						,t.ODR_CGY 				        AS  ODR_CGY             					--委托类别
						,a1.JYLBMC						AS	ODR_CGY_NAME             				--委托类别名称
						,t.SEC_CD						AS  SEC_CD              					--证券代码
						,t.SEC_NAME						AS  SEC_NAME            					--证券名称
						,t.SEC_CGY						AS  SEC_CGY             					--证券类别
						,t.MTCH_QTY						AS  ODR_QTY             					--委托数量
						,t.MTCH_PRC 			        AS  ODR_PRC             					--委托价格
						,NULL						    AS  RPT_RSLT            					--申报结果
						,NULL					        AS  RSLT_EXPLN          					--结果说明
						,t.MTCH_QTY						AS  MTCH_QTY            					--成交数量
						,t.MTCH_AMT						AS  MTCH_AMT            					--成交金额
						,t.MTCH_PRC						AS  MTCH_PRC            					--成交价格
						,NULL						    AS  MTCH_MT             					--成交时间
						,NULL						    AS  ODR_TELR            					--委托柜员
						,NULL					        AS  RECHK_TELR          					--复核柜员
						,NULL			                AS  SECOND_CARD_VRFCTN  					--二代证验证
    				    ,a3.CTF_CGY_CD_NAME             AS   CTF_CGY  --开户证件类别
  FROM  		DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS  	t
  LEFT JOIN     EDW_PROD.T_EDW_T99_TJYLB			a1
  ON			CAST(t.ODR_CGY AS DECIMAL(38,0)) = a1.JYLB
  AND			a1.XTBS = 'JZJY'
  AND           t.BUS_DATE = a1.BUS_DATE
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO               a2
  ON            t.CUST_NO = a2.CUST_NO
  AND           a2.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.V_CTF_CGY_CD     a3
  ON            a2.CTF_CGY_CD = a3.CTF_CGY_CD
  WHERE 		SYS_SRC = '普通账户'
  AND      t.ODR_NO = 0
  AND     t.ODR_CGY IN (1,2)
  AND     t.EXG <> 'TA'
  AND     t.bus_date =  %d{yyyyMMdd}
  ;
 
-----------------------------初始化结束--------------------

 --删除临时表
   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_BULK_TRD_TEMP1;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_BULK_TRD_TEMP;
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_BULK_TRD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_PRT_BULK_TRD;
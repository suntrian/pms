--/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:客户对账单收益率日表                                                                       */
  --/* 创建人:黄勇华                                                                               */
  --/* 创建时间:2017-02-02                                                                        */

 INSERT OVERWRITE DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_DAY
 (
                         CUST_NO                    --客户号                                   
						,NET_INCM                   --收益率                    					
 ) 
 partition(bus_date )
 SELECT           t.CUST_NO                        as CUST_NO                    --客户号                        
                  ,t.NET_INCM                      as NET_INCM                   --收益率
				  ,t.BUS_DATE                      as BUS_DATE
 FROM        DDW_PROD.T_DDW_CUST_STATMT_DAY    t
 WHERE       EXISTS(SELECT 1 FROM DDW_PROD.T_DDW_F00_CUST_CUST_INFO a 
                    WHERE  (a.ORDI_CUST_STAT < > '3' OR a.ORDI_CNCLACT_DT > %d{yyyyMMdd})
                    AND    a.BUS_DATE = %d{yyyyMMdd}					
					AND    t.CUST_NO = a.CUST_NO
                    )
 AND   SUBSTR(CAST(t.BUS_DATE as STRING),1,6) =   SUBSTR('%d{yyyyMMdd}',1,6)   
 ;       
  
-------------------------插入数据结束---------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_CUST_STATMT_NET_INCM_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_CUST_STATMT_NET_INCM_DAY;
--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:金融产品基础属性统计表                                                               */
--/* 创建人:OYJ                                                                                    */
--/* 创建时间:2019-5-17                                                                            */ 

ALTER TABLE DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR DROP IF EXISTS PARTITION (BUS_DATE = %d{yyyyMMdd});

--上日金融产品内部编码临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP1;
CREATE TABLE DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP1
AS
SELECT A.PROD_CD,A.PROD_CL_CD,A.PROD_CODE,A.ISSUE_PLCG_MOD,A.DATA_SCR,MAX(A.INR_CD) AS INR_CD
FROM DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR A
WHERE EXISTS (SELECT 1 FROM EDW_PROD.T_EDW_T99_TRD_DATE B
		                     WHERE  B.BUS_DATE = %d{yyyyMMdd}
							 AND    A.BUS_DATE = B.LST_TRD_D
							 AND    B.TRD_DT = %d{yyyyMMdd}
             )
GROUP BY A.PROD_CD,A.PROD_CL_CD,A.PROD_CODE,A.ISSUE_PLCG_MOD,A.DATA_SCR
;

--当日金融产品代码临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP2;
CREATE TABLE DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP2
AS
SELECT MAX(A.ID) AS ID,NVL(B.INR_CD,'') AS INR_CD,A.CPDM AS PROD_CD,A.CPFL AS PROD_CL_CD
      ,CASE WHEN SUBSTR(A.CPFL,1,2) = '01' AND TRIM(NVL(C.EXAPPLYINGCODE,'')) <> '' THEN C.EXAPPLYINGCODE ELSE A.CPDM END AS PROD_CODE
	  ,'CRM' AS DATA_SCR
FROM 
(
  SELECT *
  FROM EDW_PROD.T_EDW_T04_C5_TSPIF_CPDM
  WHERE BUS_DATE  = %d{yyyyMMdd}
  AND (SHBZ = 1 OR CPDM = '006371')
  AND CPDM NOT IN (SELECT CPDM FROM EDW_PROD.T_EDW_T04_C5_TSPIF_CPDM WHERE BUS_DATE  = %d{yyyyMMdd} AND (SHBZ = 1 OR CPDM = '006371') GROUP BY CPDM,CPFL HAVING COUNT(*) > 1)
) A
LEFT JOIN DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP1 B
ON A.CPDM = B.PROD_CD
AND A.CPFL = B.PROD_CL_CD
LEFT JOIN FUNDEXT.DBO_MF_FUNDARCHIVES C
ON A.CPDM = C.SECURITYCODE 
AND C.DT = '%d{yyyyMMdd}'
AND %d{yyyyMMdd} >= CASE WHEN NVL(C.STARTDATE,'') = '' THEN 19000101 ELSE CAST(REPLACE(SUBSTR(NVL(C.STARTDATE,''),1,10),'-','') AS INT) END
AND %d{yyyyMMdd} < CASE WHEN NVL(C.EXPIREDATE,'') = '' THEN 99991231 ELSE CAST(REPLACE(SUBSTR(NVL(C.EXPIREDATE,''),1,10),'-','') AS INT) END
WHERE A.BUS_DATE  = %d{yyyyMMdd}
AND (A.SHBZ = 1 OR A.CPDM = '006371')
GROUP BY NVL(B.INR_CD,''),A.CPDM,A.CPFL,CASE WHEN SUBSTR(A.CPFL,1,2) = '01' AND TRIM(NVL(C.EXAPPLYINGCODE,'')) <> '' THEN C.EXAPPLYINGCODE ELSE A.CPDM END
;

--当日场内基金信息临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP3;
CREATE TABLE DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP3
AS
SELECT
   '' AS ID                                                                             --  1 . 产品ID(PK)
  ,CASE WHEN T7.INR_CD IS NOT NULL THEN T7.INR_CD ELSE '' END AS INR_CD                 --  2 . 产品内部代码
  ,T1.ZQDM AS PROD_CD                                                                   --  3 . 产品代码
  ,CASE WHEN T2.FUNDTYPECODE = 1101 THEN '010100'
        WHEN T2.FUNDTYPECODE = 1103 THEN '010500'
		WHEN T2.FUNDTYPECODE = 1105 THEN '010200'
		WHEN T2.FUNDTYPECODE = 1109 THEN '010300'
   ELSE '010600' END AS PROD_CL_CD  				  		                            --  4 . 产品分类
  ,CASE WHEN T2.FUNDTYPECODE = 1101 THEN '股票基金'
        WHEN T2.FUNDTYPECODE = 1103 THEN '混合基金'
		WHEN T2.FUNDTYPECODE = 1105 THEN '债券基金'
		WHEN T2.FUNDTYPECODE = 1109 THEN '货币市场基金'
   ELSE '其它' END AS PROD_CL_DSC                                                       --  5 . 产品分类描述
  ,T1.ZQQC AS PROD_FULLNM                                                               --  6 . 产品全称
  ,T1.ZQMC AS PROD_SHRTNM                                                               --  7 . 产品简称
  ,0 as PROD_CRINT_DT                                                                   --  8 . 产品起息日
  ,NVL(CAST(REPLACE(SUBSTR(NVL(T2.ESTABLISHMENTDATE,''),1,10),'-','') AS INT),0) AS PROD_ESTAB_DT           --  9 . 产品成立日
  ,NVL(CAST(REPLACE(SUBSTR(NVL(T2.EXPIREDATE,''),1,10),'-','') AS INT),0) AS IVSM_EXPI_DT                   -- 10 . 投资到期日
  ,T1.DFRQ AS CASHE_DT                                                                                      -- 11 . 兑付日期
  ,NVL(CAST(REPLACE(SUBSTR(NVL(T6.ISSUESTARTDATE,''),1,10),'-','') AS INT),0) AS RAIS_STRT_DT               -- 12 . 募集起始日期
  ,NVL(CAST(REPLACE(SUBSTR(NVL(T6.ISSUEENDDATE,''),1,10),'-','') AS INT),0) AS RAIS_END_DT                  -- 13 . 募集结束日期
  ,NVL(T3.TACODE,'') AS PROD_ADMIN                                                      -- 14 . 产品管理人
  ,NVL(T3.INVESTADVISORNAME,'') AS PROD_ADMIN_DSC                                       -- 15 . 产品管理人描述
  ,'' AS PROD_SCL_UPLMT                                                                 -- 16 . 产品规模上限
  ,'' AS SALE_NETPOT                                                                    -- 17 . 销售网点
  ,'' AS PROD_SALE_REG                                                                  -- 18 . 产品销售地区
  ,0 AS PROD_SALE_STRT_DT                                                               -- 19 . 产品销售起始日期
  ,0 AS PROD_SALE_END_DT                                                                -- 20 . 产品销售结束日期
  ,0 AS PROD_SUST_MKT_START_DT                                                          -- 21 . 产品持续营销起始日
  ,0 AS PROD_SUST_MKT_END_DT                                                            -- 22 . 产品持续营销结束日
  ,'' AS PROD_HLT                                                                       -- 23 . 产品亮点
  ,'' AS PROD_ASS_POLICY                                                                -- 24 . 产品考核政策
  ,'' AS SALE_CNL_CD                                                                    -- 25 . 销售渠道
  ,'' AS IF_HOT                                                                         -- 26 . 是否核心销售
  ,'' AS IF_KEY_SALES                                                                   -- 27 . 是否重点销售产品
  ,'' AS PROD_DEDLN                                                                     -- 28 . 产品期限
  ,'' AS YLD_TP_CD                                                                      -- 29 . 收益类型(适当性)
  ,'' AS YLD_TP_DSC                                                                     -- 30 . 收益类型描述
  ,T1.ZQFXDJ AS PROD_RSK_RTG_CD                                                         -- 31 . 产品风险评级
  ,CASE WHEN T1.ZQFXDJ = '1' THEN '低风险级别'
        WHEN T1.ZQFXDJ = '2' THEN '较低风险级别'
        WHEN T1.ZQFXDJ = '3' THEN '中等风险级别'
        WHEN T1.ZQFXDJ = '4' THEN '较高风险级别'
        WHEN T1.ZQFXDJ = '5' THEN '高风险级别'
   ELSE '未知' END AS PROD_RSK_RTG_DSC                                                  -- 32 . 产品风险评级描述
  ,'' AS LINKED_RLD_CGY_CD                                                              -- 33 . 挂钩标的类别 
  ,'' AS LINKED_RLD_CGY_NM                                                              -- 34 . 挂钩标的名称 
  ,0 AS LINKED_RTO                                                                      -- 35 . 挂钩率(%) 
  ,'' AS LINKED_YLD_EXPLN                                                               -- 36 . 挂钩收益说明 
  ,'' AS TRD_LOCTN                                                                      -- 37 . 交易场所 
  ,0 AS ADVBOOK_START_DT                                                                -- 38 . 预售期起始日
  ,0 AS ADVBOOK_END_DT                                                                  -- 39 . 预售期结束日
  ,0 AS WINDG_START_DT                                                                  -- 40 . 清盘期起始日
  ,0 AS WINDG_END_DT                                                                    -- 41 . 清盘期结束日
  ,0 AS PROD_END_DT                                                                     -- 42 . 产品结束日
  ,'' AS PROD_PHS_CD                                                                    -- 43 . 产品阶段
  ,'' AS PROD_PHS_DSC                                                                   -- 44 . 产品阶段描述
  ,T1.ZQJYZT AS TRD_STAT_CD                                                             -- 45 . 交易状态
  ,NVL(T4.BMSM,'') AS TRD_STAT_DSC                                                      -- 46 . 交易状态描述
  ,'' AS PROD_DEDLN_SDX                                                                 -- 47 . 产品期限(适当性)
  ,'' AS PROD_DEDLN_SDX_DSC                                                             -- 48 . 产品期限描述
  ,'' AS IF_PROD_GRADE_CD                                                               -- 49 . 产品是否分级
  ,'' AS IF_PROD_GRADE_DSC                                                              -- 50 . 产品是否分级描述
  ,NVL(T5.UNITNV,0) AS UNIT_NAV                                                         -- 51 . 单位净值
  ,NVL(T5.ACCUMULATEDUNITNV,0) AS GT_NAV                                                -- 52 . 累计净值
  ,%d{yyyyMMdd} AS NAV_DT                                                               -- 53 . 净值日期
  ,0 AS IDV_FSTTM_SCRP_LOW_AMT                                                          -- 54 . 个人首次认购最低金额
  ,0 AS ORG_FSTTM_SCRP_LOW_AMT                                                          -- 55 . 机构首次认购最低金额
  ,0 AS IDV_ADDI_SCRP_LOW_AMT                                                           -- 56 . 个人追加认购最低金额
  ,0 AS ORG_ADDI_SCRP_LOW_AMT                                                           -- 57 . 机构追加认购最低金额
  ,0 AS IDV_FSTTM_PRCH_LOW_AMT                                                          -- 58 . 个人首次申购最低金额
  ,0 AS ORG_FSTTM_PRCH_LOW_AMT                                                          -- 59 . 机构首次申购最低金额
  ,0 AS IDV_ADDI_PRCH_LOW_AMT                                                           -- 60 . 个人追加申购最低金额
  ,0 AS ORG_ADDI_PRCH_LOW_AMT                                                           -- 61 . 机构追加申购最低金额
  ,'' AS IF_FIXINV_FND                                                                  -- 62 . 是否定投基金
  ,'' AS FIXINV_STAT                                                                    -- 63 . 定投状态
  ,'' AS FIXINV_STAT_DSC                                                                -- 64 . 定投状态描述
  ,0 AS FIXINV_STRT                                                                     -- 65 . 定投起点
  ,0 AS FIXINV_INCRM                                                                    -- 66 . 定投递增金额
  ,'' AS ESP_FEE_RATE                                                                   -- 67 . 特别费率优惠
  ,NVL(T2.LOWESTSUMFORHOLDING,0) AS HLD_SHR_LOW                                         -- 68 . 最低持有份额
  ,'' AS IVSM_CL                                                                        -- 69 . 投资品种
  ,'' AS IVSM_CL_DSC                                                                    -- 70 . 投资品种描述
  ,'' AS FIT_IVSTR_TP                                                                   -- 71 . 适合投资者类型
  ,'' AS FIT_IVSTR_TP_DSC                                                               -- 72 . 适合投资者类型描述
  ,NVL(CAST(T2.FLOATTYPE AS STRING),'') AS ISSUE_PLCG_MOD                               -- 73 . 发售方式
  ,CASE WHEN T2.FLOATTYPE = 1 THEN '场内'
        WHEN T2.FLOATTYPE = 3 THEN '场内和场外'
   ELSE '场外' END AS ISSUE_PLCG_MOD_DSC                                                -- 74 . 发售方式描述
  ,NVL(CAST(T2.FUNDNATURE AS STRING),'') AS FND_PROP                                    -- 75 . 基金性质
  ,CASE WHEN T2.FUNDNATURE = 1 THEN '常规基金'
        WHEN T2.FUNDNATURE = 2 THEN 'QDII基金'
        WHEN T2.FUNDNATURE = 3 THEN '互认基金'
   ELSE '' END AS FND_PROP_DSC                                                          -- 76 . 基金性质描述
  ,NVL(CAST(T2.SHAREPROPERTIES AS STRING),'') AS SHR_ATTR                               -- 77 . 份额属性
  ,CASE WHEN T2.SHAREPROPERTIES = 1 THEN '稳健型'
        WHEN T2.SHAREPROPERTIES = 2 THEN '进取型'
   ELSE '' END AS SHR_ATTR_DSC                                                          -- 78 . 份额属性描述
  ,'JZJY' AS DATA_SCR                                                                   -- 79 . 数据来源
  ,CASE WHEN TRIM(NVL(T2.EXAPPLYINGCODE,'')) <> '' THEN T2.EXAPPLYINGCODE
   ELSE T1.ZQDM END AS PROD_CODE                                                        -- 80 . 产品代码1(场内基金转换后代码)
FROM EDW_PROD.T_EDW_T04_TZQDM T1
LEFT JOIN FUNDEXT.DBO_MF_FUNDARCHIVES T2
ON T1.ZQDM = T2.SECURITYCODE 
AND T2.DT = '%d{yyyyMMdd}'
AND %d{yyyyMMdd} >= CASE WHEN NVL(T2.STARTDATE,'') = '' THEN 19000101 ELSE CAST(REPLACE(SUBSTR(NVL(T2.STARTDATE,''),1,10),'-','') AS INT) END
AND %d{yyyyMMdd} < CASE WHEN NVL(T2.EXPIREDATE,'') = '' THEN 99991231 ELSE CAST(REPLACE(SUBSTR(NVL(T2.EXPIREDATE,''),1,10),'-','') AS INT) END
LEFT JOIN FUNDEXT.DBO_MF_INVESTADVISOROUTLINE T3
ON T2.INVESTADVISORCODE = T3.INVESTADVISORCODE
AND T3.DT = '%d{yyyyMMdd}'
LEFT JOIN JZJYCX.ABOSS_TXTDM T4
ON T1.ZQJYZT = T4.BM
AND T4.FLDM = 'ZQJYZT'
AND T4.DT = '%d{yyyyMMdd}'
LEFT JOIN FUNDEXT.DBO_MF_NETVALUE T5
ON T2.INNERCODE  = T5.INNERCODE
AND REPLACE(SUBSTR(T5.ENDDATE,1,10),'-','') = '%d{yyyyMMdd}'
AND T5.DT = '%d{yyyyMMdd}'
LEFT JOIN FUNDEXT.DBO_MF_ISSUEANDLISTING T6
ON T2.INNERCODE  = T6.INNERCODE
AND T6.DT = '%d{yyyyMMdd}'
LEFT JOIN DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP1 T7
ON T1.ZQDM = T7.PROD_CD
AND SUBSTR(T7.PROD_CL_CD,1,2)  = '01'
WHERE T1.BUS_DATE = %d{yyyyMMdd}
AND UPPER(ZQLB) LIKE 'J%'
;

--当日金融产品代码临时表(剔除场内基金转换后代码与场内基金代码重复数据)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP4;
CREATE TABLE DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP4
AS
 SELECT CAST(ID AS STRING) AS ID,INR_CD,PROD_CD,PROD_CL_CD,PROD_CODE,DATA_SCR
 FROM DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP2
 WHERE PROD_CD <> PROD_CODE
 AND PROD_CODE IN 
 (
 SELECT PROD_CODE
 FROM DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP2
 WHERE SUBSTR(PROD_CL_CD,1,2) = '01'
 GROUP BY PROD_CODE
 HAVING COUNT(*) > 1
 )
UNION ALL
 SELECT CAST(ID AS STRING) AS ID,INR_CD,PROD_CD,PROD_CL_CD,PROD_CODE,DATA_SCR
 FROM DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP2
 WHERE PROD_CODE NOT IN 
 (
 SELECT PROD_CODE
 FROM DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP2
 WHERE SUBSTR(PROD_CL_CD,1,2) = '01'
 GROUP BY PROD_CODE
 HAVING COUNT(*) > 1
 )
UNION ALL
 SELECT ID,INR_CD,PROD_CD,PROD_CL_CD,PROD_CODE,DATA_SCR
 FROM DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP3
 WHERE PROD_CODE NOT IN
 (SELECT PROD_CODE FROM DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP2 WHERE SUBSTR(PROD_CL_CD,1,2) = '01')
;

--当日金融产品新增代码临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP5;
CREATE TABLE DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP5
AS
SELECT PROD_CD,PROD_CL_CD,ROW_NUMBER() OVER(PARTITION BY SUBSTR(PROD_CL_CD,1,2) ORDER BY PROD_CD ASC) AS NUM
FROM DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP4
WHERE NVL(INR_CD,'') = ''
;

--上日金融产品各大类最大内部编码临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP6;
CREATE TABLE DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP6
AS
SELECT SUBSTR(PROD_CL_CD,1,2) AS PROD_MCGY,MAX(CAST(SUBSTR(INR_CD,5) AS INT)) AS MAX_NUM
FROM DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP1
GROUP BY SUBSTR(PROD_CL_CD,1,2)
;

--当日新增金融产品内部编码临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP7;
CREATE TABLE DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP7
AS
SELECT T.PROD_CD
      ,T.PROD_CL_CD
	  ,CASE WHEN LENGTH(T.NUM) = 1 THEN CONCAT('0000',T.NUM)
	        WHEN LENGTH(T.NUM) = 2 THEN CONCAT('000',T.NUM)
			WHEN LENGTH(T.NUM) = 3 THEN CONCAT('00',T.NUM)
			WHEN LENGTH(T.NUM) = 4 THEN CONCAT('0',T.NUM)
	   ELSE T.NUM END AS NUM
FROM
(
  SELECT A.PROD_CD,A.PROD_CL_CD,CAST((A.NUM + NVL(B.MAX_NUM,0)) AS STRING) AS NUM
  FROM DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP5 A
  LEFT JOIN DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP6 B
  ON SUBSTR(A.PROD_CL_CD,1,2) = B.PROD_MCGY
) T
;

--插入当日正式数据
INSERT INTO DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR
(
   ID  						    --  1 . 产品ID(PK)
  ,INR_CD  					    --  2 . 产品内部代码
  ,PROD_CD  				    --  3 . 产品代码
  ,PROD_CL_CD  				    --  4 . 产品分类
  ,PROD_CL_DSC  			    --  5 . 产品分类描述
  ,PROD_FULLNM  			    --  6 . 产品全称
  ,PROD_SHRTNM  			    --  7 . 产品简称
  ,PROD_CRINT_DT  				--  8 . 产品起息日
  ,PROD_ESTAB_DT  			 	--  9 . 产品成立日
  ,IVSM_EXPI_DT  			 	-- 10 . 投资到期日
  ,CASHE_DT  				 	-- 11 . 兑付日期
  ,RAIS_STRT_DT  			 	-- 12 . 募集起始日期
  ,RAIS_END_DT  			 	-- 13 . 募集结束日期
  ,PROD_ADMIN  				    -- 14 . 产品管理人
  ,PROD_ADMIN_DSC  			    -- 15 . 产品管理人描述
  ,PROD_SCL_UPLMT  			    -- 16 . 产品规模上限
  ,SALE_NETPOT  			    -- 17 . 销售网点
  ,PROD_SALE_REG  			    -- 18 . 产品销售地区
  ,PROD_SALE_STRT_DT  		 	-- 19 . 产品销售起始日期
  ,PROD_SALE_END_DT  		 	-- 20 . 产品销售结束日期
  ,PROD_SUST_MKT_START_DT 	 	-- 21 . 产品持续营销起始日
  ,PROD_SUST_MKT_END_DT  	 	-- 22 . 产品持续营销结束日
  ,PROD_HLT  				    -- 23 . 产品亮点
  ,PROD_ASS_POLICY  		    -- 24 . 产品考核政策
  ,SALE_CNL_CD  			    -- 25 . 销售渠道
  ,IF_HOT  				 	    -- 26 . 是否核心销售
  ,IF_KEY_SALES  			    -- 27 . 是否重点销售产品
  ,PROD_DEDLN  				    -- 28 . 产品期限
  ,YLD_TP_CD  				    -- 29 . 收益类型(适当性)
  ,YLD_TP_DSC  				    -- 30 . 收益类型描述
  ,PROD_RSK_RTG_CD  		    -- 31 . 产品风险评级
  ,PROD_RSK_RTG_DSC  		    -- 32 . 产品风险评级描述
  ,LINKED_RLD_CGY_CD  		    -- 33 . 挂钩标的类别 
  ,LINKED_RLD_CGY_NM  		    -- 34 . 挂钩标的名称 
  ,LINKED_RTO  				 	-- 35 . 挂钩率(%) 
  ,LINKED_YLD_EXPLN  		    -- 36 . 挂钩收益说明 
  ,TRD_LOCTN  				    -- 37 . 交易场所 
  ,ADVBOOK_START_DT  		 	-- 38 . 预售期起始日
  ,ADVBOOK_END_DT  			 	-- 39 . 预售期结束日
  ,WINDG_START_DT  			 	-- 40 . 清盘期起始日
  ,WINDG_END_DT  			 	-- 41 . 清盘期结束日
  ,PROD_END_DT  			 	-- 42 . 产品结束日
  ,PROD_PHS_CD  			    -- 43 . 产品阶段
  ,PROD_PHS_DSC  			    -- 44 . 产品阶段描述
  ,TRD_STAT_CD  			    -- 45 . 交易状态
  ,TRD_STAT_DSC  			    -- 46 . 交易状态描述
  ,PROD_DEDLN_SDX  			    -- 47 . 产品期限(适当性)
  ,PROD_DEDLN_SDX_DSC  		    -- 48 . 产品期限描述
  ,IF_PROD_GRADE_CD  		    -- 49 . 产品是否分级
  ,IF_PROD_GRADE_DSC  		    -- 50 . 产品是否分级描述
  ,UNIT_NAV  				 	-- 51 . 单位净值
  ,GT_NAV  					 	-- 52 . 累计净值
  ,NAV_DT  					 	-- 53 . 净值日期
  ,IDV_FSTTM_SCRP_LOW_AMT 	 	-- 54 . 个人首次认购最低金额
  ,ORG_FSTTM_SCRP_LOW_AMT 	 	-- 55 . 机构首次认购最低金额
  ,IDV_ADDI_SCRP_LOW_AMT  	 	-- 56 . 个人追加认购最低金额
  ,ORG_ADDI_SCRP_LOW_AMT  	 	-- 57 . 机构追加认购最低金额
  ,IDV_FSTTM_PRCH_LOW_AMT 	 	-- 58 . 个人首次申购最低金额
  ,ORG_FSTTM_PRCH_LOW_AMT 	 	-- 59 . 机构首次申购最低金额
  ,IDV_ADDI_PRCH_LOW_AMT  	 	-- 60 . 个人追加申购最低金额
  ,ORG_ADDI_PRCH_LOW_AMT  	 	-- 61 . 机构追加申购最低金额
  ,IF_FIXINV_FND  			    -- 62 . 是否定投基金
  ,FIXINV_STAT 				    -- 63 . 定投状态
  ,FIXINV_STAT_DSC			    -- 64 . 定投状态描述
  ,FIXINV_STRT  			 	-- 65 . 定投起点
  ,FIXINV_INCRM  			 	-- 66 . 定投递增金额
  ,ESP_FEE_RATE  			    -- 67 . 特别费率优惠
  ,HLD_SHR_LOW  			 	-- 68 . 最低持有份额
  ,IVSM_CL  				    -- 69 . 投资品种
  ,IVSM_CL_DSC  			    -- 70 . 投资品种描述
  ,FIT_IVSTR_TP                 -- 71 . 适合投资者类型
  ,FIT_IVSTR_TP_DSC             -- 72 . 适合投资者类型描述
  ,ISSUE_PLCG_MOD               -- 73 . 发售方式
  ,ISSUE_PLCG_MOD_DSC           -- 74 . 发售方式描述
  ,FND_PROP                     -- 75 . 基金性质
  ,FND_PROP_DSC                 -- 76 . 基金性质描述
  ,SHR_ATTR                     -- 77 . 份额属性
  ,SHR_ATTR_DSC                 -- 78 . 份额属性描述
  ,DATA_SCR                     -- 79 . 数据来源
  ,PROD_CODE                    -- 80 . 产品代码1(场内基金转换后代码)
  ,PREP_TXT_COL1                -- 81 . 预留文本字段1
  ,PREP_TXT_COL2                -- 82 . 预留文本字段2
  ,PREP_TXT_COL3                -- 83 . 预留文本字段3
  ,PREP_TXT_COL4                -- 84 . 预留文本字段4
  ,PREP_TXT_COL5                -- 85 . 预留文本字段5
  ,PREP_NUM_COL1                -- 86 . 预留数值字段1
  ,PREP_NUM_COL2                -- 87 . 预留数值字段2
  ,PREP_NUM_COL3                -- 88 . 预留数值字段3
  ,PREP_INT_COL1                -- 89 . 预留整型字段1
  ,PREP_INT_COL2                -- 90 . 预留整型字段2
  ,PREP_INT_COL3                -- 91 . 预留整型字段3
)
PARTITION( BUS_DATE = %d{yyyyMMdd})
SELECT
          CAST(T1.ID AS STRING) AS ID  		 			                                                        --  1 . 产品ID(PK)
         ,CASE WHEN NVL(T2.INR_CD,'') <> '' THEN T2.INR_CD
		       WHEN NVL(T2.INR_CD,'') = '' AND SUBSTR(T1.PROD_CL_CD,1,2) = '01' THEN CONCAT('GMJJ',T3.NUM)
               WHEN NVL(T2.INR_CD,'') = '' AND SUBSTR(T1.PROD_CL_CD,1,2) = '02' THEN CONCAT('SMJJ',T3.NUM)
               WHEN NVL(T2.INR_CD,'') = '' AND SUBSTR(T1.PROD_CL_CD,1,2) = '03' THEN CONCAT('XTCP',T3.NUM)
               WHEN NVL(T2.INR_CD,'') = '' AND SUBSTR(T1.PROD_CL_CD,1,2) = '04' THEN CONCAT('ZGNB',T3.NUM)
               WHEN NVL(T2.INR_CD,'') = '' AND SUBSTR(T1.PROD_CL_CD,1,2) = '05' THEN CONCAT('YHLC',T3.NUM)
               WHEN NVL(T2.INR_CD,'') = '' AND SUBSTR(T1.PROD_CL_CD,1,2) = '06' THEN CONCAT('SYPZ',T3.NUM)
               WHEN NVL(T2.INR_CD,'') = '' AND SUBSTR(T1.PROD_CL_CD,1,2) = '07' THEN CONCAT('ZGWB',T3.NUM)
               WHEN NVL(T2.INR_CD,'') = '' AND SUBSTR(T1.PROD_CL_CD,1,2) = '08' THEN CONCAT('JJZH',T3.NUM)
          END AS INR_CD  				                                                                        --  2 . 产品内部代码
         ,T1.PROD_CD  				                                                                            --  3 . 产品代码
         ,T1.PROD_CL_CD  			                                                                            --  4 . 产品分类
         ,NVL(T4.NAME,'') AS PROD_CL_DSC                                                                        --  5 . 产品分类描述
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND TRIM(NVL(T5.JJQC,'')) = '' AND TRIM(NVL(T7.CPQC,'')) = '' AND TRIM(NVL(T13.PROD_FULLNM,'')) <> ''
		       THEN T13.PROD_FULLNM
		  ELSE COALESCE(T5.JJQC,T6.CPQC,T7.CPQC) END AS PROD_FULLNM  			                                --  6 . 产品全称
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND TRIM(NVL(T5.JJJC,'')) = '' AND TRIM(NVL(T7.CPMC,'')) = '' AND TRIM(NVL(T13.PROD_SHRTNM,'')) <> ''
		       THEN T13.PROD_SHRTNM
		  ELSE COALESCE(T5.JJJC,T6.CPJC,T7.CPMC) END AS PROD_SHRTNM  			                                --  7 . 产品简称
         ,COALESCE(T6.CPQXR,T7.CPQXR) AS PROD_CRINT_DT  	                                                    --  8 . 产品起息日
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3')  AND NVL(T7.CPCLR,0) = 0 AND NVL(T13.PROD_ESTAB_DT,0) <> 0
		       THEN T13.PROD_ESTAB_DT
		  ELSE T7.CPCLR END AS PROD_ESTAB_DT                                                                    --  9 . 产品成立日
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3')  AND NVL(T7.TZDQR,0) = 0 AND NVL(T13.IVSM_EXPI_DT,0) <> 0
		       THEN T13.IVSM_EXPI_DT
		  ELSE COALESCE(T6.CPDQR,T7.TZDQR) END AS IVSM_EXPI_DT                                                  -- 10 . 投资到期日
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3')  AND NVL(T7.CPDFR,0) = 0 AND NVL(T13.CASHE_DT,0) <> 0
		       THEN T13.CASHE_DT
		  ELSE COALESCE(T6.CPDFR,T7.CPDFR) END AS CASHE_DT                                                      -- 11 . 兑付日期
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND NVL(T5.RGKSRQ,0) = 0 AND NVL(T7.MJQSR,0) = 0 AND NVL(T13.RAIS_STRT_DT,0) <> 0
		       THEN T13.RAIS_STRT_DT
		  ELSE COALESCE(T5.RGKSRQ,T6.RGKSRQ,T7.MJQSR) END AS RAIS_STRT_DT                                       -- 12 . 募集起始日期
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND NVL(T5.RGJSRQ,0) = 0 AND NVL(T7.MJJSR,0) = 0 AND NVL(T13.RAIS_END_DT,0) <> 0
		       THEN T13.RAIS_END_DT
		  ELSE COALESCE(T5.RGJSRQ,T6.RGJSRQ,T7.MJJSR) END AS RAIS_END_DT                                        -- 13 . 募集结束日期
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND TRIM(NVL(T5.GLRDM,'')) = '' AND TRIM(NVL(CAST(T7.CPGLR AS STRING),'')) = '' AND TRIM(NVL(T13.PROD_ADMIN,'')) <> ''
		       THEN T13.PROD_ADMIN
		  ELSE COALESCE(T5.GLRDM,T6.FXJG,CAST(T7.CPGLR AS STRING)) END AS PROD_ADMIN                            -- 14 . 产品管理人
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND TRIM(NVL(T5.GLRDM,'')) = '' AND TRIM(NVL(CAST(T7.CPGLR AS STRING),'')) = '' AND TRIM(NVL(T13.PROD_ADMIN,'')) <> ''
		       THEN T13.PROD_ADMIN_DSC
		  ELSE NVL(T7.CPGLRJP,'') END AS PROD_ADMIN_DSC                                                         -- 15 . 产品管理人描述
         ,NVL(T7.CPGMSX,'') AS PROD_SCL_UPLMT                                                                   -- 16 . 产品规模上限
         ,NVL(T7.XSWD,'') AS SALE_NETPOT                                                                        -- 17 . 销售网点
         ,NVL(T7.XSDQ,'') AS PROD_SALE_REG                                                                      -- 18 . 产品销售地区
         ,T7.XSQSR AS PROD_SALE_STRT_DT                                                                         -- 19 . 产品销售起始日期
         ,T7.XSJSR AS PROD_SALE_END_DT                                                                          -- 20 . 产品销售结束日期
         ,T7.CXYXQSR AS PROD_SUST_MKT_START_DT                                                                  -- 21 . 产品持续营销起始日
         ,T7.CXYXJSR AS PROD_SUST_MKT_END_DT                                                                    -- 22 . 产品持续营销结束日
         ,NVL(T7.CPLD,'') AS PROD_HLT                                                                           -- 23 . 产品亮点
         ,NVL(T7.CPKHZC,'') AS PROD_ASS_POLICY                                                                  -- 24 . 产品考核政策
         ,NVL(CAST(T7.XSQD AS STRING),'') AS SALE_CNL_CD                                                        -- 25 . 销售渠道
         ,NVL(CAST(T7.SFRXCP AS STRING),'') AS IF_HOT                                                           -- 26 . 是否核心销售
         ,NVL(CAST(T7.SFZDXS AS STRING),'') AS IF_KEY_SALES                                                     -- 27 . 是否重点销售产品
         ,NVL(CAST(T7.CPQX_R AS STRING),'') AS PROD_DEDLN  			                                            -- 28 . 产品期限
         ,CAST(COALESCE(T5.YQSY,T6.YQSY,T7.SYLX) AS STRING) AS YLD_TP_CD  			                            -- 29 . 收益类型(适当性)
         ,CASE WHEN COALESCE(T5.YQSY,T6.YQSY,T7.SYLX) = 1
		       THEN '固定收益'
			   WHEN COALESCE(T5.YQSY,T6.YQSY,T7.SYLX) = 2
			   THEN '浮动收益'
			   WHEN COALESCE(T5.YQSY,T6.YQSY,T7.SYLX) = 4
			   THEN '浮动盈亏'
		  ELSE NVL(T7.SYLXMS,'未知') END AS YLD_TP_DSC  			                                            -- 30 . 收益类型描述
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND TRIM(NVL(CAST(T5.JJFXDJ AS STRING),'')) = '' AND TRIM(NVL(CAST(T7.CPFXDJ AS STRING),'')) = '' AND TRIM(NVL(T13.PROD_RSK_RTG_CD,'')) <> ''
		       THEN T13.PROD_RSK_RTG_CD
		  ELSE CAST(COALESCE(T5.JJFXDJ,T6.FXDJ,T7.CPFXDJ) AS STRING) END AS PROD_RSK_RTG_CD  		            -- 31 . 产品风险评级
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND TRIM(NVL(CAST(T5.JJFXDJ AS STRING),'')) = '' AND TRIM(NVL(CAST(T7.CPFXDJ AS STRING),'')) = '' AND TRIM(NVL(T13.PROD_RSK_RTG_CD,'')) <> ''
		       THEN T13.PROD_RSK_RTG_DSC
		       WHEN T5.JJFXDJ = 1 THEN '低风险级别'
		       WHEN T5.JJFXDJ = 2 THEN '较低风险级别'
			   WHEN T5.JJFXDJ = 3 THEN '中等风险级别'
			   WHEN T5.JJFXDJ = 4 THEN '较高风险级别'
			   WHEN T5.JJFXDJ = 5 THEN '高风险级别'
			   WHEN T5.JJFXDJ IS NULL AND T6.FXDJ = 1 THEN '低风险级别'
			   WHEN T5.JJFXDJ IS NULL AND T6.FXDJ = 2 THEN '较低风险级别'
			   WHEN T5.JJFXDJ IS NULL AND T6.FXDJ = 3 THEN '中等风险级别'
			   WHEN T5.JJFXDJ IS NULL AND T6.FXDJ = 4 THEN '较高风险级别'
			   WHEN T5.JJFXDJ IS NULL AND T6.FXDJ = 5 THEN '高风险级别'
			   WHEN T5.JJFXDJ IS NULL AND T6.FXDJ IS NULL AND T7.CPFXDJ = 1 THEN '低风险级别'
			   WHEN T5.JJFXDJ IS NULL AND T6.FXDJ IS NULL AND T7.CPFXDJ = 2 THEN '较低风险级别'
			   WHEN T5.JJFXDJ IS NULL AND T6.FXDJ IS NULL AND T7.CPFXDJ = 3 THEN '中等风险级别'
			   WHEN T5.JJFXDJ IS NULL AND T6.FXDJ IS NULL AND T7.CPFXDJ = 4 THEN '较高风险级别'
			   WHEN T5.JJFXDJ IS NULL AND T6.FXDJ IS NULL AND T7.CPFXDJ = 5 THEN '高风险级别'
		  ELSE NVL(T7.CPFXDJMS,'未知') END AS PROD_RSK_RTG_DSC                                                  -- 32 . 产品风险评级描述
         ,NVL(CAST(T7.GGBDLB AS STRING),'') AS LINKED_RLD_CGY_CD                                                -- 33 . 挂钩标的类别
         ,NVL(T7.GGBDMC,'') AS LINKED_RLD_CGY_NM                                                                -- 34 . 挂钩标的名称 
         ,T7.GGL AS LINKED_RTO                                                                                  -- 35 . 挂钩率(%) 
         ,NVL(T7.GGSYSM,'') AS LINKED_YLD_EXPLN  	                                                            -- 36 . 挂钩收益说明 
         ,NVL(T7.JYCS,'') AS TRD_LOCTN                                                                          -- 37 . 交易场所
         ,T7.YSQQSR AS ADVBOOK_START_DT                                                                         -- 38 . 预售期起始日
         ,T7.YSQJSR AS ADVBOOK_END_DT  		                                                                    -- 39 . 预售期结束日
         ,T7.QPQQSR AS WINDG_START_DT  		                                                                    -- 40 . 清盘期起始日
         ,T7.QPQJSR AS WINDG_END_DT                                                                             -- 41 . 清盘期结束日
         ,T7.CPJSR AS PROD_END_DT  	 		                                                                    -- 42 . 产品结束日
         ,'' AS PROD_PHS_CD                                                                                     -- 43 . 产品阶段
         ,'' AS PROD_PHS_DSC                                                                                    -- 44 . 产品阶段描述
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND TRIM(NVL(CAST(T5.JYZT AS STRING),'')) = '' AND TRIM(NVL(T13.TRD_STAT_CD,'')) <> ''
		       THEN CONCAT('JJ9',T13.TRD_STAT_CD)
		       WHEN T5.JYZT = 0 THEN 'JJ00'
		       WHEN T5.JYZT = 1 THEN 'JJ01'
			   WHEN T5.JYZT = 3 THEN 'JJ03'
			   WHEN T5.JYZT = 4 THEN 'JJ04'
			   WHEN T5.JYZT = 5 THEN 'JJ05'
			   WHEN T5.JYZT = 6 THEN 'JJ06'
			   WHEN T5.JYZT = 9 THEN 'JJ09'
			   WHEN T5.JYZT = 10 THEN 'JJ10'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 1 THEN 'JR01'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 2 THEN 'JR02'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 3 THEN 'JR03'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 4 THEN 'JR04'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 5 THEN 'JR05'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 6 THEN 'JR06'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 7 THEN 'JR07'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 8 THEN 'JR08'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 9 THEN 'JR09'
		  ELSE 'QT00' END AS TRD_STAT_CD  			                                                            -- 45 . 交易状态
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND TRIM(NVL(CAST(T5.JYZT AS STRING),'')) = '' AND TRIM(NVL(T13.TRD_STAT_CD,'')) <> ''
		       THEN CONCAT('场内基金_',T13.TRD_STAT_DSC)
		       WHEN T5.JYZT = 0 THEN '基金_正常开放'
		       WHEN T5.JYZT = 1 THEN '基金_认购期'
			   WHEN T5.JYZT = 3 THEN '基金_发行失败'
			   WHEN T5.JYZT = 4 THEN '基金_暂停交易'
			   WHEN T5.JYZT = 5 THEN '基金_暂停申购'
			   WHEN T5.JYZT = 6 THEN '基金_暂停赎回'
			   WHEN T5.JYZT = 9 THEN '基金_封闭'
			   WHEN T5.JYZT = 10 THEN '基金_中止'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 1 THEN '金融产品_可认购'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 2 THEN '金融产品_可申购'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 3 THEN '金融产品_可赎回'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 4 THEN '金融产品_可申购可赎回'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 5 THEN '金融产品_停止申购赎回'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 6 THEN '金融产品_停止申购'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 7 THEN '金融产品_停止赎回'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 8 THEN '金融产品_封闭'
			   WHEN T5.JYZT IS NULL AND T6.JYZT = 9 THEN '金融产品_终止'
		  ELSE '其它' END AS TRD_STAT_DSC                                                                       -- 46 . 交易状态描述
         ,CAST(NVL(T5.TZQX,T7.CPQX_SDX) AS STRING) AS PROD_DEDLN_SDX                                            -- 47 . 产品期限(适当性)
         ,COALESCE(T8.BMSM,'') AS PROD_DEDLN_SDX_DSC  	                                                        -- 48 . 产品期限描述
         ,NVL(CAST(T7.CPSFFJ AS STRING),'') AS IF_PROD_GRADE_CD                                                 -- 49 . 产品是否分级
         ,NVL(T7.CPSFFJMS,'') AS IF_PROD_GRADE_DSC                                                              -- 50 . 产品是否分级描述
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND NVL(T5.JJJZ,0) = 0 AND NVL(T7.CPJZ,0) = 0 AND NVL(T13.UNIT_NAV,0) <> 0
		       THEN T13.UNIT_NAV
		  ELSE COALESCE(T5.JJJZ,T6.CPJZ,T7.CPJZ) END AS UNIT_NAV  			                                    -- 51 . 单位净值
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND NVL(T5.LJJZ,0) = 0 AND NVL(T7.LJJZ,0) = 0 AND NVL(T13.GT_NAV,0) <> 0
		       THEN T13.GT_NAV
		  ELSE NVL(T5.LJJZ,T7.LJJZ) END AS GT_NAV  				                                                -- 52 . 累计净值
         ,%d{yyyyMMdd} AS NAV_DT  				                                                                -- 53 . 净值日期
         ,COALESCE(T5.GRSCRGZDZJ,T6.RGZDZJ,T10.GRSCRGZDJE) AS IDV_FSTTM_SCRP_LOW_AMT                            -- 54 . 个人首次认购最低金额
         ,COALESCE(T5.JGSCRGZDZJ,T6.RGZDZJ_JG,T10.JGSCRGZDJE) AS ORG_FSTTM_SCRP_LOW_AMT                         -- 55 . 机构首次认购最低金额
         ,COALESCE(T5.GRZJRGZDZJ,T6.RGDZZJ,T10.GRZJRGZDJE) AS IDV_ADDI_SCRP_LOW_AMT                             -- 56 . 个人追加认购最低金额
         ,COALESCE(T5.JGZJRGZDZJ,T6.RGDZZJ_JG,T10.JGZJRGZDJE) AS ORG_ADDI_SCRP_LOW_AMT                          -- 57 . 机构追加认购最低金额
         ,COALESCE(T5.GRSCSGZDZJ,T6.SGZDZJ,T10.GRSCSGZDJE) AS IDV_FSTTM_PRCH_LOW_AMT                            -- 58 . 个人首次申购最低金额
         ,COALESCE(T5.JGSCSGZDZJ,T6.SGZDZJ_JG,T10.JGSCSGZDJE) AS ORG_FSTTM_PRCH_LOW_AMT                         -- 59 . 机构首次申购最低金额
         ,COALESCE(T5.GRZJSGZDZJ,T6.SGDZZJ,T10.GRZJSGZDJE) AS IDV_ADDI_PRCH_LOW_AMT                             -- 60 . 个人追加申购最低金额
         ,COALESCE(T5.JGZJSGZDZJ,T6.SGDZZJ_JG,T10.JGZJSGZDJE) AS ORG_ADDI_PRCH_LOW_AMT                          -- 61 . 机构追加申购最低金额
         ,CASE WHEN T11.TADM IS NOT NULL THEN '是' ELSE '否' END AS IF_FIXINV_FND  		                        -- 62 . 是否定投基金
         ,NVL(CAST(DTSTAT AS STRING),'') AS FIXINV_STAT 			                                            -- 63 . 定投状态
		 ,NVL(T12.BMSM,'') AS FIXINV_STAT_DSC                                                                   -- 64 . 定投状态描述
         ,T11.ZDSGJE AS FIXINV_STRT  			                                                                -- 65 . 定投起点
         ,T11.SGJEJS AS FIXINV_INCRM  		                                                                    -- 66 . 定投递增金额
         ,'' AS ESP_FEE_RATE                                                                                    -- 67 . 特别费率优惠
         ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND T13.ISSUE_PLCG_MOD IN ('1','3') AND NVL(T5.GRCCZDFE,0) = 0 AND NVL(T13.HLD_SHR_LOW,0) <> 0
		       THEN T13.HLD_SHR_LOW
		  ELSE T5.GRCCZDFE END AS HLD_SHR_LOW  		 	                                                        -- 68 . 最低持有份额
         ,CAST(NVL(T5.TZPZ,T6.TZPZ) AS STRING) AS IVSM_CL                                                       -- 69 . 投资品种
         ,NVL(T9.BMSM,'') AS IVSM_CL_DSC  			                                                            -- 70 . 投资品种描述
		 ,CAST(T7.SHTZZLX AS STRING) AS FIT_IVSTR_TP                                                            -- 71 . 适合投资者类型
		 ,CASE WHEN T7.SHTZZLX = 0 THEN '私募合格投资者'
		       WHEN T7.SHTZZLX = 1 THEN '资管合格投资者'
			   WHEN T7.SHTZZLX = 2 THEN '保守型及以上的合格投资者(不含最低类别)'
		  ELSE '' END AS FIT_IVSTR_TP_DSC                                                                       -- 72 . 适合投资者类型描述
		 ,NVL(CAST(T14.FLOATTYPE AS STRING),'') AS ISSUE_PLCG_MOD                                               -- 73 . 发售方式
         ,CASE WHEN T14.FLOATTYPE = 1 THEN '场内'
               WHEN T14.FLOATTYPE = 3 THEN '场内和场外'
          ELSE '场外' END AS ISSUE_PLCG_MOD_DSC                                                                 -- 74 . 发售方式描述
         ,NVL(CAST(T14.FUNDNATURE AS STRING),'') AS FND_PROP                                                    -- 75 . 基金性质
         ,CASE WHEN T14.FUNDNATURE = 1 THEN '常规基金'
               WHEN T14.FUNDNATURE = 2 THEN 'QDII基金'
               WHEN T14.FUNDNATURE = 3 THEN '互认基金'
          ELSE '' END AS FND_PROP_DSC                                                                            -- 76 . 基金性质描述
         ,NVL(CAST(T14.SHAREPROPERTIES AS STRING),'') AS SHR_ATTR                                                -- 77 . 份额属性
         ,CASE WHEN T14.SHAREPROPERTIES = 1 THEN '稳健型'
               WHEN T14.SHAREPROPERTIES = 2 THEN '进取型'
          ELSE '' END AS SHR_ATTR_DSC                                                                            -- 78 . 份额属性描述
		 ,T1.DATA_SCR AS DATA_SCR                                                                                -- 79 . 数据来源
		 ,CASE WHEN SUBSTR(T1.PROD_CL_CD,1,2) = '01' AND TRIM(NVL(T14.EXAPPLYINGCODE,'')) <> '' THEN T14.EXAPPLYINGCODE
		  ELSE T1.PROD_CD END AS PROD_CODE                                                                       -- 80 . 产品代码1(场内基金转换后代码)
		 ,'' AS PREP_TXT_COL1                                                                                    -- 81 . 预留文本字段1
         ,'' AS PREP_TXT_COL2                                                                                    -- 82 . 预留文本字段2
         ,'' AS PREP_TXT_COL3                                                                                    -- 83 . 预留文本字段3
         ,'' AS PREP_TXT_COL4                                                                                    -- 84 . 预留文本字段4
         ,'' AS PREP_TXT_COL5                                                                                    -- 85 . 预留文本字段5
         ,T7.SYL AS PREP_NUM_COL1                                                                                -- 86 . 预留数值字段1 -> 收益率
         ,0 AS PREP_NUM_COL2                                                                                     -- 87 . 预留数值字段2
         ,0 AS PREP_NUM_COL3                                                                                     -- 88 . 预留数值字段3
         ,T7.CPCXQSR AS PREP_INT_COL1                                                                            -- 89 . 预留整型字段1 -> 下一开放日
         ,0 AS PREP_INT_COL2                                                                                     -- 90 . 预留整型字段2
         ,0 AS PREP_INT_COL3                                                                                     -- 91 . 预留整型字段3
FROM DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP4 T1
LEFT JOIN DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP1 T2
ON T1.PROD_CD = T2.PROD_CD
AND T1.PROD_CL_CD = T2.PROD_CL_CD
LEFT JOIN DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP7 T3
ON T1.PROD_CD = T3.PROD_CD
AND T1.PROD_CL_CD = T3.PROD_CL_CD
LEFT JOIN C5CX.SPIF_TPIF_JRCPFL T4
ON T1.PROD_CL_CD = T4.FLBM
AND T4.DT = '%d{yyyyMMdd}'
LEFT JOIN JZJYCX.OFS_TOF_JJXX T5
ON T1.PROD_CD = T5.JJDM
AND T5.DT = '%d{yyyyMMdd}'
LEFT JOIN JZJYCX.JRCP_TJRCP_CPDM T6
ON T1.PROD_CD = T6.CPDM
AND T6.DT = '%d{yyyyMMdd}'
LEFT JOIN EDW_PROD.T_EDW_T04_C5_TSPIF_CPDM T7
ON T1.PROD_CD = T7.CPDM
AND T1.PROD_CL_CD = T7.CPFL
AND T7.BUS_DATE = %d{yyyyMMdd}
AND (T7.SHBZ = 1 OR T7.CPDM = '006371')
LEFT JOIN JZJYCX.ABOSS_TXTDM T8
ON CAST(NVL(T5.TZQX,T7.CPQX_SDX) AS STRING) = T8.BM
AND T8.FLDM = 'TZQX'
AND T8.DT = '%d{yyyyMMdd}'
LEFT JOIN JZJYCX.ABOSS_TXTDM T9
ON CAST(NVL(T5.TZPZ,T6.TZPZ) AS STRING) = T9.BM
AND T9.FLDM = 'TZPZ'
AND T9.DT = '%d{yyyyMMdd}'
LEFT JOIN EDW_PROD.T_EDW_T04_C5_TSPIF_CPDM_PT_JZJY T10
ON T7.ID = T10.CPID
AND T10.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN 
(
 SELECT TADM,MIN(ZDSGJE) AS ZDSGJE,MAX(SGJEJS) AS SGJEJS FROM EDW_PROD.T_EDW_T04_TOF_DQDESGPZ WHERE BUS_DATE = %d{yyyyMMdd} GROUP BY TADM
) T11
ON T5.TADM = T11.TADM
LEFT JOIN JZJYCX.ABOSS_TXTDM T12
ON CAST(T5.DTSTAT AS STRING) = T12.BM
AND T12.FLDM = 'OF_JJZT_DT'
AND T12.DT = '%d{yyyyMMdd}'
LEFT JOIN DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP3 T13
ON T1.PROD_CD = T13.PROD_CD
AND SUBSTR(T1.PROD_CL_CD,1,2) = SUBSTR(T13.PROD_CL_CD,1,2)
LEFT JOIN FUNDEXT.DBO_MF_FUNDARCHIVES T14
ON T1.PROD_CD = T14.SECURITYCODE
AND T14.DT = '%d{yyyyMMdd}'
AND %d{yyyyMMdd} >= CASE WHEN NVL(T14.STARTDATE,'') = '' THEN 19000101 ELSE CAST(REPLACE(SUBSTR(NVL(T14.STARTDATE,''),1,10),'-','') AS INT) END
AND %d{yyyyMMdd} < CASE WHEN NVL(T14.EXPIREDATE,'') = '' THEN 99991231 ELSE CAST(REPLACE(SUBSTR(NVL(T14.EXPIREDATE,''),1,10),'-','') AS INT) END
WHERE T1.DATA_SCR = 'CRM'
;


--插入当日正式数据
INSERT INTO DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR
(
   ID  						    --  1 . 产品ID(PK)
  ,INR_CD  					    --  2 . 产品内部代码
  ,PROD_CD  				    --  3 . 产品代码
  ,PROD_CL_CD  				    --  4 . 产品分类
  ,PROD_CL_DSC  			    --  5 . 产品分类描述
  ,PROD_FULLNM  			    --  6 . 产品全称
  ,PROD_SHRTNM  			    --  7 . 产品简称
  ,PROD_CRINT_DT  				--  8 . 产品起息日
  ,PROD_ESTAB_DT  			 	--  9 . 产品成立日
  ,IVSM_EXPI_DT  			 	-- 10 . 投资到期日
  ,CASHE_DT  				 	-- 11 . 兑付日期
  ,RAIS_STRT_DT  			 	-- 12 . 募集起始日期
  ,RAIS_END_DT  			 	-- 13 . 募集结束日期
  ,PROD_ADMIN  				    -- 14 . 产品管理人
  ,PROD_ADMIN_DSC  			    -- 15 . 产品管理人描述
  ,PROD_SCL_UPLMT  			    -- 16 . 产品规模上限
  ,SALE_NETPOT  			    -- 17 . 销售网点
  ,PROD_SALE_REG  			    -- 18 . 产品销售地区
  ,PROD_SALE_STRT_DT  		 	-- 19 . 产品销售起始日期
  ,PROD_SALE_END_DT  		 	-- 20 . 产品销售结束日期
  ,PROD_SUST_MKT_START_DT 	 	-- 21 . 产品持续营销起始日
  ,PROD_SUST_MKT_END_DT  	 	-- 22 . 产品持续营销结束日
  ,PROD_HLT  				    -- 23 . 产品亮点
  ,PROD_ASS_POLICY  		    -- 24 . 产品考核政策
  ,SALE_CNL_CD  			    -- 25 . 销售渠道
  ,IF_HOT  				 	    -- 26 . 是否核心销售
  ,IF_KEY_SALES  			    -- 27 . 是否重点销售产品
  ,PROD_DEDLN  				    -- 28 . 产品期限
  ,YLD_TP_CD  				    -- 29 . 收益类型(适当性)
  ,YLD_TP_DSC  				    -- 30 . 收益类型描述
  ,PROD_RSK_RTG_CD  		    -- 31 . 产品风险评级
  ,PROD_RSK_RTG_DSC  		    -- 32 . 产品风险评级描述
  ,LINKED_RLD_CGY_CD  		    -- 33 . 挂钩标的类别 
  ,LINKED_RLD_CGY_NM  		    -- 34 . 挂钩标的名称 
  ,LINKED_RTO  				 	-- 35 . 挂钩率(%) 
  ,LINKED_YLD_EXPLN  		    -- 36 . 挂钩收益说明 
  ,TRD_LOCTN  				    -- 37 . 交易场所 
  ,ADVBOOK_START_DT  		 	-- 38 . 预售期起始日
  ,ADVBOOK_END_DT  			 	-- 39 . 预售期结束日
  ,WINDG_START_DT  			 	-- 40 . 清盘期起始日
  ,WINDG_END_DT  			 	-- 41 . 清盘期结束日
  ,PROD_END_DT  			 	-- 42 . 产品结束日
  ,PROD_PHS_CD  			    -- 43 . 产品阶段
  ,PROD_PHS_DSC  			    -- 44 . 产品阶段描述
  ,TRD_STAT_CD  			    -- 45 . 交易状态
  ,TRD_STAT_DSC  			    -- 46 . 交易状态描述
  ,PROD_DEDLN_SDX  			    -- 47 . 产品期限(适当性)
  ,PROD_DEDLN_SDX_DSC  		    -- 48 . 产品期限描述
  ,IF_PROD_GRADE_CD  		    -- 49 . 产品是否分级
  ,IF_PROD_GRADE_DSC  		    -- 50 . 产品是否分级描述
  ,UNIT_NAV  				 	-- 51 . 单位净值
  ,GT_NAV  					 	-- 52 . 累计净值
  ,NAV_DT  					 	-- 53 . 净值日期
  ,IDV_FSTTM_SCRP_LOW_AMT 	 	-- 54 . 个人首次认购最低金额
  ,ORG_FSTTM_SCRP_LOW_AMT 	 	-- 55 . 机构首次认购最低金额
  ,IDV_ADDI_SCRP_LOW_AMT  	 	-- 56 . 个人追加认购最低金额
  ,ORG_ADDI_SCRP_LOW_AMT  	 	-- 57 . 机构追加认购最低金额
  ,IDV_FSTTM_PRCH_LOW_AMT 	 	-- 58 . 个人首次申购最低金额
  ,ORG_FSTTM_PRCH_LOW_AMT 	 	-- 59 . 机构首次申购最低金额
  ,IDV_ADDI_PRCH_LOW_AMT  	 	-- 60 . 个人追加申购最低金额
  ,ORG_ADDI_PRCH_LOW_AMT  	 	-- 61 . 机构追加申购最低金额
  ,IF_FIXINV_FND  			    -- 62 . 是否定投基金
  ,FIXINV_STAT 				    -- 63 . 定投状态
  ,FIXINV_STAT_DSC			    -- 64 . 定投状态描述
  ,FIXINV_STRT  			 	-- 65 . 定投起点
  ,FIXINV_INCRM  			 	-- 66 . 定投递增金额
  ,ESP_FEE_RATE  			    -- 67 . 特别费率优惠
  ,HLD_SHR_LOW  			 	-- 68 . 最低持有份额
  ,IVSM_CL  				    -- 69 . 投资品种
  ,IVSM_CL_DSC  			    -- 70 . 投资品种描述
  ,FIT_IVSTR_TP                 -- 71 . 适合投资者类型
  ,FIT_IVSTR_TP_DSC             -- 72 . 适合投资者类型描述
  ,ISSUE_PLCG_MOD               -- 73 . 发售方式
  ,ISSUE_PLCG_MOD_DSC           -- 74 . 发售方式描述
  ,FND_PROP                     -- 75 . 基金性质
  ,FND_PROP_DSC                 -- 76 . 基金性质描述
  ,SHR_ATTR                     -- 77 . 份额属性
  ,SHR_ATTR_DSC                 -- 78 . 份额属性描述
  ,DATA_SCR                     -- 79 . 数据来源
  ,PROD_CODE                    -- 80 . 产品代码1(场内基金转换后代码)
  ,PREP_TXT_COL1                -- 81 . 预留文本字段1
  ,PREP_TXT_COL2                -- 82 . 预留文本字段2
  ,PREP_TXT_COL3                -- 83 . 预留文本字段3
  ,PREP_TXT_COL4                -- 84 . 预留文本字段4
  ,PREP_TXT_COL5                -- 85 . 预留文本字段5
  ,PREP_NUM_COL1                -- 86 . 预留数值字段1
  ,PREP_NUM_COL2                -- 87 . 预留数值字段2
  ,PREP_NUM_COL3                -- 88 . 预留数值字段3
  ,PREP_INT_COL1                -- 89 . 预留整型字段1
  ,PREP_INT_COL2                -- 90 . 预留整型字段2
  ,PREP_INT_COL3                -- 91 . 预留整型字段3
)
PARTITION( BUS_DATE = %d{yyyyMMdd})
SELECT 
   T2.ID  						                            --  1 . 产品ID(PK)
  ,CASE WHEN NVL(T2.INR_CD,'') <>  '' THEN T2.INR_CD
   ELSE CONCAT('GMJJ',T3.NUM) END AS INR_CD                 --  2 . 产品内部代码
  ,T2.PROD_CD  				                                --  3 . 产品代码
  ,T2.PROD_CL_CD  				                            --  4 . 产品分类
  ,T2.PROD_CL_DSC  			                                --  5 . 产品分类描述
  ,T2.PROD_FULLNM  			                                --  6 . 产品全称
  ,T2.PROD_SHRTNM  			                                --  7 . 产品简称
  ,T2.PROD_CRINT_DT  				                        --  8 . 产品起息日
  ,T2.PROD_ESTAB_DT  			 	                        --  9 . 产品成立日
  ,T2.IVSM_EXPI_DT  			 	                        -- 10 . 投资到期日
  ,T2.CASHE_DT  				 	                        -- 11 . 兑付日期
  ,T2.RAIS_STRT_DT  			 	                        -- 12 . 募集起始日期
  ,T2.RAIS_END_DT  			 	                            -- 13 . 募集结束日期
  ,T2.PROD_ADMIN  				                            -- 14 . 产品管理人
  ,T2.PROD_ADMIN_DSC  			                            -- 15 . 产品管理人描述
  ,T2.PROD_SCL_UPLMT  			                            -- 16 . 产品规模上限
  ,T2.SALE_NETPOT  			                                -- 17 . 销售网点
  ,T2.PROD_SALE_REG  			                            -- 18 . 产品销售地区
  ,T2.PROD_SALE_STRT_DT  		 	                        -- 19 . 产品销售起始日期
  ,T2.PROD_SALE_END_DT  		 	                        -- 20 . 产品销售结束日期
  ,T2.PROD_SUST_MKT_START_DT 	 	                        -- 21 . 产品持续营销起始日
  ,T2.PROD_SUST_MKT_END_DT  	 	                        -- 22 . 产品持续营销结束日
  ,T2.PROD_HLT  				                            -- 23 . 产品亮点
  ,T2.PROD_ASS_POLICY  		                                -- 24 . 产品考核政策
  ,T2.SALE_CNL_CD  			                                -- 25 . 销售渠道
  ,T2.IF_HOT  				 	                            -- 26 . 是否核心销售
  ,T2.IF_KEY_SALES  			                            -- 27 . 是否重点销售产品
  ,T2.PROD_DEDLN  				                            -- 28 . 产品期限
  ,T2.YLD_TP_CD  				                            -- 29 . 收益类型(适当性)
  ,T2.YLD_TP_DSC  				                            -- 30 . 收益类型描述
  ,T2.PROD_RSK_RTG_CD  		                                -- 31 . 产品风险评级
  ,T2.PROD_RSK_RTG_DSC  		                            -- 32 . 产品风险评级描述
  ,T2.LINKED_RLD_CGY_CD  		                            -- 33 . 挂钩标的类别 
  ,T2.LINKED_RLD_CGY_NM  		                            -- 34 . 挂钩标的名称 
  ,T2.LINKED_RTO  				 	                        -- 35 . 挂钩率(%) 
  ,T2.LINKED_YLD_EXPLN  		                            -- 36 . 挂钩收益说明 
  ,T2.TRD_LOCTN  				                            -- 37 . 交易场所 
  ,T2.ADVBOOK_START_DT  		 	                        -- 38 . 预售期起始日
  ,T2.ADVBOOK_END_DT  			 	                        -- 39 . 预售期结束日
  ,T2.WINDG_START_DT  			 	                        -- 40 . 清盘期起始日
  ,T2.WINDG_END_DT  			 	                        -- 41 . 清盘期结束日
  ,T2.PROD_END_DT  			                                -- 42 . 产品结束日
  ,T2.PROD_PHS_CD  			                                -- 43 . 产品阶段
  ,T2.PROD_PHS_DSC  			                            -- 44 . 产品阶段描述
  ,T2.TRD_STAT_CD                                           -- 45 . 交易状态
  ,T2.TRD_STAT_DSC  			                            -- 46 . 交易状态描述
  ,T2.PROD_DEDLN_SDX  			                            -- 47 . 产品期限(适当性)
  ,T2.PROD_DEDLN_SDX_DSC  		                            -- 48 . 产品期限描述
  ,T2.IF_PROD_GRADE_CD  		                            -- 49 . 产品是否分级
  ,T2.IF_PROD_GRADE_DSC  		                            -- 50 . 产品是否分级描述
  ,T2.UNIT_NAV  				 	                        -- 51 . 单位净值
  ,T2.GT_NAV  					 	                        -- 52 . 累计净值
  ,T2.NAV_DT  					 	                        -- 53 . 净值日期
  ,T2.IDV_FSTTM_SCRP_LOW_AMT 	 	                        -- 54 . 个人首次认购最低金额
  ,T2.ORG_FSTTM_SCRP_LOW_AMT 	 	                        -- 55 . 机构首次认购最低金额
  ,T2.IDV_ADDI_SCRP_LOW_AMT  	 	                        -- 56 . 个人追加认购最低金额
  ,T2.ORG_ADDI_SCRP_LOW_AMT  	 	                        -- 57 . 机构追加认购最低金额
  ,T2.IDV_FSTTM_PRCH_LOW_AMT 	 	                        -- 58 . 个人首次申购最低金额
  ,T2.ORG_FSTTM_PRCH_LOW_AMT 	 	                        -- 59 . 机构首次申购最低金额
  ,T2.IDV_ADDI_PRCH_LOW_AMT  	 	                        -- 60 . 个人追加申购最低金额
  ,T2.ORG_ADDI_PRCH_LOW_AMT  	 	                        -- 61 . 机构追加申购最低金额
  ,T2.IF_FIXINV_FND  			                            -- 62 . 是否定投基金
  ,T2.FIXINV_STAT 				                            -- 63 . 定投状态
  ,T2.FIXINV_STAT_DSC			                            -- 64 . 定投状态描述
  ,T2.FIXINV_STRT                                           -- 65 . 定投起点
  ,T2.FIXINV_INCRM  			 	                        -- 66 . 定投递增金额
  ,T2.ESP_FEE_RATE  			                            -- 67 . 特别费率优惠
  ,T2.HLD_SHR_LOW                                           -- 68 . 最低持有份额
  ,T2.IVSM_CL                                               -- 69 . 投资品种
  ,T2.IVSM_CL_DSC                                           -- 70 . 投资品种描述
  ,T2.FIT_IVSTR_TP                                          -- 71 . 适合投资者类型
  ,T2.FIT_IVSTR_TP_DSC                                      -- 72 . 适合投资者类型描述
  ,T2.ISSUE_PLCG_MOD                                        -- 73 . 发售方式
  ,T2.ISSUE_PLCG_MOD_DSC                                    -- 74 . 发售方式描述
  ,T2.FND_PROP                                              -- 75 . 基金性质
  ,T2.FND_PROP_DSC                                          -- 76 . 基金性质描述
  ,T2.SHR_ATTR                                              -- 77 . 份额属性
  ,T2.SHR_ATTR_DSC                                          -- 78 . 份额属性描述
  ,T2.DATA_SCR                                              -- 79 . 数据来源
  ,T2.PROD_CODE                                             -- 80 . 产品代码1(场内基金转换后代码)
  ,'' AS PREP_TXT_COL1                                      -- 81 . 预留文本字段1
  ,'' AS PREP_TXT_COL2                                      -- 82 . 预留文本字段2
  ,'' AS PREP_TXT_COL3                                      -- 83 . 预留文本字段3
  ,'' AS PREP_TXT_COL4                                      -- 84 . 预留文本字段4
  ,'' AS PREP_TXT_COL5                                      -- 85 . 预留文本字段5
  ,0 AS PREP_NUM_COL1                                       -- 86 . 预留数值字段1
  ,0 AS PREP_NUM_COL2                                       -- 87 . 预留数值字段2
  ,0 AS PREP_NUM_COL3                                       -- 88 . 预留数值字段3
  ,0 AS PREP_INT_COL1                                       -- 89 . 预留整型字段1
  ,0 AS PREP_INT_COL2                                       -- 90 . 预留整型字段2
  ,0 AS PREP_INT_COL3                                       -- 91 . 预留整型字段3
FROM DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP4 T1
INNER JOIN DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP3 T2
ON T1.PROD_CD = T2.PROD_CD
AND SUBSTR(T1.PROD_CL_CD,1,2) = SUBSTR(T2.PROD_CL_CD,1,2)
LEFT JOIN DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP7 T3
ON T1.PROD_CD = T3.PROD_CD
AND T1.PROD_CL_CD = T3.PROD_CL_CD
WHERE T1.DATA_SCR = 'JZJY'
;


--跑批结束插入标志位
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_LM_FNCL_PROD_BAS_ATTR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
invalidate metadata DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP1;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP2;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP3;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP4;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP5;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP6;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_LM_FNCL_PROD_BAS_ATTR_TMP7;
------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户产指标日表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2018-05-16                                                                        */ 
  
----产品持仓
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_PROD_IDX_DAY_TEMP;
 CREATE TABLE DDW_PROD.T_DDW_F10_CUST_PROD_IDX_DAY_TEMP as 
 SELECT    CUST_NO            as CUST_NO
          ,SEC_CD             as PROD_CD
		  ,'场内基金'         as PROD_CGY
		  ,SUM(SEC_QTY)       as HLD_QTY
          ,SUM(SEC_MKTVAL)	  as HLD_AMT	  
 FROM     DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS
 WHERE    SUBSTR(SEC_CGY,1,1) IN ('J','E','L')
 AND      BUS_DATE = %d{yyyyMMdd}
 GROUP BY CUST_NO,PROD_CD,PROD_CGY
 UNION ALL
 SELECT    CUST_NO                    as CUST_NO
          ,PROD_CD                    as PROD_CD
		  ,CASE WHEN PROD_CGY = 9
		        THEN '银行产品'
				WHEN PROD_CGY = 8
				AND  PROD_CD = 'A30003'
		        THEN '现金添利' 
				WHEN PROD_CGY = 8
				AND  PROD_CD < > 'A30003'
				AND  SUBSTR(PROD_CD,1,1) = 'A'
		        THEN '公司产品' 
				WHEN PROD_CGY = 8				
				AND  SUBSTR(PROD_CD,1,2) = '95'
		        THEN '国君产品'
				ELSE '场外基金'
				END                   as PROD_CGY
		  ,SUM(PROD_SHR_QTY)          as HLD_QTY
          ,SUM(PROD_NEWST_MKTVAL)	  as HLD_AMT	  
 FROM     DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS
 WHERE    BUS_DATE = %d{yyyyMMdd}
 GROUP BY CUST_NO,PROD_CD,PROD_CGY
 ;
--------临时表2
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_PROD_IDX_DAY_TEMP1;
 CREATE TABLE DDW_PROD.T_DDW_F10_CUST_PROD_IDX_DAY_TEMP1 as 
 SELECT   CUST_NO             as CUST_NO
         ,SEC_CD             as PROD_CD
         ,'场内基金'         as PROD_CGY
         ,SUM(CASE WHEN ODR_CGY IN (83)
                   THEN MTCH_QTY
                   ELSE 0
                   END
			 ) 	as SCRP_QTY	       --认购数量
		 ,SUM(CASE WHEN ODR_CGY IN (1111,42)
               THEN MTCH_QTY
               ELSE 0
               END) 	as PRCH_QTY	        --申购数量
         ,SUM(CASE WHEN ODR_CGY IN (29)
                   THEN MTCH_QTY           
                   ELSE 0
                   END
			 )	   as ABTG_PRCH_QTY   --套利申购数量
		,SUM(CASE WHEN ODR_CGY IN (43,2222)
                  THEN MTCH_QTY
                  ELSE 0
                  END
            )				  as RDMPT_QTY                      --赎回数量
		,SUM(CASE WHEN ODR_CGY IN (30)
                  THEN MTCH_QTY
                  ELSE 0
                  END)  as ABTG_RDMPT_QTY                 --套利赎回数量	   
         ,SUM(CASE WHEN ODR_CGY IN (1)
                   THEN MTCH_QTY
                   ELSE 0
                   END
			 )   as BUYIN_QTY                      --买入数量
		 ,SUM(CASE WHEN ODR_CGY IN (2)
                   THEN MTCH_QTY
                   ELSE 0
                   END
			 )   as SELL_QTY                       --卖出数量
		,SUM(CASE WHEN ODR_CGY IN (46)
                  THEN MTCH_QTY
                  ELSE 0
                  END 
 			)	  as TFRM_QTY                       --转换数量
		 ,SUM(CASE WHEN ODR_CGY IN (6,45)
                   THEN MTCH_QTY
                   ELSE 0
                   END)    as BNS_QTY                        --分红数量
        ,SUM(CASE WHEN ODR_CGY IN (83)
                  THEN MTCH_AMT
                  ELSE 0
                  END
			)	  as SCRP_AMT	              --认购金额
		 ,SUM(CASE WHEN ODR_CGY IN (1111,42)
                   THEN MTCH_AMT
                   ELSE 0
                   END
             )		as PRCH_AMT	             --申购金额
         ,SUM(CASE WHEN ODR_CGY IN (29)
                   THEN MTCH_AMT
                   ELSE 0
                   END
			)   as ABTG_PRCH_AMT           --套利申购金额
		,SUM(CASE WHEN ODR_CGY IN (43,2222)
                  THEN MTCH_AMT
                  ELSE 0
                  END)  as RDMPT_AMT                      --赎回金额
		,SUM(CASE WHEN ODR_CGY IN (30)
                  THEN MTCH_AMT
                  ELSE 0
                  END 
			)	  as ABTG_RDMPT_AMT                 --套利赎回金额	   
        ,SUM(CASE WHEN ODR_CGY IN (1)
                  THEN MTCH_AMT
                  ELSE 0
                  END
			)	  as BUYIN_AMT                      --买入金额
		,SUM(CASE WHEN ODR_CGY IN (2)
                  THEN MTCH_AMT
                  ELSE 0
                  END
			)	  as SELL_AMT                       --卖出金额
	   ,SUM(CASE WHEN ODR_CGY IN (46)
                    THEN MTCH_AMT
                    ELSE 0
                    END
	   	)	  as TFRM_AMT                       --转换金额
		 ,SUM(CASE WHEN ODR_CGY IN (6,45)
                   THEN MTCH_AMT
                   ELSE 0
                   END
			)	   as BNS_AMT                        --分红金额
         ,SUM(CASE WHEN ODR_CGY IN (80,81,83)
                   THEN S1
                   ELSE 0
                   END
			 )   as 	 SCRP_CMSN_FEE                  --认购手续费
		  ,SUM(CASE WHEN ODR_CGY IN (1111,42)
                    THEN S1
                    ELSE 0
                    END
				)	as PRCH_CMSN_FEE                  --申购手续费
		  ,SUM(CASE WHEN ODR_CGY IN (2222,43)
                    THEN S1
                    ELSE 0
                    END
			  )	as RDMPT_CMSN_FEE                 --赎回手续费
		  ,SUM(CASE WHEN ODR_CGY IN (1)
                    THEN S1
                    ELSE 0
                    END
 				)	as BUYIN_CMSN_FEE                 --买入手续费
		  ,SUM(CASE WHEN ODR_CGY IN (2)
                    THEN S1
                    ELSE 0
                    END
				)	as SELL_CMSN_FEE                  --卖出手续费
		   ,SUM(CASE WHEN ODR_CGY IN (46)
                     THEN S1
                     ELSE 0
                     END
		 		)	as TFRM_CMSN_FEE                  --转换手续费
           ,SUM(CASE WHEN ODR_CGY IN (29)
                     THEN S1
                     ELSE 0
                     END
				)	 as ABTG_PRCH_CMSN_FEE                  --套利申购手续费
		   ,SUM(CASE WHEN ODR_CGY IN (30)
                     THEN S1
                     ELSE 0
                     END
				)	 as ABTG_RDMPT_CMSN_FEE                  --套利赎回手续费			   
 FROM   DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
 WHERE  ODR_CGY IN (1,2,29,30,1111,2222,46,80,81,83)
 AND    BUS_DATE = %d{yyyyMMdd}
 AND    SUBSTR(SEC_CGY,1,1) IN ('J','E','L')
 GROUP BY  CUST_NO,PROD_CD,PROD_CGY
 UNION ALL
 SELECT    t.CUST_NO             as CUST_NO
         ,t.PROD_CD             as PROD_CD
         ,CASE WHEN t.PROD_CGY = 9
		        THEN '银行产品'
				WHEN t.PROD_CGY = 8
				AND  t.PROD_CD = 'A30003'
		        THEN '现金添利' 
				WHEN t.PROD_CGY = 8
				AND  t.PROD_CD < > 'A30003'
				AND  SUBSTR(t.PROD_CD,1,1) = 'A'
		        THEN '公司产品' 
				WHEN t.PROD_CGY = 8				
				AND  SUBSTR(t.PROD_CD,1,2) = '95'
		        THEN '国君产品'
				ELSE '场外基金'
				END                   as PROD_CGY         
         ,SUM(CASE WHEN PROD_BIZ_CD IN ('130')
                   THEN CNFM_SHR
                   ELSE 0
                   END
			 ) 	as SCRP_QTY	       --认购数量
		 ,SUM(CASE WHEN PROD_BIZ_CD IN ('122','139')
               THEN CNFM_SHR
               ELSE 0
               END) 	as PRCH_QTY	        --申购数量
         ,SUM(0)	   as ABTG_PRCH_QTY   --套利申购数量
		,SUM(CASE WHEN PROD_BIZ_CD IN ('124','142')
                  THEN CNFM_SHR
                  ELSE 0
                  END
            )				  as RDMPT_QTY                      --赎回数量
		 ,SUM(0)  as ABTG_RDMPT_QTY                 --套利赎回数量	   
         ,SUM(0)   as BUYIN_QTY                      --买入数量
		 ,SUM(0)   as SELL_QTY                       --卖出数量
		,SUM(CASE WHEN a1.YWDM IN ('136','137','138')
                  THEN a1.QRFE
                  ELSE 0
                  END 
 			)	  as TFRM_QTY                       --转换数量
		 ,SUM(CASE WHEN PROD_BIZ_CD IN ('143')
                   THEN CNFM_SHR
                   ELSE 0
                   END)    as BNS_QTY                        --分红数量
        ,SUM(CASE WHEN PROD_BIZ_CD IN ('130')
                  THEN CNFM_AMT
                  ELSE 0
                  END
			)	  as SCRP_AMT	              --认购金额
		 ,SUM(CASE WHEN PROD_BIZ_CD IN ('139','122')
                   THEN CNFM_AMT
                   ELSE 0
                   END
             )		as PRCH_AMT	             --申购金额
         ,SUM(0)   as ABTG_PRCH_AMT           --套利申购金额
		,SUM(CASE WHEN PROD_BIZ_CD IN ('142','124')
                  THEN CNFM_AMT
                  ELSE 0
                  END)  as RDMPT_AMT                      --赎回金额
		,SUM(0)	  as ABTG_RDMPT_AMT                 --套利赎回金额	   
        ,SUM(0)	  as BUYIN_AMT                      --买入金额
		,SUM(0)	  as SELL_AMT                       --卖出金额
		,SUM(CASE  WHEN  a1.YWDM IN ('136','137','138')
                    THEN a1.QRJE
                    ELSE 0
                    END
	   	 )	  as TFRM_AMT                       --转换金额
		 ,SUM(CASE WHEN PROD_BIZ_CD IN ('143')
                   THEN CNFM_AMT
                   ELSE 0
                   END
			)	   as BNS_AMT                        --分红金额
         ,SUM(CASE WHEN PROD_BIZ_CD IN ('130')
                   THEN CMSN_FEE
				   WHEN PROD_BIZ_CD IN ('600')
				   AND  a2.YWDM = '130'
				   THEN 0-CNFM_AMT
                   ELSE 0
                   END
			 )   as 	 SCRP_CMSN_FEE                  --认购手续费
		  ,SUM(CASE WHEN PROD_BIZ_CD IN ('122','139')
                    THEN CMSN_FEE
					WHEN PROD_BIZ_CD IN ('600')
				    AND  a2.YWDM IN ('122','139')
				    THEN 0-CNFM_AMT
                    ELSE 0
                    END
				)	as PRCH_CMSN_FEE                  --申购手续费
		  ,SUM(CASE WHEN PROD_BIZ_CD IN ('124','142')
                    THEN CMSN_FEE
                    ELSE 0
                    END
			  )	as RDMPT_CMSN_FEE                 --赎回手续费
		  ,SUM(0)	as BUYIN_CMSN_FEE                 --买入手续费
		  ,SUM(0)	as SELL_CMSN_FEE                  --卖出手续费
		  ,SUM(CASE WHEN a1.YWDM IN ('136','137','138')
                     THEN a1.SXF
                     ELSE 0
                     END
		 		)	as TFRM_CMSN_FEE                  --转换手续费
           ,SUM(0)	 as ABTG_PRCH_CMSN_FEE                  --套利申购手续费
		   ,SUM(0)	 as ABTG_RDMPT_CMSN_FEE                  --套利赎回手续费			   
 FROM      DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS  t
 LEFT JOIN EDW_PROD.T_EDW_T05_TOF_JJJGLS            a1
 ON        t.evnt_seqnbr = a1.seqno
 AND       a1.BUS_DATE = %d{yyyyMMdd}
 AND       t.PROD_CGY = 8
 LEFT JOIN (SELECT JJDM,KHH,JJJG_LSH,YWDM
            FROM EDW_PROD.T_EDW_T05_TOF_JJJGLS
			WHERE YWDM IN ('122','139','130')
			GROUP BY JJDM,KHH,JJJG_LSH,YWDM
			)            a2
 ON        a1.KHH = a2.KHH
 AND       a1.JJDM = a2.JJDM
 AND       a1.JJJG_LSH = a2.JJJG_LSH
 AND       a1.YWDM = '600'
 WHERE  t.PROD_BIZ_CD IN ('130','122','124','142','139','143','600','136','8888','9999','6666','7777','5555')
 AND    t.BUS_DATE = %d{yyyyMMdd}
 GROUP BY  CUST_NO,PROD_CD,PROD_CGY
 ;

------插入数据
  INSERT OVERWRITE DDW_PROD.T_DDW_F10_CUST_PROD_IDX_DAY
(                CUST_NO                        --客户号                 
                ,BRH_NO                         --营业部编号                         
                ,CUST_CGY				        --客户类别
                ,PROD_CD                        --产品代码
				,PSN_NO                         --人员编码
				,PROD_CGY                       --产品类别
				,SVC_RLN_TP                     --服务关系类型
				,SCRP_QTY                       --认购数量
				,PRCH_QTY                       --申购数量
				,ABTG_PRCH_QTY                  --套利申购数量
				,RDMPT_QTY                      --赎回数量
				,ABTG_RDMPT_QTY                 --套利赎回数量
				,BUYIN_QTY                      --买入数量
				,SELL_QTY                       --卖出数量
				,TFRM_QTY                       --转换数量
				,BNS_QTY                        --分红数量
				,SCRP_AMT                       --认购金额
				,PRCH_AMT                       --申购金额
				,RDMPT_AMT                      --赎回金额
				,ABTG_PRCH_AMT                  --套利申购金额
				,ABTG_RDMPT_AMT                 --套利赎回金额
				,BUYIN_AMT                      --买入金额
				,SELL_AMT                       --卖出金额
				,TFRM_AMT                       --转换金额
				,BNS_AMT                        --分红金额
				,SCRP_CMSN_FEE                  --认购手续费
				,PRCH_CMSN_FEE                  --申购手续费
				,RDMPT_CMSN_FEE                 --赎回手续费
				,BUYIN_CMSN_FEE                 --买入手续费
				,SELL_CMSN_FEE                  --卖出手续费
				,TFRM_CMSN_FEE                  --转换手续费
                ,ABTG_PRCH_CMSN_FEE			    --套利申购手续费
				,ABTG_RDMPT_CMSN_FEE            --套利赎回手续费				
				,HLD_QTY                        --持仓数量
				,HLD_AMT                        --持仓金额				
 ) partition(BUS_DATE = %d{yyyyMMdd})
 SELECT          
                NVL(t.CUST_NO,a1.CUST_NO)      as CUST_NO                        --客户号                     
                ,a2.BRH_NO                     as BRH_NO                         --营业部编号        
                ,a2.CUST_CGY			       as CUST_CGY				        --客户类别
                ,NVL(t.PROD_CD,a1.PROD_CD)     as PROD_CD                        --产品代码
                ,a3.PSN_NO                     as PSN_NO                         --人员编码
                ,NVL(t.PROD_CGY,a1.PROD_CGY)   as PROD_CGY                       --产品类别
                ,a3.SVC_RLN_TP                 as SVC_RLN_TP                     --服务关系类型
                ,NVL(a1.SCRP_QTY,0)            as SCRP_QTY                       --认购数量
                ,NVL(a1.PRCH_QTY,0)            as PRCH_QTY                       --申购数量
                ,NVL(a1.ABTG_PRCH_QTY,0)       as ABTG_PRCH_QTY                  --套利申购数量
                ,NVL(a1.RDMPT_QTY,0)           as RDMPT_QTY                      --赎回数量
                ,NVL(a1.ABTG_RDMPT_QTY,0)      as ABTG_RDMPT_QTY                 --套利赎回数量
                ,NVL(a1.BUYIN_QTY,0)           as BUYIN_QTY                      --买入数量
                ,NVL(a1.SELL_QTY,0)            as SELL_QTY                       --卖出数量
                ,NVL(a1.TFRM_QTY,0)            as TFRM_QTY                       --转换数量
                ,NVL(a1.BNS_QTY,0)             as BNS_QTY                        --分红数量
                ,NVL(a1.SCRP_AMT,0)            as SCRP_AMT                       --认购金额
                ,NVL(a1.PRCH_AMT,0)            as PRCH_AMT                       --申购金额
                ,NVL(a1.RDMPT_AMT,0)           as RDMPT_AMT                      --赎回金额
                ,NVL(a1.ABTG_PRCH_AMT,0)       as ABTG_PRCH_AMT                  --套利申购金额
                ,NVL(a1.ABTG_RDMPT_AMT,0)      as ABTG_RDMPT_AMT                 --套利赎回金额
                ,NVL(a1.BUYIN_AMT,0)           as BUYIN_AMT                      --买入金额
                ,NVL(a1.SELL_AMT,0)            as SELL_AMT                       --卖出金额
                ,NVL(a1.TFRM_AMT,0)            as TFRM_AMT                       --转换金额
                ,NVL(a1.BNS_AMT,0)             as BNS_AMT                        --分红金额
                ,NVL(a1.SCRP_CMSN_FEE,0)       as SCRP_CMSN_FEE                  --认购手续费
                ,NVL(a1.PRCH_CMSN_FEE,0)       as PRCH_CMSN_FEE                  --申购手续费
                ,NVL(a1.RDMPT_CMSN_FEE,0)      as RDMPT_CMSN_FEE                 --赎回手续费
                ,NVL(a1.BUYIN_CMSN_FEE,0)      as BUYIN_CMSN_FEE                 --买入手续费
                ,NVL(a1.SELL_CMSN_FEE,0)       as SELL_CMSN_FEE                  --卖出手续费
                ,NVL(a1.TFRM_CMSN_FEE,0)       as TFRM_CMSN_FEE                  --转换手续费
                ,NVL(a1.ABTG_PRCH_CMSN_FEE,0)  as ABTG_PRCH_CMSN_FEE			    --套利申购手续费
                ,NVL(a1.ABTG_RDMPT_CMSN_FEE,0) as ABTG_RDMPT_CMSN_FEE            --套利赎回手续费	
                ,NVL(t.HLD_QTY,0)              as HLD_QTY                        --持仓数量
                ,NVL(t.HLD_AMT,0)              as HLD_AMT                        --持仓金额			
 FROM           DDW_PROD.T_DDW_F10_CUST_PROD_IDX_DAY_TEMP   t
 FULL JOIN      DDW_PROD.T_DDW_F10_CUST_PROD_IDX_DAY_TEMP1  a1
 ON             t.CUST_NO = a1.CUST_NO
 AND            t.PROD_CD = a1.PROD_CD
 AND            t.PROD_CGY = a1.PROD_CGY
 LEFT JOIN      DDW_PROD.T_DDW_F00_CUST_CUST_INFO        a2
 ON             NVL(t.CUST_NO,a1.CUST_NO) = a2.CUST_NO
 AND            a2.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN    (SELECT CUST_NO,MAX(BRK_NO) as PSN_NO,'经纪关系' as SVC_RLN_TP 
               FROM   DDW_PROD.T_DDW_F00_CUST_CUST_BRK_RLN 
               WHERE  %d{yyyyMMdd} > = STATS_DT 
               AND      %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
			    AND     BUS_DATE = %d{yyyyMMdd}
			   GROUP BY CUST_NO
               UNION ALL
               SELECT CUST_NO,MAX(PSN_NO) as PSN_NO,'服务关系'  as SVC_RLN_TP
               FROM DDW_PROD.T_DDW_F00_CUST_CUST_RLN
               WHERE    %d{yyyyMMdd} > = STATS_DT 
               AND      %d{yyyyMMdd} < NVL(EXPR_DT,99999999) 
               AND      BUS_DATE = %d{yyyyMMdd}
               AND       SVC_RLN_TP = '4'
			   GROUP BY CUST_NO
			   )                                             a3
  ON             NVL(t.CUST_NO,a1.CUST_NO) = a3.CUST_NO			   
 ;
 
 ------删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_PROD_IDX_DAY_TEMP ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_PROD_IDX_DAY_TEMP1 ;
 
-----------------------插入数据结束-------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_CUST_PROD_IDX_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F10_CUST_PROD_IDX_DAY;
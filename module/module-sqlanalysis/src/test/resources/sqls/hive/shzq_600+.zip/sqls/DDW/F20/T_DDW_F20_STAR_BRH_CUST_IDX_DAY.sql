------/* ***************************************** SQL BEGIN ***************************************** */
------/* 脚本功能:营业部星级客户指标日表                                                                  */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2018-04-20                                                                        */


 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP3 ;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP3 as 
 SELECT t.CUST_NO,SUM(MTCH_AMT) as TRD_VOL
 FROM 
 (SELECT CUST_NO,SUM(ROUND(CASE WHEN b.BUS_DATE IS NOT NULL
                               THEN a.MTCH_AMT*b.ZHHL
						       ELSE a.MTCH_AMT
						       END,2)
			        ) as MTCH_AMT
 FROM   DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS a
 LEFT JOIN     EDW_PROD.T_EDW_T99_HLZH         b
 ON            a.BUS_DATE = b.BUS_DATE
 AND           b.BZDM = a.CCY_CD
 WHERE  a.BUS_DATE = %d{yyyyMMdd}
 AND    a.ODR_CGY IN (1,2,4,5,42,43,57,58,59,60,61,62,63,64,71,72,78,79,80,114,124,1111,2222)
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 GROUP BY a.CUST_NO
 UNION ALL
 SELECT CUST_NO,SUM(MTCH_AMT) as MTCH_AMT
 FROM   DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
 WHERE  BUS_DATE = %d{yyyyMMdd}
 AND    WRNT_BS_DRCT IN ('1','2')
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 GROUP BY CUST_NO
 UNION ALL
 SELECT CUST_NO,SUM(CNFM_AMT) as MTCH_AMT
 FROM   DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS
 WHERE  BUS_DATE = %d{yyyyMMdd}
 AND    PROD_BIZ_CD IN ('130','122','142','150','139','124')
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 GROUP BY CUST_NO
 )  t
 GROUP BY t.CUST_NO
 ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP as 
 SELECT CUST_NO
 FROM   DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS
 WHERE  BUS_DATE = %d{yyyyMMdd}
 AND    ODR_CGY IN (1,2,4,5,42,43,57,58,59,60,61,62,63,64,71,72,78,79,80,114,124,1111,2222)
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 UNION 
 SELECT CUST_NO
 FROM   DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
 WHERE  BUS_DATE = %d{yyyyMMdd}
 AND    WRNT_BS_DRCT IN ('1','2')
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 UNION 
 
 SELECT CUST_NO
 FROM   DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS
 WHERE  BUS_DATE = %d{yyyyMMdd}
 AND    PROD_BIZ_CD IN ('130','122','142','150','139','124')
 AND    CUST_NO NOT IN ('105810000001','100610335855')
 ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP1;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP1 as 
  SELECT         t.BRH_NO
               ,t.CUST_STAR
               ,SUM(DECODE(t.CUST_STAT,'3',1,1)) as CUST_VOL 
               ,SUM(CASE WHEN a2.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TRD_CUST_VOL
			   ,SUM(CASE WHEN NVL(t.IF_CRD_CNCLACT,3) = 0
			             AND  t.CRD_OPNAC_DT IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as CRD_CUST_VOL
			  ,SUM(CASE WHEN a3.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TRD_CRD_CUST_VOL
              ,SUM(CASE WHEN NVL(t.IF_H_K,3) = 0
			            AND  t.H_K_OPNAC_DT IS NOT NULL
			            THEN 1
					    ELSE 0
					    END
				    )                            as H_K_CUST_VOL	
              ,SUM(CASE WHEN a4.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TRD_H_K_CUST_VOL	
              ,SUM(CASE WHEN NVL(t.IF_WRNT_CNCLACT,3) = 0
			            AND  t.WRNT_OPNAC_DT IS NOT NULL
			            THEN 1
					    ELSE 0
					    END
				    )                            as WRNT_CUST_VOL
              ,SUM(CASE WHEN a5.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TRD_WRNT_CUST_VOL					
			  ,SUM(CASE WHEN NVL(t.IF_STIB,3) = 0
			            AND  t.STIB_OPNAC_DT IS NOT NULL
			            THEN 1
					    ELSE 0
					    END
				    )                            as STIB_CUST_VOL	
			  ,SUM(CASE WHEN a7.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TRD_STIB_CUST_VOL              --交易科创板客户数
              ,SUM(CASE WHEN NVL(t.IF_NEW_T3BOD,3) = 0
			            AND  t.NEW_T3BOD_OPNAC_DT IS NOT NULL
			            THEN 1
						WHEN NVL(t.IF_LMT_NEW_T3BOD,3) = 0
			            AND  t.LMT_NEW_T3BOD_OPNAC_DT IS NOT NULL
			            THEN 1
					    ELSE 0
					    END
				    )                            as NEW_T3BOD_CUST_VOL
               ,SUM(CASE WHEN a6.CUST_NO IS NOT NULL
			             THEN 1
					     ELSE 0
					     END
				    )                            as TRD_NWE_T3BOD_CUST_VOL	
                ,SUM(CASE WHEN NVL(t.IF_T3BOD,3) = 0
			            AND  t.T3BOD_OPNAC_DT IS NOT NULL
			            THEN 1
					    ELSE 0
					    END
				    )                            as T3BOD_CUST_VOL	
                ,SUM(CASE WHEN NVL(t.IF_PLG_REPO,3) = 0
			            AND  t.PLG_REPO_OPNAC_DT IS NOT NULL
			            THEN 1
					    ELSE 0
					    END
				    )                            as PLG_REPO_CUST_VOL	
                ,SUM(CASE WHEN NVL(t.IF_STK_PLG,3) = 0
			            AND  t.STK_PLG_OPNAC_DT IS NOT NULL
			            THEN 1
					    ELSE 0
					    END
				    )                            as STK_PLG_CUST_VOL
                 ,SUM(CASE WHEN NVL(t.IF_STR_FND,3) = 0
			            AND  t.STR_FND_OPNAC_DT IS NOT NULL
			            THEN 1
					    ELSE 0
					    END
				    )                            as STR_FND_CUST_VOL
				 ,SUM(CASE WHEN t.CUST_STAT < > '3'
			            AND  t.CUST_CGY = '2'
			            THEN 1
					    ELSE 0
					    END
				    )    as PROD_CUST_VOL
                ,SUM(CASE WHEN NVL(t.IF_CASH_PROD,3) = 0
			            AND  t.CASH_PROD_OPNAC_DT IS NOT NULL
			            THEN 1
					    ELSE 0
					    END
				    )                            as CASH_PROD_CUST_VOL
                 ,SUM(CASE WHEN t.CUST_STAT < > '3'
			               AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
			               THEN 1
					       ELSE 0
					       END
				    )    as QLFD_CUST_VOL	
                ,SUM(CASE WHEN t.CUST_STAT < > '3'
			               AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
			               AND  t.BROK_RLN_PSN_NO IS NOT NULL
						   THEN 1
					       ELSE 0
					       END
				    )    as BROK_RLN_QLFD_CUST_VOL		
                ,SUM(CASE WHEN t.CUST_STAT < > '3'
			               AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
			               AND  t.CUST_RLN = '强服务关系'
						   THEN 1
					       ELSE 0
					       END
				    )    as STRONG_SVC_RLN_QLFD_CUST_VOL
                 ,SUM(CASE WHEN t.CUST_STAT < > '3'
			               AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
			               AND  t.CUST_RLN = '弱服务关系'
						   THEN 1
					       ELSE 0
					       END
				    )    as WEAK_SVC_RLN_QLFD_CUST_VOL	
			      ,SUM(CASE WHEN t.CUST_STAT < > '3'
			               AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
			               AND  t.BROK_RLN_PSN_NO IS NOT NULL
						   THEN 1
					       ELSE 0
					       END
				    )    as BROK_RLN_CUST_VOL		
                ,SUM(CASE WHEN t.CUST_STAT < > '3'
			               AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
			               AND  t.CUST_RLN = '强服务关系'
						   THEN 1
					       ELSE 0
					       END
				    )    as STRONG_SVC_RLN_CUST_VOL
                 ,SUM(CASE WHEN t.CUST_STAT < > '3'
			               AND  t.CUST_RSK_LVL IN ('0','1','2','8','19')
			               AND  t.CUST_RLN = '弱服务关系'
						   THEN 1
					       ELSE 0
					       END
				    )    as WEAK_SVC_RLN_CUST_VOL

					
	           ,SUM(CASE WHEN t.OPNAC_DT =  %d{yyyyMMdd}
			             THEN 1
						 ELSE 0
				         END 
				   )    as OPNAC_CUST_VOL   
				   
               ,SUM(CASE WHEN NVL(t.CRD_OPNAC_DT,0) = %d{yyyyMMdd}
			             THEN 1
						 ELSE 0
				         END 
				   )    as  OPNAC_CRD_CUST_VOL          
               ,SUM(CASE WHEN NVL(t.WRNT_OPNAC_DT,0) = %d{yyyyMMdd}
			             THEN 1
						 ELSE 0
				         END 
				   )   as OPNAC_WRNT_CUST_VOL         
               ,SUM(CASE WHEN NVL(t.STIB_OPNAC_DT,0) = %d{yyyyMMdd}
			             THEN 1
						 ELSE 0
				         END 
				   )  as OPN_STIB_CUST_VOL 
                ,SUM(CASE WHEN NVL(t.H_K_OPNAC_DT,0) = %d{yyyyMMdd}
			             THEN 1
						 ELSE 0
				         END 
				   )  as OPN_H_K_CUST_VOL				   
               ,SUM(CASE WHEN NVL(t.PLG_REPO_OPNAC_DT,0) = %d{yyyyMMdd}
			             THEN 1
						 ELSE 0
				         END 
				   )  as OPN_PLG_REPO_CUST_VOL       
               ,SUM(CASE WHEN NVL(t.STK_PLG_OPNAC_DT,0) = %d{yyyyMMdd}
			             THEN 1
						 ELSE 0
				         END 
				   ) as OPN_STK_PLG_CUST_VOL        
               ,SUM(CASE WHEN NVL(t.STR_FND_OPNAC_DT,0) = %d{yyyyMMdd}
			             THEN 1
						 ELSE 0
				         END 
				   ) as OPN_STR_FND_CUST_VOL        
               ,SUM(CASE WHEN NVL(t.NEW_T3BOD_OPNAC_DT,0) = %d{yyyyMMdd}
			             THEN 1
						 WHEN NVL(t.LMT_NEW_T3BOD_OPNAC_DT,0) = %d{yyyyMMdd}
			             THEN 1
						 ELSE 0
				         END 
				   ) as OPN_NEW_T3BOD_CUST_VOL      
               ,SUM(CASE WHEN NVL(t.T3BOD_OPNAC_DT,0) = %d{yyyyMMdd}
			             THEN 1
						 ELSE 0
				         END 
				   ) as OPN_T3BOD_CUST_VOL  
                ,SUM(CASE WHEN NVL(t.IB_CUST_FLG,'0') = '1'
				          AND    t.CUST_STAT < > '3' 
			              THEN 1
						  ELSE 0
				          END 
				   ) as INR_PB_CUST_VOL  
				  ,SUM(CASE WHEN NVL(t.IB_CUST_FLG,'0') = '1'
				            AND  t.OPNAC_DT =  %d{yyyyMMdd}
			             THEN 1
						 ELSE 0
				         END 
				   ) as OPNAC_INR_PB_CUST_VOL 
               ,SUM(CASE WHEN NVL(t.CNCLACT_DT,0) = %d{yyyyMMdd}
			             AND  t.CUST_STAT = '3'
						 THEN 1
						 ELSE 0
				         END 
				   ) as CNCLACT_CUST_VOL               --销户数(当日)
               ,SUM(CASE WHEN NVL(t.CRD_CNCLACT_DT,0) = %d{yyyyMMdd}
			             AND  t.IF_CRD_CNCLACT = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CNCLACT_CRD_CUST_VOL           --销户信用客户数(当日)
               ,SUM(CASE WHEN NVL(t.WRNT_CNCLACT_DT,0) = %d{yyyyMMdd}
			             AND  t.IF_WRNT_CNCLACT = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CNCLACT_WRNT_CUST_VOL          --销户期权客户数(当日)
               ,SUM(CASE WHEN NVL(t.STIB_CNCLACT_DT,0) = %d{yyyyMMdd}
			             AND  t.IF_STIB = 3
						 THEN 1
						 ELSE 0
				         END 
				   )  as CLS_STIB_CUST_VOL              --关闭科创板客户数(当日)
               ,SUM(CASE WHEN NVL(t.H_K_CNCLACT_DT,0) = %d{yyyyMMdd}
			             AND  t.IF_H_K = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CLS_H_K_CUST_VOL               --关闭港股通客户数(当日)
               ,SUM(CASE WHEN NVL(t.PLG_REPO_CNCLACT_DT,0) = %d{yyyyMMdd}
			             AND  t.IF_PLG_REPO = 3
						 THEN 1
						 ELSE 0
				         END 
				   )  as CLS_PLG_REPO_CUST_VOL          --关闭质押回购客户数(股票质押)(当日)
               ,SUM(CASE WHEN NVL(t.STK_PLG_CNCLACT_DT,0) = %d{yyyyMMdd}
			             AND  t.IF_STK_PLG = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CLS_STK_PLG_CUST_VOL           --关闭股票质押客户数(小微贷)(当日)
               ,SUM(CASE WHEN NVL(t.STR_FND_CNCLACT_DT,0) = %d{yyyyMMdd}
			             AND  t.IF_STR_FND  = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CLS_STR_FND_CUST_VOL           --关闭分级基金客户数
               ,SUM(CASE WHEN NVL(t.NEW_T3BOD_CNCLACT_DT,0) = %d{yyyyMMdd}
			             AND  t.IF_NEW_T3BOD  = 3
						 THEN 1
						 WHEN NVL(t.LMT_NEW_T3BOD_CNCLACT_DT,0) = %d{yyyyMMdd}
			             AND  t.IF_LMT_NEW_T3BOD  = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CLS_NEW_T3BOD_CUST_VOL         --关闭新三板客户数(受限制当日+非受限制当日)
               ,SUM(CASE WHEN NVL(t.T3BOD_CNCLACT_DT,0) = %d{yyyyMMdd}
			             AND  t.IF_T3BOD  = 3
						 THEN 1
						 ELSE 0
				         END 
				   ) as CLS_T3BOD_CUST_VOL             --关闭三板客户数(当日)				   
				,SUM(CASE WHEN SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
			             AND  NVL(t.VLD_DT,0) =  %d{yyyyMMdd}
			             THEN 1
					     ELSE 0
					     END
				    )                            as ADDED_VLD_CUST_VOL
				,SUM(CASE WHEN SUBSTR(CAST(t.OPNAC_DT as STRING),1,4) < SUBSTR('%d{yyyyMMdd}',1,4)
			              AND  NVL(t.VLD_DT,0) =  %d{yyyyMMdd}
			              THEN 1
					      ELSE 0
					      END
				    )                            as ADDED_OLD_VLD_CUST_VOL		
 FROM          DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL   t
 INNER JOIN    DDW_PROD.T_DDW_INR_ORG_BRH               a1
 ON            t.BRH_NO = a1.BRH_NO
 AND           a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP a2
 ON            t.CUST_NO = a2.CUST_NO
 LEFT JOIN   (SELECT CUST_NO 
              FROM  DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
              WHERE BUS_DATE = %d{yyyyMMdd}
			  AND   ODR_CGY IN (1,2,61,62,63,64,71,72,80,83)
			  AND   SYS_SRC = '信用账户'
			  GROUP BY CUST_NO
			  )                                   a3
  ON            t.CUST_NO = a3.CUST_NO
 LEFT JOIN   (SELECT CUST_NO 
              FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
              WHERE BUS_DATE = %d{yyyyMMdd}
			  AND   ODR_CGY IN (1,2,80,83)
			  AND   EXG IN ('HK','SK')
			  AND   SYS_SRC = '普通账户'
			  GROUP BY CUST_NO
             )                                   a4
  ON            t.CUST_NO = a4.CUST_NO
 LEFT JOIN   (SELECT CUST_NO
              FROM   DDW_PROD.T_DDW_F00_TRD_WRNT_TRD_DEL_HIS
              WHERE  BUS_DATE = %d{yyyyMMdd}
              AND    WRNT_BS_DRCT IN ('1','2')
			  GROUP BY CUST_NO
             )                                   a5
  ON            t.CUST_NO = a5.CUST_NO
  LEFT JOIN   (SELECT CUST_NO 
               FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
               WHERE BUS_DATE = %d{yyyyMMdd}
			   AND   ODR_CGY IN (1,2,57,58,59,60,78,79)
			   AND   EXG IN ('TA')
			   AND   SUBSTR(SEC_CD,1,2) IN ('43','83','87')
			   AND   SYS_SRC = '普通账户'
			   GROUP BY CUST_NO
              )                                   a6
 ON            t.CUST_NO = a6.CUST_NO
   LEFT JOIN   (SELECT CUST_NO 
               FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
               WHERE BUS_DATE = %d{yyyyMMdd}
			   AND   ODR_CGY IN (1,2,61,62,63,64,71,72,80,57,58,59,60,78,79,29,30,1111,2222)
			   AND   EXG IN ('SH')
			   AND   SUBSTR(SEC_CD,1,3) IN ('688')
			   AND   SYS_SRC = '普通账户'
			   GROUP BY CUST_NO
              )                                   a7
 ON            t.CUST_NO = a7.CUST_NO
 WHERE         t.BUS_DATE = %d{yyyyMMdd}
 AND           t.OPNAC_DT < = %d{yyyyMMdd}
 GROUP BY       t.BRH_NO
               ,t.CUST_STAR
 ;
 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP2;
 CREATE TABLE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP2 as 
SELECT         t.BRH_NO
               ,t.CUST_STAR
               ,SUM(NVL(a2.TOT_AST,0))     as CUST_TOT_AST
			   ,SUM(NVL(a2.NET_TOT_AST,0)) as CUST_NET_TOT_AST
			   ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
			             THEN a2.NET_TOT_AST
					     ELSE 0
					     END
				   )                        as BROK_RLN_CUST_NET_TOT_AST
               ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
			             THEN a2.NET_TOT_AST
					     ELSE 0
					     END
				   )                        as STRONG_SVC_CUST_NET_TOT_AST
               ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
			             THEN a2.NET_TOT_AST
					     ELSE 0
					     END
				   )                        as WEAK_SVC_CUST_NET_TOT_AST
			   ,SUM(CASE WHEN t.OPNAC_DT =  %d{yyyyMMdd}
			             THEN a2.NET_TOT_AST
					     ELSE 0
					     END
				   )                        as NEW_OPNAC_NET_TOT_AST
		
				 ,SUM(CASE WHEN  NVL(t.VLD_DT,0) =  %d{yyyyMMdd}
                         AND   t.OPNAC_DT > = 20190101
			             THEN a2.NET_TOT_AST
					     ELSE 0
					     END
				   )                        as ADDED_VLD_NET_TOT_AST
				  ,SUM(CASE WHEN  NVL(t.VLD_DT,0) =  %d{yyyyMMdd}
                            AND   t.OPNAC_DT BETWEEN 20160101 AND 20181231
			                THEN a2.NET_TOT_AST
					        ELSE 0
					        END
				     )                        as ADDED_OLD_VLD_NET_TOT_AST
				 ,SUM(NVL(a2.NET_TFR_IN_AMT,0)+NVL(a2.NET_TFR_IN_MKTVAL,0)) as NET_TFR_IN_AST
				 ,SUM(ROUND(NVL(a3.ORDI_TRD_VOL_HB_USD,0)*a6.ZHHL,2)+ROUND(NVL(a3.ORDI_TRD_VOL_SB_HKD,0)*a7.ZHHL,2)+NVL(a3.TRD_VOL_GEM,0)+NVL(a3.TRD_VOL_SMS,0)+NVL(a3.TRD_VOL_SA,0)+NVL(a3.TRD_VOL_HA,0)+NVL(a3.TRD_VOL_RK,0)+NVL(a3.TRD_VOL_AK,0)) as STK_TRD_VOL
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN ROUND(NVL(a3.ORDI_TRD_VOL_HB_USD,0)*a6.ZHHL,2)+ROUND(NVL(a3.ORDI_TRD_VOL_SB_HKD,0)*a7.ZHHL,2)+NVL(a3.TRD_VOL_GEM,0)+NVL(a3.TRD_VOL_SMS,0)+NVL(a3.TRD_VOL_SA,0)+NVL(a3.TRD_VOL_HA,0)+NVL(a3.TRD_VOL_RK,0)+NVL(a3.TRD_VOL_AK,0)
					       ELSE 0
					       END
					)       as BROK_RLN_STK_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN ROUND(NVL(a3.ORDI_TRD_VOL_HB_USD,0)*a6.ZHHL,2)+ROUND(NVL(a3.ORDI_TRD_VOL_SB_HKD,0)*a7.ZHHL,2)+NVL(a3.TRD_VOL_GEM,0)+NVL(a3.TRD_VOL_SMS,0)+NVL(a3.TRD_VOL_SA,0)+NVL(a3.TRD_VOL_HA,0)+NVL(a3.TRD_VOL_RK,0)+NVL(a3.TRD_VOL_AK,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_STK_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN ROUND(NVL(a3.ORDI_TRD_VOL_HB_USD,0)*a6.ZHHL,2)+ROUND(NVL(a3.ORDI_TRD_VOL_SB_HKD,0)*a7.ZHHL,2)+NVL(a3.TRD_VOL_GEM,0)+NVL(a3.TRD_VOL_SMS,0)+NVL(a3.TRD_VOL_SA,0)+NVL(a3.TRD_VOL_HA,0)+NVL(a3.TRD_VOL_RK,0)+NVL(a3.TRD_VOL_AK,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_STK_TRD_VOL
					
				 ,SUM(NVL(a3.ORDI_TRD_VOL_EXG_FND,0)+NVL(a3.CRD_TRD_VOL_EXG_FND,0)) as FND_TRD_VOL
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a3.ORDI_TRD_VOL_EXG_FND,0)+NVL(a3.CRD_TRD_VOL_EXG_FND,0)
					       ELSE 0
					       END
					)       as BROK_RLN_FND_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a3.ORDI_TRD_VOL_EXG_FND,0)+NVL(a3.CRD_TRD_VOL_EXG_FND,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_FND_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a3.ORDI_TRD_VOL_EXG_FND,0)+NVL(a3.CRD_TRD_VOL_EXG_FND,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_FND_TRD_VOL
			  
			     ,SUM(NVL(a3.ORDI_TRD_VOL_HK,0)+NVL(a3.ORDI_TRD_VOL_SK,0)) as H_K_TRD_VOL
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a3.ORDI_TRD_VOL_HK,0)+NVL(a3.ORDI_TRD_VOL_SK,0)
					       ELSE 0
					       END
					)       as BROK_RLN_H_K_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a3.ORDI_TRD_VOL_HK,0)+NVL(a3.ORDI_TRD_VOL_SK,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_H_K_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a3.ORDI_TRD_VOL_HK,0)+NVL(a3.ORDI_TRD_VOL_SK,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_H_K_TRD_VOL
					
				 ,SUM(NVL(a4.NEW_T3BOD_TRD_VOL,0)) as NEW_T3BOD_TRD_VOL
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a4.NEW_T3BOD_TRD_VOL,0)
					       ELSE 0
					       END
					)       as BROK_RLN_NEW_T3BOD_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a4.NEW_T3BOD_TRD_VOL,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_NEW_T3BOD_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a4.NEW_T3BOD_TRD_VOL,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_NEW_T3BOD_TRD_VOL
				 ,SUM(NVL(a5.TRD_VOL_CRD,0)) as CRD_TRD_VOL
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a5.TRD_VOL_CRD,0)
					       ELSE 0
					       END
					)       as BROK_RLN_CRD_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a5.TRD_VOL_CRD,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_RLN_CRD_TRD_VOL
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a5.TRD_VOL_CRD,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_RLN_CRD_TRD_VOL
                      
                ,SUM(NVL(a5.TDY_ADDED_MRGNC_INT,0))  as TDY_ADDED_MRGNC_INT            --当日新增融资利息
                ,SUM(NVL(a5.TDY_ADDED_MRGNS_INT,0))  as TDY_ADDED_MRGNS_INT          --当日新增融券利息

		        ,SUM(NVL(a2.STK_PLG_AMT,0))              as STK_PLG_AMT                   --股票质押余额
                ,SUM(NVL(a2.STK_PLG_ADD_INT,0))          as STK_PLG_ADD_INT              --股票质押新增利息
                ,SUM(NVL(a2.STK_PLG_ADD_TRD_AMT,0))      as STK_PLG_ADD_TRD_AMT          --股票质押初始交易量
				,SUM(NVL(a2.MIN_STK_PLG_AMT,0))          as MIN_STK_PLG_AMT              --小微贷余额
                ,SUM(NVL(a2.MIN_STK_PLG_ADD_INT,0))      as MIN_STK_PLG_ADD_INT          --小微贷新增利息
                ,SUM(NVL(a2.MIN_STK_PLG_ADD_TRD_AMT,0))  as MIN_STK_PLG_ADD_TRD_AMT      --小微贷初始交易量	
				,SUM(CASE WHEN NVL(a2.STK_PLG_ADD_TRD_AMT,0) > 0
				      THEN 1
					  ELSE 0
					  END) as  TRD_PLG_REPO_CUST_VOL          --交易质押回购客户数(股票质押)
                ,SUM(CASE WHEN NVL(a2.MIN_STK_PLG_ADD_TRD_AMT,0) > 0
				      THEN 1
					  ELSE 0
					  END) as TRD_STK_PLG_CUST_VOL           --交易股票质押客户数(小微贷)
				 
				 ,SUM(NVL(a3.ORDI_NET_S1_INCM_HB_RMB,0)+NVL(a3.ORDI_NET_S1_INCM_SB_RMB,0)+NVL(a3.NET_S1_INCM_HA,0)+NVL(a3.NET_S1_INCM_SA,0)+NVL(a3.NET_S1_INCM_SMS,0)+NVL(a3.NET_S1_INCM_GEM,0)+NVL(a3.NET_S1_INCM_STIB_AK,0)+NVL(a3.NET_S1_INCM_STIB_RK,0)) as STK_NET_S1 
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a3.ORDI_NET_S1_INCM_HB_RMB,0)+NVL(a3.ORDI_NET_S1_INCM_SB_RMB,0)+NVL(a3.NET_S1_INCM_HA,0)+NVL(a3.NET_S1_INCM_SA,0)+NVL(a3.NET_S1_INCM_SMS,0)+NVL(a3.NET_S1_INCM_GEM,0)+NVL(a3.NET_S1_INCM_STIB_AK,0)+NVL(a3.NET_S1_INCM_STIB_RK,0)
					       ELSE 0
					       END
					)       as BROK_RLN_STK_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a3.ORDI_NET_S1_INCM_HB_RMB,0)+NVL(a3.ORDI_NET_S1_INCM_SB_RMB,0)+NVL(a3.NET_S1_INCM_HA,0)+NVL(a3.NET_S1_INCM_SA,0)+NVL(a3.NET_S1_INCM_SMS,0)+NVL(a3.NET_S1_INCM_GEM,0)+NVL(a3.NET_S1_INCM_STIB_AK,0)+NVL(a3.NET_S1_INCM_STIB_RK,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_STK_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a3.ORDI_NET_S1_INCM_HB_RMB,0)+NVL(a3.ORDI_NET_S1_INCM_SB_RMB,0)+NVL(a3.NET_S1_INCM_HA,0)+NVL(a3.NET_S1_INCM_SA,0)+NVL(a3.NET_S1_INCM_SMS,0)+NVL(a3.NET_S1_INCM_GEM,0)+NVL(a3.NET_S1_INCM_STIB_AK,0)+NVL(a3.NET_S1_INCM_STIB_RK,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_STK_NET_S1
					
				 ,SUM(NVL(a3.ORDI_NET_S1_INCM_EXG_FND,0)+NVL(a3.CRD_NET_S1_INCM_EXG_FND,0)) as FND_NET_S1 
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a3.ORDI_NET_S1_INCM_EXG_FND,0)+NVL(a3.CRD_NET_S1_INCM_EXG_FND,0)
					       ELSE 0
					       END
					)       as BROK_RLN_FND_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a3.ORDI_NET_S1_INCM_EXG_FND,0)+NVL(a3.CRD_NET_S1_INCM_EXG_FND,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_FND_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a3.ORDI_NET_S1_INCM_EXG_FND,0)+NVL(a3.CRD_NET_S1_INCM_EXG_FND,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_FND_NET_S1
					
				 ,SUM(NVL(a3.ORDI_NET_S1_INCM_HK,0)+NVL(a3.ORDI_NET_S1_INCM_SK,0)) as H_K_NET_S1 
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a3.ORDI_NET_S1_INCM_HK,0)+NVL(a3.ORDI_NET_S1_INCM_SK,0)
					       ELSE 0
					       END
					)       as BROK_RLN_H_K_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a3.ORDI_NET_S1_INCM_HK,0)+NVL(a3.ORDI_NET_S1_INCM_SK,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_H_K_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a3.ORDI_NET_S1_INCM_HK,0)+NVL(a3.ORDI_NET_S1_INCM_SK,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_H_K_NET_S1
					
				 ,SUM(NVL(a4.NEW_T3BOD_NET_S1,0)) as NEW_T3BOD_NET_S1
				 ,SUM(CASE WHEN t.BROK_RLN_PSN_NO IS NOT NULL
				           THEN NVL(a4.NEW_T3BOD_NET_S1,0)
					       ELSE 0
					       END
					)       as BROK_RLN_NEW_T3BOD_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '强服务关系'
				           THEN NVL(a4.NEW_T3BOD_NET_S1,0)
					       ELSE 0
					       END
					)       as STRONG_SVC_NEW_T3BOD_NET_S1
			     ,SUM(CASE WHEN NVL(t.CUST_RLN,'1') = '弱服务关系'
				           THEN NVL(a4.NEW_T3BOD_NET_S1,0)
					       ELSE 0
					       END
					)       as WEAK_SVC_NEW_T3BOD_NET_S1
				 ,SUM(NVL(a2.TOT_CPTL,0)) as CPTL_BAL
				 ,SUM(NVL(a2.MKTVAL_HA,0)+NVL(a2.MKTVAL_SA,0)+NVL(a2.MKTVAL_SMS,0)+NVL(a2.MKTVAL_SMS,0)+NVL(a2.MKTVAL_GEM,0)+NVL(a2.ORDI_MKTVAL_AK_STIB,0)+NVL(a2.ORDI_MKTVAL_RK_STIB,0)+NVL(a2.CRD_MKTVAL_AK_STIB,0)+NVL(a2.CRD_MKTVAL_RK_STIB,0)) as A_STK_MKTVAL                 
                 ,SUM(ROUND((NVL(a2.ORDI_MKTVAL_HB_USD,0)*a6.ZHHL+NVL(a2.ORDI_MKTVAL_SB_HKD,0)*a7.ZHHL),2)) as B_STK_MKTVAL                
                 ,SUM(NVL(a2.ORDI_MKTVAL_HK,0)+NVL(a2.ORDI_MKTVAL_SK,0)) as H_K_STK_MKTVAL              
                 ,SUM(NVL(a8.TRD_VOL,0))  as TRD_VOL                     
                 ,SUM(NVL(a3.ORDI_NET_S1_INCM_RMB,0)+NVL(a3.CRD_NET_S1_INCM,0)) as NET_S1_INCM                 
                 ,SUM(NVL(a3.CRD_MRGNC_MRGNS_PRDCT_INT,0)+NVL(a3.ORDI_PLG_REPO_PRDCT_INT,0)) as INT_INCM                    
                 ,SUM(NVL(a3.NET_S1_INCM_HA,0)+NVL(a3.NET_S1_INCM_SA,0)+NVL(a3.NET_S1_INCM_SMS,0)+NVL(a3.NET_S1_INCM_GEM,0)+NVL(a3.NET_S1_INCM_STIB_AK,0)+NVL(a3.NET_S1_INCM_STIB_RK,0)) as A_STK_NET_S1                
                 ,SUM(NVL(a3.TRD_VOL_HA,0)+NVL(a3.TRD_VOL_SA,0)+NVL(a3.TRD_VOL_SMS,0)+NVL(a3.TRD_VOL_GEM,0)+NVL(a3.TRD_VOL_RK,0)+NVL(a3.TRD_VOL_AK,0)) as A_STK_TRD_VOL               
                 ,SUM(NVL(a5.MRGNC_INL_GL,0)) as MRGNC_CPTL_BAL              
                 ,SUM(NVL(a5.MRGNS_INL_GL,0)) as MRGNS_CPTL_BAL 
                 ,SUM(CASE WHEN NVL(a9.UN_TRD_NET_TOT_AST,0) > 0
				           THEN NVL(a9.UN_TRD_NET_TOT_AST,0)
						   WHEN NVL(a9.UN_TRD_NET_TOT_AST,0) < 0
				           THEN NVL(a9.UN_TRD_NET_TOT_AST,0)
					       ELSE NVL(a9.FZN_NET_TOT_AST,0)
					       END
						) as UN_TRD_NET_AST 				 
 FROM          DDW_PROD.T_DDW_F00_CUST_CUST_ATTR_LABL   t
 INNER JOIN    DDW_PROD.T_DDW_INR_ORG_BRH               a1
 ON            t.BRH_NO = a1.BRH_NO
 AND           a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY   a2
 ON            t.CUST_NO = a2.CUST_NO
 AND           a2.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY   a3
 ON            t.CUST_NO = a3.CUST_NO
 AND           a3.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_F10_AST_CUST_UN_TRD_AST_AGGR_DAY   a9
 ON            t.CUST_NO = a9.CUST_NO
 AND           a9.BUS_DATE = %d{yyyyMMdd}  
LEFT JOIN    (SELECT CUST_NO,SUM(MTCH_AMT) as NEW_T3BOD_TRD_VOL,SUM(S1-S11-S12) as NEW_T3BOD_NET_S1
                FROM  DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS 
                WHERE  BUS_DATE = %d{yyyyMMdd}
				AND   ODR_CGY IN (1,2,57,58,59,60,78,79)
				AND   EXG IN ('TA')
				AND   SUBSTR(SEC_CD,1,2) IN ('43','83','87')
				AND   SYS_SRC = '普通账户'
				GROUP BY CUST_NO
			   ) a4
 ON            t.CUST_NO = a4.CUST_NO
 
LEFT JOIN    DDW_PROD.T_DDW_F10_MRGNC_MRGNS_CUST_STATS_DAY a5
 ON            t.CUST_NO = a5.CUST_NO
 AND           a5.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     EDW_PROD.T_EDW_T99_HLZH                   a6
 ON            t.BUS_DATE = a6.BUS_DATE
 AND           a6.BUS_DATE = %d{yyyyMMdd}
 AND           a6.BZDM = 'USD'
  LEFT JOIN     EDW_PROD.T_EDW_T99_HLZH                   a7
 ON            t.BUS_DATE = a7.BUS_DATE
 AND           a7.BUS_DATE = %d{yyyyMMdd}
 AND           a7.BZDM = 'HKD'
 LEFT JOIN     DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP3 a8
 ON             t.CUST_NO = a8.CUST_NO
 WHERE         t.BUS_DATE = %d{yyyyMMdd}
 GROUP BY       t.BRH_NO
               ,t.CUST_STAR
 ;
 
 INSERT OVERWRITE DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY
(
           BELTO_FILIL_CDG               --分公司编码
          ,BELTO_FILIL                    --分公司名称
          ,BRH_NO                         --营业部编码
          ,BRH_FULLNM                     --营业部名称
          ,CUST_STAR                      --客户星级
          ,CUST_VOL                       --客户数
          ,TRD_CUST_VOL                   --交易客户客户数
          ,ADDED_VLD_CUST_VOL             --新增有效客户数
          ,ADDED_OLD_VLD_CUST_VOL         --新增存量有效客户数
          ,CRD_CUST_VOL                   --信用客户数
          ,TRD_CRD_CUST_VOL               --交易信用客户数
          ,H_K_CUST_VOL                   --港股通客户数
          ,TRD_H_K_CUST_VOL               --交易港股通客户数
          ,WRNT_CUST_VOL                  --期权客户数
          ,TRD_WRNT_CUST_VOL              --交易期权客户数
          ,STIB_CUST_VOL                  --科创板客户数
		  ,TRD_STIB_CUST_VOL              --交易科创板客户数
          ,NEW_T3BOD_CUST_VOL             --新三板客户数(受限制+非受限制)
          ,TRD_NWE_T3BOD_CUST_VOL         --交易新三板客户数
          ,T3BOD_CUST_VOL                 --三板客户数
          ,PLG_REPO_CUST_VOL              --质押回购客户数(股票质押)
          ,STK_PLG_CUST_VOL               --股票质押客户数(小微贷)
		  ,TRD_PLG_REPO_CUST_VOL          --交易质押回购客户数(股票质押)
          ,TRD_STK_PLG_CUST_VOL           --交易股票质押客户数(小微贷)
		  
		  
          ,STR_FND_CUST_VOL               --分级基金客户数
          ,PROD_CUST_VOL                  --产品客户数
          ,INR_PB_CUST_VOL                --内部PB账户数
          ,EXTN_PB_CUST_VOL               --外部PB账户数
          ,CASH_PROD_CUST_VOL             --现金添利客户数
          ,QLFD_CUST_VOL                  --合格客户数
          ,BROK_RLN_QLFD_CUST_VOL         --经纪关系合格客户数
          ,STRONG_SVC_RLN_QLFD_CUST_VOL   --强服务关系合格客户数
          ,WEAK_SVC_RLN_QLFD_CUST_VOL     --弱服务关系合格客户数
		  ,BROK_RLN_CUST_VOL              --经纪关系客户数
		  ,STRONG_SVC_RLN_CUST_VOL        --强服务关系客户数
		  ,WEAK_SVC_RLN_CUST_VOL          --弱服务关系客户数
          ,OPNAC_CUST_VOL                 --开户数(当日)
          ,OPNAC_CRD_CUST_VOL             --开户信用客户数(当日)
          ,OPNAC_WRNT_CUST_VOL            --开户期权客户数(当日)
          ,OPN_STIB_CUST_VOL              --开通科创板客户数(当日) 
          ,OPN_H_K_CUST_VOL               --开通港股通客户数(当日)		  
          ,OPN_PLG_REPO_CUST_VOL          --开通质押回购客户数(股票质押)(当日)
          ,OPN_STK_PLG_CUST_VOL           --开通股票质押客户数(小微贷)(当日)
          ,OPN_STR_FND_CUST_VOL           --开通分级基金客户数
          ,OPN_NEW_T3BOD_CUST_VOL         --开通新三板客户数(受限制当日)
          ,OPN_T3BOD_CUST_VOL             --开通三板客户数(当日)
		  ,OPNAC_INR_PB_CUST_VOL          --开户内部PB客户数(当日)
          ,CNCLACT_CUST_VOL               --销户数(当日)
          ,CNCLACT_CRD_CUST_VOL           --销户信用客户数(当日)
          ,CNCLACT_WRNT_CUST_VOL          --销户期权客户数(当日)
          ,CLS_STIB_CUST_VOL              --关闭科创板客户数(当日)
          ,CLS_H_K_CUST_VOL               --关闭港股通客户数(当日)
          ,CLS_PLG_REPO_CUST_VOL          --关闭质押回购客户数(股票质押)(当日)
          ,CLS_STK_PLG_CUST_VOL           --关闭股票质押客户数(小微贷)(当日)
          ,CLS_STR_FND_CUST_VOL           --关闭分级基金客户数
          ,CLS_NEW_T3BOD_CUST_VOL         --关闭新三板客户数(受限制当日)
          ,CLS_T3BOD_CUST_VOL             --关闭三板客户数(当日)
          ,CUST_TOT_AST                   --客户总资产
          ,CUST_NET_TOT_AST               --客户净资产
          ,BROK_RLN_CUST_NET_TOT_AST      --经纪关系净资产
          ,STRONG_SVC_CUST_NET_TOT_AST    --强服务关系净资产
          ,WEAK_SVC_CUST_NET_TOT_AST      --弱服务关系净资产
          ,NEW_OPNAC_NET_TOT_AST          --新开户净资产
          ,ADDED_VLD_NET_TOT_AST          --新增有效户净资产
          ,ADDED_OLD_VLD_NET_TOT_AST      --存量有效户净资产
          ,NET_TFR_IN_AST                 --资产净流入
          ,STK_TRD_VOL                    --股票交易量
          ,BROK_RLN_STK_TRD_VOL           --经纪关系股票交易量
          ,STRONG_SVC_STK_TRD_VOL         --强服务关系股票交易量
          ,WEAK_SVC_STK_TRD_VOL           --弱服务关系股票交易量
          ,FND_TRD_VOL                    --基金交易量
          ,BROK_RLN_FND_TRD_VOL           --经纪关系基金交易量
          ,STRONG_SVC_FND_TRD_VOL         --强服务关系基金交易量
          ,WEAK_SVC_FND_TRD_VOL           --弱服务关系基金交易量
          ,H_K_TRD_VOL                    --港股通交易量
          ,BROK_RLN_H_K_TRD_VOL           --经纪关系港股通交易量
          ,STRONG_SVC_H_K_TRD_VOL         --强服务关系港股通交易量
          ,WEAK_SVC_H_K_TRD_VOL           --弱服务关系港股通交易量
          ,NEW_T3BOD_TRD_VOL              --新三板交易量
          ,BROK_RLN_NEW_T3BOD_TRD_VOL     --经纪关系新三板交易量
          ,STRONG_SVC_NEW_T3BOD_TRD_VOL   --强服务关系新三板交易量
          ,WEAK_SVC_NEW_T3BOD_TRD_VOL     --弱服务关系新三板交易量
          ,CRD_TRD_VOL                    --融资融券交易量
		  ,BROK_RLN_CRD_TRD_VOL           --经纪关系融资融券交易量
          ,STRONG_SVC_RLN_CRD_TRD_VOL         --强服务关系融资融券交易量
          ,WEAK_SVC_RLN_CRD_TRD_VOL           --弱服务关系融资融券交易量
          ,TDY_ADDED_MRGNC_INT            --当日新增融资利息
          ,TDY_ADDED_MRGNS_INT            --当日新增融券利息
          ,STK_PLG_AMT                    --股票质押余额
          ,STK_PLG_ADD_INT                --股票质押新增利息
          ,STK_PLG_ADD_TRD_AMT            --股票质押初始交易量
          ,MIN_STK_PLG_AMT                --小微贷余额
          ,MIN_STK_PLG_ADD_INT            --小微贷新增利息
          ,MIN_STK_PLG_ADD_TRD_AMT        --小微贷初始交易量
          ,STK_NET_S1                     --股票净佣金
          ,BROK_RLN_STK_NET_S1            --经纪关系股票净佣金
          ,STRONG_SVC_STK_NET_S1          --强服务关系股票净佣金
          ,WEAK_SVC_STK_NET_S1            --弱服务关系股票净佣金
          ,FND_NET_S1                     --基金净佣金
          ,BROK_RLN_FND_NET_S1            --经纪关系基金净佣金
          ,STRONG_SVC_FND_NET_S1          --强服务关系基金净佣金
          ,WEAK_SVC_FND_NET_S1            --弱服务关系基金净佣金
          ,H_K_NET_S1                     --港股通净佣金
          ,BROK_RLN_H_K_NET_S1            --经纪关系港股通净佣金
          ,STRONG_SVC_H_K_NET_S1          --强服务关系港股通净佣金
          ,WEAK_SVC_H_K_NET_S1            --弱服务关系港股通净佣金
          ,NEW_T3BOD_NET_S1               --新三板净佣金
          ,BROK_RLN_NEW_T3BOD_NET_S1      --经纪关系新三板净佣金
          ,STRONG_SVC_NEW_T3BOD_NET_S1    --强服务关系新三板净佣金
          ,WEAK_SVC_NEW_T3BOD_NET_S1      --弱服务关系新三板净佣金
          ,CPTL_BAL                       --资金余额
          ,A_STK_MKTVAL                   --A股票市值
          ,B_STK_MKTVAL                   --B股票市值
          ,H_K_STK_MKTVAL                 --港股股票市值
          ,TRD_VOL                        --交易量
          ,NET_S1_INCM                    --净佣金收入
          ,INT_INCM                       --息费收入
          ,A_STK_NET_S1                   --A股净佣金
          ,A_STK_TRD_VOL                  --A股交易量
          ,MRGNC_CPTL_BAL                 --融资余额
          ,MRGNS_CPTL_BAL                 --融券余额
          ,UN_TRD_NET_AST                 --非交易净资产          
 ) PARTITION(BUS_DATE = %d{yyyyMMdd})
 SELECT    t.BELTO_FILIL_CDG               --分公司编码
          ,t.BELTO_FILIL                    --分公司名称
          ,t.BRH_NO                         --营业部编码
          ,t.BRH_FULLNM                     --营业部名称
          ,a1.CUST_STAR                      --客户星级
          ,NVL(a2.CUST_VOL,0)                       --客户数
          ,NVL(a2.TRD_CUST_VOL,0)                   --交易客户客户数
          ,NVL(a2.ADDED_VLD_CUST_VOL,0)             --新增有效客户数
          ,NVL(a2.ADDED_OLD_VLD_CUST_VOL,0)         --新增存量有效客户数
          ,NVL(a2.CRD_CUST_VOL,0)                   --信用客户数
          ,NVL(a2.TRD_CRD_CUST_VOL,0)               --交易信用客户数
          ,NVL(a2.H_K_CUST_VOL,0)                   --港股通客户数
          ,NVL(a2.TRD_H_K_CUST_VOL,0)               --交易港股通客户数
          ,NVL(a2.WRNT_CUST_VOL,0)                  --期权客户数
          ,NVL(a2.TRD_WRNT_CUST_VOL,0)              --交易期权客户数
          ,NVL(a2.STIB_CUST_VOL,0)                  --科创板客户数
		  ,NVL(a2.TRD_STIB_CUST_VOL,0)              --交易科创板客户数
          ,NVL(a2.NEW_T3BOD_CUST_VOL,0)             --新三板客户数(受限制+非受限制)
          ,NVL(a2.TRD_NWE_T3BOD_CUST_VOL,0)         --交易新三板客户数
          ,NVL(a2.T3BOD_CUST_VOL,0)                 --三板客户数
          ,NVL(a2.PLG_REPO_CUST_VOL,0)              --质押回购客户数(股票质押)
          ,NVL(a2.STK_PLG_CUST_VOL,0)               --股票质押客户数(小微贷)
		  ,NVL(a3.TRD_PLG_REPO_CUST_VOL,0)          --交易质押回购客户数(股票质押)
          ,NVL(a3.TRD_STK_PLG_CUST_VOL,0)           --交易股票质押客户数(小微贷)
          ,NVL(a2.STR_FND_CUST_VOL,0)               --分级基金客户数
          ,NVL(a2.PROD_CUST_VOL,0)                  --产品客户数
           ,NVL(a2.INR_PB_CUST_VOL,0) as INR_PB_CUST_VOL                --内部PB账户数
          ,0 as EXTN_PB_CUST_VOL               --外部PB账户数
          ,NVL(a2.CASH_PROD_CUST_VOL,0)             --现金添利客户数
          ,NVL(a2.QLFD_CUST_VOL,0)                  --合格客户数
          ,NVL(a2.BROK_RLN_QLFD_CUST_VOL,0)         --经纪关系合格客户数
          ,NVL(a2.STRONG_SVC_RLN_QLFD_CUST_VOL,0)   --强服务关系合格客户数
          ,NVL(a2.WEAK_SVC_RLN_QLFD_CUST_VOL,0)     --弱服务关系合格客户数
		  ,NVL(a2.BROK_RLN_CUST_VOL,0)              --经纪关系客户数
		  ,NVL(a2.STRONG_SVC_RLN_CUST_VOL,0)        --强服务关系客户数
		  ,NVL(a2.WEAK_SVC_RLN_CUST_VOL,0)          --弱服务关系客户数
          ,NVL(a2.OPNAC_CUST_VOL,0)                 --开户数(当日)
          ,NVL(a2.OPNAC_CRD_CUST_VOL,0)             --开户信用客户数(当日)
          ,NVL(a2.OPNAC_WRNT_CUST_VOL,0)            --开户期权客户数(当日)
          ,NVL(a2.OPN_STIB_CUST_VOL,0)              --开通科创板客户数(当日)
          ,NVL(a2.OPN_H_K_CUST_VOL,0)               --开通港股通客户数(当日)		  
          ,NVL(a2.OPN_PLG_REPO_CUST_VOL,0)          --开通质押回购客户数(股票质押)(当日)
          ,NVL(a2.OPN_STK_PLG_CUST_VOL,0)           --开通股票质押客户数(小微贷)(当日)
          ,NVL(a2.OPN_STR_FND_CUST_VOL,0)           --开通分级基金客户数
          ,NVL(a2.OPN_NEW_T3BOD_CUST_VOL,0)         --开通新三板客户数(受限制当日)
          ,NVL(a2.OPN_T3BOD_CUST_VOL,0)             --开通三板客户数(当日)
		  ,NVL(a2.OPNAC_INR_PB_CUST_VOL,0)          --开户内部PB客户数(当日)
          ,NVL(a2.CNCLACT_CUST_VOL,0)               --销户数(当日)
          ,NVL(a2.CNCLACT_CRD_CUST_VOL,0)           --销户信用客户数(当日)
          ,NVL(a2.CNCLACT_WRNT_CUST_VOL,0)          --销户期权客户数(当日)
          ,NVL(a2.CLS_STIB_CUST_VOL,0)              --关闭科创板客户数(当日)
          ,NVL(a2.CLS_H_K_CUST_VOL,0)               --关闭港股通客户数(当日)
          ,NVL(a2.CLS_PLG_REPO_CUST_VOL,0)          --关闭质押回购客户数(股票质押)(当日)
          ,NVL(a2.CLS_STK_PLG_CUST_VOL,0)           --关闭股票质押客户数(小微贷)(当日)
          ,NVL(a2.CLS_STR_FND_CUST_VOL,0)           --关闭分级基金客户数
          ,NVL(a2.CLS_NEW_T3BOD_CUST_VOL,0)         --关闭新三板客户数(受限制当日)
          ,NVL(a2.CLS_T3BOD_CUST_VOL,0)             --关闭三板客户数(当日)
          ,NVL(a3.CUST_TOT_AST,0)                   --客户总资产
          ,NVL(a3.CUST_NET_TOT_AST,0)               --客户净资产
          ,NVL(a3.BROK_RLN_CUST_NET_TOT_AST,0)      --经纪关系净资产
          ,NVL(a3.STRONG_SVC_CUST_NET_TOT_AST,0)    --强服务关系净资产
          ,NVL(a3.WEAK_SVC_CUST_NET_TOT_AST,0)      --弱服务关系净资产
          ,NVL(a3.NEW_OPNAC_NET_TOT_AST,0)          --新开户净资产
          ,NVL(a3.ADDED_VLD_NET_TOT_AST,0)          --新增有效户净资产
          ,NVL(a3.ADDED_OLD_VLD_NET_TOT_AST,0)      --存量有效户净资产
          ,NVL(a3.NET_TFR_IN_AST,0)                 --资产净流入
          ,NVL(a3.STK_TRD_VOL,0)                    --股票交易量
          ,NVL(a3.BROK_RLN_STK_TRD_VOL,0)           --经纪关系股票交易量
          ,NVL(a3.STRONG_SVC_STK_TRD_VOL,0)         --强服务关系股票交易量
          ,NVL(a3.WEAK_SVC_STK_TRD_VOL,0)           --弱服务关系股票交易量
          ,NVL(a3.FND_TRD_VOL,0)                    --基金交易量
          ,NVL(a3.BROK_RLN_FND_TRD_VOL,0)           --经纪关系基金交易量
          ,NVL(a3.STRONG_SVC_FND_TRD_VOL,0)         --强服务关系基金交易量
          ,NVL(a3.WEAK_SVC_FND_TRD_VOL,0)           --弱服务关系基金交易量
          ,NVL(a3.H_K_TRD_VOL,0)                    --港股通交易量
          ,NVL(a3.BROK_RLN_H_K_TRD_VOL,0)           --经纪关系港股通交易量
          ,NVL(a3.STRONG_SVC_H_K_TRD_VOL,0)         --强服务关系港股通交易量
          ,NVL(a3.WEAK_SVC_H_K_TRD_VOL,0)           --弱服务关系港股通交易量
          ,NVL(a3.NEW_T3BOD_TRD_VOL,0)              --新三板交易量
          ,NVL(a3.BROK_RLN_NEW_T3BOD_TRD_VOL,0)     --经纪关系新三板交易量
          ,NVL(a3.STRONG_SVC_NEW_T3BOD_TRD_VOL,0)   --强服务关系新三板交易量
          ,NVL(a3.WEAK_SVC_NEW_T3BOD_TRD_VOL,0)     --弱服务关系新三板交易量
          ,NVL(a3.CRD_TRD_VOL,0)                    --融资融券交易量
		  ,NVL(a3.BROK_RLN_CRD_TRD_VOL,0)           --经纪关系融资融券交易量
          ,NVL(a3.STRONG_SVC_RLN_CRD_TRD_VOL,0)         --强服务关系融资融券交易量
          ,NVL(a3.WEAK_SVC_RLN_CRD_TRD_VOL,0)           --弱服务关系融资融券交易量
          ,NVL(a3.TDY_ADDED_MRGNC_INT,0)            --当日新增融资利息
          ,NVL(a3.TDY_ADDED_MRGNS_INT,0)            --当日新增融券利息
          ,NVL(a3.STK_PLG_AMT,0)                    --股票质押余额
          ,NVL(a3.STK_PLG_ADD_INT,0)                --股票质押新增利息
          ,NVL(a3.STK_PLG_ADD_TRD_AMT,0)            --股票质押初始交易量
          ,NVL(a3.MIN_STK_PLG_AMT,0)                --小微贷余额
          ,NVL(a3.MIN_STK_PLG_ADD_INT,0)            --小微贷新增利息
          ,NVL(a3.MIN_STK_PLG_ADD_TRD_AMT,0)        --小微贷初始交易量
          ,NVL(a3.STK_NET_S1,0)                     --股票净佣金
          ,NVL(a3.BROK_RLN_STK_NET_S1,0)            --经纪关系股票净佣金
          ,NVL(a3.STRONG_SVC_STK_NET_S1,0)          --强服务关系股票净佣金
          ,NVL(a3.WEAK_SVC_STK_NET_S1,0)            --弱服务关系股票净佣金
          ,NVL(a3.FND_NET_S1,0)                     --基金净佣金
          ,NVL(a3.BROK_RLN_FND_NET_S1,0)            --经纪关系基金净佣金
          ,NVL(a3.STRONG_SVC_FND_NET_S1,0)          --强服务关系基金净佣金
          ,NVL(a3.WEAK_SVC_FND_NET_S1,0)            --弱服务关系基金净佣金
          ,NVL(a3.H_K_NET_S1,0)                     --港股通净佣金
          ,NVL(a3.BROK_RLN_H_K_NET_S1,0)            --经纪关系港股通净佣金
          ,NVL(a3.STRONG_SVC_H_K_NET_S1,0)          --强服务关系港股通净佣金
          ,NVL(a3.WEAK_SVC_H_K_NET_S1,0)            --弱服务关系港股通净佣金
          ,NVL(a3.NEW_T3BOD_NET_S1,0)               --新三板净佣金
          ,NVL(a3.BROK_RLN_NEW_T3BOD_NET_S1,0)      --经纪关系新三板净佣金
          ,NVL(a3.STRONG_SVC_NEW_T3BOD_NET_S1,0)    --强服务关系新三板净佣金
          ,NVL(a3.WEAK_SVC_NEW_T3BOD_NET_S1,0)      --弱服务关系新三板净佣金
          ,NVL(a3.CPTL_BAL,0)                       --资金余额
          ,NVL(a3.A_STK_MKTVAL,0)                   --A股票市值
          ,NVL(a3.B_STK_MKTVAL,0)                   --B股票市值
          ,NVL(a3.H_K_STK_MKTVAL,0)                 --港股股票市值
          ,NVL(a3.TRD_VOL,0)                        --交易量
          ,NVL(a3.NET_S1_INCM,0)                    --净佣金收入
          ,NVL(a3.INT_INCM,0)                       --息费收入
          ,NVL(a3.A_STK_NET_S1,0)                   --A股净佣金
          ,NVL(a3.A_STK_TRD_VOL,0)                  --A股交易量
          ,NVL(a3.MRGNC_CPTL_BAL,0)                 --融资余额
          ,NVL(a3.MRGNS_CPTL_BAL,0)                 --融券余额
		  ,NVL(a3.UN_TRD_NET_AST,0)                 --非交易净资产 
 FROM 	(SELECT 1 as ID,* 
         FROM DDW_PROD.T_DDW_INR_ORG_BRH
		 WHERE BUS_DATE = %d{yyyyMMdd}
		 )t
 LEFT JOIN  (SELECT 1 as ID, BIZ_DESC as CUST_STAR 
        FROM DDW_PROD.T_DDW_LM_LABEL_DM 
         WHERE LABEL_ID = '8d0fe69b4ff546f082775761d27c70a5'
		 )    a1
 ON  t.ID = a1.ID
LEFT JOIN DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP1 a2
ON  t.BRH_NO = a2.BRH_NO
AND a1.CUST_STAR = a2.CUST_STAR
LEFT JOIN DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP2 a3
ON  t.BRH_NO = a3.BRH_NO
AND a1.CUST_STAR = a3.CUST_STAR
 ;
 --
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP1 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP2 ;
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY_TEMP3 ;
 
 
 INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F20_STAR_BRH_CUST_IDX_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata DDW_PROD.T_DDW_F20_STAR_BRH_CUST_IDX_DAY;
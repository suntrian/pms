--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:金融产品属性统计表                                                                   */
--/* 创建人:OYJ                                                                                    */
--/* 创建时间:2018-12-26                                                                           */ 


INSERT OVERWRITE DDW_PROD.T_DDW_LM_FNCL_PROD_PUBLIC_ATTR
(
 ID                                                  --1.产品ID(PK)
,INR_CD                                              --2.产品内部代码
,PROD_CD                                             --3.产品代码
,ISOC_CD                                             --4.协会代码
,PROD_CL_CD                                          --5.产品分类
,PROD_CL_DSC                                         --6.产品分类描述
,PROD_FULLNM                                         --7.产品全称
,PROD_FULLNM_PY                                      --8.产品全称(拼音)
,PROD_SHRTNM                                         --9.产品简称
,PROD_SHRTNM_PY                                      --10.产品简称(拼音)
,PROD_RAIS_DT                                        --11.产品募集期
,PROD_CRINT_DT                                       --12.产品起息日
,PROD_ESTAB_DT                                       --13.产品成立日
,IVSM_EXPI_DT                                        --14.投资到期日
,CASHE_DT                                            --15.兑付日期
,CASHE_DT_DSC                                        --16.兑付日期描述
,RAIS_STRT_DT                                        --17.募集起始日期
,RAIS_END_DT                                         --18.募集结束日期
,PROD_ADMIN                                          --19.产品管理人
,PROD_ADMIN_PY                                       --20.产品管理人简拼
,PROD_SHR_CSTN                                       --21.产品份额托管人
,PROD_AST_CSTN                                       --22.产品资产托管人
,PROD_SALES                                          --23.产品销售人
,PROD_SCL_CD                                         --24.产品规模
,PROD_SCL_DSC                                        --25.产品规模描述
,ISSUE_SCL_CD                                        --26.发行规模
,ISSUE_SCL_DSC                                       --27.发行规模描述
,PROD_SCL_UPLMT                                      --28.产品规模上限
,SALE_NETPOT                                         --29.销售网点
,PROD_SALE_REG                                       --30.产品销售地区
,PROD_SALE_STRT_DT                                   --31.产品销售起始日期
,PROD_SALE_END_DT                                    --32.产品销售结束日期
,PROD_SUST_MKT_START_DT                              --33.产品持续营销起始日
,PROD_SUST_MKT_END_DT                                --34.产品持续营销结束日
,PROD_HLT                                            --35.产品亮点
,PROD_ASS_POLICY                                     --36.产品考核政策
,SALE_CNL_CD                                         --37.销售渠道
,EXPD_YLD_RATE                                       --38.预期收益率
,YLD_RATE                                            --39.收益率
,IF_PBLS_YLD_RATE                                    --40.是否公布收益率
,IF_HOT                                              --41.是否热销产品
,IF_KEY_SALES                                        --42.是否重点销售产品
,IVSM_DEDLN                                          --43.投资期限
,PROD_DEDLN                                          --44.产品期限
,PROD_SUBS_START_DT                                  --45.产品存续期起始日
,PROD_SUBS_END_DT                                    --46.产品存续期到期日
,YLD_TP_CD                                           --47.收益类型
,YLD_TP_DSC                                          --48.收益类型描述
,PROD_RSK_RTG_CD                                     --49.产品风险评级
,PROD_RSK_RTG_DSC                                    --50.产品风险评级描述
,PRINP_GRNT_RTO                                      --51.本金保障比例（%） 
,LINKED_RLD_CGY_CD                                   --52.挂钩标的类别 
,LINKED_RLD_CGY_NM                                   --53.挂钩标的名称 
,LINKED_RTO                                          --54.挂钩率(%) 
,LINKED_YLD_EXPLN                                    --55.挂钩收益说明 
,TRD_LOCTN                                           --56.交易场所 
,ADVBOOK_START_DT                                    --57.预售期起始日
,ADVBOOK_END_DT                                      --58.预售期结束日
,WINDG_START_DT                                      --59.清盘期起始日
,WINDG_END_DT                                        --60.清盘期结束日
,PROD_END_DT                                         --61.产品结束日
,PROD_PHS_CD                                         --62.产品阶段
,PROD_PHS_DSC                                        --63.产品阶段描述
,CCY_CD                                              --64.货币种类
,CCY_DSC                                             --65.货币种类描述
,PRCH_RDMPT_STAT                                     --66.申购赎回状态
,FIT_IVSTR_TP                                        --67.适合投资者类型
,PROD_INFO_OPN_SCP                                   --68.产品信息公开范围
,IF_PRN_SUB_PROD                                     --69.是否母子产品
,IF_PRN_PROD                                         --70.是否母产品
,CRPDG_PRN_PROD_CD                                   --71.对应母产品代码
,CRPDG_PRN_PROD_NM                                   --72.对应母产品名称
,CRPDG_PRN_PROD_SHRTNM                               --73.对应母产品简称
,PROD_DEDLN_SDX                                      --74.产品期限(适当性)
,IF_PROD_GRADE_CD                                    --75.产品是否分级
,IF_PROD_GRADE_DSC                                   --76.产品是否分级描述
,UNIT_NAV                                            --77.单位净值
,GT_NAV                                              --78.累计净值
,NAV_DT                                              --79.净值日期
,PROD_SCRP_FEE                                       --80.产品认购费
,PROD_PRCH_FEE                                       --81.产品申购费
,PROD_RDMPT_FEE                                      --82.产品赎回费
,PROD_CSTD_FEE                                       --83.产品托管费
,PROD_MGMT_FEE                                       --84.产品管理费
,EXCD_YLD_ALCT                                       --85.超额收益分成
,SALE_SVC_FEE                                        --86.销售服务费
,IDV_FSTTM_SCRP_LOW_AMT                              --87.个人首次认购最低金额
,ORG_FSTTM_SCRP_LOW_AMT                              --88.机构首次认购最低金额
,IDV_ADDI_SCRP_LOW_AMT                               --89.个人追加认购最低金额
,ORG_ADDI_SCRP_LOW_AMT                               --90.机构追加认购最低金额
,BUY_STRT_DSC                                        --91.购买起点描述
,SCRP_DLV_DT                                         --92.认购交收日期
,PRCH_STRT_DT                                        --93.申购开始日
,PRCH_END_DT                                         --94.申购结束日
,IDV_FSTTM_PRCH_LOW_AMT                              --95.个人首次申购最低金额
,ORG_FSTTM_PRCH_LOW_AMT                              --96.机构首次申购最低金额
,IDV_ADDI_PRCH_LOW_AMT                               --97.个人追加申购最低金额
,ORG_ADDI_PRCH_LOW_AMT                               --98.机构追加申购最低金额
,APLCT_UPLMT                                         --99.申购人数上限
,PRCH_DLV_DT                                         --100.申购交收日期
,RDMPT_DLV_DT                                        --101.赎回交收日期
,SUBS_OPN_STRT_DT                                    --102.存续开放起始日
,SUBS_OPN_END_DT                                     --103.存续开放结束日
,SCRP_STRT_AMT                                       --104.认购金额起点
,SNGL_HIGH_SCRP_AMT                                  --105.单笔最高认购金额
,MIN_ADDI_SCRP_UNIT                                  --106.最小追加认购单位
,IDV_ACCNT_GT_SCRP_UPLMT                             --107.个人账户累计认购上限
,ORG_ACCNT_GT_SCRP_UPLMT                             --108.机构账户累计认购上限
,IF_1TO1_DRCL                                        --109.是否一对一定向
,DRCL_OBJ                                            --110.定向对象
,SCRP_CNL                                            --111.认购渠道 
,IF_QOT_ISSUE                                        --112.是否配额发行
,RESV_SCRP_OBJ                                       --113.预留认购对象
,RESV_SCRP_PSN_QTY                                   --114.预留认购人数（人）
,RESV_SCRP_QUO                                       --115.预留认购额度（元）
,RESV_QOT_HIGH_RTO                                   --116.预留名额最高比例（%）
,RESV_AMT_HIGH_RTO                                   --117.预留金额最高比例（%）
,RESV_QOT_RTO                                        --118.预留名额比例（%）
,RESV_AMT_RTO                                        --119.预留金额比例（%）
,BELTO_TA                                            --120.所属TA
,TA_CD                                               --121.TA代码 
,ISSUE_PLCG_MOD                                      --122.发行配售方式 
,IF_EXCD_SCRP_PART_CNFM                              --123.超额认购是否部分确认 
,SCRP_DURPRD_INT_DEAL_MOD                            --124.认购期利息处理方式 
,SCRP_DURPRD_INT_RATE                                --125.认购期间利率（%） 
,SCRP_DURPRD_CINT_END_DT                             --126.认购期利息计息截止日期 
,SCRP_INT_RETURN_DT                                  --127.认购利息退还日 
,IF_CINT_CTNFEE                                      --128.利息计算是否含费 
,IF_FSTTM_IVSM_CTNFEE                                --129.首次投资是否含费 
,IF_ADDI_IVSM_CTNFEE                                 --130.追加投资是否含费 
,FEE_RATE_CLC_MOD                                    --131.费率计算方式 
,SCRP_FEE_CLC_MOD                                    --132.认购费用计算方式 
,SHR_CGY                                             --133.份额类别 
,SCRP_ACPTD_CPTL_DLV_DT                              --134.认购受理资金交收日(确认日+) 
,SCRP_RSLT_CPTL_DLV_DT                               --135.认购结果资金交收日(确认日+) 
,RAIS_FAIL_CPTL_DLV_DT                               --136.募集失败资金交收日(确认日+) 
,INT_BNS_CPTL_DLV_DT                                 --137.分红（付息）资金交收日（确认日+） 
,EXPI_CPTL_DLV_DT                                    --138.到期资金交收日(确认日+) 
,DLV_BTCH                                            --139.交收批次
,IF_FIXINV_FND                                       --140.是否定投基金
,FIXINV_STAT                                         --141.定投状态
,FIXINV_STRT                                         --142.定投起点
,FIXINV_INCRM                                        --143.定投递增金额
,ESP_FEE_RATE                                        --144.特别费率优惠
,HLD_SHR_LOW                                         --145.最低持有份额
)
PARTITION( bus_date = %d{yyyyMMdd})
SELECT
       CAST(T1.ID AS STRING) AS ID                                                                       --1.产品ID(PK)
	  ,CASE WHEN NVL(T1.NBDM,'') <> '' THEN T1.NBDM ELSE NVL(T8.INR_CD,T7.CPNBDM) END AS INR_CD          --2.产品内部代码
	  ,T1.CPDM AS PROD_CD                                                                                --3.产品代码
      ,T1.XHDM AS ISOC_CD                                                                                --4.协会代码
	  ,T1.CPFL AS PROD_CL_CD                                                                             --5.产品分类
	  ,T1.CPFLMS AS PROD_CL_DSC                                                                          --6.产品分类描述
	  ,T1.CPQC AS PROD_FULLNM                                                                            --7.产品全称
	  ,T1.CPQP AS PROD_FULLNM_PY                                                                         --8.产品全称(拼音)
	  ,T1.CPMC AS PROD_SHRTNM                                                                            --9.产品简称
	  ,T1.CPJP AS PROD_SHRTNM_PY                                                                         --10.产品简称(拼音)
	  ,CAST(T1.CPMJQ AS STRING) AS PROD_RAIS_DT                                                          --11.产品募集期
	  ,NVL(T2.CPQXR,T1.CPQXR) AS PROD_CRINT_DT                                                           --12.产品起息日
      ,T1.CPCLR AS PROD_ESTAB_DT                                                                         --13.产品成立日
      ,NVL(T2.CPDQR,T1.TZDQR) AS IVSM_EXPI_DT                                                            --14.投资到期日
      ,NVL(T2.CPDFR,T1.CPDFR) AS CASHE_DT                                                                --15.兑付日期
      ,T1.DFRQMS AS CASHE_DT_DSC                                                                         --16.兑付日期描述
      ,T1.MJQSR AS RAIS_STRT_DT                                                                          --17.募集起始日期
      ,T1.MJJSR AS RAIS_END_DT                                                                           --18.募集结束日期
      ,CAST(T1.CPGLR AS STRING) AS PROD_ADMIN                                                            --19.产品管理人
      ,T1.CPGLRJP AS PROD_ADMIN_PY                                                                       --20.产品管理人简拼
      ,CAST(T1.CPFETGR AS STRING) AS PROD_SHR_CSTN                                                       --21.产品份额托管人
      ,CAST(T1.CPZCTGR AS STRING) AS PROD_AST_CSTN                                                       --22.产品资产托管人
      ,CAST(T1.CPXSR AS STRING) AS PROD_SALES                                                            --23.产品销售人
      ,T1.CPGM AS PROD_SCL_CD                                                                            --24.产品规模
      ,T1.CPGMMS AS PROD_SCL_DSC                                                                         --25.产品规模描述
      ,COALESCE(CAST(T3.FXZFE AS STRING),CAST(T2.FXZFE AS STRING),CAST(T1.FXGM AS STRING)) AS ISSUE_SCL_CD                                 --26.发行规模
      ,T1.FXGMMS AS ISSUE_SCL_DSC                                                                        --27.发行规模描述
      ,T1.CPGMSX AS PROD_SCL_UPLMT                                                                       --28.产品规模上限
      ,T1.XSWD AS SALE_NETPOT                                                                            --29.销售网点
      ,T1.XSDQ AS PROD_SALE_REG                                                                          --30.产品销售地区
      ,T1.XSQSR AS PROD_SALE_STRT_DT                                                                     --31.产品销售起始日期
      ,T1.XSJSR AS PROD_SALE_END_DT                                                                      --32.产品销售结束日期
      ,T1.CXYXQSR AS PROD_SUST_MKT_START_DT                                                              --33.产品持续营销起始日
      ,T1.CXYXJSR AS PROD_SUST_MKT_END_DT                                                                --34.产品持续营销结束日
      ,T1.CPLD AS PROD_HLT                                                                               --35.产品亮点
      ,T1.CPKHZC AS PROD_ASS_POLICY                                                                      --36.产品考核政策
      ,CAST(T1.XSQD AS STRING) AS SALE_CNL_CD                                                            --37.销售渠道
      ,T1.YQSYL AS EXPD_YLD_RATE                                                                         --38.预期收益率
      ,NVL(T3.NSYL,T1.SYL) AS YLD_RATE                                                                   --39.收益率
      ,CAST(T1.SFGBSYL AS STRING) AS IF_PBLS_YLD_RATE                                                    --40.是否公布收益率
      ,CAST(T1.SFRXCP AS STRING) AS IF_HOT                                                               --41.是否热销产品
      ,CAST(T1.SFZDXS AS STRING) AS IF_KEY_SALES                                                         --42.是否重点销售产品
      ,NVL(CAST(T2.TZQX AS STRING),CAST(T1.TZQX_R AS STRING)) AS IVSM_DEDLN                              --43.投资期限
      ,CAST(T1.CPQX_R AS STRING) AS PROD_DEDLN                                                           --44.产品期限
      ,T1.CPCXQSR AS PROD_SUBS_START_DT                                                                  --45.产品存续期起始日
      ,NVL(T2.CPDQR,T1.CPCXDQR) AS PROD_SUBS_END_DT                                                      --46.产品存续期到期日
      ,CAST(T1.SYLX AS STRING) AS YLD_TP_CD                                                              --47.收益类型
      ,T1.SYLXMS AS YLD_TP_DSC                                                                           --48.收益类型描述
      ,COALESCE(CAST(T3.JJFXDJ AS STRING),CAST(T2.JRCP_CPFXDJ AS STRING),CAST(T1.CPFXDJ AS STRING)) AS PROD_RSK_RTG_CD                                        --49.产品风险评级
      ,T1.CPFXDJMS AS PROD_RSK_RTG_DSC                                                                   --50.产品风险评级描述
      ,T1.BJBZBL AS PRINP_GRNT_RTO                                                                       --51.本金保障比例（%） 
      ,CAST(T1.GGBDLB AS STRING) AS LINKED_RLD_CGY_CD                                                    --52.挂钩标的类别 
      ,T1.GGBDMC AS LINKED_RLD_CGY_NM                                                                    --53.挂钩标的名称 
      ,T1.GGL AS LINKED_RTO                                                                              --54.挂钩率(%) 
      ,T1.GGSYSM AS LINKED_YLD_EXPLN                                                                     --55.挂钩收益说明 
      ,T1.JYCS AS TRD_LOCTN                                                                              --56.交易场所 
      ,T1.YSQQSR AS ADVBOOK_START_DT                                                                     --57.预售期起始日
      ,T1.YSQJSR AS ADVBOOK_END_DT                                                                       --58.预售期结束日
      ,T1.QPQQSR AS WINDG_START_DT                                                                       --59.清盘期起始日
      ,T1.QPQJSR AS WINDG_END_DT                                                                         --60.清盘期结束日
      ,T1.CPJSR AS PROD_END_DT                                                                           --61.产品结束日
      ,CASE WHEN T1.YSQQSR <= %d{yyyyMMdd} AND T1.YSQJSR > %d{yyyyMMdd}
	        THEN '1'
			WHEN T1.MJQSR <= %d{yyyyMMdd} AND T1.MJJSR > %d{yyyyMMdd}
			THEN '2'
			WHEN T1.CPCLR <= %d{yyyyMMdd} AND T1.QPQQSR > %d{yyyyMMdd}
			THEN '3'
			WHEN T1.QPQQSR <= %d{yyyyMMdd} AND T1.QPQJSR > %d{yyyyMMdd}
			THEN '4'
			WHEN T1.CPJSR <= %d{yyyyMMdd}
			THEN '5'
	   END AS PROD_PHS_CD                                                                                --62.产品阶段
      ,CASE WHEN T1.YSQQSR <= %d{yyyyMMdd} AND T1.YSQJSR > %d{yyyyMMdd}
	        THEN '预售期'
			WHEN T1.MJQSR <= %d{yyyyMMdd} AND T1.MJJSR > %d{yyyyMMdd}
			THEN '募集期'
			WHEN T1.CPCLR <= %d{yyyyMMdd} AND T1.QPQQSR > %d{yyyyMMdd}
			THEN '存续期'
			WHEN T1.QPQQSR <= %d{yyyyMMdd} AND T1.QPQJSR > %d{yyyyMMdd}
			THEN '清盘期'
			WHEN T1.CPJSR <= %d{yyyyMMdd}
			THEN '结束期'
	   END AS PROD_PHS_DSC                                                                               --63.产品阶段描述
      ,COALESCE(T3.JSBZDM,T2.BZDM,CAST(T1.HBZL AS STRING))CCY_CD                                         --64.货币种类
      ,T1.HBZLMS AS CCY_DSC                                                                              --65.货币种类描述
      ,CAST(T1.SGSHZT AS STRING) AS PRCH_RDMPT_STAT                                                      --66.申购赎回状态
      ,CAST(T1.SHTZZLX AS STRING) AS FIT_IVSTR_TP                                                        --67.适合投资者类型
      ,CAST(T1.CPXXGKFW AS STRING) AS PROD_INFO_OPN_SCP                                                  --68.产品信息公开范围
      ,CAST(T1.SFMZCP AS STRING) AS IF_PRN_SUB_PROD                                                      --69.是否母子产品
      ,CAST(T1.SFMCP AS STRING) AS IF_PRN_PROD                                                           --70.是否母产品
      ,T1.DYMCPDM AS CRPDG_PRN_PROD_CD                                                                   --71.对应母产品代码
      ,T1.DYMCPMC AS CRPDG_PRN_PROD_NM                                                                   --72.对应母产品名称
      ,T1.DYMCPJC AS CRPDG_PRN_PROD_SHRTNM                                                               --73.对应母产品简称
      ,COALESCE(CAST(T3.TZQX AS STRING),CAST(T1.CPQX_SDX AS STRING)) AS PROD_DEDLN_SDX                   --74.产品期限(适当性)
      ,CAST(T1.CPSFFJ AS STRING) AS IF_PROD_GRADE_CD                                                     --75.产品是否分级
      ,T1.CPSFFJMS AS IF_PROD_GRADE_DSC                                                                  --76.产品是否分级描述
      ,COALESCE(T3.JJJZ,T2.CPJZ,T1.CPJZ) AS UNIT_NAV                                                    --77.单位净值
      ,NVL(T3.LJJZ,T1.LJJZ) AS GT_NAV                                                                    --78.累计净值
      ,%d{yyyyMMdd} AS NAV_DT                                                                            --79.净值日期
      ,T4.CPRGF AS PROD_SCRP_FEE                                                                         --80.产品认购费
      ,T4.CPSGF AS PROD_PRCH_FEE                                                                         --81.产品申购费
      ,T4.CPSHF AS PROD_RDMPT_FEE                                                                        --82.产品赎回费
      ,T4.CPTGF AS PROD_CSTD_FEE                                                                         --83.产品托管费
      ,T4.CPGLF AS PROD_MGMT_FEE                                                                         --84.产品管理费
      ,T4.CESYFC AS EXCD_YLD_ALCT                                                                        --85.超额收益分成
      ,T4.XSFWF AS SALE_SVC_FEE                                                                          --86.销售服务费
      ,COALESCE(T3.GRSCRGZDZJ,T2.RGZDZJ,T4.GRSCRGZDJE) AS IDV_FSTTM_SCRP_LOW_AMT                         --87.个人首次认购最低金额
      ,COALESCE(T3.JGSCRGZDZJ,T2.RGZDZJ_JG,T4.JGSCRGZDJE) AS ORG_FSTTM_SCRP_LOW_AMT                      --88.机构首次认购最低金额
      ,COALESCE(T3.GRZJRGZDZJ,T2.RGDZZJ,T4.GRZJRGZDJE) AS IDV_ADDI_SCRP_LOW_AMT                          --89.个人追加认购最低金额
      ,COALESCE(T3.JGZJRGZDZJ,T2.RGDZZJ_JG,T4.JGZJRGZDJE) AS ORG_ADDI_SCRP_LOW_AMT                       --90.机构追加认购最低金额
      ,CAST(T4.GMQDMS AS STRING) AS BUY_STRT_DSC                                                         --91.购买起点描述
      ,CAST(T4.RGJSR AS STRING) AS SCRP_DLV_DT                                                           --92.认购交收日期
      ,T4.SGKSR AS PRCH_STRT_DT                                                                          --93.申购开始日
      ,T4.SGJSR AS PRCH_END_DT                                                                           --94.申购结束日
      ,COALESCE(T3.GRSCSGZDZJ,T2.SGZDZJ,T4.GRSCSGZDJE) AS IDV_FSTTM_PRCH_LOW_AMT                         --95.个人首次申购最低金额
      ,COALESCE(T3.JGSCSGZDZJ,T2.SGZDZJ_JG,T4.JGSCSGZDJE) AS ORG_FSTTM_PRCH_LOW_AMT                      --96.机构首次申购最低金额
      ,COALESCE(T3.GRZJSGZDZJ,T2.SGDZZJ,T4.GRZJSGZDJE) AS IDV_ADDI_PRCH_LOW_AMT                          --97.个人追加申购最低金额
      ,COALESCE(T3.JGZJSGZDZJ,T2.SGDZZJ_JG,T4.JGZJSGZDJE) AS ORG_ADDI_PRCH_LOW_AMT                       --98.机构追加申购最低金额
      ,T4.SGRSSX AS APLCT_UPLMT                                                                          --99.申购人数上限
      ,T4.SGJSRQ AS PRCH_DLV_DT                                                                          --100.申购交收日期
      ,T4.SHJSRQ AS RDMPT_DLV_DT                                                                         --101.赎回交收日期
      ,T4.CXKFQSR AS SUBS_OPN_STRT_DT                                                                    --102.存续开放起始日
      ,T4.CXKFJSR AS SUBS_OPN_END_DT                                                                     --103.存续开放结束日
      ,CAST(T5.RGJEQD AS STRING) AS SCRP_STRT_AMT                                                        --104.认购金额起点
      ,CAST(T5.DBZGRGJE AS STRING) AS SNGL_HIGH_SCRP_AMT                                                 --105.单笔最高认购金额
      ,CAST(T5.ZXZJRGDW AS STRING) AS MIN_ADDI_SCRP_UNIT                                                 --106.最小追加认购单位
      ,CAST(T5.GRZHLJRGSX AS STRING) AS IDV_ACCNT_GT_SCRP_UPLMT                                          --107.个人账户累计认购上限
      ,CAST(T5.JGZHLJRGSX AS STRING) AS ORG_ACCNT_GT_SCRP_UPLMT                                          --108.机构账户累计认购上限
      ,CAST(T5.SFYDYDX AS STRING) AS IF_1TO1_DRCL                                                        --109.是否一对一定向
      ,T5.DXDX AS DRCL_OBJ                                                                               --110.定向对象
      ,CAST(T5.RGQD AS STRING) AS SCRP_CNL                                                               --111.认购渠道 
      ,CAST(T5.SFPEFX AS STRING) AS IF_QOT_ISSUE                                                         --112.是否配额发行
      ,T5.YLRGDX AS RESV_SCRP_OBJ                                                                        --113.预留认购对象
      ,T5.YLRGRS AS RESV_SCRP_PSN_QTY                                                                    --114.预留认购人数（人）
      ,T5.YLRGED AS RESV_SCRP_QUO                                                                        --115.预留认购额度（元）
      ,T5.YLMEZGBL AS RESV_QOT_HIGH_RTO                                                                  --116.预留名额最高比例（%）
      ,T5.YLJEZGBL AS RESV_AMT_HIGH_RTO                                                                  --117.预留金额最高比例（%）
      ,T5.YLMEBL AS ESV_QOT_RTO                                                                          --118.预留名额比例（%）
      ,T5.YLJEBL AS RESV_AMT_RTO                                                                         --119.预留金额比例（%）
      ,CAST(T5.SSTA AS STRING) AS BELTO_TA                                                               --120.所属TA
      ,T5.TADM AS TA_CD                                                                                  --121.TA代码 
      ,CAST(T5.FXPSFS AS STRING) AS ISSUE_PLCG_MOD                                                       --122.发行配售方式 
      ,CAST(T5.CERGSFBFQR AS STRING) AS IF_EXCD_SCRP_PART_CNFM                                           --123.超额认购是否部分确认 
      ,CAST(T5.RGQLXCLFS AS STRING) AS SCRP_DURPRD_INT_DEAL_MOD                                          --124.认购期利息处理方式 
      ,T5.RGQJLL AS SCRP_DURPRD_INT_RATE                                                                 --125.认购期间利率（%） 
      ,T5.RGQLXJXJZR AS SCRP_DURPRD_CINT_END_DT                                                          --126.认购期利息计息截止日期 
      ,T5.RGQLXTHR AS SCRP_INT_RETURN_DT                                                                 --127.认购利息退还日 
      ,CAST(T5.LXJSSFHF AS STRING) AS IF_CINT_CTNFEE                                                     --128.利息计算是否含费 
      ,CAST(T5.SCTZSFHF AS STRING) AS IF_FSTTM_IVSM_CTNFEE                                               --129.首次投资是否含费 
      ,CAST(T5.ZJTZSFHF AS STRING) AS IF_ADDI_IVSM_CTNFEE                                                --130.追加投资是否含费 
      ,CAST(T5.FLJSFS AS STRING) AS FEE_RATE_CLC_MOD                                                     --131.费率计算方式 
      ,CAST(T5.RGFYJSFS AS STRING) AS SCRP_FEE_CLC_MOD                                                   --132.认购费用计算方式 
      ,T5.FELB AS SHR_CGY                                                                                --133.份额类别 
      ,CAST(T5.RGSLZJJSR AS STRING) AS SCRP_ACPTD_CPTL_DLV_DT                                            --134.认购受理资金交收日(确认日+) 
      ,CAST(T5.RGJGZIJSR AS STRING) AS SCRP_RSLT_CPTL_DLV_DT                                             --135.认购结果资金交收日(确认日+) 
      ,CAST(T5.MJSBZJJSR AS STRING) AS RAIS_FAIL_CPTL_DLV_DT                                             --136.募集失败资金交收日(确认日+) 
      ,CAST(T5.FHZJJSR AS STRING) AS INT_BNS_CPTL_DLV_DT                                                 --137.分红（付息）资金交收日（确认日+） 
      ,CAST(T5.DQZJJSR AS STRING) AS EXPI_CPTL_DLV_DT                                                    --138.到期资金交收日(确认日+) 
      ,CAST(T5.JSPC AS STRING) AS DLV_BTCH                                                               --139.交收批次
      ,CASE WHEN T6.TADM IS NOT NULL THEN '是' ELSE '否' END AS IF_FIXINV_FND                            --140.是否定投基金
      ,T3.OF_JJZT_DT AS FIXINV_STAT                                                                      --141.定投状态
      ,T6.ZDSGJE AS FIXINV_STRT                                                                          --142.定投起点
      ,T6.SGJEJS AS FIXINV_INCRM                                                                         --143.定投递增金额
      ,'' AS ESP_FEE_RATE                                                                                --144.特别费率优惠
      ,T3.GRCCZDFE AS HLD_SHR_LOW                                                                        --145.最低持有份额
FROM EDW_PROD.T_EDW_T04_C5_TSPIF_CPDM T1
LEFT JOIN EDW_PROD.T_EDW_T99_TJRCP_CPDM T2
ON T1.CPDM = T2.CPDM
AND T2.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN EDW_PROD.T_EDW_T04_TOF_JJXX T3
ON T1.CPDM = T3.JJDM
AND T3.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN EDW_PROD.T_EDW_T04_C5_TSPIF_CPDM_PT_JZJY T4
ON T1.ID = T4.CPID
AND T4.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN EDW_PROD.T_EDW_T04_C5_TSPIF_CPDM_PT_OTC T5
ON T1.ID = T5.CPID
AND T5.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN EDW_PROD.T_EDW_T04_TOF_DQDESGPZ T6
ON T3.TADM = T6.TADM
AND T6.BUS_DATE = %d{yyyyMMdd}
LEFT JOIN
(
SELECT CPDM,CPFL
      ,CASE WHEN SUBSTR(T.CPFL,1,2) = '01' THEN CONCAT('GMJJ','000',CAST(T.NUM + NVL(T1.MAX_NUM,0) AS STRING))
            WHEN SUBSTR(T.CPFL,1,2) = '02' THEN CONCAT('SMJJ','000',CAST(T.NUM + NVL(T1.MAX_NUM,0) AS STRING))
            WHEN SUBSTR(T.CPFL,1,2) = '03' THEN CONCAT('XTCP','000',CAST(T.NUM + NVL(T1.MAX_NUM,0) AS STRING))
            WHEN SUBSTR(T.CPFL,1,2) = '04' THEN CONCAT('ZGNB','000',CAST(T.NUM + NVL(T1.MAX_NUM,0) AS STRING))
            WHEN SUBSTR(T.CPFL,1,2) = '05' THEN CONCAT('YHLC','000',CAST(T.NUM + NVL(T1.MAX_NUM,0) AS STRING))
            WHEN SUBSTR(T.CPFL,1,2) = '06' THEN CONCAT('SYPZ','000',CAST(T.NUM + NVL(T1.MAX_NUM,0) AS STRING))
            WHEN SUBSTR(T.CPFL,1,2) = '07' THEN CONCAT('ZGWB','000',CAST(T.NUM + NVL(T1.MAX_NUM,0) AS STRING))
            WHEN SUBSTR(T.CPFL,1,2) = '08' THEN CONCAT('JJZH','000',CAST(T.NUM + NVL(T1.MAX_NUM,0) AS STRING))
       ELSE CONCAT('QTCP','000',CAST(T.NUM + NVL(T1.MAX_NUM,0) AS STRING)) END AS CPNBDM
FROM
(
  select CPDM,CPFL,ROW_NUMBER() OVER(PARTITION BY SUBSTR(CPFL,1,2) ORDER BY CPDM ASC) AS NUM
  from 
  (
    SELECT DISTINCT A.CPDM,A.CPFL
    FROM EDW_PROD.T_EDW_T04_C5_TSPIF_CPDM A
    LEFT JOIN 
    (
      SELECT DISTINCT PROD_CD,PROD_CL_CD
      FROM DDW_PROD.T_DDW_LM_FNCL_PROD_PUBLIC_ATTR
      WHERE BUS_DATE = (SELECT MAX(BUS_DATE) FROM DDW_PROD.T_DDW_LM_FNCL_PROD_PUBLIC_ATTR)
      AND LENGTH (INR_CD) > 7
    ) B
    ON A.CPDM = B.PROD_CD
    AND A.CPFL = B.PROD_CL_CD
    WHERE A.BUS_DATE  = %d{yyyyMMdd}
    AND B.PROD_CD IS NULL
  ) C
) T
LEFT JOIN 
(
  SELECT 
         SUBSTR(PROD_CL_CD,1,2) AS PROD_MCGY
	    ,MAX(CAST(SUBSTR(INR_CD,5) AS INT)) AS MAX_NUM
  FROM DDW_PROD.T_DDW_LM_FNCL_PROD_PUBLIC_ATTR
  WHERE BUS_DATE = (SELECT MAX(BUS_DATE) FROM DDW_PROD.T_DDW_LM_FNCL_PROD_PUBLIC_ATTR)
  GROUP BY SUBSTR(PROD_CL_CD,1,2)
) T1
ON SUBSTR(T.CPFL,1,2) = T1.PROD_MCGY
) T7
ON T1.CPDM = T7.CPDM
AND T1.CPFL = T7.CPFL
LEFT JOIN 
(
  SELECT PROD_CD,PROD_CL_CD,MAX(INR_CD) AS INR_CD
  FROM DDW_PROD.T_DDW_LM_FNCL_PROD_PUBLIC_ATTR
  WHERE BUS_DATE = (SELECT MAX(BUS_DATE) FROM DDW_PROD.T_DDW_LM_FNCL_PROD_PUBLIC_ATTR)
  AND LENGTH (INR_CD) > 7
  GROUP BY PROD_CD,PROD_CL_CD
) T8
ON T1.CPDM = T8.PROD_CD
AND T1.CPFL = T8.PROD_CL_CD
WHERE T1.BUS_DATE = %d{yyyyMMdd}
;


INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_LM_FNCL_PROD_PUBLIC_ATTR',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss'))
;
invalidate metadata DDW_PROD.T_DDW_LM_FNCL_PROD_PUBLIC_ATTR;
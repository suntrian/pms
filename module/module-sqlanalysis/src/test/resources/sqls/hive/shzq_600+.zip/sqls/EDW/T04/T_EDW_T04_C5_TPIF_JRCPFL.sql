 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:金融产品分类表                                                                      */
  --/* 创建人:常静静                                                                                */
  --/* 创建时间:2018-12-27                                                                          */ 
  
-----------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T04_C5_TPIF_JRCPFL(
                     ID        
                    ,FID
                    ,GRADE
                    ,TYPE
                    ,FLBM
                    ,NAME
                    ,FDNCODE
                    ,XSPX
                    ,ZT
                    ,BZ
                    ,CPFL
                    ,CPLX
                    ,LBZSSX
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                     t.ID        
                    ,t.FID
                    ,t.GRADE
                    ,t.TYPE
                    ,t.FLBM
                    ,t.NAME
                    ,t.FDNCODE
                    ,t.XSPX
                    ,t.ZT
                    ,t.BZ
                    ,t.CPFL
                    ,t.CPLX
                    ,t.LBZSSX  			   
 FROM       C5CX.SPIF_TPIF_JRCPFL    t
 WHERE      t.DT = '%d{yyyyMMdd}';
----插入数据结束--------------
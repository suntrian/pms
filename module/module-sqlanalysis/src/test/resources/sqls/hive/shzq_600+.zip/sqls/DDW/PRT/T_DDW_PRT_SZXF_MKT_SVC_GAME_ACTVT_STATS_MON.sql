------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能: 上证先锋—2019年“争先创优”营销服务竞赛活动统计月表                                                                 */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 

DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP_%d{yyyyMMdd};
CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP_%d{yyyyMMdd} as
SELECT t.BRH_NO
       ,SUM(DECODE(IDX_CDG,'OPNAC_QLFD_CUST_VOL',IDX_VAL,0)) as OPNAC_QLFD_CUST_VOL
	   ,SUM(DECODE(IDX_CDG,'TISSU_GT_OPNAC_QLFD_CUST_VOL',IDX_VAL,0)) as TISSU_GT_OPNAC_QLFD_CUST_VOL
	   ,SUM(DECODE(IDX_CDG,'TADDED_VLD_CUST_VOL',IDX_VAL,0)) as TADDED_VLD_CUST_VOL
	   ,SUM(DECODE(IDX_CDG,'TISSU_GT_TADDED_VLD_CUST_VOL',IDX_VAL,0)) as TISSU_GT_TADDED_VLD_CUST_VOL
	   ,SUM(DECODE(IDX_CDG,'OPN_H_K_PRVL_CUST_VOL',IDX_VAL,0)) as OPN_H_K_PRVL_CUST_VOL
	   ,SUM(DECODE(IDX_CDG,'TISSU_GT_OPN_H_K_PRVL_CUST_VOL',IDX_VAL,0)) as TISSU_GT_OPN_H_K_PRVL_CUST_VOL
	   ,SUM(DECODE(IDX_CDG,'OPNAC_CRD_CUST_VOL',IDX_VAL,0)) as OPNAC_CRD_CUST_VOL
	   ,SUM(DECODE(IDX_CDG,'TISSU_GT_OPNAC_CRD_CUST_VOL',IDX_VAL,0)) as TISSU_GT_OPNAC_CRD_CUST_VOL
	   ,SUM(DECODE(IDX_CDG,'OPNAC_WRNT_CUST_VOL',IDX_VAL,0)) as OPNAC_WRNT_CUST_VOL
	   ,SUM(DECODE(IDX_CDG,'TISSU_GT_OPNAC_WRNT_CUST_VOL',IDX_VAL,0)) as TISSU_GT_OPNAC_WRNT_CUST_VOL
	   ,SUM(DECODE(IDX_CDG,'OPN_STIB_PRVL_CUST_VOL',IDX_VAL,0)) as OPN_STIB_PRVL_CUST_VOL 
	    ,SUM(DECODE(IDX_CDG,'TISSU_GT_OPN_STIB_PRVL_CUST_VOL',IDX_VAL,0)) as TISSU_GT_OPN_STIB_PRVL_CUST_VOL 
	   
	      
FROM DDW_PROD.T_DDW_F20_BRH_CUST_VOL_IDX_MON t
WHERE CUST_CGY = '3'
AND IDX_CDG IN ('OPNAC_QLFD_CUST_VOL','TISSU_GT_OPNAC_QLFD_CUST_VOL'
,'TADDED_VLD_CUST_VOL'
,'TISSU_GT_TADDED_VLD_CUST_VOL'
,'OPN_H_K_PRVL_CUST_VOL'        
,'TISSU_GT_OPN_H_K_PRVL_CUST_VOL'
,'OPNAC_CRD_CUST_VOL'            
,'TISSU_GT_OPNAC_CRD_CUST_VOL'   
,'OPNAC_WRNT_CUST_VOL'           
,'TISSU_GT_OPNAC_WRNT_CUST_VOL'  
,'OPN_STIB_PRVL_CUST_VOL'
,'TISSU_GT_OPN_STIB_PRVL_CUST_VOL'
)
and t.year_mon = casT(substr('%d{yyyyMMdd}',1,6) AS int)
group by t.brh_no
 ;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP1_%d{yyyyMMdd};
CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP1_%d{yyyyMMdd} as
SELECT t.CUST_NO
FROM 
(SELECT KHH as CUST_NO  FROM newcrm.DSC_STAT_T_STAT_KHZC_R
WHERE DT BETWEEN '20160101' AND '20161231'
AND  ZZC > 0 
UNION 
SELECT CUST_NO
FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY
WHERE BUS_DATE BETWEEN 20170101 AND 20181231
AND   TOT_AST > 0
)   t
GROUP BY t.CUST_NO ;
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP2_%d{yyyyMMdd};
 CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP2_%d{yyyyMMdd} as
 SELECT       t.BRH_NO              
             ,t.CUST_NO
			 ,CASE WHEN t.CUST_RSK_LVL IN ('0','1','2','8','19')
			       THEN '合格客户'
				   ELSE '-'
				   END  as IF_QLFD
			 ,NVL(MIN_BUS_DATE,99999999) as MIN_BUS_DATE
			 ,NVL(MIN_BUS_DATE_50,99999999) as MIN_BUS_DATE_50
             ,NVL(a2.FNL_AST,0) as FNL_AST
             ,NVL(a3.NET_TOT_AST,0)  as STRT_AST
             ,NVL(a4.NET_TOT_AST,0)  as LAST_Y_FNL_AST	
             ,CASE WHEN a5.CUST_NO IS NULL
			       AND NVL(t.ORDI_OPNAC_DT,99999999) BETWEEN 20160101 AND 20181231
                   THEN '存量客户'
                   ELSE '-'
                   END  as IF_CLKH
             ,NVL(t.ORDI_OPNAC_DT,99999999)	 as ORDI_OPNAC_DT			   
 FROM          DDW_PROD.T_DDW_F00_CUST_CUST_INFO    t
 INNER JOIN    DDW_PROD.T_DDW_INR_ORG_BRH           a1
 ON            t.BRH_NO = a1.BRH_NO
 AND           a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN    (SELECT CUST_NO
                     ,MIN(CASE WHEN NET_TOT_AST > = 1000
					           THEN BUS_DATE 
						       ELSE 99999999
						       END
						 ) as MIN_BUS_DATE
					 ,MIN(CASE WHEN NET_TOT_AST > = 500000
					           THEN BUS_DATE 
						       ELSE 99999999
						       END
						 ) as MIN_BUS_DATE_50
                     ,SUM(DECODE(BUS_DATE,%d{yyyyMMdd},NET_TOT_AST,0)) FNL_AST
               FROM   DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY 
               WHERE  SUBSTR(CAST(BUS_DATE as STRING),1,4) = SUBSTR('%d{yyyyMMdd}',1,4)	
               AND   BUS_DATE < = 	%d{yyyyMMdd}		   
			   GROUP BY CUST_NO 
			  )                                 a2
 ON         t.CUST_NO = a2.CUST_NO
 LEFT JOIN ( SELECT CUST_NO,NET_TOT_AST,a.BUS_DATE
             FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY a
             WHERE  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                                    FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                       WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
			                       AND BUS_DATE = %d{yyyyMMdd}
				                   )  b
                     WHERE  a.BUS_DATE = b.MON_START
				      )
	    AND  SUBSTR(CAST(a.BUS_DATE as STRING),1,6) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',0,-1,0),1,6)
	  )     a3
 ON          t.CUST_NO = a3.CUST_NO
  LEFT JOIN ( SELECT CUST_NO,NET_TOT_AST,a.BUS_DATE
             FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY a
             WHERE  EXISTS(SELECT 1 FROM (SELECT MAX(TRD_DT) as MON_START 
                                    FROM   EDW_PROD.T_EDW_T99_TRD_DATE 
			                       WHERE   SUBSTR(CAST(TRD_DT as STRING) ,1,4) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4)
			                       AND BUS_DATE = %d{yyyyMMdd}
				                   )  b
                     WHERE  a.BUS_DATE = b.MON_START
				      )
	    AND  SUBSTR(CAST(a.BUS_DATE as STRING),1,4) = SUBSTR(EDW_PROD.G_DATE_ADD_STR('%d{yyyyMMdd}','yyyyMMdd','yyyyMMdd',-1,0,0),1,4)
	  )     a4
 ON          t.CUST_NO = a4.CUST_NO
 LEFT JOIN DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP1_%d{yyyyMMdd} a5
 ON           t.CUST_NO = a5.CUST_NO
 WHERE        t.BUS_DATE =%d{yyyyMMdd}
 AND         t.CUST_NO < > '100610335855'
 ;
 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP6_%d{yyyyMMdd};
 CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP6_%d{yyyyMMdd} as
 SELECT 
         BRH_NO
		,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,6) =SUBSTR('%d{yyyyMMdd}',1,6)
		          AND  IF_QLFD = '合格客户'
			      THEN 1
				  ELSE 0
			      END 
             )    as OPNAC_QLFD_CUST_VOL
        ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND  IF_QLFD = '合格客户'
			      THEN 1
				  ELSE 0
			      END 
             )    as TISSU_GT_OPNAC_QLFD_CUST_VOL	
       ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND SUBSTR(CAST(MIN_BUS_DATE as STRING),1,6) =SUBSTR('%d{yyyyMMdd}',1,6)				 
			      THEN 1
				  ELSE 0
			      END 
             )    as TADDED_VLD_CUST_VOL
        ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND SUBSTR(CAST(MIN_BUS_DATE as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
			      THEN 1
				  ELSE 0
			      END 
             )    as TISSU_GT_TADDED_VLD_CUST_VOL
      ,SUM(CASE WHEN IF_CLKH = '存量客户'
		          AND SUBSTR(CAST(MIN_BUS_DATE as STRING),1,6) =SUBSTR('%d{yyyyMMdd}',1,6)				 
			      THEN 1
				  ELSE 0
			      END 
             )    as STOCK_ACTVT_CUST_VOL
        ,SUM(CASE WHEN IF_CLKH = '存量客户'
		          AND SUBSTR(CAST(MIN_BUS_DATE as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
			      THEN 1
				  ELSE 0
			      END 
             )    as TISSU_GT_STOCK_ACTVT_CUST_VOL	

      ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND SUBSTR(CAST(MIN_BUS_DATE as STRING),1,6) =SUBSTR('%d{yyyyMMdd}',1,6)				 
			      THEN FNL_AST
				  ELSE 0
			      END 
             )    as ADDED_AST_S1
        ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND SUBSTR(CAST(MIN_BUS_DATE as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
			      THEN FNL_AST
				  ELSE 0
			      END 
             )    as ADDED_AST_S2

       ,SUM(CASE WHEN   IF_QLFD = '合格客户'
			      THEN FNL_AST-STRT_AST
				  ELSE 0
			      END 
             )    as ADDED_AST_S5
        ,SUM(CASE WHEN  IF_QLFD = '合格客户'
			      THEN FNL_AST-LAST_Y_FNL_AST
				  ELSE 0
			      END 
             )    as ADDED_AST_S6
		,SUM(CASE WHEN  LAST_Y_FNL_AST >= 500000
			      THEN 1
				  ELSE 0
			      END 
             )    as HIGHT_CUST_S1
		,SUM(CASE WHEN  FNL_AST >= 500000
			      THEN 1
				  ELSE 0
			      END 
             )    as HIGHT_CUST_S2 
		 ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND SUBSTR(CAST(MIN_BUS_DATE_50 as STRING),1,6) =SUBSTR('%d{yyyyMMdd}',1,6)				 
			      THEN 1
				  ELSE 0
			      END 
             )    as HIGHT_CUST_S4
        ,SUM(CASE WHEN SUBSTR(CAST(ORDI_OPNAC_DT as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
		          AND SUBSTR(CAST(MIN_BUS_DATE_50 as STRING),1,4) =SUBSTR('%d{yyyyMMdd}',1,4)
			      THEN 1
				  ELSE 0
			      END 
             )    as HIGHT_CUST_S5
 FROM   DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP2_%d{yyyyMMdd}  t
 GROUP BY  t.BRH_NO ;
 
 
 
 
 

 
  DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP3_%d{yyyyMMdd};
 CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP3_%d{yyyyMMdd} as
 SELECT a.TRD_DT,b.TRD_DT as TRD_DT_20,c.TRD_DT as TRD_DT_21
 FROM 
 (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT DESC )  as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND      TRD_DT < = %d{yyyyMMdd}
  AND       BUS_DATE = %d{yyyyMMdd}
 )  a
 LEFT JOIN 
  (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT  DESC )-19  as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND       TRD_DT < = %d{yyyyMMdd}
  AND       BUS_DATE = %d{yyyyMMdd}
 )   b
 ON  a.NUM = b.NUM
 LEFT JOIN 
  (SELECT   TRD_DT,ROW_NUMBER() OVER(ORDER BY TRD_DT  DESC )-20  as NUM
  FROM      EDW_PROD.T_EDW_T99_TRD_DATE
  WHERE     TRD_DT = NAT_DT
  AND      TRD_DT < = %d{yyyyMMdd}
  AND       BUS_DATE = %d{yyyyMMdd}
 )   c
 ON  a.NUM = c.NUM ;
     DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP4_%d{yyyyMMdd};
 CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP4_%d{yyyyMMdd} as
 SELECT      distinct t.BRH_NO
              ,t.CUST_NO
			  ,t.opn_dt
			  ,a2.trd_dt_20
			  ,a2.trd_dt_21
			  ---,a4.bus_date_min
			  --,a4.bus_date_max
			 -- ,a3.NET_TOT_AST
 FROM        (SELECT  BRH_NO
                     ,CUST_NO 
                     ,MIN(b.TRD_DT) as OPN_DT					 
              FROM DDW_PROD.T_DDW_F00_CUST_CUST_OPN_TRD_PRVL a
			  LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE  b
              ON        a.OPN_DT = b.NAT_DT
              AND       b.BUS_DATE = %d{yyyyMMdd}		  
			  WHERE  OPN_PRVL = 20
               AND   a.BUS_DATE = %d{yyyyMMdd}
              GROUP BY 	BRH_NO,CUST_NO		  
              )t
 INNER JOIN    DDW_PROD.T_DDW_INR_ORG_BRH           a1
 ON            t.BRH_NO = a1.BRH_NO
 AND           a1.BUS_DATE = %d{yyyyMMdd}
 LEFT JOIN     DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP3_%d{yyyyMMdd} a2
 ON           t.OPN_DT = a2.trd_dt
 --LEFT JOIN   DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY a3
 --ON          t.CUST_NO = a3.cust_no
 --and         a2.trd_dt_21 = a3.BUS_DATE
 LEFT JOIN (SELECT  CUST_NO
                   ,BUS_DATE
             FROM DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS
			 WHERE SUBSTR(BIZ_SBJ,1,3) = '101'
			 AND INCM_AMT > 0
			 AND  BUS_DATE >= 20190101
			 AND   BUS_DATE <= %d{yyyyMMdd}
			 GROUP BY CUST_NO,BUS_DATE
			 )    a4
ON      t.CUST_NO = a4.CUST_NO
WHERE  a4.BUS_DATE is not null
AND     a4.BUS_DATE between a2.trd_dt_20 and t.opn_dt;

   DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP5_%d{yyyyMMdd};
 CREATE TABLE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP5_%d{yyyyMMdd} as
 SELECT a1.brh_no
       ,SUM(CASE WHEN SUBSTR(cast(a1.opn_dt AS string),1,6) = SUBSTR('%d{yyyyMMdd}',1,6) 
	             THEN 1
			     ELSE 0
			     END) as STIB_S5
	   ,SUM(CASE WHEN SUBSTR(cast(a1.opn_dt AS string),1,4) = SUBSTR('%d{yyyyMMdd}',1,4) 
	             THEN 1
			     ELSE 0
			     END) as STIB_S6
 FROM DDW_PROD.T_DDW_F10_AST_CUST_AST_AGGR_DAY t
 INNER JOIN DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP4_%d{yyyyMMdd} a1
 ON        t.CUST_NO = a1.cust_no
 and       t.bus_date = a1.trd_dt_21
 WHERE    t.net_tot_ast <  500000
 group by a1.BRH_NO ;
 
 

  

 

 
   
 
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON
(
  BELTO_FILIL_CDG                            --分公司编码
, BELTO_FILIL                                --分公司名称
, BRH_NO                                     --营业部编码
, BRH_FULLNM                                 --营业部名称
,OPNAC_QLFD_CUST_VOL                         --新增合格客户数
,TISSU_GT_OPNAC_QLFD_CUST_VOL				 --本年累计新增合格客户数
,TADDED_VLD_CUST_VOL                         --新增有效客户数
,TISSU_GT_TADDED_VLD_CUST_VOL				 --本年累计新增有效客户数
,STOCK_ACTVT_CUST_VOL                        --存量客户激活
,TISSU_GT_STOCK_ACTVT_CUST_VOL               --本年累计存量客户激活
,ADDED_AST_S1                                --新增客户引进资产当期数
,ADDED_AST_S2                                --新增客户引进资产本年累计
,ADDED_AST_S3                                --存量客户新引进资产当期数
,ADDED_AST_S4                                --存量客户新引进资产本年累计数
,ADDED_AST_S5                                --当期合计新增资产
,ADDED_AST_S6                                --本年累计合计新增资产
,HIGHT_CUST_S1                               --新引进高端客户数上年期末数
,HIGHT_CUST_S2                               --新引进高端客户数当期期末数
,HIGHT_CUST_S3                               --新引进高端客户数增长率
,HIGHT_CUST_S4                               --新引进高端客户数当期新增数
,HIGHT_CUST_S5                               --新引进高端客户数本年新增累计数
,STIB_S1                                     --科创板当期
,STIB_S2                                     --科创板本年累计
,STIB_S3                                     --科创板存量客户当期
,STIB_S4                                     --科创板存量客户本年累计
,STIB_S5                                     --科创板增量客户当期
,STIB_S6                                     --科创板增量客户本年累计
,OPN_H_K_PRVL_CUST_VOL                       --港股通当期
,TISSU_GT_OPN_H_K_PRVL_CUST_VOL              --港股通本年累计
,OPNAC_CRD_CUST_VOL                          --两融当期
,TISSU_GT_OPNAC_CRD_CUST_VOL                 --两融本年累计
,OPNAC_WRNT_CUST_VOL                         --股票期权当期
,TISSU_GT_OPNAC_WRNT_CUST_VOL                --股票期权本年累计
,OPNAC_IB_CUST_VOL                           --IB业务当期
,TISSU_GT_OPNAC_IB_CUST_VOL                  --IB业务本年累计
,PROD_S1                                     --公募基金当期
,PROD_S2                                     --公募基金本年累计
,PROD_S3                                     --公司资管产品当期
,PROD_S4                                     --公司资管产品本年累计            
 ) PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
SELECT    t.BELTO_FILIL_CDG                             --分公司编码
        , t.BELTO_FILIL                                --分公司名称
        , t.BRH_NO                                     --营业部编码
        , t.BRH_FULLNM                                 --营业部名称
        ,NVL(a3.OPNAC_QLFD_CUST_VOL,0)                         --新增合格客户数
        ,NVL(a3.TISSU_GT_OPNAC_QLFD_CUST_VOL,0)				 --本年累计新增合格客户数
        ,NVL(a1.TADDED_VLD_CUST_VOL,0)                         --新增有效客户数
        ,NVL(a1.TISSU_GT_TADDED_VLD_CUST_VOL,0)				 --本年累计新增有效客户数
        ,NVL(a3.STOCK_ACTVT_CUST_VOL,0)                        --存量客户激活
        ,NVL(a3.TISSU_GT_STOCK_ACTVT_CUST_VOL,0)               --本年累计存量客户激活
        ,NVL(a3.ADDED_AST_S1,0)                                --新增客户引进资产当期数
        ,NVL(a3.ADDED_AST_S2,0)                                --新增客户引进资产本年累计
        ,NVL(a3.ADDED_AST_S5,0)- NVL(a3.ADDED_AST_S1,0)                               --存量客户新引进资产当期数
        ,NVL(a3.ADDED_AST_S6,0)- NVL(a3.ADDED_AST_S2,0)                              --存量客户新引进资产本年累计数
        ,NVL(a3.ADDED_AST_S5,0)                                --当期合计新增资产
        ,NVL(a3.ADDED_AST_S6,0)                                --本年累计合计新增资产
        ,NVL(a3.HIGHT_CUST_S1,0)                               --新引进高端客户数上年期末数
        ,NVL(a3.HIGHT_CUST_S2,0)                               --新引进高端客户数当期期末数
        ,CAST(round(NVL(a3.HIGHT_CUST_S2,0)*1.0000/NVL(a3.HIGHT_CUST_S1,0)-1,6) as DECIMAL(38,6))                              --新引进高端客户数增长率
        ,NVL(a3.HIGHT_CUST_S4,0)                               --新引进高端客户数当期新增数
        ,NVL(a3.HIGHT_CUST_S5,0)                               --新引进高端客户数本年新增累计数
        ,NVL(a1.OPN_STIB_PRVL_CUST_VOL,0)                                     --科创板当期
        ,NVL(a1.TISSU_GT_OPN_STIB_PRVL_CUST_VOL,0)                                     --科创板本年累计
        ,NVL(a1.OPN_STIB_PRVL_CUST_VOL,0)- NVL(a2.STIB_S5,0)                                    --科创板存量客户当期
        ,NVL(a1.TISSU_GT_OPN_STIB_PRVL_CUST_VOL,0)-  NVL(a2.STIB_S6,0)                                   --科创板存量客户本年累计
        ,NVL(a2.STIB_S5,0)                                     --科创板增量客户当期
		,NVL(a2.STIB_S6,0)                                     --科创板增量客户本年累计
        ,NVL(a1.OPN_H_K_PRVL_CUST_VOL,0)                       --港股通当期
        ,NVL(a1.TISSU_GT_OPN_H_K_PRVL_CUST_VOL,0)              --港股通本年累计
        ,NVL(a1.OPNAC_CRD_CUST_VOL,0)                          --两融当期
        ,NVL(a1.TISSU_GT_OPNAC_CRD_CUST_VOL,0)                 --两融本年累计
        ,NVL(a1.OPNAC_WRNT_CUST_VOL,0)                         --股票期权当期
        ,NVL(a1.TISSU_GT_OPNAC_WRNT_CUST_VOL,0)                --股票期权本年累计
        ,0                           --IB业务当期
        ,0                  --IB业务本年累计
        ,0                                     --公募基金当期
        ,0                                     --公募基金本年累计
        ,0                                     --公司资管产品当期
        ,0                                     --公司资管产品本年累计
 FROM  DDW_PROD.T_DDW_INR_ORG_BRH   t
LEFT JOIN DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP_%d{yyyyMMdd} a1
ON        t.BRH_NO = a1.BRH_NO
LEFT JOIN DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP5_%d{yyyyMMdd} a2
ON        t.BRH_NO = a2.BRH_NO
LEFT JOIN DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP6_%d{yyyyMMdd} a3
ON        t.BRH_NO = a3.BRH_NO
WHERE   t.BUS_DATE = %d{yyyyMMdd} ;

 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP1_%d{yyyyMMdd};
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP2_%d{yyyyMMdd};
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP3_%d{yyyyMMdd};
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP4_%d{yyyyMMdd};
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP5_%d{yyyyMMdd};
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP6_%d{yyyyMMdd};
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON_TEMP_%d{yyyyMMdd};
 
 ---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
    invalidate metadata DDW_PROD.T_DDW_PRT_SZXF_MKT_SVC_GAME_ACTVT_STATS_MON ;
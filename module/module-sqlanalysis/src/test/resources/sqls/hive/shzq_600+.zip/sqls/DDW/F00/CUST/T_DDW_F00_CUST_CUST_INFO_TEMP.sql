drop table if exists DDW_PROD.T_DDW_F00_CUST_CUST_INFO_%d{yyyyMMdd};
create table DDW_PROD.T_DDW_F00_CUST_CUST_INFO_%d{yyyyMMdd} as
select * from DDW_PROD.T_DDW_F00_CUST_CUST_INFO
where bus_date = %d{yyyyMMdd} ;


INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_CUST_INFO
(
                                     CUST_NO                                 --客户号                               
                                    ,CUST_NAME                               --客户姓名    
								    ,BRH_NO                                  --营业部编号   	
								    ,BRH_NAME                                --营业部名称   	
								    ,OPNAC_MOD                               --开户方式 
                                    ,OPNAC_CLNT								 --开户终端
									,OPNAC_DT                                --开户日期
								    ,ORDI_OPNAC_DT                           --普通账户开户日期  
                                    ,CRD_OPNAC_DT                            --信用账户开户日期
									,WRNT_OPNAC_DT                           --期权账户开户日期
									,CNCLACT_DT                              --销户日期
                                    ,ORDI_CNCLACT_DT                         --普通账户销户日期	
                                    ,CRD_CNCLACT_DT                          --信用账户销户日期
                                    ,WRNT_CNCLACT_DT                         --期权账户销户日期
                                    ,ORDI_CUST_GROUP                         --普通账户客户群组	
                                    ,CRD_CUST_GROUP                          --信用账户客户群组
                                    ,WRNT_CUST_GROUP                         --期权账户客户群组									
								    ,CTF_CGY_CD                              --证件类别代码  	
								    ,CTF_NO                                  --证件编号    	
								    ,CUST_CGY                                --客户类别
									,CUST_STAT                               --客户状态
									,ORDI_CUST_STAT                          --普通账户客户状态 
                                    ,CRD_CUST_STAT                           --信用账户客户状态									
								    ,WRNT_CUST_STAT                          --期权账户客户状态    	
								    ,GNDR_CD                                 --性别代码    	
								    ,DEPMGT_BANK                             --存管银行    	
								    ,CTRL_ATTR                               --控制属性    	
								    ,M_LAUND_RSK_LVL                         --洗钱风险等级 
                                    ,M_LAUND_RSK_IDSTR_CGY_CD                --洗钱风险行业类别代码									
								    ,RSK_BEAR_ABLTY                          --风险承受能力  	
								    ,IMAGE_TP                                --影像类型    	
								    ,CTF_EXPR_DT                             --证件截止日期  	
								    ,CTCT_ADDR                               --联系地址    	
								    ,CTCT_TEL                                --联系电话
                                    ,CTCT_PSN_NAME	                         --联系人姓名									
								    ,PHONE                                   --手机  
                                    ,BRTH_YM                                 --出生年月									
								    ,EDU_CD                                  --学历代码    	
								    ,OCP_CD                                  --职业代码    	
								    ,SECOND_CARD_VRFCTN                      --是否二代证   	
								    ,CUST_RSK_LVL                            --客户风险级别  	
								    ,FRIST_EVAL_DT                           --初次评测日期 
                                    ,CMSN_SETUP_DT                           --佣金设置日期
                                    ,CMSN_SETUP_ABST                         --佣金设置摘要									
								    ,IF_OPN_PHONE_ODR                        --是否开通手机委托
									,ORDI_ODR_MOD_SCP                        --普通账户委托范围
									,CRD_ODR_MOD_SCP                         --信用账户委托范围
									,WRNT_ODR_MOD_SCP                        --期权账户委托范围									
                                    ,CTF_ADDR                                --证件地址 
									,CITY_CD                                 --国家代码
									,NATN_CD                                 --民族代码
									,MARG_STAT_CD                            --婚姻状况代码 
                                    ,AGE                                     --年龄	
                                    ,CID									
) 
 partition(bus_date = %d{yyyyMMdd})
 select   CUST_NO                                 --客户号                               
                                    ,CUST_NAME                               --客户姓名    
								    ,BRH_NO                                  --营业部编号   	
								    ,BRH_NAME                                --营业部名称   	
								    ,OPNAC_MOD                               --开户方式 
                                    ,OPNAC_CLNT								 --开户终端
									,OPNAC_DT                                --开户日期
								    ,ORDI_OPNAC_DT                           --普通账户开户日期  
                                    ,CRD_OPNAC_DT                            --信用账户开户日期
									,WRNT_OPNAC_DT                           --期权账户开户日期
									,YGT_XHRQ   
									,JZJYKH_XHRQ
									,RZRQKH_XHRQ
									,GGQQKH_XHRQ
									
									
                                    ,ORDI_CUST_GROUP                         --普通账户客户群组	
                                    ,CRD_CUST_GROUP                          --信用账户客户群组
                                    ,WRNT_CUST_GROUP                         --期权账户客户群组									
								    ,CTF_CGY_CD                              --证件类别代码  	
								    ,CTF_NO                                  --证件编号    	
								    ,CUST_CGY                                --客户类别
									,CUST_STAT                               --客户状态
									,ORDI_CUST_STAT                          --普通账户客户状态 
                                    ,CRD_CUST_STAT                           --信用账户客户状态									
								    ,WRNT_CUST_STAT                          --期权账户客户状态    	
								    ,GNDR_CD                                 --性别代码    	
								    ,DEPMGT_BANK                             --存管银行    	
								    ,CTRL_ATTR                               --控制属性    	
								    ,M_LAUND_RSK_LVL                         --洗钱风险等级 
                                    ,M_LAUND_RSK_IDSTR_CGY_CD                --洗钱风险行业类别代码									
								    ,RSK_BEAR_ABLTY                          --风险承受能力  	
								    ,IMAGE_TP                                --影像类型    	
								    ,CTF_EXPR_DT                             --证件截止日期  	
								    ,CTCT_ADDR                               --联系地址    	
								    ,CTCT_TEL                                --联系电话
                                    ,CTCT_PSN_NAME	                         --联系人姓名									
								    ,PHONE                                   --手机  
                                    ,BRTH_YM                                 --出生年月									
								    ,EDU_CD                                  --学历代码    	
								    ,OCP_CD                                  --职业代码    	
								    ,SECOND_CARD_VRFCTN                      --是否二代证   	
								    ,CUST_RSK_LVL                            --客户风险级别  	
								    ,FRIST_EVAL_DT                           --初次评测日期 
                                    ,CMSN_SETUP_DT                           --佣金设置日期
                                    ,CMSN_SETUP_ABST                         --佣金设置摘要									
								    ,IF_OPN_PHONE_ODR                        --是否开通手机委托
									,ORDI_ODR_MOD_SCP                        --普通账户委托范围
									,CRD_ODR_MOD_SCP                         --信用账户委托范围
									,WRNT_ODR_MOD_SCP                        --期权账户委托范围									
                                    ,CTF_ADDR                                --证件地址 
									,CITY_CD                                 --国家代码
									,NATN_CD                                 --民族代码
									,MARG_STAT_CD                            --婚姻状况代码 
                                    ,AGE                                     --年龄	
                                    ,t.CID									
            
	from DDW_PROD.T_DDW_F00_CUST_CUST_INFO_%d{yyyyMMdd}  t
	left join edw_prod.t_edw_t01_tkhxx a1
	on t.cust_no = a1.khh
	and a1.bus_date =%d{yyyyMMdd} ;
	
	
	drop table if exists DDW_PROD.T_DDW_F00_CUST_CUST_INFO_%d{yyyyMMdd};
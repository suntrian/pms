 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:约定购回标的证券表                                                                 */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                        */ 
  
 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TSO_KHZDXQXY; 
----插入数据开始------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TSO_KHZDXQXY(
                                    KHH                                 --客户号                                
                                   ,ZQDM                                --交易所                                
                                   ,JYS                                 --证券代码                               
                                   ,KHXM                                --客户姓名                               
                                   ,YYB                                 --营业部                                
                                   ,GGQQKH_KHQZ                         --个股期权客户客户群组                         
                                   ,ZQMC                                --证券名称                               
                                   ,CLZB                                --策略指标                               
                                   ,ZBZ                                 --指标值                                
                                   ,KSRQ                                --开始日期                               
                                   ,JSRQ                                --结束日期                               
                                   ,BDRQ                                --变动日期                               
                                   ,SOP_XQXYLB                          --自动行权协议类别                           
                                   ,HYDM                                --期权合约代码                             
                                   ,HYMC                                --合约名称    
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.KHH                                 as KHH                                 --客户号                                 
                                   ,t.JYS                                 as ZQDM                                --交易所                                 
                                   ,t.ZQDM                                as JYS                                 --证券代码                                
                                   ,t.KHXM                                as KHXM                                --客户姓名                                
                                   ,CAST(COALESCE(t2.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as YYB                                 --营业部                                 
                                   ,t.KHQZ                                as GGQQKH_KHQZ                         --客户群组                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.CLZB                                as CLZB                                --策略指标                                
                                   ,t.ZBZ                                 as ZBZ                                 --指标值                                 
                                   ,t.KSRQ                                as KSRQ                                --开始日期                                
                                   ,t.JSRQ                                as JSRQ                                --结束日期                                
                                   ,t.BDRQ                                as BDRQ                                --变动日期                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.XYLB AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                 as SOP_XQXYLB                          --协议类别                                
                                   ,t.HYDM                                as HYDM                                --合约代码                                
                                   ,t.HYMC                                as HYMC                                --合约名称    
                                   ,'GGQQ'								  as XTBS
 FROM           GGQQCX.SOPTION_TSO_KHZDXQXY            t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING  t1 
 ON             t1.DMLX = 'SOP_XQXYLB'
 AND            t1.YXT = 'GGQQ'
 AND            t1.YDM = CAST(t.XYLB AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING      t2
 ON             t2.YXT = 'GGQQ'
 AND            t2.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---------------- from GGQQCX.SOPTION_TSO_KHZDXQXY end -----------------------
-------插入数据结束------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TSO_KHZDXQXY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TSO_KHZDXQXY;
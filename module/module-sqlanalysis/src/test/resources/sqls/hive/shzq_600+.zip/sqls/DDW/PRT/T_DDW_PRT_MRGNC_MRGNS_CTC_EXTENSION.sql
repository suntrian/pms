 /* ***************************************** SQL Begin ******************************************/
 /* 脚本功能:融资融券合约展期表                                                                     */
 /* 创建人:黄勇华                                                                              */
 /* 创建时间:2017-03-07                                                                        */ 
 /*  T_DDW_F05_CUST_CRD_GL_CHG     修改为   T_EDW_T05_TXY_FZBDMXLS  */

 ----判断是否有临时表
 DROP TABLE IF EXISTS   DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_CTC_EXTENSION_TEMP;
----创建临时表  
 CREATE TABLE DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_CTC_EXTENSION_TEMP AS 
 SELECT 
                                  t.FSRQ                        as OCC_DT                     --发生日期
								 ,t.YYB                         as BRH_NO                     --营业部编号                                                     
                                 ,NVL(a4.BRH_SHRTNM,a5.filil_dept_shrtnm)                 as BRH_NAME                   --营业部名称  
								 ,t.KHH                         as CUST_NO                    --客户号                                                   
                                 ,t.KHXM                        as CUST_NAME                  --客户姓名  
								 ,a2.KHRQ                       as OPNAC_DT                   --开户日期 
								 ,t.FZXX_LSH                    as GL_SER_NBR                 --负债流水号  
								 ,t.ZY                          as ABST                       --摘要 
                                 ,t.JYLB                        as TRD_CGY                    --交易类别	
                                 ,t.BUS_DATE                    AS BUS_DATE								 
  FROM          EDW_PROD.T_EDW_T05_TXY_FZBDMXLS                t
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                a4
  ON            t.YYB = a4.BRH_NO
  AND           a4.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT                 a5
  ON            t.YYB = a5.FILIL_DEPT_CDG
  AND           a5.BUS_DATE = %d{yyyyMMdd}   
  LEFT JOIN  ( SELECT KHH,KHRQ,BUS_DATE FROM  EDW_PROD.T_EDW_T02_TZJZH WHERE ZZHBZ =1 AND XTBS = 'RZRQ')  a2                   
  ON           t.KHH =  a2.KHH
  AND          t.BUS_DATE = a2.BUS_DATE  
  WHERE         t.bus_date = %d{yyyyMMdd} ;


-------------插入数据开始--------------
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_CTC_EXTENSION
(
                                     OCC_DT          --发生日期
                                    ,BRH_NO          --营业部编号
                                    ,BRH_NAME        --营业部名称
                                    ,CUST_NO         --客户号
                                    ,CUST_NAME       --客户姓名
                                    ,OPNAC_DT        --开户日期											
                                    ,GL_SER_NBR      --负债流水号
                                    ,ABST            --摘要                                             
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT 
                                    t.OCC_DT                      as OCC_DT          --发生日期                                         
                                   ,t.BRH_NO                      as BRH_NO          --营业部编号                                         
                                   ,t.BRH_NAME                    as BRH_NAME        --营业部名称                                         
                                   ,t.CUST_NO                     as CUST_NO         --客户号                                                                          
                                   ,t.CUST_NAME                   as CUST_NAME       --客户姓名
                                   ,t.OPNAC_DT                    as OPNAC_DT        --开户日期										   
                                   ,t.GL_SER_NBR                  as GL_SER_NBR      --负债流水号                                        
                                   ,t.ABST                        as ABST            --摘要                                               
                                                  

   FROM     DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_CTC_EXTENSION_TEMP      t
   WHERE    TRD_CGY = 81
   AND      t.BUS_DATE = %d{yyyyMMdd}
  
 ;    
   
   
------结束----   

----删除临时表  
DROP TABLE IF EXISTS   DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_CTC_EXTENSION_TEMP;                                         

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_MRGNC_MRGNS_CTC_EXTENSION',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
     invalidate metadata DDW_PROD.T_DDW_PRT_MRGNC_MRGNS_CTC_EXTENSION; 
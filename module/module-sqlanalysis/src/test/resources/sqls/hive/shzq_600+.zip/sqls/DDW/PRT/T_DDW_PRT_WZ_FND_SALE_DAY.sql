------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:温州事业部基金销售日报表                                                           */
------/* 创建人:欧阳晶                                                                                 */
------/* 创建时间:2018-07-02                                                                           */ 

----基金交易临时表-从证券交易/产品交易表取数
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FND_SALE_DAY_TEMP1;
CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_FND_SALE_DAY_TEMP1
AS 
    SELECT
           T1.BRH_NO                                             --1.营业部编号
		  ,T2.BRH_FULLNM AS BRH_NAME                             --2.营业部名称
		  ,T3.ASS_MLTP                                           --3.考核倍数
          ,T1.SEC_CD AS FND_CD                                   --4.基金代码
          ,COALESCE(T6.JJQC,T5.CPQC,t7.ZQMC) AS FND_NAME         --5.基金名称
		  ,T3.FND_CGY AS PROD_CGY                                --6.产品归类
          ,SUM(T1.MTCH_AMT) AS SALE_QTY                          --7.销售量
		  ,SUM(T1.MTCH_AMT * T3.ASS_MLTP / 30) AS ASS_SALE_QTY   --8.考核销售量
		  ,%d{yyyyMMdd} AS BUS_DATE                              --9.数据日期
    FROM DDW_PROD.T_DDW_F00_TRD_SEC_TRD_DEL_HIS T1
    INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
            ON T1.BRH_NO = T2.BRH_NO
           AND T2.BELTO_FILIL_CDG = '0032'
		   AND T2.BUS_DATE = %d{yyyyMMdd}
    INNER JOIN DDW_PROD.T_DDW_CFG_WZ_PROD T3
            ON T1.SEC_CD = T3.PROD_CD
    LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO T4
           ON T1.CUST_NO = T4.CUST_NO
          AND T4.BUS_DATE = %d{yyyyMMdd}
    LEFT JOIN EDW_PROD.T_EDW_T99_TJRCP_CPDM T5
           ON T1.SEC_CD = T5.CPDM
          AND T5.BUS_DATE = %d{yyyyMMdd}
    LEFT JOIN EDW_PROD.T_EDW_T04_TOF_JJXX T6
           ON T1.SEC_CD = T6.JJDM
          AND T6.BUS_DATE = %d{yyyyMMdd}
    LEFT JOIN EDW_PROD.T_EDW_T04_TZQDM T7
           ON T1.EXG = T7.JYS
          AND T1.SEC_CD = T7.ZQDM
          AND T7.BUS_DATE = %d{yyyyMMdd}
    WHERE T1.ODR_CGY IN (1,1111,83,42)
      AND T1.BUS_DATE = %d{yyyyMMdd}
      AND ((SUBSTR(T1.SEC_CD,1,2) IN ('50','51','52') AND EXG = 'SH') OR (SUBSTR(T1.SEC_CD,1,2) IN ('15','16','18') AND EXG = 'SZ'))
    GROUP BY 
             T1.BRH_NO
		    ,T2.BRH_FULLNM
		    ,T3.ASS_MLTP
            ,T1.SEC_CD
            ,COALESCE(T6.JJQC,T5.CPQC,t7.ZQMC)
		    ,T3.FND_CGY
   UNION ALL
    SELECT 
           T1.BRH_NO                                             --1.营业部编号
		  ,T2.BRH_FULLNM AS BRH_NAME                             --2.营业部名称
		  ,T3.ASS_MLTP                                           --3.考核倍数
          ,T1.PROD_CD AS FND_CD                                  --4.基金代码
          ,COALESCE(T6.JJQC,T5.CPQC,T8.CPQC) AS FND_NAME                 --5.基金名称
		  ,T3.FND_CGY AS PROD_CGY                                --6.产品归类
          ,SUM(T1.CNFM_AMT) AS SALE_QTY                          --7.销售量
		  ,SUM(T1.CNFM_AMT * T3.ASS_MLTP / 30) AS ASS_SALE_QTY   --8.考核销售量
		  ,%d{yyyyMMdd} AS BUS_DATE                              --9.数据日期
    FROM DDW_PROD.T_DDW_F00_TRD_PROD_TRD_DEL_HIS T1
    INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T2
            ON T1.BRH_NO = T2.BRH_NO
           AND T2.BELTO_FILIL_CDG = '0032'
           AND T2.BUS_DATE = %d{yyyyMMdd}
    INNER JOIN DDW_PROD.T_DDW_CFG_WZ_PROD T3
            ON T1.PROD_CD = T3.PROD_CD
    LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO T4
           ON T1.CUST_NO = T4.CUST_NO
          AND T4.BUS_DATE = %d{yyyyMMdd}
    LEFT JOIN EDW_PROD.T_EDW_T99_TJRCP_CPDM T5
           ON T1.PROD_CD = T5.CPDM
          AND T5.BUS_DATE = %d{yyyyMMdd}
    LEFT JOIN EDW_PROD.T_EDW_T04_TOF_JJXX T6
           ON T1.PROD_CD = T6.JJDM
          AND T6.BUS_DATE = %d{yyyyMMdd}
	LEFT JOIN EDW_PROD.T_EDW_T04_TFP_CPDM T8
               ON T1.PROD_CD = T8.CPDM
              AND T8.BUS_DATE = %d{yyyyMMdd}
    WHERE T1.PROD_BIZ_CD IN ('122','130','139')
      AND T1.BUS_DATE = %d{yyyyMMdd}
    GROUP BY 
             T1.BRH_NO
            ,T2.BRH_FULLNM
            ,T3.ASS_MLTP
		    ,T2.BRH_FULLNM
            ,T1.PROD_CD
            ,COALESCE(T6.JJQC,T5.CPQC,T8.CPQC)
            ,T3.FND_CGY
;


----基金持仓临时表-从证券持仓/产品持仓表取数
DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FND_SALE_DAY_TEMP2;
CREATE TABLE DDW_PROD.T_DDW_PRT_WZ_FND_SALE_DAY_TEMP2
AS 
    SELECT 
		   T1.BRH_NO                                                                   --1.营业部编号
          ,T3.BRH_FULLNM AS BRH_NAME                                                   --2.营业部名称
		  ,T2.ASS_MLTP                                                                 --3.考核倍数
		  ,T1.SEC_CD AS FND_CD                                                         --4.基金代码
		  ,COALESCE(T7.JJQC,T6.CPQC,t8.ZQMC) AS FND_NAME                               --5.基金名称
		  ,T2.FND_CGY AS PROD_CGY                                                      --6.产品归类
		  ,SUM(T1.SEC_MKTVAL) AS RTAN_QTY                                              --7.保有量
		  ,SUM(T1.SEC_MKTVAL * T2.ASS_MLTP / 30) AS ASS_RTAN_QTY                       --8.考核保有量
		  ,T4.NAT_DT AS BUS_DATE                                                       --9.数据日期
        FROM DDW_PROD.T_DDW_F00_AST_SEC_HLD_DTL_HIS T1
		INNER JOIN DDW_PROD.T_DDW_CFG_WZ_PROD T2
		        ON T1.SEC_CD = T2.PROD_CD
        INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T3
		        ON T1.BRH_NO = T3.BRH_NO
               AND T3.BELTO_FILIL_CDG = '0032'
			   AND T3.BUS_DATE = %d{yyyyMMdd}
		LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE T4
		       ON T1.BUS_DATE = T4.TRD_DT
		      AND T4.BUS_DATE = %d{yyyyMMdd}
		LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO T5
		       ON T1.CUST_NO = T5.CUST_NO
		      AND T5.BUS_DATE = %d{yyyyMMdd}
        LEFT JOIN EDW_PROD.T_EDW_T99_TJRCP_CPDM T6
               ON T1.SEC_CD = T6.CPDM
              AND T6.BUS_DATE = %d{yyyyMMdd}
        LEFT JOIN EDW_PROD.T_EDW_T04_TOF_JJXX T7
               ON T1.SEC_CD = T7.JJDM
              AND T7.BUS_DATE = %d{yyyyMMdd}
        LEFT JOIN EDW_PROD.T_EDW_T04_TZQDM T8
               ON T1.EXG = T8.JYS
              AND T1.SEC_CD = T8.ZQDM
              AND T8.BUS_DATE = %d{yyyyMMdd}
        WHERE T1.BUS_DATE = %d{yyyyMMdd}
          AND T1.SEC_QTY > 0
	      AND ((SUBSTR(T1.SEC_CD,1,2) IN ('50','51','52') AND T1.EXG = 'SH') OR (SUBSTR(T1.SEC_CD,1,2) IN ('15','16','18') AND T1.EXG = 'SZ'))
        GROUP BY 
		         T1.BRH_NO
                ,T3.BRH_FULLNM
		        ,T2.ASS_MLTP
		        ,T1.SEC_CD
		        ,COALESCE(T7.JJQC,T6.CPQC,t8.ZQMC)
		        ,T2.FND_CGY
				,T4.NAT_DT
   UNION ALL
    SELECT 
		   T1.BRH_NO                                                                          --1.营业部编号
          ,T3.BRH_FULLNM AS BRH_NAME                                                          --2.营业部名称
		  ,T2.ASS_MLTP                                                                        --3.考核倍数
		  ,T1.PROD_CD AS FND_CD                                                               --4.基金代码
		  ,COALESCE(T7.JJQC,T6.CPQC,T8.CPQC) AS FND_NAME                                              --5.基金名称
		  ,T2.FND_CGY AS PROD_CGY                                                             --6.产品归类
		  ,SUM(T1.PROD_NEWST_MKTVAL) AS RTAN_QTY                                              --7.保有量
		  ,SUM(T1.PROD_NEWST_MKTVAL * T2.ASS_MLTP / 30) AS ASS_RTAN_QTY                       --8.考核保有量
		  ,T4.NAT_DT AS BUS_DATE                                                              --9.数据日期
        FROM DDW_PROD.T_DDW_F00_AST_PROD_HLD_DTL_HIS T1
		INNER JOIN DDW_PROD.T_DDW_CFG_WZ_PROD T2
		        ON T1.PROD_CD = T2.PROD_CD
        INNER JOIN DDW_PROD.T_DDW_INR_ORG_BRH T3
		        ON T1.BRH_NO = T3.BRH_NO
               AND T3.BELTO_FILIL_CDG = '0032'
			   AND T3.BUS_DATE = %d{yyyyMMdd}
		LEFT JOIN EDW_PROD.T_EDW_T99_TRD_DATE T4
		       ON T1.BUS_DATE = T4.TRD_DT
		      AND T4.BUS_DATE = %d{yyyyMMdd}
		LEFT JOIN DDW_PROD.T_DDW_F00_CUST_CUST_INFO T5
		       ON T1.CUST_NO = T5.CUST_NO
		      AND T5.BUS_DATE = %d{yyyyMMdd}
        LEFT JOIN EDW_PROD.T_EDW_T99_TJRCP_CPDM T6
               ON T1.PROD_CD = T6.CPDM
              AND T6.BUS_DATE = %d{yyyyMMdd}
        LEFT JOIN EDW_PROD.T_EDW_T04_TOF_JJXX T7
               ON T1.PROD_CD = T7.JJDM
              AND T7.BUS_DATE = %d{yyyyMMdd}
	    LEFT JOIN EDW_PROD.T_EDW_T04_TFP_CPDM T8
              ON T1.PROD_CD = T8.CPDM
              AND T8.BUS_DATE = %d{yyyyMMdd}
        WHERE T1.BUS_DATE = %d{yyyyMMdd}
          AND T1.PROD_SHR_QTY > 0
        GROUP BY 
		         T1.BRH_NO
                ,T3.BRH_FULLNM
		        ,T2.ASS_MLTP
		        ,T1.PROD_CD
		        ,COALESCE(T7.JJQC,T6.CPQC,T8.CPQC)
		        ,T2.FND_CGY
				,T4.NAT_DT
;

------插入数据开始
INSERT OVERWRITE DDW_PROD.T_DDW_PRT_WZ_FND_SALE_DAY
(    BRH_NO                                      --1.营业部编号
	,BRH_NAME                                    --2.营业部名称
	,ASS_MLTP                                    --3.考核倍数
    ,FND_CD			                             --4.基金代码
    ,FND_NAME                                    --5.基金名称
	,PROD_CGY                                    --6.产品归类
	,SALE_QTY                                    --7.销售量
	,ASS_SALE_QTY                                --8.考核销售量
	,RTAN_QTY                                    --9.保有量
	,ASS_RTAN_QTY                                --10.考核保有量
 ) partition(BUS_DATE)
    SELECT
	       COALESCE(T1.BRH_NO,T2.BRH_NO) AS BRH_NO                                     --1.营业部编号
		  ,COALESCE(T1.BRH_NAME,T2.BRH_NAME) AS BRH_NAME                               --2.营业部名称
		  ,COALESCE(T1.ASS_MLTP,T2.ASS_MLTP) AS ASS_MLTP                               --3.考核倍数
		  ,COALESCE(T1.FND_CD,T2.FND_CD) AS FND_CD                                     --4.基金代码
		  ,COALESCE(T1.FND_NAME,T2.FND_NAME) AS FND_NAME                               --5.基金名称
		  ,COALESCE(T1.PROD_CGY,T2.PROD_CGY) AS PROD_CGY                               --6.产品归类
		  ,COALESCE(T1.SALE_QTY,0) AS SALE_QTY                                         --7.销售量
		  ,COALESCE(CAST(T1.ASS_SALE_QTY AS DECIMAL(38,2)),0) AS ASS_SALE_QTY          --8.考核销售量
		  ,COALESCE(T2.RTAN_QTY,0) AS RTAN_QTY                                         --9.保有量
		  ,COALESCE(CAST(T2.ASS_RTAN_QTY AS DECIMAL(38,2)),0) AS ASS_RTAN_QTY          --10.考核保有量
		  ,CAST(COALESCE(T1.BUS_DATE,T2.BUS_DATE) AS INT) AS BUS_DATE                  --11.加载日期
	FROM
	(
	   SELECT BUS_DATE,BRH_NO,BRH_NAME,ASS_MLTP,FND_CD,FND_NAME,PROD_CGY,SUM(SALE_QTY) AS SALE_QTY,SUM(ASS_SALE_QTY) AS ASS_SALE_QTY
       FROM DDW_PROD.T_DDW_PRT_WZ_FND_SALE_DAY_TEMP1
       GROUP BY BUS_DATE,BRH_NO,BRH_NAME,ASS_MLTP,FND_CD,FND_NAME,PROD_CGY
    ) T1
	FULL JOIN
	(
	   SELECT BUS_DATE,BRH_NO,BRH_NAME,ASS_MLTP,FND_CD,FND_NAME,PROD_CGY,SUM(RTAN_QTY) AS RTAN_QTY,SUM(ASS_RTAN_QTY) AS ASS_RTAN_QTY
       FROM DDW_PROD.T_DDW_PRT_WZ_FND_SALE_DAY_TEMP2
       GROUP BY BUS_DATE,BRH_NO,BRH_NAME,ASS_MLTP,FND_CD,FND_NAME,PROD_CGY
	) T2
	 ON T1.BUS_DATE = T2.BUS_DATE
	AND T1.BRH_NO = T2.BRH_NO
	AND T1.FND_CD = T2.FND_CD
;
------插入数据结束

------删除临时表
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FND_SALE_DAY_TEMP1;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FND_SALE_DAY_TEMP2;
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FND_SALE_DAY_TEMP1;
--DROP TABLE IF EXISTS DDW_PROD.T_DDW_PRT_WZ_FND_SALE_STATS_MON_TEMP2;

-----------------------------加载结束--------------------
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PRT_WZ_FND_SALE_DAY',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ; 
invalidate metadata DDW_PROD.T_DDW_PRT_WZ_FND_SALE_DAY;
------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:客户交易收入月表                                                                */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON_TEMP ;
 CREATE TABLE DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON_TEMP as
SELECT      CUST_NO
           ,SUM(CASE WHEN SYS_SRC = '普通账户'
                     THEN  ACCNT_BAL*0.0127/360
	                 ELSE 0
				     END 
				) as ORDI_PRDCT_GL_INT                      --普通账户预计息差收入
		   ,SUM(CASE WHEN SYS_SRC = '信用账户'
		             THEN  ACCNT_BAL*0.0127/360
	                 ELSE 0
				     END 
				) as CRD_PRDCT_GL_INT                       --信用账户预计息差收入
FROM       DDW_PROD.T_DDW_F00_AST_CPTL_BAL_HIS  a
WHERE      CCY_CD = 'RMB'
AND        SYS_SRC IN ('普通账户','信用账户')
AND        SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
GROUP BY   CUST_NO
;

DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON_TEMP1 ;
CREATE TABLE DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON_TEMP1 as
SELECT     CUST_NO
          ,SUM(CASE WHEN SYS_SRC = '普通账户'
		            AND  BIZ_SBJ IN ('10501','10503')
		            THEN  INCM_AMT*(0.0162-0.0035)/0.0035
	                ELSE 0
				    END 
				)  as ORDI_FCT_GL_INT                      --普通账户实际息差收入
          ,SUM(CASE WHEN SYS_SRC = '信用账户'
		            AND  BIZ_SBJ IN ('10501','10503')
		            THEN  INCM_AMT*(0.0162-0.0035)/0.0035
	                ELSE 0
				    END 
				)  as CRD_FCT_GL_INT                       --信用账户实际息差收入
FROM       DDW_PROD.T_DDW_F00_TRD_CPTL_TRD_DTL_HIS  a
WHERE      CCY_CD = 'RMB'
AND        SYS_SRC IN ('普通账户','信用账户')
AND        SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
AND        BIZ_SBJ IN ('10501','10503')
GROUP BY   CUST_NO ;

--客户交易收入表
INSERT OVERWRITE DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON
(        CUST_NO                                     --客户号                 
        ,BRH_NO                                      --营业部编号                         
        ,CUST_CGY			                         --客户类别
		,CRD_MRGNC_MRGNS_PRDCT_INT                   --信用账户融资融券预计利息    
        ,CRD_MRGNC_MRGNS_RTN_INT                     --信用账户融资融券归还利息
		,ORDI_PLG_REPO_PRDCT_INT                     --普通账户质押回购预计利息
        ,ORDI_PLG_REPO_RTN_INT                       --普通账户质押回购归还利息
		,ORDI_S1_INCM_RMB                            --普通账户佣金收入(人民币)
        ,CRD_S1_INCM                                 --信用账户佣金收入
        ,ORDI_S1_INCM_OTH_RMB                        --普通账户佣金收入_其他(包括权证等)
        ,S1_INCM_HA                                  --佣金收入_沪A主板
        ,ORDI_S1_INCM_HA                             --普通账户佣金收入_沪A主板
        ,CRD_S1_INCM_HA                              --信用账户佣金收入_沪A主板
        ,S1_INCM_SA                                  --佣金收入_深A主板
        ,ORDI_S1_INCM_SA                             --普通账户佣金收入_深A主板
        ,CRD_S1_INCM_SA                              --信用账户佣金收入_深A主板
        ,S1_INCM_SMS                                 --佣金收入_中小板
        ,ORDI_S1_INCM_SMS                            --普通账户佣金收入_中小板
        ,CRD_S1_INCM_SMS                             --信用账户佣金收入_中小板
        ,S1_INCM_GEM                                 --佣金收入_创业板
        ,ORDI_S1_INCM_GEM                            --普通账户佣金收入_创业板
        ,CRD_S1_INCM_GEM                             --信用账户佣金收入_创业板
        ,ORDI_S1_INCM_HB_USD                         --普通账户佣金收入_沪B_美元
        ,ORDI_S1_INCM_SB_HKD                         --普通账户佣金收入_深B_港币
        ,ORDI_S1_INCM_HK                             --普通账户佣金收入_沪港通
        ,ORDI_S1_INCM_SK                             --普通账户佣金收入_深港通
        ,ORDI_S1_INCM_TA                             --普通账户佣金收入_三板A股
        ,ORDI_S1_INCM_TU_USD                         --普通账户佣金收入_三板B股_美元
        ,ORDI_S1_INCM_REPO                           --普通账户佣金收入_回购
        ,ORDI_S1_INCM_EXG_FND                        --普通账户佣金收入_场内基金收入
        ,ORDI_S1_INCM_CLS_FND                        --普通账户佣金收入_封闭式基金
        ,ORDI_S1_INCM_ETF_FND                        --普通账户佣金收入_ETF
        ,ORDI_S1_INCM_OPN_FND                        --普通账户佣金收入_开放式
        ,ORDI_S1_INCM_LOF_FND                        --普通账户佣金收入_LOF
        ,ORDI_S1_INCM_FOF_FND                        --普通账户佣金收入_FOF
        ,CRD_S1_INCM_EXG_FND                         --信用账户佣金收入_场内基金收入
        ,CRD_S1_INCM_CLS_FND                         --信用账户佣金收入_封闭式基金
        ,CRD_S1_INCM_ETF_FND                         --信用账户佣金收入_ETF
        ,CRD_S1_INCM_OPN_FND                         --信用账户佣金收入_开放式
        ,CRD_S1_INCM_LOF_FND                         --信用账户佣金收入_LOF
        ,CRD_S1_INCM_FOF_FND                         --信用账户佣金收入_FOF
        ,ORDI_S1_INCM_BOND                           --普通账户佣金收入_债券
        ,CRD_S1_INCM_BOND                            --信用账户佣金收入_债券
        ,ORDI_NET_S1_INCM_RMB                        --普通账户净佣金收入(人民币)
        ,CRD_NET_S1_INCM                             --信用账户净佣金收入
        ,ORDI_NET_S1_INCM_OTH_RMB                    --普通账户净佣金收入_其他(包括权证等)
        ,NET_S1_INCM_HA                              --净佣金收入_沪A主板
        ,ORDI_NET_S1_INCM_HA                         --普通账户净佣金收入_沪A主板
        ,CRD_NET_S1_INCM_HA                          --信用账户净佣金收入_沪A主板
        ,NET_S1_INCM_SA                              --净佣金收入_深A主板
        ,ORDI_NET_S1_INCM_SA                         --普通账户净佣金收入_深A主板
        ,CRD_NET_S1_INCM_SA                          --信用账户净佣金收入_深A主板
        ,NET_S1_INCM_SMS                             --净佣金收入_中小板
        ,ORDI_NET_S1_INCM_SMS                        --普通账户净佣金收入_中小板
        ,CRD_NET_S1_INCM_SMS                         --信用账户净佣金收入_中小板
        ,NET_S1_INCM_GEM                             --净佣金收入_创业板
        ,ORDI_NET_S1_INCM_GEM                        --普通账户净佣金收入_创业板
        ,CRD_NET_S1_INCM_GEM                         --信用账户净佣金收入_创业板
        ,ORDI_NET_S1_INCM_HB_USD                     --普通账户净佣金收入_沪B_美元
        ,ORDI_NET_S1_INCM_SB_HKD                     --普通账户净佣金收入_深B_港币
        ,ORDI_NET_S1_INCM_HK                         --普通账户净佣金收入_沪港通
        ,ORDI_NET_S1_INCM_SK                         --普通账户净佣金收入_深港通
        ,ORDI_NET_S1_INCM_TA                         --普通账户净佣金收入_三板A股
        ,ORDI_NET_S1_INCM_TU_USD                     --普通账户净佣金收入_三板B股_美元
        ,ORDI_NET_S1_INCM_REPO                       --普通账户净佣金收入_回购
        ,ORDI_NET_S1_INCM_EXG_FND                    --普通账户净佣金收入_场内基金收入
        ,ORDI_NET_S1_INCM_CLS_FND                    --普通账户净佣金收入_封闭式基金
        ,ORDI_NET_S1_INCM_ETF_FND                    --普通账户净佣金收入_ETF
        ,ORDI_NET_S1_INCM_OPN_FND                    --普通账户净佣金收入_开放式
        ,ORDI_NET_S1_INCM_LOF_FND                    --普通账户净佣金收入_LOF
        ,ORDI_NET_S1_INCM_FOF_FND                    --普通账户净佣金收入_FOF
        ,CRD_NET_S1_INCM_EXG_FND                     --信用账户净佣金收入_场内基金收入
        ,CRD_NET_S1_INCM_CLS_FND                     --信用账户净佣金收入_封闭式基金
        ,CRD_NET_S1_INCM_ETF_FND                     --信用账户净佣金收入_ETF
        ,CRD_NET_S1_INCM_OPN_FND                     --信用账户净佣金收入_开放式
        ,CRD_NET_S1_INCM_LOF_FND                     --信用账户净佣金收入_LOF
        ,CRD_NET_S1_INCM_FOF_FND                     --信用账户净佣金收入_FOF
        ,ORDI_NET_S1_INCM_BOND                       --普通账户净佣金收入_债券
        ,CRD_NET_S1_INCM_BOND                        --信用账户净佣金收入_债券	
        ,ORDI_TRD_FEE_RMB                            --普通账户交易费用(人民币)
        ,CRD_TRD_FEE                                 --信用账户交易费用
        ,ORDI_TRD_FEE_OTH_RMB                        --普通账户交易费用_其他(包括权证等)
        ,TRD_FEE_HA                                  --交易费用_沪A主板
        ,ORDI_TRD_FEE_HA                             --普通账户交易费用_沪A主板
        ,CRD_TRD_FEE_HA                              --信用账户交易费用_沪A主板
        ,TRD_FEE_SA                                  --交易费用_深A主板
        ,ORDI_TRD_FEE_SA                             --普通账户交易费用_深A主板
        ,CRD_TRD_FEE_SA                              --信用账户交易费用_深A主板
        ,TRD_FEE_SMS                                 --交易费用_中小板
        ,ORDI_TRD_FEE_SMS                            --普通账户交易费用_中小板
        ,CRD_TRD_FEE_SMS                             --信用账户交易费用_中小板
        ,TRD_FEE_GEM                                 --交易费用_创业板
        ,ORDI_TRD_FEE_GEM                            --普通账户交易费用_创业板
        ,CRD_TRD_FEE_GEM                             --信用账户交易费用_创业板
        ,ORDI_TRD_FEE_HB_USD                         --普通账户交易费用_沪B_美元
        ,ORDI_TRD_FEE_SB_HKD                         --普通账户交易费用_深B_港币
        ,ORDI_TRD_FEE_HK                             --普通账户交易费用_沪港通
        ,ORDI_TRD_FEE_SK                             --普通账户交易费用_深港通
        ,ORDI_TRD_FEE_TA                             --普通账户交易费用_三板A股
        ,ORDI_TRD_FEE_TU_USD                         --普通账户交易费用_三板B股_美元
        ,ORDI_TRD_FEE_REPO                           --普通账户交易费用_回购
        ,ORDI_TRD_FEE_EXG_FND                        --普通账户交易费用_场内基金
        ,ORDI_TRD_FEE_CLS_FND                        --普通账户交易费用_封闭式基金
        ,ORDI_TRD_FEE_ETF_FND                        --普通账户交易费用_ETF
        ,ORDI_TRD_FEE_OPN_FND                        --普通账户交易费用_开放式
        ,ORDI_TRD_FEE_LOF_FND                        --普通账户交易费用_LOF
        ,ORDI_TRD_FEE_FOF_FND                        --普通账户交易费用_FOF
        ,CRD_TRD_FEE_EXG_FND                         --信用账户交易费用_场内基金
        ,CRD_TRD_FEE_CLS_FND                         --信用账户交易费用_封闭式基金
        ,CRD_TRD_FEE_ETF_FND                         --信用账户交易费用_ETF
        ,CRD_TRD_FEE_OPN_FND                         --信用账户交易费用_开放式
        ,CRD_TRD_FEE_LOF_FND                         --信用账户交易费用_LOF
        ,CRD_TRD_FEE_FOF_FND                         --信用账户交易费用_FOF
        ,ORDI_TRD_FEE_BOND                           --普通账户交易费用_债券
        ,CRD_TRD_FEE_BOND                            --信用账户交易费用_债券					 
        ,PROD_CMSN_FEE                               --产品手续费
        ,AGN_FND_CMSN_FEE                            --代销基金手续费
        ,GS_PROD_CMSN_FEE                            --公司产品手续费
        ,GJ_PROD_CMSN_FEE                            --国君产品手续费
        ,OTC_PROD_CMSN_FEE                           --OTC产品手续费
        ,PROD_SCRP_AMT                               --产品认购金额		
        ,PROD_PRCH_AMT                               --产品申购金额	
        ,PROD_FIXINV_AMT                             --产品定投金额	
        ,PROD_RDMPT_AMT                              --产品赎回金额
        ,AGN_FND_SCRP_AMT                            --代销基金认购金额
        ,AGN_FND_PRCH_AMT                            --代销基金申购金额
        ,AGN_FND_FIXINV_AMT                          --代销基金定投金额
        ,AGN_FND_RDMPT_AMT                           --代销基金赎回金额
        ,GS_PROD_SCRP_AMT                            --公司产品认购金额
        ,GS_PROD_PRCH_AMT                            --公司产品申购金额
        ,GS_PROD_FIXINV_AMT                          --公司产品定投金额
        ,GS_PROD_RDMPT_AMT                           --公司产品赎回金额
        ,GJ_PROD_SCRP_AMT                            --国君产品认购金额
        ,GJ_PROD_PRCH_AMT                            --国君产品申购金额
        ,GJ_PROD_FIXINV_AMT                          --国君产品定投金额
        ,GJ_PROD_RDMPT_AMT                           --国君产品赎回金额
        ,BANK_PROD_SCRP_AMT                          --银行产品认购金额
        ,BANK_PROD_PRCH_AMT                          --银行产品申购金额		
        ,BANK_PROD_RDMPT_AMT                         --银行产品赎回金额	
        ,OTC_PROD_SCRP_AMT                           --OTC产品认购金额
        ,OTC_PROD_PRCH_AMT                           --OTC产品申购金额		
        ,OTC_PROD_RDMPT_AMT                          --OTC产品赎回金额			
        ,AGN_FND_SCRP_ITMS                           --代销基金认购笔数
        ,AGN_FND_PRCH_ITMS                           --代销基金申购笔数
        ,AGN_FND_FIXINV_ITMS                         --代销基金定投笔数
        ,AGN_FND_RDMPT_ITMS                          --代销基金赎回笔数
        ,GS_PROD_SCRP_ITMS                           --公司产品认购笔数
        ,GS_PROD_PRCH_ITMS                           --公司产品申购笔数
        ,GS_PROD_FIXINV_ITMS                         --公司产品定投笔数
        ,GS_PROD_RDMPT_ITMS                          --公司产品赎回笔数
        ,GJ_PROD_SCRP_ITMS                           --国君产品认购笔数
        ,GJ_PROD_PRCH_ITMS                           --国君产品申购笔数
        ,GJ_PROD_FIXINV_ITMS                         --国君产品定投笔数
        ,GJ_PROD_RDMPT_ITMS                          --国君产品赎回笔数
        ,BANK_PROD_SCRP_ITMS                         --银行产品认购笔数
        ,BANK_PROD_PRCH_ITMS                         --银行产品申购笔数		
        ,BANK_PROD_RDMPT_ITMS                        --银行产品赎回笔数
        ,OTC_PROD_SCRP_ITMS                          --OTC产品认购笔数
        ,OTC_PROD_PRCH_ITMS                          --OTC产品申购笔数		
        ,OTC_PROD_RDMPT_ITMS                         --OTC产品赎回笔数			 
        ,ORDI_TRD_VOL_RMB                            --普通账户交易量(人民币)
        ,ORDI_TRD_VOL_RMB_80                         --普通账户交易量(人民币)(不包含申购交易量)			
        ,ORDI_TRD_VOL_RMB_BUYIN                      --普通账户交易量(人民币)_买入
        ,ORDI_TRD_VOL_RMB_SELL                       --普通账户交易量(人民币)_卖出
        ,ORDI_TRD_VOL_RMB_PRCH                       --普通账户交易量(人民币)_申购
        ,CRD_TRD_VOL                                 --信用账户交易量
        ,CRD_TRD_VOL_80                              --信用账户交易量(不包含申购交易量)
        ,CRD_TRD_VOL_BUYIN                           --信用账户交易量_买入
        ,CRD_TRD_VOL_SELL                            --信用账户交易量_卖出
        ,CRD_TRD_VOL_PRCH                            --信用账户交易量_申购
        ,ORDI_TRD_VOL_OTH_RMB                        --普通账户交易量_其他(包括权证等)
        ,ORDI_TRD_VOL_OTH_RMB_BUYIN                  --普通账户交易量_其他(包括权证等)_买入
        ,ORDI_TRD_VOL_OTH_RMB_SELL                   --普通账户交易量_其他(包括权证等)_卖出
        ,TRD_VOL_HA                                  --交易量_沪A主板
        ,TRD_VOL_HA_80                               --交易量_沪A主板(不包含申购交易量)
        ,TRD_VOL_HA_BUYIN                            --交易量_沪A主板_买入
        ,TRD_VOL_HA_SELL                             --交易量_沪A主板_卖出
        ,TRD_VOL_HA_PRCH                             --交易量_沪A主板_申购
        ,ORDI_TRD_VOL_HA                             --普通账户交易量_沪A主板
        ,ORDI_TRD_VOL_HA_80                          --普通账户交易量_沪A主板(不包含申购交易量)
        ,ORDI_TRD_VOL_HA_BUYIN                       --普通账户交易量_沪A主板_买入
        ,ORDI_TRD_VOL_HA_SELL                        --普通账户交易量_沪A主板_卖出
        ,ORDI_TRD_VOL_HA_PRCH                        --普通账户交易量_沪A主板_申购
        ,CRD_TRD_VOL_HA                              --信用账户交易量_沪A主板
        ,CRD_TRD_VOL_HA_80                           --信用账户交易量_沪A主板(不包含申购交易量)
        ,CRD_TRD_VOL_HA_BUYIN                        --信用账户交易量_沪A主板_买入
        ,CRD_TRD_VOL_HA_SELL                         --信用账户交易量_沪A主板_卖出
        ,CRD_TRD_VOL_HA_PRCH                         --信用账户交易量_沪A主板_申购
        ,TRD_VOL_SA                                  --交易量_深A主板
        ,TRD_VOL_SA_80                               --交易量_深A主板(不包含申购交易量)
        ,TRD_VOL_SA_BUYIN                            --交易量_深A主板_买入
        ,TRD_VOL_SA_SELL                             --交易量_深A主板_卖出
        ,TRD_VOL_SA_PRCH                             --交易量_深A主板_申购
        ,ORDI_TRD_VOL_SA                             --普通账户交易量_深A主板
        ,ORDI_TRD_VOL_SA_80                          --普通账户交易量_深A主板(不包含申购交易量)
        ,ORDI_TRD_VOL_SA_BUYIN                       --普通账户交易量_深A主板_买入
        ,ORDI_TRD_VOL_SA_SELL                        --普通账户交易量_深A主板_卖出
        ,ORDI_TRD_VOL_SA_PRCH                        --普通账户交易量_深A主板_申购
        ,CRD_TRD_VOL_SA                              --信用账户交易量_深A主板
        ,CRD_TRD_VOL_SA_80                           --信用账户交易量_深A主板(不包含申购交易量)
        ,CRD_TRD_VOL_SA_BUYIN                        --信用账户交易量_深A主板_买入
        ,CRD_TRD_VOL_SA_SELL                         --信用账户交易量_深A主板_卖出
        ,CRD_TRD_VOL_SA_PRCH                         --信用账户交易量_深A主板_申购
        ,TRD_VOL_SMS                                 --交易量_中小板
        ,TRD_VOL_SMS_80                              --交易量_中小板(不包含申购交易量)
        ,TRD_VOL_SMS_BUYIN                           --交易量_中小板_买入
        ,TRD_VOL_SMS_SELL                            --交易量_中小板_卖出
        ,TRD_VOL_SMS_PRCH                            --交易量_中小板_申购
        ,ORDI_TRD_VOL_SMS                            --普通账户交易量_中小板
        ,ORDI_TRD_VOL_SMS_80                         --普通账户交易量_中小板(不包含申购交易量)
        ,ORDI_TRD_VOL_SMS_BUYIN                      --普通账户交易量_中小板_买入
        ,ORDI_TRD_VOL_SMS_SELL                       --普通账户交易量_中小板_卖出
        ,ORDI_TRD_VOL_SMS_PRCH                       --普通账户交易量_中小板_申购
        ,CRD_TRD_VOL_SMS                             --信用账户交易量_中小板
        ,CRD_TRD_VOL_SMS_80                          --信用账户交易量_中小板(不包含申购交易量)
        ,CRD_TRD_VOL_SMS_BUYIN                       --信用账户交易量_中小板_买入
        ,CRD_TRD_VOL_SMS_SELL                        --信用账户交易量_中小板_卖出
        ,CRD_TRD_VOL_SMS_PRCH                        --信用账户交易量_中小板_申购
        ,TRD_VOL_GEM                                 --交易量_创业板
        ,TRD_VOL_GEM_80                              --交易量_创业板(不包含申购交易量)
        ,TRD_VOL_GEM_BUYIN                           --交易量_创业板_买入
        ,TRD_VOL_GEM_SELL                            --交易量_创业板_卖出
        ,TRD_VOL_GEM_PRCH                            --交易量_创业板_申购
        ,ORDI_TRD_VOL_GEM                            --普通账户交易量_创业板
        ,ORDI_TRD_VOL_GEM_80                         --普通账户交易量_创业板(不包含申购交易量)
        ,ORDI_TRD_VOL_GEM_BUYIN                      --普通账户交易量_创业板_买入
        ,ORDI_TRD_VOL_GEM_SELL                       --普通账户交易量_创业板_卖出
        ,ORDI_TRD_VOL_GEM_PRCH                       --普通账户交易量_创业板_申购
        ,CRD_TRD_VOL_GEM                             --信用账户交易量_创业板
        ,CRD_TRD_VOL_GEM_80                          --信用账户交易量_创业板(不包含申购交易量)
        ,CRD_TRD_VOL_GEM_BUYIN                       --信用账户交易量_创业板_买入
        ,CRD_TRD_VOL_GEM_SELL                        --信用账户交易量_创业板_卖出
        ,CRD_TRD_VOL_GEM_PRCH                        --信用账户交易量_创业板_申购
        ,ORDI_TRD_VOL_HB_USD                         --普通账户交易量_沪B_美元
        ,ORDI_TRD_VOL_HB_USD_BUYIN                   --普通账户交易量_沪B_美元_买入
        ,ORDI_TRD_VOL_HB_USD_SELL                    --普通账户交易量_沪B_美元_卖出
        ,ORDI_TRD_VOL_SB_HKD                         --普通账户交易量_深B_港币
        ,ORDI_TRD_VOL_SB_HKD_BUYIN                   --普通账户交易量_深B_港币_买入
        ,ORDI_TRD_VOL_SB_HKD_SELL                    --普通账户交易量_深B_港币_卖出
        ,ORDI_TRD_VOL_HK                             --普通账户交易量_沪港通
        ,ORDI_TRD_VOL_HK_BUYIN                       --普通账户交易量_沪港通_买入
        ,ORDI_TRD_VOL_HK_SELL                        --普通账户交易量_沪港通_卖出
        ,ORDI_TRD_VOL_SK                             --普通账户交易量_深港通
        ,ORDI_TRD_VOL_SK_BUYIN                       --普通账户交易量_深港通_买入
        ,ORDI_TRD_VOL_SK_SELL                        --普通账户交易量_深港通_卖出
        ,ORDI_TRD_VOL_TA                             --普通账户交易量_三板A股
        ,ORDI_TRD_VOL_TA_BUYIN                       --普通账户交易量_三板A股_买入
        ,ORDI_TRD_VOL_TA_SELL                        --普通账户交易量_三板A股_卖出
        ,ORDI_TRD_VOL_TU_USD                         --普通账户交易量_三板B股_美元
        ,ORDI_TRD_VOL_TU_USD_BUYIN                   --普通账户交易量_三板B股_美元_买入
        ,ORDI_TRD_VOL_TU_USD_SELL                    --普通账户交易量_三板B股_美元_卖出
        ,ORDI_TRD_VOL_REPO                           --普通账户交易量_回购
        ,ORDI_TRD_VOL_REPO_BUYIN                     --普通账户交易量_回购_买入
        ,ORDI_TRD_VOL_REPO_SELL                      --普通账户交易量_回购_卖出
        ,ORDI_TRD_VOL_EXG_FND                        --普通账户交易量_场内基金
        ,ORDI_TRD_VOL_EXG_FND_BUYIN                  --普通账户交易量_场内基金_买入
        ,ORDI_TRD_VOL_EXG_FND_SELL                   --普通账户交易量_场内基金_卖出
        ,ORDI_TRD_VOL_CLS_FND                        --普通账户交易量_封闭式基金
        ,ORDI_TRD_VOL_CLS_FND_BUYIN                  --普通账户交易量_封闭式基金_买入
        ,ORDI_TRD_VOL_CLS_FND_SELL                   --普通账户交易量_封闭式基金_卖出
        ,ORDI_TRD_VOL_ETF_FND                        --普通账户交易量_ETF
        ,ORDI_TRD_VOL_ETF_FND_BUYIN                  --普通账户交易量_ETF_买入
        ,ORDI_TRD_VOL_ETF_FND_SELL                   --普通账户交易量_ETF_卖出
        ,ORDI_TRD_VOL_OPN_FND                        --普通账户交易量_开放式
        ,ORDI_TRD_VOL_OPN_FND_BUYIN                  --普通账户交易量_开放式_买入
        ,ORDI_TRD_VOL_OPN_FND_SELL                   --普通账户交易量_开放式_卖出
        ,ORDI_TRD_VOL_LOF_FND                        --普通账户交易量_LOF
        ,ORDI_TRD_VOL_LOF_FND_BUYIN                  --普通账户交易量_LOF_买入
        ,ORDI_TRD_VOL_LOF_FND_SELL                   --普通账户交易量_LOF_卖出
        ,ORDI_TRD_VOL_FOF_FND                        --普通账户交易量_FOF
        ,ORDI_TRD_VOL_FOF_FND_BUYIN                  --普通账户交易量_FOF_买入
        ,ORDI_TRD_VOL_FOF_FND_SELL                   --普通账户交易量_FOF_卖出
        ,CRD_TRD_VOL_EXG_FND                         --信用账户交易量_场内基金
        ,CRD_TRD_VOL_EXG_FND_BUYIN                   --信用账户交易量_场内基金_买入
        ,CRD_TRD_VOL_EXG_FND_SELL                    --信用账户交易量_场内基金_卖出
        ,CRD_TRD_VOL_CLS_FND                         --信用账户交易量_封闭式基金
        ,CRD_TRD_VOL_CLS_FND_BUYIN                   --信用账户交易量_封闭式基金_买入
        ,CRD_TRD_VOL_CLS_FND_SELL                    --信用账户交易量_封闭式基金_卖出
        ,CRD_TRD_VOL_ETF_FND                         --信用账户交易量_ETF
        ,CRD_TRD_VOL_ETF_FND_BUYIN                   --信用账户交易量_ETF_买入
        ,CRD_TRD_VOL_ETF_FND_SELL                    --信用账户交易量_ETF_卖出
        ,CRD_TRD_VOL_OPN_FND                         --信用账户交易量_开放式
        ,CRD_TRD_VOL_OPN_FND_BUYIN                   --信用账户交易量_开放式_买入
        ,CRD_TRD_VOL_OPN_FND_SELL                    --信用账户交易量_开放式_卖出
        ,CRD_TRD_VOL_LOF_FND                         --信用账户交易量_LOF
        ,CRD_TRD_VOL_LOF_FND_BUYIN                   --信用账户交易量_LOF_买入
        ,CRD_TRD_VOL_LOF_FND_SELL                    --信用账户交易量_LOF_卖出
        ,CRD_TRD_VOL_FOF_FND                         --信用账户交易量_FOF
        ,CRD_TRD_VOL_FOF_FND_BUYIN                   --信用账户交易量_FOF_买入
        ,CRD_TRD_VOL_FOF_FND_SELL                    --信用账户交易量_FOF_卖出
        ,ORDI_TRD_VOL_BOND                           --普通账户交易量_债券
        ,ORDI_TRD_VOL_BOND_80                        --普通账户交易量_债券(不包含债券的申购)
        ,ORDI_TRD_VOL_BOND_BUYIN                     --普通账户交易量_债券_买入
        ,ORDI_TRD_VOL_BOND_SELL                      --普通账户交易量_债券_卖出
        ,ORDI_TRD_VOL_BOND_PRCH                      --普通账户交易量_债券_申购
        ,CRD_TRD_VOL_BOND                            --信用账户交易量_债券	
        ,CRD_TRD_VOL_BOND_80                         --信用账户交易量_债券(不包含债券的申购)	
        ,CRD_TRD_VOL_BOND_BUYIN                      --信用账户交易量_债券_买入
        ,CRD_TRD_VOL_BOND_SELL                       --信用账户交易量_债券_卖出
        ,CRD_TRD_VOL_BOND_PRCH                       --信用账户交易量_债券_申购
        ,ORDI_TRD_ITMS                               --普通账户交易笔数
        ,ORDI_TRD_ITMS_80                            --普通账户交易笔数(不包含申购的笔数)
        ,CRD_TRD_ITMS                                --信用账户交易笔数
        ,CRD_TRD_ITMS_80                             --信用账户交易笔数(不包含申购的笔数)
        ,ORDI_TRD_ITMS_OTH                           --普通账户交易笔数_其他(包括权证等)
        ,TRD_ITMS_HA                                 --交易笔数_沪A主板
        ,TRD_ITMS_HA_80                              --交易笔数_沪A主板(不包含申购的笔数)
        ,ORDI_TRD_ITMS_HA                            --普通账户交易笔数_沪A主板
        ,ORDI_TRD_ITMS_HA_80                         --普通账户交易笔数_沪A主板(不包含申购的笔数)
        ,CRD_TRD_ITMS_HA                             --信用账户交易笔数_沪A主板
        ,CRD_TRD_ITMS_HA_80                          --信用账户交易笔数_沪A主板(不包含申购的笔数)
        ,TRD_ITMS_SA                                 --交易笔数_深A主板
        ,TRD_ITMS_SA_80                              --交易笔数_深A主板(不包含申购的笔数)
        ,ORDI_TRD_ITMS_SA                            --普通账户交易笔数_深A主板
        ,ORDI_TRD_ITMS_SA_80                         --普通账户交易笔数_深A主板(不包含申购的笔数)
        ,CRD_TRD_ITMS_SA                             --信用账户交易笔数_深A主板
        ,TRD_ITMS_SMS                                --交易笔数_中小板
        ,TRD_ITMS_SMS_80                             --交易笔数_中小板(不包含申购的笔数)
        ,ORDI_TRD_ITMS_SMS                           --普通账户交易笔数_中小板
        ,ORDI_TRD_ITMS_SMS_80                        --普通账户交易笔数_中小板(不包含申购的笔数)
        ,CRD_TRD_ITMS_SMS                            --信用账户交易笔数_中小板
        ,CRD_TRD_ITMS_SMS_80                         --信用账户交易笔数_中小板(不包含申购的笔数)
        ,TRD_ITMS_GEM                                --交易笔数_创业板
        ,TRD_ITMS_GEM_80                             --交易笔数_创业板(不包含申购的笔数)
        ,ORDI_TRD_ITMS_GEM                           --普通账户交易笔数_创业板
        ,ORDI_TRD_ITMS_GEM_80                        --普通账户交易笔数_创业板(不包含申购的笔数)
        ,CRD_TRD_ITMS_GEM                            --信用账户交易笔数_创业板
        ,CRD_TRD_ITMS_GEM_80                         --信用账户交易笔数_创业板(不包含申购的笔数)
        ,ORDI_TRD_ITMS_HB                            --普通账户交易笔数_沪B
        ,ORDI_TRD_ITMS_SB                            --普通账户交易笔数_深B
        ,ORDI_TRD_ITMS_HK                            --普通账户交易笔数_沪港通
        ,ORDI_TRD_ITMS_SK                            --普通账户交易笔数_深港通
        ,ORDI_TRD_ITMS_TA                            --普通账户交易笔数_三板A股
        ,ORDI_TRD_ITMS_TU                            --普通账户交易笔数_三板B股
        ,ORDI_TRD_ITMS_REPO                          --普通账户交易笔数_回购
        ,ORDI_TRD_ITMS_EXG_FND                       --普通账户交易笔数_场内基金
        ,ORDI_TRD_ITMS_CLS_FND                       --普通账户交易笔数_封闭式基金
        ,ORDI_TRD_ITMS_ETF_FND                       --普通账户交易笔数_ETF
        ,ORDI_TRD_ITMS_OPN_FND                       --普通账户交易笔数_开放式
        ,ORDI_TRD_ITMS_LOF_FND                       --普通账户交易笔数_LOF
        ,ORDI_TRD_ITMS_FOF_FND                       --普通账户交易笔数_FOF
        ,CRD_TRD_ITMS_EXG_FND                        --信用账户交易笔数_场内基金
        ,CRD_TRD_ITMS_CLS_FND                        --信用账户交易笔数_封闭式基金
        ,CRD_TRD_ITMS_ETF_FND                        --信用账户交易笔数_ETF
        ,CRD_TRD_ITMS_OPN_FND                        --信用账户交易笔数_开放式
        ,CRD_TRD_ITMS_LOF_FND                        --信用账户交易笔数_LOF
        ,CRD_TRD_ITMS_FOF_FND                        --信用账户交易笔数_FOF
        ,ORDI_TRD_ITMS_BOND                          --普通账户交易笔数_债券
        ,ORDI_TRD_ITMS_BOND_80                       --普通账户交易笔数_债券(不包含债券申购)
        ,CRD_TRD_ITMS_BOND                           --信用账户交易笔数_债券	
        ,CRD_TRD_ITMS_BOND_80                        --信用账户交易笔数_债券(不包含债券申购)	
        ,WRNT_TRD_CNTS                               --期权账户交易张数
        ,WRNT_TRD_VOL                                --期权账户交易量
        ,WRNT_S1_INCM                                --期权账户佣金收入
        ,WRNT_NET_S1_INCM                            --期权账户净佣金收入
        ,WRNT_TRD_FEE                                --期权账户交易费用
        ,WRNT_TRD_ITMS                               --期权账户交易笔数
        ,WRNT_TRD_VOL_BUYIN                          --期权账户交易量_买入
        ,WRNT_TRD_VOL_SELL                           --期权账户交易量_卖出
        ,WRNT_TRD_CNTS_BUYIN                         --期权账户交易张数_买入
        ,WRNT_TRD_CNTS_SELL                          --期权账户交易张数_卖出
        ,WRNT_TRD_VOL_BUYIN_O                        --期权账户交易量_买入_开仓
        ,WRNT_TRD_VOL_BUYIN_C                        --期权账户交易量_买入_平仓
        ,WRNT_TRD_VOL_SELL_O                         --期权账户交易量_卖出_开仓
        ,WRNT_TRD_VOL_SELL_C                         --期权账户交易量_卖出_平仓
        ,WRNT_TRD_CNTS_BUYIN_O                       --期权账户交易张数_买入_开仓
        ,WRNT_TRD_CNTS_BUYIN_C                       --期权账户交易张数_买入_平仓
        ,WRNT_TRD_CNTS_SELL_O                        --期权账户交易张数_卖出_开仓
        ,WRNT_TRD_CNTS_SELL_C                        --期权账户交易张数_卖出_平仓
		,TOT_S1                                      --总佣金
		,TOT_NET_S1                                  --总净佣金
		,TOT_INCM_OFFER                              --总收入贡献
		,ORDI_S1_INCM_HB_RMB                         --普通账户佣金收入_沪B_人民币
		,ORDI_S1_INCM_SB_RMB                         --普通账户佣金收入_深B_人民币
		,ORDI_S1_INCM_TU_RMB                         --普通账户佣金收入_三板B股_人民币
		,ORDI_NET_S1_INCM_HB_RMB                     --普通账户净佣金收入_沪B_人民币
		,ORDI_NET_S1_INCM_SB_RMB                     --普通账户净佣金收入_深B_人民币
		,ORDI_NET_S1_INCM_TU_RMB                     --普通账户净佣金收入_三板B股_人民币
		,ORDI_TRD_FEE_HB_RMB                         --普通账户交易费用_沪B_人民币
		,ORDI_TRD_FEE_SB_RMB                         --普通账户交易费用_深B_人民币
		,ORDI_TRD_FEE_TU_RMB                         --普通账户交易费用_三板B股_人民币
		,ORDI_TRD_VOL_HB_RMB                         --普通账户交易量_沪B_人民币
		,ORDI_TRD_VOL_HB_RMB_BUYIN                   --普通账户交易量_沪B_人民币_买入
		,ORDI_TRD_VOL_HB_RMB_SELL                    --普通账户交易量_沪B_人民币_卖出
		,ORDI_TRD_VOL_SB_RMB                         --普通账户交易量_深B_人民币
		,ORDI_TRD_VOL_SB_RMB_BUYIN                   --普通账户交易量_深B_人民币_买入
		,ORDI_TRD_VOL_SB_RMB_SELL                    --普通账户交易量_深B_人民币_卖出
		,ORDI_TRD_VOL_TU_RMB                         --普通账户交易量_三板B股_人民币
		,ORDI_TRD_VOL_TU_RMB_BUYIN                   --普通账户交易量_三板B股_人民币_买入
		,ORDI_TRD_VOL_TU_RMB_SELL                    --普通账户交易量_三板B股_人民币_卖出
		,ETL_DT
	    ,ORDI_S1_INCM_STIB_AK                             --普通账户佣金收入_AK科创板
		,CRD_S1_INCM_STIB_AK                              --信用账户佣金收入_AK科创板
		,S1_INCM_STIB_AK                                  --佣金收入_AK科创板
        ,ORDI_S1_INCM_STIB_RK                             --普通账户佣金收入_RK科创CDR
		,CRD_S1_INCM_STIB_RK                              --信用账户佣金收入_RK科创CDR
		,S1_INCM_STIB_RK                                  --佣金收入_RK科创CDR
		,ORDI_NET_S1_INCM_STIB_AK                         --普通账户净佣金收入_AK科创板
		,CRD_NET_S1_INCM_STIB_AK                          --信用账户净佣金收入_AK科创板
		,NET_S1_INCM_STIB_AK                              --净佣金收入_AK科创板
        ,ORDI_NET_S1_INCM_STIB_RK                         --普通账户净佣金收入_RK科创CDR
		,CRD_NET_S1_INCM_STIB_RK                          --信用账户净佣金收入_RK科创CDR
		,NET_S1_INCM_STIB_RK                              --净佣金收入_RK科创CDR
		,ORDI_TRD_FEE_STIB_AK                             --普通账户交易费用_AK科创板
		,CRD_TRD_FEE_STIB_AK                              --信用账户交易费用_AK科创板
		,TRD_FEE_STIB_AK                                  --交易费用_AK科创板
        ,ORDI_TRD_FEE_STIB_RK                             --普通账户交易费用_RK科创CDR
		,CRD_TRD_FEE_STIB_RK                              --信用账户交易费用_RK科创CDR
		,TRD_FEE_STIB_RK                                  --交易费用_RK科创CDR		
		,TRD_VOL_AK                                       --交易量_AK科创板
        ,TRD_VOL_AK_80                                    --交易量_AK科创板(不包含申购交易量)
        ,TRD_VOL_AK_BUYIN                                 --交易量_AK科创板_买入
        ,TRD_VOL_AK_SELL                                  --交易量_AK科创板_卖出
        ,TRD_VOL_AK_PRCH                                  --交易量_AK科创板_申购
		,ORDI_TRD_VOL_AK                                  --普通账户交易量_AK科创板
        ,ORDI_TRD_VOL_AK_80                               --普通账户交易量_AK科创板(不包含申购交易量)
        ,ORDI_TRD_VOL_AK_BUYIN                            --普通账户交易量_AK科创板_买入
        ,ORDI_TRD_VOL_AK_SELL                             --普通账户交易量_AK科创板_卖出
        ,ORDI_TRD_VOL_AK_PRCH                             --普通账户交易量_AK科创板_申购
        ,CRD_TRD_VOL_AK                                   --信用账户交易量_AK科创板
        ,CRD_TRD_VOL_AK_80                                --信用账户交易量_AK科创板(不包含申购交易量)
        ,CRD_TRD_VOL_AK_BUYIN                             --信用账户交易量_AK科创板_买入
        ,CRD_TRD_VOL_AK_SELL                              --信用账户交易量_AK科创板_卖出
        ,CRD_TRD_VOL_AK_PRCH                              --信用账户交易量_AK科创板_申购		
		,TRD_VOL_RK                                       --交易量_RK科创CDR
        ,TRD_VOL_RK_80                                    --交易量_RK科创CDR(不包含申购交易量)
        ,TRD_VOL_RK_BUYIN                                 --交易量_RK科创CDR_买入
        ,TRD_VOL_RK_SELL                                  --交易量_RK科创CDR_卖出
        ,TRD_VOL_RK_PRCH                                  --交易量_RK科创CDR_申购
		,ORDI_TRD_VOL_RK                                  --普通账户交易量_RK科创CDR
        ,ORDI_TRD_VOL_RK_80                               --普通账户交易量_RK科创CDR(不包含申购交易量)
        ,ORDI_TRD_VOL_RK_BUYIN                            --普通账户交易量_RK科创CDR_买入
        ,ORDI_TRD_VOL_RK_SELL                             --普通账户交易量_RK科创CDR_卖出
        ,ORDI_TRD_VOL_RK_PRCH                             --普通账户交易量_RK科创CDR_申购
        ,CRD_TRD_VOL_RK                                   --信用账户交易量_RK科创CDR
        ,CRD_TRD_VOL_RK_80                                --信用账户交易量_RK科创CDR(不包含申购交易量)
        ,CRD_TRD_VOL_RK_BUYIN                             --信用账户交易量_RK科创CDR_买入
        ,CRD_TRD_VOL_RK_SELL                              --信用账户交易量_RK科创CDR_卖出
        ,CRD_TRD_VOL_RK_PRCH                              --信用账户交易量_RK科创CDR_申购		
		,TRD_ITMS_STIB_AK                                 --交易笔数_AK科创板
        ,TRD_ITMS_STIB_AK_80                              --交易笔数_AK科创板(不包含申购的笔数)
		,ORDI_TRD_ITMS_STIB_AK                            --普通账户交易笔数_AK科创板
        ,ORDI_TRD_ITMS_STIB_AK_80                         --普通账户交易笔数_AK科创板(不包含申购的笔数)
        ,CRD_TRD_ITMS_STIB_AK                             --信用账户交易笔数_AK科创板
        ,CRD_TRD_ITMS_STIB_AK_80                          --信用账户交易笔数_AK科创板(不包含申购的笔数)
	    ,TRD_ITMS_STIB_RK                                 --交易笔数_RK科创CDR
        ,TRD_ITMS_STIB_RK_80                              --交易笔数_RK科创CDR(不包含申购的笔数)
		,ORDI_TRD_ITMS_STIB_RK                            --普通账户交易笔数_RK科创CDR
        ,ORDI_TRD_ITMS_STIB_RK_80                         --普通账户交易笔数_RK科创CDR(不包含申购的笔数)
        ,CRD_TRD_ITMS_STIB_RK                             --信用账户交易笔数_RK科创CDR
        ,CRD_TRD_ITMS_STIB_RK_80                          --信用账户交易笔数_RK科创CDR(不包含申购的笔数)
		,CRD_CRD_TRD_VOL                         --信用账户信用交易量
        ,CRD_CRD_TRD_S1                          --信用账户信用交易佣金
        ,CRD_CRD_TRD_NET_S1                      --信用账户信用交易净佣金
        ,CRD_CRD_TRD_FEE                         --信用账户信用交易费用
        ,CRD_CRD_TRD_ITMS                        --信用账户信用交易笔数
        ,NEW_TA_TRD_VOL                          --新三板交易量
        ,NEW_TA_TRD_S1                           --新三板交易佣金
        ,NEW_TA_TRD_NET_S1                       --新三板交易净佣金
        ,NEW_TA_TRD_FEE                          --新三板交易费用
        ,NEW_TA_TRD_ITMS                         --新三板交易笔数
        ,CLS_FND_TRD_VOL                         --分级基金交易量
        ,CLS_FND_TRD_S1                          --分级基金交易佣金
        ,CLS_FND_TRD_NET_S1                      --分级基金交易净佣金
        ,CLS_FND_TRD_FEE                         --分级基金交易费用
        ,CLS_FND_TRD_ITMS                        --分级基金交易笔数
		,S1_ASTK                                           --A股佣金
		,S1_BSTK                                           --B股佣金
		,S1_HK_STK                                         --港股佣金
		,S1_EXG_FND                                        --场内基金佣金
		,NET_S1_ASTK                                       --A股净佣金
		,NET_S1_BSTK                                       --B股净佣金
		,NET_S1_HK_STK                                     --港股净佣金
		,NET_S1_EXG_FND                                    --场内基金净佣金		
		,TRD_ITMS_ASTK                                     --A股交易笔数
		,TRD_ITMS_ASTK_BUYIN                               --A股交易笔数_买入
		,TRD_ITMS_ASTK_SELL                                --A股交易笔数_卖出
		,TRD_ITMS_ASTK_PRCH                                --A股交易笔数_申购
		,TRD_ITMS_BSTK                                     --B股交易笔数
		,TRD_ITMS_BSTK_BUYIN                               --B股交易笔数_买入
		,TRD_ITMS_BSTK_SELL                                --B股交易笔数_卖出
		,TRD_ITMS_HK_STK                                   --港股交易笔数
		,TRD_ITMS_HK_STK_BUYIN                             --港股交易笔数_买入
		,TRD_ITMS_HK_STK_SELL                              --港股交易笔数_卖出
		,TRD_ITMS_EXG_FND                                  --场内基金的交易笔数
		,TRD_ITMS_EXG_FND_BUYIN                            --场内基金的交易笔数_买入
		,TRD_ITMS_EXG_FND_SELL                             --场内基金的交易笔数_卖出
		 ,WRNT_TRD_CNTS_SH               --期权账户交易张数(SH)
        ,WRNT_TRD_VOL_SH                        --期权账户交易量(SH)
        ,WRNT_S1_INCM_SH                        --期权账户佣金收入(SH)
        ,WRNT_NET_S1_INCM_SH                    --期权账户净佣金收入(SH)
        ,WRNT_TRD_FEE_SH                        --期权账户交易费用(SH)
        ,WRNT_TRD_ITMS_SH                       --期权账户交易笔数(SH)
        ,WRNT_TRD_VOL_BUYIN_SH                  --期权账户交易量_买入(SH)
        ,WRNT_TRD_VOL_SELL_SH                   --期权账户交易量_卖出(SH)
        ,WRNT_TRD_CNTS_BUYIN_SH                 --期权账户交易张数_买入(SH)
        ,WRNT_TRD_CNTS_SELL_SH                  --期权账户交易张数_卖出(SH)	 					
        ,WRNT_TRD_VOL_BUYIN_O_SH                --期权账户交易量_买入_开仓(SH)
        ,WRNT_TRD_VOL_BUYIN_C_SH                --期权账户交易量_买入_平仓(SH)
        ,WRNT_TRD_VOL_SELL_O_SH                 --期权账户交易量_卖出_开仓(SH)
        ,WRNT_TRD_VOL_SELL_C_SH                 --期权账户交易量_卖出_平仓(SH)
        ,WRNT_TRD_CNTS_BUYIN_O_SH               --期权账户交易张数_买入_开仓(SH)
        ,WRNT_TRD_CNTS_BUYIN_C_SH               --期权账户交易张数_买入_平仓(SH)
        ,WRNT_TRD_CNTS_SELL_O_SH                --期权账户交易张数_卖出_开仓(SH)
        ,WRNT_TRD_CNTS_SELL_C_SH                --期权账户交易张数_卖出_平仓(SH)
        ,WRNT_TRD_CNTS_SZ                       --期权账户交易张数(SZ)
        ,WRNT_TRD_VOL_SZ                        --期权账户交易量(SZ)
        ,WRNT_S1_INCM_SZ                        --期权账户佣金收入(SZ)
        ,WRNT_NET_S1_INCM_SZ                    --期权账户净佣金收入(SZ)
        ,WRNT_TRD_FEE_SZ                        --期权账户交易费用(SZ)
        ,WRNT_TRD_ITMS_SZ                       --期权账户交易笔数(SZ)
        ,WRNT_TRD_VOL_BUYIN_SZ                  --期权账户交易量_买入(SZ)
        ,WRNT_TRD_VOL_SELL_SZ                   --期权账户交易量_卖出(SZ)
        ,WRNT_TRD_CNTS_BUYIN_SZ                 --期权账户交易张数_买入(SZ)
        ,WRNT_TRD_CNTS_SELL_SZ                  --期权账户交易张数_卖出(SZ)	 					 
        ,WRNT_TRD_VOL_BUYIN_O_SZ                --期权账户交易量_买入_开仓(SZ)
        ,WRNT_TRD_VOL_BUYIN_C_SZ                --期权账户交易量_买入_平仓(SZ)
        ,WRNT_TRD_VOL_SELL_O_SZ                 --期权账户交易量_卖出_开仓(SZ)
        ,WRNT_TRD_VOL_SELL_C_SZ                 --期权账户交易量_卖出_平仓(SZ)
        ,WRNT_TRD_CNTS_BUYIN_O_SZ               --期权账户交易张数_买入_开仓(SZ)
        ,WRNT_TRD_CNTS_BUYIN_C_SZ               --期权账户交易张数_买入_平仓(SZ)
        ,WRNT_TRD_CNTS_SELL_O_SZ                --期权账户交易张数_卖出_开仓(SZ)
        ,WRNT_TRD_CNTS_SELL_C_SZ                --期权账户交易张数_卖出_平仓(SZ)
		,ORDI_PRDCT_GL_INT                      --普通账户预计息差收入
		,CRD_PRDCT_GL_INT                       --信用账户预计息差收入
		,ORDI_FCT_GL_INT                      --普通账户实际息差收入
		,CRD_FCT_GL_INT                       --信用账户实际息差收入
)PARTITION(YEAR_MON = CAST(SUBSTR('%d{yyyyMMdd}',1,6) as INT))
 SELECT  t.CUST_NO                                     --客户号                 
        ,t.BRH_NO                                      --营业部编号                         
        ,t.CUST_CGY			                         --客户类别
		,SUM(NVL(a1.CRD_MRGNC_MRGNS_PRDCT_INT,0))                   --信用账户融资融券预计利息    
        ,SUM(NVL(a1.CRD_MRGNC_MRGNS_RTN_INT,0))                     --信用账户融资融券归还利息
		,SUM(NVL(a1.ORDI_PLG_REPO_PRDCT_INT,0))                     --普通账户质押回购预计利息
        ,SUM(NVL(a1.ORDI_PLG_REPO_RTN_INT,0))                       --普通账户质押回购归还利息
		,SUM(NVL(a1.ORDI_S1_INCM_RMB,0))                            --普通账户佣金收入(人民币)
        ,SUM(NVL(a1.CRD_S1_INCM,0))                                 --信用账户佣金收入
        ,SUM(NVL(a1.ORDI_S1_INCM_OTH_RMB,0))                        --普通账户佣金收入_其他(包括权证等)
        ,SUM(NVL(a1.S1_INCM_HA,0))                                  --佣金收入_沪A主板
        ,SUM(NVL(a1.ORDI_S1_INCM_HA,0))                             --普通账户佣金收入_沪A主板
        ,SUM(NVL(a1.CRD_S1_INCM_HA,0))                              --信用账户佣金收入_沪A主板
        ,SUM(NVL(a1.S1_INCM_SA,0))                                  --佣金收入_深A主板
        ,SUM(NVL(a1.ORDI_S1_INCM_SA,0))                             --普通账户佣金收入_深A主板
        ,SUM(NVL(a1.CRD_S1_INCM_SA,0))                              --信用账户佣金收入_深A主板
        ,SUM(NVL(a1.S1_INCM_SMS,0))                                 --佣金收入_中小板
        ,SUM(NVL(a1.ORDI_S1_INCM_SMS,0))                            --普通账户佣金收入_中小板
        ,SUM(NVL(a1.CRD_S1_INCM_SMS,0))                             --信用账户佣金收入_中小板
        ,SUM(NVL(a1.S1_INCM_GEM,0))                                 --佣金收入_创业板
        ,SUM(NVL(a1.ORDI_S1_INCM_GEM,0))                            --普通账户佣金收入_创业板
        ,SUM(NVL(a1.CRD_S1_INCM_GEM,0))                             --信用账户佣金收入_创业板
        ,SUM(NVL(a1.ORDI_S1_INCM_HB_USD,0))                         --普通账户佣金收入_沪B_美元
        ,SUM(NVL(a1.ORDI_S1_INCM_SB_HKD,0))                         --普通账户佣金收入_深B_港币
        ,SUM(NVL(a1.ORDI_S1_INCM_HK,0))                             --普通账户佣金收入_沪港通
        ,SUM(NVL(a1.ORDI_S1_INCM_SK,0))                             --普通账户佣金收入_深港通
        ,SUM(NVL(a1.ORDI_S1_INCM_TA,0))                             --普通账户佣金收入_三板A股
        ,SUM(NVL(a1.ORDI_S1_INCM_TU_USD,0))                         --普通账户佣金收入_三板B股_美元
        ,SUM(NVL(a1.ORDI_S1_INCM_REPO,0))                           --普通账户佣金收入_回购
        ,SUM(NVL(a1.ORDI_S1_INCM_EXG_FND,0))                        --普通账户佣金收入_场内基金收入
        ,SUM(NVL(a1.ORDI_S1_INCM_CLS_FND,0))                        --普通账户佣金收入_封闭式基金
        ,SUM(NVL(a1.ORDI_S1_INCM_ETF_FND,0))                        --普通账户佣金收入_ETF
        ,SUM(NVL(a1.ORDI_S1_INCM_OPN_FND,0))                        --普通账户佣金收入_开放式
        ,SUM(NVL(a1.ORDI_S1_INCM_LOF_FND,0))                        --普通账户佣金收入_LOF
        ,SUM(NVL(a1.ORDI_S1_INCM_FOF_FND,0))                        --普通账户佣金收入_FOF
        ,SUM(NVL(a1.CRD_S1_INCM_EXG_FND,0))                         --信用账户佣金收入_场内基金收入
        ,SUM(NVL(a1.CRD_S1_INCM_CLS_FND,0))                         --信用账户佣金收入_封闭式基金
        ,SUM(NVL(a1.CRD_S1_INCM_ETF_FND,0))                         --信用账户佣金收入_ETF
        ,SUM(NVL(a1.CRD_S1_INCM_OPN_FND,0))                         --信用账户佣金收入_开放式
        ,SUM(NVL(a1.CRD_S1_INCM_LOF_FND,0))                         --信用账户佣金收入_LOF
        ,SUM(NVL(a1.CRD_S1_INCM_FOF_FND,0))                         --信用账户佣金收入_FOF
        ,SUM(NVL(a1.ORDI_S1_INCM_BOND,0))                           --普通账户佣金收入_债券
        ,SUM(NVL(a1.CRD_S1_INCM_BOND,0))                            --信用账户佣金收入_债券
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_RMB,0))                        --普通账户净佣金收入(人民币)
        ,SUM(NVL(a1.CRD_NET_S1_INCM,0))                             --信用账户净佣金收入
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_OTH_RMB,0))                    --普通账户净佣金收入_其他(包括权证等)
        ,SUM(NVL(a1.NET_S1_INCM_HA,0))                              --净佣金收入_沪A主板
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_HA,0))                         --普通账户净佣金收入_沪A主板
        ,SUM(NVL(a1.CRD_NET_S1_INCM_HA,0))                          --信用账户净佣金收入_沪A主板
        ,SUM(NVL(a1.NET_S1_INCM_SA,0))                              --净佣金收入_深A主板
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_SA,0))                         --普通账户净佣金收入_深A主板
        ,SUM(NVL(a1.CRD_NET_S1_INCM_SA,0))                          --信用账户净佣金收入_深A主板
        ,SUM(NVL(a1.NET_S1_INCM_SMS,0))                             --净佣金收入_中小板
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_SMS,0))                        --普通账户净佣金收入_中小板
        ,SUM(NVL(a1.CRD_NET_S1_INCM_SMS,0))                         --信用账户净佣金收入_中小板
        ,SUM(NVL(a1.NET_S1_INCM_GEM,0))                             --净佣金收入_创业板
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_GEM,0))                        --普通账户净佣金收入_创业板
        ,SUM(NVL(a1.CRD_NET_S1_INCM_GEM,0))                         --信用账户净佣金收入_创业板
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_HB_USD,0))                     --普通账户净佣金收入_沪B_美元
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_SB_HKD,0))                     --普通账户净佣金收入_深B_港币
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_HK,0))                         --普通账户净佣金收入_沪港通
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_SK,0))                         --普通账户净佣金收入_深港通
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_TA,0))                         --普通账户净佣金收入_三板A股
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_TU_USD,0))                     --普通账户净佣金收入_三板B股_美元
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_REPO,0))                       --普通账户净佣金收入_回购
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_EXG_FND,0))                    --普通账户净佣金收入_场内基金收入
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_CLS_FND,0))                    --普通账户净佣金收入_封闭式基金
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_ETF_FND,0))                    --普通账户净佣金收入_ETF
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_OPN_FND,0))                    --普通账户净佣金收入_开放式
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_LOF_FND,0))                    --普通账户净佣金收入_LOF
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_FOF_FND,0))                    --普通账户净佣金收入_FOF
        ,SUM(NVL(a1.CRD_NET_S1_INCM_EXG_FND,0))                     --信用账户净佣金收入_场内基金收入
        ,SUM(NVL(a1.CRD_NET_S1_INCM_CLS_FND,0))                     --信用账户净佣金收入_封闭式基金
        ,SUM(NVL(a1.CRD_NET_S1_INCM_ETF_FND,0))                     --信用账户净佣金收入_ETF
        ,SUM(NVL(a1.CRD_NET_S1_INCM_OPN_FND,0))                     --信用账户净佣金收入_开放式
        ,SUM(NVL(a1.CRD_NET_S1_INCM_LOF_FND,0))                     --信用账户净佣金收入_LOF
        ,SUM(NVL(a1.CRD_NET_S1_INCM_FOF_FND,0))                     --信用账户净佣金收入_FOF
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_BOND,0))                       --普通账户净佣金收入_债券
        ,SUM(NVL(a1.CRD_NET_S1_INCM_BOND,0))                        --信用账户净佣金收入_债券	
        ,SUM(NVL(a1.ORDI_TRD_FEE_RMB,0))                            --普通账户交易费用(人民币)
        ,SUM(NVL(a1.CRD_TRD_FEE,0))                                 --信用账户交易费用
        ,SUM(NVL(a1.ORDI_TRD_FEE_OTH_RMB,0))                        --普通账户交易费用_其他(包括权证等)
        ,SUM(NVL(a1.TRD_FEE_HA,0))                                  --交易费用_沪A主板
        ,SUM(NVL(a1.ORDI_TRD_FEE_HA,0))                             --普通账户交易费用_沪A主板
        ,SUM(NVL(a1.CRD_TRD_FEE_HA,0))                              --信用账户交易费用_沪A主板
        ,SUM(NVL(a1.TRD_FEE_SA,0))                                  --交易费用_深A主板
        ,SUM(NVL(a1.ORDI_TRD_FEE_SA,0))                             --普通账户交易费用_深A主板
        ,SUM(NVL(a1.CRD_TRD_FEE_SA,0))                              --信用账户交易费用_深A主板
        ,SUM(NVL(a1.TRD_FEE_SMS,0))                                 --交易费用_中小板
        ,SUM(NVL(a1.ORDI_TRD_FEE_SMS,0))                            --普通账户交易费用_中小板
        ,SUM(NVL(a1.CRD_TRD_FEE_SMS,0))                             --信用账户交易费用_中小板
        ,SUM(NVL(a1.TRD_FEE_GEM,0))                                 --交易费用_创业板
        ,SUM(NVL(a1.ORDI_TRD_FEE_GEM,0))                            --普通账户交易费用_创业板
        ,SUM(NVL(a1.CRD_TRD_FEE_GEM,0))                             --信用账户交易费用_创业板
        ,SUM(NVL(a1.ORDI_TRD_FEE_HB_USD,0))                         --普通账户交易费用_沪B_美元
        ,SUM(NVL(a1.ORDI_TRD_FEE_SB_HKD,0))                         --普通账户交易费用_深B_港币
        ,SUM(NVL(a1.ORDI_TRD_FEE_HK,0))                             --普通账户交易费用_沪港通
        ,SUM(NVL(a1.ORDI_TRD_FEE_SK,0))                             --普通账户交易费用_深港通
        ,SUM(NVL(a1.ORDI_TRD_FEE_TA,0))                             --普通账户交易费用_三板A股
        ,SUM(NVL(a1.ORDI_TRD_FEE_TU_USD,0))                         --普通账户交易费用_三板B股_美元
        ,SUM(NVL(a1.ORDI_TRD_FEE_REPO,0))                           --普通账户交易费用_回购
        ,SUM(NVL(a1.ORDI_TRD_FEE_EXG_FND,0))                        --普通账户交易费用_场内基金
        ,SUM(NVL(a1.ORDI_TRD_FEE_CLS_FND,0))                        --普通账户交易费用_封闭式基金
        ,SUM(NVL(a1.ORDI_TRD_FEE_ETF_FND,0))                        --普通账户交易费用_ETF
        ,SUM(NVL(a1.ORDI_TRD_FEE_OPN_FND,0))                        --普通账户交易费用_开放式
        ,SUM(NVL(a1.ORDI_TRD_FEE_LOF_FND,0))                        --普通账户交易费用_LOF
        ,SUM(NVL(a1.ORDI_TRD_FEE_FOF_FND,0))                        --普通账户交易费用_FOF
        ,SUM(NVL(a1.CRD_TRD_FEE_EXG_FND,0))                         --信用账户交易费用_场内基金
        ,SUM(NVL(a1.CRD_TRD_FEE_CLS_FND,0))                         --信用账户交易费用_封闭式基金
        ,SUM(NVL(a1.CRD_TRD_FEE_ETF_FND,0))                         --信用账户交易费用_ETF
        ,SUM(NVL(a1.CRD_TRD_FEE_OPN_FND,0))                         --信用账户交易费用_开放式
        ,SUM(NVL(a1.CRD_TRD_FEE_LOF_FND,0))                         --信用账户交易费用_LOF
        ,SUM(NVL(a1.CRD_TRD_FEE_FOF_FND,0))                         --信用账户交易费用_FOF
        ,SUM(NVL(a1.ORDI_TRD_FEE_BOND,0))                           --普通账户交易费用_债券
        ,SUM(NVL(a1.CRD_TRD_FEE_BOND,0))                            --信用账户交易费用_债券					 
        ,SUM(NVL(a1.PROD_CMSN_FEE,0))                               --产品手续费
        ,SUM(NVL(a1.AGN_FND_CMSN_FEE,0))                            --代销基金手续费
        ,SUM(NVL(a1.GS_PROD_CMSN_FEE,0))                            --公司产品手续费
        ,SUM(NVL(a1.GJ_PROD_CMSN_FEE,0))                            --国君产品手续费
        ,SUM(NVL(a1.OTC_PROD_CMSN_FEE,0))                           --OTC产品手续费
        ,SUM(NVL(a1.PROD_SCRP_AMT,0))                               --产品认购金额		
        ,SUM(NVL(a1.PROD_PRCH_AMT,0))                               --产品申购金额	
        ,SUM(NVL(a1.PROD_FIXINV_AMT,0))                             --产品定投金额	
        ,SUM(NVL(a1.PROD_RDMPT_AMT,0))                              --产品赎回金额
        ,SUM(NVL(a1.AGN_FND_SCRP_AMT,0))                            --代销基金认购金额
        ,SUM(NVL(a1.AGN_FND_PRCH_AMT,0))                            --代销基金申购金额
        ,SUM(NVL(a1.AGN_FND_FIXINV_AMT,0))                          --代销基金定投金额
        ,SUM(NVL(a1.AGN_FND_RDMPT_AMT,0))                           --代销基金赎回金额
        ,SUM(NVL(a1.GS_PROD_SCRP_AMT,0))                            --公司产品认购金额
        ,SUM(NVL(a1.GS_PROD_PRCH_AMT,0))                            --公司产品申购金额
        ,SUM(NVL(a1.GS_PROD_FIXINV_AMT,0))                          --公司产品定投金额
        ,SUM(NVL(a1.GS_PROD_RDMPT_AMT,0))                           --公司产品赎回金额
        ,SUM(NVL(a1.GJ_PROD_SCRP_AMT,0))                            --国君产品认购金额
        ,SUM(NVL(a1.GJ_PROD_PRCH_AMT,0))                            --国君产品申购金额
        ,SUM(NVL(a1.GJ_PROD_FIXINV_AMT,0))                          --国君产品定投金额
        ,SUM(NVL(a1.GJ_PROD_RDMPT_AMT,0))                           --国君产品赎回金额
        ,SUM(NVL(a1.BANK_PROD_SCRP_AMT,0))                          --银行产品认购金额
        ,SUM(NVL(a1.BANK_PROD_PRCH_AMT,0))                          --银行产品申购金额		
        ,SUM(NVL(a1.BANK_PROD_RDMPT_AMT,0))                         --银行产品赎回金额	
        ,SUM(NVL(a1.OTC_PROD_SCRP_AMT,0))                           --OTC产品认购金额
        ,SUM(NVL(a1.OTC_PROD_PRCH_AMT,0))                           --OTC产品申购金额		
        ,SUM(NVL(a1.OTC_PROD_RDMPT_AMT,0))                          --OTC产品赎回金额			
        ,SUM(NVL(a1.AGN_FND_SCRP_ITMS,0))                           --代销基金认购笔数
        ,SUM(NVL(a1.AGN_FND_PRCH_ITMS,0))                           --代销基金申购笔数
        ,SUM(NVL(a1.AGN_FND_FIXINV_ITMS,0))                         --代销基金定投笔数
        ,SUM(NVL(a1.AGN_FND_RDMPT_ITMS,0))                          --代销基金赎回笔数
        ,SUM(NVL(a1.GS_PROD_SCRP_ITMS,0))                           --公司产品认购笔数
        ,SUM(NVL(a1.GS_PROD_PRCH_ITMS,0))                           --公司产品申购笔数
        ,SUM(NVL(a1.GS_PROD_FIXINV_ITMS,0))                         --公司产品定投笔数
        ,SUM(NVL(a1.GS_PROD_RDMPT_ITMS,0))                          --公司产品赎回笔数
        ,SUM(NVL(a1.GJ_PROD_SCRP_ITMS,0))                           --国君产品认购笔数
        ,SUM(NVL(a1.GJ_PROD_PRCH_ITMS,0))                           --国君产品申购笔数
        ,SUM(NVL(a1.GJ_PROD_FIXINV_ITMS,0))                         --国君产品定投笔数
        ,SUM(NVL(a1.GJ_PROD_RDMPT_ITMS,0))                          --国君产品赎回笔数
        ,SUM(NVL(a1.BANK_PROD_SCRP_ITMS,0))                         --银行产品认购笔数
        ,SUM(NVL(a1.BANK_PROD_PRCH_ITMS,0))                         --银行产品申购笔数		
        ,SUM(NVL(a1.BANK_PROD_RDMPT_ITMS,0))                        --银行产品赎回笔数
        ,SUM(NVL(a1.OTC_PROD_SCRP_ITMS,0))                          --OTC产品认购笔数
        ,SUM(NVL(a1.OTC_PROD_PRCH_ITMS,0))                          --OTC产品申购笔数		
        ,SUM(NVL(a1.OTC_PROD_RDMPT_ITMS,0))                         --OTC产品赎回笔数			 
        ,SUM(NVL(a1.ORDI_TRD_VOL_RMB,0))                            --普通账户交易量(人民币)
        ,SUM(NVL(a1.ORDI_TRD_VOL_RMB_80,0))                         --普通账户交易量(人民币)(不包含申购交易量)			
        ,SUM(NVL(a1.ORDI_TRD_VOL_RMB_BUYIN,0))                      --普通账户交易量(人民币)_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_RMB_SELL,0))                       --普通账户交易量(人民币)_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_RMB_PRCH,0))                       --普通账户交易量(人民币)_申购
        ,SUM(NVL(a1.CRD_TRD_VOL,0))                                 --信用账户交易量
        ,SUM(NVL(a1.CRD_TRD_VOL_80,0))                              --信用账户交易量(不包含申购交易量)
        ,SUM(NVL(a1.CRD_TRD_VOL_BUYIN,0))                           --信用账户交易量_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_SELL,0))                            --信用账户交易量_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_PRCH,0))                            --信用账户交易量_申购
        ,SUM(NVL(a1.ORDI_TRD_VOL_OTH_RMB,0))                        --普通账户交易量_其他(包括权证等)
        ,SUM(NVL(a1.ORDI_TRD_VOL_OTH_RMB_BUYIN,0))                  --普通账户交易量_其他(包括权证等)_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_OTH_RMB_SELL,0))                   --普通账户交易量_其他(包括权证等)_卖出
        ,SUM(NVL(a1.TRD_VOL_HA,0))                                  --交易量_沪A主板
        ,SUM(NVL(a1.TRD_VOL_HA_80,0))                               --交易量_沪A主板(不包含申购交易量)
        ,SUM(NVL(a1.TRD_VOL_HA_BUYIN,0))                            --交易量_沪A主板_买入
        ,SUM(NVL(a1.TRD_VOL_HA_SELL,0))                             --交易量_沪A主板_卖出
        ,SUM(NVL(a1.TRD_VOL_HA_PRCH,0))                             --交易量_沪A主板_申购
        ,SUM(NVL(a1.ORDI_TRD_VOL_HA,0))                             --普通账户交易量_沪A主板
        ,SUM(NVL(a1.ORDI_TRD_VOL_HA_80,0))                          --普通账户交易量_沪A主板(不包含申购交易量)
        ,SUM(NVL(a1.ORDI_TRD_VOL_HA_BUYIN,0))                       --普通账户交易量_沪A主板_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_HA_SELL,0))                        --普通账户交易量_沪A主板_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_HA_PRCH,0))                        --普通账户交易量_沪A主板_申购
        ,SUM(NVL(a1.CRD_TRD_VOL_HA,0))                              --信用账户交易量_沪A主板
        ,SUM(NVL(a1.CRD_TRD_VOL_HA_80,0))                           --信用账户交易量_沪A主板(不包含申购交易量)
        ,SUM(NVL(a1.CRD_TRD_VOL_HA_BUYIN,0))                        --信用账户交易量_沪A主板_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_HA_SELL,0))                         --信用账户交易量_沪A主板_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_HA_PRCH,0))                         --信用账户交易量_沪A主板_申购
        ,SUM(NVL(a1.TRD_VOL_SA,0))                                  --交易量_深A主板
        ,SUM(NVL(a1.TRD_VOL_SA_80,0))                               --交易量_深A主板(不包含申购交易量)
        ,SUM(NVL(a1.TRD_VOL_SA_BUYIN,0))                            --交易量_深A主板_买入
        ,SUM(NVL(a1.TRD_VOL_SA_SELL,0))                             --交易量_深A主板_卖出
        ,SUM(NVL(a1.TRD_VOL_SA_PRCH,0))                             --交易量_深A主板_申购
        ,SUM(NVL(a1.ORDI_TRD_VOL_SA,0))                             --普通账户交易量_深A主板
        ,SUM(NVL(a1.ORDI_TRD_VOL_SA_80,0))                          --普通账户交易量_深A主板(不包含申购交易量)
        ,SUM(NVL(a1.ORDI_TRD_VOL_SA_BUYIN,0))                       --普通账户交易量_深A主板_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_SA_SELL,0))                        --普通账户交易量_深A主板_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_SA_PRCH,0))                        --普通账户交易量_深A主板_申购
        ,SUM(NVL(a1.CRD_TRD_VOL_SA,0))                              --信用账户交易量_深A主板
        ,SUM(NVL(a1.CRD_TRD_VOL_SA_80,0))                           --信用账户交易量_深A主板(不包含申购交易量)
        ,SUM(NVL(a1.CRD_TRD_VOL_SA_BUYIN,0))                        --信用账户交易量_深A主板_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_SA_SELL,0))                         --信用账户交易量_深A主板_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_SA_PRCH,0))                         --信用账户交易量_深A主板_申购
        ,SUM(NVL(a1.TRD_VOL_SMS,0))                                 --交易量_中小板
        ,SUM(NVL(a1.TRD_VOL_SMS_80,0))                              --交易量_中小板(不包含申购交易量)
        ,SUM(NVL(a1.TRD_VOL_SMS_BUYIN,0))                           --交易量_中小板_买入
        ,SUM(NVL(a1.TRD_VOL_SMS_SELL,0))                            --交易量_中小板_卖出
        ,SUM(NVL(a1.TRD_VOL_SMS_PRCH,0))                            --交易量_中小板_申购
        ,SUM(NVL(a1.ORDI_TRD_VOL_SMS,0))                            --普通账户交易量_中小板
        ,SUM(NVL(a1.ORDI_TRD_VOL_SMS_80,0))                         --普通账户交易量_中小板(不包含申购交易量)
        ,SUM(NVL(a1.ORDI_TRD_VOL_SMS_BUYIN,0))                      --普通账户交易量_中小板_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_SMS_SELL,0))                       --普通账户交易量_中小板_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_SMS_PRCH,0))                       --普通账户交易量_中小板_申购
        ,SUM(NVL(a1.CRD_TRD_VOL_SMS,0))                             --信用账户交易量_中小板
        ,SUM(NVL(a1.CRD_TRD_VOL_SMS_80,0))                          --信用账户交易量_中小板(不包含申购交易量)
        ,SUM(NVL(a1.CRD_TRD_VOL_SMS_BUYIN,0))                       --信用账户交易量_中小板_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_SMS_SELL,0))                        --信用账户交易量_中小板_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_SMS_PRCH,0))                        --信用账户交易量_中小板_申购
        ,SUM(NVL(a1.TRD_VOL_GEM,0))                                 --交易量_创业板
        ,SUM(NVL(a1.TRD_VOL_GEM_80,0))                              --交易量_创业板(不包含申购交易量)
        ,SUM(NVL(a1.TRD_VOL_GEM_BUYIN,0))                           --交易量_创业板_买入
        ,SUM(NVL(a1.TRD_VOL_GEM_SELL,0))                            --交易量_创业板_卖出
        ,SUM(NVL(a1.TRD_VOL_GEM_PRCH,0))                            --交易量_创业板_申购
        ,SUM(NVL(a1.ORDI_TRD_VOL_GEM,0))                            --普通账户交易量_创业板
        ,SUM(NVL(a1.ORDI_TRD_VOL_GEM_80,0))                         --普通账户交易量_创业板(不包含申购交易量)
        ,SUM(NVL(a1.ORDI_TRD_VOL_GEM_BUYIN,0))                      --普通账户交易量_创业板_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_GEM_SELL,0))                       --普通账户交易量_创业板_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_GEM_PRCH,0))                       --普通账户交易量_创业板_申购
        ,SUM(NVL(a1.CRD_TRD_VOL_GEM,0))                             --信用账户交易量_创业板
        ,SUM(NVL(a1.CRD_TRD_VOL_GEM_80,0))                          --信用账户交易量_创业板(不包含申购交易量)
        ,SUM(NVL(a1.CRD_TRD_VOL_GEM_BUYIN,0))                       --信用账户交易量_创业板_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_GEM_SELL,0))                        --信用账户交易量_创业板_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_GEM_PRCH,0))                        --信用账户交易量_创业板_申购
        ,SUM(NVL(a1.ORDI_TRD_VOL_HB_USD,0))                         --普通账户交易量_沪B_美元
        ,SUM(NVL(a1.ORDI_TRD_VOL_HB_USD_BUYIN,0))                   --普通账户交易量_沪B_美元_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_HB_USD_SELL,0))                    --普通账户交易量_沪B_美元_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_SB_HKD,0))                         --普通账户交易量_深B_港币
        ,SUM(NVL(a1.ORDI_TRD_VOL_SB_HKD_BUYIN,0))                   --普通账户交易量_深B_港币_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_SB_HKD_SELL,0))                    --普通账户交易量_深B_港币_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_HK,0))                             --普通账户交易量_沪港通
        ,SUM(NVL(a1.ORDI_TRD_VOL_HK_BUYIN,0))                       --普通账户交易量_沪港通_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_HK_SELL,0))                        --普通账户交易量_沪港通_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_SK,0))                             --普通账户交易量_深港通
        ,SUM(NVL(a1.ORDI_TRD_VOL_SK_BUYIN,0))                       --普通账户交易量_深港通_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_SK_SELL,0))                        --普通账户交易量_深港通_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_TA,0))                             --普通账户交易量_三板A股
        ,SUM(NVL(a1.ORDI_TRD_VOL_TA_BUYIN,0))                       --普通账户交易量_三板A股_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_TA_SELL,0))                        --普通账户交易量_三板A股_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_TU_USD,0))                         --普通账户交易量_三板B股_美元
        ,SUM(NVL(a1.ORDI_TRD_VOL_TU_USD_BUYIN,0))                   --普通账户交易量_三板B股_美元_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_TU_USD_SELL,0))                    --普通账户交易量_三板B股_美元_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_REPO,0))                           --普通账户交易量_回购
        ,SUM(NVL(a1.ORDI_TRD_VOL_REPO_BUYIN,0))                     --普通账户交易量_回购_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_REPO_SELL,0))                      --普通账户交易量_回购_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_EXG_FND,0))                        --普通账户交易量_场内基金
        ,SUM(NVL(a1.ORDI_TRD_VOL_EXG_FND_BUYIN,0))                  --普通账户交易量_场内基金_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_EXG_FND_SELL,0))                   --普通账户交易量_场内基金_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_CLS_FND,0))                        --普通账户交易量_封闭式基金
        ,SUM(NVL(a1.ORDI_TRD_VOL_CLS_FND_BUYIN,0))                  --普通账户交易量_封闭式基金_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_CLS_FND_SELL,0))                   --普通账户交易量_封闭式基金_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_ETF_FND,0))                        --普通账户交易量_ETF
        ,SUM(NVL(a1.ORDI_TRD_VOL_ETF_FND_BUYIN,0))                  --普通账户交易量_ETF_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_ETF_FND_SELL,0))                   --普通账户交易量_ETF_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_OPN_FND,0))                        --普通账户交易量_开放式
        ,SUM(NVL(a1.ORDI_TRD_VOL_OPN_FND_BUYIN,0))                  --普通账户交易量_开放式_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_OPN_FND_SELL,0))                   --普通账户交易量_开放式_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_LOF_FND,0))                        --普通账户交易量_LOF
        ,SUM(NVL(a1.ORDI_TRD_VOL_LOF_FND_BUYIN,0))                  --普通账户交易量_LOF_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_LOF_FND_SELL,0))                   --普通账户交易量_LOF_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_FOF_FND,0))                        --普通账户交易量_FOF
        ,SUM(NVL(a1.ORDI_TRD_VOL_FOF_FND_BUYIN,0))                  --普通账户交易量_FOF_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_FOF_FND_SELL,0))                   --普通账户交易量_FOF_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_EXG_FND,0))                         --信用账户交易量_场内基金
        ,SUM(NVL(a1.CRD_TRD_VOL_EXG_FND_BUYIN,0))                   --信用账户交易量_场内基金_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_EXG_FND_SELL,0))                    --信用账户交易量_场内基金_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_CLS_FND,0))                         --信用账户交易量_封闭式基金
        ,SUM(NVL(a1.CRD_TRD_VOL_CLS_FND_BUYIN,0))                   --信用账户交易量_封闭式基金_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_CLS_FND_SELL,0))                    --信用账户交易量_封闭式基金_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_ETF_FND,0))                         --信用账户交易量_ETF
        ,SUM(NVL(a1.CRD_TRD_VOL_ETF_FND_BUYIN,0))                   --信用账户交易量_ETF_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_ETF_FND_SELL,0))                    --信用账户交易量_ETF_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_OPN_FND,0))                         --信用账户交易量_开放式
        ,SUM(NVL(a1.CRD_TRD_VOL_OPN_FND_BUYIN,0))                   --信用账户交易量_开放式_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_OPN_FND_SELL,0))                    --信用账户交易量_开放式_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_LOF_FND,0))                         --信用账户交易量_LOF
        ,SUM(NVL(a1.CRD_TRD_VOL_LOF_FND_BUYIN,0))                   --信用账户交易量_LOF_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_LOF_FND_SELL,0))                    --信用账户交易量_LOF_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_FOF_FND,0))                         --信用账户交易量_FOF
        ,SUM(NVL(a1.CRD_TRD_VOL_FOF_FND_BUYIN,0))                   --信用账户交易量_FOF_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_FOF_FND_SELL,0))                    --信用账户交易量_FOF_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_BOND,0))                           --普通账户交易量_债券
        ,SUM(NVL(a1.ORDI_TRD_VOL_BOND_80,0))                        --普通账户交易量_债券(不包含债券的申购)
        ,SUM(NVL(a1.ORDI_TRD_VOL_BOND_BUYIN,0))                     --普通账户交易量_债券_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_BOND_SELL,0))                      --普通账户交易量_债券_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_BOND_PRCH,0))                      --普通账户交易量_债券_申购
        ,SUM(NVL(a1.CRD_TRD_VOL_BOND,0))                            --信用账户交易量_债券	
        ,SUM(NVL(a1.CRD_TRD_VOL_BOND_80,0))                         --信用账户交易量_债券(不包含债券的申购)	
        ,SUM(NVL(a1.CRD_TRD_VOL_BOND_BUYIN,0))                      --信用账户交易量_债券_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_BOND_SELL,0))                       --信用账户交易量_债券_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_BOND_PRCH,0))                       --信用账户交易量_债券_申购
        ,SUM(NVL(a1.ORDI_TRD_ITMS,0))                               --普通账户交易笔数
        ,SUM(NVL(a1.ORDI_TRD_ITMS_80,0))                            --普通账户交易笔数(不包含申购的笔数)
        ,SUM(NVL(a1.CRD_TRD_ITMS,0))                                --信用账户交易笔数
        ,SUM(NVL(a1.CRD_TRD_ITMS_80,0))                             --信用账户交易笔数(不包含申购的笔数)
        ,SUM(NVL(a1.ORDI_TRD_ITMS_OTH,0))                           --普通账户交易笔数_其他(包括权证等)
        ,SUM(NVL(a1.TRD_ITMS_HA,0))                                 --交易笔数_沪A主板
        ,SUM(NVL(a1.TRD_ITMS_HA_80,0))                              --交易笔数_沪A主板(不包含申购的笔数)
        ,SUM(NVL(a1.ORDI_TRD_ITMS_HA,0))                            --普通账户交易笔数_沪A主板
        ,SUM(NVL(a1.ORDI_TRD_ITMS_HA_80,0))                         --普通账户交易笔数_沪A主板(不包含申购的笔数)
        ,SUM(NVL(a1.CRD_TRD_ITMS_HA,0))                             --信用账户交易笔数_沪A主板
        ,SUM(NVL(a1.CRD_TRD_ITMS_HA_80,0))                          --信用账户交易笔数_沪A主板(不包含申购的笔数)
        ,SUM(NVL(a1.TRD_ITMS_SA,0))                                 --交易笔数_深A主板
        ,SUM(NVL(a1.TRD_ITMS_SA_80,0))                              --交易笔数_深A主板(不包含申购的笔数)
        ,SUM(NVL(a1.ORDI_TRD_ITMS_SA,0))                            --普通账户交易笔数_深A主板
        ,SUM(NVL(a1.ORDI_TRD_ITMS_SA_80,0))                         --普通账户交易笔数_深A主板(不包含申购的笔数)
        ,SUM(NVL(a1.CRD_TRD_ITMS_SA,0))                             --信用账户交易笔数_深A主板
        ,SUM(NVL(a1.TRD_ITMS_SMS,0))                                --交易笔数_中小板
        ,SUM(NVL(a1.TRD_ITMS_SMS_80,0))                             --交易笔数_中小板(不包含申购的笔数)
        ,SUM(NVL(a1.ORDI_TRD_ITMS_SMS,0))                           --普通账户交易笔数_中小板
        ,SUM(NVL(a1.ORDI_TRD_ITMS_SMS_80,0))                        --普通账户交易笔数_中小板(不包含申购的笔数)
        ,SUM(NVL(a1.CRD_TRD_ITMS_SMS,0))                            --信用账户交易笔数_中小板
        ,SUM(NVL(a1.CRD_TRD_ITMS_SMS_80,0))                         --信用账户交易笔数_中小板(不包含申购的笔数)
        ,SUM(NVL(a1.TRD_ITMS_GEM,0))                                --交易笔数_创业板
        ,SUM(NVL(a1.TRD_ITMS_GEM_80,0))                             --交易笔数_创业板(不包含申购的笔数)
        ,SUM(NVL(a1.ORDI_TRD_ITMS_GEM,0))                           --普通账户交易笔数_创业板
        ,SUM(NVL(a1.ORDI_TRD_ITMS_GEM_80,0))                        --普通账户交易笔数_创业板(不包含申购的笔数)
        ,SUM(NVL(a1.CRD_TRD_ITMS_GEM,0))                            --信用账户交易笔数_创业板
        ,SUM(NVL(a1.CRD_TRD_ITMS_GEM_80,0))                         --信用账户交易笔数_创业板(不包含申购的笔数)
        ,SUM(NVL(a1.ORDI_TRD_ITMS_HB,0))                            --普通账户交易笔数_沪B
        ,SUM(NVL(a1.ORDI_TRD_ITMS_SB,0))                            --普通账户交易笔数_深B
        ,SUM(NVL(a1.ORDI_TRD_ITMS_HK,0))                            --普通账户交易笔数_沪港通
        ,SUM(NVL(a1.ORDI_TRD_ITMS_SK,0))                            --普通账户交易笔数_深港通
        ,SUM(NVL(a1.ORDI_TRD_ITMS_TA,0))                            --普通账户交易笔数_三板A股
        ,SUM(NVL(a1.ORDI_TRD_ITMS_TU,0))                            --普通账户交易笔数_三板B股
        ,SUM(NVL(a1.ORDI_TRD_ITMS_REPO,0))                          --普通账户交易笔数_回购
        ,SUM(NVL(a1.ORDI_TRD_ITMS_EXG_FND,0))                       --普通账户交易笔数_场内基金
        ,SUM(NVL(a1.ORDI_TRD_ITMS_CLS_FND,0))                       --普通账户交易笔数_封闭式基金
        ,SUM(NVL(a1.ORDI_TRD_ITMS_ETF_FND,0))                       --普通账户交易笔数_ETF
        ,SUM(NVL(a1.ORDI_TRD_ITMS_OPN_FND,0))                       --普通账户交易笔数_开放式
        ,SUM(NVL(a1.ORDI_TRD_ITMS_LOF_FND,0))                       --普通账户交易笔数_LOF
        ,SUM(NVL(a1.ORDI_TRD_ITMS_FOF_FND,0))                       --普通账户交易笔数_FOF
        ,SUM(NVL(a1.CRD_TRD_ITMS_EXG_FND,0))                        --信用账户交易笔数_场内基金
        ,SUM(NVL(a1.CRD_TRD_ITMS_CLS_FND,0))                        --信用账户交易笔数_封闭式基金
        ,SUM(NVL(a1.CRD_TRD_ITMS_ETF_FND,0))                        --信用账户交易笔数_ETF
        ,SUM(NVL(a1.CRD_TRD_ITMS_OPN_FND,0))                        --信用账户交易笔数_开放式
        ,SUM(NVL(a1.CRD_TRD_ITMS_LOF_FND,0))                        --信用账户交易笔数_LOF
        ,SUM(NVL(a1.CRD_TRD_ITMS_FOF_FND,0))                        --信用账户交易笔数_FOF
        ,SUM(NVL(a1.ORDI_TRD_ITMS_BOND,0))                          --普通账户交易笔数_债券
        ,SUM(NVL(a1.ORDI_TRD_ITMS_BOND_80,0))                       --普通账户交易笔数_债券(不包含债券申购)
        ,SUM(NVL(a1.CRD_TRD_ITMS_BOND,0))                           --信用账户交易笔数_债券	
        ,SUM(NVL(a1.CRD_TRD_ITMS_BOND_80,0))                        --信用账户交易笔数_债券(不包含债券申购)	
        ,SUM(NVL(a1.WRNT_TRD_CNTS,0))                               --期权账户交易张数
        ,SUM(NVL(a1.WRNT_TRD_VOL,0))                                --期权账户交易量
        ,SUM(NVL(a1.WRNT_S1_INCM,0))                                --期权账户佣金收入
        ,SUM(NVL(a1.WRNT_NET_S1_INCM,0))                            --期权账户净佣金收入
        ,SUM(NVL(a1.WRNT_TRD_FEE,0))                                --期权账户交易费用
        ,SUM(NVL(a1.WRNT_TRD_ITMS,0))                               --期权账户交易笔数
        ,SUM(NVL(a1.WRNT_TRD_VOL_BUYIN,0))                          --期权账户交易量_买入
        ,SUM(NVL(a1.WRNT_TRD_VOL_SELL,0))                           --期权账户交易量_卖出
        ,SUM(NVL(a1.WRNT_TRD_CNTS_BUYIN,0))                         --期权账户交易张数_买入
        ,SUM(NVL(a1.WRNT_TRD_CNTS_SELL,0))                          --期权账户交易张数_卖出
        ,SUM(NVL(a1.WRNT_TRD_VOL_BUYIN_O,0))                        --期权账户交易量_买入_开仓
        ,SUM(NVL(a1.WRNT_TRD_VOL_BUYIN_C,0))                        --期权账户交易量_买入_平仓
        ,SUM(NVL(a1.WRNT_TRD_VOL_SELL_O,0))                         --期权账户交易量_卖出_开仓
        ,SUM(NVL(a1.WRNT_TRD_VOL_SELL_C,0))                         --期权账户交易量_卖出_平仓
        ,SUM(NVL(a1.WRNT_TRD_CNTS_BUYIN_O,0))                       --期权账户交易张数_买入_开仓
        ,SUM(NVL(a1.WRNT_TRD_CNTS_BUYIN_C,0))                       --期权账户交易张数_买入_平仓
        ,SUM(NVL(a1.WRNT_TRD_CNTS_SELL_O,0))                        --期权账户交易张数_卖出_开仓
        ,SUM(NVL(a1.WRNT_TRD_CNTS_SELL_C,0))                        --期权账户交易张数_卖出_平仓
		,SUM(NVL(a1.TOT_S1,0))                                      --总佣金
		,SUM(NVL(a1.TOT_NET_S1,0))                                  --总净佣金
		,SUM(NVL(a1.TOT_INCM_OFFER,0))                              --总收入贡献
	    ,SUM(NVL(a1.ORDI_S1_INCM_HB_RMB,0))                         --普通账户佣金收入_沪B_人民币
		,SUM(NVL(a1.ORDI_S1_INCM_SB_RMB,0))                         --普通账户佣金收入_深B_人民币
		,SUM(NVL(a1.ORDI_S1_INCM_TU_RMB,0))                         --普通账户佣金收入_三板B股_人民币
		,SUM(NVL(a1.ORDI_NET_S1_INCM_HB_RMB,0))                     --普通账户净佣金收入_沪B_人民币
		,SUM(NVL(a1.ORDI_NET_S1_INCM_SB_RMB,0))                     --普通账户净佣金收入_深B_人民币
		,SUM(NVL(a1.ORDI_NET_S1_INCM_TU_RMB,0))                     --普通账户净佣金收入_三板B股_人民币
		,SUM(NVL(a1.ORDI_TRD_FEE_HB_RMB,0))                         --普通账户交易费用_沪B_人民币
		,SUM(NVL(a1.ORDI_TRD_FEE_SB_RMB,0))                         --普通账户交易费用_深B_人民币
		,SUM(NVL(a1.ORDI_TRD_FEE_TU_RMB,0))                         --普通账户交易费用_三板B股_人民币
		,SUM(NVL(a1.ORDI_TRD_VOL_HB_RMB,0))                         --普通账户交易量_沪B_人民币
		,SUM(NVL(a1.ORDI_TRD_VOL_HB_RMB_BUYIN,0))                   --普通账户交易量_沪B_人民币_买入
		,SUM(NVL(a1.ORDI_TRD_VOL_HB_RMB_SELL,0))                    --普通账户交易量_沪B_人民币_卖出
		,SUM(NVL(a1.ORDI_TRD_VOL_SB_RMB,0))                         --普通账户交易量_深B_人民币
		,SUM(NVL(a1.ORDI_TRD_VOL_SB_RMB_BUYIN,0))                   --普通账户交易量_深B_人民币_买入
		,SUM(NVL(a1.ORDI_TRD_VOL_SB_RMB_SELL,0))                    --普通账户交易量_深B_人民币_卖出
		,SUM(NVL(a1.ORDI_TRD_VOL_TU_RMB,0))                         --普通账户交易量_三板B股_人民币
		,SUM(NVL(a1.ORDI_TRD_VOL_TU_RMB_BUYIN,0))                   --普通账户交易量_三板B股_人民币_买入
		,SUM(NVL(a1.ORDI_TRD_VOL_TU_RMB_SELL,0))                    --普通账户交易量_三板B股_人民币_卖出
		,%d{yyyyMMdd}   as ETL_DT
        ,SUM(NVL(a1.ORDI_S1_INCM_STIB_AK,0))                             --普通账户佣金收入_AK科创板
		,SUM(NVL(a1.CRD_S1_INCM_STIB_AK,0))                              --信用账户佣金收入_AK科创板
		,SUM(NVL(a1.S1_INCM_STIB_AK,0))                                  --佣金收入_AK科创板
        ,SUM(NVL(a1.ORDI_S1_INCM_STIB_RK,0))                             --普通账户佣金收入_RK科创CDR
		,SUM(NVL(a1.CRD_S1_INCM_STIB_RK,0))                              --信用账户佣金收入_RK科创CDR
		,SUM(NVL(a1.S1_INCM_STIB_RK,0))                                  --佣金收入_RK科创CDR
		,SUM(NVL(a1.ORDI_NET_S1_INCM_STIB_AK,0))                         --普通账户净佣金收入_AK科创板
		,SUM(NVL(a1.CRD_NET_S1_INCM_STIB_AK,0))                          --信用账户净佣金收入_AK科创板
		,SUM(NVL(a1.NET_S1_INCM_STIB_AK,0))                              --净佣金收入_AK科创板
        ,SUM(NVL(a1.ORDI_NET_S1_INCM_STIB_RK,0))                         --普通账户净佣金收入_RK科创CDR
		,SUM(NVL(a1.CRD_NET_S1_INCM_STIB_RK,0))                          --信用账户净佣金收入_RK科创CDR
		,SUM(NVL(a1.NET_S1_INCM_STIB_RK,0))                              --净佣金收入_RK科创CDR
		,SUM(NVL(a1.ORDI_TRD_FEE_STIB_AK,0))                             --普通账户交易费用_AK科创板
		,SUM(NVL(a1.CRD_TRD_FEE_STIB_AK,0))                              --信用账户交易费用_AK科创板
		,SUM(NVL(a1.TRD_FEE_STIB_AK,0))                                  --交易费用_AK科创板
        ,SUM(NVL(a1.ORDI_TRD_FEE_STIB_RK,0))                             --普通账户交易费用_RK科创CDR
		,SUM(NVL(a1.CRD_TRD_FEE_STIB_RK,0))                              --信用账户交易费用_RK科创CDR
		,SUM(NVL(a1.TRD_FEE_STIB_RK,0))                                  --交易费用_RK科创CDR		
		,SUM(NVL(a1.TRD_VOL_AK,0))                                       --交易量_AK科创板
        ,SUM(NVL(a1.TRD_VOL_AK_80,0))                                    --交易量_AK科创板(不包含申购交易量)
        ,SUM(NVL(a1.TRD_VOL_AK_BUYIN,0))                                 --交易量_AK科创板_买入
        ,SUM(NVL(a1.TRD_VOL_AK_SELL,0))                                  --交易量_AK科创板_卖出
        ,SUM(NVL(a1.TRD_VOL_AK_PRCH,0))                                  --交易量_AK科创板_申购
		,SUM(NVL(a1.ORDI_TRD_VOL_AK,0))                                  --普通账户交易量_AK科创板
        ,SUM(NVL(a1.ORDI_TRD_VOL_AK_80,0))                               --普通账户交易量_AK科创板(不包含申购交易量)
        ,SUM(NVL(a1.ORDI_TRD_VOL_AK_BUYIN,0))                            --普通账户交易量_AK科创板_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_AK_SELL,0))                             --普通账户交易量_AK科创板_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_AK_PRCH,0))                             --普通账户交易量_AK科创板_申购
        ,SUM(NVL(a1.CRD_TRD_VOL_AK,0))                                   --信用账户交易量_AK科创板
        ,SUM(NVL(a1.CRD_TRD_VOL_AK_80,0))                                --信用账户交易量_AK科创板(不包含申购交易量)
        ,SUM(NVL(a1.CRD_TRD_VOL_AK_BUYIN,0))                             --信用账户交易量_AK科创板_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_AK_SELL,0))                              --信用账户交易量_AK科创板_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_AK_PRCH,0))                              --信用账户交易量_AK科创板_申购		
		,SUM(NVL(a1.TRD_VOL_RK,0))                                       --交易量_RK科创CDR
        ,SUM(NVL(a1.TRD_VOL_RK_80,0))                                    --交易量_RK科创CDR(不包含申购交易量)
        ,SUM(NVL(a1.TRD_VOL_RK_BUYIN,0))                                 --交易量_RK科创CDR_买入
        ,SUM(NVL(a1.TRD_VOL_RK_SELL,0))                                  --交易量_RK科创CDR_卖出
        ,SUM(NVL(a1.TRD_VOL_RK_PRCH,0))                                  --交易量_RK科创CDR_申购
		,SUM(NVL(a1.ORDI_TRD_VOL_RK,0))                                  --普通账户交易量_RK科创CDR
        ,SUM(NVL(a1.ORDI_TRD_VOL_RK_80,0))                               --普通账户交易量_RK科创CDR(不包含申购交易量)
        ,SUM(NVL(a1.ORDI_TRD_VOL_RK_BUYIN,0))                            --普通账户交易量_RK科创CDR_买入
        ,SUM(NVL(a1.ORDI_TRD_VOL_RK_SELL,0))                             --普通账户交易量_RK科创CDR_卖出
        ,SUM(NVL(a1.ORDI_TRD_VOL_RK_PRCH,0))                             --普通账户交易量_RK科创CDR_申购
        ,SUM(NVL(a1.CRD_TRD_VOL_RK,0))                                   --信用账户交易量_RK科创CDR
        ,SUM(NVL(a1.CRD_TRD_VOL_RK_80,0))                                --信用账户交易量_RK科创CDR(不包含申购交易量)
        ,SUM(NVL(a1.CRD_TRD_VOL_RK_BUYIN,0))                             --信用账户交易量_RK科创CDR_买入
        ,SUM(NVL(a1.CRD_TRD_VOL_RK_SELL,0))                              --信用账户交易量_RK科创CDR_卖出
        ,SUM(NVL(a1.CRD_TRD_VOL_RK_PRCH,0))                              --信用账户交易量_RK科创CDR_申购		
		,SUM(NVL(a1.TRD_ITMS_STIB_AK,0))                                 --交易笔数_AK科创板
        ,SUM(NVL(a1.TRD_ITMS_STIB_AK_80,0))                              --交易笔数_AK科创板(不包含申购的笔数)
		,SUM(NVL(a1.ORDI_TRD_ITMS_STIB_AK,0))                            --普通账户交易笔数_AK科创板
        ,SUM(NVL(a1.ORDI_TRD_ITMS_STIB_AK_80,0))                         --普通账户交易笔数_AK科创板(不包含申购的笔数)
        ,SUM(NVL(a1.CRD_TRD_ITMS_STIB_AK,0))                             --信用账户交易笔数_AK科创板
        ,SUM(NVL(a1.CRD_TRD_ITMS_STIB_AK_80,0))                          --信用账户交易笔数_AK科创板(不包含申购的笔数)
	    ,SUM(NVL(a1.TRD_ITMS_STIB_RK,0))                                 --交易笔数_RK科创CDR
        ,SUM(NVL(a1.TRD_ITMS_STIB_RK_80,0))                              --交易笔数_RK科创CDR(不包含申购的笔数)
		,SUM(NVL(a1.ORDI_TRD_ITMS_STIB_RK,0))                            --普通账户交易笔数_RK科创CDR
        ,SUM(NVL(a1.ORDI_TRD_ITMS_STIB_RK_80,0))                         --普通账户交易笔数_RK科创CDR(不包含申购的笔数)
        ,SUM(NVL(a1.CRD_TRD_ITMS_STIB_RK,0))                             --信用账户交易笔数_RK科创CDR
        ,SUM(NVL(a1.CRD_TRD_ITMS_STIB_RK_80,0))                          --信用账户交易笔数_RK科创CDR(不包含申购的笔数)
		,SUM(NVL(a1.CRD_CRD_TRD_VOL,0))                         --信用账户信用交易量
        ,SUM(NVL(a1.CRD_CRD_TRD_S1,0))                          --信用账户信用交易佣金
        ,SUM(NVL(a1.CRD_CRD_TRD_NET_S1,0))                      --信用账户信用交易净佣金
        ,SUM(NVL(a1.CRD_CRD_TRD_FEE,0))                         --信用账户信用交易费用
        ,SUM(NVL(a1.CRD_CRD_TRD_ITMS,0))                        --信用账户信用交易笔数
        ,SUM(NVL(a1.NEW_TA_TRD_VOL,0))                          --新三板交易量
        ,SUM(NVL(a1.NEW_TA_TRD_S1,0))                           --新三板交易佣金
        ,SUM(NVL(a1.NEW_TA_TRD_NET_S1,0))                       --新三板交易净佣金
        ,SUM(NVL(a1.NEW_TA_TRD_FEE,0))                          --新三板交易费用
        ,SUM(NVL(a1.NEW_TA_TRD_ITMS,0))                         --新三板交易笔数
        ,SUM(NVL(a1.CLS_FND_TRD_VOL,0))                         --分级基金交易量
        ,SUM(NVL(a1.CLS_FND_TRD_S1,0))                          --分级基金交易佣金
        ,SUM(NVL(a1.CLS_FND_TRD_NET_S1,0))                      --分级基金交易净佣金
        ,SUM(NVL(a1.CLS_FND_TRD_FEE,0))                         --分级基金交易费用
        ,SUM(NVL(a1.CLS_FND_TRD_ITMS,0))                        --分级基金交易笔数
		,SUM(NVL(a1.S1_ASTK,0))                                           --A股佣金
		,SUM(NVL(a1.S1_BSTK,0))                                           --B股佣金
		,SUM(NVL(a1.S1_HK_STK,0))                                         --港股佣金
		,SUM(NVL(a1.S1_EXG_FND,0))                                        --场内基金佣金
		,SUM(NVL(a1.NET_S1_ASTK,0))                                       --A股净佣金
		,SUM(NVL(a1.NET_S1_BSTK,0))                                       --B股净佣金
		,SUM(NVL(a1.NET_S1_HK_STK,0))                                     --港股净佣金
		,SUM(NVL(a1.NET_S1_EXG_FND,0))                                    --场内基金净佣金		
		,SUM(NVL(a1.TRD_ITMS_ASTK,0))                                     --A股交易笔数
		,SUM(NVL(a1.TRD_ITMS_ASTK_BUYIN,0))                               --A股交易笔数_买入
		,SUM(NVL(a1.TRD_ITMS_ASTK_SELL,0))                                --A股交易笔数_卖出
		,SUM(NVL(a1.TRD_ITMS_ASTK_PRCH,0))                                --A股交易笔数_申购
		,SUM(NVL(a1.TRD_ITMS_BSTK,0))                                     --B股交易笔数
		,SUM(NVL(a1.TRD_ITMS_BSTK_BUYIN,0))                               --B股交易笔数_买入
		,SUM(NVL(a1.TRD_ITMS_BSTK_SELL,0))                                --B股交易笔数_卖出
		,SUM(NVL(a1.TRD_ITMS_HK_STK,0))                                   --港股交易笔数
		,SUM(NVL(a1.TRD_ITMS_HK_STK_BUYIN,0))                             --港股交易笔数_买入
		,SUM(NVL(a1.TRD_ITMS_HK_STK_SELL,0))                              --港股交易笔数_卖出
		,SUM(NVL(a1.TRD_ITMS_EXG_FND,0))                                  --场内基金的交易笔数
		,SUM(NVL(a1.TRD_ITMS_EXG_FND_BUYIN,0))                            --场内基金的交易笔数_买入
		,SUM(NVL(a1.TRD_ITMS_EXG_FND_SELL,0))                             --场内基金的交易笔数_卖出
		,SUM(NVL(a1.WRNT_TRD_CNTS_SH,0))               --期权账户交易张数(SH)
        ,SUM(NVL(a1.WRNT_TRD_VOL_SH,0))                        --期权账户交易量(SH)
        ,SUM(NVL(a1.WRNT_S1_INCM_SH,0))                        --期权账户佣金收入(SH)
        ,SUM(NVL(a1.WRNT_NET_S1_INCM_SH,0))                    --期权账户净佣金收入(SH)
        ,SUM(NVL(a1.WRNT_TRD_FEE_SH,0))                        --期权账户交易费用(SH)
        ,SUM(NVL(a1.WRNT_TRD_ITMS_SH,0))                       --期权账户交易笔数(SH)
        ,SUM(NVL(a1.WRNT_TRD_VOL_BUYIN_SH,0))                  --期权账户交易量_买入(SH)
        ,SUM(NVL(a1.WRNT_TRD_VOL_SELL_SH,0))                   --期权账户交易量_卖出(SH)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_BUYIN_SH,0))                 --期权账户交易张数_买入(SH)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_SELL_SH,0))                  --期权账户交易张数_卖出(SH)	 					
        ,SUM(NVL(a1.WRNT_TRD_VOL_BUYIN_O_SH,0))                --期权账户交易量_买入_开仓(SH)
        ,SUM(NVL(a1.WRNT_TRD_VOL_BUYIN_C_SH,0))                --期权账户交易量_买入_平仓(SH)
        ,SUM(NVL(a1.WRNT_TRD_VOL_SELL_O_SH,0))                 --期权账户交易量_卖出_开仓(SH)
        ,SUM(NVL(a1.WRNT_TRD_VOL_SELL_C_SH,0))                 --期权账户交易量_卖出_平仓(SH)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_BUYIN_O_SH,0))               --期权账户交易张数_买入_开仓(SH)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_BUYIN_C_SH,0))               --期权账户交易张数_买入_平仓(SH)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_SELL_O_SH,0))                --期权账户交易张数_卖出_开仓(SH)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_SELL_C_SH,0))                --期权账户交易张数_卖出_平仓(SH)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_SZ,0))                       --期权账户交易张数(SZ)
        ,SUM(NVL(a1.WRNT_TRD_VOL_SZ,0))                        --期权账户交易量(SZ)
        ,SUM(NVL(a1.WRNT_S1_INCM_SZ,0))                        --期权账户佣金收入(SZ)
        ,SUM(NVL(a1.WRNT_NET_S1_INCM_SZ,0))                    --期权账户净佣金收入(SZ)
        ,SUM(NVL(a1.WRNT_TRD_FEE_SZ,0))                        --期权账户交易费用(SZ)
        ,SUM(NVL(a1.WRNT_TRD_ITMS_SZ,0))                       --期权账户交易笔数(SZ)
        ,SUM(NVL(a1.WRNT_TRD_VOL_BUYIN_SZ,0))                  --期权账户交易量_买入(SZ)
        ,SUM(NVL(a1.WRNT_TRD_VOL_SELL_SZ,0))                   --期权账户交易量_卖出(SZ)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_BUYIN_SZ,0))                 --期权账户交易张数_买入(SZ)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_SELL_SZ,0))                  --期权账户交易张数_卖出(SZ)	 					 
        ,SUM(NVL(a1.WRNT_TRD_VOL_BUYIN_O_SZ,0))                --期权账户交易量_买入_开仓(SZ)
        ,SUM(NVL(a1.WRNT_TRD_VOL_BUYIN_C_SZ,0))                --期权账户交易量_买入_平仓(SZ)
        ,SUM(NVL(a1.WRNT_TRD_VOL_SELL_O_SZ,0))                 --期权账户交易量_卖出_开仓(SZ)
        ,SUM(NVL(a1.WRNT_TRD_VOL_SELL_C_SZ ,0))                --期权账户交易量_卖出_平仓(SZ)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_BUYIN_O_SZ,0))               --期权账户交易张数_买入_开仓(SZ)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_BUYIN_C_SZ,0))               --期权账户交易张数_买入_平仓(SZ)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_SELL_O_SZ,0))                --期权账户交易张数_卖出_开仓(SZ)
        ,SUM(NVL(a1.WRNT_TRD_CNTS_SELL_C_SZ,0))                --期权账户交易张数_卖出_平仓(SZ)
		,ROUND(SUM(NVL(a2.ORDI_PRDCT_GL_INT,0)),8)                      --普通账户预计息差收入
		,ROUND(SUM(NVL(a2.CRD_PRDCT_GL_INT,0)),8)                       --信用账户预计息差收入
		,ROUND(SUM(NVL(a3.ORDI_FCT_GL_INT,0)),8)                      --普通账户实际息差收入
		,ROUND(SUM(NVL(a3.CRD_FCT_GL_INT,0)),8)                       --信用账户实际息差收入
 FROM  (SELECT CUST_NO
               ,BRH_NO
			   ,CUST_CGY
        FROM  DDW_PROD.T_DDW_F00_CUST_CUST_INFO  
		WHERE BUS_DATE = %d{yyyyMMdd}
		)  t
 LEFT JOIN (SELECT CUST_NO 
                   ,SUM(CRD_MRGNC_MRGNS_PRDCT_INT)     as CRD_MRGNC_MRGNS_PRDCT_INT      
,SUM(CRD_MRGNC_MRGNS_RTN_INT)       as CRD_MRGNC_MRGNS_RTN_INT        
,SUM(ORDI_PLG_REPO_PRDCT_INT)       as ORDI_PLG_REPO_PRDCT_INT        
,SUM(ORDI_PLG_REPO_RTN_INT)         as ORDI_PLG_REPO_RTN_INT          
,SUM(ORDI_S1_INCM_RMB)              as ORDI_S1_INCM_RMB               
,SUM(CRD_S1_INCM)                   as CRD_S1_INCM                    
,SUM(ORDI_S1_INCM_OTH_RMB)          as ORDI_S1_INCM_OTH_RMB           
,SUM(S1_INCM_HA)                    as S1_INCM_HA                     
,SUM(ORDI_S1_INCM_HA)               as ORDI_S1_INCM_HA                
,SUM(CRD_S1_INCM_HA)                as CRD_S1_INCM_HA                 
,SUM(S1_INCM_SA)                    as S1_INCM_SA                     
,SUM(ORDI_S1_INCM_SA)               as ORDI_S1_INCM_SA                
,SUM(CRD_S1_INCM_SA)                as CRD_S1_INCM_SA                 
,SUM(S1_INCM_SMS)                   as S1_INCM_SMS                    
,SUM(ORDI_S1_INCM_SMS)              as ORDI_S1_INCM_SMS               
,SUM(CRD_S1_INCM_SMS)               as CRD_S1_INCM_SMS                
,SUM(S1_INCM_GEM)                   as S1_INCM_GEM                    
,SUM(ORDI_S1_INCM_GEM)              as ORDI_S1_INCM_GEM               
,SUM(CRD_S1_INCM_GEM)               as CRD_S1_INCM_GEM                
,SUM(ORDI_S1_INCM_HB_USD)           as ORDI_S1_INCM_HB_USD            
,SUM(ORDI_S1_INCM_SB_HKD)           as ORDI_S1_INCM_SB_HKD            
,SUM(ORDI_S1_INCM_HK)               as ORDI_S1_INCM_HK                
,SUM(ORDI_S1_INCM_SK)               as ORDI_S1_INCM_SK                
,SUM(ORDI_S1_INCM_TA)               as ORDI_S1_INCM_TA                
,SUM(ORDI_S1_INCM_TU_USD)           as ORDI_S1_INCM_TU_USD            
,SUM(ORDI_S1_INCM_REPO)             as ORDI_S1_INCM_REPO              
,SUM(ORDI_S1_INCM_EXG_FND)          as ORDI_S1_INCM_EXG_FND           
,SUM(ORDI_S1_INCM_CLS_FND)          as ORDI_S1_INCM_CLS_FND           
,SUM(ORDI_S1_INCM_ETF_FND)          as ORDI_S1_INCM_ETF_FND           
,SUM(ORDI_S1_INCM_OPN_FND)          as ORDI_S1_INCM_OPN_FND           
,SUM(ORDI_S1_INCM_LOF_FND)          as ORDI_S1_INCM_LOF_FND           
,SUM(ORDI_S1_INCM_FOF_FND)          as ORDI_S1_INCM_FOF_FND           
,SUM(CRD_S1_INCM_EXG_FND)           as CRD_S1_INCM_EXG_FND            
,SUM(CRD_S1_INCM_CLS_FND)           as CRD_S1_INCM_CLS_FND            
,SUM(CRD_S1_INCM_ETF_FND)           as CRD_S1_INCM_ETF_FND            
,SUM(CRD_S1_INCM_OPN_FND)           as CRD_S1_INCM_OPN_FND            
,SUM(CRD_S1_INCM_LOF_FND)           as CRD_S1_INCM_LOF_FND            
,SUM(CRD_S1_INCM_FOF_FND)           as CRD_S1_INCM_FOF_FND            
,SUM(ORDI_S1_INCM_BOND)             as ORDI_S1_INCM_BOND              
,SUM(CRD_S1_INCM_BOND)              as CRD_S1_INCM_BOND               
,SUM(ORDI_NET_S1_INCM_RMB)          as ORDI_NET_S1_INCM_RMB           
,SUM(CRD_NET_S1_INCM)               as CRD_NET_S1_INCM                
,SUM(ORDI_NET_S1_INCM_OTH_RMB)      as ORDI_NET_S1_INCM_OTH_RMB       
,SUM(NET_S1_INCM_HA)                as NET_S1_INCM_HA                 
,SUM(ORDI_NET_S1_INCM_HA)           as ORDI_NET_S1_INCM_HA            
,SUM(CRD_NET_S1_INCM_HA)            as CRD_NET_S1_INCM_HA             
,SUM(NET_S1_INCM_SA)                as NET_S1_INCM_SA                 
,SUM(ORDI_NET_S1_INCM_SA)           as ORDI_NET_S1_INCM_SA            
,SUM(CRD_NET_S1_INCM_SA)            as CRD_NET_S1_INCM_SA             
,SUM(NET_S1_INCM_SMS)               as NET_S1_INCM_SMS                
,SUM(ORDI_NET_S1_INCM_SMS)          as ORDI_NET_S1_INCM_SMS           
,SUM(CRD_NET_S1_INCM_SMS)           as CRD_NET_S1_INCM_SMS            
,SUM(NET_S1_INCM_GEM)               as NET_S1_INCM_GEM                
,SUM(ORDI_NET_S1_INCM_GEM)          as ORDI_NET_S1_INCM_GEM           
,SUM(CRD_NET_S1_INCM_GEM)           as CRD_NET_S1_INCM_GEM            
,SUM(ORDI_NET_S1_INCM_HB_USD)       as ORDI_NET_S1_INCM_HB_USD        
,SUM(ORDI_NET_S1_INCM_SB_HKD)       as ORDI_NET_S1_INCM_SB_HKD        
,SUM(ORDI_NET_S1_INCM_HK)           as ORDI_NET_S1_INCM_HK            
,SUM(ORDI_NET_S1_INCM_SK)           as ORDI_NET_S1_INCM_SK            
,SUM(ORDI_NET_S1_INCM_TA)           as ORDI_NET_S1_INCM_TA            
,SUM(ORDI_NET_S1_INCM_TU_USD)       as ORDI_NET_S1_INCM_TU_USD        
,SUM(ORDI_NET_S1_INCM_REPO)         as ORDI_NET_S1_INCM_REPO          
,SUM(ORDI_NET_S1_INCM_EXG_FND)      as ORDI_NET_S1_INCM_EXG_FND       
,SUM(ORDI_NET_S1_INCM_CLS_FND)      as ORDI_NET_S1_INCM_CLS_FND       
,SUM(ORDI_NET_S1_INCM_ETF_FND)      as ORDI_NET_S1_INCM_ETF_FND       
,SUM(ORDI_NET_S1_INCM_OPN_FND)      as ORDI_NET_S1_INCM_OPN_FND       
,SUM(ORDI_NET_S1_INCM_LOF_FND)      as ORDI_NET_S1_INCM_LOF_FND       
,SUM(ORDI_NET_S1_INCM_FOF_FND)      as ORDI_NET_S1_INCM_FOF_FND       
,SUM(CRD_NET_S1_INCM_EXG_FND)       as CRD_NET_S1_INCM_EXG_FND        
,SUM(CRD_NET_S1_INCM_CLS_FND)       as CRD_NET_S1_INCM_CLS_FND        
,SUM(CRD_NET_S1_INCM_ETF_FND)       as CRD_NET_S1_INCM_ETF_FND        
,SUM(CRD_NET_S1_INCM_OPN_FND)       as CRD_NET_S1_INCM_OPN_FND        
,SUM(CRD_NET_S1_INCM_LOF_FND)       as CRD_NET_S1_INCM_LOF_FND        
,SUM(CRD_NET_S1_INCM_FOF_FND)       as CRD_NET_S1_INCM_FOF_FND        
,SUM(ORDI_NET_S1_INCM_BOND)         as ORDI_NET_S1_INCM_BOND          
,SUM(CRD_NET_S1_INCM_BOND)          as CRD_NET_S1_INCM_BOND           
,SUM(ORDI_TRD_FEE_RMB)              as ORDI_TRD_FEE_RMB               
,SUM(CRD_TRD_FEE)                   as CRD_TRD_FEE                    
,SUM(ORDI_TRD_FEE_OTH_RMB)          as ORDI_TRD_FEE_OTH_RMB           
,SUM(TRD_FEE_HA)                    as TRD_FEE_HA                     
,SUM(ORDI_TRD_FEE_HA)               as ORDI_TRD_FEE_HA                
,SUM(CRD_TRD_FEE_HA)                as CRD_TRD_FEE_HA                 
,SUM(TRD_FEE_SA)                    as TRD_FEE_SA                     
,SUM(ORDI_TRD_FEE_SA)               as ORDI_TRD_FEE_SA                
,SUM(CRD_TRD_FEE_SA)                as CRD_TRD_FEE_SA                 
,SUM(TRD_FEE_SMS)                   as TRD_FEE_SMS                    
,SUM(ORDI_TRD_FEE_SMS)              as ORDI_TRD_FEE_SMS               
,SUM(CRD_TRD_FEE_SMS)               as CRD_TRD_FEE_SMS                
,SUM(TRD_FEE_GEM)                   as TRD_FEE_GEM                    
,SUM(ORDI_TRD_FEE_GEM)              as ORDI_TRD_FEE_GEM               
,SUM(CRD_TRD_FEE_GEM)               as CRD_TRD_FEE_GEM                
,SUM(ORDI_TRD_FEE_HB_USD)           as ORDI_TRD_FEE_HB_USD            
,SUM(ORDI_TRD_FEE_SB_HKD)           as ORDI_TRD_FEE_SB_HKD            
,SUM(ORDI_TRD_FEE_HK)               as ORDI_TRD_FEE_HK                
,SUM(ORDI_TRD_FEE_SK)               as ORDI_TRD_FEE_SK                
,SUM(ORDI_TRD_FEE_TA)               as ORDI_TRD_FEE_TA                
,SUM(ORDI_TRD_FEE_TU_USD)           as ORDI_TRD_FEE_TU_USD            
,SUM(ORDI_TRD_FEE_REPO)             as ORDI_TRD_FEE_REPO              
,SUM(ORDI_TRD_FEE_EXG_FND)          as ORDI_TRD_FEE_EXG_FND           
,SUM(ORDI_TRD_FEE_CLS_FND)          as ORDI_TRD_FEE_CLS_FND           
,SUM(ORDI_TRD_FEE_ETF_FND)          as ORDI_TRD_FEE_ETF_FND           
,SUM(ORDI_TRD_FEE_OPN_FND)          as ORDI_TRD_FEE_OPN_FND           
,SUM(ORDI_TRD_FEE_LOF_FND)          as ORDI_TRD_FEE_LOF_FND           
,SUM(ORDI_TRD_FEE_FOF_FND)          as ORDI_TRD_FEE_FOF_FND           
,SUM(CRD_TRD_FEE_EXG_FND)           as CRD_TRD_FEE_EXG_FND            
,SUM(CRD_TRD_FEE_CLS_FND)           as CRD_TRD_FEE_CLS_FND            
,SUM(CRD_TRD_FEE_ETF_FND)           as CRD_TRD_FEE_ETF_FND            
,SUM(CRD_TRD_FEE_OPN_FND)           as CRD_TRD_FEE_OPN_FND            
,SUM(CRD_TRD_FEE_LOF_FND)           as CRD_TRD_FEE_LOF_FND            
,SUM(CRD_TRD_FEE_FOF_FND)           as CRD_TRD_FEE_FOF_FND            
,SUM(ORDI_TRD_FEE_BOND)             as ORDI_TRD_FEE_BOND              
,SUM(CRD_TRD_FEE_BOND)              as CRD_TRD_FEE_BOND               
,SUM(PROD_CMSN_FEE)                 as PROD_CMSN_FEE                  
,SUM(AGN_FND_CMSN_FEE)              as AGN_FND_CMSN_FEE               
,SUM(GS_PROD_CMSN_FEE)              as GS_PROD_CMSN_FEE               
,SUM(GJ_PROD_CMSN_FEE)              as GJ_PROD_CMSN_FEE               
,SUM(OTC_PROD_CMSN_FEE)             as OTC_PROD_CMSN_FEE              
,SUM(PROD_SCRP_AMT)                 as PROD_SCRP_AMT                  
,SUM(PROD_PRCH_AMT)                 as PROD_PRCH_AMT                  
,SUM(PROD_FIXINV_AMT)               as PROD_FIXINV_AMT                
,SUM(PROD_RDMPT_AMT)                as PROD_RDMPT_AMT                 
,SUM(AGN_FND_SCRP_AMT)              as AGN_FND_SCRP_AMT               
,SUM(AGN_FND_PRCH_AMT)              as AGN_FND_PRCH_AMT               
,SUM(AGN_FND_FIXINV_AMT)            as AGN_FND_FIXINV_AMT             
,SUM(AGN_FND_RDMPT_AMT)             as AGN_FND_RDMPT_AMT              
,SUM(GS_PROD_SCRP_AMT)              as GS_PROD_SCRP_AMT               
,SUM(GS_PROD_PRCH_AMT)              as GS_PROD_PRCH_AMT               
,SUM(GS_PROD_FIXINV_AMT)            as GS_PROD_FIXINV_AMT             
,SUM(GS_PROD_RDMPT_AMT)             as GS_PROD_RDMPT_AMT              
,SUM(GJ_PROD_SCRP_AMT)              as GJ_PROD_SCRP_AMT               
,SUM(GJ_PROD_PRCH_AMT)              as GJ_PROD_PRCH_AMT               
,SUM(GJ_PROD_FIXINV_AMT)            as GJ_PROD_FIXINV_AMT             
,SUM(GJ_PROD_RDMPT_AMT)             as GJ_PROD_RDMPT_AMT              
,SUM(BANK_PROD_SCRP_AMT)            as BANK_PROD_SCRP_AMT             
,SUM(BANK_PROD_PRCH_AMT)            as BANK_PROD_PRCH_AMT             
,SUM(BANK_PROD_RDMPT_AMT)           as BANK_PROD_RDMPT_AMT            
,SUM(OTC_PROD_SCRP_AMT)             as OTC_PROD_SCRP_AMT              
,SUM(OTC_PROD_PRCH_AMT)             as OTC_PROD_PRCH_AMT              
,SUM(OTC_PROD_RDMPT_AMT)            as OTC_PROD_RDMPT_AMT             
,SUM(AGN_FND_SCRP_ITMS)             as AGN_FND_SCRP_ITMS              
,SUM(AGN_FND_PRCH_ITMS)             as AGN_FND_PRCH_ITMS              
,SUM(AGN_FND_FIXINV_ITMS)           as AGN_FND_FIXINV_ITMS            
,SUM(AGN_FND_RDMPT_ITMS)            as AGN_FND_RDMPT_ITMS             
,SUM(GS_PROD_SCRP_ITMS)             as GS_PROD_SCRP_ITMS              
,SUM(GS_PROD_PRCH_ITMS)             as GS_PROD_PRCH_ITMS              
,SUM(GS_PROD_FIXINV_ITMS)           as GS_PROD_FIXINV_ITMS            
,SUM(GS_PROD_RDMPT_ITMS)            as GS_PROD_RDMPT_ITMS             
,SUM(GJ_PROD_SCRP_ITMS)             as GJ_PROD_SCRP_ITMS              
,SUM(GJ_PROD_PRCH_ITMS)             as GJ_PROD_PRCH_ITMS              
,SUM(GJ_PROD_FIXINV_ITMS)           as GJ_PROD_FIXINV_ITMS            
,SUM(GJ_PROD_RDMPT_ITMS)            as GJ_PROD_RDMPT_ITMS             
,SUM(BANK_PROD_SCRP_ITMS)           as BANK_PROD_SCRP_ITMS            
,SUM(BANK_PROD_PRCH_ITMS)           as BANK_PROD_PRCH_ITMS            
,SUM(BANK_PROD_RDMPT_ITMS)          as BANK_PROD_RDMPT_ITMS           
,SUM(OTC_PROD_SCRP_ITMS)            as OTC_PROD_SCRP_ITMS             
,SUM(OTC_PROD_PRCH_ITMS)            as OTC_PROD_PRCH_ITMS             
,SUM(OTC_PROD_RDMPT_ITMS)           as OTC_PROD_RDMPT_ITMS            
,SUM(ORDI_TRD_VOL_RMB)              as ORDI_TRD_VOL_RMB               
,SUM(ORDI_TRD_VOL_RMB_80)           as ORDI_TRD_VOL_RMB_80            
,SUM(ORDI_TRD_VOL_RMB_BUYIN)        as ORDI_TRD_VOL_RMB_BUYIN         
,SUM(ORDI_TRD_VOL_RMB_SELL)         as ORDI_TRD_VOL_RMB_SELL          
,SUM(ORDI_TRD_VOL_RMB_PRCH)         as ORDI_TRD_VOL_RMB_PRCH          
,SUM(CRD_TRD_VOL)                   as CRD_TRD_VOL                    
,SUM(CRD_TRD_VOL_80)                as CRD_TRD_VOL_80                 
,SUM(CRD_TRD_VOL_BUYIN)             as CRD_TRD_VOL_BUYIN              
,SUM(CRD_TRD_VOL_SELL)              as CRD_TRD_VOL_SELL               
,SUM(CRD_TRD_VOL_PRCH)              as CRD_TRD_VOL_PRCH               
,SUM(ORDI_TRD_VOL_OTH_RMB)          as ORDI_TRD_VOL_OTH_RMB           
,SUM(ORDI_TRD_VOL_OTH_RMB_BUYIN)    as ORDI_TRD_VOL_OTH_RMB_BUYIN     
,SUM(ORDI_TRD_VOL_OTH_RMB_SELL)     as ORDI_TRD_VOL_OTH_RMB_SELL      
,SUM(TRD_VOL_HA)                    as TRD_VOL_HA                     
,SUM(TRD_VOL_HA_80)                 as TRD_VOL_HA_80                  
,SUM(TRD_VOL_HA_BUYIN)              as TRD_VOL_HA_BUYIN               
,SUM(TRD_VOL_HA_SELL)               as TRD_VOL_HA_SELL                
,SUM(TRD_VOL_HA_PRCH)               as TRD_VOL_HA_PRCH                
,SUM(ORDI_TRD_VOL_HA)               as ORDI_TRD_VOL_HA                
,SUM(ORDI_TRD_VOL_HA_80)            as ORDI_TRD_VOL_HA_80             
,SUM(ORDI_TRD_VOL_HA_BUYIN)         as ORDI_TRD_VOL_HA_BUYIN          
,SUM(ORDI_TRD_VOL_HA_SELL)          as ORDI_TRD_VOL_HA_SELL           
,SUM(ORDI_TRD_VOL_HA_PRCH)          as ORDI_TRD_VOL_HA_PRCH           
,SUM(CRD_TRD_VOL_HA)                as CRD_TRD_VOL_HA                 
,SUM(CRD_TRD_VOL_HA_80)             as CRD_TRD_VOL_HA_80              
,SUM(CRD_TRD_VOL_HA_BUYIN)          as CRD_TRD_VOL_HA_BUYIN           
,SUM(CRD_TRD_VOL_HA_SELL)           as CRD_TRD_VOL_HA_SELL            
,SUM(CRD_TRD_VOL_HA_PRCH)           as CRD_TRD_VOL_HA_PRCH            
,SUM(TRD_VOL_SA)                    as TRD_VOL_SA                     
,SUM(TRD_VOL_SA_80)                 as TRD_VOL_SA_80                  
,SUM(TRD_VOL_SA_BUYIN)              as TRD_VOL_SA_BUYIN               
,SUM(TRD_VOL_SA_SELL)               as TRD_VOL_SA_SELL                
,SUM(TRD_VOL_SA_PRCH)               as TRD_VOL_SA_PRCH                
,SUM(ORDI_TRD_VOL_SA)               as ORDI_TRD_VOL_SA                
,SUM(ORDI_TRD_VOL_SA_80)            as ORDI_TRD_VOL_SA_80             
,SUM(ORDI_TRD_VOL_SA_BUYIN)         as ORDI_TRD_VOL_SA_BUYIN          
,SUM(ORDI_TRD_VOL_SA_SELL)          as ORDI_TRD_VOL_SA_SELL           
,SUM(ORDI_TRD_VOL_SA_PRCH)          as ORDI_TRD_VOL_SA_PRCH           
,SUM(CRD_TRD_VOL_SA)                as CRD_TRD_VOL_SA                 
,SUM(CRD_TRD_VOL_SA_80)             as CRD_TRD_VOL_SA_80              
,SUM(CRD_TRD_VOL_SA_BUYIN)          as CRD_TRD_VOL_SA_BUYIN           
,SUM(CRD_TRD_VOL_SA_SELL)           as CRD_TRD_VOL_SA_SELL            
,SUM(CRD_TRD_VOL_SA_PRCH)           as CRD_TRD_VOL_SA_PRCH            
,SUM(TRD_VOL_SMS)                   as TRD_VOL_SMS                    
,SUM(TRD_VOL_SMS_80)                as TRD_VOL_SMS_80                 
,SUM(TRD_VOL_SMS_BUYIN)             as TRD_VOL_SMS_BUYIN              
,SUM(TRD_VOL_SMS_SELL)              as TRD_VOL_SMS_SELL               
,SUM(TRD_VOL_SMS_PRCH)              as TRD_VOL_SMS_PRCH               
,SUM(ORDI_TRD_VOL_SMS)              as ORDI_TRD_VOL_SMS               
,SUM(ORDI_TRD_VOL_SMS_80)           as ORDI_TRD_VOL_SMS_80            
,SUM(ORDI_TRD_VOL_SMS_BUYIN)        as ORDI_TRD_VOL_SMS_BUYIN         
,SUM(ORDI_TRD_VOL_SMS_SELL)         as ORDI_TRD_VOL_SMS_SELL          
,SUM(ORDI_TRD_VOL_SMS_PRCH)         as ORDI_TRD_VOL_SMS_PRCH          
,SUM(CRD_TRD_VOL_SMS)               as CRD_TRD_VOL_SMS                
,SUM(CRD_TRD_VOL_SMS_80)            as CRD_TRD_VOL_SMS_80             
,SUM(CRD_TRD_VOL_SMS_BUYIN)         as CRD_TRD_VOL_SMS_BUYIN          
,SUM(CRD_TRD_VOL_SMS_SELL)          as CRD_TRD_VOL_SMS_SELL           
,SUM(CRD_TRD_VOL_SMS_PRCH)          as CRD_TRD_VOL_SMS_PRCH           
,SUM(TRD_VOL_GEM)                   as TRD_VOL_GEM                    
,SUM(TRD_VOL_GEM_80)                as TRD_VOL_GEM_80                 
,SUM(TRD_VOL_GEM_BUYIN)             as TRD_VOL_GEM_BUYIN              
,SUM(TRD_VOL_GEM_SELL)              as TRD_VOL_GEM_SELL               
,SUM(TRD_VOL_GEM_PRCH)              as TRD_VOL_GEM_PRCH               
,SUM(ORDI_TRD_VOL_GEM)              as ORDI_TRD_VOL_GEM               
,SUM(ORDI_TRD_VOL_GEM_80)           as ORDI_TRD_VOL_GEM_80            
,SUM(ORDI_TRD_VOL_GEM_BUYIN)        as ORDI_TRD_VOL_GEM_BUYIN         
,SUM(ORDI_TRD_VOL_GEM_SELL)         as ORDI_TRD_VOL_GEM_SELL          
,SUM(ORDI_TRD_VOL_GEM_PRCH)         as ORDI_TRD_VOL_GEM_PRCH          
,SUM(CRD_TRD_VOL_GEM)               as CRD_TRD_VOL_GEM                
,SUM(CRD_TRD_VOL_GEM_80)            as CRD_TRD_VOL_GEM_80             
,SUM(CRD_TRD_VOL_GEM_BUYIN)         as CRD_TRD_VOL_GEM_BUYIN          
,SUM(CRD_TRD_VOL_GEM_SELL)          as CRD_TRD_VOL_GEM_SELL           
,SUM(CRD_TRD_VOL_GEM_PRCH)          as CRD_TRD_VOL_GEM_PRCH           
,SUM(ORDI_TRD_VOL_HB_USD)           as ORDI_TRD_VOL_HB_USD            
,SUM(ORDI_TRD_VOL_HB_USD_BUYIN)     as ORDI_TRD_VOL_HB_USD_BUYIN      
,SUM(ORDI_TRD_VOL_HB_USD_SELL)      as ORDI_TRD_VOL_HB_USD_SELL       
,SUM(ORDI_TRD_VOL_SB_HKD)           as ORDI_TRD_VOL_SB_HKD            
,SUM(ORDI_TRD_VOL_SB_HKD_BUYIN)     as ORDI_TRD_VOL_SB_HKD_BUYIN      
,SUM(ORDI_TRD_VOL_SB_HKD_SELL)      as ORDI_TRD_VOL_SB_HKD_SELL       
,SUM(ORDI_TRD_VOL_HK)               as ORDI_TRD_VOL_HK                
,SUM(ORDI_TRD_VOL_HK_BUYIN)         as ORDI_TRD_VOL_HK_BUYIN          
,SUM(ORDI_TRD_VOL_HK_SELL)          as ORDI_TRD_VOL_HK_SELL           
,SUM(ORDI_TRD_VOL_SK)               as ORDI_TRD_VOL_SK                
,SUM(ORDI_TRD_VOL_SK_BUYIN)         as ORDI_TRD_VOL_SK_BUYIN          
,SUM(ORDI_TRD_VOL_SK_SELL)          as ORDI_TRD_VOL_SK_SELL           
,SUM(ORDI_TRD_VOL_TA)               as ORDI_TRD_VOL_TA                
,SUM(ORDI_TRD_VOL_TA_BUYIN)         as ORDI_TRD_VOL_TA_BUYIN          
,SUM(ORDI_TRD_VOL_TA_SELL)          as ORDI_TRD_VOL_TA_SELL           
,SUM(ORDI_TRD_VOL_TU_USD)           as ORDI_TRD_VOL_TU_USD            
,SUM(ORDI_TRD_VOL_TU_USD_BUYIN)     as ORDI_TRD_VOL_TU_USD_BUYIN      
,SUM(ORDI_TRD_VOL_TU_USD_SELL)      as ORDI_TRD_VOL_TU_USD_SELL       
,SUM(ORDI_TRD_VOL_REPO)             as ORDI_TRD_VOL_REPO              
,SUM(ORDI_TRD_VOL_REPO_BUYIN)       as ORDI_TRD_VOL_REPO_BUYIN        
,SUM(ORDI_TRD_VOL_REPO_SELL)        as ORDI_TRD_VOL_REPO_SELL         
,SUM(ORDI_TRD_VOL_EXG_FND)          as ORDI_TRD_VOL_EXG_FND           
,SUM(ORDI_TRD_VOL_EXG_FND_BUYIN)    as ORDI_TRD_VOL_EXG_FND_BUYIN     
,SUM(ORDI_TRD_VOL_EXG_FND_SELL)     as ORDI_TRD_VOL_EXG_FND_SELL      
,SUM(ORDI_TRD_VOL_CLS_FND)          as ORDI_TRD_VOL_CLS_FND           
,SUM(ORDI_TRD_VOL_CLS_FND_BUYIN)    as ORDI_TRD_VOL_CLS_FND_BUYIN     
,SUM(ORDI_TRD_VOL_CLS_FND_SELL)     as ORDI_TRD_VOL_CLS_FND_SELL      
,SUM(ORDI_TRD_VOL_ETF_FND)          as ORDI_TRD_VOL_ETF_FND           
,SUM(ORDI_TRD_VOL_ETF_FND_BUYIN)    as ORDI_TRD_VOL_ETF_FND_BUYIN     
,SUM(ORDI_TRD_VOL_ETF_FND_SELL)     as ORDI_TRD_VOL_ETF_FND_SELL      
,SUM(ORDI_TRD_VOL_OPN_FND)          as ORDI_TRD_VOL_OPN_FND           
,SUM(ORDI_TRD_VOL_OPN_FND_BUYIN)    as ORDI_TRD_VOL_OPN_FND_BUYIN     
,SUM(ORDI_TRD_VOL_OPN_FND_SELL)     as ORDI_TRD_VOL_OPN_FND_SELL      
,SUM(ORDI_TRD_VOL_LOF_FND)          as ORDI_TRD_VOL_LOF_FND           
,SUM(ORDI_TRD_VOL_LOF_FND_BUYIN)    as ORDI_TRD_VOL_LOF_FND_BUYIN     
,SUM(ORDI_TRD_VOL_LOF_FND_SELL)     as ORDI_TRD_VOL_LOF_FND_SELL      
,SUM(ORDI_TRD_VOL_FOF_FND)          as ORDI_TRD_VOL_FOF_FND           
,SUM(ORDI_TRD_VOL_FOF_FND_BUYIN)    as ORDI_TRD_VOL_FOF_FND_BUYIN     
,SUM(ORDI_TRD_VOL_FOF_FND_SELL)     as ORDI_TRD_VOL_FOF_FND_SELL      
,SUM(CRD_TRD_VOL_EXG_FND)           as CRD_TRD_VOL_EXG_FND            
,SUM(CRD_TRD_VOL_EXG_FND_BUYIN)     as CRD_TRD_VOL_EXG_FND_BUYIN      
,SUM(CRD_TRD_VOL_EXG_FND_SELL)      as CRD_TRD_VOL_EXG_FND_SELL       
,SUM(CRD_TRD_VOL_CLS_FND)           as CRD_TRD_VOL_CLS_FND            
,SUM(CRD_TRD_VOL_CLS_FND_BUYIN)     as CRD_TRD_VOL_CLS_FND_BUYIN      
,SUM(CRD_TRD_VOL_CLS_FND_SELL)      as CRD_TRD_VOL_CLS_FND_SELL       
,SUM(CRD_TRD_VOL_ETF_FND)           as CRD_TRD_VOL_ETF_FND            
,SUM(CRD_TRD_VOL_ETF_FND_BUYIN)     as CRD_TRD_VOL_ETF_FND_BUYIN      
,SUM(CRD_TRD_VOL_ETF_FND_SELL)      as CRD_TRD_VOL_ETF_FND_SELL       
,SUM(CRD_TRD_VOL_OPN_FND)           as CRD_TRD_VOL_OPN_FND            
,SUM(CRD_TRD_VOL_OPN_FND_BUYIN)     as CRD_TRD_VOL_OPN_FND_BUYIN      
,SUM(CRD_TRD_VOL_OPN_FND_SELL)      as CRD_TRD_VOL_OPN_FND_SELL       
,SUM(CRD_TRD_VOL_LOF_FND)           as CRD_TRD_VOL_LOF_FND            
,SUM(CRD_TRD_VOL_LOF_FND_BUYIN)     as CRD_TRD_VOL_LOF_FND_BUYIN      
,SUM(CRD_TRD_VOL_LOF_FND_SELL)      as CRD_TRD_VOL_LOF_FND_SELL       
,SUM(CRD_TRD_VOL_FOF_FND)           as CRD_TRD_VOL_FOF_FND            
,SUM(CRD_TRD_VOL_FOF_FND_BUYIN)     as CRD_TRD_VOL_FOF_FND_BUYIN      
,SUM(CRD_TRD_VOL_FOF_FND_SELL)      as CRD_TRD_VOL_FOF_FND_SELL       
,SUM(ORDI_TRD_VOL_BOND)             as ORDI_TRD_VOL_BOND              
,SUM(ORDI_TRD_VOL_BOND_80)          as ORDI_TRD_VOL_BOND_80           
,SUM(ORDI_TRD_VOL_BOND_BUYIN)       as ORDI_TRD_VOL_BOND_BUYIN        
,SUM(ORDI_TRD_VOL_BOND_SELL)        as ORDI_TRD_VOL_BOND_SELL         
,SUM(ORDI_TRD_VOL_BOND_PRCH)        as ORDI_TRD_VOL_BOND_PRCH         
,SUM(CRD_TRD_VOL_BOND)              as CRD_TRD_VOL_BOND               
,SUM(CRD_TRD_VOL_BOND_80)           as CRD_TRD_VOL_BOND_80            
,SUM(CRD_TRD_VOL_BOND_BUYIN)        as CRD_TRD_VOL_BOND_BUYIN         
,SUM(CRD_TRD_VOL_BOND_SELL)         as CRD_TRD_VOL_BOND_SELL          
,SUM(CRD_TRD_VOL_BOND_PRCH)         as CRD_TRD_VOL_BOND_PRCH          
,SUM(ORDI_TRD_ITMS)                 as ORDI_TRD_ITMS                  
,SUM(ORDI_TRD_ITMS_80)              as ORDI_TRD_ITMS_80               
,SUM(CRD_TRD_ITMS)                  as CRD_TRD_ITMS                   
,SUM(CRD_TRD_ITMS_80)               as CRD_TRD_ITMS_80                
,SUM(ORDI_TRD_ITMS_OTH)             as ORDI_TRD_ITMS_OTH              
,SUM(TRD_ITMS_HA)                   as TRD_ITMS_HA                    
,SUM(TRD_ITMS_HA_80)                as TRD_ITMS_HA_80                 
,SUM(ORDI_TRD_ITMS_HA)              as ORDI_TRD_ITMS_HA               
,SUM(ORDI_TRD_ITMS_HA_80)           as ORDI_TRD_ITMS_HA_80            
,SUM(CRD_TRD_ITMS_HA)               as CRD_TRD_ITMS_HA                
,SUM(CRD_TRD_ITMS_HA_80)            as CRD_TRD_ITMS_HA_80             
,SUM(TRD_ITMS_SA)                   as TRD_ITMS_SA                    
,SUM(TRD_ITMS_SA_80)                as TRD_ITMS_SA_80                 
,SUM(ORDI_TRD_ITMS_SA)              as ORDI_TRD_ITMS_SA               
,SUM(ORDI_TRD_ITMS_SA_80)           as ORDI_TRD_ITMS_SA_80            
,SUM(CRD_TRD_ITMS_SA)               as CRD_TRD_ITMS_SA                
,SUM(TRD_ITMS_SMS)                  as TRD_ITMS_SMS                   
,SUM(TRD_ITMS_SMS_80)               as TRD_ITMS_SMS_80                
,SUM(ORDI_TRD_ITMS_SMS)             as ORDI_TRD_ITMS_SMS              
,SUM(ORDI_TRD_ITMS_SMS_80)          as ORDI_TRD_ITMS_SMS_80           
,SUM(CRD_TRD_ITMS_SMS)              as CRD_TRD_ITMS_SMS               
,SUM(CRD_TRD_ITMS_SMS_80)           as CRD_TRD_ITMS_SMS_80            
,SUM(TRD_ITMS_GEM)                  as TRD_ITMS_GEM                   
,SUM(TRD_ITMS_GEM_80)               as TRD_ITMS_GEM_80                
,SUM(ORDI_TRD_ITMS_GEM)             as ORDI_TRD_ITMS_GEM              
,SUM(ORDI_TRD_ITMS_GEM_80)          as ORDI_TRD_ITMS_GEM_80           
,SUM(CRD_TRD_ITMS_GEM)              as CRD_TRD_ITMS_GEM               
,SUM(CRD_TRD_ITMS_GEM_80)           as CRD_TRD_ITMS_GEM_80            
,SUM(ORDI_TRD_ITMS_HB)              as ORDI_TRD_ITMS_HB               
,SUM(ORDI_TRD_ITMS_SB)              as ORDI_TRD_ITMS_SB               
,SUM(ORDI_TRD_ITMS_HK)              as ORDI_TRD_ITMS_HK               
,SUM(ORDI_TRD_ITMS_SK)              as ORDI_TRD_ITMS_SK               
,SUM(ORDI_TRD_ITMS_TA)              as ORDI_TRD_ITMS_TA               
,SUM(ORDI_TRD_ITMS_TU)              as ORDI_TRD_ITMS_TU               
,SUM(ORDI_TRD_ITMS_REPO)            as ORDI_TRD_ITMS_REPO             
,SUM(ORDI_TRD_ITMS_EXG_FND)         as ORDI_TRD_ITMS_EXG_FND          
,SUM(ORDI_TRD_ITMS_CLS_FND)         as ORDI_TRD_ITMS_CLS_FND          
,SUM(ORDI_TRD_ITMS_ETF_FND)         as ORDI_TRD_ITMS_ETF_FND          
,SUM(ORDI_TRD_ITMS_OPN_FND)         as ORDI_TRD_ITMS_OPN_FND          
,SUM(ORDI_TRD_ITMS_LOF_FND)         as ORDI_TRD_ITMS_LOF_FND          
,SUM(ORDI_TRD_ITMS_FOF_FND)         as ORDI_TRD_ITMS_FOF_FND          
,SUM(CRD_TRD_ITMS_EXG_FND)          as CRD_TRD_ITMS_EXG_FND           
,SUM(CRD_TRD_ITMS_CLS_FND)          as CRD_TRD_ITMS_CLS_FND           
,SUM(CRD_TRD_ITMS_ETF_FND)          as CRD_TRD_ITMS_ETF_FND           
,SUM(CRD_TRD_ITMS_OPN_FND)          as CRD_TRD_ITMS_OPN_FND           
,SUM(CRD_TRD_ITMS_LOF_FND)          as CRD_TRD_ITMS_LOF_FND           
,SUM(CRD_TRD_ITMS_FOF_FND)          as CRD_TRD_ITMS_FOF_FND           
,SUM(ORDI_TRD_ITMS_BOND)            as ORDI_TRD_ITMS_BOND             
,SUM(ORDI_TRD_ITMS_BOND_80)         as ORDI_TRD_ITMS_BOND_80          
,SUM(CRD_TRD_ITMS_BOND)             as CRD_TRD_ITMS_BOND              
,SUM(CRD_TRD_ITMS_BOND_80)          as CRD_TRD_ITMS_BOND_80           
,SUM(WRNT_TRD_CNTS)                 as WRNT_TRD_CNTS                  
,SUM(WRNT_TRD_VOL)                  as WRNT_TRD_VOL                   
,SUM(WRNT_S1_INCM)                  as WRNT_S1_INCM                   
,SUM(WRNT_NET_S1_INCM)              as WRNT_NET_S1_INCM               
,SUM(WRNT_TRD_FEE)                  as WRNT_TRD_FEE                   
,SUM(WRNT_TRD_ITMS)                 as WRNT_TRD_ITMS                  
,SUM(WRNT_TRD_VOL_BUYIN)            as WRNT_TRD_VOL_BUYIN             
,SUM(WRNT_TRD_VOL_SELL)             as WRNT_TRD_VOL_SELL              
,SUM(WRNT_TRD_CNTS_BUYIN)           as WRNT_TRD_CNTS_BUYIN            
,SUM(WRNT_TRD_CNTS_SELL)            as WRNT_TRD_CNTS_SELL             
,SUM(WRNT_TRD_VOL_BUYIN_O)          as WRNT_TRD_VOL_BUYIN_O           
,SUM(WRNT_TRD_VOL_BUYIN_C)          as WRNT_TRD_VOL_BUYIN_C           
,SUM(WRNT_TRD_VOL_SELL_O)           as WRNT_TRD_VOL_SELL_O            
,SUM(WRNT_TRD_VOL_SELL_C)           as WRNT_TRD_VOL_SELL_C            
,SUM(WRNT_TRD_CNTS_BUYIN_O)         as WRNT_TRD_CNTS_BUYIN_O          
,SUM(WRNT_TRD_CNTS_BUYIN_C)         as WRNT_TRD_CNTS_BUYIN_C          
,SUM(WRNT_TRD_CNTS_SELL_O)          as WRNT_TRD_CNTS_SELL_O           
,SUM(WRNT_TRD_CNTS_SELL_C)          as WRNT_TRD_CNTS_SELL_C           
,SUM(TOT_S1)                        as TOT_S1                         
,SUM(TOT_NET_S1)                    as TOT_NET_S1                     
,SUM(TOT_INCM_OFFER)                as TOT_INCM_OFFER                 
,SUM(ORDI_S1_INCM_HB_RMB)           as ORDI_S1_INCM_HB_RMB            
,SUM(ORDI_S1_INCM_SB_RMB)           as ORDI_S1_INCM_SB_RMB            
,SUM(ORDI_S1_INCM_TU_RMB)           as ORDI_S1_INCM_TU_RMB            
,SUM(ORDI_NET_S1_INCM_HB_RMB)       as ORDI_NET_S1_INCM_HB_RMB        
,SUM(ORDI_NET_S1_INCM_SB_RMB)       as ORDI_NET_S1_INCM_SB_RMB        
,SUM(ORDI_NET_S1_INCM_TU_RMB)       as ORDI_NET_S1_INCM_TU_RMB        
,SUM(ORDI_TRD_FEE_HB_RMB)           as ORDI_TRD_FEE_HB_RMB            
,SUM(ORDI_TRD_FEE_SB_RMB)           as ORDI_TRD_FEE_SB_RMB            
,SUM(ORDI_TRD_FEE_TU_RMB)           as ORDI_TRD_FEE_TU_RMB            
,SUM(ORDI_TRD_VOL_HB_RMB)           as ORDI_TRD_VOL_HB_RMB            
,SUM(ORDI_TRD_VOL_HB_RMB_BUYIN)     as ORDI_TRD_VOL_HB_RMB_BUYIN      
,SUM(ORDI_TRD_VOL_HB_RMB_SELL)      as ORDI_TRD_VOL_HB_RMB_SELL       
,SUM(ORDI_TRD_VOL_SB_RMB)           as ORDI_TRD_VOL_SB_RMB            
,SUM(ORDI_TRD_VOL_SB_RMB_BUYIN)     as ORDI_TRD_VOL_SB_RMB_BUYIN      
,SUM(ORDI_TRD_VOL_SB_RMB_SELL)      as ORDI_TRD_VOL_SB_RMB_SELL       
,SUM(ORDI_TRD_VOL_TU_RMB)           as ORDI_TRD_VOL_TU_RMB            
,SUM(ORDI_TRD_VOL_TU_RMB_BUYIN)     as ORDI_TRD_VOL_TU_RMB_BUYIN      
,SUM(ORDI_TRD_VOL_TU_RMB_SELL)      as ORDI_TRD_VOL_TU_RMB_SELL       
,SUM(ORDI_S1_INCM_STIB_AK)          as ORDI_S1_INCM_STIB_AK           
,SUM(CRD_S1_INCM_STIB_AK)           as CRD_S1_INCM_STIB_AK            
,SUM(S1_INCM_STIB_AK)               as S1_INCM_STIB_AK                
,SUM(ORDI_S1_INCM_STIB_RK)          as ORDI_S1_INCM_STIB_RK           
,SUM(CRD_S1_INCM_STIB_RK)           as CRD_S1_INCM_STIB_RK            
,SUM(S1_INCM_STIB_RK)               as S1_INCM_STIB_RK                
,SUM(ORDI_NET_S1_INCM_STIB_AK)      as ORDI_NET_S1_INCM_STIB_AK       
,SUM(CRD_NET_S1_INCM_STIB_AK)       as CRD_NET_S1_INCM_STIB_AK        
,SUM(NET_S1_INCM_STIB_AK)           as NET_S1_INCM_STIB_AK            
,SUM(ORDI_NET_S1_INCM_STIB_RK)      as ORDI_NET_S1_INCM_STIB_RK       
,SUM(CRD_NET_S1_INCM_STIB_RK)       as CRD_NET_S1_INCM_STIB_RK        
,SUM(NET_S1_INCM_STIB_RK)           as NET_S1_INCM_STIB_RK            
,SUM(ORDI_TRD_FEE_STIB_AK)          as ORDI_TRD_FEE_STIB_AK           
,SUM(CRD_TRD_FEE_STIB_AK)           as CRD_TRD_FEE_STIB_AK            
,SUM(TRD_FEE_STIB_AK)               as TRD_FEE_STIB_AK                
,SUM(ORDI_TRD_FEE_STIB_RK)          as ORDI_TRD_FEE_STIB_RK           
,SUM(CRD_TRD_FEE_STIB_RK)           as CRD_TRD_FEE_STIB_RK            
,SUM(TRD_FEE_STIB_RK)               as TRD_FEE_STIB_RK                
,SUM(TRD_VOL_AK)                    as TRD_VOL_AK                     
,SUM(TRD_VOL_AK_80)                 as TRD_VOL_AK_80                  
,SUM(TRD_VOL_AK_BUYIN)              as TRD_VOL_AK_BUYIN               
,SUM(TRD_VOL_AK_SELL)               as TRD_VOL_AK_SELL                
,SUM(TRD_VOL_AK_PRCH)               as TRD_VOL_AK_PRCH                
,SUM(ORDI_TRD_VOL_AK)               as ORDI_TRD_VOL_AK                
,SUM(ORDI_TRD_VOL_AK_80)            as ORDI_TRD_VOL_AK_80             
,SUM(ORDI_TRD_VOL_AK_BUYIN)         as ORDI_TRD_VOL_AK_BUYIN          
,SUM(ORDI_TRD_VOL_AK_SELL)          as ORDI_TRD_VOL_AK_SELL           
,SUM(ORDI_TRD_VOL_AK_PRCH)          as ORDI_TRD_VOL_AK_PRCH           
,SUM(CRD_TRD_VOL_AK)                as CRD_TRD_VOL_AK                 
,SUM(CRD_TRD_VOL_AK_80)             as CRD_TRD_VOL_AK_80              
,SUM(CRD_TRD_VOL_AK_BUYIN)          as CRD_TRD_VOL_AK_BUYIN           
,SUM(CRD_TRD_VOL_AK_SELL)           as CRD_TRD_VOL_AK_SELL            
,SUM(CRD_TRD_VOL_AK_PRCH)           as CRD_TRD_VOL_AK_PRCH            
,SUM(TRD_VOL_RK)                    as TRD_VOL_RK                     
,SUM(TRD_VOL_RK_80)                 as TRD_VOL_RK_80                  
,SUM(TRD_VOL_RK_BUYIN)              as TRD_VOL_RK_BUYIN               
,SUM(TRD_VOL_RK_SELL)               as TRD_VOL_RK_SELL                
,SUM(TRD_VOL_RK_PRCH)               as TRD_VOL_RK_PRCH                
,SUM(ORDI_TRD_VOL_RK)               as ORDI_TRD_VOL_RK                
,SUM(ORDI_TRD_VOL_RK_80)            as ORDI_TRD_VOL_RK_80             
,SUM(ORDI_TRD_VOL_RK_BUYIN)         as ORDI_TRD_VOL_RK_BUYIN          
,SUM(ORDI_TRD_VOL_RK_SELL)          as ORDI_TRD_VOL_RK_SELL           
,SUM(ORDI_TRD_VOL_RK_PRCH)          as ORDI_TRD_VOL_RK_PRCH           
,SUM(CRD_TRD_VOL_RK)                as CRD_TRD_VOL_RK                 
,SUM(CRD_TRD_VOL_RK_80)             as CRD_TRD_VOL_RK_80              
,SUM(CRD_TRD_VOL_RK_BUYIN)          as CRD_TRD_VOL_RK_BUYIN           
,SUM(CRD_TRD_VOL_RK_SELL)           as CRD_TRD_VOL_RK_SELL            
,SUM(CRD_TRD_VOL_RK_PRCH)           as CRD_TRD_VOL_RK_PRCH            
,SUM(TRD_ITMS_STIB_AK)              as TRD_ITMS_STIB_AK               
,SUM(TRD_ITMS_STIB_AK_80)           as TRD_ITMS_STIB_AK_80            
,SUM(ORDI_TRD_ITMS_STIB_AK)         as ORDI_TRD_ITMS_STIB_AK          
,SUM(ORDI_TRD_ITMS_STIB_AK_80)      as ORDI_TRD_ITMS_STIB_AK_80       
,SUM(CRD_TRD_ITMS_STIB_AK)          as CRD_TRD_ITMS_STIB_AK           
,SUM(CRD_TRD_ITMS_STIB_AK_80)       as CRD_TRD_ITMS_STIB_AK_80        
,SUM(TRD_ITMS_STIB_RK)              as TRD_ITMS_STIB_RK               
,SUM(TRD_ITMS_STIB_RK_80)           as TRD_ITMS_STIB_RK_80            
,SUM(ORDI_TRD_ITMS_STIB_RK)         as ORDI_TRD_ITMS_STIB_RK          
,SUM(ORDI_TRD_ITMS_STIB_RK_80)      as ORDI_TRD_ITMS_STIB_RK_80       
,SUM(CRD_TRD_ITMS_STIB_RK)          as CRD_TRD_ITMS_STIB_RK           
,SUM(CRD_TRD_ITMS_STIB_RK_80)       as CRD_TRD_ITMS_STIB_RK_80        
,SUM(CRD_CRD_TRD_VOL)               as CRD_CRD_TRD_VOL                
,SUM(CRD_CRD_TRD_S1)                as CRD_CRD_TRD_S1                 
,SUM(CRD_CRD_TRD_NET_S1)            as CRD_CRD_TRD_NET_S1             
,SUM(CRD_CRD_TRD_FEE)               as CRD_CRD_TRD_FEE                
,SUM(CRD_CRD_TRD_ITMS)              as CRD_CRD_TRD_ITMS               
,SUM(NEW_TA_TRD_VOL)                as NEW_TA_TRD_VOL                 
,SUM(NEW_TA_TRD_S1)                 as NEW_TA_TRD_S1                  
,SUM(NEW_TA_TRD_NET_S1)             as NEW_TA_TRD_NET_S1              
,SUM(NEW_TA_TRD_FEE)                as NEW_TA_TRD_FEE                 
,SUM(NEW_TA_TRD_ITMS)               as NEW_TA_TRD_ITMS                
,SUM(CLS_FND_TRD_VOL)               as CLS_FND_TRD_VOL                
,SUM(CLS_FND_TRD_S1)                as CLS_FND_TRD_S1                 
,SUM(CLS_FND_TRD_NET_S1)            as CLS_FND_TRD_NET_S1             
,SUM(CLS_FND_TRD_FEE)               as CLS_FND_TRD_FEE                
,SUM(CLS_FND_TRD_ITMS)              as CLS_FND_TRD_ITMS               
,SUM(S1_ASTK)                       as S1_ASTK                        
,SUM(S1_BSTK)                       as S1_BSTK                        
,SUM(S1_HK_STK)                     as S1_HK_STK                      
,SUM(S1_EXG_FND)                    as S1_EXG_FND                     
,SUM(NET_S1_ASTK)                   as NET_S1_ASTK                    
,SUM(NET_S1_BSTK)                   as NET_S1_BSTK                    
,SUM(NET_S1_HK_STK)                 as NET_S1_HK_STK                  
,SUM(NET_S1_EXG_FND)                as NET_S1_EXG_FND                 
,SUM(TRD_ITMS_ASTK)                 as TRD_ITMS_ASTK                  
,SUM(TRD_ITMS_ASTK_BUYIN)           as TRD_ITMS_ASTK_BUYIN            
,SUM(TRD_ITMS_ASTK_SELL)            as TRD_ITMS_ASTK_SELL             
,SUM(TRD_ITMS_ASTK_PRCH)            as TRD_ITMS_ASTK_PRCH             
,SUM(TRD_ITMS_BSTK)                 as TRD_ITMS_BSTK                  
,SUM(TRD_ITMS_BSTK_BUYIN)           as TRD_ITMS_BSTK_BUYIN            
,SUM(TRD_ITMS_BSTK_SELL)            as TRD_ITMS_BSTK_SELL             
,SUM(TRD_ITMS_HK_STK)               as TRD_ITMS_HK_STK                
,SUM(TRD_ITMS_HK_STK_BUYIN)         as TRD_ITMS_HK_STK_BUYIN          
,SUM(TRD_ITMS_HK_STK_SELL)          as TRD_ITMS_HK_STK_SELL           
,SUM(TRD_ITMS_EXG_FND)              as TRD_ITMS_EXG_FND               
,SUM(TRD_ITMS_EXG_FND_BUYIN)        as TRD_ITMS_EXG_FND_BUYIN         
,SUM(TRD_ITMS_EXG_FND_SELL)         as TRD_ITMS_EXG_FND_SELL          
,SUM(WRNT_TRD_CNTS_SH)              as WRNT_TRD_CNTS_SH              
,SUM(WRNT_TRD_VOL_SH)               as WRNT_TRD_VOL_SH                
,SUM(WRNT_S1_INCM_SH)               as WRNT_S1_INCM_SH                
,SUM(WRNT_NET_S1_INCM_SH)           as WRNT_NET_S1_INCM_SH            
,SUM(WRNT_TRD_FEE_SH)               as WRNT_TRD_FEE_SH                
,SUM(WRNT_TRD_ITMS_SH)              as WRNT_TRD_ITMS_SH               
,SUM(WRNT_TRD_VOL_BUYIN_SH)         as WRNT_TRD_VOL_BUYIN_SH          
,SUM(WRNT_TRD_VOL_SELL_SH)          as WRNT_TRD_VOL_SELL_SH           
,SUM(WRNT_TRD_CNTS_BUYIN_SH)        as WRNT_TRD_CNTS_BUYIN_SH         
,SUM(WRNT_TRD_CNTS_SELL_SH)         as WRNT_TRD_CNTS_SELL_SH          
,SUM(WRNT_TRD_VOL_BUYIN_O_SH)       as WRNT_TRD_VOL_BUYIN_O_SH        
,SUM(WRNT_TRD_VOL_BUYIN_C_SH)       as WRNT_TRD_VOL_BUYIN_C_SH        
,SUM(WRNT_TRD_VOL_SELL_O_SH)        as WRNT_TRD_VOL_SELL_O_SH         
,SUM(WRNT_TRD_VOL_SELL_C_SH)        as WRNT_TRD_VOL_SELL_C_SH         
,SUM(WRNT_TRD_CNTS_BUYIN_O_SH)      as WRNT_TRD_CNTS_BUYIN_O_SH       
,SUM(WRNT_TRD_CNTS_BUYIN_C_SH)      as WRNT_TRD_CNTS_BUYIN_C_SH       
,SUM(WRNT_TRD_CNTS_SELL_O_SH)       as WRNT_TRD_CNTS_SELL_O_SH        
,SUM(WRNT_TRD_CNTS_SELL_C_SH)       as WRNT_TRD_CNTS_SELL_C_SH        
,SUM(WRNT_TRD_CNTS_SZ)              as WRNT_TRD_CNTS_SZ               
,SUM(WRNT_TRD_VOL_SZ)               as WRNT_TRD_VOL_SZ                
,SUM(WRNT_S1_INCM_SZ)               as WRNT_S1_INCM_SZ                
,SUM(WRNT_NET_S1_INCM_SZ)           as WRNT_NET_S1_INCM_SZ            
,SUM(WRNT_TRD_FEE_SZ)               as WRNT_TRD_FEE_SZ                
,SUM(WRNT_TRD_ITMS_SZ)              as WRNT_TRD_ITMS_SZ               
,SUM(WRNT_TRD_VOL_BUYIN_SZ)         as WRNT_TRD_VOL_BUYIN_SZ          
,SUM(WRNT_TRD_VOL_SELL_SZ)          as WRNT_TRD_VOL_SELL_SZ           
,SUM(WRNT_TRD_CNTS_BUYIN_SZ)        as WRNT_TRD_CNTS_BUYIN_SZ         
,SUM(WRNT_TRD_CNTS_SELL_SZ)         as WRNT_TRD_CNTS_SELL_SZ          
,SUM(WRNT_TRD_VOL_BUYIN_O_SZ)       as WRNT_TRD_VOL_BUYIN_O_SZ        
,SUM(WRNT_TRD_VOL_BUYIN_C_SZ)       as WRNT_TRD_VOL_BUYIN_C_SZ        
,SUM(WRNT_TRD_VOL_SELL_O_SZ)        as WRNT_TRD_VOL_SELL_O_SZ         
,SUM(WRNT_TRD_VOL_SELL_C_SZ)        as WRNT_TRD_VOL_SELL_C_SZ         
,SUM(WRNT_TRD_CNTS_BUYIN_O_SZ)      as WRNT_TRD_CNTS_BUYIN_O_SZ       
,SUM(WRNT_TRD_CNTS_BUYIN_C_SZ)      as WRNT_TRD_CNTS_BUYIN_C_SZ       
,SUM(WRNT_TRD_CNTS_SELL_O_SZ)       as WRNT_TRD_CNTS_SELL_O_SZ        
,SUM(WRNT_TRD_CNTS_SELL_C_SZ)       as WRNT_TRD_CNTS_SELL_C_SZ                       
			FROM DDW_PROD.T_DDW_F10_CUST_TRD_INCM_DAY 
            WHERE SUBSTR(CAST(BUS_DATE as STRING),1,6) = SUBSTR('%d{yyyyMMdd}',1,6)
			GROUP BY CUST_NO
			
			)  a1
 ON        t.CUST_NO = a1.CUST_NO
 LEFT JOIN (select CUST_NO,ORDI_PRDCT_GL_INT,CRD_PRDCT_GL_INT from DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON_TEMP where ORDI_PRDCT_GL_INT+CRD_PRDCT_GL_INT > 0) a2
 ON        t.CUST_NO = a2.CUST_NO
 LEFT JOIN (select CUST_NO,ORDI_FCT_GL_INT,CRD_FCT_GL_INT from DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON_TEMP1 where ORDI_FCT_GL_INT+CRD_FCT_GL_INT > 0) a3
 ON        t.CUST_NO = a3.CUST_NO
 WHERE COALESCE(a1.CUST_NO,a2.CUST_NO,a3.CUST_NO) IS NOT NULL 
 GROUP BY   t.CUST_NO  
           ,t.BRH_NO   
           ,t.CUST_CGY
           ,ETL_DT ;		   
		   
----
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON_TEMP ;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON_TEMP1 ;

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F10_CUST_TRD_INCM_MON',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;

 invalidate metadata DDW_PROD.T_DDW_F10_CUST_TRD_INCM_MON;
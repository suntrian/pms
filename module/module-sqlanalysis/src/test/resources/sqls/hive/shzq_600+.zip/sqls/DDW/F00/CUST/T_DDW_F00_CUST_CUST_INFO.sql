 ----/* ***************************************** SQL Begin *****************************************  */
  ----/* 脚本功能:客户信息表                                                                         */
  ----/* 创建人:黄勇华                                                                               */
  ----/* 创建时间:2016-11-30                                                                        */ 

  
------删除临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP1;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP2;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP5;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP3;
-----------------------删除临时表-------------------- 

----创建二代证验证表
 CREATE TABLE  DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP1
 as SELECT t.KHH
           ,t.EDZ
	FROM  (SELECT           KHH
                           ,EDZ 
	       FROM            EDW_PROD.T_EDW_T02_LCJZKH 
	       WHERE           EDZ = 1 
	       AND             BUS_DATE = %d{yyyyMMdd} 
		   UNION ALL
		   SELECT           GTKHH   as KHH
                           ,EDZ 
	       FROM            EDW_PROD.T_EDW_T02_LCFXCKH 
	       WHERE           EDZ = 1 
	       AND             BUS_DATE = %d{yyyyMMdd} 
	       UNION ALL
	       SELECT           t.KHH as KHH
	                        ,1    as EDZ
	       FROM ( SELECT     KHH
	                         ,RQ
			      FROM       EDW_PROD.T_EDW_T05_TYGTXTCZMX
			      WHERE      YWKM = '20090'
			      OR         ZY LIKE '%二代证验证%'
			      UNION ALL
                  SELECT      a.KHH
			                  ,b.SQRQ as RQ
			      FROM   (SELECT   YYB
			                       ,ZJBH
							       ,KHH
					      FROM     EDW_PROD.T_EDW_T01_TKHXX
					      WHERE    BUS_DATE = %d{yyyyMMdd}
			              )            a
			      LEFT JOIN (SELECT   ZJBH
			                          ,YYB
								      ,SQRQ 
					         FROM  EDW_PROD.T_EDW_T02_TGMSFCXSQ 
					         WHERE CLJG = 1
					        )         b
			      ON      a.YYB = b.YYB
			      AND     a.ZJBH = b.ZJBH
			     )      t
	       WHERE   EXISTS (SELECT 1 FROM EDW_PROD.T_EDW_T01_TKHXX  a1 
				           WHERE t.RQ  = a1.YGT_KHRQ 
					       AND   t.KHH = a1.KHH 
					       AND   a1.BUS_DATE = %d{yyyyMMdd}
					      )
	       GROUP BY KHH,EDZ
	    )              t
	GROUP BY t.KHH,t.EDZ ;

----创建临时表2---------------------------------	  
 CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP2 
 as     SELECT t.RQ,t.KHH,t.ZY,t.LY
		FROM (SELECT  RQ,KHH,FSSJ,ZY,'JZJY' AS LY , ROW_NUMBER() OVER(PARTITION BY KHH ORDER BY RQ DESC, FSSJ DESC) AS NUM		
		      FROM     EDW_PROD.T_EDW_T05_TYWXTCZMX
		      WHERE    XTBS = 'JZJY' AND ywkm = '30599' AND zy like('%佣金%')  and zy like('%对象复核%') 
              UNION ALL
		      SELECT   RQ,KHH,FSSJ,ZY,'RZRQ' AS LY ,ROW_NUMBER() OVER(PARTITION BY KHH ORDER BY RQ DESC, FSSJ DESC) AS NUM		
		      FROM     EDW_PROD.T_EDW_T05_TYWXTCZMX
		      WHERE    XTBS = 'RZRQ' AND ywkm = '30599' AND zy like('%佣金%')  and zy like('%对象复核%') 
		      )        t
		WHERE t.NUM = 1
	  ;
 ---创建存管银行临时表3
 CREATE TABLE  DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP3
 as    SELECT T.KHH,GROUP_CONCAT(T.YHDM,',') as yhdm
FROM  (SELECT  distinct a.khh,b.yhdm
       FROM       ( SELECT  GTZJZH
	                        ,KHH
                    FROM    EDW_PROD.T_EDW_T02_TZJZH 
                    WHERE   ZZHBZ = 1 
				    AND     XTBS = 'JZJY'
				    AND     BUS_DATE = %d{yyyyMMdd}
                   )            a
       INNER JOIN  ( SELECT  GTZJZH
	                        ,YHDM
                     FROM    EDW_PROD.T_EDW_T02_TCGZHDY
                     WHERE   XTBS = 'JZJY'
					 AND     BUS_DATE = %d{yyyyMMdd}
                    )           b
       ON   a.GTZJZH = b.GTZJZH
	   )  T GROUP BY T.KHH
 ;
-------洗钱风险等级临时表4
-- CREATE TABLE  DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP4
-- as SELECT    a.KHH,b.NOTE 
--    FROM        EDW_PROD.T_EDW_T99_TKHYWSX      a
--	LEFT JOIN  (SELECT  IBM
--	                    ,NOTE
--						,DT 
--			     FROM    YGTCX.CIF_TXTDM 
--				 WHERE   FLDM = 'XQFXDJ'
--				 WHERE   DT = '%d{yyyyMMdd}'
--				 )            b
--	ON        a.XQFXDJDM = CAST(b.IBM AS STRING)
--	WHERE     a.BUS_DATE = %d{yyyyMMdd}
--	;
---最近联系人临时表5
 CREATE TABLE  DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP5
 as SELECT  a.KHH
	       ,a.LXRMC
    FROM  (SELECT  KHH
				   ,LXRMC
				   ,ROW_NUMBER() OVER(PARTITION BY KHH ORDER BY LXRID DESC) as NUM
		   FROM    EDW_PROD.T_EDW_T01_TLXR
		   WHERE   BUS_DATE = %d{yyyyMMdd}
		   ) a
    WHERE  a.NUM = 1
 ;
--CREATE TABLE DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP1 AS 
--  SELECT t1.khh,t1.rq, 1 as bz 
--  FROM (
--         SELECT t.khh,t.rq
--         FROM (
--	             SELECT  khh,rq 
--                 FROM   EDW_PROD.T_EDW_T05_TYGTXTCZMX
--                 WHERE  YWKM = '20090' OR  zy like '%二代证验证%'
--                 UNION ALL
--                 SELECT     a1.khh,a2.sqrq as rq
--                 FROM       (SELECT yyb,zjbh,khh FROM  EDW_PROD.T_EDW_T01_TKHXX where bus_date = %d{yyyyMMdd})     a1
--                 INNER JOIN (SELECT zjbh,yyb,sqrq FROM EDW_PROD.T_EDW_T02_TGMSFCXSQ WHERE CLJG = 1)                a2
--                 ON           a1.yyb = a2.yyb
--                 AND          a1.zjbh = a2.zjbh
--              ) t
--       GROUP BY t.khh,t.rq
--      )   t1
--	  ;

	  

--------插入数据开始-----------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_CUST_CUST_INFO
(
                                     CUST_NO                                 --客户号                               
                                    ,CUST_NAME                               --客户姓名    
								    ,BRH_NO                                  --营业部编号   	
								    ,BRH_NAME                                --营业部名称   	
								    ,OPNAC_MOD                               --开户方式 
                                    ,OPNAC_CLNT								 --开户终端
									,OPNAC_DT                                --开户日期
								    ,ORDI_OPNAC_DT                           --普通账户开户日期  
                                    ,CRD_OPNAC_DT                            --信用账户开户日期
									,WRNT_OPNAC_DT                           --期权账户开户日期
									,CNCLACT_DT                              --销户日期
                                    ,ORDI_CNCLACT_DT                         --普通账户销户日期	
                                    ,CRD_CNCLACT_DT                          --信用账户销户日期
                                    ,WRNT_CNCLACT_DT                         --期权账户销户日期
                                    ,ORDI_CUST_GROUP                         --普通账户客户群组	
                                    ,CRD_CUST_GROUP                          --信用账户客户群组
                                    ,WRNT_CUST_GROUP                         --期权账户客户群组									
								    ,CTF_CGY_CD                              --证件类别代码  	
								    ,CTF_NO                                  --证件编号    	
								    ,CUST_CGY                                --客户类别
									,CUST_STAT                               --客户状态
									,ORDI_CUST_STAT                          --普通账户客户状态 
                                    ,CRD_CUST_STAT                           --信用账户客户状态									
								    ,WRNT_CUST_STAT                          --期权账户客户状态    	
								    ,GNDR_CD                                 --性别代码    	
								    ,DEPMGT_BANK                             --存管银行    	
								    ,CTRL_ATTR                               --控制属性    	
								    ,M_LAUND_RSK_LVL                         --洗钱风险等级 
                                    ,M_LAUND_RSK_IDSTR_CGY_CD                --洗钱风险行业类别代码									
								    ,RSK_BEAR_ABLTY                          --风险承受能力  	
								    ,IMAGE_TP                                --影像类型    	
								    ,CTF_EXPR_DT                             --证件截止日期  	
								    ,CTCT_ADDR                               --联系地址    	
								    ,CTCT_TEL                                --联系电话
                                    ,CTCT_PSN_NAME	                         --联系人姓名									
								    ,PHONE                                   --手机  
                                    ,BRTH_YM                                 --出生年月									
								    ,EDU_CD                                  --学历代码    	
								    ,OCP_CD                                  --职业代码    	
								    ,SECOND_CARD_VRFCTN                      --是否二代证   	
								    ,CUST_RSK_LVL                            --客户风险级别  	
								    ,FRIST_EVAL_DT                           --初次评测日期 
                                    ,CMSN_SETUP_DT                           --佣金设置日期
                                    ,CMSN_SETUP_ABST                         --佣金设置摘要									
								    ,IF_OPN_PHONE_ODR                        --是否开通手机委托
									,ORDI_ODR_MOD_SCP                        --普通账户委托范围
									,CRD_ODR_MOD_SCP                         --信用账户委托范围
									,WRNT_ODR_MOD_SCP                        --期权账户委托范围									
                                    ,CTF_ADDR                                --证件地址 
									,CITY_CD                                 --国家代码
									,NATN_CD                                 --民族代码
									,MARG_STAT_CD                            --婚姻状况代码 
                                    ,AGE                                     --年龄	
                                    ,CID									
) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT                         t.KHH                            as CUST_NO                                 --客户号                    
                                ,t.KHXM                          as CUST_NAME                               --客户姓名    
                                ,t.YYB                           as BRH_NO                                  --营业部编号   	
                                ,NVL(a2.BRH_SHRTNM,a10.FILIL_DEPT_SHRTNM)                   as BRH_NAME     --营业部名称   	
                                ,t.KH_KHFS                       as OPNAC_MOD                               --开户方式 
                                ,a11.KHZD                        as OPNAC_CLNT								 --开户终端
                                ,t.YGT_KHRQ                      as OPNAC_DT
								,t.JZJYKH_KHRQ                   as ORDI_OPNAC_DT                           --普通账户开户日期  
                                ,t.RZRQKH_KHRQ                   as CRD_OPNAC_DT                            --信用账户开户日期
                                ,t.GGQQKH_KHRQ                   as WRNT_OPNAC_DT                           --期权账户开户日期
                                ,t.YGT_XHRQ                      as CNCLACT_DT
								,t.JZJYKH_XHRQ                   as ORDI_CNCLACT_DT                         --普通账户销户日期	
                                ,t.RZRQKH_XHRQ                   as CRD_CNCLACT_DT                          --信用账户销户日期
                                ,t.GGQQKH_XHRQ                   as WRNT_CNCLACT_DT                         --期权账户销户日期                                
								,t.JZJYKH_KHQZ                   as ORDI_CUST_GROUP                         --普通账户客户群组	
                                ,t.RZRQKH_KHQZ                   as CRD_CUST_GROUP                          --信用账户客户群组
                                ,t.GGQQKH_KHQZ                   as WRNT_CUST_GROUP                         --期权账户客户群组			
                                ,t.ZJLBDM                        as CTF_CGY_CD                              --证件类别代码  	
                                ,t.ZJBH                          as CTF_NO                                  --证件编号    	
                                ,t.KHLB                          as CUST_CGY                                --客户类别
                                ,t.YGT_KHZTDM                    as CUST_STAT
								,t.JZJYKH_KHZTDM                 as ORDI_CUST_STAT                          --普通账户客户状态 
                                ,t.RZRQKH_KHZTDM                 as CRD_CUST_STAT                           --信用账户客户状态			
                                ,t.GGQQKH_KHZTDM                 as WRNT_CUST_STAT                          --期权账户客户状态    	
                                ,a1.XBDM                         as GNDR_CD                                 --性别代码    	
                                ,a3.YHDM                         as DEPMGT_BANK                             --存管银行    	
                                ,a4.KZSX                         as CTRL_ATTR                               --控制属性    	
                                ,a4.XQFXDJDM                     as M_LAUND_RSK_LVL                            --洗钱风险等级 
                                ,a4.FXQHYLBDM                    as M_LAUND_RSK_IDSTR_CGY_CD                --洗钱风险行业类别代码														  
                                ,t.FXCSNL                        as RSK_BEAR_ABLTY                          --风险承受能力  	
                                ,CASE WHEN a5.YWXTKHH IS NOT NULL
       								     THEN '有'
										 ELSE '无'
										 END                     as IMAGE_TP                                --影像类型    	
                                ,t.ZJJZRQ                        as CTF_EXPR_DT                             --证件截止日期  	
                                ,t.LXDZ                          as CTCT_ADDR                               --联系地址    	
                                ,t.LXDH                          as CTCT_TEL                                --联系电话
                                ,a6.LXRMC                        as CTCT_PSN_NAME	                         --联系人姓名				
                                ,t.SJ                            as PHONE                                   --手机  
                                ,a1.CSRQ                         as BRTH_YM                                 --出生年月					
                                ,a1.XLDM                         as EDU_CD                                  --学历代码    	
                                ,a1.ZYDM                         as OCP_CD                                  --职业代码    	
                                ,CASE WHEN a7.EDZ = 1
             						  THEN '已验证'	
 									  ELSE '未验证'
									  END                        as SECOND_CARD_VRFCTN                      --是否二代证   	
                                ,t.KHFXJB                        as CUST_RSK_LVL                            --客户风险级别  	
                                ,a8.ARCHIVE_DATE                 as FRIST_EVAL_DT                           --初次评测日期 
                                ,a9.RQ                           as CMSN_SETUP_DT                           --佣金设置日期
                                ,a9.ZY                           as CMSN_SETUP_ABST                         --佣金设置摘要				
                                ,CASE WHEN MOD(t.JZJYKH_WTFSFW,128)>63 
								      THEN '开通' 
									  ELSE '未开通' 
									  END                        as IF_OPN_PHONE_ODR                        --是否开通手机委托
                                ,t.JZJYKH_WTFSFW                 as ORDI_ODR_MOD_SCP                        --普通账户委托范围
								,t.RZRQKH_WTFSFW                 as CRD_ODR_MOD_SCP                         --信用账户委托范围
								,t.GGQQKH_WTFSFW                 as WRNT_ODR_MOD_SCP                        --期权账户委托范围			
								,t.ZJDZ                          as CTF_ADDR                                --证件地址
                                ,t.GJDM                          as CITY_CD        --国家代码	
                                ,a1.MZDM                         as NATN_CD                                 --民族代码
                                ,a1.HYZKDM                       as MARG_STAT_CD                            --婚姻状况代码 
                                ,CASE WHEN CAST(SUBSTR('%d{yyyyMMdd}',5,2) AS INT) > CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(a1.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
                                      THEN CAST(SUBSTR('%d{yyyyMMdd}',1,4) AS INT) - CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),1,4) AS INT)
                                      WHEN CAST(SUBSTR('%d{yyyyMMdd}',5,2) AS INT) < CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(a1.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
                                      THEN CAST(SUBSTR('%d{yyyyMMdd}',1,4) AS INT) - CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),1,4) AS INT) - 1
                                      WHEN CAST(SUBSTR('%d{yyyyMMdd}',5,2) AS INT) = CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(a1.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
                                      AND CAST(SUBSTR('%d{yyyyMMdd}',7,2) AS INT) >= CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),7,2) AS INT)
                                      THEN CAST(SUBSTR('%d{yyyyMMdd}',1,4) AS INT) - CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),1,4) AS INT)
                                      WHEN CAST(SUBSTR('%d{yyyyMMdd}',5,2) AS INT) = CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),5,2) AS INT) AND NVL(a1.CSRQ,0) BETWEEN 10000101 AND %d{yyyyMMdd}
                                      AND CAST(SUBSTR('%d{yyyyMMdd}',7,2) AS INT) < CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),7,2) AS INT)
                                      THEN CAST(SUBSTR('%d{yyyyMMdd}',1,4) AS INT) - CAST(SUBSTR(CAST(NVL(a1.CSRQ,0) AS STRING),1,4) AS INT) - 1
                                      ELSE 0 END                       as AGE			   --年龄	
                                ,t.CID									  
  FROM          EDW_PROD.T_EDW_T01_TKHXX                             t
  LEFT JOIN     EDW_PROD.T_EDW_T01_TGRKHXX                           a1
  ON            t.KHH = a1.KHH 
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_BRH                           a2
  ON            t.YYB = a2.BRH_NO
  AND           a2.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_INR_ORG_FILIL_DEPT         a10
  ON            t.YYB = a10.FILIL_DEPT_CDG
  AND           a10.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP3              a3
  ON            t.KHH = a3.KHH
  LEFT JOIN		EDW_PROD.T_EDW_T99_TKHYWSX                           a4
  ON            t.KHH = a4.KHH
  AND           a4.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     (SELECT   YWXTKHH 
                 FROM     YGTCX.EIMAGE_TDA_KHJBDA 
				 WHERE    YXLX IN (9,10)
				 AND      DT = '%d{yyyyMMdd}'
				 GROUP BY YWXTKHH
				)                                                     a5
  ON            t.KHH = a5.YWXTKHH
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP5               a6
  ON              t.KHH = a6.KHH
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP1               a7
  ON            t.KHH = a7.KHH 
  LEFT JOIN  (SELECT a.CLIENT_ID AS KHH,a.ARCHIVE_DATE
              FROM ( SELECT BRANCH_NO,CLIENT_ID,ARCHIVE_DATE
                           ,ROW_NUMBER() OVER(PARTITION BY BRANCH_NO,CLIENT_ID ORDER BY ARCHIVE_DATE DESC,OC_TIME DESC) AS NUM
	                 FROM FXQ.HSMAN_AML_CLIENTLEVEL_CHECK
	                 WHERE DT = '%d{yyyyMMdd}'
	                 AND   DELETE_FLAG = '0'
	                 AND   CHECK_STATUS = '5'
	                )               a
              WHERE a.NUM = 1
			 )                                                        a8
  ON        t.KHH = TRIM(a8.KHH)
  LEFT JOIN     DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP2               a9
  ON            t.KHH = a9.KHH
  AND           a9.LY = 'JZJY' 
  LEFT JOIN   EDW_PROD.T_EDW_T02_LCFXCKH     a11
  ON          t.KHH = a11.GTKHH
  AND         a11.BUS_DATE = %d{yyyyMMdd}
  AND         LENGTH(TRIM(NVL(a11.GTKHH,''))) > 0
  LEFT JOIN   (SELECT TRD_DT
                      ,MAX(NAT_DT) as NAT_DT_MAX
               FROM EDW_PROD.T_EDW_T99_TRD_DATE
			   WHERE BUS_DATE = %d{yyyyMMdd}
			   AND   TRD_DT = %d{yyyyMMdd}
			   GROUP BY TRD_DT
			   ) a12
  ON          t.BUS_DATE = a12.TRD_DT  
  WHERE         t.BUS_DATE = %d{yyyyMMdd} 
  AND          NVL(t.YGT_KHRQ,20140101) < = a12.NAT_DT_MAX
  ;
  
  -----------------------------加载结束--------------------
------删除临时表
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP1;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP2;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP5;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP3;
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_CUST_CUST_INFO_TEMP;
-----------------------删除临时表-------------------- 

INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_CUST_CUST_INFO',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_CUST_CUST_INFO ;
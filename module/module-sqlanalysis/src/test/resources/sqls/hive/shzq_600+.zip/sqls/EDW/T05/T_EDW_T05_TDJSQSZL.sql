--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:待交收清算资料表                                                                     */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */  
TRUNCATE TABLE EDW_PROD.T_EDW_T05_TDJSQSZL ;
------插入数据
INSERT OVERWRITE EDW_PROD.T_EDW_T05_TDJSQSZL
(
                                    DJSQS_LSH                           --待交收清算流水号                           
                                   ,WTH                                 --委托合同号                              
                                   ,KHH                                 --客户号                                
                                   ,KHXM                                --客户姓名                               
                                   ,KHQZ                                --客户群组                               
                                   ,GSFLDM                              --公司分类代码                             
                                   ,GDH                                 --股东号                                
                                   ,GDXM                                --股东姓名                               
                                   ,JYS                                 --交易所                                
                                   ,ZJJSLX                              --交易资金结算类型                           
                                   ,JSJG                                --结算机构                               
                                   ,JSZH                                --结算帐户                               
                                   ,JSBZDM                              --结算币种                               
                                   ,ZHGLJG                              --帐户管理机构                             
                                   ,YYB                                 --营业部                                
                                   ,WTFS                                --委托方式                               
                                   ,XWDM                                --席位代码                               
                                   ,ZQDM                                --证券代码                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQLB                                --证券类别                               
                                   ,WTLB                                --委托类别                               
                                   ,CJBH                                --成交编号                               
                                   ,CJRQ                                --成交日期                               
                                   ,CJSJ                                --成交时间                               
                                   ,SBSJ                                --申报时间                               
                                   ,CJBS                                --成交笔数                               
                                   ,CJSL                                --成交数量                               
                                   ,CJJG                                --成交价格                               
                                   ,JSJ                                 --结算价                                
                                   ,LXJG                                --利息价格                               
                                   ,CJJE                                --成交金额                               
                                   ,LXJE                                --利息金额                               
                                   ,YSJE                                --应收金额                               
                                   ,BZS1                                --标准佣金                               
                                   ,S1                                  --实收佣金                               
                                   ,YHS                                 --印花税                                
                                   ,S3                                  --过户费                                
                                   ,S4                                  --附加费                                
                                   ,S5                                  --结算费                                
                                   ,S6                                  --交易规费                               
                                   ,S11                                 --一级费用_经手费                           
                                   ,S12                                 --一级费用_证管费                           
                                   ,S13                                 --一级费用_过户费                           
                                   ,S15                                 --一级费用_结算费                           
                                   ,S16                                 --一级费用_风险基金                          
                                   ,YSJE_YJ                             --一级应收金额                             
                                   ,YSSL                                --应收股份                               
                                   ,JSRQ                                --交收日期                               
                                   ,JSBZ                                --交收标志                               
                                   ,YSJE_2                              --二次交收应收金额                           
                                   ,YSSL_2                              --二次交收应收股份                           
                                   ,JSRQ_2                              --二次交收日期                             
                                   ,JSBZ_2                              --二次交收标志                             
                                   ,YJDJFS                              --佣金策略类别                             
                                   ,FID                                 --佣金策略编号                             
                                   ,FSYYB                               --委托发生营业部                            
                                   ,ZJDJXM_LSH                          --资金冻结项目流水号                          
                                   ,LSH_ZQDJXM                          --股份冻结项目流水号                          
                                   ,BCSL                                --本次数量    
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
SELECT 
                                    t.LSH                as DJSQS_LSH                            --流水号                                 
                                   ,t.WTH                as WTH                                  --委托合同号                               
                                   ,t.KHH                as KHH                                  --客户号                                 
                                   ,t.KHXM               as KHXM                                 --客户姓名                                
                                   ,t.KHQZ               as KHQZ                                 --客户群组                                
                                   ,t.GSFL               as GSFLDM                               --公司分类                                
                                   ,t.GDH                as GDH                                  --股东号                                 
                                   ,t.GDXM               as GDXM                                 --股东姓名                                
                                   ,t.JYS                as JYS                                  --交易所                                 
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.JSLX AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                 as ZJJSLX                               --结算类型                                
                                   ,t.JSJG               as JSJG                                 --结算机构                                
                                   ,t.JSZH               as JSZH                                 --结算帐户                                
                                   ,t.BZ                 as JSBZDM                               --结算币种                                
                                   ,t.ZHGLJG             as ZHGLJG                               --帐户管理机构                              
                                   ,CAST(COALESCE(t4.MBJGDM,NULLIF(CONCAT('ERR',CAST(t.YYB AS VARCHAR(20))),'ERR')) AS VARCHAR(20))                as YYB                                  --营业部                                 
                                   ,t.WTFS               as WTFS                                 --委托方式                                
                                   ,t.XWDM               as XWDM                                 --席位代码                                
                                   ,t.ZQDM               as ZQDM                                 --证券代码                                
                                   ,t.ZQMC               as ZQMC                                 --证券名称                                
                                   ,case when SUBSTR(t.ZQDM,1,3) = '206'
								         AND JYS = 'SH'
										 THEN 'H2'
								         ELSE t.ZQLB
										 END as ZQLB                                 --证券类别                                
                                   ,t.WTLB               as WTLB                                 --委托类别                                
                                   ,t.CJBH               as CJBH                                 --成交编号                                
                                   ,t.CJRQ               as CJRQ                                 --成交日期                                
                                   ,t.CJSJ               as CJSJ                                 --成交时间                                
                                   ,t.SBSJ               as SBSJ                                 --申报时间                                
                                   ,t.CJBS               as CJBS                                 --成交笔数                                
                                   ,t.CJSL               as CJSL                                 --成交数量                                
                                   ,t.CJJG               as CJJG                                 --成交价格                                
                                   ,t.JSJ                as JSJ                                  --结算价                                 
                                   ,t.LXJG               as LXJG                                 --利息价格                                
                                   ,t.CJJE               as CJJE                                 --成交金额                                
                                   ,t.LXJE               as LXJE                                 --利息金额                                
                                   ,t.YSJE               as YSJE                                 --应收(付)金额                             
                                   ,t.BZS1               as BZS1                                 --标准佣金                                
                                   ,t.S1                 as S1                                   --实收佣金                                
                                   ,t.S2                 as YHS                                  --印花税                                 
                                   ,t.S3                 as S3                                   --过户费                                 
                                   ,t.S4                 as S4                                   --附加费                                 
                                   ,t.S5                 as S5                                   --结算费                                 
                                   ,t.S6                 as S6                                   --交易规费                                
                                   ,t.S11                as S11                                  --一级费用_经手费                            
                                   ,t.S12                as S12                                  --一级费用_证管费                            
                                   ,t.S13                as S13                                  --一级费用_过户费                            
                                   ,t.S15                as S15                                  --一级费用_结算费                            
                                   ,t.S16                as S16                                  --一级费用_风险基金                           
                                   ,t.YSJE_YJ            as YSJE_YJ                              --一级应收(付)金额                           
                                   ,t.YSSL               as YSSL                                 --应收(付)股份                             
                                   ,t.JSRQ               as JSRQ                                 --交收日期                                
                                   ,t.JSBZ               as JSBZ                                 --交收标志                                
                                   ,t.YSJE_2             as YSJE_2                               --二次交收应收(付)金额                         
                                   ,t.YSSL_2             as YSSL_2                               --二次交收应收(付)股份                         
                                   ,t.JSRQ_2             as JSRQ_2                               --二次交收日期                              
                                   ,t.JSBZ_2             as JSBZ_2                               --二次交收标志                              
                                   ,CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.YJDJFS AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )               as YJDJFS                               --佣金策略类别                              
                                   ,t.FID                as FID                                  --佣金策略编号                              
                                   ,t.FSYYB              as FSYYB                                --委托发生营业部                             
                                   ,t.LSH_ZJDJXM         as ZJDJXM_LSH                           --资金冻结项目流水号                           
                                   ,t.LSH_ZQDJXM         as LSH_ZQDJXM                           --股份冻结项目流水号                           
                                   ,t.BCSL               as BCSL                                 --本次数量   
                                   ,'JZJY'				 as XTBS								   
 FROM  			JZJYCX.DATACENTER_TDJSQSZL 						t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t1 
 ON             t1.DMLX = 'ZJJSLX'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.JSLX AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING 			t2 
 ON             t2.DMLX = 'YJDJFS'
 AND            t2.YXT = 'JZJY'
 AND            t2.YDM = CAST(t.YJDJFS AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T03_ORG_CODE_MAPPING    t4
 ON             t4.YXT = 'JZJY'
 AND            t4.JGDM = CAST(t.YYB AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}'
-- UNION ALL
-- SELECT                             0                          --待交收清算流水号                           
--                                   ,WTH                                 --委托合同号                              
--                                   ,KHH                                 --客户号                                
--                                   ,KHXM                                --客户姓名                               
--                                   ,KHQZ                                --客户群组                               
--                                   ,GSFLDM                              --公司分类代码                             
--                                   ,GDH                                 --股东号                                
--                                   ,GDXM                                --股东姓名                               
--                                   ,JYS                                 --交易所                                
--                                   ,ZJJSLX                              --交易资金结算类型                           
--                                   ,JSJG                                --结算机构                               
--                                   ,JSZH                                --结算帐户                               
--                                   ,'RMB'                              --结算币种                               
--                                   ,ZHGLJG                              --帐户管理机构                             
--                                   ,YYB                                 --营业部                                
--                                   ,WTFS                                --委托方式                               
--                                   ,XWDM                                --席位代码                               
--                                   ,ZQDM                                --证券代码                               
--                                   ,ZQMC                                --证券名称                               
--                                   ,'H2' ZQLB                                --证券类别                               
--                                   ,WTLB                                --委托类别                               
--                                   ,CJBH                                --成交编号                               
--                                   ,CJRQ                                --成交日期                               
--                                   ,CJSJ                                --成交时间                               
--                                   ,SBSJ                                --申报时间                               
--                                   ,CJBS                                --成交笔数                               
--                                   ,CJSL                                --成交数量                               
--                                   ,CJJG                                --成交价格                               
--                                   ,JSJ                                 --结算价                                
--                                   ,LXJG                                --利息价格                               
--                                   ,CJJE                                --成交金额                               
--                                   ,LXJE                                --利息金额                               
--                                   ,YSJE                                --应收金额                               
--                                   ,BZS1                                --标准佣金                               
--                                   ,S1                                  --实收佣金                               
--                                   ,0                                 --印花税                                
--                                   ,S3                                  --过户费                                
--                                   ,S4                                  --附加费                                
--                                   ,S5                                  --结算费                                
--                                   ,S6                                  --交易规费                               
--                                   ,S11                                 --一级费用_经手费                           
--                                   ,S12                                 --一级费用_证管费                           
--                                   ,S13                                 --一级费用_过户费                           
--                                   ,S15                                 --一级费用_结算费                           
--                                   ,S16                                 --一级费用_风险基金                          
--                                   ,YSJE_YJ                             --一级应收金额                             
--                                   ,YSSL                                --应收股份                               
--                                   ,JSRQ                                --交收日期                               
--                                   ,0                                --交收标志                               
--                                   ,0                              --二次交收应收金额                           
--                                   ,0                              --二次交收应收股份                           
--                                   ,99999999                              --二次交收日期                             
--                                   ,0                              --二次交收标志                             
--                                   ,YJDJFS                              --佣金策略类别                             
--                                   ,FID                                 --佣金策略编号                             
--                                   ,FSYYB                               --委托发生营业部                            
--                                   ,0                          --资金冻结项目流水号                          
--                                   ,0                          --股份冻结项目流水号                          
--                                   ,BCSL                                --本次数量    
--                                   ,XTBS	
--	FROM EDW_PROD.T_EDW_T05_TJGMXLS
--	WHERE WTLB = 114
--	AND   ZQDM = '206014'
--	AND JYS ='SH'
 
 
 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T05_TDJSQSZL',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
invalidate metadata EDW_PROD.T_EDW_T05_TDJSQSZL;
--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:OTC产品代码表                                                                           */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2018-08-29                                                                           */  

TRUNCATE TABLE EDW_PROD.T_EDW_T04_TFP_CPDM ;
------插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TFP_CPDM
 (                                  ID                       --ID
                                   ,CPDM                     --产品代码
                                   ,CPDM_XT                  --产品代码_系统
                                   ,CPJP                     --产品简拼
                                   ,CPFL                     --产品大类
  								   ,CPMC                     --产品名称
                                   ,CPQC                     --产品全称
                                   ,SYLX                     --收益类型
                                   ,CPLX                     --产品类型
                                   ,FXPJ                     --风险评级
                                   ,FXJB_FXF                 --风险级别_发行方
                                   ,TZTS                     --投资天数
                                   ,TZPZ                     --投资品种
                                   ,CPPJ                     --产品评级
                                   ,OTC_JYS                  --销售市场
                                   ,FXJG                     --发行机构
                                   ,ZLXS                     --是否主力销售
                                   ,SFRX                     --热销标志
                                   ,SFXCP                    --新产品
                                   ,CXGX                     --承销关系
                                   ,ZYCD                     --重要程度
                                   ,BZDM                     --币种代码
                                   ,CPZT                     --产品状态
                                   ,SJBZ                     --上架标志
                                   ,SJRQ                     --上架日期
                                   ,CPDM_WB                  --产品代码外部
                                   ,CPDM_TA                  --产品代码TA
                                   ,CPTZQX                   --产品投资期限
                                   ,YQSY                     --预期收益
                                   ,XTBS                 	   --系统标识                        									
 ) 
 PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.ID              as ID                --ID
                                   ,t.CPDM            as CPDM              --产品代码
                                   ,t.CPDM_XT         as CPDM_XT           --产品代码_系统
                                   ,t.CPJP            as CPJP              --产品简拼
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.CPFL AS VARCHAR(20))),'ERR')) AS VARCHAR(20))           as CPFL              --产品大类
  								   ,t.CPMC            as CPMC              --产品名称
                                   ,t.CPQC            as CPQC              --产品全称
                                   ,t.SYLX            as SYLX              --收益类型
                                   ,t.CPLX            as CPLX              --产品类型
                                   ,t.FXPJ            as FXPJ              --风险评级
                                   ,t.FXJB_FXF        as FXJB_FXF          --风险级别_发行方
                                   ,CASE WHEN t.TZQX IN (1,2,4)
 								         THEN NULL
										 ELSE TZQX
										 END          as TZTS              --投资天数
                                   ,CAST(T.TZPZ AS STRING) AS TZPZ         --投资品种  -- CAST(COALESCE(t2.MBDM,NULLIF(CONCAT('ERR',CAST(t.TZPZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20))            as TZPZ              --投资品种
                                   ,t.CPPJ            as CPPJ              --产品评级
                                   ,CAST(COALESCE(t4.MBDM,NULLIF(CONCAT('ERR',CAST(t.JYS AS VARCHAR(20))),'ERR')) AS VARCHAR(20))         as OTC_JYS           --销售市场
                                   ,t.FXJG            as FXJG              --发行机构
                                   ,t.ZLXS            as ZLXS              --是否主力销售
                                   ,t.SFRX            as SFRX              --热销标志
                                   ,t.SFXCP           as SFXCP             --新产品
                                   ,t.CXGX            as CXGX              --承销关系
                                   ,t.ZYCD            as ZYCD              --重要程度
                                   ,CAST(COALESCE(t3.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20))      as BZDM              --币种代码
                                   ,t.CPZT            as CPZT              --产品状态
                                   ,t.SJBZ            as SJBZ              --上架标志
                                   ,t.SJRQ            as SJRQ              --上架日期
                                   ,t.CPDM_WB         as CPDM_WB           --产品代码外部
                                   ,t.CPDM_TA         as CPDM_TA           --产品代码TA
                                   ,cast(CASE WHEN t.TZQX IN (1,2,4)
								              AND t.CPTZQX IS NULL
 								              THEN t.TZQX
										      WHEN t.TZQX BETWEEN 5 AND 365
										      AND  t.CPTZQX IS NULL
										      THEN 1
										      WHEN t.TZQX BETWEEN 365 AND 1825
										      AND  t.CPTZQX IS NULL
										      THEN 2
										      WHEN t.TZQX > 1825
										      AND  t.CPTZQX IS NULL
										      THEN 4
										      ELSE t.CPTZQX
										      END AS string)        as CPTZQX            --产品投资期限
                                   ,t.YQSY            as YQSY              --预期收益
                                   ,'OTC'             as XTBS          	   --系统标识  										

									
									
 FROM	OTCCX.PRODUCT_TFP_CPDM  t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING    t1
 ON             t1.YXT = 'OTC'
 AND            t1.DMLX = 'OTC_CPFL'
 AND            t1.YDM = CAST(t.CPFL AS VARCHAR(20))
 --LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING    t2
 --ON             t2.YXT = 'OTC'
 --AND            t2.DMLX = 'TZPZ'
 --AND            t2.YDM = CAST(t.TZPZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING   t3
 ON             t3.YXT = 'OTC'
 AND            t3.DMLX = 'BZDM'
 AND            t3.YDM = CAST(t.BZ AS VARCHAR(20))
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING    t4
 ON             t4.YXT = 'OTC'
 AND            t4.DMLX = 'OTC_JYS'
 AND            t4.YDM = CAST(t.JYS AS VARCHAR(20))
 WHERE 	        t.DT = '%d{yyyyMMdd}'
 ;

---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TFP_CPDM',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
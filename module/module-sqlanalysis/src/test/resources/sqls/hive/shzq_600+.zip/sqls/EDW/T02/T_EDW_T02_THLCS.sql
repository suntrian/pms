 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:汇率参数表                                                                */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                       */
  TRUNCATE TABLE EDW_PROD.T_EDW_T02_THLCS ;
--------插入数据开始---------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_THLCS(
                                    BZ1                                 --货币代码1                              
                                   ,BZ2                                 --货币代码2                              
                                   ,XCMRJ                               --现钞买入价                              
                                   ,XCMCJ                               --现钞卖出价                              
                                   ,XHMRJ                               --现汇买入价                              
                                   ,XHMCJ                               --现汇卖出价                              
                                   ,GSBL                                --估算比例                               
                                   ,GXRQ                                --更新日期                               
                                   ,HLBZ                                --汇率标志 
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.BZ1                                 as BZ1                                 --货币代码1                               
                                   ,t.BZ2                                 as BZ2                                 --货币代码2                               
                                   ,t.XCMRJ                               as XCMRJ                               --现钞买入价                               
                                   ,t.XCMCJ                               as XCMCJ                               --现钞卖出价                               
                                   ,t.XHMRJ                               as XHMRJ                               --现汇买入价                               
                                   ,t.XHMCJ                               as XHMCJ                               --现汇卖出价                               
                                   ,t.GSBL                                as GSBL                                --估算比例                                
                                   ,t.XGRQ                                as GXRQ                                --更新日期                                
                                   ,t.HLBZ                                as HLBZ                                --汇率标志  
                                   ,'JZJY'                                as XTBS								   
 FROM      JZJYCX.ACCOUNT_THLCS t
 WHERE     t.DT = '%d{yyyyMMdd}';
-----------插入数据结束-------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_THLCS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_THLCS;
 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:普通账户负债明细历史表                                                         */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2017-02-02                                                                        */ 

 -----创建临时表(总利息)
DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS_TEMP ;
CREATE TABLE DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS_TEMP
as SELECT       XYBH
               ,WTLB
               ,SUM(ROUND(CASE WHEN WTLB = 53 
			               AND  XYBH IN (799,550,35,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1)
                           AND  SYBZ > = 0					 
					       THEN  a.CJJG*a.CJJE*b.NUM*1.000000/360+NVL(a.TZLX,0)
					       WHEN WTLB = 53 
			               AND  XYBH NOT IN (799,550,35,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1) 
					       AND  SYBZ > = 0
					       THEN  a.CJJG*a.CJJE*b.NUM*1.000000/365+NVL(a.TZLX,0)
					       WHEN WTLB = 53 
			               AND  XYBH IN (799,550,35,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1) 
					       AND  SYBZ > = 0
					       THEN  a.CJJG*a.CJJE*b.NUM*1.000000/360+NVL(a.TZLX,0)
					       WHEN WTLB = 53 
			               AND  XYBH NOT IN (799,550,35,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1) 
					       AND  SYBZ > = 0
					       THEN  a.CJJG*a.CJJE*b.NUM*1.000000/365+NVL(a.TZLX,0)
					       ELSE 0
					       END,2)
						)     as ZLX
   FROM         EDW_PROD.T_EDW_T02_TZYHGLS   a
  LEFT JOIN   (SELECT   TRD_DT,COUNT(1) as NUM 
               FROM     EDW_PROD.T_EDW_T99_TRD_DATE
               WHERE    BUS_DATE = %d{yyyyMMdd}
			   AND      TRD_DT >   20130901
			   GROUP BY TRD_DT
			  )           b
  ON           a.BUS_DATE = b.TRD_DT
  WHERE        SUBSTR(a.CJBH,1,1) < > '-'  --债券市值
  AND           a.WTLB = 53
  AND           LENGTH(TRIM(NVL(a.CJBH,''))) > 0  
  AND           BUS_DATE < = %d{yyyyMMdd}
  AND           a.JSBZ < > 1
  GROUP BY     XYBH,WTLB ;  
  
  ------------------------
  


--------------插入数据-------------
INSERT OVERWRITE DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS
(                                 
                                   CUST_NO                            --客户号           
                                  ,CUST_NAME                          --客户姓名 
                                  ,SHRHLD_N0				          --股东号								  
                                  ,BRH_NO                             --营业部编号       
                                 -- ,BRH_NAME                           --营业部名称       
                                  ,EXG                                --交易所
                                  ,SEC_CD                             --证券代码
                                  ,SEC_NAME                           --证券名称
                                  ,SEC_CGY                            --证券类别
                                  ,CCY_CD                             --币种代码
								  ,QTY_GL					 		  --负债数量                                
                                  ,ORDI_ACCT_GL_PRINP                 --普通账户负债本金
                                  ,ORDI_ACCT_GL_TOT_PRINP             --普通账户负债总利息
                                  ,ORDI_ACCT_GL_ADD_PRINP			  --普通账户新增利息
								  ,MTCH_AMT                           --成交金额     
								  ,PRDCT_RTN_PRINP                    --预计归还金额
								  ,INTSETL_AMT                        --结息金额
								  ,CL
) 
 partition(bus_date = %d{yyyyMMdd} )
 SELECT 
                                    t.KHH                                    as CUST_NO                            --客户号           
                                   ,t.KHXM                                   as CUST_NAME                          --客户姓名 
                                   ,t.GDH                                    as SHRHLD_N0				           --股东号					
                                   ,t.YYB                                    as BRH_NO                             --营业部编号       
                                  
                                   ,t.JYS                                    as EXG                                --交易所
                                   ,t.ZQDM                                   as SEC_CD                             --证券代码
                                   ,t.ZQMC                                   as SEC_NAME                           --证券名称
                                   ,t.ZQLB                                   as SEC_CGY                            --证券类别   
                                   ,t.JSBZDM                                 as CCY_CD                             --币种代码
                                   ,SUM(NVL(t.CJSL,0))                       as QTY_GL					 		   --负债数量                                                 
                                   ,SUM(NVL(t.CJJE,0))                       as ORDI_ACCT_GL_PRINP                 --普通账户负债本金  																																		                                                           
                                   ,SUM(0)                                   as ORDI_ACCT_GL_TOT_PRINP             --普通账户负债总利息息		
                                   ,SUM(0)                                   as ORDI_ACCT_GL_ADD_PRINP			   --普通账户新增利息
                                   ,SUM(NVL(t.CJJE,0))                       as MTCH_AMT                           --成交金额                     
                                   ,SUM(0)                                   as PRDCT_RTN_PRINP                            --交收金额		
                                   ,SUM(0)                                   as INTSETL_AMT                            --结息金额
                                   ,'回购' as CL
 FROM          EDW_PROD.T_EDW_T05_TDJSQSZL                                             t   
  WHERE         t.BUS_DATE = %d{yyyyMMdd} AND t.ZQLB LIKE 'H%' AND t.WTLB IN (4,114)   AND t.JSBZ_2 = 0  AND JSRQ_2 > %d{yyyyMMdd}           --债券市值
  GROUP BY      CUST_NO,CUST_NAME,SHRHLD_N0,BRH_NO,EXG,SEC_CD,SEC_NAME,SEC_CGY,CCY_CD
 UNION ALL
 SELECT 
                                    t.KHH                                    as CUST_NO                            --客户号           
                                   ,t.KHXM                                   as CUST_NAME                          --客户姓名 
                                   ,t.GDH                                    as SHRHLD_N0				           --股东号					
                                   ,t.YYB                                    as BRH_NO                             --营业部编号                                         
                                   ,t.JYS                                    as EXG                                --交易所
                                   ,t.ZQDM                                   as SEC_CD                             --证券代码
                                   ,t.ZQMC                                   as SEC_NAME                           --证券名称
                                   ,a1.ZQLB                                  as SEC_CGY                            --证券类别   
                                   ,'RMB'                                    as CCY_CD                             --币种代码
                                   ,SUM(NVL(t.CJSL,0))                       as QTY_GL					 		   --负债数量                                                 
                                   ,SUM(t.CJJE+a2.ZLX-t.JSJE)                as ORDI_ACCT_GL_PRINP                 --普通账户负债本金  																																		                                                           
                                   ,SUM(a2.ZLX)                              as ORDI_ACCT_GL_TOT_PRINP             --普通账户负债总利息息		
                                   ,SUM(ROUND(CASE WHEN t.WTLB = 53 
			                                       AND  t.XYBH IN (799,550,35,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1)
                                                   AND  t.SYBZ > = 0					 
					                               THEN t.CJJG*t.CJJE*a3.NUM*1.000000/360+NVL(t.TZLX,0)
					                               WHEN t.WTLB = 53 
			                                       AND  t.XYBH NOT IN (799,550,35,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1) 
					                               AND  t.SYBZ > = 0
					                               THEN t.CJJG*t.CJJE*a3.NUM*1.000000/360+NVL(t.TZLX,0)
					                               WHEN t.WTLB = 53 
			                                       AND  t.XYBH IN (799,550,35,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1) 
					                               AND  t.SYBZ > = 0
					                               THEN t.CJJG*t.CJJE*a3.NUM*1.000000/365+NVL(t.TZLX,0)
					                               WHEN t.WTLB = 53 
			                                       AND  t.XYBH NOT IN (799,550,35,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1) 
					                               AND  t.SYBZ > = 0
					                               THEN  t.CJJG*t.CJJE*a3.NUM*1.000000/365+NVL(t.TZLX,0)
					                               ELSE 0
					                               END,2
												 )
						                  )                                  as ORDI_ACCT_GL_ADD_PRINP			   --普通账户新增利息
                                   ,SUM(NVL(t.CJJE,0))                       as MTCH_AMT                           --成交金额                     
                                   ,SUM(NVL(t.JSJE,0))                         as PRDCT_RTN_PRINP                    --预计归还金额		
                                   ,SUM(NVL(t.JXJE,0))                       as INTSETL_AMT                         --结息金额
                                    ,DECODE(t.WTFS,8,'股票质押','小微贷') as CL
  FROM          EDW_PROD.T_EDW_T02_TZYHGLS                                             t
  LEFT JOIN     EDW_PROD.T_EDW_T04_TZQDM                                              a1
  ON            t.JYS = a1.JYS
  AND           t.ZQDM = a1.ZQDM
  AND           a1.BUS_DATE = %d{yyyyMMdd}
  LEFT JOIN     DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS_TEMP                   a2
  ON            t.XYBH = a2.XYBH
  AND           t.WTLB = a2.WTLB   
  LEFT JOIN   (SELECT   TRD_DT,COUNT(1) as NUM 
               FROM     EDW_PROD.T_EDW_T99_TRD_DATE
               WHERE    BUS_DATE = %d{yyyyMMdd}
			   AND      TRD_DT =   %d{yyyyMMdd}
			   GROUP BY TRD_DT
			  )                                                a3
  ON           t.BUS_DATE = a3.TRD_DT
  WHERE         t.BUS_DATE = %d{yyyyMMdd} 
  AND           t.JSBZ = 0 
  AND           t.CJRQ < = %d{yyyyMMdd}
  AND           SUBSTR(t.CJBH,1,1) < > '-'  --债券市值
  AND           t.WTLB = 53
  AND           LENGTH(TRIM(NVL(t.CJBH,''))) > 0 
  GROUP BY      CUST_NO,CUST_NAME,SHRHLD_N0,BRH_NO,EXG,SEC_CD,SEC_NAME,SEC_CGY,CCY_CD,cl
;		
---------------- 插入数据结束 -----------------------
 DROP TABLE IF EXISTS DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS_TEMP;
 
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_F00_AST_ORDI_ACCNT_GL_DTL_HIS ;
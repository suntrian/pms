 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:融券证券头寸明细表                                                                */
  --/* 创建人:黄勇华                                                                              */
  --/* 创建时间:2016-11-02                                                                       */
 TRUNCATE TABLE EDW_PROD.T_EDW_T02_TXY_RQZQTCMX; 
-------插入数据开始-------------------
INSERT OVERWRITE EDW_PROD.T_EDW_T02_TXY_RQZQTCMX(
                                    XXBH                                --信息编号                               
                                   ,QYSX                                --券融属性                               
                                   ,BZDM                                --币种代码                               
                                   ,JYS                                 --交易所                                
                                   ,GDH                                 --股东号                                
                                   ,ZQDM                                --证券代码                               
                                   ,ZQLB                                --证券类别                               
                                   ,ZQMC                                --证券名称                               
                                   ,ZQSL                                --证券数量                               
                                   ,DJSL                                --冻结数量                               
                                   ,MCWTSL                              --卖出委托数量                             
                                   ,RCSL                                --已融出数量                              
                                   ,YYSL                                --预约数量                               
                                   ,KCRQ                                --开仓日期                               
                                   ,DQRQ                                --到期日期                               
                                   ,WBLSH                               --外部流水号                              
                                   ,BDRQ                                --变动日期   
                                   ,XTBS								   
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                                    t.XXBH                                as XXBH                                --信息编号                                
                                   ,t.QYSX                                as QYSX                                --券融属性                                
                                   ,CAST(COALESCE(t1.MBDM,NULLIF(CONCAT('ERR',CAST(t.BZ AS VARCHAR(20))),'ERR')) AS VARCHAR(20) )                                  as BZDM                                --币种                                  
                                   ,t.JYS                                 as JYS                                 --交易所                                 
                                   ,t.GDH                                 as GDH                                 --股东号                                 
                                   ,t.ZQDM                                as ZQDM                                --证券代码                                
                                   ,t.ZQLB                                as ZQLB                                --证券类别                                
                                   ,t.ZQMC                                as ZQMC                                --证券名称                                
                                   ,t.ZQSL                                as ZQSL                                --证券数量                                
                                   ,t.DJSL                                as DJSL                                --冻结数量                                
                                   ,t.MCWTSL                              as MCWTSL                              --卖出委托数量                              
                                   ,t.RCSL                                as RCSL                                --已融出数量                               
                                   ,t.YYSL                                as YYSL                                --预约数量                                
                                   ,t.KCRQ                                as KCRQ                                --开仓日期                                
                                   ,t.DQRQ                                as DQRQ                                --到期日期                                
                                   ,t.WBLSH                               as WBLSH                               --外部流水号                               
                                   ,t.BDRQ                                as BDRQ                                --变动日期  
                                   ,'RZRQ'							      as XTBS	   
 FROM           RZRQCX.MARGIN_TXY_RQZQTCMX             t
 LEFT JOIN      EDW_PROD.T_EDW_T99_PUBLIC_CODE_MAPPING t1 
 ON             t1.DMLX = 'BZDM'
 AND            t1.YXT = 'JZJY'
 AND            t1.YDM = CAST(t.BZ AS VARCHAR(20))
 WHERE          t.DT = '%d{yyyyMMdd}';
---------插入数据结束----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T02_TXY_RQZQTCMX',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
  invalidate metadata EDW_PROD.T_EDW_T02_TXY_RQZQTCMX;
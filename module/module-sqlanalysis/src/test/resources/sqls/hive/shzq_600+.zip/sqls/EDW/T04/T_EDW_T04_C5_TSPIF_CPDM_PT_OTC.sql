 --/* ***************************************** SQL Begin ***************************************** */
  --/* 脚本功能:OTC平台属性                                                                 */
  --/* 创建人:段智泓                                                                              */
  --/* 创建时间:2018-12-20                                                                       */ 
  
-----------插入数据开始----------------
INSERT OVERWRITE EDW_PROD.T_EDW_T04_C5_TSPIF_CPDM_PT_OTC(
                     ID              --ID
                    ,CPID            --金融产品
                    ,RGJEQD          --认购金额起点
                    ,DBZGRGJE        --单笔最高认购金额
                    ,ZXZJRGDW        --最小追加认购单位
                    ,GRZHLJRGSX      --个人账户累计认购上限
                    ,JGZHLJRGSX      --机构账户累计认购上限
                    ,SFYDYDX         --是否一对一定向
                    ,DXDX            --定向对象
                    ,RGQD            --认购渠道 
                    ,SFPEFX          --是否配额发行
                    ,YLRGDX          --预留认购对象
                    ,YLRGRS          --预留认购人数（人）
                    ,YLRGED          --预留认购额度（元）
                    ,YLMEZGBL        --预留名额最高比例（%）
                    ,YLJEZGBL        --预留金额最高比例（%）
                    ,YLMEBL          --预留名额比例（%）
                    ,YLJEBL          --预留金额比例（%）
                    ,SSTA            --所属TA
                    ,TADM            --TA代码 
                    ,FXPSFS          --发行配售方式 
                    ,CERGSFBFQR      --超额认购是否部分确认 
                    ,RGQLXCLFS       --认购期利息处理方式 
                    ,RGQJLL          --认购期间利率（%） 
                    ,RGQLXTHR        --认购利息退还日 
                    ,LXJSSFHF        --利息计算是否含费 
                    ,SCTZSFHF        --首次投资是否含费 
                    ,ZJTZSFHF        --追加投资是否含费 
                    ,FLJSFS          --费率计算方式 
                    ,RGFYJSFS        --认购费用计算方式 
                    ,FELB            --份额类别 
                    ,RGSLZJJSR       --认购受理资金交收日(确认日+) 
                    ,RGJGZIJSR       --认购结果资金交收日(确认日+) 
                    ,MJSBZJJSR       --募集失败资金交收日(确认日+) 
                    ,FHZJJSR         --分红（付息）资金交收日（确认日+）
                    ,DQZJJSR         --到期资金交收日(确认日+) 
                    ,JSPC            --交收批次
                    ,RGQLXJXJZR      --认购期利息计息截止日期
) 
PARTITION( bus_date = %d{yyyyMMdd})
 SELECT 
                     t.ID            --ID
                    ,t.CPID          --金融产品
                    ,t.RGJEQD        --认购金额起点
                    ,t.DBZGRGJE      --单笔最高认购金额
                    ,t.ZXZJRGDW      --最小追加认购单位
                    ,t.GRZHLJRGSX    --个人账户累计认购上限
                    ,t.JGZHLJRGSX    --机构账户累计认购上限
                    ,t.SFYDYDX       --是否一对一定向
                    ,t.DXDX          --定向对象
                    ,t.RGQD          --认购渠道 
                    ,t.SFPEFX        --是否配额发行
                    ,t.YLRGDX        --预留认购对象
                    ,t.YLRGRS        --预留认购人数（人）
                    ,t.YLRGED        --预留认购额度（元）
                    ,t.YLMEZGBL      --预留名额最高比例（%）
                    ,t.YLJEZGBL      --预留金额最高比例（%）
                    ,t.YLMEBL        --预留名额比例（%）
                    ,t.YLJEBL        --预留金额比例（%）
                    ,t.SSTA          --所属TA
                    ,t.TADM          --TA代码 
                    ,t.FXPSFS        --发行配售方式 
                    ,t.CERGSFBFQR    --超额认购是否部分确认 
                    ,t.RGQLXCLFS     --认购期利息处理方式 
                    ,t.RGQJLL        --认购期间利率（%） 
                    ,t.RGQLXTHR      --认购利息退还日 
                    ,t.LXJSSFHF      --利息计算是否含费 
                    ,t.SCTZSFHF      --首次投资是否含费 
                    ,t.ZJTZSFHF      --追加投资是否含费 
                    ,t.FLJSFS        --费率计算方式 
                    ,t.RGFYJSFS      --认购费用计算方式 
                    ,t.FELB          --份额类别 
                    ,t.RGSLZJJSR     --认购受理资金交收日(确认日+) 
                    ,t.RGJGZIJSR     --认购结果资金交收日(确认日+) 
                    ,t.MJSBZJJSR     --募集失败资金交收日(确认日+) 
                    ,t.FHZJJSR       --分红（付息）资金交收日（确认日+）
                    ,t.DQZJJSR       --到期资金交收日(确认日+) 
                    ,t.JSPC          --交收批次
                    ,t.RGQLXJXJZR	 --认购期利息计息截止日期		   
 FROM       C5CX.SPIF_TSPIF_CPDM_PT_OTC    t
 WHERE      t.DT = '%d{yyyyMMdd}';
----插入数据结束--------------



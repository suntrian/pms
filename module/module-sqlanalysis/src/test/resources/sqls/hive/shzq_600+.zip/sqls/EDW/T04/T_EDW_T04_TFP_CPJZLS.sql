--/* ***************************************** SQL Begin ***************************************** */
--/* 脚本功能:金融产品净值表                                                                           */
--/* 创建人:黄勇华                                                                                 */
--/* 创建时间:2016-11-02                                                                           */ 



 ---插入数据
 INSERT OVERWRITE EDW_PROD.T_EDW_T04_TFP_CPJZLS
 (
              CPID                   --产品ID
             ,CPDM                   --产品代码
             ,JGDM                   --发行机构代码
             ,RQ                     --净值日期
             ,CPJZ_SR                --上日产品单位净值
             ,CPJZ                   --产品单位净值
			 ,LJJZ                   --单位累计净值
			 ,CPGM                   --产品规模(亿)
			 ,CPSZ                   --产品市值(亿)
			 ,SJSYL                  --实际收益率
			 ,YQSYL                  --预计收益率 
             ,XTBS                   --系统标识			 
) 
 PARTITION( BUS_DATE = %d{yyyyMMdd} ) 
 SELECT       t.CPID              as CPID         --产品ID
             ,t.CPDM              as CPDM         --产品代码
             ,t.JGDM              as JGDM         --发行机构代码
             ,t.RQ                as RQ           --净值日期
             ,t.CPJZ_SR           as CPJZ_SR      --上日产品单位净值
             ,t.CPJZ              as CPJZ         --产品单位净值
             ,t.LJJZ              as LJJZ         --单位累计净值
             ,t.CPGM              as CPGM         --产品规模(亿)
             ,t.CPSZ              as CPSZ         --产品市值(亿)
             ,t.SJSYL             as SJSYL        --实际收益率
             ,t.YQSYL             as YQSYL        --预计收益率
             ,'OTC'               as XTBS    			 
             --,CAST(t.DT as INT)   as BUS_DATE			 
 FROM  OTCCX.FPSS_HIS_TFP_CPJZLS   t 
 WHERE DT = '%d{yyyyMMdd}'
 ;
---------------- 数据插入结束
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('EDW_PROD','T_EDW_T04_TFP_CPJZLS',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 

------/* ***************************************** SQL Begin ***************************************** */
------/* 脚本功能:基金业务代码                                                                      */
------/* 创建人:黄勇华                                                                               */
------/* 创建时间:2016-11-30                                                                        */ 
--------------插入数据-------------------
TRUNCATE TABLE DDW_PROD.T_DDW_PUB_FND_BIZ_CD ;
INSERT OVERWRITE DDW_PROD.T_DDW_PUB_FND_BIZ_CD
(
               FND_BIZ_CD           --基金业务代码
              ,FND_BIZ_NAME         --基金业务名称
              ,FND_BIZ_CGY          --基金业务类别  							                                   								
 ) 
 partition(bus_date=%d{yyyyMMdd})
 SELECT         t.YWDM	      as FND_BIZ_CD           --基金业务代码                          
               ,t.YWMC        as FND_BIZ_NAME         --基金业务名称 
               ,t.YWLB        as FND_BIZ_CGY          --基金业务类别   	                                        						    
 FROM           EDW_PROD.T_EDW_T99_TOF_YWDM                     t       
 WHERE          t.BUS_DATE = %d{yyyyMMdd} 
 ;
---------------- 插入数据结束 -----------------------
INSERT INTO DDW_PROD.T_DDW_DAY_END (USER,TABLE_NAME,UPDATE_TIME ) 
PARTITION( BUS_DATE = %d{yyyyMMdd})VALUES('DDW_PROD','T_DDW_PUB_FND_BIZ_CD',from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')) ;
 invalidate metadata DDW_PROD.T_DDW_PUB_FND_BIZ_CD;